; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:errNarrow" = type { { i64, ptr }, i32, i64, i64, i1, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:ctSource" = type { { i64, ptr }, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/check:factsCopy" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:factRead" = type { i64, i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:Verdict" = type { { i64, ptr }, { i64, ptr }, i1, i32, { i64, ptr }, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/check:laneVals" = type { i64, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/check:collWalk" = type { ptr, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca %"std/prelude/text:StringBuilder"
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca i32
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l97 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t8)
  store %"compiler/source:Span" %t10, ptr %l16
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l19
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l19
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16)
  store { i64, ptr } %t17, ptr %l20
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v0, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l16
  %t22 = load %"compiler/diagmsg:Msg", ptr %l21
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l22
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t24 = call ptr @__olang_scope_hold(ptr %s0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l23, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = call ptr @__olang_region_make(ptr %s0)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t32 = load i64, ptr %l23
  %t33 = inttoptr i64 %t32 to ptr
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t33, ptr %t30, i32 %t31)
  store { i64, ptr } %t36, ptr %l27
  br label %bb11
bb11:
  %t37 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t42 = icmp eq i64 %t40, 0
  br i1 %t42, label %bb14, label %bb15
bb13:
  %t44 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t44, ptr %l5, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l35
  br label %bb16
bb14:
  store { i64, ptr } zeroinitializer, ptr %l27, !tbaa !27
  br label %bb15
bb15:
  %t55 = load i64, ptr %l23
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = load { i64, ptr }, ptr %l27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = icmp ne ptr %t59, null
  %t61 = select i1 %t60, ptr %t59, ptr null
  call void @__olang_region_settle_in(ptr %t56, ptr %t61)
  br label %bb13
bb16:
  %t62 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t64 = trunc i64 22 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t67, ptr %l38
  br label %bb19
bb18:
  br label %bb44
bb19:
  %t68 = load %"std/prelude/text:StringBuilder", ptr %l38
  store %"std/prelude/text:StringBuilder" %t68, ptr %l6
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l46
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l41, !tbaa !29
  %t86 = load i32, ptr %l46, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t85, i32 %t86)
  store { i64, ptr } %t87, ptr %l47
  br label %bb21
bb21:
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb24:
  br label %bb25
bb25:
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  store i32 %t107, ptr %l10, !tbaa !23
  %t110 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l6)
  store i64 %t110, ptr %l58
  br label %bb26
bb26:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = icmp sgt i64 %t111, 0
  br i1 %t112, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s5, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  store ptr %l6, ptr %l61, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l10, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l64
  br label %bb31
bb31:
  %t120 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t121 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t121, { i64, ptr } %t120)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb22
bb34:
  %t128 = call ptr @__olang_scope_hold(ptr %s0)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l69, !tbaa !24
  %t130 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5
  br i1 %t130, label %bb35, label %bb36
bb35:
  %t132 = call ptr @__olang_region_make(ptr %s0)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l69, !tbaa !24
  br label %bb36
bb36:
  %t134 = load i64, ptr %l69
  %t135 = inttoptr i64 %t134 to ptr
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %t135, ptr %l6)
  store { i64, ptr } %t137, ptr %l72
  br label %bb37
bb37:
  %t138 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t143 = icmp eq i64 %t141, 0
  br i1 %t143, label %bb40, label %bb41
bb39:
  %t145 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t145, ptr %l76, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t146, ptr %l5, !tbaa !27
  %t147 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5
  br i1 %t147, label %bb42, label %bb43
bb40:
  store { i64, ptr } zeroinitializer, ptr %l72, !tbaa !27
  br label %bb41
bb41:
  %t149 = load i64, ptr %l69
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = load { i64, ptr }, ptr %l72
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = call ptr @__olang_region_or(ptr %t152, ptr null)
  %t154 = icmp ne ptr %t153, null
  %t155 = select i1 %t154, ptr %t153, ptr null
  call void @__olang_region_settle_in(ptr %t150, ptr %t155)
  br label %bb39
bb42:
  %t156 = load { i64, ptr }, ptr %l76
  %t157 = extractvalue { i64, ptr } %t156, 1
  call void @__olang_region_release(ptr %t157)
  store { i64, ptr } zeroinitializer, ptr %l76
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l78, !tbaa !29
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t161 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t159)
  store %"compiler/source:Span" %t161, ptr %l80
  br label %bb45
bb45:
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l81, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t163, ptr %l82, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 0
  %t167 = load ptr, ptr %t166, !tbaa !39
  %t169 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t167)
  store %"compiler/source:Span" %t169, ptr %l84
  br label %bb46
bb46:
  %t170 = getelementptr %"compiler/source:Span", ptr %l84, i32 0, i32 0
  %t171 = load i32, ptr %t170, !tbaa !23
  store i32 %t171, ptr %l85, !tbaa !23
  %t174 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t174, ptr %l87
  br label %bb47
bb47:
  %t175 = getelementptr %"compiler/source:Span", ptr %l87, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load i32, ptr %l85, !tbaa !23
  %t179 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t177, i32 %t176)
  store %"compiler/source:Span" %t179, ptr %l89
  br label %bb48
bb48:
  %t180 = load ptr, ptr %l81, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t180, %"compiler/source:Span" %t181)
  store { i64, ptr } %t182, ptr %l90
  br label %bb49
bb49:
  %t183 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t183, ptr %l91, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l92, !tbaa !29
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t185)
  store %"compiler/source:Span" %t187, ptr %l94
  br label %bb50
bb50:
  %t188 = load ptr, ptr %l92, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l94
  %t190 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t188, %"compiler/source:Span" %t189)
  store { i64, ptr } %t190, ptr %l95
  br label %bb51
bb51:
  %t191 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t194 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t191, { i64, ptr } %t192, { i64, ptr } %t193)
  store %"compiler/diagmsg:Msg" %t194, ptr %l96
  br label %bb52
bb52:
  %t195 = load ptr, ptr %l78, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l80
  %t197 = load %"compiler/diagmsg:Msg", ptr %l96
  %t198 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t195, %"compiler/source:Span" %t196, %"compiler/diagmsg:Msg" %t197)
  store i64 %t198, ptr %l97
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:ownerAt"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca %"compiler/check:ownerAt"
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store %"compiler/check:ownerAt" %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load %"compiler/check:ownerAt", ptr %l15
  store %"compiler/check:ownerAt" %t27, ptr %l4
  %t28 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = getelementptr %"compiler/check:ownerAt", ptr %l4, i32 0, i32 1
  %t44 = load i1, ptr %t43, !tbaa !21
  %t49 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t39, i32 %t41, i32 %t42, i1 %t44)
  store i64 %t49, ptr %l25
  br label %bb10
bb10:
  %t50 = load i64, ptr %l25, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5d13064994ae0ba3_8fd3ca0506e03b5f)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 2
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { ptr }, ptr %t32, i32 0, i32 0
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t42)
  store i32 %t45, ptr %l25
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = load i32, ptr %l25, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t48, ptr %l26
  br label %bb12
bb12:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_9f696ab3dd58ed55_6fb72788626d8d91)
  unreachable
bb18:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l28, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 12
  store i1 %t58, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l29, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Seq", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_53a208522c5b83d_88406af5a3018049)
  unreachable
bb27:
  br label %bb28
bb28:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Seq", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load ptr, ptr %l39, !tbaa !29
  %t89 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerCall(ptr %v0, ptr %v1, ptr %t87, ptr %t86)
  store i1 %t89, ptr %l45
  br label %bb29
bb29:
  %t90 = load i1, ptr %l45, !tbaa !21
  store i1 %t90, ptr %l38, !tbaa !21
  br label %bb30
bb30:
  %t91 = load i1, ptr %l38, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_396e8fee6f4dc59f_ecca1e109e67d07b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/source:Span" %a3, i32 %a4, { i64, ptr } %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/generic:Desc"
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca ptr
  %l56 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l106 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l123 = alloca ptr
  %l127 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, ptr }
  %l138 = alloca %"compiler/diagmsg:Msg"
  %l139 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca { i64, ptr }
  %l157 = alloca %"compiler/diagmsg:Msg"
  %l158 = alloca i64
  %l163 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l173 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l182 = alloca %"compiler/diagmsg:Msg"
  %l183 = alloca i64
  %l186 = alloca ptr
  %l191 = alloca i32
  %l199 = alloca ptr
  %l202 = alloca i1
  %l206 = alloca %"compiler/generic:Desc"
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/source:Span"
  %l216 = alloca %"compiler/generic:Desc"
  %l218 = alloca ptr
  %l221 = alloca i1
  %l225 = alloca %"compiler/generic:Desc"
  %l232 = alloca %"compiler/generic:Desc"
  %l236 = alloca i32
  %l239 = alloca i1
  %l245 = alloca ptr
  %l250 = alloca i32
  %l258 = alloca ptr
  %l259 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca i32
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l270 = alloca i32
  %l271 = alloca { i64, ptr }
  %l275 = alloca ptr
  %l278 = alloca i1
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l288 = alloca ptr
  %l290 = alloca ptr
  %l295 = alloca i32
  %l298 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l309 = alloca i1
  %l310 = alloca i1
  %l318 = alloca ptr
  %l321 = alloca i1
  %l324 = alloca i1
  %l330 = alloca ptr
  %l333 = alloca i1
  %l338 = alloca i32
  %l342 = alloca ptr
  %l343 = alloca %"compiler/source:Span"
  %l346 = alloca { i64, ptr }
  %l348 = alloca %"compiler/diagmsg:Msg"
  %l349 = alloca i64
  %l354 = alloca ptr
  %l359 = alloca ptr
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l20, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l24
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t21, ptr %l7
  %t22 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 9}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t30, ptr %l29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i32, ptr %l4, !tbaa !23
  %t41 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t34, i64 %t36, i32 %t37)
  store i64 %t41, ptr %l34
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l35, !tbaa !27
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6af63211fe08a219_4bcf48e786826ca5)
  unreachable
bb8:
  %t47 = mul i64 0, 8
  %t48 = insertvalue { i64, ptr } undef, i64 0, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6af63211fe08a219_4bcf48e786826ca5)
  unreachable
bb10:
  %t52 = icmp sle i64 0, 2305843009213693951
  br i1 %t52, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_31ceea79ef23e30c_3748df63b5867238)
  unreachable
bb12:
  %t54 = mul i64 0, 4
  %t55 = insertvalue { i64, ptr } undef, i64 0, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l28
  %t59 = load %"compiler/source:Span", ptr %l29
  %t60 = load i64, ptr %l34, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t57, %"compiler/source:Span" %t58, %"compiler/source:Span" %t59, i64 %t60, ptr null, { i64, ptr } %t61, { i64, ptr } %t62, { i64, ptr } %t56)
  store ptr %t64, ptr %l42
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_31ceea79ef23e30c_3748df63b5867238)
  unreachable
bb14:
  %t65 = load ptr, ptr %l42, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb15:
  %t66 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 9}
  %t69 = trunc i64 7 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l45, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t73, ptr %l46
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l4, !tbaa !23
  %t78 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l49
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l46
  %t82 = load i32, ptr %l49, !tbaa !23
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v2, ptr %v3, ptr %t80, %"compiler/source:Span" %t81, i32 %t82, { i64, ptr } %t79)
  store ptr %t84, ptr %l51
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l51, !tbaa !29
  store ptr %t85, ptr %rv
  br label %ret
bb20:
  %t86 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !range !{i32 0, i32 9}
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i32 %t96, ptr %l56
  br label %bb23
bb22:
  br label %bb37
bb23:
  %t97 = load i32, ptr %l56, !tbaa !23
  store i32 %t97, ptr %l8, !tbaa !23
  %t98 = load i32, ptr %l8, !tbaa !23
  %t100 = icmp slt i32 %t98, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t102 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  store i1 %t105, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t107 = load i1, ptr %l59, !tbaa !21
  br i1 %t107, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l62, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l63
  %t110 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t110, ptr %l64
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t114, i64 %t116, i64 %t118)
  store i32 %t122, ptr %l69
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = load ptr, ptr %l62, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l63
  %t127 = load %"compiler/source:Span", ptr %l64
  %t128 = load i32, ptr %l69, !tbaa !23
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v2, ptr %v3, ptr %t125, %"compiler/source:Span" %t126, %"compiler/source:Span" %t127, i32 %t128, { i64, ptr } %t123, i32 %a6)
  store ptr %t131, ptr %l72
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l72, !tbaa !29
  store ptr %t132, ptr %rv
  br label %ret
bb31:
  %t133 = load i32, ptr %l8, !tbaa !23
  %t135 = icmp slt i32 %t133, 0
  br i1 %t135, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t137, %"compiler/source:Span" %t138)
  store ptr %t141, ptr %l77
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t142 = load ptr, ptr %l77, !tbaa !29
  store ptr %t142, ptr %rv
  br label %ret
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t145 = load %"compiler/source:Span", ptr %l3
  %t146 = load i32, ptr %l8, !tbaa !23
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t143, %"compiler/source:Span" %t144, %"compiler/source:Span" %t145, i32 %t146, { i64, ptr } %t147)
  store ptr %t153, ptr %l83
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l83, !tbaa !29
  store ptr %t154, ptr %rv
  br label %ret
bb37:
  %t155 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 9}
  %t158 = trunc i64 0 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 161
  store ptr %t163, ptr %l87, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l4, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t164, i32 %t165)
  store { i64, ptr } %t168, ptr %l90
  br label %bb40
bb39:
  br label %bb88
bb40:
  %t169 = load ptr, ptr %l87, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t169, { i64, ptr } %t170)
  br label %bb41
bb41:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodMeant(ptr %v0, ptr %v2, ptr %s6, ptr %t171, i32 %t172, { i64, ptr } %t173)
  store { i64, ptr } %t177, ptr %l94
  br label %bb42
bb42:
  %t178 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t178, ptr %l9, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t179, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t181, ptr %l96
  br label %bb43
bb43:
  %t182 = load i1, ptr %l96, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l98, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t186, ptr %l99
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l4, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l102
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t192 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t196 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMethod(ptr %s7, ptr %s6, ptr %v0, { i64, ptr } %t192, { i64, ptr } %t193)
  store %"compiler/diagmsg:Msg" %t196, ptr %l105
  br label %bb47
bb47:
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l99
  %t199 = load %"compiler/diagmsg:Msg", ptr %l105
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t197, %"compiler/source:Span" %t198, %"compiler/diagmsg:Msg" %t199)
  store i64 %t200, ptr %l106
  br label %bb48
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t201, %"compiler/source:Span" %t202)
  store ptr %t205, ptr %l109
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  %t206 = load ptr, ptr %l109, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb50:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l110, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l4, !tbaa !23
  %t212 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t208, i32 %t209)
  store { i64, ptr } %t212, ptr %l113
  br label %bb51
bb51:
  %t213 = load ptr, ptr %l110, !tbaa !29
  %t214 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t215 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v0, ptr %s6, ptr %t213, { i64, ptr } %t214)
  store { i64, ptr } %t215, ptr %l114
  br label %bb52
bb52:
  %t216 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t219 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t216, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t219, ptr %l116
  br label %bb53
bb53:
  %t220 = load i1, ptr %l116, !tbaa !21
  %t221 = xor i1 %t220, true
  br i1 %t221, label %bb54, label %bb55
bb54:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l3
  %t225 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, i32 %t225, i1 false)
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t229, %"compiler/source:Span" %t230)
  store ptr %t233, ptr %l123
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  %t234 = load ptr, ptr %l123, !tbaa !29
  store ptr %t234, ptr %rv
  br label %ret
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 16
  %t238 = load i32, ptr %t237, !tbaa !23
  %t240 = icmp ne i32 %t238, 0
  br i1 %t240, label %bb59, label %bb60
bb59:
  %t242 = load i32, ptr %l4, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 16
  %t246 = load i32, ptr %t245, !tbaa !23
  %t249 = icmp eq i32 %t242, %t246
  store i1 %t249, ptr %l127, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb61
bb61:
  %t251 = load i1, ptr %l127, !tbaa !21
  br i1 %t251, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l132, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t253, ptr %l133
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l4, !tbaa !23
  %t258 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t254, i32 %t255)
  store { i64, ptr } %t258, ptr %l136
  br label %bb64
bb63:
  br label %bb68
bb64:
  %t259 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t261 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionSelf(ptr %s9, ptr %v0, { i64, ptr } %t259)
  store %"compiler/diagmsg:Msg" %t261, ptr %l138
  br label %bb65
bb65:
  %t262 = load ptr, ptr %l132, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l133
  %t264 = load %"compiler/diagmsg:Msg", ptr %l138
  %t265 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t262, %"compiler/source:Span" %t263, %"compiler/diagmsg:Msg" %t264)
  store i64 %t265, ptr %l139
  br label %bb66
bb66:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t266, %"compiler/source:Span" %t267)
  store ptr %t270, ptr %l142
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  %t271 = load ptr, ptr %l142, !tbaa !29
  store ptr %t271, ptr %rv
  br label %ret
bb68:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l143, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l4, !tbaa !23
  %t277 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t273, i32 %t274)
  store { i64, ptr } %t277, ptr %l146
  br label %bb69
bb69:
  %t278 = load ptr, ptr %l143, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t280 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s6, ptr %t278, { i64, ptr } %t279, i1 true)
  store { i64, ptr } %t280, ptr %l147
  br label %bb70
bb70:
  %t281 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t281, ptr %l11, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t286 = icmp eq i64 %t284, 0
  br i1 %t286, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s10
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l151, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t289, ptr %l152
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l4, !tbaa !23
  %t294 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t290, i32 %t291)
  store { i64, ptr } %t294, ptr %l155
  br label %bb73
bb72:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/generic:Program", ptr %t298, i32 0, i32 2
  %t301 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t300, { i64, ptr } %t301)
  store i32 %t304, ptr %l163
  br label %bb76
bb73:
  %t305 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t307 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %s10, ptr %v0, { i64, ptr } %t305)
  store %"compiler/diagmsg:Msg" %t307, ptr %l157
  br label %bb74
bb74:
  %t308 = load ptr, ptr %l151, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l152
  %t310 = load %"compiler/diagmsg:Msg", ptr %l157
  %t311 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t308, %"compiler/source:Span" %t309, %"compiler/diagmsg:Msg" %t310)
  store i64 %t311, ptr %l158
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s10)
  br label %bb86
bb76:
  %t312 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t313 = load i32, ptr %l163, !tbaa !23
  %t315 = icmp ne i32 %t313, %t312
  br i1 %t315, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s12
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l166, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t318, ptr %l167
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l4, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t319, i32 %t320)
  store { i64, ptr } %t323, ptr %l170
  br label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s13
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l175, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t325, ptr %l176
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l4, !tbaa !23
  %t330 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t326, i32 %t327)
  store { i64, ptr } %t330, ptr %l179
  br label %bb82
bb79:
  %t331 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t332 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t335 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s12, ptr %s6, ptr %v0, { i64, ptr } %t331, { i64, ptr } %t332)
  store %"compiler/diagmsg:Msg" %t335, ptr %l173
  br label %bb80
bb80:
  %t336 = load ptr, ptr %l166, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l167
  %t338 = load %"compiler/diagmsg:Msg", ptr %l173
  %t339 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t336, %"compiler/source:Span" %t337, %"compiler/diagmsg:Msg" %t338)
  store i64 %t339, ptr %l174
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb82:
  %t340 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t344 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %s13, ptr %s6, ptr %v0, { i64, ptr } %t340, { i64, ptr } %t341)
  store %"compiler/diagmsg:Msg" %t344, ptr %l182
  br label %bb83
bb83:
  %t345 = load ptr, ptr %l175, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l176
  %t347 = load %"compiler/diagmsg:Msg", ptr %l182
  %t348 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t345, %"compiler/source:Span" %t346, %"compiler/diagmsg:Msg" %t347)
  store i64 %t348, ptr %l183
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s13)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load %"compiler/source:Span", ptr %l1
  %t353 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t349, %"compiler/source:Span" %t350)
  store ptr %t353, ptr %l186
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s6)
  %t354 = load ptr, ptr %l186, !tbaa !29
  store ptr %t354, ptr %rv
  br label %ret
bb88:
  %t355 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t356 = load i32, ptr %t355, !range !{i32 0, i32 9}
  %t358 = trunc i64 1 to i32
  %t359 = icmp eq i32 %t356, %t358
  br i1 %t359, label %bb89, label %bb90
bb89:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l2, !tbaa !29
  %t365 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t361, ptr %t362)
  store i32 %t365, ptr %l191
  br label %bb91
bb90:
  br label %bb131
bb91:
  %t366 = load i32, ptr %l191, !tbaa !23
  store i32 %t366, ptr %l12, !tbaa !23
  %t367 = load i32, ptr %l12, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t371 = icmp eq i32 %t367, %t368
  br i1 %t371, label %bb92, label %bb93
bb92:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t373, { i64, ptr } %t374)
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  %t381 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t377, %"compiler/source:Span" %t378)
  store ptr %t381, ptr %l199
  br label %bb95
bb95:
  %t382 = load ptr, ptr %l199, !tbaa !29
  store ptr %t382, ptr %rv
  br label %ret
bb96:
  %t383 = load i32, ptr %l12, !tbaa !23
  %t385 = icmp sge i32 %t383, 0
  br i1 %t385, label %bb97, label %bb98
bb97:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t391 = load i32, ptr %l12, !tbaa !23
  %t394 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t390, i32 %t391)
  store %"compiler/generic:Desc" %t394, ptr %l206
  br label %bb99
bb98:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb100
bb99:
  %t395 = getelementptr %"compiler/generic:Desc", ptr %l206, i32 0, i32 0
  %t396 = load i64, ptr %t395, !tbaa !24
  %t397 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t400 = icmp eq i64 %t396, %t397
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb100
bb100:
  %t402 = load i1, ptr %l202, !tbaa !21
  br i1 %t402, label %bb101, label %bb102
bb101:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l210, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l211
  %t405 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t405, ptr %l212
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load i32, ptr %l12, !tbaa !23
  %t413 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t409, i32 %t410)
  store %"compiler/generic:Desc" %t413, ptr %l216
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t414 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t415 = load ptr, ptr %l210, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l211
  %t417 = load %"compiler/source:Span", ptr %l212
  %t418 = load %"compiler/generic:Desc", ptr %l216
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFnCall(ptr %v0, ptr %v2, ptr %v3, ptr %t415, %"compiler/source:Span" %t416, %"compiler/source:Span" %t417, %"compiler/generic:Desc" %t418, { i64, ptr } %t414)
  store ptr %t420, ptr %l218
  br label %bb104
bb104:
  %t421 = load ptr, ptr %l218, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb105:
  %t422 = load i32, ptr %l12, !tbaa !23
  %t424 = icmp sge i32 %t422, 0
  br i1 %t424, label %bb106, label %bb107
bb106:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t430 = load i32, ptr %l12, !tbaa !23
  %t433 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t429, i32 %t430)
  store %"compiler/generic:Desc" %t433, ptr %l225
  br label %bb108
bb107:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb109
bb108:
  %t434 = getelementptr %"compiler/generic:Desc", ptr %l225, i32 0, i32 0
  %t435 = load i64, ptr %t434, !tbaa !24
  %t436 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t439 = icmp eq i64 %t435, %t436
  store i1 %t439, ptr %l221, !tbaa !21
  br label %bb109
bb109:
  %t441 = load i1, ptr %l221, !tbaa !21
  br i1 %t441, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s17
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 1
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t446 = load i32, ptr %l12, !tbaa !23
  %t449 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t445, i32 %t446)
  store %"compiler/generic:Desc" %t449, ptr %l232
  br label %bb112
bb111:
  br label %bb130
bb112:
  %t450 = load %"compiler/generic:Desc", ptr %l232
  store %"compiler/generic:Desc" %t450, ptr %l13
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/check:Checker", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t456 = load i32, ptr %t455, !tbaa !23
  %t459 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t454, i32 %t456)
  store i32 %t459, ptr %l236
  br label %bb113
bb113:
  %t460 = load i32, ptr %l236, !tbaa !23
  store i32 %t460, ptr %l14, !tbaa !23
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i32, ptr %l14, !tbaa !23
  %t465 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t461, i32 %t462)
  store i1 %t465, ptr %l239
  br label %bb114
bb114:
  %t466 = load i1, ptr %l239, !tbaa !21
  br i1 %t466, label %bb115, label %bb116
bb115:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load %"compiler/source:Span", ptr %l1
  %t469 = load %"compiler/source:Span", ptr %l3
  %t470 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t471 = load i32, ptr %t470, !tbaa !23
  %t472 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t467, %"compiler/source:Span" %t468, %"compiler/source:Span" %t469, i32 %t471, { i64, ptr } %t472)
  store ptr %t478, ptr %l245
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s17)
  %t479 = load ptr, ptr %l245, !tbaa !29
  store ptr %t479, ptr %rv
  br label %ret
bb118:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !29
  %t485 = getelementptr %"compiler/generic:Program", ptr %t483, i32 0, i32 2
  %t486 = load i32, ptr %l14, !tbaa !23
  %t489 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t485, i32 %t486)
  store i32 %t489, ptr %l250
  br label %bb119
bb119:
  %t490 = load i32, ptr %l250, !range !{i32 0, i32 33}
  %t492 = trunc i64 32 to i32
  %t493 = icmp eq i32 %t490, %t492
  br i1 %t493, label %bb120, label %bb121
bb120:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load %"compiler/source:Span", ptr %l1
  %t497 = load i32, ptr %l14, !tbaa !23
  %t498 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 2
  %t499 = load i64, ptr %t498, !tbaa !24
  %t500 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t506 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordCalled(ptr %v0, ptr %v2, ptr %v3, ptr %t495, %"compiler/source:Span" %t496, i32 %t497, i64 %t499, { i64, ptr } %t500)
  store ptr %t506, ptr %l258
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_scope_close(ptr %s17)
  %t507 = load ptr, ptr %l258, !tbaa !29
  store ptr %t507, ptr %rv
  br label %ret
bb123:
  %t508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t508, ptr %l259, !tbaa !29
  %t509 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t509, ptr %l260
  %t510 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t510, ptr %l261
  %t511 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t512 = load i32, ptr %t511, !tbaa !23
  store i32 %t512, ptr %l262, !tbaa !23
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/check:Checker", ptr %t513, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t518 = getelementptr %"compiler/generic:Program", ptr %t516, i32 0, i32 2
  %t519 = load i32, ptr %l14, !tbaa !23
  %t522 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s17, ptr %t518, i32 %t519)
  store { i64, ptr } %t522, ptr %l267
  br label %bb124
bb124:
  %t523 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t523, ptr %l268, !tbaa !27
  %t524 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 2
  %t525 = load i64, ptr %t524, !tbaa !24
  %t527 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i32, ptr %t528, i64 %t525
  %t530 = load i32, ptr %t529, !tbaa !33
  store i32 %t530, ptr %l270, !tbaa !23
  %t531 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t531, ptr %l271, !tbaa !27
  %t532 = icmp sge i64 0, 0
  br i1 %t532, label %bb125, label %bb126
bb125:
  %t534 = icmp sle i64 0, 1152921504606846975
  br i1 %t534, label %bb127, label %bb128
bb126:
  call void @__olang_check_failed(ptr @olang_loc_b1d60606349c196f_148fe1dbe07e141b)
  unreachable
bb127:
  %t536 = mul i64 0, 8
  %t537 = insertvalue { i64, ptr } undef, i64 0, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t539 = load ptr, ptr %l259, !tbaa !29
  %t540 = load %"compiler/source:Span", ptr %l260
  %t541 = load %"compiler/source:Span", ptr %l261
  %t542 = load i32, ptr %l262, !tbaa !23
  %t543 = load i32, ptr %l270, !tbaa !23
  %t544 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t546 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %t539, %"compiler/source:Span" %t540, %"compiler/source:Span" %t541, i32 %t542, i32 %t543, { i64, ptr } %t544, { i64, ptr } %t538)
  store ptr %t546, ptr %l275
  br label %bb129
bb128:
  call void @__olang_check_failed(ptr @olang_loc_b1d60606349c196f_148fe1dbe07e141b)
  unreachable
bb129:
  call void @__olang_scope_close(ptr %s17)
  %t547 = load ptr, ptr %l275, !tbaa !29
  store ptr %t547, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  %t548 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t549 = load i32, ptr %t548, !range !{i32 0, i32 9}
  %t551 = trunc i64 1 to i32
  %t552 = icmp eq i32 %t549, %t551
  br i1 %t552, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l278, !tbaa !21
  br label %bb134
bb133:
  %t554 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t555 = load i32, ptr %t554, !range !{i32 0, i32 9}
  %t557 = trunc i64 2 to i32
  %t558 = icmp eq i32 %t555, %t557
  store i1 %t558, ptr %l278, !tbaa !21
  br label %bb134
bb134:
  %t560 = load i1, ptr %l278, !tbaa !21
  br i1 %t560, label %bb135, label %bb136
bb135:
  %t561 = load ptr, ptr %l0, !tbaa !29
  store ptr %t561, ptr %l281, !tbaa !29
  %t562 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t562, ptr %l282
  %t563 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t563, ptr %l283
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load ptr, ptr %l2, !tbaa !29
  %t567 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t571 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t564, ptr %t565, i32 %t567)
  store ptr %t571, ptr %l288
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t572 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t573 = load ptr, ptr %l281, !tbaa !29
  %t574 = load %"compiler/source:Span", ptr %l282
  %t575 = load %"compiler/source:Span", ptr %l283
  %t576 = load ptr, ptr %l288, !tbaa !29
  %t578 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t573, %"compiler/source:Span" %t574, %"compiler/source:Span" %t575, ptr %t576, { i64, ptr } %t572)
  store ptr %t578, ptr %l290
  br label %bb138
bb138:
  %t579 = load ptr, ptr %l290, !tbaa !29
  store ptr %t579, ptr %rv
  br label %ret
bb139:
  %t580 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t581 = load i32, ptr %t580, !range !{i32 0, i32 9}
  %t583 = trunc i64 8 to i32
  %t584 = icmp eq i32 %t581, %t583
  br i1 %t584, label %bb140, label %bb141
bb140:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l2, !tbaa !29
  %t590 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t586, ptr %t587)
  store i32 %t590, ptr %l295
  br label %bb142
bb141:
  br label %bb178
bb142:
  %t591 = load i32, ptr %l295, !tbaa !23
  store i32 %t591, ptr %l15, !tbaa !23
  %t592 = load i32, ptr %l15, !tbaa !23
  %t594 = icmp sge i32 %t592, 0
  br i1 %t594, label %bb143, label %bb144
bb143:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/check:Checker", ptr %t596, i32 0, i32 1
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t601 = getelementptr %"compiler/generic:Program", ptr %t599, i32 0, i32 2
  %t602 = load i32, ptr %l15, !tbaa !23
  %t605 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t601, i32 %t602)
  store i1 %t605, ptr %l303
  br label %bb145
bb144:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb153
bb145:
  %t606 = load i1, ptr %l303, !tbaa !21
  br i1 %t606, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l304, !tbaa !21
  br label %bb149
bb147:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/check:Checker", ptr %t607, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t612 = getelementptr %"compiler/generic:Program", ptr %t610, i32 0, i32 2
  %t613 = load i32, ptr %l15, !tbaa !23
  %t616 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t612, i32 %t613)
  store i1 %t616, ptr %l309
  br label %bb148
bb148:
  %t617 = load i1, ptr %l309, !tbaa !21
  store i1 %t617, ptr %l304, !tbaa !21
  br label %bb149
bb149:
  %t618 = load i1, ptr %l304, !tbaa !21
  br i1 %t618, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l310, !tbaa !21
  br label %bb152
bb151:
  %t619 = load i32, ptr %l15, !tbaa !23
  %t620 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t623 = icmp eq i32 %t619, %t620
  store i1 %t623, ptr %l310, !tbaa !21
  br label %bb152
bb152:
  %t625 = load i1, ptr %l310, !tbaa !21
  store i1 %t625, ptr %l298, !tbaa !21
  br label %bb153
bb153:
  %t626 = load i1, ptr %l298, !tbaa !21
  br i1 %t626, label %bb154, label %bb155
bb154:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l1
  %t629 = load i32, ptr %l15, !tbaa !23
  %t630 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t635 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v2, ptr %v3, ptr %t627, %"compiler/source:Span" %t628, i32 %t629, { i64, ptr } %t630)
  store ptr %t635, ptr %l318
  br label %bb156
bb155:
  br label %bb157
bb156:
  %t636 = load ptr, ptr %l318, !tbaa !29
  store ptr %t636, ptr %rv
  br label %ret
bb157:
  %t637 = load i32, ptr %l15, !tbaa !23
  %t639 = icmp sge i32 %t637, 0
  br i1 %t639, label %bb158, label %bb159
bb158:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i32, ptr %l15, !tbaa !23
  %t645 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t641, i32 %t642)
  store i1 %t645, ptr %l324
  br label %bb160
bb159:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb161
bb160:
  %t646 = load i1, ptr %l324, !tbaa !21
  store i1 %t646, ptr %l321, !tbaa !21
  br label %bb161
bb161:
  %t647 = load i1, ptr %l321, !tbaa !21
  br i1 %t647, label %bb162, label %bb163
bb162:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l1
  %t650 = load %"compiler/source:Span", ptr %l3
  %t651 = load i32, ptr %l15, !tbaa !23
  %t652 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t658 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t648, %"compiler/source:Span" %t649, %"compiler/source:Span" %t650, i32 %t651, { i64, ptr } %t652)
  store ptr %t658, ptr %l330
  br label %bb164
bb163:
  br label %bb165
bb164:
  %t659 = load ptr, ptr %l330, !tbaa !29
  store ptr %t659, ptr %rv
  br label %ret
bb165:
  %t660 = load i32, ptr %l15, !tbaa !23
  %t662 = icmp sge i32 %t660, 0
  br i1 %t662, label %bb166, label %bb167
bb166:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/check:Checker", ptr %t664, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !29
  %t669 = getelementptr %"compiler/generic:Program", ptr %t667, i32 0, i32 2
  %t670 = load i32, ptr %l15, !tbaa !23
  %t673 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t669, i32 %t670)
  store i32 %t673, ptr %l338
  br label %bb168
bb167:
  store i1 false, ptr %l333, !tbaa !21
  br label %bb169
bb168:
  %t674 = load i32, ptr %l338, !range !{i32 0, i32 33}
  %t676 = trunc i64 25 to i32
  %t677 = icmp eq i32 %t674, %t676
  %t679 = xor i1 %t677, true
  store i1 %t679, ptr %l333, !tbaa !21
  br label %bb169
bb169:
  %t681 = load i1, ptr %l333, !tbaa !21
  br i1 %t681, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s24
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l342, !tbaa !29
  %t683 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t683, ptr %l343
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load i32, ptr %l15, !tbaa !23
  %t688 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t684, i32 %t685)
  store { i64, ptr } %t688, ptr %l346
  br label %bb172
bb171:
  br label %bb177
bb172:
  %t689 = load { i64, ptr }, ptr %l346, !tbaa !27
  %t691 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s24, ptr %v0, { i64, ptr } %t689)
  store %"compiler/diagmsg:Msg" %t691, ptr %l348
  br label %bb173
bb173:
  %t692 = load ptr, ptr %l342, !tbaa !29
  %t693 = load %"compiler/source:Span", ptr %l343
  %t694 = load %"compiler/diagmsg:Msg", ptr %l348
  %t695 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t692, %"compiler/source:Span" %t693, %"compiler/diagmsg:Msg" %t694)
  store i64 %t695, ptr %l349
  br label %bb174
bb174:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t696, { i64, ptr } %t697)
  br label %bb175
bb175:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t701 = load %"compiler/source:Span", ptr %l1
  %t704 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t700, %"compiler/source:Span" %t701)
  store ptr %t704, ptr %l354
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s24)
  %t705 = load ptr, ptr %l354, !tbaa !29
  store ptr %t705, ptr %rv
  br label %ret
bb177:
  br label %bb178
bb178:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t707 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t706, %"compiler/source:Span" %t707, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb179
bb179:
  %t710 = load ptr, ptr %l0, !tbaa !29
  %t711 = load %"compiler/source:Span", ptr %l1
  %t714 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t710, %"compiler/source:Span" %t711)
  store ptr %t714, ptr %l359
  br label %bb180
bb180:
  %t715 = load ptr, ptr %l359, !tbaa !29
  store ptr %t715, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/generic:Context"
  %l19 = alloca %"compiler/generic:Context"
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l72 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca { i64, i32 }
  %l93 = alloca i1
  %l97 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t20, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %l18, i64 160, i1 false)
  %t21 = call ptr @__olang_scope_hold(ptr %s0)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l20, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = call ptr @__olang_region_make_part(ptr %s0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t27 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t28 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l23, !tbaa !24
  %t32 = load i64, ptr %l23, !tbaa !24
  %t33 = mul i64 %t32, 8
  %t34 = load i64, ptr %l20
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call ptr @__olang_held_alloc(ptr %t35, i64 %t33)
  %t37 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = mul i64 %t43, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t46 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t47 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t46, i32 0, i32 0
  store { i64, ptr } %t45, ptr %t47, !tbaa !27
  %t48 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t51 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t50, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb11, label %bb12
bb10:
  %t57 = call ptr @__olang_scope_hold(ptr %s0)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l28, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t59, label %bb13, label %bb14
bb11:
  %t61 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t62 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t61, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t62, !tbaa !27
  br label %bb12
bb12:
  %t63 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t64 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %l20
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = load { i64, ptr }, ptr %t64
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = icmp ne ptr %t69, null
  %t71 = select i1 %t70, ptr %t69, ptr null
  call void @__olang_region_settle_in(ptr %t66, ptr %t71)
  br label %bb10
bb13:
  %t72 = call ptr @__olang_region_make_part(ptr %s0)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l28, !tbaa !24
  br label %bb14
bb14:
  %t74 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t75 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l30, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l31, !tbaa !24
  %t79 = load i64, ptr %l31, !tbaa !24
  %t80 = mul i64 %t79, 8
  %t81 = load i64, ptr %l28
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l32, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l31, !tbaa !24
  %t91 = mul i64 %t90, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t93 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t93, i32 0, i32 1
  store { i64, ptr } %t92, ptr %t94, !tbaa !27
  %t95 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t97 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t97, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb17, label %bb18
bb16:
  %t104 = call ptr @__olang_scope_hold(ptr %s0)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l36, !tbaa !24
  %t106 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t106, label %bb19, label %bb20
bb17:
  %t108 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t109 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t108, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t109, !tbaa !27
  br label %bb18
bb18:
  %t110 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t111 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t110, i32 0, i32 1
  %t112 = load i64, ptr %l28
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = load { i64, ptr }, ptr %t111
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = call ptr @__olang_region_or(ptr %t115, ptr null)
  %t117 = icmp ne ptr %t116, null
  %t118 = select i1 %t117, ptr %t116, ptr null
  call void @__olang_region_settle_in(ptr %t113, ptr %t118)
  br label %bb16
bb19:
  %t119 = call ptr @__olang_region_make_part(ptr %s0)
  %t120 = ptrtoint ptr %t119 to i64
  store i64 %t120, ptr %l36, !tbaa !24
  br label %bb20
bb20:
  %t121 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 2
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l38, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l39, !tbaa !24
  %t126 = load i64, ptr %l39, !tbaa !24
  %t127 = mul i64 %t126, 8
  %t128 = load i64, ptr %l36
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call ptr @__olang_held_alloc(ptr %t129, i64 %t127)
  %t131 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l40, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l39, !tbaa !24
  %t138 = mul i64 %t137, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t140 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t141 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 2
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t142, label %bb21, label %bb22
bb21:
  %t144 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t145 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t144, i32 0, i32 2
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t149 = icmp eq i64 %t147, 0
  br i1 %t149, label %bb23, label %bb24
bb22:
  %t151 = call ptr @__olang_scope_hold(ptr %s0)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l44, !tbaa !24
  %t153 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t153, label %bb25, label %bb26
bb23:
  %t155 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t156 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t155, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t156, !tbaa !27
  br label %bb24
bb24:
  %t157 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 2
  %t158 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t157, i32 0, i32 2
  %t159 = load i64, ptr %l36
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = load { i64, ptr }, ptr %t158
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = call ptr @__olang_region_or(ptr %t162, ptr null)
  %t164 = icmp ne ptr %t163, null
  %t165 = select i1 %t164, ptr %t163, ptr null
  call void @__olang_region_settle_in(ptr %t160, ptr %t165)
  br label %bb22
bb25:
  %t166 = call ptr @__olang_region_make_part(ptr %s0)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l44, !tbaa !24
  br label %bb26
bb26:
  %t168 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t169 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t168, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l46, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l47, !tbaa !24
  %t173 = load i64, ptr %l47, !tbaa !24
  %t174 = mul i64 %t173, 8
  %t175 = load i64, ptr %l44
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = call ptr @__olang_held_alloc(ptr %t176, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l48, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l47, !tbaa !24
  %t185 = mul i64 %t184, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %t183, i64 %t185, i1 false)
  %t186 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t187 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t188 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t187, i32 0, i32 0
  store { i64, ptr } %t186, ptr %t188, !tbaa !27
  %t189 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t189, label %bb27, label %bb28
bb27:
  %t191 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t192 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t191, i32 0, i32 0
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t196 = icmp eq i64 %t194, 0
  br i1 %t196, label %bb29, label %bb30
bb28:
  %t198 = call ptr @__olang_scope_hold(ptr %s0)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l52, !tbaa !24
  %t200 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t200, label %bb31, label %bb32
bb29:
  %t202 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t203 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t202, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t203, !tbaa !27
  br label %bb30
bb30:
  %t204 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t205 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t204, i32 0, i32 0
  %t206 = load i64, ptr %l44
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %t205
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  br label %bb28
bb31:
  %t213 = call ptr @__olang_region_make_part(ptr %s0)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l52, !tbaa !24
  br label %bb32
bb32:
  %t215 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l54, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l55, !tbaa !24
  %t220 = load i64, ptr %l55, !tbaa !24
  %t221 = mul i64 %t220, 8
  %t222 = load i64, ptr %l52
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = call ptr @__olang_held_alloc(ptr %t223, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l56, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = load i64, ptr %l55, !tbaa !24
  %t232 = mul i64 %t231, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t228, ptr %t230, i64 %t232, i1 false)
  %t233 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t234 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t235 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t234, i32 0, i32 1
  store { i64, ptr } %t233, ptr %t235, !tbaa !27
  %t236 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t236, label %bb33, label %bb34
bb33:
  %t238 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t239 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t238, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  %t243 = icmp eq i64 %t241, 0
  br i1 %t243, label %bb35, label %bb36
bb34:
  %t245 = call ptr @__olang_scope_hold(ptr %s0)
  %t246 = ptrtoint ptr %t245 to i64
  store i64 %t246, ptr %l60, !tbaa !24
  %t247 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t247, label %bb37, label %bb38
bb35:
  %t249 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t250 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t249, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t250, !tbaa !27
  br label %bb36
bb36:
  %t251 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t252 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t251, i32 0, i32 1
  %t253 = load i64, ptr %l52
  %t254 = inttoptr i64 %t253 to ptr
  %t255 = load { i64, ptr }, ptr %t252
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = call ptr @__olang_region_or(ptr %t256, ptr null)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr null
  call void @__olang_region_settle_in(ptr %t254, ptr %t259)
  br label %bb34
bb37:
  %t260 = call ptr @__olang_region_make_part(ptr %s0)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l60, !tbaa !24
  br label %bb38
bb38:
  %t262 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t262, i32 0, i32 2
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l62, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l63, !tbaa !24
  %t267 = load i64, ptr %l63, !tbaa !24
  %t268 = mul i64 %t267, 8
  %t269 = load i64, ptr %l60
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = call ptr @__olang_held_alloc(ptr %t270, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l64, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = load i64, ptr %l63, !tbaa !24
  %t279 = mul i64 %t278, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t275, ptr %t277, i64 %t279, i1 false)
  %t280 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t281 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t282 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t281, i32 0, i32 2
  store { i64, ptr } %t280, ptr %t282, !tbaa !27
  %t283 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t283, label %bb39, label %bb40
bb39:
  %t285 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t286 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t285, i32 0, i32 2
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t290 = icmp eq i64 %t288, 0
  br i1 %t290, label %bb41, label %bb42
bb40:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l19, i64 160, i1 false)
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = load ptr, ptr %l3, !tbaa !29
  %t300 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %s0, ptr %t295, ptr %l4, ptr %t296)
  store i32 %t300, ptr %l72
  br label %bb43
bb41:
  %t301 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t302 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t301, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t302, !tbaa !27
  br label %bb42
bb42:
  %t303 = getelementptr %"compiler/generic:Context", ptr %l19, i32 0, i32 3
  %t304 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t303, i32 0, i32 2
  %t305 = load i64, ptr %l60
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = load { i64, ptr }, ptr %t304
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = call ptr @__olang_region_or(ptr %t308, ptr null)
  %t310 = icmp ne ptr %t309, null
  %t311 = select i1 %t310, ptr %t309, ptr null
  call void @__olang_region_settle_in(ptr %t306, ptr %t311)
  br label %bb40
bb43:
  %t312 = load i32, ptr %l72, !tbaa !23
  store i32 %t312, ptr %l5, !tbaa !23
  %t313 = load i32, ptr %l5, !tbaa !23
  %t314 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t317 = icmp ne i32 %t313, %t314
  br i1 %t317, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s2
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t323 = load i32, ptr %l5, !tbaa !23
  %t324 = load ptr, ptr %lp2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v2, ptr %t322, i32 %t323, ptr %t324)
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l80, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %lp2
  %t333 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v2, ptr %s2, ptr %t329, ptr %t330)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t333, ptr %l83
  br label %bb47
bb47:
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  %t335 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %t335
  %t336 = load ptr, ptr %l80, !tbaa !29
  %t338 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %s2, ptr %v2, ptr %t336, ptr %t335)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %l85
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t339 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  %t340 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t339, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t340, ptr %rv
  br label %ret
bb49:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l3, !tbaa !29
  %t345 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t341, ptr %t342)
  store { i64, i32 } %t345, ptr %l88
  br label %bb50
bb50:
  %t346 = load { i64, i32 }, ptr %l88
  store { i64, i32 } %t346, ptr %l6
  %t347 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t348 = load i64, ptr %t347, !tbaa !24
  store i64 %t348, ptr %l7, !tbaa !24
  %t350 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t351 = load i32, ptr %t350, !tbaa !23
  store i32 %t351, ptr %l8, !tbaa !23
  %t353 = load i64, ptr %l7, !tbaa !24
  %t355 = icmp slt i64 %t353, 0
  br i1 %t355, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb53
bb52:
  %t357 = load i64, ptr %l7, !tbaa !24
  %t359 = icmp sge i64 %t357, 64
  store i1 %t359, ptr %l93, !tbaa !21
  br label %bb53
bb53:
  %t361 = load i1, ptr %l93, !tbaa !21
  br i1 %t361, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t363 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t363, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t364 = load ptr, ptr %lp2
  store ptr %t364, ptr %l97, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i32, ptr %l8, !tbaa !23
  %t367 = load i64, ptr %l7, !tbaa !24
  store i64 %t367, ptr %l100, !tbaa !24
  %t368 = load i64, ptr %l100, !tbaa !24
  %t369 = load i64, ptr %l100, !tbaa !24
  %t370 = shl i64 1, %t369
  %t374 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t365, i32 %t366, i64 %t370)
  store i32 %t374, ptr %l102
  br label %bb57
bb57:
  %t375 = load ptr, ptr %l97, !tbaa !29
  %t376 = load i32, ptr %l102, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t375, i32 %t376)
  br label %bb58
bb58:
  %t377 = load ptr, ptr %lp2
  %t378 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t377
  call void @__olang_scope_close(ptr %s0)
  %t380 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t378, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t380, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca %"compiler/check:narrowed"
  %l23 = alloca %"compiler/check:narrowed"
  %l24 = alloca i32
  %l29 = alloca %"compiler/check:narrowed"
  %l32 = alloca %"compiler/check:narrowed"
  %l33 = alloca i32
  %l40 = alloca i64
  %l42 = alloca i1
  %l43 = alloca %"compiler/check:nullNarrow"
  %l46 = alloca %"compiler/check:nullNarrow"
  %l47 = alloca i32
  %l52 = alloca %"compiler/check:nullNarrow"
  %l55 = alloca %"compiler/check:nullNarrow"
  %l56 = alloca i32
  %l60 = alloca i64
  %l62 = alloca i1
  %l63 = alloca %"compiler/check:errNarrow"
  %l66 = alloca %"compiler/check:errNarrow"
  %l67 = alloca i32
  %l72 = alloca %"compiler/check:errNarrow"
  %l75 = alloca %"compiler/check:errNarrow"
  %l76 = alloca i32
  %l83 = alloca i64
  %l85 = alloca i1
  %l86 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l94 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i32
  %l104 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i32
  %l115 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i32
  %l124 = alloca ptr
  %l131 = alloca %"compiler/typed:Block"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 48
  %t7 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t3, i64 %a4)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %t9, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t13)
  store ptr %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l14, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 46
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = icmp sgt i64 %t22, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l6, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 46
  %t29 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %s1, ptr %t27)
  %t30 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 1
  %t31 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 0
  store i32 %t31, ptr %l24
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33, !prof !99
ok.33:
  store %"compiler/check:narrowed" %t30, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb8:
  %t34 = load %"compiler/check:narrowed", ptr %l23
  store %"compiler/check:narrowed" %t34, ptr %l20
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f3fef639868d2bb5_dd9676d0e98a8921)
  unreachable
bb11:
  %t35 = getelementptr %"compiler/check:narrowed", ptr %l20, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l19, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 46
  %t49 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %s1, ptr %t47)
  %t50 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 0
  store i32 %t51, ptr %l33
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb17, label %ok.53, !prof !99
ok.53:
  store %"compiler/check:narrowed" %t50, ptr %l32
  br label %bb16
bb16:
  %t54 = load %"compiler/check:narrowed", ptr %l32
  store %"compiler/check:narrowed" %t54, ptr %l29
  br label %bb24
bb17:
  %t55 = load i32, ptr %l33, !tbaa !23
  %t56 = icmp eq i32 %t55, 65536
  br i1 %t56, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_df1f5fd28061949_6fd2bc487e6b648d)
  unreachable
bb19:
  %t58 = load i32, ptr %l33, !tbaa !23
  %t59 = icmp eq i32 %t58, 65537
  br i1 %t59, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_adf1079d57e55808_9269da6a723799fc)
  unreachable
bb21:
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = icmp eq i32 %t61, 65538
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a)
  unreachable
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_92a21335b7ae999a_7e07c1814bb2a646)
  unreachable
bb24:
  %t64 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3anarrowed_2e5
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t66 = getelementptr %"compiler/check:narrowed", ptr %l29, i32 0, i32 5
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  call void @__olang_region_release(ptr %t68)
  store { i64, ptr } zeroinitializer, ptr %t66
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb27:
  br label %bb4
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 50
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l40
  br label %bb30
bb30:
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = icmp sgt i64 %t74, 0
  br i1 %t75, label %bb31, label %bb32
bb31:
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 50
  %t81 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %s3, ptr %t79)
  %t82 = extractvalue { i32, %"compiler/check:nullNarrow" } %t81, 1
  %t83 = extractvalue { i32, %"compiler/check:nullNarrow" } %t81, 0
  store i32 %t83, ptr %l47
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb34, label %ok.85, !prof !99
ok.85:
  store %"compiler/check:nullNarrow" %t82, ptr %l46
  br label %bb33
bb32:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb37
bb33:
  %t86 = load %"compiler/check:nullNarrow", ptr %l46
  store %"compiler/check:nullNarrow" %t86, ptr %l43
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_check_failed(ptr @olang_loc_abe1ff4556bedc08_80ba96099639cb2c)
  unreachable
bb36:
  %t87 = getelementptr %"compiler/check:nullNarrow", ptr %l43, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l1, !tbaa !24
  %t92 = icmp eq i64 %t88, %t89
  store i1 %t92, ptr %l42, !tbaa !21
  br label %bb37
bb37:
  %t94 = load i1, ptr %l42, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb39:
  br label %bb40
bb40:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 50
  %t101 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %s3, ptr %t99)
  %t102 = extractvalue { i32, %"compiler/check:nullNarrow" } %t101, 1
  %t103 = extractvalue { i32, %"compiler/check:nullNarrow" } %t101, 0
  store i32 %t103, ptr %l56
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb42, label %ok.105, !prof !99
ok.105:
  store %"compiler/check:nullNarrow" %t102, ptr %l55
  br label %bb41
bb41:
  %t106 = load %"compiler/check:nullNarrow", ptr %l55
  store %"compiler/check:nullNarrow" %t106, ptr %l52
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3anullNarrow_2e0
  br i1 %t107, label %bb44, label %bb45
bb42:
  br label %bb43
bb43:
  br label %bb46
bb44:
  %t109 = getelementptr %"compiler/check:nullNarrow", ptr %l52, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109
  %t111 = extractvalue { i64, ptr } %t110, 1
  call void @__olang_region_release(ptr %t111)
  store { i64, ptr } zeroinitializer, ptr %t109
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  br label %bb29
bb48:
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/check:frame", ptr %t112, i32 0, i32 62
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l60
  br label %bb50
bb50:
  %t117 = load i64, ptr %l60, !tbaa !24
  %t118 = icmp sgt i64 %t117, 0
  br i1 %t118, label %bb51, label %bb52
bb51:
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t122 = getelementptr %"compiler/check:frame", ptr %t120, i32 0, i32 62
  %t124 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %s6, ptr %t122)
  %t125 = extractvalue { i32, %"compiler/check:errNarrow" } %t124, 1
  %t126 = extractvalue { i32, %"compiler/check:errNarrow" } %t124, 0
  store i32 %t126, ptr %l67
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb54, label %ok.128, !prof !99
ok.128:
  store %"compiler/check:errNarrow" %t125, ptr %l66
  br label %bb53
bb52:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb57
bb53:
  %t129 = load %"compiler/check:errNarrow", ptr %l66
  store %"compiler/check:errNarrow" %t129, ptr %l63
  br label %bb56
bb54:
  br label %bb55
bb55:
  call void @__olang_check_failed(ptr @olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7)
  unreachable
bb56:
  %t130 = getelementptr %"compiler/check:errNarrow", ptr %l63, i32 0, i32 2
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load i64, ptr %l1, !tbaa !24
  %t135 = icmp eq i64 %t131, %t132
  store i1 %t135, ptr %l62, !tbaa !21
  br label %bb57
bb57:
  %t137 = load i1, ptr %l62, !tbaa !21
  %t138 = xor i1 %t137, true
  br i1 %t138, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb59:
  br label %bb60
bb60:
  %t140 = load ptr, ptr %l6, !tbaa !29
  %t142 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 62
  %t144 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %s6, ptr %t142)
  %t145 = extractvalue { i32, %"compiler/check:errNarrow" } %t144, 1
  %t146 = extractvalue { i32, %"compiler/check:errNarrow" } %t144, 0
  store i32 %t146, ptr %l76
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb62, label %ok.148, !prof !99
ok.148:
  store %"compiler/check:errNarrow" %t145, ptr %l75
  br label %bb61
bb61:
  %t149 = load %"compiler/check:errNarrow", ptr %l75
  store %"compiler/check:errNarrow" %t149, ptr %l72
  br label %bb69
bb62:
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = icmp eq i32 %t150, 65536
  br i1 %t151, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b4897252f2a0467_e1365b27726b9d63)
  unreachable
bb64:
  %t153 = load i32, ptr %l76, !tbaa !23
  %t154 = icmp eq i32 %t153, 65537
  br i1 %t154, label %bb65, label %bb66
bb65:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2)
  unreachable
bb66:
  %t156 = load i32, ptr %l76, !tbaa !23
  %t157 = icmp eq i32 %t156, 65538
  br i1 %t157, label %bb67, label %bb68
bb67:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e882b6948f69dce8_e6367676615923ec)
  unreachable
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9e6114e2cf841093_fa90ce222875bd2f)
  unreachable
bb69:
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aerrNarrow_2e0
  br i1 %t159, label %bb70, label %bb71
bb70:
  %t161 = getelementptr %"compiler/check:errNarrow", ptr %l72, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161
  %t163 = extractvalue { i64, ptr } %t162, 1
  call void @__olang_region_release(ptr %t163)
  store { i64, ptr } zeroinitializer, ptr %t161
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s6)
  br label %bb72
bb72:
  br label %bb49
bb73:
  br label %bb74
bb74:
  %t164 = load ptr, ptr %l6, !tbaa !29
  %t166 = getelementptr %"compiler/check:frame", ptr %t164, i32 0, i32 22
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t166)
  store i64 %t168, ptr %l83
  br label %bb75
bb75:
  %t169 = load i64, ptr %l83, !tbaa !24
  %t170 = icmp sgt i64 %t169, 0
  br i1 %t170, label %bb76, label %bb77
bb76:
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 22
  %t176 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t174)
  %t177 = extractvalue { i32, i64 } %t176, 1
  %t178 = extractvalue { i32, i64 } %t176, 0
  store i32 %t178, ptr %l90
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb79, label %ok.180, !prof !99
ok.180:
  store i64 %t177, ptr %l89
  br label %bb78
bb77:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb82
bb78:
  %t181 = load i64, ptr %l89, !tbaa !24
  store i64 %t181, ptr %l86, !tbaa !24
  br label %bb81
bb79:
  br label %bb80
bb80:
  call void @__olang_check_failed(ptr @olang_loc_c349e4c9332250dd_9daf9d91ff07ef41)
  unreachable
bb81:
  %t182 = load i64, ptr %l1, !tbaa !24
  %t183 = load i64, ptr %l86, !tbaa !24
  %t185 = icmp eq i64 %t183, %t182
  store i1 %t185, ptr %l85, !tbaa !21
  br label %bb82
bb82:
  %t187 = load i1, ptr %l85, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb83, label %bb84
bb83:
  br label %bb96
bb84:
  br label %bb85
bb85:
  %t190 = load ptr, ptr %l6, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 22
  %t194 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t192)
  %t195 = extractvalue { i32, i64 } %t194, 1
  %t196 = extractvalue { i32, i64 } %t194, 0
  store i32 %t196, ptr %l98
  %t197 = icmp ne i32 %t196, 0
  br i1 %t197, label %bb87, label %ok.198, !prof !99
ok.198:
  store i64 %t195, ptr %l97
  br label %bb86
bb86:
  %t199 = load i64, ptr %l97, !tbaa !24
  store i64 %t199, ptr %l94, !tbaa !24
  br label %bb94
bb87:
  %t200 = load i32, ptr %l98, !tbaa !23
  %t201 = icmp eq i32 %t200, 65536
  br i1 %t201, label %bb88, label %bb89
bb88:
  call void @__olang_bang_failed_plain(ptr @olang_loc_90c216d2a7707e63_13ebc04feeb9a31f)
  unreachable
bb89:
  %t203 = load i32, ptr %l98, !tbaa !23
  %t204 = icmp eq i32 %t203, 65537
  br i1 %t204, label %bb90, label %bb91
bb90:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e7cf760e54914750_8299ab19ca729e9c)
  unreachable
bb91:
  %t206 = load i32, ptr %l98, !tbaa !23
  %t207 = icmp eq i32 %t206, 65538
  br i1 %t207, label %bb92, label %bb93
bb92:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2de9afb4b96dcf94_71a46e56f9644858)
  unreachable
bb93:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6d051d6c732886d2_d9cb433bcdc0e6)
  unreachable
bb94:
  br label %bb95
bb95:
  br label %bb74
bb96:
  br label %bb97
bb97:
  %t209 = load ptr, ptr %l6, !tbaa !29
  %t211 = getelementptr %"compiler/check:frame", ptr %t209, i32 0, i32 24
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t211)
  store i64 %t213, ptr %l104
  br label %bb98
bb98:
  %t214 = load i64, ptr %l104, !tbaa !24
  %t215 = icmp sgt i64 %t214, 0
  br i1 %t215, label %bb99, label %bb100
bb99:
  %t217 = load ptr, ptr %l6, !tbaa !29
  %t219 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 24
  %t221 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t219)
  %t222 = extractvalue { i32, i64 } %t221, 1
  %t223 = extractvalue { i32, i64 } %t221, 0
  store i32 %t223, ptr %l111
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb102, label %ok.225, !prof !99
ok.225:
  store i64 %t222, ptr %l110
  br label %bb101
bb100:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb105
bb101:
  %t226 = load i64, ptr %l110, !tbaa !24
  store i64 %t226, ptr %l107, !tbaa !24
  br label %bb104
bb102:
  br label %bb103
bb103:
  call void @__olang_check_failed(ptr @olang_loc_fd3792a3478c708a_bd2f712e645466e6)
  unreachable
bb104:
  %t227 = load i64, ptr %l1, !tbaa !24
  %t228 = load i64, ptr %l107, !tbaa !24
  %t230 = icmp eq i64 %t228, %t227
  store i1 %t230, ptr %l106, !tbaa !21
  br label %bb105
bb105:
  %t232 = load i1, ptr %l106, !tbaa !21
  %t233 = xor i1 %t232, true
  br i1 %t233, label %bb106, label %bb107
bb106:
  br label %bb119
bb107:
  br label %bb108
bb108:
  %t235 = load ptr, ptr %l6, !tbaa !29
  %t237 = getelementptr %"compiler/check:frame", ptr %t235, i32 0, i32 24
  %t239 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t237)
  %t240 = extractvalue { i32, i64 } %t239, 1
  %t241 = extractvalue { i32, i64 } %t239, 0
  store i32 %t241, ptr %l119
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb110, label %ok.243, !prof !99
ok.243:
  store i64 %t240, ptr %l118
  br label %bb109
bb109:
  %t244 = load i64, ptr %l118, !tbaa !24
  store i64 %t244, ptr %l115, !tbaa !24
  br label %bb117
bb110:
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = icmp eq i32 %t245, 65536
  br i1 %t246, label %bb111, label %bb112
bb111:
  call void @__olang_bang_failed_plain(ptr @olang_loc_12b3dc107423b434_482fbf8ad69d32f8)
  unreachable
bb112:
  %t248 = load i32, ptr %l119, !tbaa !23
  %t249 = icmp eq i32 %t248, 65537
  br i1 %t249, label %bb113, label %bb114
bb113:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4090f31281295d0b_b76133cd00d27c97)
  unreachable
bb114:
  %t251 = load i32, ptr %l119, !tbaa !23
  %t252 = icmp eq i32 %t251, 65538
  br i1 %t252, label %bb115, label %bb116
bb115:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ee572ef2923bf685_6f413c271381cde1)
  unreachable
bb116:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a)
  unreachable
bb117:
  br label %bb118
bb118:
  br label %bb97
bb119:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t254)
  store ptr %t256, ptr %l124
  br label %bb120
bb120:
  %t257 = load ptr, ptr %l124, !tbaa !29
  %t261 = getelementptr %"compiler/check:frame", ptr %t257, i32 0, i32 7
  store i64 %a2, ptr %t261, !tbaa !24
  %t262 = load i64, ptr %l1, !tbaa !24
  %t264 = trunc i64 %t262 to i32
  %t266 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t269 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v1, ptr %v1, i32 %t264, { i64, ptr } %t266)
  store %"compiler/typed:Block" %t269, ptr %l131
  br label %bb121
bb121:
  %t270 = load %"compiler/typed:Block", ptr %l131
  %t271 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/typed:Block" %t270, ptr %t271
  store ptr %t271, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l94 = alloca i64
  %l97 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l104 = alloca { i64, ptr }
  %l107 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t199 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = load i32, ptr %l14, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t10, i32 %t11, i32 %t12)
  store i64 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load i64, ptr %l7, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i32, ptr %l6, !tbaa !23
  store i32 %t25, ptr %l25, !tbaa !23
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t28 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t26)
  store { i64, ptr } %t28, ptr %l27
  br label %bb7
bb7:
  %t29 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t32 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t30)
  store { i64, ptr } %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t34 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t33)
  store { i64, ptr } %t34, ptr %l31
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = load i32, ptr %l25, !tbaa !23
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t40 = load %"compiler/source:Span", ptr %l28
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t36, i64 %t37, i32 %t38, { i64, ptr } %t39, %"compiler/source:Span" %t40, { i64, ptr } %t35)
  store i1 %t42, ptr %l33
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l34, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l35, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l39
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l42
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 66
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l43, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 66
  store { i64, ptr } %t63, ptr %t65, !tbaa !27
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e66
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l43
  %t69 = extractvalue { i64, ptr } %t68, 1
  call void @__olang_region_release(ptr %t69)
  store { i64, ptr } zeroinitializer, ptr %l43
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t71 = load ptr, ptr %l45, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb15, label %bb16
bb15:
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 18}
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t78 = load i1, ptr %l46, !tbaa !21
  br i1 %t78, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l50
  %t81 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t81, ptr %l51
  %t82 = load i64, ptr %l7, !tbaa !24
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = load ptr, ptr %l5, !tbaa !29
  store ptr %t83, ptr %l54, !tbaa !29
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = icmp sle i64 0, 1152921504606846975
  br i1 %t87, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb22:
  %t89 = mul i64 0, 8
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t91, ptr %l57, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t96 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v0, ptr %t92, ptr %t93)
  store { i64, ptr } %t96, ptr %l60
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb24:
  %t97 = icmp sge i64 0, 0
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = icmp sle i64 0, 2305843009213693951
  br i1 %t99, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb27:
  %t101 = mul i64 0, 4
  %t102 = insertvalue { i64, ptr } undef, i64 0, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l50
  %t106 = load %"compiler/source:Span", ptr %l51
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = load ptr, ptr %l54, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t104, %"compiler/source:Span" %t105, %"compiler/source:Span" %t106, i64 %t107, ptr %t108, { i64, ptr } %t109, { i64, ptr } %t110, { i64, ptr } %t103)
  store ptr %t112, ptr %l64
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb29:
  %t113 = load ptr, ptr %l64, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t113, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd)
  unreachable
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 48
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l68
  br label %bb36
bb36:
  %t120 = load i64, ptr %l68, !tbaa !24
  store i64 %t120, ptr %l8, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v3, ptr %t121, %"compiler/source:Span" %t122, ptr %t123)
  store ptr %t127, ptr %l72
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l72, !tbaa !29
  store ptr %t128, ptr %l9, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t130, ptr %l74
  %t131 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t131, ptr %l75
  %t132 = load i64, ptr %l7, !tbaa !24
  store i64 %t132, ptr %l76, !tbaa !24
  %t133 = load ptr, ptr %l5, !tbaa !29
  store ptr %t133, ptr %l78, !tbaa !29
  %t135 = icmp sge i64 0, 0
  br i1 %t135, label %bb38, label %bb39
bb38:
  %t137 = icmp sle i64 0, 1152921504606846975
  br i1 %t137, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb40:
  %t139 = mul i64 0, 8
  %t140 = insertvalue { i64, ptr } undef, i64 0, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t141, ptr %l81, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l82, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t145 = load ptr, ptr %l9, !tbaa !29
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t143, %"compiler/source:Span" %t144, ptr %t145)
  store ptr %t149, ptr %l86
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb42:
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t151 = load ptr, ptr %l86, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v3, ptr %v0, ptr %t150, ptr %t151)
  store { i64, ptr } %t152, ptr %l87
  br label %bb43
bb43:
  %t153 = icmp sge i64 0, 0
  br i1 %t153, label %bb44, label %bb45
bb44:
  %t155 = icmp sle i64 0, 2305843009213693951
  br i1 %t155, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb46:
  %t157 = mul i64 0, 4
  %t158 = insertvalue { i64, ptr } undef, i64 0, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t160 = load ptr, ptr %l73, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l74
  %t162 = load %"compiler/source:Span", ptr %l75
  %t163 = load i64, ptr %l76, !tbaa !24
  %t164 = load ptr, ptr %l78, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t160, %"compiler/source:Span" %t161, %"compiler/source:Span" %t162, i64 %t163, ptr %t164, { i64, ptr } %t165, { i64, ptr } %t166, { i64, ptr } %t159)
  store ptr %t168, ptr %l91
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb48:
  %t169 = load ptr, ptr %l91, !tbaa !29
  store ptr %t169, ptr %l10, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 48
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l94
  br label %bb49
bb49:
  %t175 = load i64, ptr %l8, !tbaa !24
  %t176 = load i64, ptr %l94, !tbaa !24
  %t178 = icmp sgt i64 %t176, %t175
  br i1 %t178, label %bb50, label %bb51
bb50:
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l97
  %t181 = load ptr, ptr %l10, !tbaa !29
  %t184 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t181)
  store i32 %t184, ptr %l100
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 48
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store { i64, ptr } %t191, ptr %l104
  br label %bb53
bb53:
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t196 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t194, ptr %t192, i1 false)
  store %"compiler/typed:Seq" %t196, ptr %l107
  br label %bb54
bb54:
  %t197 = load %"compiler/typed:Seq", ptr %l107
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t197, ptr %t198
  store { i64, [5 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 0
  store i64 12, ptr %t200
  %t201 = load %"compiler/source:Span", ptr %l97
  %t202 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t201, 0
  %t203 = load i32, ptr %l100, !tbaa !23
  %t204 = insertvalue { %"compiler/source:Span", i32, ptr } %t202, i32 %t203, 1
  %t206 = insertvalue { %"compiler/source:Span", i32, ptr } %t204, ptr %t198, 2
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t206, ptr %t207
  %t208 = load { i64, [5 x i64] }, ptr %t199
  %t210 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t208, ptr %t210
  call void @__olang_scope_close(ptr %s0)
  store ptr %t210, ptr %rv
  br label %ret
bb55:
  %t212 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t212, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l12 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l14 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l15 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l37 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l39 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l40 = alloca i32
  %l42 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t3)
  store ptr %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 4
  %t9 = getelementptr %"compiler/generic:Context", ptr %t8, i32 0, i32 2
  %t11 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t9)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l11
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t12, ptr %l2
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l2)
  %t15 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 1
  %t16 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 0
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb6, label %ok.18, !prof !99
ok.18:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t15, ptr %l14
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l14
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t19, ptr %l12
  br label %bb8
bb6:
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb8:
  %t24 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l12
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t24, ptr %l3
  store ptr %l1, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t25, i32 %t27)
  store { i64, ptr } %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t46, { i64, ptr } %t44)
  br label %bb10
bb10:
  store ptr %l1, ptr %l24, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = inttoptr i64 0 to ptr
  %t60 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t57, ptr %t53, i32 %t55)
  store { i64, ptr } %t60, ptr %l30
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t62 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t62, { i64, ptr } %t61)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb4
bb14:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t64)
  store ptr %t66, ptr %l33
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 4
  %t70 = getelementptr %"compiler/generic:Context", ptr %t69, i32 0, i32 3
  %t72 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t70)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t72, ptr %l36
  br label %bb16
bb16:
  %t73 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l36
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t73, ptr %l4
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l4)
  %t76 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 1
  %t77 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 0
  store i32 %t77, ptr %l40
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb19, label %ok.79, !prof !99
ok.79:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t76, ptr %l39
  br label %bb18
bb18:
  %t80 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l39
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t80, ptr %l37
  br label %bb21
bb19:
  %t81 = load i32, ptr %l40, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb21:
  %t85 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l37
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t85, ptr %l5
  store ptr %l1, ptr %l43, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s5, ptr %t86, i32 %t88)
  store { i64, ptr } %t91, ptr %l46
  br label %bb22
bb22:
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t94 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t92, i64 %t93)
  %t102 = getelementptr i8, ptr %t101, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = getelementptr i8, ptr %t102, i64 %t96
  call void @olang_textcopy(ptr %t103, ptr %t98, i64 %t99)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t101, 1
  %t107 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t107, { i64, ptr } %t105)
  br label %bb23
bb23:
  store ptr %l1, ptr %l49, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = inttoptr i64 0 to ptr
  %t121 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t118, ptr %t114, i32 %t116)
  store { i64, ptr } %t121, ptr %l55
  br label %bb24
bb24:
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t123 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t123, { i64, ptr } %t122)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb17
bb27:
  %t126 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t126, ptr %l58
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i64
  %l22 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca i32
  %l62 = alloca i32
  %l64 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i32
  %l96 = alloca i32
  %l98 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i32
  %l106 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca i64
  %l148 = alloca ptr
  %l157 = alloca i1
  %l169 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i1
  %l192 = alloca i32
  %l198 = alloca i32
  %l202 = alloca i1
  %l205 = alloca i1
  %l206 = alloca i1
  %l211 = alloca i32
  %l218 = alloca i32
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i1
  %l231 = alloca i32
  %l238 = alloca i32
  %l243 = alloca i32
  %l246 = alloca i1
  %l249 = alloca ptr
  %l254 = alloca i32
  %l259 = alloca i32
  %l260 = alloca i1
  %l265 = alloca i32
  %l268 = alloca i1
  %l269 = alloca i1
  %l272 = alloca i1
  %l274 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i32
  %l281 = alloca i32
  %l282 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i1
  %l290 = alloca i1
  %l292 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i32
  %l299 = alloca i32
  %l300 = alloca i1
  %l304 = alloca i1
  %l305 = alloca i1
  %l308 = alloca i1
  %l309 = alloca i1
  %l312 = alloca ptr
  %l315 = alloca i32
  %l318 = alloca i32
  %l319 = alloca i1
  %l322 = alloca ptr
  %l325 = alloca i32
  %l330 = alloca i64
  %l335 = alloca i64
  %l336 = alloca i64
  %l337 = alloca i32
  %l340 = alloca i1
  %l341 = alloca i1
  %l344 = alloca i1
  %l345 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca ptr
  %l352 = alloca i32
  %l353 = alloca i32
  %l354 = alloca ptr
  %l357 = alloca i32
  %l358 = alloca i32
  %l359 = alloca i1
  %l362 = alloca ptr
  %l363 = alloca ptr
  %l366 = alloca i32
  %l367 = alloca i32
  %l372 = alloca i64
  %l377 = alloca i64
  %l378 = alloca i64
  %l379 = alloca i32
  %l384 = alloca i32
  %l387 = alloca i1
  %l392 = alloca i32
  %l395 = alloca i1
  %l398 = alloca ptr
  %l403 = alloca i32
  %l408 = alloca i32
  %l409 = alloca i1
  %l412 = alloca ptr
  %l417 = alloca i32
  %l418 = alloca i32
  %l419 = alloca ptr
  %l420 = alloca %"compiler/source:Span"
  %l423 = alloca { i64, ptr }
  %l424 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l429 = alloca %"compiler/diagmsg:Msg"
  %l430 = alloca i64
  %l433 = alloca ptr
  %l434 = alloca %"compiler/source:Span"
  %l435 = alloca i32
  %l436 = alloca ptr
  %l437 = alloca ptr
  %l440 = alloca ptr
  %l441 = alloca i32
  %l443 = alloca %"compiler/source:Span"
  %l444 = alloca ptr
  %l445 = alloca ptr
  %l446 = alloca ptr
  %l449 = alloca ptr
  %l450 = alloca i32
  %l452 = alloca %"compiler/source:Span"
  %l453 = alloca ptr
  %l454 = alloca %"compiler/typed:Cond"
  %s5 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca ptr
  %t867 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v2, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp eq i64 %t7, 1
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v4, ptr %t11, ptr %t12, i32 %t14)
  store ptr %t18, ptr %l22
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t19 = load ptr, ptr %l22, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %v4, ptr %t24, ptr %t25, i32 %t27)
  store ptr %t31, ptr %l29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load ptr, ptr %l29, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %v4, ptr %t33, ptr %t34)
  store ptr %t37, ptr %l32
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l32, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  store ptr null, ptr %l8, !tbaa !29
  store ptr null, ptr %l9, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l39
  br label %bb13
bb12:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t50 = load i1, ptr %l39, !tbaa !21
  store i1 %t50, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l36, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l43
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  %t57 = load i1, ptr %l43, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t61, ptr %t62, i1 false, ptr %t63, i32 %t64)
  store ptr %t69, ptr %l49
  br label %bb21
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load i32, ptr %l5, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v1, ptr %v4, ptr %t70, ptr %t71, i1 true, ptr %t72, i32 %t73)
  store ptr %t78, ptr %l70
  br label %bb29
bb21:
  %t79 = load ptr, ptr %l49, !tbaa !29
  store ptr %t79, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  store ptr %t82, ptr %l52, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l53, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l54, !tbaa !29
  %t85 = load ptr, ptr %l9, !tbaa !29
  %t88 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t85)
  store i32 %t88, ptr %l57
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = load i32, ptr %l57, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t91, ptr %l58
  br label %bb23
bb23:
  %t92 = load i1, ptr %l58, !tbaa !21
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t93)
  store i32 %t96, ptr %l62
  br label %bb26
bb25:
  %t97 = load i32, ptr %l5, !tbaa !23
  store i32 %t97, ptr %l59, !tbaa !23
  br label %bb27
bb26:
  %t99 = load i32, ptr %l62, !tbaa !23
  store i32 %t99, ptr %l59, !tbaa !23
  br label %bb27
bb27:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t103 = load i32, ptr %l59, !tbaa !23
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v1, ptr %v4, ptr %t100, ptr %t101, i1 true, ptr %t102, i32 %t103)
  store ptr %t104, ptr %l64
  br label %bb28
bb28:
  %t105 = load ptr, ptr %l64, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  br label %bb48
bb29:
  %t107 = load ptr, ptr %l70, !tbaa !29
  store ptr %t107, ptr %l8, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  store ptr %t110, ptr %l73, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  store ptr %t111, ptr %l74, !tbaa !29
  %t112 = load i32, ptr %l5, !tbaa !23
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t116 = icmp eq i32 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t118, ptr %t119)
  store i1 %t122, ptr %l81
  br label %bb32
bb31:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb33
bb32:
  %t123 = load i1, ptr %l81, !tbaa !21
  store i1 %t123, ptr %l78, !tbaa !21
  br label %bb33
bb33:
  %t124 = load i1, ptr %l78, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  store i1 %t129, ptr %l85
  br label %bb36
bb35:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb37
bb36:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l82, !tbaa !21
  br label %bb37
bb37:
  %t133 = load i1, ptr %l82, !tbaa !21
  br i1 %t133, label %bb38, label %bb39
bb38:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l88, !tbaa !29
  %t135 = load ptr, ptr %l8, !tbaa !29
  %t138 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t135)
  store i32 %t138, ptr %l91
  br label %bb40
bb39:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb42
bb40:
  %t139 = load ptr, ptr %l88, !tbaa !29
  %t140 = load i32, ptr %l91, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t139, i32 %t140)
  store i1 %t141, ptr %l92
  br label %bb41
bb41:
  %t142 = load i1, ptr %l92, !tbaa !21
  store i1 %t142, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t143 = load i1, ptr %l87, !tbaa !21
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t144 = load ptr, ptr %l8, !tbaa !29
  %t147 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t144)
  store i32 %t147, ptr %l96
  br label %bb45
bb44:
  %t148 = load i32, ptr %l5, !tbaa !23
  store i32 %t148, ptr %l93, !tbaa !23
  br label %bb46
bb45:
  %t150 = load i32, ptr %l96, !tbaa !23
  store i32 %t150, ptr %l93, !tbaa !23
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = load ptr, ptr %l73, !tbaa !29
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load i32, ptr %l93, !tbaa !23
  %t155 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t151, ptr %t152, i1 false, ptr %t153, i32 %t154)
  store ptr %t155, ptr %l98
  br label %bb47
bb47:
  %t156 = load ptr, ptr %l98, !tbaa !29
  store ptr %t156, ptr %l9, !tbaa !29
  br label %bb48
bb48:
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t158)
  store i32 %t160, ptr %l101
  br label %bb49
bb49:
  %t161 = load i32, ptr %l101, !tbaa !23
  store i32 %t161, ptr %l10, !tbaa !23
  %t162 = load ptr, ptr %l9, !tbaa !29
  %t164 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t162)
  store i32 %t164, ptr %l103
  br label %bb50
bb50:
  %t165 = load i32, ptr %l103, !tbaa !23
  store i32 %t165, ptr %l11, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l10, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l106
  br label %bb51
bb51:
  %t171 = load i1, ptr %l106, !tbaa !21
  br i1 %t171, label %bb52, label %bb53
bb52:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l11, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l110
  br label %bb54
bb53:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb55
bb54:
  %t177 = load i1, ptr %l110, !tbaa !21
  store i1 %t177, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  %t178 = load i1, ptr %l107, !tbaa !21
  br i1 %t178, label %bb56, label %bb57
bb56:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l10, !tbaa !23
  %t186 = load i32, ptr %l11, !tbaa !23
  %t190 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t184, i32 %t185, i32 %t186)
  store i1 %t190, ptr %l117
  br label %bb58
bb57:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb59
bb58:
  %t191 = load i1, ptr %l117, !tbaa !21
  %t192 = xor i1 %t191, true
  store i1 %t192, ptr %l111, !tbaa !21
  br label %bb59
bb59:
  %t194 = load i1, ptr %l111, !tbaa !21
  br i1 %t194, label %bb60, label %bb61
bb60:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t199 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  store i1 %t199, ptr %l122
  br label %bb62
bb61:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb63
bb62:
  %t200 = load i1, ptr %l122, !tbaa !21
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l119, !tbaa !21
  br label %bb63
bb63:
  %t203 = load i1, ptr %l119, !tbaa !21
  br i1 %t203, label %bb64, label %bb65
bb64:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l4, !tbaa !29
  %t208 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t204, ptr %t205)
  store i1 %t208, ptr %l127
  br label %bb66
bb65:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb67
bb66:
  %t209 = load i1, ptr %l127, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l124, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l124, !tbaa !21
  br i1 %t212, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s5
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l129, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l130, !tbaa !29
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t215)
  store %"compiler/source:Span" %t217, ptr %l132
  br label %bb70
bb69:
  br label %bb78
bb70:
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l134
  br label %bb71
bb71:
  %t221 = load ptr, ptr %l130, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l132
  %t223 = load %"compiler/source:Span", ptr %l134
  %t224 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t221, %"compiler/source:Span" %t222, %"compiler/source:Span" %t223, i64 2)
  store %"compiler/source:Span" %t224, ptr %l135
  br label %bb72
bb72:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l10, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l138
  br label %bb73
bb73:
  %t230 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t230, ptr %l139, !tbaa !27
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i32, ptr %l11, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t231, i32 %t232)
  store { i64, ptr } %t235, ptr %l142
  br label %bb74
bb74:
  %t236 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t239 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s5, ptr %s5, ptr %v0, { i64, ptr } %t237, { i64, ptr } %t236)
  store %"compiler/diagmsg:Msg" %t239, ptr %l144
  br label %bb75
bb75:
  %t240 = load ptr, ptr %l129, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l135
  %t242 = load %"compiler/diagmsg:Msg", ptr %l144
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t240, %"compiler/source:Span" %t241, %"compiler/diagmsg:Msg" %t242)
  store i64 %t243, ptr %l145
  br label %bb76
bb76:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l1
  %t248 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t244, %"compiler/source:Span" %t245)
  store ptr %t248, ptr %l148
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s5)
  %t249 = load ptr, ptr %l148, !tbaa !29
  store ptr %t249, ptr %rv
  br label %ret
bb78:
  %t250 = load i32, ptr %l10, !tbaa !23
  store i32 %t250, ptr %l12, !tbaa !23
  %t252 = load i32, ptr %l5, !tbaa !23
  %t253 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t256 = icmp ne i32 %t252, %t253
  br i1 %t256, label %bb79, label %bb80
bb79:
  %t258 = load i32, ptr %l5, !tbaa !23
  store i32 %t258, ptr %l12, !tbaa !23
  br label %bb236
bb80:
  %t260 = load i32, ptr %l10, !tbaa !23
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t264 = icmp eq i32 %t260, %t261
  br i1 %t264, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb83
bb82:
  %t266 = load i32, ptr %l10, !tbaa !23
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t270 = icmp eq i32 %t266, %t267
  store i1 %t270, ptr %l157, !tbaa !21
  br label %bb83
bb83:
  %t272 = load i1, ptr %l157, !tbaa !21
  br i1 %t272, label %bb84, label %bb85
bb84:
  %t273 = load i32, ptr %l11, !tbaa !23
  store i32 %t273, ptr %l12, !tbaa !23
  br label %bb235
bb85:
  %t275 = load i32, ptr %l11, !tbaa !23
  %t276 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t279 = icmp eq i32 %t275, %t276
  br i1 %t279, label %bb86, label %bb87
bb86:
  %t281 = load i32, ptr %l10, !tbaa !23
  store i32 %t281, ptr %l12, !tbaa !23
  br label %bb234
bb87:
  %t283 = load i32, ptr %l10, !tbaa !23
  %t284 = load i32, ptr %l11, !tbaa !23
  %t287 = icmp ne i32 %t283, %t284
  br i1 %t287, label %bb88, label %bb89
bb88:
  %t289 = load i32, ptr %l11, !tbaa !23
  %t290 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t293 = icmp ne i32 %t289, %t290
  store i1 %t293, ptr %l169, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb90
bb90:
  %t295 = load i1, ptr %l169, !tbaa !21
  br i1 %t295, label %bb91, label %bb92
bb91:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 2
  %t302 = load i32, ptr %l10, !tbaa !23
  %t303 = load i32, ptr %l11, !tbaa !23
  %t307 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t301, i32 %t302, i32 %t303)
  store i1 %t307, ptr %l178
  br label %bb93
bb92:
  br label %bb233
bb93:
  %t308 = load i1, ptr %l178, !tbaa !21
  br i1 %t308, label %bb94, label %bb95
bb94:
  %t309 = load i32, ptr %l10, !tbaa !23
  store i32 %t309, ptr %l12, !tbaa !23
  br label %bb232
bb95:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l10, !tbaa !23
  %t315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t311, i32 %t312)
  store i1 %t315, ptr %l182
  br label %bb96
bb96:
  %t316 = load i1, ptr %l182, !tbaa !21
  br i1 %t316, label %bb97, label %bb98
bb97:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l11, !tbaa !23
  %t321 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l186
  br label %bb99
bb98:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb100
bb99:
  %t322 = load i1, ptr %l186, !tbaa !21
  store i1 %t322, ptr %l183, !tbaa !21
  br label %bb100
bb100:
  %t323 = load i1, ptr %l183, !tbaa !21
  br i1 %t323, label %bb101, label %bb102
bb101:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t328 = load i32, ptr %l10, !tbaa !23
  %t329 = load i32, ptr %l11, !tbaa !23
  %t333 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t327, i32 %t328, i32 %t329)
  store i32 %t333, ptr %l192
  br label %bb103
bb102:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb104
bb103:
  %t334 = load i32, ptr %l192, !tbaa !23
  %t335 = icmp sge i32 %t334, 0
  store i1 %t335, ptr %l187, !tbaa !21
  br label %bb104
bb104:
  %t337 = load i1, ptr %l187, !tbaa !21
  br i1 %t337, label %bb105, label %bb106
bb105:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t342 = load i32, ptr %l10, !tbaa !23
  %t343 = load i32, ptr %l11, !tbaa !23
  %t347 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t341, i32 %t342, i32 %t343)
  store i32 %t347, ptr %l198
  br label %bb107
bb106:
  %t348 = load i32, ptr %l11, !tbaa !23
  %t349 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t352 = icmp eq i32 %t348, %t349
  br i1 %t352, label %bb108, label %bb109
bb107:
  %t354 = load i32, ptr %l198, !tbaa !23
  store i32 %t354, ptr %l12, !tbaa !23
  br label %bb231
bb108:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l10, !tbaa !23
  %t359 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t355, i32 %t356)
  store i1 %t359, ptr %l205
  br label %bb110
bb109:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb115
bb110:
  %t360 = load i1, ptr %l205, !tbaa !21
  br i1 %t360, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb114
bb112:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/check:Checker", ptr %t361, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = getelementptr %"compiler/generic:Program", ptr %t364, i32 0, i32 2
  %t367 = load i32, ptr %l10, !tbaa !23
  %t370 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t366, i32 %t367)
  store i32 %t370, ptr %l211
  br label %bb113
bb113:
  %t371 = load i32, ptr %l211, !range !{i32 0, i32 33}
  %t373 = trunc i64 21 to i32
  %t374 = icmp eq i32 %t371, %t373
  store i1 %t374, ptr %l206, !tbaa !21
  br label %bb114
bb114:
  %t376 = load i1, ptr %l206, !tbaa !21
  store i1 %t376, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t377 = load i1, ptr %l202, !tbaa !21
  br i1 %t377, label %bb116, label %bb117
bb116:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/generic:Program", ptr %t381, i32 0, i32 2
  %t384 = load i32, ptr %l10, !tbaa !23
  %t387 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t383, i32 %t384)
  store i32 %t387, ptr %l218
  br label %bb118
bb117:
  %t388 = load i32, ptr %l10, !tbaa !23
  %t389 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t392 = icmp eq i32 %t388, %t389
  br i1 %t392, label %bb119, label %bb120
bb118:
  %t394 = load i32, ptr %l218, !tbaa !23
  store i32 %t394, ptr %l12, !tbaa !23
  br label %bb230
bb119:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load i32, ptr %l11, !tbaa !23
  %t399 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t395, i32 %t396)
  store i1 %t399, ptr %l225
  br label %bb121
bb120:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb126
bb121:
  %t400 = load i1, ptr %l225, !tbaa !21
  br i1 %t400, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l226, !tbaa !21
  br label %bb125
bb123:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  %t407 = load i32, ptr %l11, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l231
  br label %bb124
bb124:
  %t411 = load i32, ptr %l231, !range !{i32 0, i32 33}
  %t413 = trunc i64 21 to i32
  %t414 = icmp eq i32 %t411, %t413
  store i1 %t414, ptr %l226, !tbaa !21
  br label %bb125
bb125:
  %t416 = load i1, ptr %l226, !tbaa !21
  store i1 %t416, ptr %l222, !tbaa !21
  br label %bb126
bb126:
  %t417 = load i1, ptr %l222, !tbaa !21
  br i1 %t417, label %bb127, label %bb128
bb127:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/generic:Program", ptr %t421, i32 0, i32 2
  %t424 = load i32, ptr %l11, !tbaa !23
  %t427 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t423, i32 %t424)
  store i32 %t427, ptr %l238
  br label %bb129
bb128:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = getelementptr %"compiler/generic:Program", ptr %t431, i32 0, i32 2
  %t434 = load i32, ptr %l10, !tbaa !23
  %t437 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t433, i32 %t434)
  store i32 %t437, ptr %l243
  br label %bb130
bb129:
  %t438 = load i32, ptr %l238, !tbaa !23
  store i32 %t438, ptr %l12, !tbaa !23
  br label %bb229
bb130:
  %t439 = load i32, ptr %l243, !range !{i32 0, i32 33}
  %t441 = trunc i64 21 to i32
  %t442 = icmp eq i32 %t439, %t441
  br i1 %t442, label %bb131, label %bb132
bb131:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/check:Checker", ptr %t444, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = getelementptr %"compiler/generic:Program", ptr %t447, i32 0, i32 2
  store ptr %t449, ptr %l249, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/check:Checker", ptr %t450, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/generic:Program", ptr %t453, i32 0, i32 2
  %t456 = load i32, ptr %l10, !tbaa !23
  %t459 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t455, i32 %t456)
  store i32 %t459, ptr %l254
  br label %bb133
bb132:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb136
bb133:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/generic:Program", ptr %t463, i32 0, i32 2
  %t466 = load i32, ptr %l11, !tbaa !23
  %t469 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t465, i32 %t466)
  store i32 %t469, ptr %l259
  br label %bb134
bb134:
  %t470 = load ptr, ptr %l249, !tbaa !29
  %t471 = load i32, ptr %l254, !tbaa !23
  %t472 = load i32, ptr %l259, !tbaa !23
  %t473 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t470, i32 %t471, i32 %t472)
  store i1 %t473, ptr %l260
  br label %bb135
bb135:
  %t474 = load i1, ptr %l260, !tbaa !21
  store i1 %t474, ptr %l246, !tbaa !21
  br label %bb136
bb136:
  %t475 = load i1, ptr %l246, !tbaa !21
  br i1 %t475, label %bb137, label %bb138
bb137:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/check:Checker", ptr %t476, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !29
  %t481 = getelementptr %"compiler/generic:Program", ptr %t479, i32 0, i32 2
  %t482 = load i32, ptr %l10, !tbaa !23
  %t485 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t481, i32 %t482)
  store i32 %t485, ptr %l265
  br label %bb139
bb138:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l10, !tbaa !23
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t486, i32 %t487)
  store i1 %t490, ptr %l268
  br label %bb140
bb139:
  %t491 = load i32, ptr %l265, !tbaa !23
  store i32 %t491, ptr %l12, !tbaa !23
  br label %bb228
bb140:
  %t492 = load i1, ptr %l268, !tbaa !21
  br i1 %t492, label %bb141, label %bb142
bb141:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load i32, ptr %l11, !tbaa !23
  %t497 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t493, i32 %t494)
  store i1 %t497, ptr %l272
  br label %bb143
bb142:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb144
bb143:
  %t498 = load i1, ptr %l272, !tbaa !21
  %t499 = xor i1 %t498, true
  store i1 %t499, ptr %l269, !tbaa !21
  br label %bb144
bb144:
  %t501 = load i1, ptr %l269, !tbaa !21
  br i1 %t501, label %bb145, label %bb146
bb145:
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l275, !tbaa !29
  %t503 = load i32, ptr %l11, !tbaa !23
  store i32 %t503, ptr %l276, !tbaa !23
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t504, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t509 = getelementptr %"compiler/generic:Program", ptr %t507, i32 0, i32 2
  %t510 = load i32, ptr %l10, !tbaa !23
  %t513 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t509, i32 %t510)
  store i32 %t513, ptr %l281
  br label %bb147
bb146:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb149
bb147:
  %t514 = load ptr, ptr %l275, !tbaa !29
  %t515 = load i32, ptr %l276, !tbaa !23
  %t516 = load i32, ptr %l281, !tbaa !23
  %t517 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t514, i32 %t515, i32 %t516)
  store i1 %t517, ptr %l282
  br label %bb148
bb148:
  %t518 = load i1, ptr %l282, !tbaa !21
  store i1 %t518, ptr %l274, !tbaa !21
  br label %bb149
bb149:
  %t519 = load i1, ptr %l274, !tbaa !21
  br i1 %t519, label %bb150, label %bb151
bb150:
  %t520 = load i32, ptr %l10, !tbaa !23
  store i32 %t520, ptr %l12, !tbaa !23
  br label %bb227
bb151:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l11, !tbaa !23
  %t526 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t522, i32 %t523)
  store i1 %t526, ptr %l286
  br label %bb152
bb152:
  %t527 = load i1, ptr %l286, !tbaa !21
  br i1 %t527, label %bb153, label %bb154
bb153:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load i32, ptr %l10, !tbaa !23
  %t532 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t528, i32 %t529)
  store i1 %t532, ptr %l290
  br label %bb155
bb154:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb156
bb155:
  %t533 = load i1, ptr %l290, !tbaa !21
  %t534 = xor i1 %t533, true
  store i1 %t534, ptr %l287, !tbaa !21
  br label %bb156
bb156:
  %t536 = load i1, ptr %l287, !tbaa !21
  br i1 %t536, label %bb157, label %bb158
bb157:
  %t537 = load ptr, ptr %l0, !tbaa !29
  store ptr %t537, ptr %l293, !tbaa !29
  %t538 = load i32, ptr %l10, !tbaa !23
  store i32 %t538, ptr %l294, !tbaa !23
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/check:Checker", ptr %t539, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !29
  %t544 = getelementptr %"compiler/generic:Program", ptr %t542, i32 0, i32 2
  %t545 = load i32, ptr %l11, !tbaa !23
  %t548 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l299
  br label %bb159
bb158:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb161
bb159:
  %t549 = load ptr, ptr %l293, !tbaa !29
  %t550 = load i32, ptr %l294, !tbaa !23
  %t551 = load i32, ptr %l299, !tbaa !23
  %t552 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t549, i32 %t550, i32 %t551)
  store i1 %t552, ptr %l300
  br label %bb160
bb160:
  %t553 = load i1, ptr %l300, !tbaa !21
  store i1 %t553, ptr %l292, !tbaa !21
  br label %bb161
bb161:
  %t554 = load i1, ptr %l292, !tbaa !21
  br i1 %t554, label %bb162, label %bb163
bb162:
  %t555 = load i32, ptr %l11, !tbaa !23
  store i32 %t555, ptr %l12, !tbaa !23
  br label %bb226
bb163:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load i32, ptr %l10, !tbaa !23
  %t561 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t557, i32 %t558)
  store i1 %t561, ptr %l304
  br label %bb164
bb164:
  %t562 = load i1, ptr %l304, !tbaa !21
  br i1 %t562, label %bb165, label %bb166
bb165:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i32, ptr %l11, !tbaa !23
  %t567 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t563, i32 %t564)
  store i1 %t567, ptr %l308
  br label %bb167
bb166:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb168
bb167:
  %t568 = load i1, ptr %l308, !tbaa !21
  store i1 %t568, ptr %l305, !tbaa !21
  br label %bb168
bb168:
  %t569 = load i1, ptr %l305, !tbaa !21
  br i1 %t569, label %bb169, label %bb170
bb169:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/check:Checker", ptr %t570, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !29
  %t575 = getelementptr %"compiler/generic:Program", ptr %t573, i32 0, i32 2
  store ptr %t575, ptr %l312, !tbaa !29
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i32, ptr %l10, !tbaa !23
  %t580 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t576, i32 %t577)
  store i32 %t580, ptr %l315
  br label %bb171
bb170:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb174
bb171:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load i32, ptr %l11, !tbaa !23
  %t585 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t581, i32 %t582)
  store i32 %t585, ptr %l318
  br label %bb172
bb172:
  %t586 = load ptr, ptr %l312, !tbaa !29
  %t587 = load i32, ptr %l315, !tbaa !23
  %t588 = load i32, ptr %l318, !tbaa !23
  %t589 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l319
  br label %bb173
bb173:
  %t590 = load i1, ptr %l319, !tbaa !21
  store i1 %t590, ptr %l309, !tbaa !21
  br label %bb174
bb174:
  %t591 = load i1, ptr %l309, !tbaa !21
  br i1 %t591, label %bb175, label %bb176
bb175:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t595, i32 0, i32 2
  store ptr %t597, ptr %l322, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load i32, ptr %l10, !tbaa !23
  %t602 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t598, i32 %t599)
  store i32 %t602, ptr %l325
  br label %bb177
bb176:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load i32, ptr %l10, !tbaa !23
  %t607 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t603, i32 %t604)
  store i1 %t607, ptr %l340
  br label %bb182
bb177:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/check:Checker", ptr %t608, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = getelementptr %"compiler/generic:Program", ptr %t611, i32 0, i32 2
  %t614 = load i32, ptr %l10, !tbaa !23
  %t617 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t613, i32 %t614)
  store i64 %t617, ptr %l330
  br label %bb178
bb178:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !29
  %t623 = getelementptr %"compiler/generic:Program", ptr %t621, i32 0, i32 2
  %t624 = load i32, ptr %l11, !tbaa !23
  %t627 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t623, i32 %t624)
  store i64 %t627, ptr %l335
  br label %bb179
bb179:
  %t628 = load i64, ptr %l330, !tbaa !24
  %t629 = load i64, ptr %l335, !tbaa !24
  %t630 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t628, i64 %t629)
  store i64 %t630, ptr %l336
  br label %bb180
bb180:
  %t631 = load ptr, ptr %l322, !tbaa !29
  %t632 = load i32, ptr %l325, !tbaa !23
  %t633 = load i64, ptr %l336, !tbaa !24
  %t634 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t631, i32 %t632, i64 %t633)
  store i32 %t634, ptr %l337
  br label %bb181
bb181:
  %t635 = load i32, ptr %l337, !tbaa !23
  store i32 %t635, ptr %l12, !tbaa !23
  br label %bb225
bb182:
  %t636 = load i1, ptr %l340, !tbaa !21
  br i1 %t636, label %bb183, label %bb184
bb183:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load i32, ptr %l11, !tbaa !23
  %t641 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t637, i32 %t638)
  store i1 %t641, ptr %l344
  br label %bb185
bb184:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb186
bb185:
  %t642 = load i1, ptr %l344, !tbaa !21
  store i1 %t642, ptr %l341, !tbaa !21
  br label %bb186
bb186:
  %t643 = load i1, ptr %l341, !tbaa !21
  br i1 %t643, label %bb187, label %bb188
bb187:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t646 = getelementptr %"compiler/check:Checker", ptr %t644, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t649 = getelementptr %"compiler/generic:Program", ptr %t647, i32 0, i32 2
  store ptr %t649, ptr %l348, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l349, !tbaa !29
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load i32, ptr %l10, !tbaa !23
  %t655 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t651, i32 %t652)
  store i32 %t655, ptr %l352
  br label %bb189
bb188:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb194
bb189:
  %t656 = load ptr, ptr %l349, !tbaa !29
  %t657 = load i32, ptr %l352, !tbaa !23
  %t658 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t656, i32 %t657)
  store i32 %t658, ptr %l353
  br label %bb190
bb190:
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l354, !tbaa !29
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load i32, ptr %l11, !tbaa !23
  %t664 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t660, i32 %t661)
  store i32 %t664, ptr %l357
  br label %bb191
bb191:
  %t665 = load ptr, ptr %l354, !tbaa !29
  %t666 = load i32, ptr %l357, !tbaa !23
  %t667 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t665, i32 %t666)
  store i32 %t667, ptr %l358
  br label %bb192
bb192:
  %t668 = load ptr, ptr %l348, !tbaa !29
  %t669 = load i32, ptr %l353, !tbaa !23
  %t670 = load i32, ptr %l358, !tbaa !23
  %t671 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t668, i32 %t669, i32 %t670)
  store i1 %t671, ptr %l359
  br label %bb193
bb193:
  %t672 = load i1, ptr %l359, !tbaa !21
  store i1 %t672, ptr %l345, !tbaa !21
  br label %bb194
bb194:
  %t673 = load i1, ptr %l345, !tbaa !21
  br i1 %t673, label %bb195, label %bb196
bb195:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/check:Checker", ptr %t674, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !29
  %t679 = getelementptr %"compiler/generic:Program", ptr %t677, i32 0, i32 2
  store ptr %t679, ptr %l362, !tbaa !29
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l363, !tbaa !29
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load i32, ptr %l10, !tbaa !23
  %t685 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t681, i32 %t682)
  store i32 %t685, ptr %l366
  br label %bb197
bb196:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/check:Checker", ptr %t686, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t691 = getelementptr %"compiler/generic:Program", ptr %t689, i32 0, i32 2
  %t692 = load i32, ptr %l10, !tbaa !23
  %t695 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t691, i32 %t692)
  store i32 %t695, ptr %l384
  br label %bb203
bb197:
  %t696 = load ptr, ptr %l363, !tbaa !29
  %t697 = load i32, ptr %l366, !tbaa !23
  %t698 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t696, i32 %t697)
  store i32 %t698, ptr %l367
  br label %bb198
bb198:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = getelementptr %"compiler/check:Checker", ptr %t699, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !29
  %t704 = getelementptr %"compiler/generic:Program", ptr %t702, i32 0, i32 2
  %t705 = load i32, ptr %l10, !tbaa !23
  %t708 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t704, i32 %t705)
  store i64 %t708, ptr %l372
  br label %bb199
bb199:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t711 = getelementptr %"compiler/check:Checker", ptr %t709, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !29
  %t714 = getelementptr %"compiler/generic:Program", ptr %t712, i32 0, i32 2
  %t715 = load i32, ptr %l11, !tbaa !23
  %t718 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t714, i32 %t715)
  store i64 %t718, ptr %l377
  br label %bb200
bb200:
  %t719 = load i64, ptr %l372, !tbaa !24
  %t720 = load i64, ptr %l377, !tbaa !24
  %t721 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t719, i64 %t720)
  store i64 %t721, ptr %l378
  br label %bb201
bb201:
  %t722 = load ptr, ptr %l362, !tbaa !29
  %t723 = load i32, ptr %l367, !tbaa !23
  %t724 = load i64, ptr %l378, !tbaa !24
  %t725 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t722, i32 %t723, i64 %t724)
  store i32 %t725, ptr %l379
  br label %bb202
bb202:
  %t726 = load i32, ptr %l379, !tbaa !23
  store i32 %t726, ptr %l12, !tbaa !23
  br label %bb224
bb203:
  %t727 = load i32, ptr %l384, !range !{i32 0, i32 33}
  %t729 = trunc i64 19 to i32
  %t730 = icmp eq i32 %t727, %t729
  br i1 %t730, label %bb204, label %bb205
bb204:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t734 = getelementptr %"compiler/check:Checker", ptr %t732, i32 0, i32 1
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = getelementptr %"compiler/generic:Program", ptr %t735, i32 0, i32 2
  %t738 = load i32, ptr %l11, !tbaa !23
  %t741 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t737, i32 %t738)
  store i32 %t741, ptr %l392
  br label %bb206
bb205:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb207
bb206:
  %t742 = load i32, ptr %l392, !range !{i32 0, i32 33}
  %t744 = trunc i64 19 to i32
  %t745 = icmp eq i32 %t742, %t744
  store i1 %t745, ptr %l387, !tbaa !21
  br label %bb207
bb207:
  %t747 = load i1, ptr %l387, !tbaa !21
  br i1 %t747, label %bb208, label %bb209
bb208:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = getelementptr %"compiler/check:Checker", ptr %t748, i32 0, i32 1
  %t751 = load ptr, ptr %t750, !tbaa !29
  %t753 = getelementptr %"compiler/generic:Program", ptr %t751, i32 0, i32 2
  store ptr %t753, ptr %l398, !tbaa !29
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = getelementptr %"compiler/check:Checker", ptr %t754, i32 0, i32 1
  %t757 = load ptr, ptr %t756, !tbaa !29
  %t759 = getelementptr %"compiler/generic:Program", ptr %t757, i32 0, i32 2
  %t760 = load i32, ptr %l10, !tbaa !23
  %t763 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t759, i32 %t760)
  store i32 %t763, ptr %l403
  br label %bb210
bb209:
  store i1 false, ptr %l395, !tbaa !21
  br label %bb213
bb210:
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t766 = getelementptr %"compiler/check:Checker", ptr %t764, i32 0, i32 1
  %t767 = load ptr, ptr %t766, !tbaa !29
  %t769 = getelementptr %"compiler/generic:Program", ptr %t767, i32 0, i32 2
  %t770 = load i32, ptr %l11, !tbaa !23
  %t773 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t769, i32 %t770)
  store i32 %t773, ptr %l408
  br label %bb211
bb211:
  %t774 = load ptr, ptr %l398, !tbaa !29
  %t775 = load i32, ptr %l403, !tbaa !23
  %t776 = load i32, ptr %l408, !tbaa !23
  %t777 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t774, i32 %t775, i32 %t776)
  store i1 %t777, ptr %l409
  br label %bb212
bb212:
  %t778 = load i1, ptr %l409, !tbaa !21
  store i1 %t778, ptr %l395, !tbaa !21
  br label %bb213
bb213:
  %t779 = load i1, ptr %l395, !tbaa !21
  br i1 %t779, label %bb214, label %bb215
bb214:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t782 = getelementptr %"compiler/check:Checker", ptr %t780, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !29
  %t785 = getelementptr %"compiler/generic:Program", ptr %t783, i32 0, i32 2
  store ptr %t785, ptr %l412, !tbaa !29
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t788 = getelementptr %"compiler/check:Checker", ptr %t786, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !29
  %t791 = getelementptr %"compiler/generic:Program", ptr %t789, i32 0, i32 2
  %t792 = load i32, ptr %l10, !tbaa !23
  %t795 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t795, ptr %l417
  br label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s32
  %t796 = load ptr, ptr %l0, !tbaa !29
  store ptr %t796, ptr %l419, !tbaa !29
  %t797 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t797, ptr %l420
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load i32, ptr %l10, !tbaa !23
  %t802 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t798, i32 %t799)
  store { i64, ptr } %t802, ptr %l423
  br label %bb218
bb216:
  %t803 = load ptr, ptr %l412, !tbaa !29
  %t804 = load i32, ptr %l417, !tbaa !23
  %t805 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t803, i32 %t804, i32 0)
  store i32 %t805, ptr %l418
  br label %bb217
bb217:
  %t806 = load i32, ptr %l418, !tbaa !23
  store i32 %t806, ptr %l12, !tbaa !23
  br label %bb223
bb218:
  %t807 = load { i64, ptr }, ptr %l423, !tbaa !27
  store { i64, ptr } %t807, ptr %l424, !tbaa !27
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t809 = load i32, ptr %l11, !tbaa !23
  %t812 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t808, i32 %t809)
  store { i64, ptr } %t812, ptr %l427
  br label %bb219
bb219:
  %t813 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t816 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s32, ptr %s32, ptr %v0, { i64, ptr } %t814, { i64, ptr } %t813)
  store %"compiler/diagmsg:Msg" %t816, ptr %l429
  br label %bb220
bb220:
  %t817 = load ptr, ptr %l419, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l420
  %t819 = load %"compiler/diagmsg:Msg", ptr %l429
  %t820 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t817, %"compiler/source:Span" %t818, %"compiler/diagmsg:Msg" %t819)
  store i64 %t820, ptr %l430
  br label %bb221
bb221:
  %t821 = load ptr, ptr %l0, !tbaa !29
  %t822 = load %"compiler/source:Span", ptr %l1
  %t825 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t821, %"compiler/source:Span" %t822)
  store ptr %t825, ptr %l433
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s32)
  %t826 = load ptr, ptr %l433, !tbaa !29
  store ptr %t826, ptr %rv
  br label %ret
bb223:
  br label %bb224
bb224:
  br label %bb225
bb225:
  br label %bb226
bb226:
  br label %bb227
bb227:
  br label %bb228
bb228:
  br label %bb229
bb229:
  br label %bb230
bb230:
  br label %bb231
bb231:
  br label %bb232
bb232:
  br label %bb233
bb233:
  br label %bb234
bb234:
  br label %bb235
bb235:
  br label %bb236
bb236:
  %t827 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t827, ptr %l434
  %t828 = load i32, ptr %l12, !tbaa !23
  store i32 %t828, ptr %l435, !tbaa !23
  %t829 = load ptr, ptr %l7, !tbaa !29
  store ptr %t829, ptr %l436, !tbaa !29
  %t830 = load ptr, ptr %l0, !tbaa !29
  store ptr %t830, ptr %l437, !tbaa !29
  %t831 = load ptr, ptr %l8, !tbaa !29
  %t833 = icmp eq ptr %t831, null
  br i1 %t833, label %bb237, label %bb238
bb237:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb238:
  br label %bb239
bb239:
  %t835 = load ptr, ptr %l8, !tbaa !29
  store ptr %t835, ptr %l440, !tbaa !29
  %t836 = load i32, ptr %l12, !tbaa !23
  store i32 %t836, ptr %l441, !tbaa !23
  %t837 = load ptr, ptr %l2, !tbaa !29
  %t839 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t837)
  store %"compiler/source:Span" %t839, ptr %l443
  br label %bb240
bb240:
  %t840 = load ptr, ptr %l437, !tbaa !29
  %t841 = load ptr, ptr %l440, !tbaa !29
  %t842 = load i32, ptr %l441, !tbaa !23
  %t843 = load %"compiler/source:Span", ptr %l443
  %t844 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v4, ptr %v4, ptr %t840, ptr %t841, i32 %t842, %"compiler/source:Span" %t843)
  store ptr %t844, ptr %l444
  br label %bb241
bb241:
  %t845 = load ptr, ptr %l444, !tbaa !29
  store ptr %t845, ptr %l445, !tbaa !29
  %t846 = load ptr, ptr %l0, !tbaa !29
  store ptr %t846, ptr %l446, !tbaa !29
  %t847 = load ptr, ptr %l9, !tbaa !29
  %t849 = icmp eq ptr %t847, null
  br i1 %t849, label %bb242, label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb243:
  br label %bb244
bb244:
  %t851 = load ptr, ptr %l9, !tbaa !29
  store ptr %t851, ptr %l449, !tbaa !29
  %t852 = load i32, ptr %l12, !tbaa !23
  store i32 %t852, ptr %l450, !tbaa !23
  %t853 = load ptr, ptr %l4, !tbaa !29
  %t855 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t853)
  store %"compiler/source:Span" %t855, ptr %l452
  br label %bb245
bb245:
  %t856 = load ptr, ptr %l446, !tbaa !29
  %t857 = load ptr, ptr %l449, !tbaa !29
  %t858 = load i32, ptr %l450, !tbaa !23
  %t859 = load %"compiler/source:Span", ptr %l452
  %t860 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v4, ptr %v0, ptr %t856, ptr %t857, i32 %t858, %"compiler/source:Span" %t859)
  store ptr %t860, ptr %l453
  br label %bb246
bb246:
  %t861 = load ptr, ptr %l436, !tbaa !29
  %t862 = load ptr, ptr %l445, !tbaa !29
  %t863 = load ptr, ptr %l453, !tbaa !29
  %t864 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v4, ptr %v4, ptr %v0, ptr %v4, ptr %t861, ptr %t862, ptr %t863)
  store %"compiler/typed:Cond" %t864, ptr %l454
  br label %bb247
bb247:
  %t865 = load %"compiler/typed:Cond", ptr %l454
  %t866 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t865, ptr %t866
  store { i64, [5 x i64] } zeroinitializer, ptr %t867
  %t868 = getelementptr { i64, [5 x i64] }, ptr %t867, i32 0, i32 0
  store i64 11, ptr %t868
  %t869 = load %"compiler/source:Span", ptr %l434
  %t870 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t869, 0
  %t871 = load i32, ptr %l435, !tbaa !23
  %t872 = insertvalue { %"compiler/source:Span", i32, ptr } %t870, i32 %t871, 1
  %t874 = insertvalue { %"compiler/source:Span", i32, ptr } %t872, ptr %t866, 2
  %t875 = getelementptr { i64, [5 x i64] }, ptr %t867, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t874, ptr %t875
  %t876 = load { i64, [5 x i64] }, ptr %t867
  %t878 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t876, ptr %t878
  store ptr %t878, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/check:ctSource"
  %l98 = alloca i32
  %l102 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca i64
  %l118 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca %"compiler/check:ctSource"
  %l157 = alloca ptr
  %l158 = alloca i1
  %l176 = alloca { i64, ptr }
  %l182 = alloca %"compiler/check:ctSource"
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 19
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l22, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb24
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l31
  br label %bb5
bb5:
  %t30 = load i64, ptr %l31, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l35
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l35, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 6
  %t43 = load i1, ptr %t42, !tbaa !21
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb10
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t50, i64 %t51)
  store i1 %t54, ptr %l43
  br label %bb9
bb9:
  %t55 = load i1, ptr %l43, !tbaa !21
  store i1 %t55, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l48
  br label %bb14
bb14:
  %t66 = load i64, ptr %l48, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Func", ptr %t67, i32 0, i32 4
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l50, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l54, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/load:Loader", ptr %t87, i32 0, i32 10
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l60
  br label %bb15
bb15:
  %t94 = load ptr, ptr %l60, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 6
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l7, !tbaa !29
  %t99 = load ptr, ptr %l7, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb17:
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t106 = getelementptr %"compiler/source:Source", ptr %t103, i32 0, i32 1
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Func", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Sig", ptr %t111, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Func", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t120 = load ptr, ptr %l54, !tbaa !29
  %t124 = call { i64, ptr } @compiler_2fast_2eRequirements(ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t119, ptr %t120, { i64, ptr } %t107, { i64, ptr } %t114, ptr %t118)
  store { i64, ptr } %t124, ptr %l73
  br label %bb19
bb19:
  %t125 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t125, ptr %l74, !tbaa !27
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr %"compiler/ast:Func", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l76, !tbaa !29
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Func", ptr %t131, i32 0, i32 3
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Sig", ptr %t134, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l79, !tbaa !27
  %t138 = load i64, ptr %l6, !tbaa !24
  store i64 %t138, ptr %l80, !tbaa !24
  %t139 = call ptr @__olang_scope_hold(ptr %v1)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l81, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3actSource_2e4
  br i1 %t141, label %bb20, label %bb21
bb20:
  %t143 = call ptr @__olang_region_make(ptr %v1)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb21
bb21:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Func", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %t148, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t145, i32 %t149)
  store { i64, ptr } %t152, ptr %l86
  br label %bb22
bb22:
  %t153 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = load i64, ptr %l81
  %t157 = inttoptr i64 %t156 to ptr
  %t158 = call ptr @__olang_held_alloc(ptr %t157, i64 %t155)
  call void @olang_textcopy(ptr %t158, ptr %t154, i64 %t155)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t163 = load ptr, ptr %l76, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t165 = load i64, ptr %l80, !tbaa !24
  %t167 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t162, ptr %t163, { i64, ptr } %t164, i64 %t165, { i64, ptr } %t160)
  store %"compiler/check:ctSource" %t167, ptr %l89
  br label %bb23
bb23:
  %t168 = load %"compiler/check:ctSource", ptr %l89
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/check:ctSource" %t168, ptr %t169
  call void @__olang_scope_close(ptr %s1)
  store ptr %t169, ptr %rv
  br label %ret
bb24:
  %t171 = load { i64, [2 x i64] }, ptr %l2
  %t173 = extractvalue { i64, [2 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 1
  br i1 %t174, label %bb25, label %bb26
bb25:
  %t176 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t177 = getelementptr { i32, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb65
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l9, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l98
  br label %bb28
bb28:
  %t190 = load i32, ptr %l98, !tbaa !23
  store i32 %t190, ptr %l10, !tbaa !23
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = load i32, ptr %l10, !tbaa !23
  %t198 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t194, i32 %t195)
  store ptr %t198, ptr %l102
  br label %bb29
bb29:
  %t199 = load ptr, ptr %l102, !tbaa !29
  store ptr %t199, ptr %l11, !tbaa !29
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  br i1 %t202, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb32
bb31:
  %t204 = load ptr, ptr %l11, !tbaa !29
  %t206 = getelementptr %"compiler/ast:TypeDecl", ptr %t204, i32 0, i32 3
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  store i1 %t209, ptr %l105, !tbaa !21
  br label %bb32
bb32:
  %t211 = load i1, ptr %l105, !tbaa !21
  br i1 %t211, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %l10, !tbaa !23
  %t222 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t218, i32 %t219)
  store i64 %t222, ptr %l114
  br label %bb36
bb36:
  %t223 = load i64, ptr %l114, !tbaa !24
  store i64 %t223, ptr %l12, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t227 = getelementptr %"compiler/ast:TypeDecl", ptr %t225, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t224, i32 %t228)
  store { i64, ptr } %t231, ptr %l118
  br label %bb37
bb37:
  %t232 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t233, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t238 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t238, ptr %lp13
  %t240 = load ptr, ptr %lp13
  store { i64, ptr } %t237, ptr %t240, !tbaa !27
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/load:Loader", ptr %t247, i32 0, i32 10
  %t250 = load i64, ptr %l12, !tbaa !24
  %t253 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t249, i64 %t250)
  store ptr %t253, ptr %l125
  br label %bb38
bb38:
  %t254 = load ptr, ptr %l125, !tbaa !29
  %t256 = getelementptr %"compiler/load:Module", ptr %t254, i32 0, i32 6
  %t257 = load ptr, ptr %t256, !tbaa !29
  store ptr %t257, ptr %l14, !tbaa !29
  %t259 = load ptr, ptr %l14, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb40:
  br label %bb41
bb41:
  %t263 = load ptr, ptr %l14, !tbaa !29
  %t266 = getelementptr %"compiler/source:Source", ptr %t263, i32 0, i32 1
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  store { i64, ptr } %t267, ptr %l15, !tbaa !27
  %t269 = load ptr, ptr %l11, !tbaa !29
  %t271 = getelementptr %"compiler/ast:TypeDecl", ptr %t269, i32 0, i32 3
  %t272 = load ptr, ptr %t271, !tbaa !29
  store ptr %t272, ptr %l16, !tbaa !29
  %t274 = load ptr, ptr %l16, !tbaa !29
  store ptr %t274, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t275 = load ptr, ptr %l135, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb42, label %bb43
bb42:
  %t278 = load ptr, ptr %l135, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 5}
  %t281 = icmp eq i64 %t279, 0
  store i1 %t281, ptr %l136, !tbaa !21
  br label %bb43
bb43:
  %t282 = load i1, ptr %l136, !tbaa !21
  br i1 %t282, label %bb44, label %bb45
bb44:
  %t283 = load ptr, ptr %l16, !tbaa !29
  %t285 = getelementptr { i64, [6 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { ptr }, ptr %t285, i32 0, i32 0
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l17, !tbaa !29
  br label %bb46
bb45:
  br label %bb49
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t289 = load ptr, ptr %l17, !tbaa !29
  %t291 = getelementptr %"compiler/ast:StructBody", ptr %t289, i32 0, i32 2
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 0
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/load:Loader", ptr %t299, i32 0, i32 3
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t304 = load ptr, ptr %l17, !tbaa !29
  %t306 = getelementptr %"compiler/ast:StructBody", ptr %t304, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306, !tbaa !27
  %t312 = call { i64, ptr } @compiler_2fast_2eRequirements(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s7, ptr %v0, { i64, ptr } %t292, ptr %t302, { i64, ptr } %t303, { i64, ptr } %t307, ptr null)
  store { i64, ptr } %t312, ptr %l150
  br label %bb47
bb47:
  %t313 = load ptr, ptr %l17, !tbaa !29
  %t315 = getelementptr %"compiler/ast:StructBody", ptr %t313, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t317 = load i64, ptr %l12, !tbaa !24
  %t318 = load ptr, ptr %lp13
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t324 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t320, ptr null, { i64, ptr } %t316, i64 %t317, { i64, ptr } %t319)
  store %"compiler/check:ctSource" %t324, ptr %l155
  br label %bb48
bb48:
  %t325 = load %"compiler/check:ctSource", ptr %l155
  %t326 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/check:ctSource" %t325, ptr %t326
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  store ptr %t326, ptr %rv
  br label %ret
bb49:
  %t328 = load ptr, ptr %l16, !tbaa !29
  store ptr %t328, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t329 = load ptr, ptr %l157, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb50, label %bb51
bb50:
  %t332 = load ptr, ptr %l157, !tbaa !29
  %t333 = load i64, ptr %t332, !range !{i64 0, i64 5}
  %t335 = icmp eq i64 %t333, 3
  store i1 %t335, ptr %l158, !tbaa !21
  br label %bb51
bb51:
  %t336 = load i1, ptr %l158, !tbaa !21
  br i1 %t336, label %bb52, label %bb53
bb52:
  %t337 = load ptr, ptr %l16, !tbaa !29
  %t339 = getelementptr { i64, [6 x i64] }, ptr %t337, i32 0, i32 1
  %t340 = getelementptr { ptr, ptr }, ptr %t339, i32 0, i32 1
  %t341 = load ptr, ptr %t340
  store ptr %t341, ptr %l18, !tbaa !29
  br label %bb54
bb53:
  br label %bb60
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t343 = load ptr, ptr %l18, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  br i1 %t345, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = getelementptr %"compiler/ast:Func", ptr %t348, i32 0, i32 4
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/check:Checker", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = getelementptr %"compiler/generic:Program", ptr %t355, i32 0, i32 0
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t360 = getelementptr %"compiler/load:Loader", ptr %t358, i32 0, i32 3
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t363 = load ptr, ptr %l18, !tbaa !29
  %t365 = getelementptr %"compiler/ast:Func", ptr %t363, i32 0, i32 3
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/ast:Sig", ptr %t366, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  %t374 = call { i64, ptr } @compiler_2fast_2eRequirements(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s8, ptr %v0, { i64, ptr } %t351, ptr %t361, { i64, ptr } %t362, { i64, ptr } %t369, ptr null)
  store { i64, ptr } %t374, ptr %l176
  br label %bb58
bb58:
  %t375 = load ptr, ptr %l18, !tbaa !29
  %t377 = getelementptr %"compiler/ast:Func", ptr %t375, i32 0, i32 3
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Sig", ptr %t378, i32 0, i32 0
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t382 = load i64, ptr %l12, !tbaa !24
  %t383 = load ptr, ptr %lp13
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t389 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t385, ptr null, { i64, ptr } %t381, i64 %t382, { i64, ptr } %t384)
  store %"compiler/check:ctSource" %t389, ptr %l182
  br label %bb59
bb59:
  %t390 = load %"compiler/check:ctSource", ptr %l182
  %t391 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/check:ctSource" %t390, ptr %t391
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  store ptr %t391, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_7d341668197b23b8_39fb9abd34d1e724)
  unreachable
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store ptr null, ptr %rv
  br label %ret
bb69:
  call void @__olang_check_failed(ptr @olang_loc_82b8e88501244989_8304f205bc7c5615)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Sig", ptr %t17, i32 0, i32 4
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb22
bb6:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t24, ptr %l15
  br label %bb7
bb7:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 7
  %t29 = load i1, ptr %t28, !tbaa !21
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb22
bb11:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t33, ptr %l19
  br label %bb12
bb12:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l23
  br label %bb16
bb16:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l8, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Sig", ptr %t47, i32 0, i32 5
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l8, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bdeebae2e62e4381_d7e2b33750a898f5)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l8, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t83, i64 %t84)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l14, !tbaa !24
  store i64 %t88, ptr %l62, !tbaa !24
  %t89 = load ptr, ptr %l13, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t89)
  store i64 %t91, ptr %l64
  br label %bb23
bb23:
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = load i64, ptr %l64, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t98 = load ptr, ptr %l13, !tbaa !29
  %t99 = load i64, ptr %l14, !tbaa !24
  %t102 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l69
  br label %bb27
bb27:
  %t103 = load i32, ptr %l69, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t104, i32 %t103)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t108 = load i64, ptr %l14, !tbaa !24
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l24 = alloca ptr
  %l29 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i32
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l99 = alloca ptr
  %l102 = alloca i64
  %l105 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l124 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrSubjectOf(ptr %v0, ptr %v1, ptr %v3, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l14, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t7)
  store i32 %t10, ptr %l17
  br label %bb2
bb2:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, i64 0)
  store ptr %t24, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l24, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l29
  br label %bb7
bb7:
  %t36 = load i1, ptr %l29, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l31, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t40)
  store %"compiler/source:Span" %t42, ptr %l33
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l34, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t44)
  store %"compiler/source:Span" %t46, ptr %l36
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l36
  %t49 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t49, ptr %l37
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l40
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t55, ptr %l41, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l42, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t57)
  store %"compiler/source:Span" %t59, ptr %l44
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l42, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l44
  %t62 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t60, %"compiler/source:Span" %t61)
  store { i64, ptr } %t62, ptr %l45
  br label %bb15
bb15:
  %t63 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t66 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrComparedNotError(ptr %v0, ptr %s2, ptr %v0, ptr %v0, { i64, ptr } %t63, { i64, ptr } %t64, { i64, ptr } %t65)
  store %"compiler/diagmsg:Msg" %t66, ptr %l46
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l31, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l33
  %t69 = load %"compiler/diagmsg:Msg", ptr %l46
  %t70 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t67, %"compiler/source:Span" %t68, %"compiler/diagmsg:Msg" %t69)
  store i64 %t70, ptr %l47
  br label %bb17
bb17:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t71, %"compiler/source:Span" %t72, i32 %t73, i64 0)
  store ptr %t77, ptr %l51
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t78 = load ptr, ptr %l51, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t83 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v2, ptr %s0, ptr %t79, ptr %t80)
  %t84 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, 1
  %t85 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, 0
  store i32 %t85, ptr %l56
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb21, label %ok.87, !prof !99
ok.87:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l55
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l52
  br label %bb24
bb21:
  %t89 = load i32, ptr %l56, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l62
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load ptr, ptr %l62, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb24:
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l7
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l63, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l6, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l68
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load i32, ptr %l68, !tbaa !23
  %t115 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t113, i32 %t114)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l69
  br label %bb26
bb26:
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l8
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t117, ptr %l8, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l73
  br label %bb27
bb27:
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l73)
  store i64 %t123, ptr %l75
  br label %bb28
bb28:
  %t124 = load i64, ptr %l75, !tbaa !24
  %t125 = icmp eq i64 %t124, 0
  br i1 %t125, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l77, !tbaa !29
  %t128 = load ptr, ptr %l4, !tbaa !29
  %t130 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t128)
  store %"compiler/source:Span" %t130, ptr %l79
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l80, !tbaa !29
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t132)
  store %"compiler/source:Span" %t134, ptr %l82
  br label %bb32
bb32:
  %t135 = load ptr, ptr %l80, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l82
  %t137 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s4, ptr %t135, %"compiler/source:Span" %t136)
  store { i64, ptr } %t137, ptr %l83
  br label %bb33
bb33:
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t140 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = getelementptr i8, ptr %t148, i64 %t142
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t147, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s4, ptr %t153, ptr %l7)
  store { i64, ptr } %t156, ptr %l88
  br label %bb34
bb34:
  %t157 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t157, ptr %l89, !tbaa !27
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s4, ptr %t158, ptr %l8)
  store { i64, ptr } %t161, ptr %l92
  br label %bb35
bb35:
  %t162 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s4, ptr %s4, ptr %s4, ptr %v0, { i64, ptr } %t163, { i64, ptr } %t164, { i64, ptr } %t162)
  store %"compiler/diagmsg:Msg" %t166, ptr %l94
  br label %bb36
bb36:
  %t167 = load ptr, ptr %l77, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l79
  %t169 = load %"compiler/diagmsg:Msg", ptr %l94
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l95
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l1
  %t173 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t171, %"compiler/source:Span" %t172, i32 %t173, i64 0)
  store ptr %t177, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t178 = load ptr, ptr %l99, !tbaa !29
  store ptr %t178, ptr %rv
  br label %ret
bb39:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 48
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l102
  br label %bb40
bb40:
  %t184 = load i64, ptr %l102, !tbaa !24
  store i64 %t184, ptr %l9, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l5, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %v3, ptr %v3, ptr %t185, ptr %t186)
  store ptr %t189, ptr %l105
  br label %bb41
bb41:
  %t190 = load ptr, ptr %l105, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l1
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v3, ptr %s0, ptr %v3, ptr %t191, %"compiler/source:Span" %t192, ptr %t190, ptr %l7)
  store ptr %t198, ptr %l110
  br label %bb42
bb42:
  %t199 = load ptr, ptr %l110, !tbaa !29
  store ptr %t199, ptr %l11, !tbaa !29
  %t202 = trunc i64 96 to i32
  %t203 = icmp eq i32 %a2, %t202
  br i1 %t203, label %bb43, label %bb44
bb43:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load ptr, ptr %l11, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t205, %"compiler/source:Span" %t206, ptr %t207)
  store ptr %t211, ptr %l117
  br label %bb45
bb44:
  %t212 = load ptr, ptr %l11, !tbaa !29
  store ptr %t212, ptr %l113, !tbaa !29
  br label %bb46
bb45:
  %t214 = load ptr, ptr %l117, !tbaa !29
  store ptr %t214, ptr %l113, !tbaa !29
  br label %bb46
bb46:
  %t215 = load ptr, ptr %l113, !tbaa !29
  store ptr %t215, ptr %l11, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  %t218 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t219 = load i64, ptr %l9, !tbaa !24
  %t220 = load ptr, ptr %l11, !tbaa !29
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v3, ptr %v3, ptr %t216, %"compiler/source:Span" %t217, i32 %t218, i64 %t219, ptr %t220)
  store ptr %t226, ptr %l124
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t227 = load ptr, ptr %l124, !tbaa !29
  store ptr %t227, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca i64
  %l41 = alloca ptr
  %rv = alloca ptr
  %t62 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fde34f6ad3d04e85_8bb8dc064f471149)
  unreachable
bb16:
  br label %bb28
bb17:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb18, label %bb19
bb18:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb19
bb19:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7e2870e38111b7d4_913a9c3a02b86678)
  unreachable
bb28:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l22
  br label %bb29
bb29:
  %t41 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t41, ptr %l3
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t43, ptr %l24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t44)
  store i32 %t47, ptr %l27
  br label %bb30
bb30:
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t48, %"compiler/source:Span" %t49, i32 %t50)
  store i64 %t51, ptr %l28
  br label %bb31
bb31:
  %t52 = load i64, ptr %l28, !tbaa !24
  store i64 %t52, ptr %l4, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 48
  %t56 = load %"compiler/source:Span", ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  %t61 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t65 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t56, 0
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr } %t65, i32 %t59, 1
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr } %t67, ptr %t61, 2
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t55, ptr %t73)
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t76, %"compiler/source:Span" %t77, i64 %t78)
  store ptr %t82, ptr %l41
  br label %bb33
bb33:
  %t83 = load ptr, ptr %l41, !tbaa !29
  store ptr %t83, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrSubjectOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 65
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 64
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l13
  %t21 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l10, ptr %l13)
  store i1 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l18
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 65
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l18
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t32, %"compiler/source:Span" %t33, i64 %t31)
  store ptr %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l21, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l26, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorMethod(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"compiler/diagmsg:Msg"
  %l30 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l89 = alloca i1
  %l90 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l96 = alloca { i64, ptr }
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l14, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i32, ptr %l18, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t21 = icmp slt i32 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t24, ptr %t25)
  store %"compiler/source:Span" %t28, ptr %l24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l27
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t36 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %s1, ptr %v0, { i64, ptr } %t34)
  store %"compiler/diagmsg:Msg" %t36, ptr %l29
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l24
  %t39 = load %"compiler/diagmsg:Msg", ptr %l29
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38, %"compiler/diagmsg:Msg" %t39)
  store i64 %t40, ptr %l30
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l35
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l1, !tbaa !24
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l39
  br label %bb11
bb11:
  %t59 = load i64, ptr %l35, !tbaa !24
  %t60 = load i64, ptr %l39, !tbaa !24
  %t61 = icmp ne i64 %t59, %t60
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l45
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t73 = load i64, ptr %l45, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t79 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t75, ptr %t76)
  store %"compiler/source:Span" %t79, ptr %l49
  br label %bb15
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/load:Loader", ptr %t86, i32 0, i32 10
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t88, i64 %t89)
  store ptr %t92, ptr %l55
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l55, !tbaa !29
  %t95 = getelementptr %"compiler/load:Module", ptr %t93, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 12
  %t107 = load i64, ptr %t106, !tbaa !24
  %t110 = icmp eq i64 %t97, %t107
  %t113 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s2, { i64, ptr } %t96, i1 %t110)
  store { i64, ptr } %t113, ptr %l64
  br label %bb17
bb17:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l5, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l70
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l65, !tbaa !29
  %t126 = load i32, ptr %l70, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t125, i32 %t126)
  store { i64, ptr } %t127, ptr %l71
  br label %bb19
bb19:
  %t128 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t141 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %s2, ptr %v0, { i64, ptr } %t138)
  store %"compiler/diagmsg:Msg" %t141, ptr %l74
  br label %bb20
bb20:
  %t142 = load ptr, ptr %l46, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l49
  %t144 = load %"compiler/diagmsg:Msg", ptr %l74
  %t145 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t142, %"compiler/source:Span" %t143, %"compiler/diagmsg:Msg" %t144)
  store i64 %t145, ptr %l75
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t146 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t147 = insertvalue [8 x { i64, ptr }] %t146, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t148 = insertvalue [8 x { i64, ptr }] %t147, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, 2
  %t149 = insertvalue [8 x { i64, ptr }] %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 3
  %t150 = insertvalue [8 x { i64, ptr }] %t149, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, 4
  %t151 = insertvalue [8 x { i64, ptr }] %t150, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) }, 5
  %t152 = insertvalue [8 x { i64, ptr }] %t151, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 6
  %t153 = insertvalue [8 x { i64, ptr }] %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 7
  %t155 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 128, i64 8)
  store [8 x { i64, ptr }] %t153, ptr %t155
  store ptr %t155, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t157 = load ptr, ptr %l7
  store i64 8, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t161 = load i64, ptr %l9, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb24, label %bb25
bb24:
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t168 = load ptr, ptr %l7
  %t169 = load i64, ptr %l8, !tbaa !24
  %t172 = getelementptr [8 x { i64, ptr }], ptr %t168, i64 0, i64 %t169
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !37
  %t176 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t177 = load ptr, ptr @__olang_prog_scope
  %t180 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t177, ptr %v1, { i64, ptr } %t173, { i64, ptr } %t176)
  store i1 %t180, ptr %l89
  br label %bb27
bb27:
  %t181 = load i1, ptr %l89, !tbaa !21
  br i1 %t181, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l90, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l4, !tbaa !29
  %t187 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t183, ptr %t184)
  store %"compiler/source:Span" %t187, ptr %l93
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l96
  br label %bb31
bb31:
  %t193 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t197 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorMethodGiven(ptr %s6, ptr %v1, ptr %v0, { i64, ptr } %t193, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t197, ptr %l99
  br label %bb32
bb32:
  %t198 = load ptr, ptr %l90, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l93
  %t200 = load %"compiler/diagmsg:Msg", ptr %l99
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t198, %"compiler/source:Span" %t199, %"compiler/diagmsg:Msg" %t200)
  store i64 %t201, ptr %l100
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t202 = load i64, ptr %l8, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l8, !tbaa !24
  br label %bb23
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/typed:Block"
  %l35 = alloca %"compiler/typed:Item"
  %l37 = alloca %"compiler/typed:Item"
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Item"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/typed:Clause"
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l61 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca i64
  %t127 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d20, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 48
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 48
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t25 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t17, 0
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } %t25, i32 0, 1
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t20, 2
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t16, ptr %t33)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  store i32 %t44, ptr %l29, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 48
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l33
  br label %bb5
bb5:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t53, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t55, ptr %l34
  br label %bb6
bb6:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t56, ptr %lp6
  %t57 = load %"compiler/typed:Block", ptr %l34
  %t58 = load ptr, ptr %lp6
  store %"compiler/typed:Block" %t57, ptr %t58
  store %"compiler/typed:Item" zeroinitializer, ptr %l35
  %t59 = icmp sgt i64 1, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v2, i32 0, i64 0)
  store %"compiler/typed:Item" %t61, ptr %l37
  br label %bb9
bb8:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  %t64 = load %"compiler/typed:Item", ptr %l37
  store %"compiler/typed:Item" %t64, ptr %l35
  br label %bb8
bb10:
  %t65 = icmp sle i64 1, 576460752303423487
  br i1 %t65, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb12:
  %t67 = mul i64 1, 16
  %t68 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t67)
  %t69 = load %"compiler/typed:Item", ptr %l35
  store i64 0, ptr %t70
  br label %fill.71
fill.71:
  %t74 = load i64, ptr %t70
  %t75 = icmp slt i64 %t74, 1
  br i1 %t75, label %fillb.72, label %filld.73
fillb.72:
  %t76 = getelementptr %"compiler/typed:Item", ptr %t68, i64 %t74
  store %"compiler/typed:Item" %t69, ptr %t76
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %t70
  br label %fill.71
filld.73:
  %t78 = insertvalue { i64, ptr } undef, i64 1, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t68, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i32, ptr %l4, !tbaa !23
  %t84 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t82, i64 -1)
  store %"compiler/typed:Item" %t84, ptr %l43
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb14:
  %t85 = load %"compiler/typed:Item", ptr %l43
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/typed:Item", ptr %t87, i64 0
  store %"compiler/typed:Item" %t85, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l44
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load ptr, ptr %lp6
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb17:
  %t96 = mul i64 0, 8
  %t97 = insertvalue { i64, ptr } undef, i64 0, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t99 = load %"compiler/source:Span", ptr %l44
  %t100 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t103 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t99, { i64, ptr } %t100, i1 false, ptr %t101, { i64, ptr } %t98, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t103, ptr %l50
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb19:
  %t104 = load %"compiler/typed:Clause", ptr %l50
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/typed:Clause" %t104, ptr %t105
  %t107 = insertvalue [1 x ptr] undef, ptr %t105, 0
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t108, ptr %lp8
  %t110 = load ptr, ptr %lp8
  store [1 x ptr] %t107, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l53
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t115 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t112)
  store i32 %t115, ptr %l56
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = load ptr, ptr %lp8
  %t120 = insertvalue { i64, ptr } undef, i64 1, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t124 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v1, ptr %v2, ptr %v2, ptr %t116, { i64, ptr } %t121, i1 false, i1 true, i1 true)
  store %"compiler/typed:Try" %t124, ptr %l61
  br label %bb21
bb21:
  %t125 = load %"compiler/typed:Try", ptr %l61
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t125, ptr %t126
  store { i64, [5 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 0
  store i64 14, ptr %t128
  %t129 = load %"compiler/source:Span", ptr %l53
  %t130 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t129, 0
  %t131 = load i32, ptr %l56, !tbaa !23
  %t132 = insertvalue { %"compiler/source:Span", i32, ptr } %t130, i32 %t131, 1
  %t134 = insertvalue { %"compiler/source:Span", i32, ptr } %t132, ptr %t126, 2
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t134, ptr %t135
  %t136 = load { i64, [5 x i64] }, ptr %t127
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t136, ptr %t138
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l19 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/diagmsg:Msg"
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca i1
  %l108 = alloca i1
  %l110 = alloca i1
  %l119 = alloca i1
  %l126 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca i32
  %l137 = alloca i1
  %l141 = alloca i1
  %l145 = alloca i1
  %l147 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l154 = alloca i64
  %l156 = alloca ptr
  %l158 = alloca i64
  %l160 = alloca %"compiler/source:Span"
  %l161 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l166 = alloca %"compiler/check:idleCall"
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l171 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l185 = alloca ptr
  %l193 = alloca ptr
  %l196 = alloca i32
  %l199 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca %"compiler/diagmsg:Msg"
  %l204 = alloca i64
  %t101 = alloca { i64, [3 x i64] }, align 8
  %t337 = alloca { i64, [3 x i64] }, align 8
  %t371 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l21, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l22, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t18 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t16, %"compiler/source:Span" %t17, ptr %t18)
  br label %bb6
bb6:
  br label %ret
bb7:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t23 = load ptr, ptr %l30, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l30, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l31, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 116}
  store i32 %t35, ptr %l4
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t43 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t45 = trunc i64 93 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb15
bb14:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t50 = trunc i64 94 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l40, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t59 = trunc i64 93 to i32
  %t60 = icmp eq i32 %t57, %t59
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i1 %t60)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %ret
bb19:
  br label %bb106
bb20:
  %t65 = load ptr, ptr %l2, !tbaa !29
  store ptr %t65, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 28}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 116}
  store i32 %t78, ptr %l6
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t86 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t88 = trunc i64 97 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l59
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t93, ptr %t94, i32 %t96)
  store ptr %t100, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  store { i64, [3 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 0
  store i64 2, ptr %t102
  %t103 = load %"compiler/source:Span", ptr %l59
  %t104 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t103, 0
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t106 = insertvalue { %"compiler/source:Span", ptr } %t104, ptr %t105, 1
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t106, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t101
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t108, ptr %t110
  %t111 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t111, ptr %t110)
  br label %bb29
bb29:
  br label %ret
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l1
  %t115 = load ptr, ptr %l7, !tbaa !29
  %t116 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t118 = trunc i64 93 to i32
  %t119 = icmp eq i32 %t116, %t118
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t113, %"compiler/source:Span" %t114, ptr %t115, i1 %t119)
  br label %bb31
bb31:
  br label %ret
bb32:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t125 = load ptr, ptr %l72, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l72, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 28}
  %t131 = icmp eq i64 %t129, 10
  store i1 %t131, ptr %l73, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l73, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb93
bb37:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t133, ptr %t134, i32 %t136)
  store ptr %t140, ptr %l80
  br label %bb38
bb38:
  %t141 = load ptr, ptr %l80, !tbaa !29
  store ptr %t141, ptr %l8, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  store ptr %t142, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 9
  store i1 %t149, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154, !range !{i32 0, i32 54}
  store i32 %t155, ptr %l9
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t157 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t159 = trunc i64 24 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l89, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store %"compiler/source:Span" %t167, ptr %l92
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t168 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0)
  store %"compiler/diagmsg:Msg" %t168, ptr %l93
  br label %bb47
bb47:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l92
  %t171 = load %"compiler/diagmsg:Msg", ptr %l93
  %t172 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t169, %"compiler/source:Span" %t170, %"compiler/diagmsg:Msg" %t171)
  store i64 %t172, ptr %l94
  br label %bb48
bb48:
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_602058b5bbdc5ba4_407e96c83aaf1680)
  unreachable
bb54:
  %t173 = load ptr, ptr %l8, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t174 = load ptr, ptr %l95, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 18}
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t181 = load i1, ptr %l96, !tbaa !21
  br i1 %t181, label %bb57, label %bb58
bb57:
  %t182 = load ptr, ptr %l8, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 0
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l10
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t190, i32 0, i32 1
  %t192 = load i32, ptr %t191
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t196, i32 0, i32 2
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l12, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t200, i32 %t192)
  store i1 %t204, ptr %l108
  br label %bb59
bb58:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb60
bb59:
  %t205 = load i1, ptr %l108, !tbaa !21
  %t206 = xor i1 %t205, true
  store i1 %t206, ptr %l99, !tbaa !21
  br label %bb60
bb60:
  %t208 = load i1, ptr %l99, !tbaa !21
  br i1 %t208, label %bb61, label %bb62
bb61:
  %t209 = load ptr, ptr %l8, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l13
  %t215 = load ptr, ptr %l8, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t217, i32 0, i32 1
  %t219 = load i32, ptr %t218
  %t221 = load ptr, ptr %l8, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l15, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t231 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %t227, i32 %t219)
  store i1 %t231, ptr %l119
  br label %bb63
bb62:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb64
bb63:
  %t232 = load i1, ptr %l119, !tbaa !21
  store i1 %t232, ptr %l110, !tbaa !21
  br label %bb64
bb64:
  %t233 = load i1, ptr %l110, !tbaa !21
  br i1 %t233, label %bb65, label %bb66
bb65:
  %t234 = load ptr, ptr %l8, !tbaa !29
  %t236 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t236, i32 0, i32 0
  %t238 = load %"compiler/source:Span", ptr %t237
  store %"compiler/source:Span" %t238, ptr %l16
  %t240 = load ptr, ptr %l8, !tbaa !29
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t242, i32 0, i32 1
  %t244 = load i32, ptr %t243
  store i32 %t244, ptr %l17, !tbaa !23
  %t246 = load ptr, ptr %l8, !tbaa !29
  %t248 = getelementptr { i64, [5 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t248, i32 0, i32 2
  %t250 = load ptr, ptr %t249
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l126, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, ptr %t250, i64 -1)
  store ptr %t259, ptr %l130
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t260 = load ptr, ptr %l126, !tbaa !29
  %t261 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t260, ptr %t261)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t262 = load ptr, ptr %l8, !tbaa !29
  %t265 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t262)
  store i32 %t265, ptr %l133
  br label %bb70
bb70:
  %t266 = load i32, ptr %l133, !tbaa !23
  store i32 %t266, ptr %l19, !tbaa !23
  %t267 = load i32, ptr %l19, !tbaa !23
  %t268 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t271 = icmp ne i32 %t267, %t268
  br i1 %t271, label %bb71, label %bb72
bb71:
  %t273 = load i32, ptr %l19, !tbaa !23
  %t274 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t277 = icmp ne i32 %t273, %t274
  store i1 %t277, ptr %l137, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb73
bb73:
  %t279 = load i1, ptr %l137, !tbaa !21
  br i1 %t279, label %bb74, label %bb75
bb74:
  %t280 = load i32, ptr %l19, !tbaa !23
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = icmp ne i32 %t280, %t281
  store i1 %t284, ptr %l141, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb76
bb76:
  %t286 = load i1, ptr %l141, !tbaa !21
  br i1 %t286, label %bb77, label %bb78
bb77:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t287)
  store i1 %t289, ptr %l147
  br label %bb79
bb78:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb80
bb79:
  %t290 = load i1, ptr %l147, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l145, !tbaa !21
  br label %bb80
bb80:
  %t293 = load i1, ptr %l145, !tbaa !21
  br i1 %t293, label %bb81, label %bb82
bb81:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 131
  store ptr %t296, ptr %l150, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t297)
  store ptr %t299, ptr %l152
  br label %bb83
bb82:
  br label %bb90
bb83:
  %t300 = load ptr, ptr %l152, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  store i64 %t303, ptr %l154, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t304)
  store ptr %t306, ptr %l156
  br label %bb84
bb84:
  %t307 = load ptr, ptr %l156, !tbaa !29
  %t309 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 2
  %t310 = load i64, ptr %t309, !tbaa !24
  store i64 %t310, ptr %l158, !tbaa !24
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t313 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t311)
  store %"compiler/source:Span" %t313, ptr %l160
  br label %bb85
bb85:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l161, !tbaa !29
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t317 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t315)
  store %"compiler/source:Span" %t317, ptr %l163
  br label %bb86
bb86:
  %t318 = load ptr, ptr %l161, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l163
  %t320 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t318, %"compiler/source:Span" %t319)
  store { i64, ptr } %t320, ptr %l164
  br label %bb87
bb87:
  %t321 = load ptr, ptr %l8, !tbaa !29
  %t322 = load i64, ptr %l154, !tbaa !24
  %t323 = load i64, ptr %l158, !tbaa !24
  %t324 = load %"compiler/source:Span", ptr %l160
  %t325 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t327 = call %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t322, i64 %t323, %"compiler/source:Span" %t324, { i64, ptr } %t325, ptr %t321)
  store %"compiler/check:idleCall" %t327, ptr %l166
  br label %bb88
bb88:
  %t328 = load ptr, ptr %l150, !tbaa !29
  %t329 = load %"compiler/check:idleCall", ptr %l166
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ePush_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t328, %"compiler/check:idleCall" %t329)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l167, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t331, ptr %l168
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l8, !tbaa !29
  %t336 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArgs(ptr %v0, ptr %v0, ptr %v0, ptr %t332, ptr %t333)
  store ptr %t336, ptr %l171
  br label %bb91
bb91:
  store { i64, [3 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [3 x i64] }, ptr %t337, i32 0, i32 0
  store i64 2, ptr %t338
  %t339 = load %"compiler/source:Span", ptr %l168
  %t340 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t339, 0
  %t341 = load ptr, ptr %l171, !tbaa !29
  %t342 = insertvalue { %"compiler/source:Span", ptr } %t340, ptr %t341, 1
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t337, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t337
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t344, ptr %t346
  %t347 = load ptr, ptr %l167, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t347, ptr %t346)
  br label %bb92
bb92:
  br label %ret
bb93:
  %t349 = load ptr, ptr %l2, !tbaa !29
  store ptr %t349, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t350 = load ptr, ptr %l174, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb94, label %bb95
bb94:
  %t353 = load ptr, ptr %l174, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 28}
  %t356 = icmp eq i64 %t354, 19
  store i1 %t356, ptr %l175, !tbaa !21
  br label %bb95
bb95:
  %t357 = load i1, ptr %l175, !tbaa !21
  br i1 %t357, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb101
bb98:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 58
  store i1 true, ptr %t360, !tbaa !21
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l179, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t362, ptr %l180
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load ptr, ptr %l2, !tbaa !29
  %t366 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t363, ptr %t364, i32 %t366)
  store ptr %t370, ptr %l185
  br label %bb99
bb99:
  store { i64, [3 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t371, i32 0, i32 0
  store i64 2, ptr %t372
  %t373 = load %"compiler/source:Span", ptr %l180
  %t374 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t373, 0
  %t375 = load ptr, ptr %l185, !tbaa !29
  %t376 = insertvalue { %"compiler/source:Span", ptr } %t374, ptr %t375, 1
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t371, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t376, ptr %t377
  %t378 = load { i64, [3 x i64] }, ptr %t371
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t378, ptr %t380
  %t381 = load ptr, ptr %l179, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t381, ptr %t380)
  br label %bb100
bb100:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 58
  store i1 false, ptr %t385, !tbaa !21
  br label %ret
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_a929affe4386ca95_c275f1e9d349f711)
  unreachable
bb106:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l2, !tbaa !29
  %t389 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t386, ptr %t387, i32 %t389)
  store ptr %t393, ptr %l193
  br label %bb107
bb107:
  %t394 = load ptr, ptr %l193, !tbaa !29
  %t398 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t394)
  store i32 %t398, ptr %l196
  br label %bb108
bb108:
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t400 = load i32, ptr %l196, !tbaa !23
  %t402 = icmp eq i32 %t400, %t399
  br i1 %t402, label %bb109, label %bb110
bb109:
  br label %ret
bb110:
  br label %bb111
bb111:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l199, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t409 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %t405, ptr %t406)
  store %"compiler/source:Span" %t409, ptr %l202
  br label %bb112
bb112:
  %t410 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0)
  store %"compiler/diagmsg:Msg" %t410, ptr %l203
  br label %bb113
bb113:
  %t411 = load ptr, ptr %l199, !tbaa !29
  %t412 = load %"compiler/source:Span", ptr %l202
  %t413 = load %"compiler/diagmsg:Msg", ptr %l203
  %t414 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t411, %"compiler/source:Span" %t412, %"compiler/diagmsg:Msg" %t413)
  store i64 %t414, ptr %l204
  br label %bb114
bb114:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/generic:Desc"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l34 = alloca i64
  %l40 = alloca i64
  %l46 = alloca i32
  %l49 = alloca i1
  %l57 = alloca %"compiler/generic:Desc"
  %l61 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_dd139b797ad07c59_48ae02fb28d54045)
  unreachable
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i64 %t47, ptr %l28
  br label %bb20
bb20:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb21, label %bb22
bb21:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNamed(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store i64 %t59, ptr %l34
  br label %bb24
bb24:
  %t60 = load i64, ptr %l34, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sge i64 %t61, 0
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t65 = load i64, ptr %l5, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodNamed(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i64 %t71, ptr %l40
  br label %bb28
bb28:
  %t72 = load i64, ptr %l40, !tbaa !24
  store i64 %t72, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb29, label %bb30
bb29:
  %t77 = load i64, ptr %l5, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store i32 %t83, ptr %l46
  br label %bb32
bb32:
  %t84 = load i32, ptr %l46, !tbaa !23
  store i32 %t84, ptr %l6, !tbaa !23
  %t85 = load i32, ptr %l6, !tbaa !23
  %t87 = icmp slt i32 %t85, 0
  br i1 %t87, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  %t89 = load i32, ptr %l6, !tbaa !23
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t93 = icmp eq i32 %t89, %t90
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i32, ptr %l6, !tbaa !23
  %t104 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t100, i32 %t101)
  store %"compiler/generic:Desc" %t104, ptr %l57
  br label %bb39
bb39:
  %t105 = load %"compiler/generic:Desc", ptr %l57
  store %"compiler/generic:Desc" %t105, ptr %l7
  %t106 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb40, label %bb41
bb40:
  %t113 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l61, !tbaa !24
  br label %bb42
bb41:
  store i64 -1, ptr %l61, !tbaa !24
  br label %bb42
bb42:
  %t116 = load i64, ptr %l61, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp ne i64 %t7, %a2
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 28}
  %t34 = icmp eq i64 %t32, 12
  store i1 %t34, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l14, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb12
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l19, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l21
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l21
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s2, ptr %t46, %"compiler/source:Span" %t47)
  store { i64, ptr } %t48, ptr %l22
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l24, !tbaa !24
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l25, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t64 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t65, ptr %l27, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l28, !tbaa !24
  %t68 = load i64, ptr %l28, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l29, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l28, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t79, ptr %l27, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ce477a1e17d80ea_6907ddc3684fedfe)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"compiler/check:factsMark"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca %"compiler/check:factsMark"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t67 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %t1)
  store %"compiler/check:factsMark" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/check:factsMark", ptr %l10
  store %"compiler/check:factsMark" %t4, ptr %l5
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 48
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i64, ptr %l13, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  store ptr %a1, ptr %l15, !tbaa !29
  store i1 %a2, ptr %l16, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l18
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 7
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i1, ptr %l16, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i1 %t23, i64 %t20)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 48
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l23
  br label %bb5
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t33 = icmp sgt i64 %t31, %t30
  store i1 %t33, ptr %l7, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t35, ptr %t36, i32 %a4)
  store ptr %t42, ptr %l30
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l30, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load i1, ptr %l7, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l33
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t49 = load ptr, ptr %l8, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t49)
  store i32 %t52, ptr %l36
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 48
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store { i64, ptr } %t59, ptr %l40
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t62, ptr %t60, i1 false)
  store %"compiler/typed:Seq" %t64, ptr %l43
  br label %bb12
bb12:
  %t65 = load %"compiler/typed:Seq", ptr %l43
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t65, ptr %t66
  store { i64, [5 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 0
  store i64 12, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l33
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t69, 0
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, i32 %t71, 1
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr } %t72, ptr %t66, 2
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t74, ptr %t75
  %t76 = load { i64, [5 x i64] }, ptr %t67
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t76, ptr %t78
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb13
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/check:factsMark", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %t80, %"compiler/check:factsMark" %t81)
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l8, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsCopy" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:factsCopy"
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store %"compiler/check:factsCopy" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = call ptr @__olang_scope_hold(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e50
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = call ptr @__olang_region_make(ptr %v0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t12 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 0
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l9
  %t15 = load i64, ptr %l6
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l10, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l6
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_region_make_part(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  store i64 %t24, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t25 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l12, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l13, !tbaa !24
  %t30 = mul i64 %t29, 48
  %t31 = load i64, ptr %l10
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l14, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = mul i64 %t40, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t43 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  store { i64, ptr } %t42, ptr %t43, !tbaa !27
  %t44 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = icmp eq i64 %t48, 0
  br i1 %t50, label %bb8, label %bb9
bb7:
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e50
  br i1 %t52, label %bb10, label %bb11
bb8:
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t54, !tbaa !27
  br label %bb9
bb9:
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t56 = load i64, ptr %l10
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = load { i64, ptr }, ptr %t55
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t62)
  br label %bb7
bb10:
  %t63 = load i64, ptr %l6
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = call ptr @__olang_region_or(ptr %t67, ptr null)
  %t69 = call ptr @__olang_region_home(ptr %t68)
  %t70 = icmp ne ptr %t69, null
  %t71 = select i1 %t70, ptr %t69, ptr null
  call void @__olang_region_settle_in(ptr %t64, ptr %t71)
  br label %bb11
bb11:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 50
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l19
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t77
  %t78 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e50
  br i1 %t78, label %bb12, label %bb13
bb12:
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  call void @__olang_region_drop(ptr %t86)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l19
  br label %bb13
bb13:
  %t87 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0
  br i1 %t87, label %bb14, label %bb15
bb14:
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  call void @__olang_region_release_part(ptr %t92, i64 %t91)
  store { i64, ptr } zeroinitializer, ptr %t89
  br label %bb15
bb15:
  %t93 = load ptr, ptr %l2, !tbaa !29
  store ptr %t93, ptr %l22, !tbaa !29
  %t94 = call ptr @__olang_scope_hold(ptr %v0)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l23, !tbaa !24
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e46
  br i1 %t96, label %bb16, label %bb17
bb16:
  %t98 = call ptr @__olang_region_make(ptr %v0)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l23, !tbaa !24
  br label %bb17
bb17:
  %t100 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 1
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l26
  %t103 = load i64, ptr %l23
  %t104 = inttoptr i64 %t103 to ptr
  %t105 = call ptr @__olang_scope_hold(ptr %t104)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l27, !tbaa !24
  %t107 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0
  br i1 %t107, label %bb18, label %bb19
bb18:
  %t109 = load i64, ptr %l23
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_region_make_part(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l27, !tbaa !24
  br label %bb19
bb19:
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l29, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l30, !tbaa !24
  %t117 = load i64, ptr %l30, !tbaa !24
  %t118 = mul i64 %t117, 80
  %t119 = load i64, ptr %l27
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_held_alloc(ptr %t120, i64 %t118)
  %t122 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l31, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l30, !tbaa !24
  %t129 = mul i64 %t128, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t131 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  store { i64, ptr } %t130, ptr %t131, !tbaa !27
  %t132 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb22, label %bb23
bb21:
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e46
  br i1 %t140, label %bb24, label %bb25
bb22:
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t142, !tbaa !27
  br label %bb23
bb23:
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t144 = load i64, ptr %l27
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = load { i64, ptr }, ptr %t143
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = call ptr @__olang_region_or(ptr %t147, ptr null)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  call void @__olang_region_settle_in(ptr %t145, ptr %t150)
  br label %bb21
bb24:
  %t151 = load i64, ptr %l23
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = call ptr @__olang_region_or(ptr %t155, ptr null)
  %t157 = call ptr @__olang_region_home(ptr %t156)
  %t158 = icmp ne ptr %t157, null
  %t159 = select i1 %t158, ptr %t157, ptr null
  call void @__olang_region_settle_in(ptr %t152, ptr %t159)
  br label %bb25
bb25:
  %t160 = load ptr, ptr %l22, !tbaa !29
  %t161 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 46
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t161
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l36
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  %t164 = load ptr, ptr %l22, !tbaa !29
  %t165 = getelementptr %"compiler/check:frame", ptr %t164, i32 0, i32 46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %t165
  %t166 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e46
  br i1 %t166, label %bb26, label %bb27
bb26:
  %t168 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = call ptr @__olang_region_home(ptr %t171)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr null
  call void @__olang_region_drop(ptr %t174)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l36
  br label %bb27
bb27:
  %t175 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0
  br i1 %t175, label %bb28, label %bb29
bb28:
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  call void @__olang_region_release_part(ptr %t180, i64 %t179)
  store { i64, ptr } zeroinitializer, ptr %t177
  br label %bb29
bb29:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l39, !tbaa !29
  %t182 = call ptr @__olang_scope_hold(ptr %v0)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l40, !tbaa !24
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e62
  br i1 %t184, label %bb30, label %bb31
bb30:
  %t186 = call ptr @__olang_region_make(ptr %v0)
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l40, !tbaa !24
  br label %bb31
bb31:
  %t188 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 2
  %t189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t188
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %l43
  %t191 = load i64, ptr %l40
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call ptr @__olang_scope_hold(ptr %t192)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l44, !tbaa !24
  %t195 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0
  br i1 %t195, label %bb32, label %bb33
bb32:
  %t197 = load i64, ptr %l40
  %t198 = inttoptr i64 %t197 to ptr
  %t199 = call ptr @__olang_region_make_part(ptr %t198)
  %t200 = ptrtoint ptr %t199 to i64
  store i64 %t200, ptr %l44, !tbaa !24
  br label %bb33
bb33:
  %t201 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l46, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l47, !tbaa !24
  %t205 = load i64, ptr %l47, !tbaa !24
  %t206 = mul i64 %t205, 56
  %t207 = load i64, ptr %l44
  %t208 = inttoptr i64 %t207 to ptr
  %t209 = call ptr @__olang_held_alloc(ptr %t208, i64 %t206)
  %t210 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  store { i64, ptr } %t211, ptr %l48, !tbaa !27
  %t212 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = load i64, ptr %l47, !tbaa !24
  %t217 = mul i64 %t216, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t213, ptr %t215, i64 %t217, i1 false)
  %t218 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t219 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  store { i64, ptr } %t218, ptr %t219, !tbaa !27
  %t220 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0
  br i1 %t220, label %bb34, label %bb35
bb34:
  %t222 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t226 = icmp eq i64 %t224, 0
  br i1 %t226, label %bb36, label %bb37
bb35:
  %t228 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e62
  br i1 %t228, label %bb38, label %bb39
bb36:
  %t230 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t230, !tbaa !27
  br label %bb37
bb37:
  %t231 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t232 = load i64, ptr %l44
  %t233 = inttoptr i64 %t232 to ptr
  %t234 = load { i64, ptr }, ptr %t231
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = call ptr @__olang_region_or(ptr %t235, ptr null)
  %t237 = icmp ne ptr %t236, null
  %t238 = select i1 %t237, ptr %t236, ptr null
  call void @__olang_region_settle_in(ptr %t233, ptr %t238)
  br label %bb35
bb38:
  %t239 = load i64, ptr %l40
  %t240 = inttoptr i64 %t239 to ptr
  %t241 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t242 = load { i64, ptr }, ptr %t241
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = call ptr @__olang_region_or(ptr %t243, ptr null)
  %t245 = call ptr @__olang_region_home(ptr %t244)
  %t246 = icmp ne ptr %t245, null
  %t247 = select i1 %t246, ptr %t245, ptr null
  call void @__olang_region_settle_in(ptr %t240, ptr %t247)
  br label %bb39
bb39:
  %t248 = load ptr, ptr %l39, !tbaa !29
  %t249 = getelementptr %"compiler/check:frame", ptr %t248, i32 0, i32 62
  %t250 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t249
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %l53
  %t251 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t252 = load ptr, ptr %l39, !tbaa !29
  %t253 = getelementptr %"compiler/check:frame", ptr %t252, i32 0, i32 62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %t253
  %t254 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e62
  br i1 %t254, label %bb40, label %bb41
bb40:
  %t256 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = call ptr @__olang_region_or(ptr %t258, ptr null)
  %t260 = call ptr @__olang_region_home(ptr %t259)
  %t261 = icmp ne ptr %t260, null
  %t262 = select i1 %t261, ptr %t260, ptr null
  call void @__olang_region_drop(ptr %t262)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l53
  br label %bb41
bb41:
  %t263 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0
  br i1 %t263, label %bb42, label %bb43
bb42:
  %t265 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265
  %t267 = extractvalue { i64, ptr } %t266, 0
  %t268 = extractvalue { i64, ptr } %t266, 1
  call void @__olang_region_release_part(ptr %t268, i64 %t267)
  store { i64, ptr } zeroinitializer, ptr %t265
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnFact(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l10 = alloca %"compiler/check:factRead"
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca %"compiler/check:factRead"
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i1
  %l33 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca i32
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i32
  %l62 = alloca ptr
  %l64 = alloca %"compiler/effects:Facts"
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca i64
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/check:factRead"
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca ptr
  %l99 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l114 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l123 = alloca i1
  %l125 = alloca i64
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l140 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i64
  %l144 = alloca ptr
  %l148 = alloca i64
  %l152 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i32
  %l159 = alloca i1
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l162 = alloca i1
  %l164 = alloca ptr
  %l166 = alloca i64
  %l167 = alloca %"compiler/source:Span"
  %l168 = alloca i64
  %l172 = alloca { i64, ptr }
  %l175 = alloca %"compiler/check:factRead"
  %l179 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca i32
  %l184 = alloca i1
  %l185 = alloca i64
  %l186 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a4)
  store { i64, ptr } %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %t7)
  store i32 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i32, ptr %l22, !range !{i32 0, i32 11}
  store i32 %t10, ptr %l6
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = call i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %t11)
  store i1 %t13, ptr %l24
  br label %bb3
bb3:
  %t14 = load i1, ptr %l24, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  %t15 = load i32, ptr %l6, !range !{i32 0, i32 11}
  %t17 = trunc i64 10 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i1, ptr %l7, !tbaa !21
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l27, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l27, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l33
  br label %bb10
bb10:
  %t31 = load i64, ptr %l33, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t37 = load i1, ptr %l7, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l38, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t40, ptr %l39
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t41, ptr %l40, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v0, ptr %t42, i64 %t43, { i64, ptr } %t44)
  store i1 %t48, ptr %l44
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t49 = load i1, ptr %l44, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l45, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l38, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l39
  %t52 = load i32, ptr %l40, !tbaa !23
  %t53 = load i64, ptr %l45, !tbaa !24
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t50, %"compiler/source:Span" %t51, i32 %t52, i64 %t53)
  store ptr %t54, ptr %l46
  br label %bb20
bb20:
  %t55 = load ptr, ptr %l46, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t60, i64 %t61)
  store i1 %t64, ptr %l51
  br label %bb22
bb22:
  %t65 = load i1, ptr %l51, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 77
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t71 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t74 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t75 = add i64 %t72, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t70, 1
  %t81 = extractvalue { i64, ptr } %t70, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t71, i64 %t72)
  %t84 = getelementptr i8, ptr %t83, i64 %t72
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t69)
  %t86 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t86, ptr %t76, i64 %t77)
  %t87 = getelementptr i8, ptr %t86, i64 %t77
  call void @olang_textcopy(ptr %t87, ptr %t80, i64 %t81)
  %t88 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t83, 1
  %t93 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %s4, ptr %t68, { i64, ptr } %t89)
  %t94 = extractvalue { i32, i1 } %t93, 1
  %t95 = extractvalue { i32, i1 } %t93, 0
  store i32 %t95, ptr %l60
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb26, label %ok.97, !prof !99
ok.97:
  store i1 %t94, ptr %l59
  br label %bb25
bb24:
  br label %bb43
bb25:
  %t98 = load i1, ptr %l59, !tbaa !21
  store i1 %t98, ptr %l52, !tbaa !21
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t99)
  store ptr %t101, ptr %l62
  br label %bb28
bb28:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load ptr, ptr %l62, !tbaa !29
  %t105 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %t103, i64 %t102)
  store %"compiler/effects:Facts" %t105, ptr %l64
  br label %bb29
bb29:
  %t106 = load i32, ptr %l6, !range !{i32 0, i32 11}
  %t109 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s4, ptr %l64, i32 %t106)
  store i1 %t109, ptr %l67
  br label %bb30
bb30:
  %t110 = load i1, ptr %l67, !tbaa !21
  store i1 %t110, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t111 = load i1, ptr %l52, !tbaa !21
  %t112 = load i64, ptr %l8, !tbaa !24
  store i64 %t112, ptr %l68, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t113, ptr %l69, !tbaa !27
  store i1 %t111, ptr %l70, !tbaa !21
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t115)
  store ptr %t117, ptr %l72
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l72, !tbaa !29
  %t120 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l74, !tbaa !24
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l75
  %t123 = call ptr @__olang_scope_hold(ptr %v0)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l76, !tbaa !24
  %t125 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactRead_2e6
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = call ptr @__olang_region_make(ptr %v0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l76, !tbaa !24
  br label %bb34
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  %t133 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s4, ptr %t129, %"compiler/source:Span" %t130)
  store { i64, ptr } %t133, ptr %l80
  br label %bb35
bb35:
  %t134 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = load i64, ptr %l76
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call ptr @__olang_held_alloc(ptr %t138, i64 %t136)
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = load i64, ptr %l68, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t145 = load i1, ptr %l70, !tbaa !21
  %t146 = load i64, ptr %l74, !tbaa !24
  %t147 = load %"compiler/source:Span", ptr %l75
  %t149 = call %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v0, ptr %v0, i64 -1, i64 %t143, { i64, ptr } %t144, i1 %t145, i64 %t146, %"compiler/source:Span" %t147, { i64, ptr } %t141)
  store %"compiler/check:factRead" %t149, ptr %l83
  br label %bb36
bb36:
  %t150 = load %"compiler/check:factRead", ptr %l83
  store %"compiler/check:factRead" %t150, ptr %l10
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 76
  %t154 = load %"compiler/check:factRead", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t153, %"compiler/check:factRead" %t154)
  br label %bb37
bb37:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l87, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t158, ptr %l88
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t159, ptr %l89, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t163 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v0, ptr %t160, ptr %l10)
  store i1 %t163, ptr %l92
  br label %bb38
bb38:
  %t164 = load i1, ptr %l92, !tbaa !21
  br i1 %t164, label %bb39, label %bb40
bb39:
  store i64 1, ptr %l93, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb41
bb41:
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l88
  %t167 = load i32, ptr %l89, !tbaa !23
  %t168 = load i64, ptr %l93, !tbaa !24
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t165, %"compiler/source:Span" %t166, i32 %t167, i64 %t168)
  store ptr %t169, ptr %l94
  br label %bb42
bb42:
  %t170 = load ptr, ptr %l94, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t170, ptr %rv
  br label %ret
bb43:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load i64, ptr %l8, !tbaa !24
  %t178 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %t172, ptr %t173, i64 %t174)
  store i64 %t178, ptr %l99
  br label %bb44
bb44:
  %t179 = load i64, ptr %l99, !tbaa !24
  store i64 %t179, ptr %l11, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l102, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t189 = load i64, ptr %l8, !tbaa !24
  %t192 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s7, ptr %t188, i64 %t189)
  store ptr %t192, ptr %l106
  br label %bb47
bb46:
  br label %bb71
bb47:
  %t193 = load ptr, ptr %l106, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 2
  %t196 = load i32, ptr %t195, !tbaa !23
  %t197 = load ptr, ptr %l102, !tbaa !29
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t197, i32 %t196)
  store { i64, ptr } %t199, ptr %l109
  br label %bb48
bb48:
  %t200 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t200, ptr %l12, !tbaa !27
  %t201 = call ptr @__olang_scope_hold(ptr %s7)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l110, !tbaa !24
  %t203 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = call ptr @__olang_region_make(ptr %s7)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l110, !tbaa !24
  br label %bb50
bb50:
  %t207 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t207, 1
  %t211 = extractvalue { i64, ptr } %t207, 0
  %t212 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t216 = extractvalue { i64, ptr } %t208, 1
  %t217 = extractvalue { i64, ptr } %t208, 0
  %t218 = add i64 %t214, %t217
  %t219 = load i64, ptr %l110
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = call ptr @__olang_held_alloc(ptr %t220, i64 %t218)
  call void @olang_textcopy(ptr %t221, ptr %t210, i64 %t211)
  %t222 = getelementptr i8, ptr %t221, i64 %t211
  call void @olang_textcopy(ptr %t222, ptr %t212, i64 %t213)
  %t223 = getelementptr i8, ptr %t222, i64 %t213
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t221, 1
  store { i64, ptr } %t225, ptr %l114, !tbaa !27
  %t226 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13
  br i1 %t226, label %bb51, label %bb52
bb51:
  %t228 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t231 = icmp eq i64 %t229, 0
  br i1 %t231, label %bb53, label %bb54
bb52:
  %t233 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t233, ptr %l13, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l3, !tbaa !29
  %t236 = load i64, ptr %l8, !tbaa !24
  %t240 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactOwner(ptr %v0, ptr %v1, ptr %s7, ptr %t234, ptr %t235, i64 %t236)
  store { i64, ptr } %t240, ptr %l121
  br label %bb55
bb53:
  store { i64, ptr } zeroinitializer, ptr %l114, !tbaa !27
  br label %bb54
bb54:
  %t241 = load i64, ptr %l110
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = load { i64, ptr }, ptr %l114
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = call ptr @__olang_region_or(ptr %t244, ptr null)
  %t246 = icmp ne ptr %t245, null
  %t247 = select i1 %t246, ptr %t245, ptr null
  call void @__olang_region_settle_in(ptr %t242, ptr %t247)
  br label %bb52
bb55:
  %t248 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t248, ptr %l14, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t251, ptr %l123
  br label %bb56
bb56:
  %t252 = load i1, ptr %l123, !tbaa !21
  %t253 = xor i1 %t252, true
  br i1 %t253, label %bb57, label %bb58
bb57:
  %t255 = call ptr @__olang_scope_hold(ptr %s7)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l125, !tbaa !24
  %t257 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13
  br i1 %t257, label %bb59, label %bb60
bb58:
  br label %bb67
bb59:
  %t259 = call ptr @__olang_region_make(ptr %s7)
  %t260 = ptrtoint ptr %t259 to i64
  store i64 %t260, ptr %l125, !tbaa !24
  br label %bb60
bb60:
  %t261 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t261, 1
  %t266 = extractvalue { i64, ptr } %t261, 0
  %t267 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t262, 1
  %t272 = extractvalue { i64, ptr } %t262, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = extractvalue { i64, ptr } %t263, 1
  %t279 = extractvalue { i64, ptr } %t263, 0
  %t280 = add i64 %t276, %t279
  %t281 = load i64, ptr %l125
  %t282 = inttoptr i64 %t281 to ptr
  %t283 = call ptr @__olang_held_alloc(ptr %t282, i64 %t280)
  call void @olang_textcopy(ptr %t283, ptr %t265, i64 %t266)
  %t284 = getelementptr i8, ptr %t283, i64 %t266
  call void @olang_textcopy(ptr %t284, ptr %t267, i64 %t268)
  %t285 = getelementptr i8, ptr %t284, i64 %t268
  call void @olang_textcopy(ptr %t285, ptr %t271, i64 %t272)
  %t286 = getelementptr i8, ptr %t285, i64 %t272
  call void @olang_textcopy(ptr %t286, ptr %t274, i64 %t275)
  %t287 = getelementptr i8, ptr %t286, i64 %t275
  call void @olang_textcopy(ptr %t287, ptr %t278, i64 %t279)
  %t288 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t283, 1
  store { i64, ptr } %t289, ptr %l130, !tbaa !27
  %t290 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13
  br i1 %t290, label %bb61, label %bb62
bb61:
  %t292 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  %t295 = icmp eq i64 %t293, 0
  br i1 %t295, label %bb63, label %bb64
bb62:
  %t297 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t297, ptr %l134, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t298, ptr %l13, !tbaa !27
  %t299 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13
  br i1 %t299, label %bb65, label %bb66
bb63:
  store { i64, ptr } zeroinitializer, ptr %l130, !tbaa !27
  br label %bb64
bb64:
  %t301 = load i64, ptr %l125
  %t302 = inttoptr i64 %t301 to ptr
  %t303 = load { i64, ptr }, ptr %l130
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = call ptr @__olang_region_or(ptr %t304, ptr null)
  %t306 = icmp ne ptr %t305, null
  %t307 = select i1 %t306, ptr %t305, ptr null
  call void @__olang_region_settle_in(ptr %t302, ptr %t307)
  br label %bb62
bb65:
  %t308 = load { i64, ptr }, ptr %l134
  %t309 = extractvalue { i64, ptr } %t308, 1
  call void @__olang_region_release(ptr %t309)
  store { i64, ptr } zeroinitializer, ptr %l134
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l136, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l137
  %t312 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t316 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %s7, ptr %v0, { i64, ptr } %t312, { i64, ptr } %t313)
  store %"compiler/diagmsg:Msg" %t316, ptr %l140
  br label %bb68
bb68:
  %t317 = load ptr, ptr %l136, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l137
  %t319 = load %"compiler/diagmsg:Msg", ptr %l140
  %t320 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t317, %"compiler/source:Span" %t318, %"compiler/diagmsg:Msg" %t319)
  store i64 %t320, ptr %l141
  br label %bb69
bb69:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t321, %"compiler/source:Span" %t322)
  store ptr %t325, ptr %l144
  br label %bb70
bb70:
  %t326 = load ptr, ptr %l144, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t326, ptr %rv
  br label %ret
bb71:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i64, ptr %l11, !tbaa !24
  %t332 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t328, i64 %t329)
  store i64 %t332, ptr %l148
  br label %bb72
bb72:
  %t333 = load i64, ptr %l11, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t336 = call i64 @__olang_fmt_i64(ptr null, i64 %t333)
  %t337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t339 = add i64 %t336, %t338
  %t341 = extractvalue { i64, ptr } %t334, 1
  %t342 = extractvalue { i64, ptr } %t334, 0
  %t343 = add i64 %t339, %t342
  %t344 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t343)
  %t345 = call i64 @__olang_fmt_i64(ptr %t344, i64 %t333)
  %t346 = getelementptr i8, ptr %t344, i64 %t336
  call void @olang_textcopy(ptr %t346, ptr %t337, i64 %t338)
  %t347 = getelementptr i8, ptr %t346, i64 %t338
  call void @olang_textcopy(ptr %t347, ptr %t341, i64 %t342)
  %t348 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t344, 1
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 77
  %t357 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %s0, ptr %t353, { i64, ptr } %t349)
  %t358 = extractvalue { i32, i1 } %t357, 1
  %t359 = extractvalue { i32, i1 } %t357, 0
  store i32 %t359, ptr %l157
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb74, label %ok.361, !prof !99
ok.361:
  store i1 %t358, ptr %l156
  br label %bb73
bb73:
  %t362 = load i1, ptr %l156, !tbaa !21
  store i1 %t362, ptr %l152, !tbaa !21
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t363 = load i32, ptr %l6, !range !{i32 0, i32 11}
  %t365 = call i1 @compiler_2feffects_2eConservative(i32 %t363)
  store i1 %t365, ptr %l159
  br label %bb76
bb76:
  %t366 = load i1, ptr %l159, !tbaa !21
  store i1 %t366, ptr %l152, !tbaa !21
  br label %bb77
bb77:
  %t367 = load i1, ptr %l152, !tbaa !21
  %t368 = load i64, ptr %l11, !tbaa !24
  store i64 %t368, ptr %l160, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t369, ptr %l161, !tbaa !27
  store i1 %t367, ptr %l162, !tbaa !21
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t371)
  store ptr %t373, ptr %l164
  br label %bb78
bb78:
  %t374 = load ptr, ptr %l164, !tbaa !29
  %t376 = getelementptr %"compiler/check:frame", ptr %t374, i32 0, i32 2
  %t377 = load i64, ptr %t376, !tbaa !24
  store i64 %t377, ptr %l166, !tbaa !24
  %t378 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t378, ptr %l167
  %t379 = call ptr @__olang_scope_hold(ptr %v0)
  %t380 = ptrtoint ptr %t379 to i64
  store i64 %t380, ptr %l168, !tbaa !24
  %t381 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactRead_2e6
  br i1 %t381, label %bb79, label %bb80
bb79:
  %t383 = call ptr @__olang_region_make(ptr %v0)
  %t384 = ptrtoint ptr %t383 to i64
  store i64 %t384, ptr %l168, !tbaa !24
  br label %bb80
bb80:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l1
  %t389 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t385, %"compiler/source:Span" %t386)
  store { i64, ptr } %t389, ptr %l172
  br label %bb81
bb81:
  %t390 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = load i64, ptr %l168
  %t394 = inttoptr i64 %t393 to ptr
  %t395 = call ptr @__olang_held_alloc(ptr %t394, i64 %t392)
  call void @olang_textcopy(ptr %t395, ptr %t391, i64 %t392)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t399 = load i64, ptr %l160, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t401 = load i1, ptr %l162, !tbaa !21
  %t402 = load i64, ptr %l166, !tbaa !24
  %t403 = load %"compiler/source:Span", ptr %l167
  %t405 = call %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t399, i64 -1, { i64, ptr } %t400, i1 %t401, i64 %t402, %"compiler/source:Span" %t403, { i64, ptr } %t397)
  store %"compiler/check:factRead" %t405, ptr %l175
  br label %bb82
bb82:
  %t406 = load %"compiler/check:factRead", ptr %l175
  store %"compiler/check:factRead" %t406, ptr %l17
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 76
  %t410 = load %"compiler/check:factRead", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t409, %"compiler/check:factRead" %t410)
  br label %bb83
bb83:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l179, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t414, ptr %l180
  %t415 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t415, ptr %l181, !tbaa !23
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t419 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v0, ptr %t416, ptr %l17)
  store i1 %t419, ptr %l184
  br label %bb84
bb84:
  %t420 = load i1, ptr %l184, !tbaa !21
  br i1 %t420, label %bb85, label %bb86
bb85:
  store i64 1, ptr %l185, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb87
bb87:
  %t421 = load ptr, ptr %l179, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l180
  %t423 = load i32, ptr %l181, !tbaa !23
  %t424 = load i64, ptr %l185, !tbaa !24
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t421, %"compiler/source:Span" %t422, i32 %t423, i64 %t424)
  store ptr %t425, ptr %l186
  br label %bb88
bb88:
  %t426 = load ptr, ptr %l186, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t426, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t29 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t26, ptr %t23, ptr %t24)
  store i32 %t29, ptr %l16
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = load i32, ptr %l16, !tbaa !23
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l17
  br label %bb8
bb8:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = load i32, ptr %l17, !tbaa !23
  %t36 = icmp ne i32 %t34, %t33
  store i1 %t36, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9cda55992b6a58cc_f4ed715c72ea34c8)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenByValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, [3 x i64] }
  %l29 = alloca i32
  %l34 = alloca i64
  %l36 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, [3 x i64] }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca { i64, [3 x i64] }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %t47 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l9
  %t7 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t5, %"compiler/source:Span" %t6)
  store { i64, ptr } %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 115
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l20
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t30, ptr %t27, ptr %t28)
  store i32 %t33, ptr %l25
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb5
bb5:
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = sext i32 %t37 to i64
  %t39 = load ptr, ptr %l13, !tbaa !29
  %t41 = call { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %t39, i64 %t38)
  %t42 = extractvalue { i32, { i64, [3 x i64] } } %t41, 1
  %t43 = extractvalue { i32, { i64, [3 x i64] } } %t41, 0
  store i32 %t43, ptr %l29
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb7, label %ok.45, !prof !99
ok.45:
  store { i64, [3 x i64] } %t42, ptr %l28
  br label %bb6
bb6:
  %t46 = load { i64, [3 x i64] }, ptr %l28
  store { i64, [3 x i64] } %t46, ptr %l11
  br label %bb9
bb7:
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [3 x i64] }, ptr %t47
  store { i64, [3 x i64] } %t49, ptr %l11
  br label %bb9
bb9:
  %t51 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t51, ptr %l4
  %t52 = load { i64, [3 x i64] }, ptr %l4
  %t54 = extractvalue { i64, [3 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 3
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t57 = getelementptr { i64, [3 x i64] }, ptr %l4, i32 0, i32 1
  %t58 = getelementptr { i64, i64, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t62)
  store ptr %t64, ptr %l36
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l34, !tbaa !24
  %t71 = icmp ne i64 %t69, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/load:Loader", ptr %t79, i32 0, i32 4
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l43, !tbaa !29
  %t83 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t83, ptr %l44
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValueAway(ptr %v0, ptr %v0, { i64, ptr } %t84)
  store %"compiler/diagmsg:Msg" %t86, ptr %l46
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t87 = load ptr, ptr %l43, !tbaa !29
  %t88 = load { i64, [3 x i64] }, ptr %l44
  %t89 = load %"compiler/diagmsg:Msg", ptr %l46
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t87, { i64, [3 x i64] } %t88, %"compiler/diagmsg:Msg" %t89)
  store i64 %t90, ptr %l47
  br label %bb17
bb17:
  %t91 = load i64, ptr %l47, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l51, !tbaa !29
  store i64 %t91, ptr %l52, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l2
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l55
  br label %bb18
bb18:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenSlot(ptr %v0, ptr %v0, { i64, ptr } %t108)
  store %"compiler/diagmsg:Msg" %t110, ptr %l57
  br label %bb19
bb19:
  %t111 = load ptr, ptr %l51, !tbaa !29
  %t112 = load i64, ptr %l52, !tbaa !24
  %t113 = load { i64, [3 x i64] }, ptr %l55
  %t114 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t111, i64 %t112, { i64, [3 x i64] } %t113, %"compiler/diagmsg:Msg" %t114)
  br label %bb20
bb20:
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_15eb6f7c806fc73b_bac9f6515206ea7f)
  unreachable
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l58, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t116, ptr %l59
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValue(ptr %v0, ptr %v0, { i64, ptr } %t117)
  store %"compiler/diagmsg:Msg" %t119, ptr %l61
  br label %bb27
bb27:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l59
  %t122 = load %"compiler/diagmsg:Msg", ptr %l61
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t120, %"compiler/source:Span" %t121, %"compiler/diagmsg:Msg" %t122)
  store i64 %t123, ptr %l62
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i32
  %l19 = alloca i64
  %l24 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/typed:Block"
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l73 = alloca i32
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l88 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l112 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t130 = alloca { i64, [1 x i64] }, align 8
  %t153 = alloca { i64, [3 x i64] }, align 8
  %t203 = alloca { i64, [3 x i64] }, align 8
  %t245 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 0
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l4
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 48
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load i64, ptr %l19, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t17, i32 %a2)
  store i32 %t21, ptr %l24
  br label %bb2
bb2:
  %t22 = load i32, ptr %l24, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l6, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l28
  br label %bb3
bb3:
  %t31 = load i32, ptr %l28, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l40
  br label %bb6
bb6:
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = load i32, ptr %l40, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l41
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp ne i64 %t58, 1
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t63, %"compiler/source:Span" %t64, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 48
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t75 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t74)
  store %"compiler/typed:Block" %t75, ptr %l50
  br label %bb13
bb13:
  %t76 = load %"compiler/typed:Block", ptr %l50
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t76, ptr %t77
  call void @__olang_scope_close(ptr %s0)
  store ptr %t77, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l54, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l7, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l59
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load i32, ptr %l59, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l60
  br label %bb16
bb16:
  %t98 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 0
  %t102 = load i32, ptr %t101, !tbaa !33
  store i32 %t102, ptr %l8, !tbaa !23
  store i64 -1, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenFromReturn, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb17, label %bb18
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l6, !tbaa !23
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t121 = or i64 %t117, %t118
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t115, i32 %t116, i64 %t121)
  store i32 %t125, ptr %l73
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t126 = load i32, ptr %l73, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l4
  %t129 = load i32, ptr %l10, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [1 x i64] }, ptr %t130, i32 0, i32 0
  store i64 3, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %t130
  %t138 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t127, i32 0, %"compiler/source:Span" %t128, i32 %t129, i32 3, { i64, [1 x i64] } %t132)
  store i64 %t138, ptr %l79
  br label %bb20
bb20:
  %t139 = load i64, ptr %l79, !tbaa !24
  store i64 %t139, ptr %l9, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l80, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l81
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = trunc i64 %t142 to i32
  store i32 %t144, ptr %l84, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l4
  %t148 = load i32, ptr %l10, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t146, %"compiler/source:Span" %t147, i32 %t148, i64 0)
  store ptr %t152, ptr %l88
  br label %bb21
bb21:
  store { i64, [3 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t155 = load %"compiler/source:Span", ptr %l81
  %t156 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t155, 0
  %t157 = load i32, ptr %l84, !tbaa !23
  %t158 = insertvalue { %"compiler/source:Span", i32, ptr } %t156, i32 %t157, 1
  %t159 = load ptr, ptr %l88, !tbaa !29
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } %t158, ptr %t159, 2
  %t161 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t160, ptr %t161
  %t162 = load { i64, [3 x i64] }, ptr %t153
  %t164 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t162, ptr %t164
  %t165 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t165, ptr %t164)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t170 = load i64, ptr %l3, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %t167, ptr %t168, i32 %t169, i64 %t170, i64 %t171)
  store ptr %t177, ptr %l96
  br label %bb24
bb24:
  %t178 = load ptr, ptr %l96, !tbaa !29
  store ptr %t178, ptr %l11, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l6, !tbaa !23
  %t183 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t179, i32 %t180)
  store i64 %t183, ptr %l99
  br label %bb25
bb25:
  %t184 = load i64, ptr %l99, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 29
  %t188 = load i32, ptr %t187, !tbaa !23
  store i32 %t188, ptr %l13, !tbaa !23
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l6, !tbaa !23
  %t194 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 29
  store i32 %t191, ptr %t194, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l104, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t196, ptr %l105
  %t197 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t197, ptr %l106
  %t198 = load i32, ptr %l7, !tbaa !23
  store i32 %t198, ptr %l107, !tbaa !23
  %t201 = trunc i64 %t184 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 0
  store i64 0, ptr %t204
  %t206 = insertvalue { i32 } undef, i32 %t201, 0
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  store { i32 } %t206, ptr %t207
  %t208 = load { i64, [3 x i64] }, ptr %t203
  %t210 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t208, ptr %t210
  store ptr %t210, ptr %l112, !tbaa !29
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb26, label %bb27
bb26:
  %t213 = icmp sle i64 0, 1152921504606846975
  br i1 %t213, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb28:
  %t215 = mul i64 0, 8
  %t216 = insertvalue { i64, ptr } undef, i64 0, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t219 = mul i64 1, 8
  %t220 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 1, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l117, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 0
  store ptr %t218, ptr %t226, !tbaa !39
  %t227 = load ptr, ptr %l104, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l105
  %t229 = load %"compiler/source:Span", ptr %l106
  %t230 = load i32, ptr %l107, !tbaa !23
  %t231 = load ptr, ptr %l112, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t227, %"compiler/source:Span" %t228, %"compiler/source:Span" %t229, i32 %t230, ptr %t231, i64 -1, ptr null, { i64, ptr } %t217, { i64, ptr } %t233)
  store ptr %t234, ptr %l118
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb30:
  %t235 = load ptr, ptr %l118, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l13, !tbaa !23
  %t240 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 29
  store i32 %t237, ptr %t240, !tbaa !23
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l4
  store { i64, [3 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 0
  store i64 6, ptr %t246
  %t248 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t242, 0
  %t250 = insertvalue { %"compiler/source:Span", ptr } %t248, ptr %t235, 1
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t250, ptr %t251
  %t252 = load { i64, [3 x i64] }, ptr %t245
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t252, ptr %t254
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t241, ptr %t254)
  br label %bb31
bb31:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 48
  %t260 = load i64, ptr %l5, !tbaa !24
  %t263 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store { i64, ptr } %t263, ptr %l130
  br label %bb32
bb32:
  %t264 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t265 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t264)
  store %"compiler/typed:Block" %t265, ptr %l131
  br label %bb33
bb33:
  %t266 = load %"compiler/typed:Block", ptr %l131
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t266, ptr %t267
  call void @__olang_scope_close(ptr %s0)
  store ptr %t267, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejudgeSlot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i64
  %l25 = alloca %"compiler/effects:Verdict"
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca %"compiler/effects:Facts"
  %l37 = alloca i1
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca %"compiler/effects:Verdict"
  %l44 = alloca %"compiler/effects:Verdict"
  %l47 = alloca i64
  %l48 = alloca %"compiler/effects:Verdict"
  %l50 = alloca %"compiler/effects:Verdict"
  %l68 = alloca ptr
  %l69 = alloca { i64, [3 x i64] }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i64
  %l101 = alloca { i64, [3 x i64] }
  %l103 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t226 = alloca { i64, [3 x i64] }, align 8
  %t324 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/generic:AnySlot", ptr %t7, i32 0, i32 5
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t6, i32 %t10)
  store i64 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i64, ptr @G_2ecompiler_2feffects_2eEffectWords, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t17 = and i64 %t15, %t14
  store i64 %t17, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb3:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  store i1 %t25, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = call ptr @__olang_scope_hold(ptr %v0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = call ptr @__olang_region_make(ptr %v0)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l23
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %t36)
  store %"compiler/effects:Verdict" %t37, ptr %l25
  br label %bb10
bb10:
  %t38 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load i64, ptr %l23
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = getelementptr %"compiler/effects:Verdict", ptr %l25, i32 0, i32 7
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  %t49 = getelementptr %"compiler/effects:Verdict", ptr %l25, i32 0, i32 4
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr %t48
  %t56 = getelementptr %"compiler/effects:Verdict", ptr %l25, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr %t55
  %t63 = getelementptr %"compiler/effects:Verdict", ptr %l25, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  call void @__olang_region_settle_in(ptr %t41, ptr %t69)
  br label %bb12
bb12:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store ptr %t70, ptr %lp5
  %t71 = load %"compiler/effects:Verdict", ptr %l25
  %t72 = load ptr, ptr %lp5
  store %"compiler/effects:Verdict" %t71, ptr %t72
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t73)
  store ptr %t75, ptr %l28
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l28, !tbaa !29
  store ptr %t76, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  store ptr %t77, ptr %l29, !tbaa !29
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t79 = load i64, ptr %l3, !tbaa !24
  %t82 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/effects:Facts" %t82, ptr %l32
  br label %bb14
bb14:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t84 = load ptr, ptr %lp5
  %t85 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eJudgeFacts(ptr %v0, ptr %s0, ptr %v0, ptr %t85, ptr %l32, i64 %t83, ptr %t84)
  br label %bb15
bb15:
  %t89 = load ptr, ptr %lp5
  %t90 = getelementptr %"compiler/effects:Verdict", ptr %t89, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t93, ptr %l37
  br label %bb16
bb16:
  %t94 = load i1, ptr %l37, !tbaa !21
  br i1 %t94, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t96 = call ptr @__olang_scope_hold(ptr %v0)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l39, !tbaa !24
  %t98 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t100 = call ptr @__olang_region_make(ptr %v0)
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l39, !tbaa !24
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l6, !tbaa !29
  store ptr %t102, ptr %l41, !tbaa !29
  %t103 = load ptr, ptr %lp5
  %t104 = load %"compiler/effects:Verdict", ptr %t103
  store %"compiler/effects:Verdict" %t104, ptr %l42
  %t106 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %s0, ptr %l42)
  store %"compiler/effects:Verdict" %t106, ptr %l44
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eFirstCallee(ptr %v0, ptr %t107, i64 %t108)
  store i64 %t111, ptr %l47
  br label %bb23
bb23:
  %t112 = load i64, ptr %l39
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = load ptr, ptr %l41, !tbaa !29
  %t115 = load %"compiler/effects:Verdict", ptr %l44
  %t116 = load i64, ptr %l47, !tbaa !24
  %t117 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eBlame(ptr %v0, ptr %s0, ptr %s0, ptr %t113, ptr %t114, %"compiler/effects:Verdict" %t115, i64 %t116, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store %"compiler/effects:Verdict" %t117, ptr %l48
  br label %bb24
bb24:
  %t118 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5
  br i1 %t118, label %bb25, label %bb26
bb25:
  %t120 = load i64, ptr %l39
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = getelementptr %"compiler/effects:Verdict", ptr %l48, i32 0, i32 7
  %t123 = load { i64, ptr }, ptr %t122
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr null)
  %t126 = call ptr @__olang_region_home(ptr %t125)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr null
  %t129 = getelementptr %"compiler/effects:Verdict", ptr %l48, i32 0, i32 4
  %t130 = load { i64, ptr }, ptr %t129
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = call ptr @__olang_region_home(ptr %t132)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr %t128
  %t136 = getelementptr %"compiler/effects:Verdict", ptr %l48, i32 0, i32 1
  %t137 = load { i64, ptr }, ptr %t136
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = call ptr @__olang_region_or(ptr %t138, ptr null)
  %t140 = call ptr @__olang_region_home(ptr %t139)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr %t135
  %t143 = getelementptr %"compiler/effects:Verdict", ptr %l48, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr null)
  %t147 = call ptr @__olang_region_home(ptr %t146)
  %t148 = icmp ne ptr %t147, null
  %t149 = select i1 %t148, ptr %t147, ptr %t142
  call void @__olang_region_settle_in(ptr %t121, ptr %t149)
  br label %bb26
bb26:
  %t150 = load ptr, ptr %lp5
  %t151 = load %"compiler/effects:Verdict", ptr %t150
  store %"compiler/effects:Verdict" %t151, ptr %l50
  %t152 = load %"compiler/effects:Verdict", ptr %l48
  %t153 = load ptr, ptr %lp5
  store %"compiler/effects:Verdict" %t152, ptr %t153
  %t154 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5
  br i1 %t154, label %bb27, label %bb28
bb27:
  %t156 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 7
  %t157 = load { i64, ptr }, ptr %t156
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = call ptr @__olang_region_or(ptr %t158, ptr null)
  %t160 = call ptr @__olang_region_home(ptr %t159)
  %t161 = icmp ne ptr %t160, null
  %t162 = select i1 %t161, ptr %t160, ptr null
  %t163 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 4
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = call ptr @__olang_region_or(ptr %t165, ptr null)
  %t167 = call ptr @__olang_region_home(ptr %t166)
  %t168 = icmp ne ptr %t167, null
  %t169 = select i1 %t168, ptr %t167, ptr %t162
  %t170 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = call ptr @__olang_region_or(ptr %t172, ptr null)
  %t174 = call ptr @__olang_region_home(ptr %t173)
  %t175 = icmp ne ptr %t174, null
  %t176 = select i1 %t175, ptr %t174, ptr %t169
  %t177 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = call ptr @__olang_region_or(ptr %t179, ptr null)
  %t181 = call ptr @__olang_region_home(ptr %t180)
  %t182 = icmp ne ptr %t181, null
  %t183 = select i1 %t182, ptr %t181, ptr %t176
  call void @__olang_region_drop(ptr %t183)
  store %"compiler/effects:Verdict" zeroinitializer, ptr %l50
  br label %bb28
bb28:
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t184, label %bb29, label %bb30
bb29:
  %t186 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  call void @__olang_region_release_part(ptr %t189, i64 %t188)
  store { i64, ptr } zeroinitializer, ptr %t186
  br label %bb30
bb30:
  %t190 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t190, label %bb31, label %bb32
bb31:
  %t192 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  call void @__olang_region_release_part(ptr %t195, i64 %t194)
  store { i64, ptr } zeroinitializer, ptr %t192
  br label %bb32
bb32:
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t196, label %bb33, label %bb34
bb33:
  %t198 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 4
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %t198
  br label %bb34
bb34:
  %t202 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = getelementptr %"compiler/effects:Verdict", ptr %l50, i32 0, i32 7
  %t205 = load { i64, ptr }, ptr %t204
  %t206 = extractvalue { i64, ptr } %t205, 0
  %t207 = extractvalue { i64, ptr } %t205, 1
  call void @__olang_region_release_part(ptr %t207, i64 %t206)
  store { i64, ptr } zeroinitializer, ptr %t204
  br label %bb36
bb36:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/generic:AnyTable", ptr %t208, i32 0, i32 3
  %t211 = load i64, ptr %t210, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/generic:AnyTable", ptr %t212, i32 0, i32 4
  %t215 = getelementptr %"compiler/source:Span", ptr %t214, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = sext i32 %t216 to i64
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/generic:AnyTable", ptr %t219, i32 0, i32 4
  %t222 = getelementptr %"compiler/source:Span", ptr %t221, i32 0, i32 1
  %t223 = load i32, ptr %t222, !tbaa !23
  %t225 = sext i32 %t223 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 0
  store i64 3, ptr %t227
  %t229 = insertvalue { i64, i64, i64 } undef, i64 %t211, 0
  %t231 = insertvalue { i64, i64, i64 } %t229, i64 %t218, 1
  %t233 = insertvalue { i64, i64, i64 } %t231, i64 %t225, 2
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  store { i64, i64, i64 } %t233, ptr %t234
  %t235 = load { i64, [3 x i64] }, ptr %t226
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 4
  %t246 = load ptr, ptr %t245, !tbaa !29
  store ptr %t246, ptr %l68, !tbaa !29
  store { i64, [3 x i64] } %t235, ptr %l69
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = getelementptr %"compiler/generic:AnyTable", ptr %t249, i32 0, i32 0
  %t252 = load i32, ptr %t251, !tbaa !23
  %t255 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t248, i32 %t252)
  store { i64, ptr } %t255, ptr %l73
  br label %bb37
bb37:
  %t256 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t256, ptr %l74, !tbaa !27
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  %t260 = getelementptr %"compiler/generic:AnySlot", ptr %t258, i32 0, i32 0
  %t261 = load i32, ptr %t260, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t257, i32 %t261)
  store { i64, ptr } %t264, ptr %l78
  br label %bb38
bb38:
  %t265 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t265, ptr %l79, !tbaa !27
  %t266 = load ptr, ptr %lp5
  %t267 = getelementptr %"compiler/effects:Verdict", ptr %t266, i32 0, i32 1
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l80, !tbaa !27
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr %"compiler/generic:AnyTable", ptr %t270, i32 0, i32 1
  %t273 = load i32, ptr %t272, !tbaa !23
  %t276 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t269, i32 %t273)
  store { i64, ptr } %t276, ptr %l84
  br label %bb39
bb39:
  %t277 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t278 = load ptr, ptr %lp5
  %t279 = getelementptr %"compiler/effects:Verdict", ptr %t278, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t286 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMethodEffect(ptr %s0, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t281, { i64, ptr } %t282, { i64, ptr } %t283, { i64, ptr } %t277, { i64, ptr } %t280)
  store %"compiler/diagmsg:Msg" %t286, ptr %l87
  br label %bb40
bb40:
  %t287 = load ptr, ptr %l68, !tbaa !29
  %t288 = load { i64, [3 x i64] }, ptr %l69
  %t289 = load %"compiler/diagmsg:Msg", ptr %l87
  %t290 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t287, { i64, [3 x i64] } %t288, %"compiler/diagmsg:Msg" %t289)
  store i64 %t290, ptr %l88
  br label %bb41
bb41:
  %t291 = load i64, ptr %l88, !tbaa !24
  store i64 %t291, ptr %l8, !tbaa !24
  %t292 = load ptr, ptr %lp5
  %t293 = getelementptr %"compiler/effects:Verdict", ptr %t292, i32 0, i32 5
  %t294 = load i64, ptr %t293, !tbaa !24
  %t296 = icmp sge i64 %t294, 0
  br i1 %t296, label %bb42, label %bb43
bb42:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 0
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/load:Loader", ptr %t304, i32 0, i32 4
  %t307 = load ptr, ptr %t306, !tbaa !29
  store ptr %t307, ptr %l94, !tbaa !29
  %t308 = load i64, ptr %l8, !tbaa !24
  store i64 %t308, ptr %l95, !tbaa !24
  %t309 = load ptr, ptr %lp5
  %t310 = getelementptr %"compiler/effects:Verdict", ptr %t309, i32 0, i32 5
  %t311 = load i64, ptr %t310, !tbaa !24
  %t312 = load ptr, ptr %lp5
  %t313 = getelementptr %"compiler/effects:Verdict", ptr %t312, i32 0, i32 6
  %t314 = getelementptr %"compiler/source:Span", ptr %t313, i32 0, i32 0
  %t315 = load i32, ptr %t314, !tbaa !23
  %t317 = sext i32 %t315 to i64
  %t318 = load ptr, ptr %lp5
  %t319 = getelementptr %"compiler/effects:Verdict", ptr %t318, i32 0, i32 6
  %t320 = getelementptr %"compiler/source:Span", ptr %t319, i32 0, i32 1
  %t321 = load i32, ptr %t320, !tbaa !23
  %t323 = sext i32 %t321 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t324
  %t325 = getelementptr { i64, [3 x i64] }, ptr %t324, i32 0, i32 0
  store i64 3, ptr %t325
  %t327 = insertvalue { i64, i64, i64 } undef, i64 %t311, 0
  %t329 = insertvalue { i64, i64, i64 } %t327, i64 %t317, 1
  %t331 = insertvalue { i64, i64, i64 } %t329, i64 %t323, 2
  %t332 = getelementptr { i64, [3 x i64] }, ptr %t324, i32 0, i32 1
  store { i64, i64, i64 } %t331, ptr %t332
  %t333 = load { i64, [3 x i64] }, ptr %t324
  store { i64, [3 x i64] } %t333, ptr %l101
  %t334 = load ptr, ptr %lp5
  %t335 = getelementptr %"compiler/effects:Verdict", ptr %t334, i32 0, i32 7
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t338 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteEffect(ptr %v0, ptr %v0, { i64, ptr } %t336)
  store %"compiler/diagmsg:Msg" %t338, ptr %l103
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t339 = load ptr, ptr %l94, !tbaa !29
  %t340 = load i64, ptr %l95, !tbaa !24
  %t341 = load { i64, [3 x i64] }, ptr %l101
  %t342 = load %"compiler/diagmsg:Msg", ptr %l103
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t339, i64 %t340, { i64, [3 x i64] } %t341, %"compiler/diagmsg:Msg" %t342)
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %a1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l4, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l17
  store { i64, ptr } %a3, ptr %l18, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l21
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t31 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v2, ptr %s0, ptr %v0, { i64, ptr } %t29, { i64, ptr } %t28)
  store %"compiler/diagmsg:Msg" %t31, ptr %l23
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l17
  %t34 = load %"compiler/diagmsg:Msg", ptr %l23
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t32, %"compiler/source:Span" %t33, %"compiler/diagmsg:Msg" %t34)
  store i64 %t35, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDot(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/check:laneNode"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %lp13 = alloca ptr
  %l18 = alloca %"compiler/check:laneNode"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i32
  %l76 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l81 = alloca i32
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca %"compiler/typed:Cond"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t125 = alloca { i64, [5 x i64] }, align 8
  %t179 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 51
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a2)
  store %"compiler/check:laneNode" %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l18
  store %"compiler/check:laneNode" %t8, ptr %l6
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l20
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l22
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l20
  %t16 = load i32, ptr %l22, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l23
  br label %bb3
bb3:
  %t18 = load i64, ptr %l23, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l24, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l25
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l28, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l29, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l30
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l32
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l30
  %t32 = load i32, ptr %l32, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l33
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l25
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l33, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 47
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l38
  br label %bb7
bb7:
  %t53 = load i64, ptr %l38, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t54 = getelementptr %"compiler/check:laneNode", ptr %l6, i32 0, i32 4
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = getelementptr %"compiler/check:laneNode", ptr %l6, i32 0, i32 5
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = insertvalue [2 x i64] undef, i64 %t55, 0
  %t61 = insertvalue [2 x i64] %t59, i64 %t57, 1
  %t63 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store [2 x i64] %t61, ptr %t63
  store ptr %t63, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t65 = load ptr, ptr %l9
  store i64 2, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l9
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = getelementptr [2 x i64], ptr %t76, i64 0, i64 %t77
  %t81 = load i64, ptr %t80, !tbaa !34
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 47
  store ptr %t85, ptr %l53, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l55
  store i64 %t81, ptr %l56, !tbaa !24
  store ptr %a3, ptr %l57, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l1
  %t92 = load i64, ptr %l7, !tbaa !24
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t90, %"compiler/source:Span" %t91, i64 %t92)
  store ptr %t96, ptr %l61
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l55
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = load ptr, ptr %l57, !tbaa !29
  %t101 = load ptr, ptr %l61, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAt(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t97, %"compiler/source:Span" %t98, i64 %t99, ptr %t100, ptr %t101)
  store ptr %t102, ptr %l62
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t103, ptr %t104)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l10, !tbaa !24
  br label %bb8
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 47
  %t113 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t112, ptr %t113)
  br label %bb17
bb17:
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l69
  %t117 = load i32, ptr %l4, !tbaa !23
  store i32 %t117, ptr %l70, !tbaa !23
  store i32 40, ptr %l71
  store i32 0, ptr %l72
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 47
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t120, i64 %t121)
  store { i64, ptr } %t124, ptr %l76
  br label %bb18
bb18:
  store { i64, [5 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 0
  store i64 9, ptr %t126
  %t127 = load %"compiler/source:Span", ptr %l69
  %t128 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t127, 0
  %t129 = load i32, ptr %l70, !tbaa !23
  %t130 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t128, i32 %t129, 1
  %t131 = load i32, ptr %l71, !range !{i32 0, i32 54}
  %t132 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t130, i32 %t131, 2
  %t133 = load i32, ptr %l72, !range !{i32 0, i32 4}
  %t134 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t132, i32 %t133, 3
  %t135 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t136 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t134, { i64, ptr } %t135, 4
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t136, ptr %t137
  %t138 = load { i64, [5 x i64] }, ptr %t125
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t139, ptr %lp13
  %t141 = load ptr, ptr %lp13
  store { i64, [5 x i64] } %t138, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l78, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t143, ptr %l79
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t144, ptr %l80, !tbaa !23
  store i32 15, ptr %l81
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l7, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l85
  br label %bb19
bb19:
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l79
  %t156 = load i32, ptr %l80, !tbaa !23
  %t157 = load i32, ptr %l81, !range !{i32 0, i32 54}
  %t158 = load ptr, ptr %l85, !tbaa !29
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t154, %"compiler/source:Span" %t155, i32 %t156, i32 %t157, ptr %t158, ptr %t152)
  store ptr %t160, ptr %l88
  br label %bb20
bb20:
  %t161 = load ptr, ptr %l88, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t162, ptr %l89
  %t163 = load i32, ptr %l4, !tbaa !23
  store i32 %t163, ptr %l90, !tbaa !23
  store ptr %t161, ptr %l91, !tbaa !29
  %t165 = load ptr, ptr %lp13
  store ptr %t165, ptr %l92, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t168 = load i32, ptr %l4, !tbaa !23
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i32 %t168)
  store ptr %t172, ptr %l96
  br label %bb21
bb21:
  %t173 = load ptr, ptr %l91, !tbaa !29
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load ptr, ptr %l96, !tbaa !29
  %t176 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v0, ptr %v3, ptr %t173, ptr %t174, ptr %t175)
  store %"compiler/typed:Cond" %t176, ptr %l97
  br label %bb22
bb22:
  %t177 = load %"compiler/typed:Cond", ptr %l97
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t177, ptr %t178
  store { i64, [5 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 0
  store i64 11, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load i32, ptr %l90, !tbaa !23
  %t184 = insertvalue { %"compiler/source:Span", i32, ptr } %t182, i32 %t183, 1
  %t186 = insertvalue { %"compiler/source:Span", i32, ptr } %t184, ptr %t178, 2
  %t187 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t186, ptr %t187
  %t188 = load { i64, [5 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t188, ptr %t190
  store ptr %t190, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/check:laneNode"
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l47 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca %"compiler/typed:Cond"
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i32
  %l83 = alloca ptr
  %l86 = alloca %"compiler/typed:Elem"
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l96 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i32
  %l104 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l114 = alloca ptr
  %l116 = alloca ptr
  %l125 = alloca ptr
  %l131 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l151 = alloca ptr
  %l157 = alloca ptr
  %l163 = alloca ptr
  %l168 = alloca i1
  %l172 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca i32
  %l184 = alloca ptr
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca %"compiler/typed:Cond"
  %l205 = alloca ptr
  %l211 = alloca ptr
  %l214 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l221 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca %"compiler/source:Span"
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l234 = alloca i1
  %l238 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l243 = alloca ptr
  %l245 = alloca ptr
  %l249 = alloca ptr
  %l250 = alloca %"compiler/typed:Cond"
  %l254 = alloca %"compiler/source:Span"
  %l255 = alloca i32
  %l256 = alloca ptr
  %l260 = alloca ptr
  %l263 = alloca %"compiler/typed:Cond"
  %l267 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca ptr
  %l278 = alloca ptr
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t61 = alloca { i64, [4 x i64] }, align 8
  %t122 = alloca { i64, [5 x i64] }, align 8
  %t156 = alloca { i64, [4 x i64] }, align 8
  %t427 = alloca { i64, [5 x i64] }, align 8
  %t563 = alloca { i64, [5 x i64] }, align 8
  %t598 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 51
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v3, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 96, i64 8)
  store ptr %t8, ptr %lp5
  %t9 = load %"compiler/check:laneNode", ptr %l22
  %t10 = load ptr, ptr %lp5
  store %"compiler/check:laneNode" %t9, ptr %t10
  %t11 = load ptr, ptr %lp5
  %t12 = getelementptr %"compiler/check:laneNode", ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:laneVals", ptr %t19, i32 0, i32 3
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t21, i64 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l31
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l30
  br label %bb4
bb3:
  br label %bb29
bb4:
  %t30 = load i64, ptr %l30, !tbaa !24
  store i64 %t30, ptr %l26, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t36, %"compiler/source:Span" %t37)
  store ptr %t40, ptr %l36
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t41 = load ptr, ptr %l36, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l39
  br label %bb12
bb12:
  %t47 = load i32, ptr %l39, !tbaa !23
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l40
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t47)
  store i32 %t53, ptr %l43
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t54, %"compiler/source:Span" %t55, i64 %t56)
  store ptr %t60, ptr %l47
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l40
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t63, 0
  %t65 = load i32, ptr %l43, !tbaa !23
  %t66 = insertvalue { %"compiler/source:Span", i32, ptr } %t64, i32 %t65, 1
  %t67 = load ptr, ptr %l47, !tbaa !29
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } %t66, ptr %t67, 2
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t68, ptr %t69
  %t70 = load { i64, [4 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t70, ptr %t72
  store ptr %t72, ptr %l8, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:laneVals", ptr %t74, i32 0, i32 4
  %t77 = load i64, ptr %l2, !tbaa !24
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t76, i64 %t77)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l55
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb16, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l54
  br label %bb15
bb15:
  %t85 = load i64, ptr %l54, !tbaa !24
  store i64 %t85, ptr %l50, !tbaa !24
  br label %bb18
bb16:
  br label %bb17
bb17:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l50, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l4, !tbaa !29
  store ptr %t87, ptr %l10, !tbaa !29
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l59
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t94)
  store i32 %t96, ptr %l61
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t99 = load i64, ptr %l9, !tbaa !24
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t97, %"compiler/source:Span" %t98, i64 %t99)
  store ptr %t103, ptr %l65
  br label %bb22
bb22:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t108 = getelementptr %"compiler/check:laneVals", ptr %t106, i32 0, i32 2
  %t109 = load i64, ptr %t108, !tbaa !24
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t104, %"compiler/source:Span" %t105, i64 %t109)
  store ptr %t113, ptr %l70
  br label %bb23
bb23:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t116 = load ptr, ptr %l65, !tbaa !29
  %t119 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v2, ptr %v3, ptr %t116, ptr %t114, ptr %t115)
  store %"compiler/typed:Cond" %t119, ptr %l73
  br label %bb24
bb24:
  %t120 = load %"compiler/typed:Cond", ptr %l73
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t120, ptr %t121
  store { i64, [5 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 0
  store i64 11, ptr %t123
  %t124 = load %"compiler/source:Span", ptr %l59
  %t125 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t124, 0
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = insertvalue { %"compiler/source:Span", i32, ptr } %t125, i32 %t126, 1
  %t129 = insertvalue { %"compiler/source:Span", i32, ptr } %t127, ptr %t121, 2
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t129, ptr %t130
  %t131 = load { i64, [5 x i64] }, ptr %t122
  %t133 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t131, ptr %t133
  store ptr %t133, ptr %l10, !tbaa !29
  br label %bb25
bb25:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l77, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l79
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l80
  %t139 = load ptr, ptr %lp5
  %t140 = getelementptr %"compiler/check:laneNode", ptr %t139, i32 0, i32 8
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l81, !tbaa !23
  %t142 = load ptr, ptr %l8, !tbaa !29
  %t143 = load ptr, ptr %l10, !tbaa !29
  store ptr %t143, ptr %l83, !tbaa !29
  %t144 = load ptr, ptr %l83, !tbaa !29
  %t145 = call ptr @__olang_scope_of(ptr %t144, ptr null)
  %t146 = call ptr @__olang_scope_hold(ptr %t145)
  %t147 = ptrtoint ptr %t146 to i64
  %t149 = inttoptr i64 %t147 to ptr
  %t151 = load ptr, ptr %l83, !tbaa !29
  %t153 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v3, ptr %t149, ptr %v3, ptr %t142, ptr %t151, i32 0)
  store %"compiler/typed:Elem" %t153, ptr %l86
  br label %bb26
bb26:
  %t154 = load %"compiler/typed:Elem", ptr %l86
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Elem" %t154, ptr %t155
  store { i64, [4 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 0
  store i64 4, ptr %t157
  %t158 = load %"compiler/source:Span", ptr %l80
  %t159 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t158, 0
  %t160 = load i32, ptr %l81, !tbaa !23
  %t161 = insertvalue { %"compiler/source:Span", i32, ptr } %t159, i32 %t160, 1
  %t163 = insertvalue { %"compiler/source:Span", i32, ptr } %t161, ptr %t155, 2
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t156
  %t167 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t165, ptr %t167
  %t168 = load ptr, ptr %l78, !tbaa !29
  %t169 = load %"compiler/source:Span", ptr %l79
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t168, %"compiler/source:Span" %t169, ptr %t167)
  store ptr %t171, ptr %l90
  br label %bb27
bb27:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t173 = load ptr, ptr %l77, !tbaa !29
  %t174 = load ptr, ptr %l90, !tbaa !29
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWiden(ptr %v0, ptr %v3, ptr %v1, ptr %v3, ptr %t173, ptr %t174, ptr %t172)
  store ptr %t176, ptr %l92
  br label %bb28
bb28:
  %t177 = load ptr, ptr %l92, !tbaa !29
  store ptr %t177, ptr %rv
  br label %ret
bb29:
  %t178 = load ptr, ptr %lp5
  %t179 = getelementptr %"compiler/check:laneNode", ptr %t178, i32 0, i32 0
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t184 = icmp eq i64 %t180, %t181
  br i1 %t184, label %bb30, label %bb31
bb30:
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t188 = getelementptr %"compiler/check:laneVals", ptr %t186, i32 0, i32 3
  %t189 = load i64, ptr %l2, !tbaa !24
  %t192 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t188, i64 %t189)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l101
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb33, label %ok.196, !prof !99
ok.196:
  store i64 %t193, ptr %l100
  br label %bb32
bb31:
  br label %bb45
bb32:
  %t197 = load i64, ptr %l100, !tbaa !24
  store i64 %t197, ptr %l96, !tbaa !24
  br label %bb35
bb33:
  br label %bb34
bb34:
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb35
bb35:
  %t198 = load i64, ptr %l96, !tbaa !24
  store i64 %t198, ptr %l11, !tbaa !24
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = icmp slt i64 %t199, 0
  br i1 %t201, label %bb36, label %bb37
bb36:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l104, !tbaa !29
  %t204 = load ptr, ptr %lp5
  %t205 = getelementptr %"compiler/check:laneNode", ptr %t204, i32 0, i32 7
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  br i1 %t208, label %bb38, label %bb39
bb37:
  br label %bb42
bb38:
  call void @__olang_check_failed(ptr @olang_loc_24a46e21631caff9_33b011dc8e05d16d)
  unreachable
bb39:
  br label %bb40
bb40:
  %t210 = load ptr, ptr %lp5
  %t211 = getelementptr %"compiler/check:laneNode", ptr %t210, i32 0, i32 7
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load ptr, ptr %l3, !tbaa !29
  %t214 = load ptr, ptr %l104, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWiden(ptr %v0, ptr %v3, ptr %v1, ptr %v3, ptr %t214, ptr %t212, ptr %t213)
  store ptr %t217, ptr %l109
  br label %bb41
bb41:
  %t218 = load ptr, ptr %l109, !tbaa !29
  store ptr %t218, ptr %rv
  br label %ret
bb42:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l110, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %lp5
  %t222 = getelementptr %"compiler/check:laneNode", ptr %t221, i32 0, i32 2
  %t223 = load %"compiler/source:Span", ptr %t222
  %t224 = load i64, ptr %l11, !tbaa !24
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t220, %"compiler/source:Span" %t223, i64 %t224)
  store ptr %t228, ptr %l114
  br label %bb43
bb43:
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t230 = load ptr, ptr %l110, !tbaa !29
  %t231 = load ptr, ptr %l114, !tbaa !29
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWiden(ptr %v0, ptr %v3, ptr %v1, ptr %v3, ptr %t230, ptr %t231, ptr %t229)
  store ptr %t233, ptr %l116
  br label %bb44
bb44:
  %t234 = load ptr, ptr %l116, !tbaa !29
  store ptr %t234, ptr %rv
  br label %ret
bb45:
  %t235 = load ptr, ptr %lp5
  %t236 = getelementptr %"compiler/check:laneNode", ptr %t235, i32 0, i32 0
  %t237 = load i64, ptr %t236, !tbaa !24
  %t238 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  %t241 = icmp eq i64 %t237, %t238
  br i1 %t241, label %bb46, label %bb47
bb46:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load ptr, ptr %lp5
  %t246 = getelementptr %"compiler/check:laneNode", ptr %t245, i32 0, i32 4
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = load ptr, ptr %l3, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t243, %"compiler/source:Span" %t244, i64 %t247, ptr %t248, ptr %t249)
  store ptr %t255, ptr %l125
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t256 = load ptr, ptr %l125, !tbaa !29
  store ptr %t256, ptr %l12, !tbaa !29
  %t257 = load ptr, ptr %lp5
  %t258 = getelementptr %"compiler/check:laneNode", ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258, !range !{i32 0, i32 116}
  %t261 = trunc i64 48 to i32
  %t262 = icmp eq i32 %t259, %t261
  br i1 %t262, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l12, !tbaa !29
  %t266 = load ptr, ptr %lp5
  %t267 = getelementptr %"compiler/check:laneNode", ptr %t266, i32 0, i32 2
  %t268 = load %"compiler/source:Span", ptr %t267
  %t272 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s7, ptr %t264, ptr %t265, %"compiler/source:Span" %t268, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t272, ptr %l131
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %lp5
  %t275 = getelementptr %"compiler/check:laneNode", ptr %t274, i32 0, i32 2
  %t276 = load %"compiler/source:Span", ptr %t275
  %t277 = load ptr, ptr %l12, !tbaa !29
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t273, %"compiler/source:Span" %t276, ptr %t277)
  store ptr %t281, ptr %l135
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  %t282 = load ptr, ptr %l135, !tbaa !29
  store ptr %t282, ptr %rv
  br label %ret
bb53:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l136, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %lp5
  %t286 = getelementptr %"compiler/check:laneNode", ptr %t285, i32 0, i32 2
  %t287 = load %"compiler/source:Span", ptr %t286
  %t288 = load ptr, ptr %lp5
  %t289 = getelementptr %"compiler/check:laneNode", ptr %t288, i32 0, i32 1
  %t290 = load i32, ptr %t289, !range !{i32 0, i32 116}
  %t291 = load ptr, ptr %l12, !tbaa !29
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v3, ptr %v0, ptr %t284, %"compiler/source:Span" %t287, i32 %t290, ptr %t291)
  store ptr %t296, ptr %l141
  br label %bb54
bb54:
  %t297 = load ptr, ptr %l136, !tbaa !29
  %t298 = load ptr, ptr %l141, !tbaa !29
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v0, ptr %v3, ptr %t297, ptr %t298)
  store ptr %t299, ptr %l142
  br label %bb55
bb55:
  %t300 = load ptr, ptr %l142, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb56:
  %t301 = load ptr, ptr %lp5
  %t302 = getelementptr %"compiler/check:laneNode", ptr %t301, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t304 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  %t307 = icmp eq i64 %t303, %t304
  br i1 %t307, label %bb57, label %bb58
bb57:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load ptr, ptr %lp5
  %t312 = getelementptr %"compiler/check:laneNode", ptr %t311, i32 0, i32 4
  %t313 = load i64, ptr %t312, !tbaa !24
  %t314 = load ptr, ptr %l3, !tbaa !29
  %t315 = load ptr, ptr %l4, !tbaa !29
  %t321 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t309, %"compiler/source:Span" %t310, i64 %t313, ptr %t314, ptr %t315)
  store ptr %t321, ptr %l151
  br label %bb59
bb58:
  br label %bb75
bb59:
  %t322 = load ptr, ptr %l151, !tbaa !29
  store ptr %t322, ptr %l13, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load ptr, ptr %lp5
  %t326 = getelementptr %"compiler/check:laneNode", ptr %t325, i32 0, i32 5
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load ptr, ptr %l3, !tbaa !29
  %t329 = load ptr, ptr %l4, !tbaa !29
  %t335 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t323, %"compiler/source:Span" %t324, i64 %t327, ptr %t328, ptr %t329)
  store ptr %t335, ptr %l157
  br label %bb60
bb60:
  %t336 = load ptr, ptr %l157, !tbaa !29
  store ptr %t336, ptr %l14, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  %t339 = load ptr, ptr %lp5
  %t340 = getelementptr %"compiler/check:laneNode", ptr %t339, i32 0, i32 6
  %t341 = load i64, ptr %t340, !tbaa !24
  %t342 = load ptr, ptr %l3, !tbaa !29
  %t343 = load ptr, ptr %l4, !tbaa !29
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t337, %"compiler/source:Span" %t338, i64 %t341, ptr %t342, ptr %t343)
  store ptr %t349, ptr %l163
  br label %bb61
bb61:
  %t350 = load ptr, ptr %l163, !tbaa !29
  store ptr %t350, ptr %l15, !tbaa !29
  %t351 = load ptr, ptr %l3, !tbaa !29
  %t353 = getelementptr %"compiler/check:laneVals", ptr %t351, i32 0, i32 1
  %t354 = load i32, ptr %t353, !tbaa !23
  %t355 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t358 = icmp ne i32 %t354, %t355
  br i1 %t358, label %bb62, label %bb63
bb62:
  %t360 = load ptr, ptr %lp5
  %t361 = getelementptr %"compiler/check:laneNode", ptr %t360, i32 0, i32 8
  %t362 = load i32, ptr %t361, !tbaa !23
  %t363 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t366 = icmp ne i32 %t362, %t363
  store i1 %t366, ptr %l168, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb64
bb64:
  %t368 = load i1, ptr %l168, !tbaa !21
  br i1 %t368, label %bb65, label %bb66
bb65:
  %t369 = load ptr, ptr %l3, !tbaa !29
  %t371 = getelementptr %"compiler/check:laneVals", ptr %t369, i32 0, i32 1
  %t372 = load i32, ptr %t371, !tbaa !23
  store i32 %t372, ptr %l172, !tbaa !23
  br label %bb67
bb66:
  %t374 = load ptr, ptr %lp5
  %t375 = getelementptr %"compiler/check:laneNode", ptr %t374, i32 0, i32 8
  %t376 = load i32, ptr %t375, !tbaa !23
  store i32 %t376, ptr %l172, !tbaa !23
  br label %bb67
bb67:
  %t378 = load i32, ptr %l172, !tbaa !23
  store i32 %t378, ptr %l16, !tbaa !23
  %t379 = load i32, ptr %l16, !tbaa !23
  %t380 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t383 = icmp eq i32 %t379, %t380
  br i1 %t383, label %bb68, label %bb69
bb68:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %lp5
  %t387 = getelementptr %"compiler/check:laneNode", ptr %t386, i32 0, i32 2
  %t388 = load %"compiler/source:Span", ptr %t387
  %t391 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t385, %"compiler/source:Span" %t388)
  store ptr %t391, ptr %l181
  br label %bb70
bb69:
  br label %bb71
bb70:
  %t392 = load ptr, ptr %l181, !tbaa !29
  store ptr %t392, ptr %rv
  br label %ret
bb71:
  %t393 = load ptr, ptr %lp5
  %t394 = getelementptr %"compiler/check:laneNode", ptr %t393, i32 0, i32 2
  %t395 = load %"compiler/source:Span", ptr %t394
  store %"compiler/source:Span" %t395, ptr %l182
  %t396 = load i32, ptr %l16, !tbaa !23
  store i32 %t396, ptr %l183, !tbaa !23
  %t397 = load ptr, ptr %l13, !tbaa !29
  store ptr %t397, ptr %l184, !tbaa !29
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l14, !tbaa !29
  %t400 = load i32, ptr %l16, !tbaa !23
  %t401 = load ptr, ptr %lp5
  %t402 = getelementptr %"compiler/check:laneNode", ptr %t401, i32 0, i32 2
  %t403 = load %"compiler/source:Span", ptr %t402
  %t408 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v3, ptr %t398, ptr %t399, i32 %t400, %"compiler/source:Span" %t403)
  store ptr %t408, ptr %l189
  br label %bb72
bb72:
  %t409 = load ptr, ptr %l189, !tbaa !29
  store ptr %t409, ptr %l190, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l15, !tbaa !29
  %t412 = load i32, ptr %l16, !tbaa !23
  %t413 = load ptr, ptr %lp5
  %t414 = getelementptr %"compiler/check:laneNode", ptr %t413, i32 0, i32 2
  %t415 = load %"compiler/source:Span", ptr %t414
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v0, ptr %t410, ptr %t411, i32 %t412, %"compiler/source:Span" %t415)
  store ptr %t420, ptr %l195
  br label %bb73
bb73:
  %t421 = load ptr, ptr %l184, !tbaa !29
  %t422 = load ptr, ptr %l190, !tbaa !29
  %t423 = load ptr, ptr %l195, !tbaa !29
  %t424 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v0, ptr %v3, ptr %t421, ptr %t422, ptr %t423)
  store %"compiler/typed:Cond" %t424, ptr %l196
  br label %bb74
bb74:
  %t425 = load %"compiler/typed:Cond", ptr %l196
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t425, ptr %t426
  store { i64, [5 x i64] } zeroinitializer, ptr %t427
  %t428 = getelementptr { i64, [5 x i64] }, ptr %t427, i32 0, i32 0
  store i64 11, ptr %t428
  %t429 = load %"compiler/source:Span", ptr %l182
  %t430 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t429, 0
  %t431 = load i32, ptr %l183, !tbaa !23
  %t432 = insertvalue { %"compiler/source:Span", i32, ptr } %t430, i32 %t431, 1
  %t434 = insertvalue { %"compiler/source:Span", i32, ptr } %t432, ptr %t426, 2
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t427, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t434, ptr %t435
  %t436 = load { i64, [5 x i64] }, ptr %t427
  %t438 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t436, ptr %t438
  store ptr %t438, ptr %rv
  br label %ret
bb75:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l1
  %t442 = load ptr, ptr %lp5
  %t443 = getelementptr %"compiler/check:laneNode", ptr %t442, i32 0, i32 4
  %t444 = load i64, ptr %t443, !tbaa !24
  %t445 = load ptr, ptr %l3, !tbaa !29
  %t446 = load ptr, ptr %l4, !tbaa !29
  %t452 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t440, %"compiler/source:Span" %t441, i64 %t444, ptr %t445, ptr %t446)
  store ptr %t452, ptr %l205
  br label %bb76
bb76:
  %t453 = load ptr, ptr %l205, !tbaa !29
  store ptr %t453, ptr %l17, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l1
  %t456 = load ptr, ptr %lp5
  %t457 = getelementptr %"compiler/check:laneNode", ptr %t456, i32 0, i32 5
  %t458 = load i64, ptr %t457, !tbaa !24
  %t459 = load ptr, ptr %l3, !tbaa !29
  %t460 = load ptr, ptr %l4, !tbaa !29
  %t466 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t454, %"compiler/source:Span" %t455, i64 %t458, ptr %t459, ptr %t460)
  store ptr %t466, ptr %l211
  br label %bb77
bb77:
  %t467 = load ptr, ptr %l211, !tbaa !29
  store ptr %t467, ptr %l18, !tbaa !29
  %t468 = load ptr, ptr %lp5
  %t469 = getelementptr %"compiler/check:laneNode", ptr %t468, i32 0, i32 1
  %t470 = load i32, ptr %t469, !range !{i32 0, i32 116}
  %t472 = trunc i64 45 to i32
  %t473 = icmp eq i32 %t470, %t472
  br i1 %t473, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb80
bb79:
  %t475 = load ptr, ptr %lp5
  %t476 = getelementptr %"compiler/check:laneNode", ptr %t475, i32 0, i32 1
  %t477 = load i32, ptr %t476, !range !{i32 0, i32 116}
  %t479 = trunc i64 46 to i32
  %t480 = icmp eq i32 %t477, %t479
  store i1 %t480, ptr %l214, !tbaa !21
  br label %bb80
bb80:
  %t482 = load i1, ptr %l214, !tbaa !21
  br i1 %t482, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l217, !tbaa !29
  %t484 = load ptr, ptr %l17, !tbaa !29
  store ptr %t484, ptr %l218, !tbaa !29
  %t485 = load ptr, ptr %lp5
  %t486 = getelementptr %"compiler/check:laneNode", ptr %t485, i32 0, i32 3
  %t487 = load %"compiler/source:Span", ptr %t486
  store %"compiler/source:Span" %t487, ptr %l219
  %t488 = load ptr, ptr %lp5
  %t489 = getelementptr %"compiler/check:laneNode", ptr %t488, i32 0, i32 1
  %t490 = load i32, ptr %t489, !range !{i32 0, i32 116}
  %t492 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s10, i32 %t490)
  store { i64, ptr } %t492, ptr %l221
  br label %bb83
bb82:
  br label %bb103
bb83:
  %t493 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t494 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s10, ptr %s10, { i64, ptr } %t493)
  store { i64, ptr } %t494, ptr %l222
  br label %bb84
bb84:
  %t495 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t496 = load ptr, ptr %l217, !tbaa !29
  %t497 = load ptr, ptr %l218, !tbaa !29
  %t498 = load %"compiler/source:Span", ptr %l219
  %t500 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s10, ptr %t496, ptr %t497, %"compiler/source:Span" %t498, { i64, ptr } %t495)
  store i1 %t500, ptr %l224
  br label %bb85
bb85:
  %t501 = load i1, ptr %l224, !tbaa !21
  %t502 = xor i1 %t501, true
  br i1 %t502, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l226, !tbaa !21
  br label %bb91
bb87:
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l227, !tbaa !29
  %t505 = load ptr, ptr %l18, !tbaa !29
  store ptr %t505, ptr %l228, !tbaa !29
  %t506 = load ptr, ptr %lp5
  %t507 = getelementptr %"compiler/check:laneNode", ptr %t506, i32 0, i32 3
  %t508 = load %"compiler/source:Span", ptr %t507
  store %"compiler/source:Span" %t508, ptr %l229
  %t509 = load ptr, ptr %lp5
  %t510 = getelementptr %"compiler/check:laneNode", ptr %t509, i32 0, i32 1
  %t511 = load i32, ptr %t510, !range !{i32 0, i32 116}
  %t513 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s10, i32 %t511)
  store { i64, ptr } %t513, ptr %l231
  br label %bb88
bb88:
  %t514 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t515 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s10, ptr %s10, { i64, ptr } %t514)
  store { i64, ptr } %t515, ptr %l232
  br label %bb89
bb89:
  %t516 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t517 = load ptr, ptr %l227, !tbaa !29
  %t518 = load ptr, ptr %l228, !tbaa !29
  %t519 = load %"compiler/source:Span", ptr %l229
  %t521 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s10, ptr %t517, ptr %t518, %"compiler/source:Span" %t519, { i64, ptr } %t516)
  store i1 %t521, ptr %l234
  br label %bb90
bb90:
  %t522 = load i1, ptr %l234, !tbaa !21
  %t523 = xor i1 %t522, true
  store i1 %t523, ptr %l226, !tbaa !21
  br label %bb91
bb91:
  %t525 = load i1, ptr %l226, !tbaa !21
  br i1 %t525, label %bb92, label %bb93
bb92:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %lp5
  %t528 = getelementptr %"compiler/check:laneNode", ptr %t527, i32 0, i32 2
  %t529 = load %"compiler/source:Span", ptr %t528
  %t532 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t526, %"compiler/source:Span" %t529)
  store ptr %t532, ptr %l238
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s10)
  %t533 = load ptr, ptr %l238, !tbaa !29
  store ptr %t533, ptr %rv
  br label %ret
bb95:
  %t534 = load ptr, ptr %lp5
  %t535 = getelementptr %"compiler/check:laneNode", ptr %t534, i32 0, i32 1
  %t536 = load i32, ptr %t535, !range !{i32 0, i32 116}
  %t538 = trunc i64 45 to i32
  %t539 = icmp eq i32 %t536, %t538
  br i1 %t539, label %bb96, label %bb97
bb96:
  %t541 = load ptr, ptr %lp5
  %t542 = getelementptr %"compiler/check:laneNode", ptr %t541, i32 0, i32 2
  %t543 = load %"compiler/source:Span", ptr %t542
  store %"compiler/source:Span" %t543, ptr %l241
  %t544 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t544, ptr %l242, !tbaa !23
  %t545 = load ptr, ptr %l17, !tbaa !29
  store ptr %t545, ptr %l243, !tbaa !29
  %t546 = load ptr, ptr %l18, !tbaa !29
  store ptr %t546, ptr %l245, !tbaa !29
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load ptr, ptr %lp5
  %t550 = getelementptr %"compiler/check:laneNode", ptr %t549, i32 0, i32 2
  %t551 = load %"compiler/source:Span", ptr %t550
  %t552 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t556 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t548, %"compiler/source:Span" %t551, i32 %t552, i64 0)
  store ptr %t556, ptr %l249
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t557 = load ptr, ptr %l243, !tbaa !29
  %t558 = load ptr, ptr %l245, !tbaa !29
  %t559 = load ptr, ptr %l249, !tbaa !29
  %t560 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t557, ptr %t558, ptr %t559)
  store %"compiler/typed:Cond" %t560, ptr %l250
  br label %bb99
bb99:
  %t561 = load %"compiler/typed:Cond", ptr %l250
  %t562 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t561, ptr %t562
  store { i64, [5 x i64] } zeroinitializer, ptr %t563
  %t564 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 0
  store i64 11, ptr %t564
  %t565 = load %"compiler/source:Span", ptr %l241
  %t566 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t565, 0
  %t567 = load i32, ptr %l242, !tbaa !23
  %t568 = insertvalue { %"compiler/source:Span", i32, ptr } %t566, i32 %t567, 1
  %t570 = insertvalue { %"compiler/source:Span", i32, ptr } %t568, ptr %t562, 2
  %t571 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t570, ptr %t571
  %t572 = load { i64, [5 x i64] }, ptr %t563
  %t574 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t572, ptr %t574
  call void @__olang_scope_close(ptr %s10)
  store ptr %t574, ptr %rv
  br label %ret
bb100:
  %t576 = load ptr, ptr %lp5
  %t577 = getelementptr %"compiler/check:laneNode", ptr %t576, i32 0, i32 2
  %t578 = load %"compiler/source:Span", ptr %t577
  store %"compiler/source:Span" %t578, ptr %l254
  %t579 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t579, ptr %l255, !tbaa !23
  %t580 = load ptr, ptr %l17, !tbaa !29
  store ptr %t580, ptr %l256, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %lp5
  %t583 = getelementptr %"compiler/check:laneNode", ptr %t582, i32 0, i32 2
  %t584 = load %"compiler/source:Span", ptr %t583
  %t585 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t589 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t581, %"compiler/source:Span" %t584, i32 %t585, i64 1)
  store ptr %t589, ptr %l260
  br label %bb101
bb101:
  %t590 = load ptr, ptr %l260, !tbaa !29
  %t591 = load ptr, ptr %l18, !tbaa !29
  %t592 = load ptr, ptr %l256, !tbaa !29
  %t595 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t592, ptr %t590, ptr %t591)
  store %"compiler/typed:Cond" %t595, ptr %l263
  br label %bb102
bb102:
  %t596 = load %"compiler/typed:Cond", ptr %l263
  %t597 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t596, ptr %t597
  store { i64, [5 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [5 x i64] }, ptr %t598, i32 0, i32 0
  store i64 11, ptr %t599
  %t600 = load %"compiler/source:Span", ptr %l254
  %t601 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t600, 0
  %t602 = load i32, ptr %l255, !tbaa !23
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } %t601, i32 %t602, 1
  %t605 = insertvalue { %"compiler/source:Span", i32, ptr } %t603, ptr %t597, 2
  %t606 = getelementptr { i64, [5 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t605, ptr %t606
  %t607 = load { i64, [5 x i64] }, ptr %t598
  %t609 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t607, ptr %t609
  call void @__olang_scope_close(ptr %s10)
  store ptr %t609, ptr %rv
  br label %ret
bb103:
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l267, !tbaa !29
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load ptr, ptr %lp5
  %t614 = getelementptr %"compiler/check:laneNode", ptr %t613, i32 0, i32 2
  %t615 = load %"compiler/source:Span", ptr %t614
  %t616 = load ptr, ptr %lp5
  %t617 = getelementptr %"compiler/check:laneNode", ptr %t616, i32 0, i32 3
  %t618 = load %"compiler/source:Span", ptr %t617
  %t619 = load ptr, ptr %lp5
  %t620 = getelementptr %"compiler/check:laneNode", ptr %t619, i32 0, i32 1
  %t621 = load i32, ptr %t620, !range !{i32 0, i32 116}
  %t622 = load ptr, ptr %l17, !tbaa !29
  %t623 = load ptr, ptr %l18, !tbaa !29
  %t624 = load ptr, ptr %lp5
  %t625 = getelementptr %"compiler/check:laneNode", ptr %t624, i32 0, i32 2
  %t626 = load %"compiler/source:Span", ptr %t625
  %t627 = load ptr, ptr %lp5
  %t628 = getelementptr %"compiler/check:laneNode", ptr %t627, i32 0, i32 2
  %t629 = load %"compiler/source:Span", ptr %t628
  %t638 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v3, ptr %v3, ptr %v0, ptr %t612, %"compiler/source:Span" %t615, %"compiler/source:Span" %t618, i32 %t621, ptr %t622, ptr %t623, %"compiler/source:Span" %t626, %"compiler/source:Span" %t629)
  store ptr %t638, ptr %l276
  br label %bb104
bb104:
  %t639 = load ptr, ptr %l276, !tbaa !29
  %t640 = call ptr @compiler_2fcheck_2eunchecked(ptr %v0, ptr %v0, ptr %t639)
  store ptr %t640, ptr %l277
  br label %bb105
bb105:
  %t641 = load ptr, ptr %l267, !tbaa !29
  %t642 = load ptr, ptr %l277, !tbaa !29
  %t643 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v0, ptr %v3, ptr %t641, ptr %t642)
  store ptr %t643, ptr %l278
  br label %bb106
bb106:
  %t644 = load ptr, ptr %l278, !tbaa !29
  store ptr %t644, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSumIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, i64, i64, i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca %"compiler/check:laneVals"
  %l38 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l48 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca %"compiler/typed:Seq"
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l73 = alloca ptr
  %l79 = alloca { i64, i64, i64, i64, i64 }
  %l85 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l118 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l133 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t28 = alloca %"compiler/check:laneVals", align 8
  %t84 = alloca { i64, [5 x i64] }, align 8
  %t118 = alloca { i64, [3 x i64] }, align 8
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t223 = alloca { i64, [3 x i64] }, align 8
  %t273 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t3 = load i32, ptr %l4, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWorksIn(ptr %v0, ptr %t1, i64 %t2, i32 %t3, %"compiler/source:Span" %a5)
  store i1 %t9, ptr %l21
  br label %bb1
bb1:
  %t10 = load i1, ptr %l21, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t13, %"compiler/source:Span" %t14)
  store ptr %t17, ptr %l25
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load ptr, ptr %l25, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 48
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l28
  br label %bb6
bb6:
  %t24 = load i64, ptr %l28, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  %t27 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %t28, ptr %v0, ptr %v1, ptr %t25, %"compiler/source:Span" %t26, i64 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t28, i64 168, i1 false)
  br label %bb7
bb7:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 168, i64 8)
  store ptr %t32, ptr %lp7
  %t33 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l32, i64 168, i1 false)
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = load ptr, ptr %lp7
  %t37 = getelementptr %"compiler/check:laneVals", ptr %t36, i32 0, i32 1
  store i32 %t34, ptr %t37, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load ptr, ptr %lp7
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %v1, ptr %t38, %"compiler/source:Span" %t39, i64 %t40, ptr %t41)
  store ptr %t46, ptr %l38
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l38, !tbaa !29
  store ptr %t47, ptr %l8, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i32, ptr %l4, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDotShape(ptr %v0, ptr %t48, i64 %t49, i32 %t50)
  store i1 %t54, ptr %l42
  br label %bb9
bb9:
  %t55 = load i1, ptr %l42, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l43
  %t57 = load i32, ptr %l4, !tbaa !23
  store i32 %t57, ptr %l44, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 48
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store { i64, ptr } %t64, ptr %l48
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load ptr, ptr %lp7
  %t69 = load i32, ptr %l4, !tbaa !23
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDot(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t65, %"compiler/source:Span" %t66, i64 %t67, ptr %t68, i32 %t69, ptr %t70)
  store ptr %t77, ptr %l55
  br label %bb13
bb13:
  %t78 = load ptr, ptr %l55, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t79, ptr %t78, i1 false)
  store %"compiler/typed:Seq" %t81, ptr %l57
  br label %bb14
bb14:
  %t82 = load %"compiler/typed:Seq", ptr %l57
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/typed:Seq" %t82, ptr %t83
  store { i64, [5 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 0
  store i64 12, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l43
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t86, 0
  %t88 = load i32, ptr %l44, !tbaa !23
  %t89 = insertvalue { %"compiler/source:Span", i32, ptr } %t87, i32 %t88, 1
  %t91 = insertvalue { %"compiler/source:Span", i32, ptr } %t89, ptr %t83, 2
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t91, ptr %t92
  %t93 = load { i64, [5 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t93, ptr %t95
  store ptr %t95, ptr %rv
  br label %ret
bb15:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t99 = load i32, ptr %l4, !tbaa !23
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t97, %"compiler/source:Span" %t98, i32 %t99)
  store i64 %t103, ptr %l64
  br label %bb16
bb16:
  %t104 = load i64, ptr %l64, !tbaa !24
  store i64 %t104, ptr %l9, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l65, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l66
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = trunc i64 %t107 to i32
  store i32 %t109, ptr %l69, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  %t113 = load i32, ptr %l4, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t111, %"compiler/source:Span" %t112, i32 %t113)
  store ptr %t117, ptr %l73
  br label %bb17
bb17:
  store { i64, [3 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 0
  store i64 0, ptr %t119
  %t120 = load %"compiler/source:Span", ptr %l66
  %t121 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t120, 0
  %t122 = load i32, ptr %l69, !tbaa !23
  %t123 = insertvalue { %"compiler/source:Span", i32, ptr } %t121, i32 %t122, 1
  %t124 = load ptr, ptr %l73, !tbaa !29
  %t125 = insertvalue { %"compiler/source:Span", i32, ptr } %t123, ptr %t124, 2
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t125, ptr %t126
  %t127 = load { i64, [3 x i64] }, ptr %t118
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t127, ptr %t129
  %t130 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t130, ptr %t129)
  br label %bb18
bb18:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t134 = load ptr, ptr %l8, !tbaa !29
  %t138 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v1, ptr %t132, %"compiler/source:Span" %t133, ptr %t134, i64 0)
  store { i64, i64, i64, i64, i64 } %t138, ptr %l79
  br label %bb19
bb19:
  %t139 = load { i64, i64, i64, i64, i64 }, ptr %l79
  store { i64, i64, i64, i64, i64 } %t139, ptr %l10
  %t140 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l10, i32 0, i32 0
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  %t143 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l10, i32 0, i32 1
  %t144 = load i64, ptr %t143, !tbaa !24
  store i64 %t144, ptr %l12, !tbaa !24
  %t146 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l10, i32 0, i32 2
  %t147 = load i64, ptr %t146, !tbaa !24
  store i64 %t147, ptr %l13, !tbaa !24
  %t149 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l10, i32 0, i32 3
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l14, !tbaa !24
  %t152 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l10, i32 0, i32 4
  %t153 = load i64, ptr %t152, !tbaa !24
  store i64 %t153, ptr %l15, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l85, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t156, ptr %l86
  store %"compiler/source:Span" %a2, ptr %l87
  store i32 68, ptr %l88
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load i64, ptr %l9, !tbaa !24
  %t164 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t158, %"compiler/source:Span" %t159, i64 %t160)
  store ptr %t164, ptr %l92
  br label %bb20
bb20:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l93, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t166, ptr %l94
  %t167 = load i64, ptr %l3, !tbaa !24
  store i64 %t167, ptr %l95, !tbaa !24
  %t168 = load ptr, ptr %lp7
  store ptr %t168, ptr %l96, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  %t171 = load i64, ptr %l11, !tbaa !24
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t169, %"compiler/source:Span" %t170, i64 %t171)
  store ptr %t175, ptr %l100
  br label %bb21
bb21:
  %t176 = load ptr, ptr %l93, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l94
  %t178 = load i64, ptr %l95, !tbaa !24
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t180 = load ptr, ptr %l100, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t176, %"compiler/source:Span" %t177, i64 %t178, ptr %t179, ptr %t180)
  store ptr %t181, ptr %l101
  br label %bb22
bb22:
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load %"compiler/source:Span", ptr %l1
  %t184 = load ptr, ptr %l85, !tbaa !29
  %t185 = load %"compiler/source:Span", ptr %l86
  %t186 = load %"compiler/source:Span", ptr %l87
  %t187 = load i32, ptr %l88, !range !{i32 0, i32 116}
  %t188 = load ptr, ptr %l92, !tbaa !29
  %t189 = load ptr, ptr %l101, !tbaa !29
  %t192 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t184, %"compiler/source:Span" %t185, %"compiler/source:Span" %t186, i32 %t187, ptr %t188, ptr %t189, %"compiler/source:Span" %t182, %"compiler/source:Span" %t183)
  store ptr %t192, ptr %l104
  br label %bb23
bb23:
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l105, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t195, ptr %l106
  %t196 = load %"compiler/source:Span", ptr %l1
  %t197 = load i32, ptr %l4, !tbaa !23
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = trunc i64 %t198 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 0, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t196, 0
  %t207 = insertvalue { %"compiler/source:Span", i32, i32 } %t205, i32 %t197, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, i32 } %t207, i32 %t200, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t213 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t211, ptr %t213
  store ptr %t213, ptr %l113, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l4, !tbaa !23
  %t217 = load %"compiler/source:Span", ptr %l1
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v0, ptr %t214, ptr %t193, i32 %t216, %"compiler/source:Span" %t217)
  store ptr %t222, ptr %l118
  br label %bb24
bb24:
  store { i64, [3 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 0
  store i64 1, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l106
  %t226 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t225, 0
  %t227 = load ptr, ptr %l113, !tbaa !29
  %t228 = insertvalue { %"compiler/source:Span", ptr, ptr } %t226, ptr %t227, 1
  %t229 = load ptr, ptr %l118, !tbaa !29
  %t230 = insertvalue { %"compiler/source:Span", ptr, ptr } %t228, ptr %t229, 2
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t230, ptr %t231
  %t232 = load { i64, [3 x i64] }, ptr %t223
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t232, ptr %t234
  %t235 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t235, ptr %t234)
  br label %bb25
bb25:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  %t239 = load i64, ptr %l11, !tbaa !24
  %t240 = load i64, ptr %l12, !tbaa !24
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  %t243 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t237, %"compiler/source:Span" %t238, i64 %t239, i64 %t240, i64 %t241, i64 %t242, i64 %t243)
  br label %bb26
bb26:
  %t251 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t251, ptr %l128
  %t252 = load i32, ptr %l4, !tbaa !23
  store i32 %t252, ptr %l129, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 48
  %t256 = load i64, ptr %l6, !tbaa !24
  %t259 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t255, i64 %t256)
  store { i64, ptr } %t259, ptr %l133
  br label %bb27
bb27:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  %t262 = load i64, ptr %l9, !tbaa !24
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %t260, %"compiler/source:Span" %t261, i64 %t262)
  store ptr %t266, ptr %l137
  br label %bb28
bb28:
  %t267 = load ptr, ptr %l137, !tbaa !29
  %t268 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t270 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t268, ptr %t267, i1 false)
  store %"compiler/typed:Seq" %t270, ptr %l139
  br label %bb29
bb29:
  %t271 = load %"compiler/typed:Seq", ptr %l139
  %t272 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/typed:Seq" %t271, ptr %t272
  store { i64, [5 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 0
  store i64 12, ptr %t274
  %t275 = load %"compiler/source:Span", ptr %l128
  %t276 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t275, 0
  %t277 = load i32, ptr %l129, !tbaa !23
  %t278 = insertvalue { %"compiler/source:Span", i32, ptr } %t276, i32 %t277, 1
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } %t278, ptr %t272, 2
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t280, ptr %t281
  %t282 = load { i64, [5 x i64] }, ptr %t273
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t282, ptr %t284
  store ptr %t284, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWiden(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/check:laneVals", ptr %t10, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l13, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l20
  br label %bb8
bb8:
  %t31 = load i1, ptr %l20, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/check:laneVals", ptr %t42, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t40, i32 %t41, i32 %t45)
  store i1 %t49, ptr %l29
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/check:laneVals", ptr %t56, i32 0, i32 1
  %t59 = load i32, ptr %t58, !tbaa !23
  store i32 %t59, ptr %l34, !tbaa !23
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l36
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = load i32, ptr %l34, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l36
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v3, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store ptr %t67, ptr %l37
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l37, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedMet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca %"compiler/names:Ref"
  %l41 = alloca { i64, ptr }
  %l47 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca i64
  %l61 = alloca { i64, ptr }
  %l71 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca i32
  %l81 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i1
  %l98 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca %"compiler/diagmsg:Msg"
  %l113 = alloca i64
  %l118 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i64
  %l144 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l151 = alloca %"compiler/diagmsg:Msg"
  %l152 = alloca i64
  %l156 = alloca i1
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca i1
  %l175 = alloca ptr
  %l177 = alloca ptr
  %l181 = alloca %"compiler/names:Ref"
  %l184 = alloca i1
  %l187 = alloca i1
  %l189 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l197 = alloca i1
  %l199 = alloca i1
  %l204 = alloca i1
  %l214 = alloca i1
  %l218 = alloca i1
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l223 = alloca i1
  %l224 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l230 = alloca %"compiler/source:Span"
  %l233 = alloca %"compiler/diagmsg:Msg"
  %l234 = alloca i64
  %l243 = alloca { i64, ptr }
  %l247 = alloca i1
  %l251 = alloca i1
  %l258 = alloca ptr
  %l260 = alloca ptr
  %l265 = alloca i32
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca { i64, ptr }
  %l273 = alloca i32
  %l274 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i32
  %l279 = alloca { i64, ptr }
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l20
  br label %bb3
bb2:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 4
  %t13 = getelementptr %"compiler/generic:Context", ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t14, ptr %l23, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 0
  %t18 = load i32, ptr %t17, !tbaa !33
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t13, i32 %t18)
  store i1 %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load i1, ptr %l25, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l18, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l30, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l32
  br label %bb8
bb7:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb8:
  %t36 = load ptr, ptr %l32, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l36
  br label %bb9
bb9:
  %t46 = getelementptr %"compiler/names:Ref", ptr %l36, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 9}
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l2
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l41, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t53, %"compiler/source:Span" %t54, i32 %t59, i1 false)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp sgt i64 %t66, 1
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t77)
  store ptr %t79, ptr %l52
  br label %bb17
bb16:
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb19
bb17:
  %t80 = load ptr, ptr %l52, !tbaa !29
  %t82 = getelementptr %"compiler/check:frame", ptr %t80, i32 0, i32 2
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l50, !tbaa !29
  %t89 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMissingIn(ptr %v0, ptr %t86, i64 %t83, i32 %t85)
  store i64 %t89, ptr %l56
  br label %bb18
bb18:
  %t90 = load i64, ptr %l56, !tbaa !24
  store i64 %t90, ptr %l47, !tbaa !24
  br label %bb19
bb19:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l5, !tbaa !24
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l5, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = sub i64 %t101, 1
  %t105 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 %t103
  %t108 = load i32, ptr %t107, !tbaa !33
  %t109 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotInModule(ptr %v0, ptr %t96, i64 %t97, i32 %t108, %"compiler/source:Span" %t109)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb23:
  %t115 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t119 = icmp eq i64 %t117, 1
  br i1 %t119, label %bb24, label %bb25
bb24:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t121)
  store ptr %t123, ptr %l73
  br label %bb26
bb25:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb28
bb26:
  %t124 = load ptr, ptr %l73, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 4
  %t127 = getelementptr %"compiler/generic:Context", ptr %t126, i32 0, i32 2
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t128, ptr %l76, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 0
  %t132 = load i32, ptr %t131, !tbaa !33
  %t135 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t127, i32 %t132)
  store i1 %t135, ptr %l78
  br label %bb27
bb27:
  %t136 = load i1, ptr %l78, !tbaa !21
  store i1 %t136, ptr %l71, !tbaa !21
  br label %bb28
bb28:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb29, label %bb30
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t138)
  store ptr %t140, ptr %l81
  br label %bb31
bb30:
  br label %bb48
bb31:
  %t141 = load ptr, ptr %l81, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 4
  %t144 = getelementptr %"compiler/generic:Context", ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t145, ptr %l84, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 0
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t144, i32 %t149)
  %t153 = extractvalue { i32, i32 } %t152, 1
  %t154 = extractvalue { i32, i32 } %t152, 0
  store i32 %t154, ptr %l87
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb33, label %ok.156, !prof !99
ok.156:
  store i32 %t153, ptr %l86
  br label %bb32
bb32:
  %t157 = load i32, ptr %l86, !tbaa !23
  store i32 %t157, ptr %l79, !tbaa !23
  br label %bb35
bb33:
  br label %bb34
bb34:
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t158, ptr %l79, !tbaa !23
  br label %bb35
bb35:
  %t160 = load i32, ptr %l79, !tbaa !23
  store i32 %t160, ptr %l6, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i32, ptr %l6, !tbaa !23
  %t168 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t164, i32 %t165)
  store i1 %t168, ptr %l92
  br label %bb36
bb36:
  %t169 = load i1, ptr %l92, !tbaa !21
  br i1 %t169, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb40
bb38:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l6, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l98
  br label %bb39
bb39:
  %t180 = load i32, ptr %l98, !range !{i32 0, i32 33}
  %t182 = trunc i64 30 to i32
  %t183 = icmp eq i32 %t180, %t182
  store i1 %t183, ptr %l93, !tbaa !21
  br label %bb40
bb40:
  %t185 = load i1, ptr %l93, !tbaa !21
  br i1 %t185, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s4
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l101, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t187, ptr %l102
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t189, ptr %l104, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 0
  %t193 = load i32, ptr %t192, !tbaa !33
  %t196 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t188, i32 %t193)
  store { i64, ptr } %t196, ptr %l106
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t197 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t197, ptr %l107, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t199, ptr %l109, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 0
  %t203 = load i32, ptr %t202, !tbaa !33
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t198, i32 %t203)
  store { i64, ptr } %t206, ptr %l111
  br label %bb44
bb44:
  %t207 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t209 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrVarNotType(ptr %s4, ptr %v0, ptr %v0, { i64, ptr } %t207, { i64, ptr } %t208)
  store %"compiler/diagmsg:Msg" %t209, ptr %l112
  br label %bb45
bb45:
  %t210 = load ptr, ptr %l101, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l102
  %t212 = load %"compiler/diagmsg:Msg", ptr %l112
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t210, %"compiler/source:Span" %t211, %"compiler/diagmsg:Msg" %t212)
  store i64 %t213, ptr %l113
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v1, ptr %t215, ptr %t216, ptr %t217)
  store i1 %t221, ptr %l118
  br label %bb49
bb49:
  %t222 = load i1, ptr %l118, !tbaa !21
  br i1 %t222, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 113
  %t227 = load i1, ptr %t226, !tbaa !21
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb53, label %bb54
bb53:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t235 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncNamed(ptr %v0, ptr %v1, ptr %t231, ptr %t232)
  store i1 %t235, ptr %l126
  br label %bb55
bb54:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb56
bb55:
  %t236 = load i1, ptr %l126, !tbaa !21
  store i1 %t236, ptr %l123, !tbaa !21
  br label %bb56
bb56:
  %t237 = load i1, ptr %l123, !tbaa !21
  br i1 %t237, label %bb57, label %bb58
bb57:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l127, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t239, ptr %l128
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l129, !tbaa !29
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t241)
  store %"compiler/source:Span" %t243, ptr %l131
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t244 = load ptr, ptr %l129, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l131
  %t246 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t244, %"compiler/source:Span" %t245)
  store { i64, ptr } %t246, ptr %l132
  br label %bb60
bb60:
  %t247 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t248 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %v0, { i64, ptr } %t247)
  store %"compiler/diagmsg:Msg" %t248, ptr %l133
  br label %bb61
bb61:
  %t249 = load ptr, ptr %l127, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l128
  %t251 = load %"compiler/diagmsg:Msg", ptr %l133
  %t252 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t249, %"compiler/source:Span" %t250, %"compiler/diagmsg:Msg" %t251)
  store i64 %t252, ptr %l134
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb63:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 118
  %t257 = load i1, ptr %t256, !tbaa !21
  store i1 %t257, ptr %l7, !tbaa !21
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 113
  %t262 = load i1, ptr %t261, !tbaa !21
  store i1 %t262, ptr %l8, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 113
  store i1 false, ptr %t266, !tbaa !21
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 118
  store i1 false, ptr %t269, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %t270, ptr %t271)
  store i1 %t274, ptr %l144
  br label %bb64
bb64:
  %t275 = load i1, ptr %l144, !tbaa !21
  br i1 %t275, label %bb65, label %bb66
bb65:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l145, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t277, ptr %l146
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l147, !tbaa !29
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t279)
  store %"compiler/source:Span" %t281, ptr %l149
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t282 = load ptr, ptr %l147, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l149
  %t284 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t282, %"compiler/source:Span" %t283)
  store { i64, ptr } %t284, ptr %l150
  br label %bb68
bb68:
  %t285 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t286 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v0, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t286, ptr %l151
  br label %bb69
bb69:
  %t287 = load ptr, ptr %l145, !tbaa !29
  %t288 = load %"compiler/source:Span", ptr %l146
  %t289 = load %"compiler/diagmsg:Msg", ptr %l151
  %t290 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t287, %"compiler/source:Span" %t288, %"compiler/diagmsg:Msg" %t289)
  store i64 %t290, ptr %l152
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb71:
  %t292 = load i1, ptr %l8, !tbaa !21
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb72, label %bb73
bb72:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  store ptr %t299, ptr %l158, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  store ptr %t303, ptr %l160, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t304)
  store ptr %t306, ptr %l162
  br label %bb74
bb73:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb77
bb74:
  %t307 = load ptr, ptr %l162, !tbaa !29
  %t309 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 4
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = load ptr, ptr %l160, !tbaa !29
  %t315 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t312, ptr %t309, ptr %t310)
  store i32 %t315, ptr %l167
  br label %bb75
bb75:
  %t316 = load ptr, ptr %l158, !tbaa !29
  %t317 = load i32, ptr %l167, !tbaa !23
  %t318 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %t316, i32 %t317)
  store i1 %t318, ptr %l168
  br label %bb76
bb76:
  %t319 = load i1, ptr %l168, !tbaa !21
  store i1 %t319, ptr %l156, !tbaa !21
  br label %bb77
bb77:
  %t320 = load i1, ptr %l156, !tbaa !21
  br i1 %t320, label %bb78, label %bb79
bb78:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenByValue(ptr %v0, ptr %v1, ptr %t321, ptr %t322, %"compiler/source:Span" %t323)
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb81:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/generic:Program", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  store ptr %t334, ptr %l175, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t335)
  store ptr %t337, ptr %l177
  br label %bb82
bb82:
  %t338 = load ptr, ptr %l177, !tbaa !29
  %t340 = getelementptr %"compiler/check:frame", ptr %t338, i32 0, i32 2
  %t341 = load i64, ptr %t340, !tbaa !24
  %t342 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t343 = load i32, ptr %t342, !tbaa !23
  %t344 = load ptr, ptr %l175, !tbaa !29
  %t347 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t344, i64 %t341, i32 %t343)
  store %"compiler/names:Ref" %t347, ptr %l181
  br label %bb83
bb83:
  %t348 = load %"compiler/names:Ref", ptr %l181
  store %"compiler/names:Ref" %t348, ptr %l9
  %t349 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t350 = load i32, ptr %t349, !range !{i32 0, i32 9}
  %t352 = trunc i64 4 to i32
  %t353 = icmp eq i32 %t350, %t352
  br i1 %t353, label %bb84, label %bb85
bb84:
  %t355 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 2
  %t356 = load i64, ptr %t355, !tbaa !24
  %t358 = icmp sge i64 %t356, 0
  store i1 %t358, ptr %l184, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb86
bb86:
  %t360 = load i1, ptr %l184, !tbaa !21
  br i1 %t360, label %bb87, label %bb88
bb87:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t361)
  store ptr %t363, ptr %l189
  br label %bb89
bb88:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb91
bb89:
  %t364 = load ptr, ptr %l189, !tbaa !29
  %t366 = getelementptr %"compiler/check:frame", ptr %t364, i32 0, i32 4
  %t367 = getelementptr %"compiler/generic:Context", ptr %t366, i32 0, i32 2
  %t368 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t368, ptr %l192, !tbaa !27
  %t369 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t373 = sub i64 %t371, 1
  %t375 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr i32, ptr %t376, i64 %t373
  %t378 = load i32, ptr %t377, !tbaa !33
  %t381 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t367, i32 %t378)
  store i1 %t381, ptr %l197
  br label %bb90
bb90:
  %t382 = load i1, ptr %l197, !tbaa !21
  %t383 = xor i1 %t382, true
  store i1 %t383, ptr %l187, !tbaa !21
  br label %bb91
bb91:
  %t385 = load i1, ptr %l187, !tbaa !21
  br i1 %t385, label %bb92, label %bb93
bb92:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t388 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t389 = load %"compiler/names:Ref", ptr %l9
  %t394 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgCountMet(ptr %v0, ptr %v2, ptr %v3, ptr %t386, { i64, ptr } %t387, { i64, ptr } %t388, %"compiler/names:Ref" %t389)
  store i1 %t394, ptr %l204
  br label %bb94
bb93:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb95
bb94:
  %t395 = load i1, ptr %l204, !tbaa !21
  %t396 = xor i1 %t395, true
  store i1 %t396, ptr %l199, !tbaa !21
  br label %bb95
bb95:
  %t398 = load i1, ptr %l199, !tbaa !21
  br i1 %t398, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t400 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t404 = icmp eq i64 %t402, 0
  br i1 %t404, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t407 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t411 = icmp eq i64 %t409, 1
  br i1 %t411, label %bb102, label %bb103
bb102:
  %t413 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t417 = icmp sgt i64 %t415, 1
  store i1 %t417, ptr %l214, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb104
bb104:
  %t419 = load i1, ptr %l214, !tbaa !21
  br i1 %t419, label %bb105, label %bb106
bb105:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t421, ptr %l220, !tbaa !27
  %t422 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr i32, ptr %t423, i64 0
  %t425 = load i32, ptr %t424, !tbaa !33
  %t428 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t420, i32 %t425)
  store { i64, ptr } %t428, ptr %l222
  br label %bb107
bb106:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb109
bb107:
  %t429 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t430 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t429, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t430, ptr %l223
  br label %bb108
bb108:
  %t431 = load i1, ptr %l223, !tbaa !21
  store i1 %t431, ptr %l218, !tbaa !21
  br label %bb109
bb109:
  %t432 = load i1, ptr %l218, !tbaa !21
  br i1 %t432, label %bb110, label %bb111
bb110:
  %t433 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t434 = load i32, ptr %t433, !range !{i32 0, i32 9}
  %t436 = trunc i64 7 to i32
  %t437 = icmp eq i32 %t434, %t436
  store i1 %t437, ptr %l224, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb112
bb112:
  %t439 = load i1, ptr %l224, !tbaa !21
  br i1 %t439, label %bb113, label %bb114
bb113:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l227, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t441, ptr %l228, !tbaa !27
  %t442 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr ptr, ptr %t443, i64 1
  %t445 = load ptr, ptr %t444, !tbaa !39
  %t447 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t445)
  store %"compiler/source:Span" %t447, ptr %l230
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t448 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t452 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %t450)
  store %"compiler/diagmsg:Msg" %t452, ptr %l233
  br label %bb116
bb116:
  %t453 = load ptr, ptr %l227, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l230
  %t455 = load %"compiler/diagmsg:Msg", ptr %l233
  %t456 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t453, %"compiler/source:Span" %t454, %"compiler/diagmsg:Msg" %t455)
  store i64 %t456, ptr %l234
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb118:
  %t458 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t458, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t460 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t460, 0
  store i64 %t462, ptr %l12, !tbaa !24
  br label %bb119
bb119:
  %t464 = load i64, ptr %l11, !tbaa !24
  %t465 = load i64, ptr %l12, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb120, label %bb121
bb120:
  br label %bb132
bb121:
  br label %bb122
bb122:
  %t472 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t472, ptr %l243, !tbaa !27
  %t473 = load i64, ptr %l11, !tbaa !24
  %t475 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = getelementptr ptr, ptr %t476, i64 %t473
  %t478 = load ptr, ptr %t477, !tbaa !39
  store ptr %t478, ptr %l13, !tbaa !29
  %t480 = load ptr, ptr %l13, !tbaa !29
  %t482 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v3, ptr %t480)
  store i1 %t482, ptr %l247
  br label %bb123
bb123:
  %t483 = load i1, ptr %l247, !tbaa !21
  br i1 %t483, label %bb124, label %bb125
bb124:
  br label %bb131
bb125:
  br label %bb126
bb126:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/check:Checker", ptr %t484, i32 0, i32 114
  store i1 true, ptr %t486, !tbaa !21
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l13, !tbaa !29
  %t491 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgMet(ptr %v0, ptr %v3, ptr %t487, ptr %t488)
  store i1 %t491, ptr %l251
  br label %bb127
bb127:
  %t492 = load i1, ptr %l251, !tbaa !21
  %t493 = xor i1 %t492, true
  br i1 %t493, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb129:
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t496 = load i64, ptr %l11, !tbaa !24
  %t499 = add i64 %t496, 1
  store i64 %t499, ptr %l11, !tbaa !24
  br label %bb119
bb132:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/check:Checker", ptr %t501, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !29
  store ptr %t504, ptr %l258, !tbaa !29
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t505)
  store ptr %t507, ptr %l260
  br label %bb133
bb133:
  %t508 = load ptr, ptr %l260, !tbaa !29
  %t510 = getelementptr %"compiler/check:frame", ptr %t508, i32 0, i32 4
  %t511 = load ptr, ptr %l1, !tbaa !29
  %t513 = load ptr, ptr %l258, !tbaa !29
  %t516 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t513, ptr %t510, ptr %t511)
  store i32 %t516, ptr %l265
  br label %bb134
bb134:
  %t517 = load i32, ptr %l265, !tbaa !23
  store i32 %t517, ptr %l14, !tbaa !23
  %t518 = load i1, ptr %l7, !tbaa !21
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb135, label %bb136
bb135:
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l269, !tbaa !29
  %t523 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t523, ptr %l270, !tbaa !27
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i32, ptr %l14, !tbaa !23
  %t528 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownBuffer(ptr %v0, ptr %t524, i32 %t525)
  store i32 %t528, ptr %l273
  br label %bb137
bb136:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb139
bb137:
  %t529 = load ptr, ptr %l269, !tbaa !29
  %t530 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t531 = load i32, ptr %l273, !tbaa !23
  %t532 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v3, ptr %t529, { i64, ptr } %t530, i32 %t531)
  store i1 %t532, ptr %l274
  br label %bb138
bb138:
  %t533 = load i1, ptr %l274, !tbaa !21
  %t534 = xor i1 %t533, true
  store i1 %t534, ptr %l268, !tbaa !21
  br label %bb139
bb139:
  %t536 = load i1, ptr %l268, !tbaa !21
  br i1 %t536, label %bb140, label %bb141
bb140:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb141:
  br label %bb142
bb142:
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l277, !tbaa !29
  %t539 = load i32, ptr %l14, !tbaa !23
  store i32 %t539, ptr %l278, !tbaa !23
  %t540 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t540, ptr %l279, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 0
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t544)
  store %"compiler/source:Span" %t546, ptr %l281
  br label %bb143
bb143:
  %t547 = load ptr, ptr %l277, !tbaa !29
  %t548 = load i32, ptr %l278, !tbaa !23
  %t549 = load %"compiler/source:Span", ptr %l281
  %t550 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t547, i32 %t548, %"compiler/source:Span" %t549)
  store i1 %t550, ptr %l282
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t551 = load i1, ptr %l282, !tbaa !21
  store i1 %t551, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l21
  br label %bb7
bb7:
  %t35 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t37 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t35)
  store { i64, ptr } %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l19
  %t42 = load %"compiler/source:Span", ptr %l21
  %t44 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, %"compiler/source:Span" %t42, i64 %t39)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 28}
  %t53 = icmp eq i64 %t51, 12
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l5
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb18
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t67, ptr %l34
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = load %"compiler/source:Span", ptr %l34
  %t77 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t75, i64 %t74)
  store %"compiler/source:Span" %t77, ptr %l39
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t78 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t78, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l41
  br label %bb22
bb22:
  %t82 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t82, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4d0d10dbd8c28898_8d57e58513238834)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownBuffer(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i32
  %l43 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 13
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 14
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEnds(ptr %v0, ptr %t24, i32 %t23)
  store i1 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i1, ptr %l16, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l8, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l23
  br label %bb10
bb10:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %l2, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l28
  br label %bb11
bb11:
  %t54 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t56 = trunc i64 19 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l36
  br label %bb14
bb13:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb15
bb14:
  %t69 = load i32, ptr %l36, !tbaa !23
  %t70 = icmp eq i32 %t69, 0
  store i1 %t70, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb16, label %bb17
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l43
  br label %bb18
bb17:
  %t83 = load i32, ptr %l1, !tbaa !23
  store i32 %t83, ptr %l38, !tbaa !23
  br label %bb19
bb18:
  %t85 = load i32, ptr %l43, !tbaa !23
  store i32 %t85, ptr %l38, !tbaa !23
  br label %bb19
bb19:
  %t86 = load i32, ptr %l38, !tbaa !23
  store i32 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i64
  %l42 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l100 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %l110 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca i32
  %l129 = alloca ptr
  %l131 = alloca i32
  %l134 = alloca i32
  %l135 = alloca i32
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca i32
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l143 = alloca i32
  %l145 = alloca %"compiler/typed:Make"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t270 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l19, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l20
  %t9 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoTarget(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t9, ptr %l21
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l20
  %t12 = load %"compiler/diagmsg:Msg", ptr %l21
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t10, %"compiler/source:Span" %t11, %"compiler/diagmsg:Msg" %t12)
  store i64 %t13, ptr %l22
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l25
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t19 = load ptr, ptr %l25, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryAt(ptr %v0, ptr %v1, ptr %t20, { i64, ptr } %t21)
  store i64 %t24, ptr %l28
  br label %bb7
bb7:
  %t25 = load i64, ptr %l28, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownMap(ptr %v0, ptr %v1, ptr %v2, ptr %t28, %"compiler/source:Span" %t29, { i64, ptr } %t30)
  store ptr %t34, ptr %l33
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load ptr, ptr %l33, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l35, !tbaa !24
  %t39 = load i64, ptr %l35, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load i64, ptr %l35, !tbaa !24
  %t43 = icmp sle i64 %t42, 1152921504606846975
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_78b67e7b86d014f7_b202530d028f16d3)
  unreachable
bb14:
  %t45 = load i64, ptr %l35, !tbaa !24
  %t46 = mul i64 %t45, 8
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t50, ptr %lp3
  %t52 = load ptr, ptr %lp3
  store { i64, ptr } %t49, ptr %t52, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = load ptr, ptr %lp3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownElem(ptr %v0, ptr %v1, ptr %v2, ptr %t53, { i64, ptr } %t54, { i64, ptr } %t56)
  store i32 %t60, ptr %l42
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_78b67e7b86d014f7_b202530d028f16d3)
  unreachable
bb16:
  %t61 = load i32, ptr %l42, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t66 = icmp eq i32 %t62, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t68, %"compiler/source:Span" %t69)
  store ptr %t72, ptr %l48
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t73 = load ptr, ptr %l48, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l4, !tbaa !23
  %t78 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l51
  br label %bb21
bb21:
  %t79 = load i32, ptr %l51, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb22
bb22:
  %t85 = load i1, ptr %l54, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = load ptr, ptr %lp3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elayRows(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t86, %"compiler/source:Span" %t87, i32 %t88, { i64, ptr } %t89, { i64, ptr } %t91, i1 false)
  store ptr %t97, ptr %l60
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t98 = load ptr, ptr %l60, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 47
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l63
  br label %bb27
bb27:
  %t104 = load i64, ptr %l63, !tbaa !24
  store i64 %t104, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb33
bb30:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l72, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l69, !tbaa !24
  br label %bb33
bb33:
  %t136 = load i64, ptr %l69, !tbaa !24
  store i64 %t136, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb35, label %bb36
bb35:
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l12, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t156, ptr %l91, !tbaa !27
  %t157 = load i64, ptr %l12, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load ptr, ptr %lp3
  %t166 = getelementptr { i64, ptr }, ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t163
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t170 = load i32, ptr %l4, !tbaa !23
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleItem(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t155, ptr %t162, ptr %t169, i32 %t170)
  store ptr %t175, ptr %l97
  br label %bb38
bb38:
  %t176 = load ptr, ptr %l97, !tbaa !29
  store ptr %t176, ptr %l13, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l4, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l100
  br label %bb39
bb39:
  %t182 = load i1, ptr %l100, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb40, label %bb41
bb40:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l102, !tbaa !29
  %t186 = load ptr, ptr %l13, !tbaa !29
  store ptr %t186, ptr %l104, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t188, ptr %l105, !tbaa !27
  %t189 = load i64, ptr %l12, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr ptr, ptr %t192, i64 %t189
  %t194 = load ptr, ptr %t193, !tbaa !39
  %t196 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t194)
  store %"compiler/source:Span" %t196, ptr %l108
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t197 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load ptr, ptr %l104, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l108
  %t202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t198, ptr %t199, %"compiler/source:Span" %t200, i64 %t197)
  store i1 %t202, ptr %l110
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 47
  store ptr %t205, ptr %l112, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t206, ptr %t207)
  store ptr %t210, ptr %l115
  br label %bb45
bb45:
  %t211 = load ptr, ptr %l112, !tbaa !29
  %t212 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t211, ptr %t212)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t213 = load i64, ptr %l11, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l11, !tbaa !24
  br label %bb34
bb48:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 47
  %t221 = load i64, ptr %l6, !tbaa !24
  %t224 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t220, i64 %t221)
  store { i64, ptr } %t224, ptr %l122
  br label %bb49
bb49:
  %t225 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t225, ptr %l14, !tbaa !27
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  store ptr %t231, ptr %l125, !tbaa !29
  %t232 = load i32, ptr %l4, !tbaa !23
  store i32 %t232, ptr %l126, !tbaa !23
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  store ptr %t238, ptr %l129, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t239)
  store i32 %t241, ptr %l131
  br label %bb50
bb50:
  %t242 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = load ptr, ptr %l129, !tbaa !29
  %t246 = load i32, ptr %l131, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t245, i32 %t246, i64 %t244)
  store i32 %t248, ptr %l134
  br label %bb51
bb51:
  %t249 = load ptr, ptr %l125, !tbaa !29
  %t250 = load i32, ptr %l126, !tbaa !23
  %t251 = load i32, ptr %l134, !tbaa !23
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t249, i32 %t250, i32 %t251)
  store i32 %t252, ptr %l135
  br label %bb52
bb52:
  %t253 = load i32, ptr %l135, !tbaa !23
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l136
  store i32 %t253, ptr %l137, !tbaa !23
  store i32 2, ptr %l138
  %t256 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t256, ptr %l139, !tbaa !27
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  %t262 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t257, i32 1, %"compiler/source:Span" %t258)
  store i32 %t262, ptr %l143
  br label %bb53
bb53:
  %t263 = load i32, ptr %l138, !range !{i32 0, i32 5}
  %t264 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t265 = load i32, ptr %l143, !tbaa !23
  %t267 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t263, i64 0, { i64, ptr } %t264, ptr null, i32 %t265, i32 0, i1 false)
  store %"compiler/typed:Make" %t267, ptr %l145
  br label %bb54
bb54:
  %t268 = load %"compiler/typed:Make", ptr %l145
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t268, ptr %t269
  store { i64, [5 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t270, i32 0, i32 0
  store i64 7, ptr %t271
  %t272 = load %"compiler/source:Span", ptr %l136
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t272, 0
  %t274 = load i32, ptr %l137, !tbaa !23
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t274, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [5 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [5 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t279, ptr %t281
  store ptr %t281, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l10 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l5, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load i32, ptr %l1, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l17, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l22
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = load i32, ptr %l22, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t43, i32 %t44, i32 0)
  store i32 %t45, ptr %l23
  br label %bb10
bb10:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameJump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca i32
  %l88 = alloca i32
  %l89 = alloca i1
  %l95 = alloca i1
  %l97 = alloca i1
  %l101 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l114 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l18
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp ne i64 %t30, %t33
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l6, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb10:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l39, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l36, !tbaa !24
  store i64 %t70, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l58, !tbaa !27
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t97, ptr %l61, !tbaa !27
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t107 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t89, i32 %t96, i32 %t103)
  store i1 %t107, ptr %l64
  br label %bb18
bb18:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb20:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t112, ptr %l68, !tbaa !27
  %t113 = load i64, ptr %l11, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t121 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t111, i32 %t118)
  store i64 %t121, ptr %l71
  br label %bb21
bb21:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l73, !tbaa !27
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t122, i32 %t129)
  store i64 %t132, ptr %l76
  br label %bb22
bb22:
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = load i64, ptr %l76, !tbaa !24
  %t135 = icmp ne i64 %t133, %t134
  store i1 %t135, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t137 = load i1, ptr %l66, !tbaa !21
  br i1 %t137, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb14
bb28:
  %t144 = load ptr, ptr %l3, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l85
  br label %bb29
bb29:
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l88
  br label %bb30
bb30:
  %t155 = load ptr, ptr %l82, !tbaa !29
  %t156 = load i32, ptr %l85, !tbaa !23
  %t157 = load i32, ptr %l88, !tbaa !23
  %t158 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t155, i32 %t156, i32 %t157)
  store i1 %t158, ptr %l89
  br label %bb31
bb31:
  %t159 = load i1, ptr %l89, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t164 = load i32, ptr %l1, !tbaa !23
  %t165 = load i32, ptr %l2, !tbaa !23
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i1 %t169, ptr %l95
  br label %bb35
bb35:
  %t170 = load i1, ptr %l95, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb39
bb37:
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load i32, ptr %l2, !tbaa !23
  %t175 = load i32, ptr %l1, !tbaa !23
  %t179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t173, i32 %t174, i32 %t175)
  store i1 %t179, ptr %l101
  br label %bb38
bb38:
  %t180 = load i1, ptr %l101, !tbaa !21
  %t181 = xor i1 %t180, true
  store i1 %t181, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t183 = load i1, ptr %l97, !tbaa !21
  br i1 %t183, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t190, i32 %t191)
  store { i64, ptr } %t194, ptr %l108
  br label %bb43
bb43:
  %t195 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l109, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l2, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l114
  br label %bb44
bb44:
  %t207 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = load i64, ptr %l109, !tbaa !24
  %t211 = icmp eq i64 %t209, %t208
  call void @__olang_scope_close(ptr %s0)
  store i1 %t211, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/diagmsg:Msg"
  %l64 = alloca i64
  %l65 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l77 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i64
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca i1
  %l130 = alloca i64
  %l132 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca %"compiler/diagmsg:Msg"
  %l152 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca i32
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca i32
  %l171 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l178 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l188 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca i1
  %l200 = alloca i1
  %l202 = alloca i1
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/diagmsg:Msg"
  %l213 = alloca i64
  %l218 = alloca ptr
  %l220 = alloca ptr
  %l221 = alloca ptr
  %l226 = alloca i1
  %l230 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l235 = alloca i64
  %l242 = alloca ptr
  %l247 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l251 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca ptr
  %l261 = alloca i1
  %l262 = alloca ptr
  %l264 = alloca %"compiler/source:Span"
  %l265 = alloca %"compiler/diagmsg:Msg"
  %l266 = alloca i64
  %l267 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l284 = alloca i1
  %l287 = alloca ptr
  %l289 = alloca %"compiler/source:Span"
  %l290 = alloca %"compiler/diagmsg:Msg"
  %l291 = alloca i64
  %l292 = alloca ptr
  %l299 = alloca i1
  %l301 = alloca ptr
  %l303 = alloca %"compiler/source:Span"
  %l304 = alloca %"compiler/diagmsg:Msg"
  %l305 = alloca i64
  %l306 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l308 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l314 = alloca i32
  %l316 = alloca i64
  %l318 = alloca i1
  %l320 = alloca ptr
  %l324 = alloca ptr
  %l328 = alloca i32
  %l331 = alloca i1
  %l332 = alloca i1
  %l335 = alloca i1
  %l336 = alloca i1
  %l341 = alloca i1
  %l342 = alloca i1
  %l347 = alloca i32
  %l352 = alloca i32
  %l358 = alloca i32
  %l366 = alloca { i64, ptr }
  %l369 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l371 = alloca ptr
  %l373 = alloca i1
  %l378 = alloca i1
  %l389 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l402 = alloca i1
  %l404 = alloca ptr
  %l406 = alloca %"compiler/source:Span"
  %l408 = alloca { i64, ptr }
  %l413 = alloca ptr
  %l415 = alloca i32
  %l417 = alloca { i64, ptr }
  %l419 = alloca { i64, ptr }
  %l423 = alloca { i64, ptr }
  %l425 = alloca %"compiler/diagmsg:Msg"
  %l426 = alloca i64
  %l431 = alloca i1
  %l433 = alloca ptr
  %l435 = alloca %"compiler/source:Span"
  %l436 = alloca i64
  %l439 = alloca { i64, ptr }
  %l440 = alloca i1
  %l441 = alloca ptr
  %l442 = alloca ptr
  %l443 = alloca i32
  %l445 = alloca i64
  %l447 = alloca ptr
  %l448 = alloca %"compiler/typed:TaskClause"
  %l450 = alloca ptr
  %l452 = alloca %"compiler/source:Span"
  %l453 = alloca i64
  %l456 = alloca { i64, ptr }
  %l457 = alloca i1
  %l461 = alloca %"compiler/typed:Clause"
  %l468 = alloca i64
  %l477 = alloca { i64, ptr }
  %l492 = alloca i64
  %l494 = alloca i1
  %l497 = alloca i64
  %l500 = alloca ptr
  %l505 = alloca i64
  %l507 = alloca ptr
  %l508 = alloca %"compiler/source:Span"
  %l509 = alloca ptr
  %l510 = alloca { i64, ptr }
  %l511 = alloca ptr
  %l514 = alloca i32
  %l515 = alloca ptr
  %l516 = alloca %"compiler/source:Span"
  %l518 = alloca { i64, ptr }
  %l519 = alloca ptr
  %l521 = alloca { i64, ptr }
  %l525 = alloca i32
  %l526 = alloca %"compiler/typed:Spawn"
  %l530 = alloca ptr
  %s0 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %t266 = alloca { i64, [3 x i64] }, align 8
  %t1031 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l45, !tbaa !29
  %t2 = load ptr, ptr %l45, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 56
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l45, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 56
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l50
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l50, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 34
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 38
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l57
  br label %bb4
bb3:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb5
bb4:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 37
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l57, !tbaa !24
  %t33 = icmp sle i64 %t31, %t30
  store i1 %t33, ptr %l54, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l54, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l61, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l62
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0)
  store %"compiler/diagmsg:Msg" %t38, ptr %l63
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t39 = load ptr, ptr %l61, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l62
  %t41 = load %"compiler/diagmsg:Msg", ptr %l63
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, %"compiler/diagmsg:Msg" %t41)
  store i64 %t42, ptr %l64
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l65, !tbaa !29
  %t44 = load ptr, ptr %l65, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 56
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = sub i64 %t46, 1
  %t51 = load ptr, ptr %l65, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 56
  store i64 %t49, ptr %t52, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 38
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l71
  br label %bb11
bb11:
  %t58 = load i64, ptr %l71, !tbaa !24
  %t59 = icmp eq i64 %t58, 0
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l73, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t62, ptr %l74
  %t63 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0)
  store %"compiler/diagmsg:Msg" %t63, ptr %l75
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t64 = load ptr, ptr %l73, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l74
  %t66 = load %"compiler/diagmsg:Msg", ptr %l75
  %t67 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t64, %"compiler/source:Span" %t65, %"compiler/diagmsg:Msg" %t66)
  store i64 %t67, ptr %l76
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l77, !tbaa !29
  %t69 = load ptr, ptr %l77, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 56
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = sub i64 %t71, 1
  %t76 = load ptr, ptr %l77, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 56
  store i64 %t74, ptr %t77, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 38
  store ptr %t80, ptr %l82, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 38
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l85
  br label %bb17
bb17:
  %t86 = load i64, ptr %l85, !tbaa !24
  %t87 = sub i64 %t86, 1
  store i64 %t87, ptr %l86, !tbaa !24
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 38
  store ptr %t90, ptr %l88, !tbaa !29
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr %"compiler/check:frame", ptr %t91, i32 0, i32 38
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l91
  br label %bb18
bb18:
  %t96 = load i64, ptr %l91, !tbaa !24
  %t97 = sub i64 %t96, 1
  %t98 = load ptr, ptr %l88, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t98, i64 %t97)
  store i64 %t100, ptr %l93
  br label %bb19
bb19:
  %t101 = load i64, ptr %l93, !tbaa !24
  %t102 = add i64 %t101, 1
  %t103 = load ptr, ptr %l82, !tbaa !29
  %t104 = load i64, ptr %l86, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t103, i64 %t104, i64 %t102)
  br label %bb20
bb20:
  %t106 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l95
  br label %bb21
bb21:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t108
  store ptr %t108, ptr %l5, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t110, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l7, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t124, ptr %l104, !tbaa !27
  %t125 = load i64, ptr %l7, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l107, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t133, ptr %t130)
  store ptr %t137, ptr %l110
  br label %bb26
bb26:
  %t138 = load ptr, ptr %l107, !tbaa !29
  %t139 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t138, ptr %t139)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb22
bb29:
  store i1 false, ptr %l10, !tbaa !21
  %t145 = load ptr, ptr %l3, !tbaa !29
  store ptr %t145, ptr %l11, !tbaa !29
  %t147 = icmp sge i64 0, 0
  br i1 %t147, label %bb30, label %bb31
bb30:
  %t149 = icmp sle i64 0, 1152921504606846975
  br i1 %t149, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb32:
  %t151 = mul i64 0, 8
  %t152 = insertvalue { i64, ptr } undef, i64 0, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t153, ptr %l12, !tbaa !27
  %t155 = load ptr, ptr %l3, !tbaa !29
  store ptr %t155, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t156 = load ptr, ptr %l118, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb34:
  %t159 = load ptr, ptr %l118, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 28}
  %t162 = icmp eq i64 %t160, 19
  store i1 %t162, ptr %l119, !tbaa !21
  br label %bb35
bb35:
  %t163 = load i1, ptr %l119, !tbaa !21
  br i1 %t163, label %bb36, label %bb37
bb36:
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l13, !tbaa !29
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t172, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173
  store { i64, ptr } %t174, ptr %l14, !tbaa !27
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 true, ptr %l10, !tbaa !21
  %t176 = load ptr, ptr %l13, !tbaa !29
  store ptr %t176, ptr %l11, !tbaa !29
  %t178 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t178, ptr %l12, !tbaa !27
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c3afd3921db70d3f_27f9f6390ccac16b)
  unreachable
bb44:
  %t180 = load ptr, ptr %l4, !tbaa !29
  %t182 = getelementptr %"compiler/check:frame", ptr %t180, i32 0, i32 28
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t182)
  store i64 %t184, ptr %l130
  br label %bb45
bb45:
  %t185 = load i64, ptr %l130, !tbaa !24
  store i64 %t185, ptr %l15, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 57
  store i32 0, ptr %t188, !tbaa !23
  %t189 = load ptr, ptr %l4, !tbaa !29
  store ptr %t189, ptr %l132, !tbaa !29
  %t190 = load ptr, ptr %l132, !tbaa !29
  %t191 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 15
  %t192 = load i64, ptr %t191, !tbaa !24
  %t195 = add i64 %t192, 1
  %t197 = load ptr, ptr %l132, !tbaa !29
  %t198 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 15
  store i64 %t195, ptr %t198, !tbaa !24
  store ptr null, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t199 = load ptr, ptr %l11, !tbaa !29
  store ptr %t199, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t200 = load ptr, ptr %l136, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb46, label %bb47
bb46:
  %t203 = load ptr, ptr %l136, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 28}
  %t206 = icmp eq i64 %t204, 20
  store i1 %t206, ptr %l137, !tbaa !21
  br label %bb47
bb47:
  %t207 = load i1, ptr %l137, !tbaa !21
  br i1 %t207, label %bb48, label %bb49
bb48:
  %t208 = load ptr, ptr %l11, !tbaa !29
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr }, ptr %t210, i32 0, i32 0
  %t212 = load %"compiler/source:Span", ptr %t211
  store %"compiler/source:Span" %t212, ptr %l18
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l19, !tbaa !29
  br label %bb50
bb49:
  br label %bb71
bb50:
  %t220 = load ptr, ptr %l19, !tbaa !29
  %t222 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 3
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/ast:Sig", ptr %t223, i32 0, i32 0
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb51, label %bb52
bb51:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l149, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t233, ptr %l150
  %t234 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0)
  store %"compiler/diagmsg:Msg" %t234, ptr %l151
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t235 = load ptr, ptr %l149, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l150
  %t237 = load %"compiler/diagmsg:Msg", ptr %l151
  %t238 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t235, %"compiler/source:Span" %t236, %"compiler/diagmsg:Msg" %t237)
  store i64 %t238, ptr %l152
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l18
  %t241 = load ptr, ptr %l19, !tbaa !29
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v2, ptr %v0, ptr %t239, %"compiler/source:Span" %t240, ptr %t241, i32 %t242)
  store ptr %t247, ptr %l157
  br label %bb56
bb56:
  %t248 = load ptr, ptr %l157, !tbaa !29
  store ptr %t248, ptr %l20, !tbaa !29
  %t249 = load ptr, ptr %l20, !tbaa !29
  %t252 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t249)
  store i32 %t252, ptr %l160
  br label %bb57
bb57:
  %t253 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t254 = load i32, ptr %l160, !tbaa !23
  %t256 = icmp ne i32 %t254, %t253
  br i1 %t256, label %bb58, label %bb59
bb58:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l163, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t259, ptr %l164
  %t260 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t260, ptr %l165
  %t261 = load ptr, ptr %l20, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t261)
  store i32 %t264, ptr %l168
  br label %bb60
bb59:
  br label %bb70
bb60:
  %t265 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [3 x i64] }, ptr %t266, i32 0, i32 0
  store i64 2, ptr %t267
  %t269 = insertvalue { ptr } undef, ptr %t265, 0
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t266, i32 0, i32 1
  store { ptr } %t269, ptr %t270
  %t271 = load { i64, [3 x i64] }, ptr %t266
  %t273 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t271, ptr %t273
  store ptr %t273, ptr %l171, !tbaa !29
  %t274 = icmp sge i64 0, 0
  br i1 %t274, label %bb61, label %bb62
bb61:
  %t276 = icmp sle i64 0, 1152921504606846975
  br i1 %t276, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb63:
  %t278 = mul i64 0, 8
  %t279 = insertvalue { i64, ptr } undef, i64 0, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t280, ptr %l174, !tbaa !27
  %t281 = icmp sge i64 0, 0
  br i1 %t281, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb65:
  %t283 = icmp sle i64 0, 1152921504606846975
  br i1 %t283, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb67:
  %t285 = mul i64 0, 8
  %t286 = insertvalue { i64, ptr } undef, i64 0, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t288 = load ptr, ptr %l163, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l164
  %t290 = load %"compiler/source:Span", ptr %l165
  %t291 = load i32, ptr %l168, !tbaa !23
  %t292 = load ptr, ptr %l171, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t288, %"compiler/source:Span" %t289, %"compiler/source:Span" %t290, i32 %t291, ptr %t292, i64 -1, ptr null, { i64, ptr } %t293, { i64, ptr } %t287)
  store ptr %t295, ptr %l178
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb69:
  %t296 = load ptr, ptr %l178, !tbaa !29
  store ptr %t296, ptr %l16, !tbaa !29
  br label %bb70
bb70:
  br label %bb100
bb71:
  %t298 = load ptr, ptr %l11, !tbaa !29
  store ptr %t298, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t299 = load ptr, ptr %l180, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t302 = load ptr, ptr %l180, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 28}
  %t305 = icmp eq i64 %t303, 10
  store i1 %t305, ptr %l181, !tbaa !21
  br label %bb73
bb73:
  %t306 = load i1, ptr %l181, !tbaa !21
  br i1 %t306, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l11, !tbaa !29
  %t310 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t314 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t307, ptr %t308, i32 %t310)
  store ptr %t314, ptr %l188
  br label %bb77
bb77:
  %t315 = load ptr, ptr %l188, !tbaa !29
  store ptr %t315, ptr %l16, !tbaa !29
  br label %bb100
bb78:
  %t317 = load ptr, ptr %l11, !tbaa !29
  store ptr %t317, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t318 = load ptr, ptr %l190, !tbaa !29
  %t319 = icmp ne ptr %t318, null
  br i1 %t319, label %bb79, label %bb80
bb79:
  %t321 = load ptr, ptr %l190, !tbaa !29
  %t322 = load i64, ptr %t321, !range !{i64 0, i64 28}
  %t324 = icmp eq i64 %t322, 4
  store i1 %t324, ptr %l191, !tbaa !21
  br label %bb80
bb80:
  %t325 = load i1, ptr %l191, !tbaa !21
  br i1 %t325, label %bb81, label %bb82
bb81:
  %t326 = load ptr, ptr %l11, !tbaa !29
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t326, i32 0, i32 1
  %t329 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t328, i32 0, i32 1
  %t330 = load i32, ptr %t329, !range !{i32 0, i32 116}
  store i32 %t330, ptr %l21
  %t332 = load ptr, ptr %l11, !tbaa !29
  %t334 = getelementptr { i64, [4 x i64] }, ptr %t332, i32 0, i32 1
  %t335 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t334, i32 0, i32 2
  %t336 = load ptr, ptr %t335
  store ptr %t336, ptr %l22, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  %t338 = load i32, ptr %l21, !range !{i32 0, i32 116}
  %t340 = trunc i64 97 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %l22, !tbaa !29
  %t345 = call i1 @compiler_2fcheck_2ecallLike(ptr %v2, ptr %t343)
  store i1 %t345, ptr %l202
  br label %bb86
bb85:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb87
bb86:
  %t346 = load i1, ptr %l202, !tbaa !21
  store i1 %t346, ptr %l200, !tbaa !21
  br label %bb87
bb87:
  %t347 = load i1, ptr %l200, !tbaa !21
  br i1 %t347, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l17, !tbaa !21
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l11, !tbaa !29
  %t351 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t355 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t348, ptr %t349, i32 %t351)
  store ptr %t355, ptr %l207
  br label %bb90
bb89:
  br label %bb91
bb90:
  %t356 = load ptr, ptr %l207, !tbaa !29
  store ptr %t356, ptr %l16, !tbaa !29
  br label %bb100
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb99
bb94:
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l209, !tbaa !29
  %t359 = load ptr, ptr %l11, !tbaa !29
  %t361 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t359)
  store %"compiler/source:Span" %t361, ptr %l211
  br label %bb95
bb95:
  %t362 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0)
  store %"compiler/diagmsg:Msg" %t362, ptr %l212
  br label %bb96
bb96:
  %t363 = load ptr, ptr %l209, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l211
  %t365 = load %"compiler/diagmsg:Msg", ptr %l212
  %t366 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t363, %"compiler/source:Span" %t364, %"compiler/diagmsg:Msg" %t365)
  store i64 %t366, ptr %l213
  br label %bb97
bb97:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l11, !tbaa !29
  %t370 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t374 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t367, ptr %t368, i32 %t370)
  store ptr %t374, ptr %l218
  br label %bb98
bb98:
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_5ca7d448b00003f5_5d17299a767670c1)
  unreachable
bb100:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t375)
  store ptr %t377, ptr %l220
  br label %bb101
bb101:
  %t378 = load ptr, ptr %l220, !tbaa !29
  store ptr %t378, ptr %l4, !tbaa !29
  %t379 = load ptr, ptr %l4, !tbaa !29
  store ptr %t379, ptr %l221, !tbaa !29
  %t380 = load ptr, ptr %l221, !tbaa !29
  %t381 = getelementptr %"compiler/check:frame", ptr %t380, i32 0, i32 15
  %t382 = load i64, ptr %t381, !tbaa !24
  %t385 = sub i64 %t382, 1
  %t387 = load ptr, ptr %l221, !tbaa !29
  %t388 = getelementptr %"compiler/check:frame", ptr %t387, i32 0, i32 15
  store i64 %t385, ptr %t388, !tbaa !24
  %t389 = load i1, ptr %l10, !tbaa !21
  br i1 %t389, label %bb102, label %bb103
bb102:
  %t391 = load ptr, ptr %l16, !tbaa !29
  %t393 = icmp eq ptr %t391, null
  %t395 = xor i1 %t393, true
  store i1 %t395, ptr %l226, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb104
bb104:
  %t397 = load i1, ptr %l226, !tbaa !21
  br i1 %t397, label %bb105, label %bb106
bb105:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l230, !tbaa !29
  %t399 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t399, ptr %l231, !tbaa !27
  %t400 = load i64, ptr %l15, !tbaa !24
  store i64 %t400, ptr %l232, !tbaa !24
  %t401 = load ptr, ptr %l4, !tbaa !29
  %t403 = getelementptr %"compiler/check:frame", ptr %t401, i32 0, i32 28
  %t405 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t403)
  store i64 %t405, ptr %l235
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t406 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 1
  %t408 = call ptr @__olang_scope_of(ptr %t407, ptr null)
  %t409 = call ptr @__olang_scope_hold(ptr %t408)
  %t410 = ptrtoint ptr %t409 to i64
  %t412 = inttoptr i64 %t410 to ptr
  %t413 = load ptr, ptr %l230, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t415 = load i64, ptr %l232, !tbaa !24
  %t416 = load i64, ptr %l235, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %t412, ptr %t413, { i64, ptr } %t414, i64 %t415, i64 %t416)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t417 = load ptr, ptr %l4, !tbaa !29
  %t419 = getelementptr %"compiler/check:frame", ptr %t417, i32 0, i32 28
  %t420 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t419, i64 %t420)
  br label %bb110
bb110:
  %t423 = load ptr, ptr %l16, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  br i1 %t425, label %bb111, label %bb112
bb111:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l242, !tbaa !29
  %t428 = load ptr, ptr %l242, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 56
  %t430 = load i64, ptr %t429, !tbaa !24
  %t433 = sub i64 %t430, 1
  %t435 = load ptr, ptr %l242, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 56
  store i64 %t433, ptr %t436, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  br label %bb113
bb113:
  %t437 = load ptr, ptr %l16, !tbaa !29
  %t439 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t437)
  store i1 %t439, ptr %l247
  br label %bb114
bb114:
  %t440 = load i1, ptr %l247, !tbaa !21
  br i1 %t440, label %bb115, label %bb116
bb115:
  %t441 = load ptr, ptr %l0, !tbaa !29
  store ptr %t441, ptr %l248, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t442, ptr %l249, !tbaa !27
  %t443 = load ptr, ptr %l3, !tbaa !29
  store ptr %t443, ptr %l250, !tbaa !29
  %t444 = load ptr, ptr %l11, !tbaa !29
  store ptr %t444, ptr %l251, !tbaa !29
  %t445 = load ptr, ptr %l16, !tbaa !29
  %t448 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t445)
  store i32 %t448, ptr %l254
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t449 = load ptr, ptr %l248, !tbaa !29
  %t450 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t451 = load ptr, ptr %l250, !tbaa !29
  %t452 = load ptr, ptr %l251, !tbaa !29
  %t453 = load i32, ptr %l254, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t449, { i64, ptr } %t450, ptr %t451, ptr %t452, i32 %t453)
  br label %bb118
bb118:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l255, !tbaa !29
  %t455 = load ptr, ptr %l255, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 56
  %t457 = load i64, ptr %t456, !tbaa !24
  %t460 = sub i64 %t457, 1
  %t462 = load ptr, ptr %l255, !tbaa !29
  %t463 = getelementptr %"compiler/check:Checker", ptr %t462, i32 0, i32 56
  store i64 %t460, ptr %t463, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb119:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load ptr, ptr %l16, !tbaa !29
  %t468 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerCall(ptr %v0, ptr %v0, ptr %t464, ptr %t465)
  store i1 %t468, ptr %l261
  br label %bb120
bb120:
  %t469 = load i1, ptr %l261, !tbaa !21
  br i1 %t469, label %bb121, label %bb122
bb121:
  %t470 = load ptr, ptr %l0, !tbaa !29
  store ptr %t470, ptr %l262, !tbaa !29
  %t471 = load ptr, ptr %l11, !tbaa !29
  %t473 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t471)
  store %"compiler/source:Span" %t473, ptr %l264
  br label %bb123
bb122:
  br label %bb126
bb123:
  %t474 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCFuncTask(ptr %v0)
  store %"compiler/diagmsg:Msg" %t474, ptr %l265
  br label %bb124
bb124:
  %t475 = load ptr, ptr %l262, !tbaa !29
  %t476 = load %"compiler/source:Span", ptr %l264
  %t477 = load %"compiler/diagmsg:Msg", ptr %l265
  %t478 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t475, %"compiler/source:Span" %t476, %"compiler/diagmsg:Msg" %t477)
  store i64 %t478, ptr %l266
  br label %bb125
bb125:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l267, !tbaa !29
  %t480 = load ptr, ptr %l267, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 56
  %t482 = load i64, ptr %t481, !tbaa !24
  %t485 = sub i64 %t482, 1
  %t487 = load ptr, ptr %l267, !tbaa !29
  %t488 = getelementptr %"compiler/check:Checker", ptr %t487, i32 0, i32 56
  store i64 %t485, ptr %t488, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb126:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/generic:Program", ptr %t492, i32 0, i32 2
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 57
  %t498 = load i32, ptr %t497, !tbaa !23
  %t501 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t494, i32 %t498)
  store { i64, ptr } %t501, ptr %l276
  br label %bb127
bb127:
  %t502 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t502, ptr %l23, !tbaa !27
  %t503 = load i1, ptr %l17, !tbaa !21
  br i1 %t503, label %bb128, label %bb129
bb128:
  %t505 = icmp sge i64 0, 0
  br i1 %t505, label %bb130, label %bb131
bb129:
  br label %bb134
bb130:
  %t507 = icmp sle i64 0, 2305843009213693951
  br i1 %t507, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb132:
  %t509 = mul i64 0, 4
  %t510 = insertvalue { i64, ptr } undef, i64 0, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t511, ptr %l23, !tbaa !27
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb134:
  %t513 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t517 = icmp sgt i64 %t515, 0
  br i1 %t517, label %bb135, label %bb136
bb135:
  %t519 = load i1, ptr %l10, !tbaa !21
  %t521 = xor i1 %t519, true
  store i1 %t521, ptr %l284, !tbaa !21
  br label %bb137
bb136:
  store i1 false, ptr %l284, !tbaa !21
  br label %bb137
bb137:
  %t523 = load i1, ptr %l284, !tbaa !21
  br i1 %t523, label %bb138, label %bb139
bb138:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l287, !tbaa !29
  %t525 = load ptr, ptr %l11, !tbaa !29
  %t527 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t525)
  store %"compiler/source:Span" %t527, ptr %l289
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t528 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0)
  store %"compiler/diagmsg:Msg" %t528, ptr %l290
  br label %bb141
bb141:
  %t529 = load ptr, ptr %l287, !tbaa !29
  %t530 = load %"compiler/source:Span", ptr %l289
  %t531 = load %"compiler/diagmsg:Msg", ptr %l290
  %t532 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t529, %"compiler/source:Span" %t530, %"compiler/diagmsg:Msg" %t531)
  store i64 %t532, ptr %l291
  br label %bb142
bb142:
  %t533 = load ptr, ptr %l4, !tbaa !29
  store ptr %t533, ptr %l292, !tbaa !29
  %t534 = load ptr, ptr %l292, !tbaa !29
  %t535 = getelementptr %"compiler/check:frame", ptr %t534, i32 0, i32 41
  %t536 = load i64, ptr %t535, !tbaa !24
  %t539 = add i64 %t536, 1
  %t541 = load ptr, ptr %l292, !tbaa !29
  %t542 = getelementptr %"compiler/check:frame", ptr %t541, i32 0, i32 41
  store i64 %t539, ptr %t542, !tbaa !24
  br label %bb143
bb143:
  %t543 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t547 = icmp eq i64 %t545, 0
  br i1 %t547, label %bb144, label %bb145
bb144:
  %t549 = load i1, ptr %l10, !tbaa !21
  store i1 %t549, ptr %l299, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb146
bb146:
  %t551 = load i1, ptr %l299, !tbaa !21
  br i1 %t551, label %bb147, label %bb148
bb147:
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l301, !tbaa !29
  %t553 = load ptr, ptr %l3, !tbaa !29
  %t555 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t553)
  store %"compiler/source:Span" %t555, ptr %l303
  br label %bb149
bb148:
  br label %bb152
bb149:
  %t556 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0)
  store %"compiler/diagmsg:Msg" %t556, ptr %l304
  br label %bb150
bb150:
  %t557 = load ptr, ptr %l301, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l303
  %t559 = load %"compiler/diagmsg:Msg", ptr %l304
  %t560 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t557, %"compiler/source:Span" %t558, %"compiler/diagmsg:Msg" %t559)
  store i64 %t560, ptr %l305
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t561 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t561, ptr %l306
  br label %bb153
bb153:
  %t562 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l306
  %t563 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t562, ptr %t563
  store ptr %t563, ptr %l24, !tbaa !29
  %t565 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t565, ptr %l308
  br label %bb154
bb154:
  %t566 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l308
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %l25
  %t567 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t571 = icmp sgt i64 %t569, 0
  br i1 %t571, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s26
  %t573 = load ptr, ptr %l16, !tbaa !29
  %t576 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t573)
  store i32 %t576, ptr %l314
  br label %bb157
bb156:
  br label %bb244
bb157:
  %t577 = load i32, ptr %l314, !tbaa !23
  store i32 %t577, ptr %l26, !tbaa !23
  %t578 = load ptr, ptr %l5, !tbaa !29
  %t580 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t578)
  store i64 %t580, ptr %l316
  br label %bb158
bb158:
  %t581 = load i64, ptr %l316, !tbaa !24
  %t582 = icmp eq i64 %t581, 1
  br i1 %t582, label %bb159, label %bb160
bb159:
  %t584 = load ptr, ptr %l5, !tbaa !29
  %t586 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s26, ptr %t584, i64 0)
  store ptr %t586, ptr %l320
  br label %bb161
bb160:
  store i1 false, ptr %l318, !tbaa !21
  br label %bb162
bb161:
  %t587 = load ptr, ptr %l320, !tbaa !29
  %t588 = icmp eq ptr %t587, null
  %t590 = xor i1 %t588, true
  store i1 %t590, ptr %l318, !tbaa !21
  br label %bb162
bb162:
  %t592 = load i1, ptr %l318, !tbaa !21
  br i1 %t592, label %bb163, label %bb164
bb163:
  %t593 = load ptr, ptr %l5, !tbaa !29
  %t595 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t593, i64 0)
  store ptr %t595, ptr %l324
  br label %bb165
bb164:
  br label %bb188
bb165:
  %t596 = load ptr, ptr %l324, !tbaa !29
  store ptr %t596, ptr %l27, !tbaa !29
  %t597 = load ptr, ptr %l27, !tbaa !29
  %t599 = icmp eq ptr %t597, null
  br i1 %t599, label %bb166, label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_ebab815881a318c_398bac8a238c0b80)
  unreachable
bb167:
  br label %bb168
bb168:
  %t601 = load ptr, ptr %l27, !tbaa !29
  %t603 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t601)
  store i32 %t603, ptr %l328
  br label %bb169
bb169:
  %t604 = load i32, ptr %l328, !tbaa !23
  store i32 %t604, ptr %l28, !tbaa !23
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l26, !tbaa !23
  %t609 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t605, i32 %t606)
  store i1 %t609, ptr %l331
  br label %bb170
bb170:
  %t610 = load i1, ptr %l331, !tbaa !21
  br i1 %t610, label %bb171, label %bb172
bb171:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load i32, ptr %l28, !tbaa !23
  %t615 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t611, i32 %t612)
  store i1 %t615, ptr %l335
  br label %bb173
bb172:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb174
bb173:
  %t616 = load i1, ptr %l335, !tbaa !21
  store i1 %t616, ptr %l332, !tbaa !21
  br label %bb174
bb174:
  %t617 = load i1, ptr %l332, !tbaa !21
  br i1 %t617, label %bb175, label %bb176
bb175:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !29
  %t623 = getelementptr %"compiler/generic:Program", ptr %t621, i32 0, i32 2
  %t624 = load i32, ptr %l28, !tbaa !23
  %t627 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t623, i32 %t624)
  store i1 %t627, ptr %l341
  br label %bb177
bb176:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb178
bb177:
  %t628 = load i1, ptr %l341, !tbaa !21
  store i1 %t628, ptr %l336, !tbaa !21
  br label %bb178
bb178:
  %t629 = load i1, ptr %l336, !tbaa !21
  br i1 %t629, label %bb179, label %bb180
bb179:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/check:Checker", ptr %t630, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !29
  %t635 = getelementptr %"compiler/generic:Program", ptr %t633, i32 0, i32 2
  %t636 = load i32, ptr %l28, !tbaa !23
  %t639 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t635, i32 %t636)
  store i32 %t639, ptr %l347
  br label %bb181
bb180:
  store i1 false, ptr %l342, !tbaa !21
  br label %bb183
bb181:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/check:Checker", ptr %t640, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !29
  %t645 = getelementptr %"compiler/generic:Program", ptr %t643, i32 0, i32 2
  %t646 = load i32, ptr %l26, !tbaa !23
  %t649 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t645, i32 %t646)
  store i32 %t649, ptr %l352
  br label %bb182
bb182:
  %t650 = load i32, ptr %l347, !tbaa !23
  %t651 = load i32, ptr %l352, !tbaa !23
  %t652 = icmp eq i32 %t650, %t651
  store i1 %t652, ptr %l342, !tbaa !21
  br label %bb183
bb183:
  %t654 = load i1, ptr %l342, !tbaa !21
  br i1 %t654, label %bb184, label %bb185
bb184:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/check:Checker", ptr %t655, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !29
  %t660 = getelementptr %"compiler/generic:Program", ptr %t658, i32 0, i32 2
  %t661 = load i32, ptr %l26, !tbaa !23
  %t664 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t660, i32 %t661)
  store i32 %t664, ptr %l358
  br label %bb186
bb185:
  br label %bb187
bb186:
  %t665 = load i32, ptr %l358, !tbaa !23
  store i32 %t665, ptr %l26, !tbaa !23
  br label %bb187
bb187:
  br label %bb188
bb188:
  %t666 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t666, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t668 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  store i64 %t670, ptr %l31, !tbaa !24
  br label %bb189
bb189:
  store %olang.scope zeroinitializer, ptr %s30
  %t672 = load i64, ptr %l30, !tbaa !24
  %t673 = load i64, ptr %l31, !tbaa !24
  %t676 = icmp slt i64 %t672, %t673
  %t678 = xor i1 %t676, true
  br i1 %t678, label %bb190, label %bb191
bb190:
  call void @__olang_scope_close(ptr %s30)
  br label %bb243
bb191:
  br label %bb192
bb192:
  %t680 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t680, ptr %l366, !tbaa !27
  %t681 = load i64, ptr %l30, !tbaa !24
  %t683 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr ptr, ptr %t684, i64 %t681
  %t686 = load ptr, ptr %t685, !tbaa !39
  store ptr %t686, ptr %l32, !tbaa !29
  %t688 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %s30, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t688, ptr %l369
  br label %bb193
bb193:
  %t689 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l369
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t689, ptr %l33
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l32, !tbaa !29
  store ptr %t691, ptr %l371, !tbaa !29
  %t692 = load ptr, ptr %l371, !tbaa !29
  %t693 = call ptr @__olang_scope_of(ptr %t692, ptr null)
  %t694 = call ptr @__olang_scope_hold(ptr %t693)
  %t695 = ptrtoint ptr %t694 to i64
  %t697 = inttoptr i64 %t695 to ptr
  %t699 = load ptr, ptr %l371, !tbaa !29
  %t700 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %t697, ptr %t690, ptr %t699)
  store i1 %t700, ptr %l373
  br label %bb194
bb194:
  %t701 = load i1, ptr %l373, !tbaa !21
  store i1 %t701, ptr %l34, !tbaa !21
  %t702 = load ptr, ptr %l32, !tbaa !29
  %t704 = getelementptr %"compiler/ast:Catch", ptr %t702, i32 0, i32 1
  %t705 = load { i64, ptr }, ptr %t704, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t705, 0
  %t709 = icmp sgt i64 %t707, 0
  br i1 %t709, label %bb195, label %bb196
bb195:
  %t711 = load i1, ptr %l34, !tbaa !21
  %t713 = xor i1 %t711, true
  store i1 %t713, ptr %l378, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l378, !tbaa !21
  br label %bb197
bb197:
  %t715 = load i1, ptr %l378, !tbaa !21
  br i1 %t715, label %bb198, label %bb199
bb198:
  %t716 = load ptr, ptr %l32, !tbaa !29
  %t718 = getelementptr %"compiler/ast:Catch", ptr %t716, i32 0, i32 1
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  store { i64, ptr } %t719, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t721 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t721, 0
  store i64 %t723, ptr %l37, !tbaa !24
  br label %bb200
bb199:
  br label %bb207
bb200:
  %t725 = load i64, ptr %l36, !tbaa !24
  %t726 = load i64, ptr %l37, !tbaa !24
  %t729 = icmp slt i64 %t725, %t726
  %t731 = xor i1 %t729, true
  br i1 %t731, label %bb201, label %bb202
bb201:
  br label %bb206
bb202:
  br label %bb203
bb203:
  %t733 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t733, ptr %l389, !tbaa !27
  %t734 = load i64, ptr %l36, !tbaa !24
  %t736 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t737 = load ptr, ptr %t736, !tbaa !27
  %t738 = getelementptr ptr, ptr %t737, i64 %t734
  %t739 = load ptr, ptr %t738, !tbaa !39
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t739, ptr %l393, !tbaa !29
  %t743 = load ptr, ptr %l393, !tbaa !29
  %t744 = call ptr @__olang_scope_of(ptr %t743, ptr null)
  %t745 = call ptr @__olang_scope_hold(ptr %t744)
  %t746 = ptrtoint ptr %t745 to i64
  %t748 = inttoptr i64 %t746 to ptr
  %t750 = load ptr, ptr %l393, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %t748, ptr %s30, ptr %t741, ptr %t750, ptr %l33)
  br label %bb204
bb204:
  br label %bb205
bb205:
  %t752 = load i64, ptr %l36, !tbaa !24
  %t755 = add i64 %t752, 1
  store i64 %t755, ptr %l36, !tbaa !24
  br label %bb200
bb206:
  br label %bb207
bb207:
  %t757 = load ptr, ptr %l32, !tbaa !29
  %t759 = getelementptr %"compiler/ast:Catch", ptr %t757, i32 0, i32 5
  %t760 = load i32, ptr %t759, !tbaa !23
  %t762 = icmp ne i32 %t760, 0
  br i1 %t762, label %bb208, label %bb209
bb208:
  store i1 true, ptr %l402, !tbaa !21
  br label %bb210
bb209:
  %t764 = load i1, ptr %l34, !tbaa !21
  store i1 %t764, ptr %l402, !tbaa !21
  br label %bb210
bb210:
  %t766 = load i1, ptr %l402, !tbaa !21
  br i1 %t766, label %bb211, label %bb212
bb211:
  store %olang.scope zeroinitializer, ptr %s35
  %t767 = load ptr, ptr %l0, !tbaa !29
  store ptr %t767, ptr %l404, !tbaa !29
  %t768 = load i1, ptr %l34, !tbaa !21
  br i1 %t768, label %bb213, label %bb214
bb212:
  br label %bb222
bb213:
  %t770 = load ptr, ptr %l32, !tbaa !29
  %t772 = getelementptr %"compiler/ast:Catch", ptr %t770, i32 0, i32 1
  %t773 = load { i64, ptr }, ptr %t772, !tbaa !27
  store { i64, ptr } %t773, ptr %l408, !tbaa !27
  %t774 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr ptr, ptr %t775, i64 0
  %t777 = load ptr, ptr %t776, !tbaa !39
  %t779 = getelementptr %"compiler/ast:Path", ptr %t777, i32 0, i32 0
  %t780 = load %"compiler/source:Span", ptr %t779
  store %"compiler/source:Span" %t780, ptr %l406
  br label %bb215
bb214:
  %t782 = load ptr, ptr %l32, !tbaa !29
  %t784 = getelementptr %"compiler/ast:Catch", ptr %t782, i32 0, i32 6
  %t785 = load %"compiler/source:Span", ptr %t784
  store %"compiler/source:Span" %t785, ptr %l406
  br label %bb215
bb215:
  %t787 = load ptr, ptr %l0, !tbaa !29
  store ptr %t787, ptr %l413, !tbaa !29
  %t788 = load i1, ptr %l34, !tbaa !21
  br i1 %t788, label %bb216, label %bb217
bb216:
  %t790 = load ptr, ptr %l32, !tbaa !29
  %t792 = getelementptr %"compiler/ast:Catch", ptr %t790, i32 0, i32 1
  %t793 = load { i64, ptr }, ptr %t792, !tbaa !27
  store { i64, ptr } %t793, ptr %l417, !tbaa !27
  %t794 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !27
  %t796 = getelementptr ptr, ptr %t795, i64 0
  %t797 = load ptr, ptr %t796, !tbaa !39
  %t799 = getelementptr %"compiler/ast:Path", ptr %t797, i32 0, i32 1
  %t800 = load { i64, ptr }, ptr %t799, !tbaa !27
  store { i64, ptr } %t800, ptr %l419, !tbaa !27
  %t801 = getelementptr { i64, ptr }, ptr %l419, i32 0, i32 1
  %t802 = load ptr, ptr %t801, !tbaa !27
  %t803 = getelementptr i32, ptr %t802, i64 0
  %t804 = load i32, ptr %t803, !tbaa !33
  store i32 %t804, ptr %l415, !tbaa !23
  br label %bb218
bb217:
  %t806 = load ptr, ptr %l32, !tbaa !29
  %t808 = getelementptr %"compiler/ast:Catch", ptr %t806, i32 0, i32 5
  %t809 = load i32, ptr %t808, !tbaa !23
  store i32 %t809, ptr %l415, !tbaa !23
  br label %bb218
bb218:
  %t811 = load ptr, ptr %l413, !tbaa !29
  %t812 = load i32, ptr %l415, !tbaa !23
  %t813 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s35, ptr %t811, i32 %t812)
  store { i64, ptr } %t813, ptr %l423
  br label %bb219
bb219:
  %t814 = load { i64, ptr }, ptr %l423, !tbaa !27
  %t816 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %s35, ptr %v0, { i64, ptr } %t814)
  store %"compiler/diagmsg:Msg" %t816, ptr %l425
  br label %bb220
bb220:
  %t817 = load ptr, ptr %l404, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l406
  %t819 = load %"compiler/diagmsg:Msg", ptr %l425
  %t820 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t817, %"compiler/source:Span" %t818, %"compiler/diagmsg:Msg" %t819)
  store i64 %t820, ptr %l426
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s35)
  br label %bb222
bb222:
  %t821 = load ptr, ptr %l32, !tbaa !29
  %t823 = getelementptr %"compiler/ast:Catch", ptr %t821, i32 0, i32 1
  %t824 = load { i64, ptr }, ptr %t823, !tbaa !27
  %t826 = extractvalue { i64, ptr } %t824, 0
  %t828 = icmp eq i64 %t826, 0
  br i1 %t828, label %bb223, label %bb224
bb223:
  store i1 true, ptr %l431, !tbaa !21
  br label %bb225
bb224:
  %t830 = load i1, ptr %l34, !tbaa !21
  store i1 %t830, ptr %l431, !tbaa !21
  br label %bb225
bb225:
  %t832 = load i1, ptr %l431, !tbaa !21
  store i1 %t832, ptr %l39, !tbaa !21
  %t833 = load ptr, ptr %l24, !tbaa !29
  store ptr %t833, ptr %l433, !tbaa !29
  %t834 = load ptr, ptr %l32, !tbaa !29
  %t836 = getelementptr %"compiler/ast:Catch", ptr %t834, i32 0, i32 0
  %t837 = load %"compiler/source:Span", ptr %t836
  store %"compiler/source:Span" %t837, ptr %l435
  %t838 = call ptr @__olang_scope_hold(ptr %v0)
  %t839 = ptrtoint ptr %t838 to i64
  store i64 %t839, ptr %l436, !tbaa !24
  %t840 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aTaskClause_2e1
  br i1 %t840, label %bb226, label %bb227
bb226:
  %t842 = call ptr @__olang_region_make(ptr %v0)
  %t843 = ptrtoint ptr %t842 to i64
  store i64 %t843, ptr %l436, !tbaa !24
  br label %bb227
bb227:
  %t844 = load i64, ptr %l436
  %t845 = inttoptr i64 %t844 to ptr
  %t847 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s30, ptr %t845, ptr %l33)
  store { i64, ptr } %t847, ptr %l439
  br label %bb228
bb228:
  %t848 = load i1, ptr %l39, !tbaa !21
  store i1 %t848, ptr %l440, !tbaa !21
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l441, !tbaa !29
  %t850 = load ptr, ptr %l32, !tbaa !29
  store ptr %t850, ptr %l442, !tbaa !29
  %t851 = load i32, ptr %l26, !tbaa !23
  store i32 %t851, ptr %l443, !tbaa !23
  %t852 = load ptr, ptr %l5, !tbaa !29
  %t854 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t852)
  store i64 %t854, ptr %l445
  br label %bb229
bb229:
  %t855 = load ptr, ptr %l442, !tbaa !29
  %t856 = call ptr @__olang_scope_of(ptr %t855, ptr null)
  %t857 = call ptr @__olang_scope_hold(ptr %t856)
  %t858 = ptrtoint ptr %t857 to i64
  %t860 = inttoptr i64 %t858 to ptr
  %t861 = load ptr, ptr %l441, !tbaa !29
  %t862 = load ptr, ptr %l442, !tbaa !29
  %t863 = load i32, ptr %l443, !tbaa !23
  %t864 = load i64, ptr %l445, !tbaa !24
  %t865 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %t860, ptr %v0, ptr %t861, ptr %t862, i32 %t863, i64 %t864)
  store ptr %t865, ptr %l447
  br label %bb230
bb230:
  %t866 = load %"compiler/source:Span", ptr %l435
  %t867 = load { i64, ptr }, ptr %l439, !tbaa !27
  %t868 = load i1, ptr %l440, !tbaa !21
  %t869 = load ptr, ptr %l447, !tbaa !29
  %t870 = call %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t866, { i64, ptr } %t867, i1 %t868, ptr %t869)
  store %"compiler/typed:TaskClause" %t870, ptr %l448
  br label %bb231
bb231:
  %t871 = load %"compiler/typed:TaskClause", ptr %l448
  %t872 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/typed:TaskClause" %t871, ptr %t872
  %t873 = load ptr, ptr %l433, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v0, ptr %t873, ptr %t872)
  br label %bb232
bb232:
  store ptr %l25, ptr %l450, !tbaa !29
  %t875 = load ptr, ptr %l32, !tbaa !29
  %t877 = getelementptr %"compiler/ast:Catch", ptr %t875, i32 0, i32 0
  %t878 = load %"compiler/source:Span", ptr %t877
  store %"compiler/source:Span" %t878, ptr %l452
  %t879 = call ptr @__olang_scope_hold(ptr %s0)
  %t880 = ptrtoint ptr %t879 to i64
  store i64 %t880, ptr %l453, !tbaa !24
  %t881 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aClause_2e1
  br i1 %t881, label %bb233, label %bb234
bb233:
  %t883 = call ptr @__olang_region_make(ptr %s0)
  %t884 = ptrtoint ptr %t883 to i64
  store i64 %t884, ptr %l453, !tbaa !24
  br label %bb234
bb234:
  %t885 = load i64, ptr %l453
  %t886 = inttoptr i64 %t885 to ptr
  %t888 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s30, ptr %t886, ptr %l33)
  store { i64, ptr } %t888, ptr %l456
  br label %bb235
bb235:
  %t889 = load i1, ptr %l39, !tbaa !21
  store i1 %t889, ptr %l457, !tbaa !21
  %t890 = icmp sge i64 0, 0
  br i1 %t890, label %bb236, label %bb237
bb236:
  %t892 = icmp sle i64 0, 1152921504606846975
  br i1 %t892, label %bb238, label %bb239
bb237:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb238:
  %t894 = mul i64 0, 8
  %t895 = insertvalue { i64, ptr } undef, i64 0, 0
  %t896 = insertvalue { i64, ptr } %t895, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t897 = load %"compiler/source:Span", ptr %l452
  %t898 = load { i64, ptr }, ptr %l456, !tbaa !27
  %t899 = load i1, ptr %l457, !tbaa !21
  %t901 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, %"compiler/source:Span" %t897, { i64, ptr } %t898, i1 %t899, ptr null, { i64, ptr } %t896, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t901, ptr %l461
  br label %bb240
bb239:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb240:
  %t902 = load %"compiler/typed:Clause", ptr %l461
  %t903 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t902, ptr %t903
  %t904 = load ptr, ptr %l450, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s0, ptr %s0, ptr %t904, ptr %t903)
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s30)
  br label %bb242
bb242:
  %t906 = load i64, ptr %l30, !tbaa !24
  %t909 = add i64 %t906, 1
  store i64 %t909, ptr %l30, !tbaa !24
  br label %bb189
bb243:
  call void @__olang_scope_close(ptr %s26)
  br label %bb244
bb244:
  %t911 = load ptr, ptr %l4, !tbaa !29
  %t913 = getelementptr %"compiler/check:frame", ptr %t911, i32 0, i32 40
  %t915 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t913)
  store i64 %t915, ptr %l468
  br label %bb245
bb245:
  %t916 = load i64, ptr %l468, !tbaa !24
  store i64 %t916, ptr %l40, !tbaa !24
  %t917 = load i1, ptr %l10, !tbaa !21
  br i1 %t917, label %bb246, label %bb247
bb246:
  %t919 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t919, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t921 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t921, 0
  store i64 %t923, ptr %l43, !tbaa !24
  br label %bb248
bb247:
  br label %bb255
bb248:
  %t925 = load i64, ptr %l42, !tbaa !24
  %t926 = load i64, ptr %l43, !tbaa !24
  %t929 = icmp slt i64 %t925, %t926
  %t931 = xor i1 %t929, true
  br i1 %t931, label %bb249, label %bb250
bb249:
  br label %bb254
bb250:
  br label %bb251
bb251:
  %t933 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t933, ptr %l477, !tbaa !27
  %t934 = load i64, ptr %l42, !tbaa !24
  %t936 = getelementptr { i64, ptr }, ptr %l477, i32 0, i32 1
  %t937 = load ptr, ptr %t936, !tbaa !27
  %t938 = getelementptr i32, ptr %t937, i64 %t934
  %t939 = load i32, ptr %t938, !tbaa !33
  %t941 = load ptr, ptr %l4, !tbaa !29
  %t943 = getelementptr %"compiler/check:frame", ptr %t941, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t943, i32 %t939)
  br label %bb252
bb252:
  br label %bb253
bb253:
  %t947 = load i64, ptr %l42, !tbaa !24
  %t950 = add i64 %t947, 1
  store i64 %t950, ptr %l42, !tbaa !24
  br label %bb248
bb254:
  br label %bb255
bb255:
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t953 = load ptr, ptr %l4, !tbaa !29
  %t955 = getelementptr %"compiler/check:frame", ptr %t953, i32 0, i32 40
  %t956 = load i64, ptr %l40, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v0, ptr %s0, ptr %t952, ptr %t955, i64 %t956, ptr %l25)
  br label %bb256
bb256:
  %t961 = load ptr, ptr %l5, !tbaa !29
  %t963 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t961)
  store i64 %t963, ptr %l492
  br label %bb257
bb257:
  %t964 = load i64, ptr %l492, !tbaa !24
  %t965 = icmp sgt i64 %t964, 0
  br i1 %t965, label %bb258, label %bb259
bb258:
  %t967 = load ptr, ptr %l4, !tbaa !29
  %t969 = getelementptr %"compiler/check:frame", ptr %t967, i32 0, i32 40
  %t971 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t969)
  store i64 %t971, ptr %l497
  br label %bb260
bb259:
  store i1 false, ptr %l494, !tbaa !21
  br label %bb261
bb260:
  %t972 = load i64, ptr %l40, !tbaa !24
  %t973 = load i64, ptr %l497, !tbaa !24
  %t975 = icmp sgt i64 %t973, %t972
  store i1 %t975, ptr %l494, !tbaa !21
  br label %bb261
bb261:
  %t977 = load i1, ptr %l494, !tbaa !21
  br i1 %t977, label %bb262, label %bb263
bb262:
  %t978 = load ptr, ptr %l4, !tbaa !29
  store ptr %t978, ptr %l500, !tbaa !29
  %t979 = load ptr, ptr %l500, !tbaa !29
  %t980 = getelementptr %"compiler/check:frame", ptr %t979, i32 0, i32 33
  %t981 = load i64, ptr %t980, !tbaa !24
  %t984 = add i64 %t981, 1
  %t986 = load ptr, ptr %l500, !tbaa !29
  %t987 = getelementptr %"compiler/check:frame", ptr %t986, i32 0, i32 33
  store i64 %t984, ptr %t987, !tbaa !24
  br label %bb264
bb263:
  br label %bb264
bb264:
  %t988 = load ptr, ptr %l5, !tbaa !29
  %t990 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t988)
  store i64 %t990, ptr %l505
  br label %bb265
bb265:
  %t991 = load i64, ptr %l505, !tbaa !24
  %t992 = icmp sgt i64 %t991, 0
  br i1 %t992, label %bb266, label %bb267
bb266:
  %t994 = load ptr, ptr %l0, !tbaa !29
  store ptr %t994, ptr %l507, !tbaa !29
  %t995 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t995, ptr %l508
  %t996 = load ptr, ptr %l3, !tbaa !29
  store ptr %t996, ptr %l509, !tbaa !29
  %t997 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t997, ptr %l510, !tbaa !27
  %t998 = load ptr, ptr %l5, !tbaa !29
  store ptr %t998, ptr %l511, !tbaa !29
  %t999 = load ptr, ptr %l16, !tbaa !29
  %t1002 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t999)
  store i32 %t1002, ptr %l514
  br label %bb268
bb267:
  br label %bb270
bb268:
  %t1003 = load ptr, ptr %l507, !tbaa !29
  %t1004 = load %"compiler/source:Span", ptr %l508
  %t1005 = load ptr, ptr %l509, !tbaa !29
  %t1006 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1007 = load ptr, ptr %l511, !tbaa !29
  %t1008 = load i32, ptr %l514, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v2, ptr %v1, ptr %v0, ptr %t1003, %"compiler/source:Span" %t1004, ptr %t1005, { i64, ptr } %t1006, ptr %t1007, i32 %t1008)
  br label %bb269
bb269:
  br label %bb270
bb270:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1009, ptr %l515, !tbaa !29
  %t1010 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1010, ptr %l516
  %t1011 = load ptr, ptr %l5, !tbaa !29
  %t1013 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v0, ptr %t1011)
  store { i64, ptr } %t1013, ptr %l518
  br label %bb271
bb271:
  %t1014 = load ptr, ptr %l16, !tbaa !29
  store ptr %t1014, ptr %l519, !tbaa !29
  %t1015 = load ptr, ptr %l24, !tbaa !29
  %t1017 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v0, ptr %t1015)
  store { i64, ptr } %t1017, ptr %l521
  br label %bb272
bb272:
  %t1018 = load ptr, ptr %l0, !tbaa !29
  %t1019 = load %"compiler/source:Span", ptr %l1
  %t1023 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1018, i32 6, %"compiler/source:Span" %t1019)
  store i32 %t1023, ptr %l525
  br label %bb273
bb273:
  %t1024 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1025 = load ptr, ptr %l519, !tbaa !29
  %t1026 = load { i64, ptr }, ptr %l521, !tbaa !27
  %t1027 = load i32, ptr %l525, !tbaa !23
  %t1028 = call %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1024, ptr %t1025, { i64, ptr } %t1026, i32 %t1027)
  store %"compiler/typed:Spawn" %t1028, ptr %l526
  br label %bb274
bb274:
  %t1029 = load %"compiler/typed:Spawn", ptr %l526
  %t1030 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Spawn" %t1029, ptr %t1030
  store { i64, [3 x i64] } zeroinitializer, ptr %t1031
  %t1032 = getelementptr { i64, [3 x i64] }, ptr %t1031, i32 0, i32 0
  store i64 14, ptr %t1032
  %t1033 = load %"compiler/source:Span", ptr %l516
  %t1034 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1033, 0
  %t1036 = insertvalue { %"compiler/source:Span", ptr } %t1034, ptr %t1030, 1
  %t1037 = getelementptr { i64, [3 x i64] }, ptr %t1031, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1036, ptr %t1037
  %t1038 = load { i64, [3 x i64] }, ptr %t1031
  %t1040 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1038, ptr %t1040
  %t1041 = load ptr, ptr %l515, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1041, ptr %t1040)
  br label %bb275
bb275:
  %t1043 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1043, ptr %l530, !tbaa !29
  %t1044 = load ptr, ptr %l530, !tbaa !29
  %t1045 = getelementptr %"compiler/check:Checker", ptr %t1044, i32 0, i32 56
  %t1046 = load i64, ptr %t1045, !tbaa !24
  %t1049 = sub i64 %t1046, 1
  %t1051 = load ptr, ptr %l530, !tbaa !29
  %t1052 = getelementptr %"compiler/check:Checker", ptr %t1051, i32 0, i32 56
  store i64 %t1049, ptr %t1052, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca i1
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i1
  %l67 = alloca i1
  %l70 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i32
  %l91 = alloca ptr
  %l93 = alloca i32
  %l95 = alloca i32
  %l101 = alloca i64
  %l103 = alloca ptr
  %l113 = alloca i64
  %l116 = alloca i64
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l154 = alloca i64
  %l155 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i1
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca i32
  %l175 = alloca ptr
  %rv = alloca ptr
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t193 = alloca i64
  %t315 = alloca { i64, [2 x i64] }, align 8
  %t371 = alloca { i64, [2 x i64] }, align 8
  %t379 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l23, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l35
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i32, ptr %l35, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l36
  br label %bb5
bb5:
  %t37 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  store ptr %t51, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l48
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l43, !tbaa !29
  %t63 = load i32, ptr %l48, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l49
  br label %bb11
bb11:
  %t65 = load i32, ptr %l49, !tbaa !23
  store i32 %t65, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l50, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 7
  store i1 %t73, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l51, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l4
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l5, !tbaa !23
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Make", ptr %t98, i32 0, i32 0
  %t101 = load i32, ptr %t100, !range !{i32 0, i32 5}
  %t103 = trunc i64 2 to i32
  %t104 = icmp eq i32 %t101, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb21
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l70, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l5, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l75
  br label %bb19
bb19:
  %t124 = load i32, ptr %l3, !tbaa !23
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l75, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t125, i32 %t126, i32 %t124)
  store i1 %t128, ptr %l77
  br label %bb20
bb20:
  %t129 = load i1, ptr %l77, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l67, !tbaa !21
  br label %bb21
bb21:
  %t132 = load i1, ptr %l67, !tbaa !21
  br i1 %t132, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l82
  br label %bb25
bb25:
  %t139 = load i1, ptr %l82, !tbaa !21
  br i1 %t139, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb28
bb27:
  %t140 = load i32, ptr %l3, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  store i1 %t144, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb33
bb30:
  %t147 = load i32, ptr %l3, !tbaa !23
  store i32 %t147, ptr %l88, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l91, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t154)
  store i32 %t156, ptr %l93
  br label %bb31
bb31:
  %t157 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t158 = load ptr, ptr %l91, !tbaa !29
  %t159 = load i32, ptr %l93, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t158, i32 %t159, i64 %t157)
  store i32 %t161, ptr %l95
  br label %bb32
bb32:
  %t162 = load i32, ptr %l88, !tbaa !23
  %t163 = load i32, ptr %l95, !tbaa !23
  %t164 = icmp eq i32 %t162, %t163
  store i1 %t164, ptr %l87, !tbaa !21
  br label %bb33
bb33:
  %t166 = load i1, ptr %l87, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb34, label %bb35
bb34:
  store ptr null, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l7, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Make", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l101, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = insertvalue { i64 } undef, i64 0, 0
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  store { i64 } %t178, ptr %t179
  %t180 = load { i64, [2 x i64] }, ptr %t176
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t180, ptr %t182
  store ptr %t182, ptr %l103, !tbaa !29
  %t183 = load i64, ptr %l101, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l101, !tbaa !24
  %t187 = icmp sle i64 %t186, 1152921504606846975
  br i1 %t187, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb39:
  %t189 = load i64, ptr %l101, !tbaa !24
  %t190 = mul i64 %t189, 8
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  %t192 = load ptr, ptr %l103, !tbaa !29
  store i64 0, ptr %t193
  br label %fill.194
fill.194:
  %t197 = load i64, ptr %t193
  %t198 = icmp slt i64 %t197, %t189
  br i1 %t198, label %fillb.195, label %filld.196
fillb.195:
  %t199 = getelementptr ptr, ptr %t191, i64 %t197
  store ptr %t192, ptr %t199
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %t193
  br label %fill.194
filld.196:
  %t201 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t191, 1
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t203, ptr %lp8
  %t205 = load ptr, ptr %lp8
  store { i64, ptr } %t202, ptr %t205, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Make", ptr %t206, i32 0, i32 2
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb41:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb46
bb43:
  %t223 = load i64, ptr %l10, !tbaa !24
  %t224 = load i64, ptr %l9, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l11, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l116, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb45
bb45:
  %t239 = load i64, ptr %l116, !tbaa !24
  store i64 %t239, ptr %l113, !tbaa !24
  br label %bb46
bb46:
  %t240 = load i64, ptr %l113, !tbaa !24
  store i64 %t240, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb47
bb47:
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb48, label %bb49
bb48:
  br label %bb79
bb49:
  br label %bb50
bb50:
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l11, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l7, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Make", ptr %t259, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l135, !tbaa !27
  %t263 = load i64, ptr %l14, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  store ptr %t268, ptr %l15, !tbaa !29
  %t270 = load ptr, ptr %l15, !tbaa !29
  store ptr %t270, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t271 = load ptr, ptr %l138, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb51, label %bb52
bb51:
  %t274 = load ptr, ptr %l138, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 18}
  %t277 = icmp eq i64 %t275, 0
  store i1 %t277, ptr %l139, !tbaa !21
  br label %bb52
bb52:
  %t278 = load i1, ptr %l139, !tbaa !21
  br i1 %t278, label %bb53, label %bb54
bb53:
  %t279 = load ptr, ptr %l15, !tbaa !29
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t281, i32 0, i32 1
  %t283 = load i32, ptr %t282
  store i32 %t283, ptr %l16, !tbaa !23
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t285 = load i32, ptr %l16, !tbaa !23
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t289 = icmp eq i32 %t285, %t286
  br i1 %t289, label %bb56, label %bb57
bb56:
  store ptr null, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t292 = load ptr, ptr %l15, !tbaa !29
  store ptr %t292, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t293 = load ptr, ptr %l148, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb59, label %bb60
bb59:
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 18}
  %t299 = icmp eq i64 %t297, 0
  store i1 %t299, ptr %l149, !tbaa !21
  br label %bb60
bb60:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb61, label %bb62
bb61:
  %t301 = load ptr, ptr %l15, !tbaa !29
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t303, i32 0, i32 2
  %t305 = load i64, ptr %t304
  store i64 %t305, ptr %l17, !tbaa !24
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t307 = load i64, ptr %l14, !tbaa !24
  store i64 %t307, ptr %l154, !tbaa !24
  %t308 = call ptr @__olang_scope_hold(ptr %v2)
  %t309 = ptrtoint ptr %t308 to i64
  store i64 %t309, ptr %l155, !tbaa !24
  %t310 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2ftyped_3aConst_26_3e_2e_2d1
  br i1 %t310, label %bb64, label %bb65
bb64:
  %t312 = call ptr @__olang_region_make(ptr %v2)
  %t313 = ptrtoint ptr %t312 to i64
  store i64 %t313, ptr %l155, !tbaa !24
  br label %bb65
bb65:
  %t314 = load i64, ptr %l17, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t315
  %t316 = getelementptr { i64, [2 x i64] }, ptr %t315, i32 0, i32 0
  store i64 0, ptr %t316
  %t318 = insertvalue { i64 } undef, i64 %t314, 0
  %t319 = getelementptr { i64, [2 x i64] }, ptr %t315, i32 0, i32 1
  store { i64 } %t318, ptr %t319
  %t320 = load { i64, [2 x i64] }, ptr %t315
  %t322 = load i64, ptr %l155
  %t323 = inttoptr i64 %t322 to ptr
  %t324 = call ptr @__olang_scope_alloc_a(ptr %t323, i64 24, i64 8)
  store { i64, [2 x i64] } %t320, ptr %t324
  %t326 = load ptr, ptr %lp8
  %t327 = load i64, ptr %l154, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %t326, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t327
  store ptr %t324, ptr %t330, !tbaa !39
  br label %bb77
bb66:
  %t331 = load ptr, ptr %l15, !tbaa !29
  store ptr %t331, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t332 = load ptr, ptr %l160, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb67, label %bb68
bb67:
  %t335 = load ptr, ptr %l160, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 18}
  %t338 = icmp eq i64 %t336, 1
  store i1 %t338, ptr %l161, !tbaa !21
  br label %bb68
bb68:
  %t339 = load i1, ptr %l161, !tbaa !21
  br i1 %t339, label %bb69, label %bb70
bb69:
  %t340 = load ptr, ptr %l15, !tbaa !29
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t342, i32 0, i32 3
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l18, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t346 = load i64, ptr %l14, !tbaa !24
  %t347 = load ptr, ptr %l18, !tbaa !29
  %t349 = load ptr, ptr %lp8
  %t351 = getelementptr { i64, ptr }, ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr ptr, ptr %t352, i64 %t346
  store ptr %t347, ptr %t353, !tbaa !39
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store ptr null, ptr %rv
  br label %ret
bb76:
  call void @__olang_check_failed(ptr @olang_loc_81d441761e2a717d_f45e749fdf1e1e81)
  unreachable
bb77:
  br label %bb78
bb78:
  %t355 = load i64, ptr %l13, !tbaa !24
  %t358 = add i64 %t355, 1
  store i64 %t358, ptr %l13, !tbaa !24
  br label %bb47
bb79:
  %t360 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t360, ptr %l172
  %t361 = load i32, ptr %l2, !tbaa !23
  store i32 %t361, ptr %l173, !tbaa !23
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t362)
  store ptr %t364, ptr %l175
  br label %bb80
bb80:
  %t365 = load ptr, ptr %l175, !tbaa !29
  %t367 = getelementptr %"compiler/check:frame", ptr %t365, i32 0, i32 2
  %t368 = load i64, ptr %t367, !tbaa !24
  %t369 = load ptr, ptr %lp8
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [2 x i64] }, ptr %t371, i32 0, i32 0
  store i64 2, ptr %t372
  %t374 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t370, 0
  %t375 = getelementptr { i64, [2 x i64] }, ptr %t371, i32 0, i32 1
  store { { i64, ptr } } %t374, ptr %t375
  %t376 = load { i64, [2 x i64] }, ptr %t371
  %t378 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t376, ptr %t378
  store { i64, [5 x i64] } zeroinitializer, ptr %t379
  %t380 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 0
  store i64 1, ptr %t380
  %t381 = load %"compiler/source:Span", ptr %l172
  %t382 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t381, 0
  %t383 = load i32, ptr %l173, !tbaa !23
  %t384 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t382, i32 %t383, 1
  %t386 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t384, i64 %t368, 2
  %t388 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t386, ptr %t378, 3
  %t389 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t388, ptr %t389
  %t390 = load { i64, [5 x i64] }, ptr %t379
  %t392 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t390, ptr %t392
  store ptr %t392, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 19
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 100
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 19
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 10
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249, !prof !99
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 10
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/diagmsg:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/diagmsg:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4caebcac4cec7311_26f3d9a9847d99e5)
  unreachable
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t324 = add i64 %t321, 1
  store i64 %t324, ptr %l6, !tbaa !24
  br label %bb9
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t13, ptr %l9
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:typeCase" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:Binding"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca %"compiler/generic:Binding"
  %l37 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l88 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i64
  %l97 = alloca i32
  %l98 = alloca i32
  %l104 = alloca i1
  %l112 = alloca i1
  %l115 = alloca ptr
  %l120 = alloca i32
  %l125 = alloca i64
  %l129 = alloca i32
  %l135 = alloca i1
  %l137 = alloca i1
  %l143 = alloca i1
  %l151 = alloca i32
  %l157 = alloca i64
  %l160 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i1
  %l182 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca i32
  %l197 = alloca i64
  %l202 = alloca i32
  %l203 = alloca i32
  %l205 = alloca i1
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l214 = alloca i64
  %l218 = alloca i64
  %l221 = alloca i64
  %l240 = alloca ptr
  %l243 = alloca i32
  %l244 = alloca { i64, ptr }
  %l247 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %s0 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t2, i64 %t4)
  store %"compiler/generic:Binding" %t7, ptr %l28
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:Binding", ptr %l28
  store %"compiler/generic:Binding" %t8, ptr %l4
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  %t17 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb38, label %bb39
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %s0, ptr %t25, i32 %t26, i32 %t28, ptr %l4)
  store i64 %t33, ptr %l37
  br label %bb6
bb5:
  br label %bb28
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l45, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l45, !tbaa !24
  store i64 %t63, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = sub i64 %t65, 1
  store i64 %t66, ptr %l54, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t67, 2147483648
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  %t73 = and i1 %t68, %t70
  store i1 %t73, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l10, !tbaa !24
  %t92 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l67, !tbaa !27
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp eq i32 %t99, %t100
  br i1 %t103, label %bb17, label %bb18
bb17:
  %t105 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 5
  %t106 = load i1, ptr %t105, !tbaa !21
  store i1 %t106, ptr %l72, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l72, !tbaa !21
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t109 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l74, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i32, ptr %l2, !tbaa !23
  %t115 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t111
  store i32 %t112, ptr %t117, !tbaa !33
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t118 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l77, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t126 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l9, !tbaa !24
  br label %bb13
bb27:
  br label %bb28
bb28:
  %t137 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  store ptr %t145, ptr %l90, !tbaa !29
  %t146 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t147 = load i32, ptr %t146, !tbaa !23
  store i32 %t147, ptr %l91, !tbaa !23
  %t148 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t149 = load i64, ptr %t148, !tbaa !24
  store i64 %t149, ptr %l92, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t155, { i64, ptr } %t157)
  store i32 %t160, ptr %l97
  br label %bb31
bb30:
  %t161 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t162 = load i32, ptr %t161, !tbaa !23
  store i32 %t162, ptr %l88, !tbaa !23
  br label %bb33
bb31:
  %t164 = load ptr, ptr %l90, !tbaa !29
  %t165 = load i32, ptr %l91, !tbaa !23
  %t166 = load i64, ptr %l92, !tbaa !24
  %t167 = load i32, ptr %l97, !tbaa !23
  %t168 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t164, i32 %t165, i64 %t166, i32 %t167)
  store i32 %t168, ptr %l98
  br label %bb32
bb32:
  %t169 = load i32, ptr %l98, !tbaa !23
  store i32 %t169, ptr %l88, !tbaa !23
  br label %bb33
bb33:
  %t170 = load i32, ptr %l88, !tbaa !23
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t175 = load i32, ptr %l2, !tbaa !23
  %t180 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t174, i32 %t175, i32 %t170)
  store i1 %t180, ptr %l104
  br label %bb34
bb34:
  %t181 = load i1, ptr %l104, !tbaa !21
  %t182 = xor i1 %t181, true
  br i1 %t182, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb81
bb38:
  %t185 = load i32, ptr %l2, !tbaa !23
  store i32 %t185, ptr %l12, !tbaa !23
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l2, !tbaa !23
  %t191 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l112
  br label %bb40
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t197 = load i32, ptr %t196, !tbaa !23
  %t198 = load i32, ptr %l2, !tbaa !23
  %t203 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %s0, ptr %t195, i32 %t197, i32 %t198, ptr %l4, i1 false, i1 false)
  store i32 %t203, ptr %l151
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb56, label %ok.205, !prof !99
ok.205:
  br label %bb55
bb40:
  %t206 = load i1, ptr %l112, !tbaa !21
  br i1 %t206, label %bb41, label %bb42
bb41:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 2
  store ptr %t212, ptr %l115, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %l2, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t218, i32 %t219)
  store i32 %t222, ptr %l120
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l2, !tbaa !23
  %t232 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t228, i32 %t229)
  store i64 %t232, ptr %l125
  br label %bb44
bb44:
  %t233 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t235 = xor i64 %t233, -1
  %t236 = load i64, ptr %l125, !tbaa !24
  %t238 = and i64 %t236, %t235
  %t239 = load ptr, ptr %l115, !tbaa !29
  %t240 = load i32, ptr %l120, !tbaa !23
  %t242 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t239, i32 %t240, i64 %t238)
  store i32 %t242, ptr %l129
  br label %bb45
bb45:
  %t243 = load i32, ptr %l129, !tbaa !23
  store i32 %t243, ptr %l12, !tbaa !23
  br label %bb46
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t251 = load i32, ptr %t250, !tbaa !23
  %t252 = load i32, ptr %l2, !tbaa !23
  %t256 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t249, i32 %t251, i32 %t252)
  store i1 %t256, ptr %l135
  br label %bb47
bb47:
  %t257 = load i1, ptr %l135, !tbaa !21
  %t258 = xor i1 %t257, true
  br i1 %t258, label %bb48, label %bb49
bb48:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 2
  %t266 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t267 = load i32, ptr %t266, !tbaa !23
  %t268 = load i32, ptr %l12, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t265, i32 %t267, i32 %t268)
  store i1 %t272, ptr %l143
  br label %bb50
bb49:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb51
bb50:
  %t273 = load i1, ptr %l143, !tbaa !21
  %t274 = xor i1 %t273, true
  store i1 %t274, ptr %l137, !tbaa !21
  br label %bb51
bb51:
  %t276 = load i1, ptr %l137, !tbaa !21
  br i1 %t276, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb80
bb55:
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb58:
  store i64 0, ptr %l13, !tbaa !24
  %t279 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t280 = load i64, ptr %t279, !tbaa !24
  store i64 %t280, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t282 = load i64, ptr %l14, !tbaa !24
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  br i1 %t286, label %bb59, label %bb60
bb59:
  %t288 = load i64, ptr %l15, !tbaa !24
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb64
bb61:
  %t292 = load i64, ptr %l14, !tbaa !24
  %t293 = load i64, ptr %l13, !tbaa !24
  %t296 = sub i64 %t292, %t293
  %t297 = load i64, ptr %l15, !tbaa !24
  %t300 = add i64 %t296, %t297
  %t302 = sub i64 %t300, 1
  %t303 = load i64, ptr %l15, !tbaa !24
  %t306 = sdiv i64 %t302, %t303
  store i64 %t306, ptr %l160, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb63
bb63:
  %t308 = load i64, ptr %l160, !tbaa !24
  store i64 %t308, ptr %l157, !tbaa !24
  br label %bb64
bb64:
  %t309 = load i64, ptr %l157, !tbaa !24
  store i64 %t309, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l16, !tbaa !24
  %t311 = sub i64 %t310, 1
  store i64 %t311, ptr %l169, !tbaa !24
  %t312 = load i64, ptr %l16, !tbaa !24
  %t313 = icmp slt i64 %t312, 2147483648
  %t314 = load i64, ptr %l17, !tbaa !24
  %t315 = icmp sge i64 %t314, 0
  %t318 = and i1 %t313, %t315
  store i1 %t318, ptr %l172, !tbaa !21
  br label %bb65
bb65:
  %t319 = load i64, ptr %l17, !tbaa !24
  %t320 = load i64, ptr %l16, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb66, label %bb67
bb66:
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t327 = load i64, ptr %l13, !tbaa !24
  %t328 = load i64, ptr %l17, !tbaa !24
  %t329 = load i64, ptr %l15, !tbaa !24
  %t332 = mul i64 %t328, %t329
  %t335 = add i64 %t327, %t332
  %t337 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l182, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i32, ptr %t342, i64 %t335
  %t344 = load i32, ptr %t343, !tbaa !33
  %t345 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t348 = icmp eq i32 %t344, %t345
  br i1 %t348, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t351 = load i64, ptr %l17, !tbaa !24
  %t354 = add i64 %t351, 1
  store i64 %t354, ptr %l17, !tbaa !24
  br label %bb65
bb73:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/generic:Program", ptr %t359, i32 0, i32 2
  store ptr %t361, ptr %l193, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  store ptr %t365, ptr %l195, !tbaa !29
  %t366 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t367 = load i32, ptr %t366, !tbaa !23
  store i32 %t367, ptr %l196, !tbaa !23
  %t368 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t369 = load i64, ptr %t368, !tbaa !24
  store i64 %t369, ptr %l197, !tbaa !24
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Program", ptr %t373, i32 0, i32 2
  %t376 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t375, { i64, ptr } %t377)
  store i32 %t380, ptr %l202
  br label %bb74
bb74:
  %t381 = load ptr, ptr %l195, !tbaa !29
  %t382 = load i32, ptr %l196, !tbaa !23
  %t383 = load i64, ptr %l197, !tbaa !24
  %t384 = load i32, ptr %l202, !tbaa !23
  %t385 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t381, i32 %t382, i64 %t383, i32 %t384)
  store i32 %t385, ptr %l203
  br label %bb75
bb75:
  %t386 = load i32, ptr %l2, !tbaa !23
  %t387 = load ptr, ptr %l193, !tbaa !29
  %t388 = load i32, ptr %l203, !tbaa !23
  %t390 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t387, i32 %t388, i32 %t386)
  store i1 %t390, ptr %l205
  br label %bb76
bb76:
  %t391 = load i1, ptr %l205, !tbaa !21
  %t392 = xor i1 %t391, true
  br i1 %t392, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t395 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %l208
  br label %bb82
bb82:
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %l19
  %t397 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t397, ptr %a3, ptr %l19, i1 false)
  br label %bb83
bb83:
  store i64 0, ptr %l20, !tbaa !24
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19)
  store i64 %t404, ptr %l214
  br label %bb84
bb84:
  %t405 = load i64, ptr %l214, !tbaa !24
  store i64 %t405, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t406 = load i64, ptr %l21, !tbaa !24
  %t407 = load i64, ptr %l20, !tbaa !24
  %t410 = icmp sgt i64 %t406, %t407
  br i1 %t410, label %bb85, label %bb86
bb85:
  %t412 = load i64, ptr %l22, !tbaa !24
  %t414 = icmp sgt i64 %t412, 0
  br i1 %t414, label %bb87, label %bb88
bb86:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb90
bb87:
  %t416 = load i64, ptr %l21, !tbaa !24
  %t417 = load i64, ptr %l20, !tbaa !24
  %t420 = sub i64 %t416, %t417
  %t421 = load i64, ptr %l22, !tbaa !24
  %t424 = add i64 %t420, %t421
  %t426 = sub i64 %t424, 1
  %t427 = load i64, ptr %l22, !tbaa !24
  %t430 = sdiv i64 %t426, %t427
  store i64 %t430, ptr %l221, !tbaa !24
  br label %bb89
bb88:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb89
bb89:
  %t432 = load i64, ptr %l221, !tbaa !24
  store i64 %t432, ptr %l218, !tbaa !24
  br label %bb90
bb90:
  %t433 = load i64, ptr %l218, !tbaa !24
  store i64 %t433, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s21
  %t434 = load i64, ptr %l24, !tbaa !24
  %t435 = load i64, ptr %l23, !tbaa !24
  %t438 = icmp slt i64 %t434, %t435
  %t440 = xor i1 %t438, true
  br i1 %t440, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s21)
  br label %bb99
bb93:
  br label %bb94
bb94:
  %t442 = load i64, ptr %l20, !tbaa !24
  %t443 = load i64, ptr %l24, !tbaa !24
  %t444 = load i64, ptr %l22, !tbaa !24
  %t447 = mul i64 %t443, %t444
  %t450 = add i64 %t442, %t447
  store i64 %t450, ptr %l25, !tbaa !24
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/check:Checker", ptr %t452, i32 0, i32 179
  store ptr %t454, ptr %l240, !tbaa !29
  %t455 = load i64, ptr %l25, !tbaa !24
  %t458 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19, i64 %t455)
  store i32 %t458, ptr %l243
  br label %bb95
bb95:
  %t459 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  store { i64, ptr } %t460, ptr %l244, !tbaa !27
  %t461 = load i64, ptr %l25, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i32, ptr %t464, i64 %t461
  %t466 = load i32, ptr %t465, !tbaa !33
  %t467 = load i32, ptr %l243, !tbaa !23
  %t469 = call %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %s21, i32 %t467, i32 %t466)
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t469, ptr %l247
  br label %bb96
bb96:
  %t470 = load ptr, ptr %l240, !tbaa !29
  %t471 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l247
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %t470, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t471)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb98
bb98:
  %t472 = load i64, ptr %l24, !tbaa !24
  %t475 = add i64 %t472, 1
  store i64 %t475, ptr %l24, !tbaa !24
  br label %bb91
bb99:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l55 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca i64
  %l60 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i64
  %l85 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l95 = alloca %"compiler/diagmsg:Msg"
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/diagmsg:Msg"
  %l105 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = load i32, ptr %l2, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %t10)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14, ptr %l4
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 110
  %t18 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t17, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18)
  store i1 %t21, ptr %l18
  br label %bb3
bb3:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 110
  %t26 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t25, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, i1 true)
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l24
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s0, ptr %t35, { i64, ptr } %t36, i1 false)
  store { i64, ptr } %t39, ptr %l27
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t48)
  store { i64, ptr } %t51, ptr %l33
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  %t54 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eunknownType_2elocal_2e6
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load { i64, ptr }, ptr %l34
  %t57 = extractvalue { i64, ptr } %t56, 1
  call void @__olang_region_release(ptr %t57)
  store { i64, ptr } zeroinitializer, ptr %l34
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t62 = icmp eq i64 %t60, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v0, ptr %s0, ptr %t64, { i64, ptr } %t65)
  store { i64, ptr } %t68, ptr %l42
  br label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb19
bb18:
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t69, ptr %l39, !tbaa !27
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t71, ptr %l7, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t74, ptr %l45
  br label %bb20
bb20:
  %t75 = load i1, ptr %l45, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l48
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l51
  br label %bb23
bb22:
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb26, label %bb27
bb23:
  %t91 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeStd(ptr %s3, ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t91, { i64, ptr } %t92, { i64, ptr } %t93)
  store %"compiler/diagmsg:Msg" %t97, ptr %l55
  br label %bb24
bb24:
  %t98 = load ptr, ptr %l47, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l48
  %t100 = load %"compiler/diagmsg:Msg", ptr %l55
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t98, %"compiler/source:Span" %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l56
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb26:
  store i1 %a3, ptr %l60, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb28
bb28:
  %t104 = load i1, ptr %l60, !tbaa !21
  br i1 %t104, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l63
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l66
  br label %bb31
bb30:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb34, label %bb35
bb31:
  %t118 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t120 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownConstraint(ptr %s5, ptr %v0, { i64, ptr } %t118)
  store %"compiler/diagmsg:Msg" %t120, ptr %l68
  br label %bb32
bb32:
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l63
  %t123 = load %"compiler/diagmsg:Msg", ptr %l68
  %t124 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t121, %"compiler/source:Span" %t122, %"compiler/diagmsg:Msg" %t123)
  store i64 %t124, ptr %l69
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l73, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t126, ptr %l74
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t127, i32 %t128)
  store { i64, ptr } %t131, ptr %l77
  br label %bb36
bb35:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t137, { i64, ptr } %t138)
  store i32 %t141, ptr %l85
  br label %bb39
bb36:
  %t142 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t144 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownType(ptr %s7, ptr %v0, { i64, ptr } %t142)
  store %"compiler/diagmsg:Msg" %t144, ptr %l79
  br label %bb37
bb37:
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l74
  %t147 = load %"compiler/diagmsg:Msg", ptr %l79
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, %"compiler/diagmsg:Msg" %t147)
  store i64 %t148, ptr %l80
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb39:
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t150 = load i32, ptr %l85, !tbaa !23
  %t152 = icmp ne i32 %t150, %t149
  br i1 %t152, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l88, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l89
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t156, i32 %t157)
  store { i64, ptr } %t160, ptr %l92
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l97, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t162, ptr %l98
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l101
  br label %bb45
bb42:
  %t168 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t172 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s9, ptr %s0, ptr %v0, { i64, ptr } %t168, { i64, ptr } %t169)
  store %"compiler/diagmsg:Msg" %t172, ptr %l95
  br label %bb43
bb43:
  %t173 = load ptr, ptr %l88, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l89
  %t175 = load %"compiler/diagmsg:Msg", ptr %l95
  %t176 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t173, %"compiler/source:Span" %t174, %"compiler/diagmsg:Msg" %t175)
  store i64 %t176, ptr %l96
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb45:
  %t177 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t181 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %s10, ptr %s0, ptr %v0, { i64, ptr } %t177, { i64, ptr } %t178)
  store %"compiler/diagmsg:Msg" %t181, ptr %l104
  br label %bb46
bb46:
  %t182 = load ptr, ptr %l97, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l98
  %t184 = load %"compiler/diagmsg:Msg", ptr %l104
  %t185 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t182, %"compiler/source:Span" %t183, %"compiler/diagmsg:Msg" %t184)
  store i64 %t185, ptr %l105
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakTargetWhat(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 5
  store i1 %t33, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l13, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l18, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l19, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f342226b8bcffe86_cb7cec1b8bc140d2)
  unreachable
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i1 %t55, ptr %l22
  br label %bb18
bb18:
  %t56 = load i1, ptr %l22, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t57, ptr %l24, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l25, !tbaa !24
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l26, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t71, ptr %l24, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l28, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t77)
  store ptr %t79, ptr %l30
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l30, !tbaa !29
  %t82 = getelementptr %"compiler/check:frame", ptr %t80, i32 0, i32 4
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l28, !tbaa !29
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t85, ptr %t82, ptr %t83)
  store i32 %t88, ptr %l35
  br label %bb23
bb23:
  %t89 = load i32, ptr %l35, !tbaa !23
  store i32 %t89, ptr %l2, !tbaa !23
  %t90 = load i32, ptr %l2, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp eq i32 %t90, %t91
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb27
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t96, i32 %t97)
  store i1 %t100, ptr %l42
  br label %bb26
bb26:
  %t101 = load i1, ptr %l42, !tbaa !21
  store i1 %t101, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l39, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t103, i32 %t104)
  store i1 %t107, ptr %l46
  br label %bb30
bb30:
  %t108 = load i1, ptr %l46, !tbaa !21
  store i1 %t108, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l43, !tbaa !21
  br i1 %t109, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t110, ptr %l48, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l49, !tbaa !24
  %t113 = load i64, ptr %l49, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l50, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l49, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t124, ptr %l48, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l2, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l55
  br label %bb35
bb35:
  %t136 = load i32, ptr %l55, !range !{i32 0, i32 33}
  store i32 %t136, ptr %l3
  %t137 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t139 = trunc i64 25 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t142, ptr %l56, !tbaa !27
  br label %bb52
bb39:
  %t144 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t146 = trunc i64 19 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t149, ptr %l56, !tbaa !27
  br label %bb52
bb43:
  %t151 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t153 = trunc i64 21 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t156, ptr %l56, !tbaa !27
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t158, ptr %l56, !tbaa !27
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_a797700ef8100967_b92f0bde838bc4d3)
  unreachable
bb52:
  %t160 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l71, !tbaa !24
  %t162 = load i64, ptr %l71, !tbaa !24
  %t163 = mul i64 %t162, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l72, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l71, !tbaa !24
  %t172 = mul i64 %t171, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t173, ptr %l56, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:collWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l11
  br label %bb1
bb1:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t18, 16
  br i1 %t20, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t22 = load i32, ptr %l4, !tbaa !23
  store i32 %t22, ptr %l15, !tbaa !23
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:collWalk", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v1, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t33, ptr %t34, i32 %t27)
  store i32 %t36, ptr %l20
  br label %bb4
bb4:
  %t37 = load i32, ptr %l15, !tbaa !23
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t41 = load i1, ptr %l14, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l23, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = call ptr @__olang_scope_or(ptr %v1, ptr %t45)
  %t47 = call ptr @__olang_scope_hold(ptr %t46)
  %t48 = ptrtoint ptr %t47 to i64
  %t50 = inttoptr i64 %t48 to ptr
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t50, ptr %t51, i32 %t44)
  store i32 %t53, ptr %l26
  br label %bb9
bb9:
  %t54 = load i32, ptr %l26, !range !{i32 0, i32 33}
  store i32 %t54, ptr %l5
  %t55 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t57 = trunc i64 25 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb43
bb13:
  %t60 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t62 = trunc i64 19 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l33, !tbaa !29
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = call ptr @__olang_scope_or(ptr %v1, ptr %t68)
  %t70 = call ptr @__olang_scope_hold(ptr %t69)
  %t71 = ptrtoint ptr %t70 to i64
  %t73 = inttoptr i64 %t71 to ptr
  %t74 = load ptr, ptr %l33, !tbaa !29
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t73, ptr %t74, i32 %t67)
  store i32 %t76, ptr %l36
  br label %bb17
bb17:
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = add i64 %t77, 1
  %t80 = load ptr, ptr %l32, !tbaa !29
  %t81 = load i32, ptr %l36, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %v1, ptr %t80, i32 %t81, i64 %t79)
  store i1 %t83, ptr %l39
  br label %bb18
bb18:
  %t84 = load i1, ptr %l39, !tbaa !21
  store i1 %t84, ptr %l27, !tbaa !21
  br label %bb43
bb19:
  %t85 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t87 = trunc i64 22 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  %t90 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t92 = trunc i64 23 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l44, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  store ptr %t96, ptr %l45, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  store ptr %t97, ptr %l46, !tbaa !29
  %t98 = load i32, ptr %l4, !tbaa !23
  %t99 = load ptr, ptr %l46, !tbaa !29
  %t100 = call ptr @__olang_scope_or(ptr %v1, ptr %t99)
  %t101 = call ptr @__olang_scope_hold(ptr %t100)
  %t102 = ptrtoint ptr %t101 to i64
  %t104 = inttoptr i64 %t102 to ptr
  %t105 = load ptr, ptr %l46, !tbaa !29
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t104, ptr %t105, i32 %t98)
  store i32 %t107, ptr %l49
  br label %bb25
bb25:
  %t108 = load ptr, ptr %l45, !tbaa !29
  %t109 = call ptr @__olang_scope_or(ptr %v1, ptr %t108)
  %t110 = call ptr @__olang_scope_hold(ptr %t109)
  %t111 = ptrtoint ptr %t110 to i64
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:collWalk", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = call ptr @__olang_scope_or(ptr %v1, ptr %t115)
  %t118 = call ptr @__olang_scope_hold(ptr %t117)
  %t119 = ptrtoint ptr %t118 to i64
  %t121 = inttoptr i64 %t111 to ptr
  %t123 = inttoptr i64 %t119 to ptr
  %t124 = load ptr, ptr %l45, !tbaa !29
  %t125 = load i32, ptr %l49, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t121, ptr %t123, ptr %t124, i32 %t125)
  store { i64, ptr } %t126, ptr %l54
  br label %bb26
bb26:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_scope_or(ptr %v1, ptr %t129)
  %t131 = call ptr @__olang_scope_hold(ptr %t130)
  %t132 = ptrtoint ptr %t131 to i64
  %t134 = inttoptr i64 %t132 to ptr
  %t135 = load ptr, ptr %l44, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %t134, ptr %v1, ptr %t135, { i64, ptr } %t136, i64 %t127)
  store i1 %t138, ptr %l57
  br label %bb27
bb27:
  %t139 = load i1, ptr %l57, !tbaa !21
  store i1 %t139, ptr %l27, !tbaa !21
  br label %bb43
bb28:
  %t140 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t142 = trunc i64 18 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t145 = load ptr, ptr %l3, !tbaa !29
  store ptr %t145, ptr %l60, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t147 = load ptr, ptr %l60, !tbaa !29
  %t148 = call ptr @__olang_scope_or(ptr %v1, ptr %t147)
  %t149 = call ptr @__olang_scope_hold(ptr %t148)
  %t150 = ptrtoint ptr %t149 to i64
  %t152 = inttoptr i64 %t150 to ptr
  %t153 = load ptr, ptr %l60, !tbaa !29
  %t155 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t152, ptr %t153, i32 %t146)
  store i1 %t155, ptr %l63
  br label %bb32
bb32:
  %t156 = load i1, ptr %l63, !tbaa !21
  br i1 %t156, label %bb33, label %bb34
bb33:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l65, !tbaa !29
  %t158 = load ptr, ptr %l3, !tbaa !29
  store ptr %t158, ptr %l66, !tbaa !29
  %t159 = load i32, ptr %l4, !tbaa !23
  %t160 = load ptr, ptr %l66, !tbaa !29
  %t161 = call ptr @__olang_scope_or(ptr %v1, ptr %t160)
  %t162 = call ptr @__olang_scope_hold(ptr %t161)
  %t163 = ptrtoint ptr %t162 to i64
  %t165 = inttoptr i64 %t163 to ptr
  %t166 = load ptr, ptr %l66, !tbaa !29
  %t168 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %t165, ptr %s5, ptr %t166, i32 %t159)
  store { i64, ptr } %t168, ptr %l69
  br label %bb35
bb34:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb37
bb35:
  %t169 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t170 = load i64, ptr %l2, !tbaa !24
  %t171 = load ptr, ptr %l65, !tbaa !29
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %s5, ptr %v1, ptr %t171, { i64, ptr } %t169, i64 %t170)
  store i1 %t174, ptr %l72
  br label %bb36
bb36:
  %t175 = load i1, ptr %l72, !tbaa !21
  store i1 %t175, ptr %l64, !tbaa !21
  br label %bb37
bb37:
  %t176 = load i1, ptr %l64, !tbaa !21
  store i1 %t176, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_d5cbe87213397023_e63da241b79e21f)
  unreachable
bb43:
  %t177 = load i1, ptr %l27, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l6, !tbaa !23
  %t23 = load i32, ptr %l6, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:collWalk", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i32, ptr %l6, !tbaa !23
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v2, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t37, ptr %t38, i32 %t31)
  store i1 %t40, ptr %l24
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l24, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l19, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = add i64 %a2, 1
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %v2, ptr %t45, i32 %t46, i64 %t49)
  store i1 %t53, ptr %l31
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb12
bb11:
  %t54 = load i1, ptr %l31, !tbaa !21
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %l4, !tbaa !24
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2)
  unreachable
bb16:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb17, label %bb18
bb17:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 12
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Seq", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb28
bb24:
  call void @__olang_check_failed(ptr @olang_loc_46a0e749826cef18_3e2809181fcd5dac)
  unreachable
bb25:
  br label %bb26
bb26:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Seq", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l34
  br label %bb27
bb27:
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %l28, !tbaa !21
  br label %bb28
bb28:
  %t70 = load i1, ptr %l28, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2f12767f94a228d4_8b6b4888798b3f68)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofText(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l4 = alloca %"compiler/check:litv"
  %l9 = alloca double
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca double
  %l18 = alloca i32
  %l19 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %l25 = alloca %"compiler/check:litv"
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i32
  %l53 = alloca i64
  %l54 = alloca i32
  %l56 = alloca %"compiler/check:litv"
  %l59 = alloca %"compiler/check:litv"
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i32
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i32
  %l71 = alloca i64
  %l72 = alloca i32
  %l74 = alloca %"compiler/check:litv"
  %l77 = alloca %"compiler/check:litv"
  %l79 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t11 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t6, { i64, ptr } %t9, { i64, ptr } %t10)
  store { i64, ptr } %t11, ptr %l14
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s1, { i64, ptr } %t19)
  %t22 = extractvalue { i32, double } %t21, 1
  %t23 = extractvalue { i32, double } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store double %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load double, ptr %l17, !tbaa !26
  store double %t26, ptr %l9, !tbaa !26
  br label %bb8
bb5:
  br label %bb6
bb6:
  %t27 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t27, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/check:litv", ptr %l19
  store %"compiler/check:litv" %t28, ptr %rv
  br label %ret
bb8:
  %t29 = load double, ptr %l9, !tbaa !26
  %t32 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t29)
  store %"compiler/check:litv" %t32, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t33, ptr %rv
  br label %ret
bb10:
  %t34 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t36 = trunc i64 2 to i32
  %t37 = icmp eq i32 %t34, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t41, ptr %l25
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/check:litv", ptr %l25
  store %"compiler/check:litv" %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp sgt i64 %t45, 2
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l30, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 0
  %t53 = load i8, ptr %t52, !tbaa !32
  %t55 = icmp eq i8 %t53, 48
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l34, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 1
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = icmp eq i8 %t62, 120
  br i1 %t64, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb29
bb20:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb22
bb21:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 1
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = icmp eq i8 %t70, 88
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t74 = load i1, ptr %l37, !tbaa !21
  br i1 %t74, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l42, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 1
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = icmp eq i8 %t79, 98
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb27:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l46, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i8, ptr %t86, i64 1
  %t88 = load i8, ptr %t87, !tbaa !32
  %t90 = icmp eq i8 %t88, 66
  store i1 %t90, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l45, !tbaa !21
  store i1 %t92, ptr %l33, !tbaa !21
  br label %bb29
bb29:
  %t93 = load i1, ptr %l33, !tbaa !21
  br i1 %t93, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t94, ptr %l50, !tbaa !27
  %t95 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 0)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l52
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb33, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l51
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t100 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t101 = load i64, ptr %l51, !tbaa !24
  %t102 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t100, i64 %t101)
  %t103 = extractvalue { i32, i64 } %t102, 1
  %t104 = extractvalue { i32, i64 } %t102, 0
  store i32 %t104, ptr %l54
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb36, label %ok.106, !prof !99
ok.106:
  store i64 %t103, ptr %l53
  br label %bb35
bb33:
  br label %bb34
bb34:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t109 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewide(ptr %v0, { i64, ptr } %t107)
  store %"compiler/check:litv" %t109, ptr %l56
  br label %bb37
bb35:
  %t110 = load i64, ptr %l53, !tbaa !65
  store i64 %t110, ptr %l49, !tbaa !65
  br label %bb38
bb36:
  br label %bb34
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load %"compiler/check:litv", ptr %l56
  store %"compiler/check:litv" %t111, ptr %rv
  br label %ret
bb38:
  %t112 = load i64, ptr %l49, !tbaa !65
  %t116 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t112)
  store %"compiler/check:litv" %t116, ptr %l59
  br label %bb39
bb39:
  %t117 = load %"compiler/check:litv", ptr %l59
  store %"compiler/check:litv" %t117, ptr %l4
  %t118 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 5
  store i1 true, ptr %t118, !tbaa !21
  %t119 = load %"compiler/check:litv", ptr %l4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:litv" %t119, ptr %rv
  br label %ret
bb40:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l62, !tbaa !27
  %t122 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 0)
  %t123 = extractvalue { i32, i64 } %t122, 1
  %t124 = extractvalue { i32, i64 } %t122, 0
  store i32 %t124, ptr %l64
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb42, label %ok.126, !prof !99
ok.126:
  store i64 %t123, ptr %l63
  br label %bb41
bb41:
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = load i64, ptr %l63, !tbaa !24
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t127, i64 %t128)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l66
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb45, label %ok.133, !prof !99
ok.133:
  store i64 %t130, ptr %l65
  br label %bb44
bb42:
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l68, !tbaa !27
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 0)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l70
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb47, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l69
  br label %bb46
bb44:
  %t140 = load i64, ptr %l65, !tbaa !24
  store i64 %t140, ptr %l61, !tbaa !24
  br label %bb54
bb45:
  br label %bb43
bb46:
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t142 = load i64, ptr %l69, !tbaa !24
  %t143 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t141, i64 %t142)
  %t144 = extractvalue { i32, i64 } %t143, 1
  %t145 = extractvalue { i32, i64 } %t143, 0
  store i32 %t145, ptr %l72
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb50, label %ok.147, !prof !99
ok.147:
  store i64 %t144, ptr %l71
  br label %bb49
bb47:
  br label %bb48
bb48:
  %t148 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t150 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewide(ptr %v0, { i64, ptr } %t148)
  store %"compiler/check:litv" %t150, ptr %l74
  br label %bb51
bb49:
  %t151 = load i64, ptr %l71, !tbaa !65
  store i64 %t151, ptr %l67, !tbaa !65
  br label %bb52
bb50:
  br label %bb48
bb51:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t152 = load %"compiler/check:litv", ptr %l74
  store %"compiler/check:litv" %t152, ptr %rv
  br label %ret
bb52:
  %t153 = load i64, ptr %l67, !tbaa !65
  %t157 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s6, i1 true, i1 false, i1 true, i64 %t153, double 0x0000000000000000)
  store %"compiler/check:litv" %t157, ptr %l77
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load %"compiler/check:litv", ptr %l77
  store %"compiler/check:litv" %t158, ptr %rv
  br label %ret
bb54:
  %t159 = load i64, ptr %l61, !tbaa !24
  %t162 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t159)
  store %"compiler/check:litv" %t162, ptr %l79
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  %t163 = load %"compiler/check:litv", ptr %l79
  store %"compiler/check:litv" %t163, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewide(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i128
  %l4 = alloca i128
  %l5 = alloca i32
  %l6 = alloca %"compiler/check:litv"
  %l8 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, i128 } %t3, 1
  %t5 = extractvalue { i32, i128 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i128 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i128, ptr %l4
  store i128 %t8, ptr %l2
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t9 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load %"compiler/check:litv", ptr %l6
  store %"compiler/check:litv" %t10, ptr %rv
  br label %ret
bb5:
  %t11 = load i128, ptr %l2
  %t14 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 false, i128 %t11)
  store %"compiler/check:litv" %t14, ptr %l8
  br label %bb6
bb6:
  %t15 = load %"compiler/check:litv", ptr %l8
  store %"compiler/check:litv" %t15, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i1
  %l85 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t24 = alloca i64
  %t109 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l19, !tbaa !23
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = icmp sle i64 1, 2305843009213693951
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb8:
  %t21 = mul i64 1, 4
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  %t23 = load i32, ptr %l19, !tbaa !23
  store i64 0, ptr %t24
  br label %fill.25
fill.25:
  %t28 = load i64, ptr %t24
  %t29 = icmp slt i64 %t28, 1
  br i1 %t29, label %fillb.26, label %filld.27
fillb.26:
  %t30 = getelementptr i32, ptr %t22, i64 %t28
  store i32 %t23, ptr %t30
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %t24
  br label %fill.25
filld.27:
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t22, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 28}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %t50)
  store { i64, ptr } %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 28}
  %t61 = icmp eq i64 %t59, 12
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t71, i32 0, i32 2
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb47
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %s3, ptr %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  %t87 = icmp sle i64 0, 2305843009213693951
  br i1 %t87, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb28:
  %t89 = mul i64 0, 4
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb30:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  store i32 %t98, ptr %l50, !tbaa !23
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load i64, ptr %l49, !tbaa !24
  %t103 = icmp sle i64 %t102, 2305843009213693951
  br i1 %t103, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb33:
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = mul i64 %t105, 4
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = load i32, ptr %l50, !tbaa !23
  store i64 0, ptr %t109
  br label %fill.110
fill.110:
  %t113 = load i64, ptr %t109
  %t114 = icmp slt i64 %t113, %t105
  br i1 %t114, label %fillb.111, label %filld.112
fillb.111:
  %t115 = getelementptr i32, ptr %t107, i64 %t113
  store i32 %t108, ptr %t115
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %t109
  br label %fill.110
filld.112:
  %t117 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t107, 1
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t119, ptr %lp6
  %t121 = load ptr, ptr %lp6
  store { i64, ptr } %t118, ptr %t121, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb35:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb40
bb37:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l62, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb39
bb39:
  %t152 = load i64, ptr %l62, !tbaa !24
  store i64 %t152, ptr %l59, !tbaa !24
  br label %bb40
bb40:
  %t153 = load i64, ptr %l59, !tbaa !24
  store i64 %t153, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = sub i64 %t154, 1
  store i64 %t155, ptr %l71, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = icmp slt i64 %t156, 2147483648
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = icmp sge i64 %t158, 0
  %t162 = and i1 %t157, %t159
  store i1 %t162, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t171 = load i64, ptr %l7, !tbaa !24
  %t172 = load i64, ptr %l11, !tbaa !24
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = mul i64 %t172, %t173
  %t179 = add i64 %t171, %t176
  store i64 %t179, ptr %l12, !tbaa !24
  %t181 = load i64, ptr %l12, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t182, ptr %l85, !tbaa !27
  %t183 = load i64, ptr %l12, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i32, ptr %t186, i64 %t183
  %t188 = load i32, ptr %t187, !tbaa !33
  %t190 = load ptr, ptr %lp6
  %t192 = getelementptr { i64, ptr }, ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t181
  store i32 %t188, ptr %t194, !tbaa !33
  br label %bb45
bb45:
  %t195 = load i64, ptr %l11, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l11, !tbaa !24
  br label %bb41
bb46:
  %t200 = load ptr, ptr %lp6
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t201, ptr %rv
  br label %ret
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t203 = icmp sge i64 0, 0
  br i1 %t203, label %bb51, label %bb52
bb51:
  %t205 = icmp sle i64 0, 2305843009213693951
  br i1 %t205, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb53:
  %t207 = mul i64 0, 4
  %t208 = insertvalue { i64, ptr } undef, i64 0, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t209, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb55:
  call void @__olang_check_failed(ptr @olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t6 = load ptr, ptr %l25, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l25, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 28}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l26, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb28
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 28}
  %t27 = icmp eq i64 %t25, 24
  store i1 %t27, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l32, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb28
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t36 = load ptr, ptr %l37, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l37, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 28}
  %t42 = icmp eq i64 %t40, 26
  store i1 %t42, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l38, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t51 = load ptr, ptr %l43, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 28}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l44, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb28
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t66 = load ptr, ptr %l49, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l49, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 28}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l2, !tbaa !29
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t81 = load ptr, ptr %l55, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 28}
  %t87 = icmp eq i64 %t85, 12
  store i1 %t87, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l56, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t95, ptr %t97)
  br label %bb29
bb29:
  br label %bb153
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l64, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 28}
  %t107 = icmp eq i64 %t105, 25
  store i1 %t107, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l3, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t115, ptr %t116)
  br label %bb36
bb36:
  br label %bb153
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l72, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 28}
  %t126 = icmp eq i64 %t124, 9
  store i1 %t126, ptr %l73, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l73, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb46
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t135 = load ptr, ptr %l78, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l78, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 28}
  %t141 = icmp eq i64 %t139, 11
  store i1 %t141, ptr %l79, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l79, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t145, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l4, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t149 = load ptr, ptr %l4, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t149, ptr %t151)
  br label %bb47
bb47:
  br label %bb153
bb48:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t155 = load ptr, ptr %l87, !tbaa !29
  %t156 = icmp ne ptr %t155, null
  br i1 %t156, label %bb49, label %bb50
bb49:
  %t158 = load ptr, ptr %l87, !tbaa !29
  %t159 = load i64, ptr %t158, !range !{i64 0, i64 28}
  %t161 = icmp eq i64 %t159, 5
  store i1 %t161, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t162 = load i1, ptr %l88, !tbaa !21
  br i1 %t162, label %bb51, label %bb52
bb51:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t165, i32 0, i32 2
  %t167 = load ptr, ptr %t166
  store ptr %t167, ptr %l5, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t171, i32 0, i32 3
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l6, !tbaa !29
  br label %bb57
bb52:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t176 = load ptr, ptr %l95, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t179 = load ptr, ptr %l95, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 28}
  %t182 = icmp eq i64 %t180, 6
  store i1 %t182, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t183 = load i1, ptr %l96, !tbaa !21
  br i1 %t183, label %bb55, label %bb56
bb55:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t186, i32 0, i32 1
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l5, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l6, !tbaa !29
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t196 = load ptr, ptr %l5, !tbaa !29
  %t198 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t196, ptr %t198)
  br label %bb58
bb58:
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t201, ptr %t203)
  br label %bb59
bb59:
  br label %bb153
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t207 = load ptr, ptr %l109, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb61, label %bb62
bb61:
  %t210 = load ptr, ptr %l109, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 28}
  %t213 = icmp eq i64 %t211, 8
  store i1 %t213, ptr %l110, !tbaa !21
  br label %bb62
bb62:
  %t214 = load i1, ptr %l110, !tbaa !21
  br i1 %t214, label %bb63, label %bb64
bb63:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l7, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l8, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t229, i32 0, i32 3
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l9, !tbaa !29
  br label %bb65
bb64:
  br label %bb69
bb65:
  %t233 = load ptr, ptr %l7, !tbaa !29
  %t235 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t233, ptr %t235)
  br label %bb66
bb66:
  %t238 = load ptr, ptr %l8, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t240)
  br label %bb67
bb67:
  %t243 = load ptr, ptr %l9, !tbaa !29
  %t245 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t243, ptr %t245)
  br label %bb68
bb68:
  br label %bb153
bb69:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t249 = load ptr, ptr %l128, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb70, label %bb71
bb70:
  %t252 = load ptr, ptr %l128, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 28}
  %t255 = icmp eq i64 %t253, 7
  store i1 %t255, ptr %l129, !tbaa !21
  br label %bb71
bb71:
  %t256 = load i1, ptr %l129, !tbaa !21
  br i1 %t256, label %bb72, label %bb73
bb72:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr }, ptr %t259, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l10, !tbaa !29
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t263 = load ptr, ptr %l10, !tbaa !29
  %t265 = getelementptr %"compiler/ast:Chain", ptr %t263, i32 0, i32 1
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  %t267 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t266, ptr %t267)
  br label %bb75
bb75:
  br label %bb153
bb76:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb77, label %bb78
bb77:
  %t274 = load ptr, ptr %l137, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 28}
  %t277 = icmp eq i64 %t275, 10
  store i1 %t277, ptr %l138, !tbaa !21
  br label %bb78
bb78:
  %t278 = load i1, ptr %l138, !tbaa !21
  br i1 %t278, label %bb79, label %bb80
bb79:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l11, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 2
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l12, !tbaa !27
  br label %bb85
bb80:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t292 = load ptr, ptr %l145, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb81, label %bb82
bb81:
  %t295 = load ptr, ptr %l145, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 28}
  %t298 = icmp eq i64 %t296, 13
  store i1 %t298, ptr %l146, !tbaa !21
  br label %bb82
bb82:
  %t299 = load i1, ptr %l146, !tbaa !21
  br i1 %t299, label %bb83, label %bb84
bb83:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t302, i32 0, i32 1
  %t304 = load ptr, ptr %t303
  store ptr %t304, ptr %l11, !tbaa !29
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t308, i32 0, i32 2
  %t310 = load { i64, ptr }, ptr %t309
  store { i64, ptr } %t310, ptr %l12, !tbaa !27
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t312 = load ptr, ptr %l11, !tbaa !29
  %t314 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t312, ptr %t314)
  br label %bb86
bb86:
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t318 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t317, ptr %t318)
  br label %bb87
bb87:
  br label %bb153
bb88:
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t322 = load ptr, ptr %l158, !tbaa !29
  %t323 = icmp ne ptr %t322, null
  br i1 %t323, label %bb89, label %bb90
bb89:
  %t325 = load ptr, ptr %l158, !tbaa !29
  %t326 = load i64, ptr %t325, !range !{i64 0, i64 28}
  %t328 = icmp eq i64 %t326, 14
  store i1 %t328, ptr %l159, !tbaa !21
  br label %bb90
bb90:
  %t329 = load i1, ptr %l159, !tbaa !21
  br i1 %t329, label %bb91, label %bb92
bb91:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t332, i32 0, i32 1
  %t334 = load ptr, ptr %t333
  store ptr %t334, ptr %l13, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t338, i32 0, i32 2
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l14, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t344, i32 0, i32 3
  %t346 = load ptr, ptr %t345
  store ptr %t346, ptr %l15, !tbaa !29
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t348 = load ptr, ptr %l13, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t348, ptr %t350)
  br label %bb94
bb94:
  %t353 = load ptr, ptr %l14, !tbaa !29
  %t354 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t353, ptr %t354)
  br label %bb95
bb95:
  %t357 = load ptr, ptr %l15, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t357, ptr %t358)
  br label %bb96
bb96:
  br label %bb153
bb97:
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t362 = load ptr, ptr %l175, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb98, label %bb99
bb98:
  %t365 = load ptr, ptr %l175, !tbaa !29
  %t366 = load i64, ptr %t365, !range !{i64 0, i64 28}
  %t368 = icmp eq i64 %t366, 15
  store i1 %t368, ptr %l176, !tbaa !21
  br label %bb99
bb99:
  %t369 = load i1, ptr %l176, !tbaa !21
  br i1 %t369, label %bb100, label %bb101
bb100:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t372, i32 0, i32 1
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l16, !tbaa !29
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t378, i32 0, i32 2
  %t380 = load ptr, ptr %t379
  store ptr %t380, ptr %l17, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t382 = load ptr, ptr %l16, !tbaa !29
  %t383 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t382, ptr %t383)
  br label %bb103
bb103:
  %t386 = load ptr, ptr %l17, !tbaa !29
  %t387 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t386, ptr %t387)
  br label %bb104
bb104:
  br label %bb153
bb105:
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t391 = load ptr, ptr %l187, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %bb106, label %bb107
bb106:
  %t394 = load ptr, ptr %l187, !tbaa !29
  %t395 = load i64, ptr %t394, !range !{i64 0, i64 28}
  %t397 = icmp eq i64 %t395, 16
  store i1 %t397, ptr %l188, !tbaa !21
  br label %bb107
bb107:
  %t398 = load i1, ptr %l188, !tbaa !21
  br i1 %t398, label %bb108, label %bb109
bb108:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr { i64, [4 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t401, i32 0, i32 2
  %t403 = load { i64, ptr }, ptr %t402
  store { i64, ptr } %t403, ptr %l18, !tbaa !27
  br label %bb122
bb109:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t406 = load ptr, ptr %l193, !tbaa !29
  %t407 = icmp ne ptr %t406, null
  br i1 %t407, label %bb110, label %bb111
bb110:
  %t409 = load ptr, ptr %l193, !tbaa !29
  %t410 = load i64, ptr %t409, !range !{i64 0, i64 28}
  %t412 = icmp eq i64 %t410, 17
  store i1 %t412, ptr %l194, !tbaa !21
  br label %bb111
bb111:
  %t413 = load i1, ptr %l194, !tbaa !21
  br i1 %t413, label %bb112, label %bb113
bb112:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr { i64, [4 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t416, i32 0, i32 1
  %t418 = load { i64, ptr }, ptr %t417
  store { i64, ptr } %t418, ptr %l18, !tbaa !27
  br label %bb122
bb113:
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t421 = load ptr, ptr %l199, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb114, label %bb115
bb114:
  %t424 = load ptr, ptr %l199, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 28}
  %t427 = icmp eq i64 %t425, 27
  store i1 %t427, ptr %l200, !tbaa !21
  br label %bb115
bb115:
  %t428 = load i1, ptr %l200, !tbaa !21
  br i1 %t428, label %bb116, label %bb117
bb116:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t431, i32 0, i32 1
  %t433 = load { i64, ptr }, ptr %t432
  store { i64, ptr } %t433, ptr %l18, !tbaa !27
  br label %bb122
bb117:
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t436 = load ptr, ptr %l205, !tbaa !29
  %t437 = icmp ne ptr %t436, null
  br i1 %t437, label %bb118, label %bb119
bb118:
  %t439 = load ptr, ptr %l205, !tbaa !29
  %t440 = load i64, ptr %t439, !range !{i64 0, i64 28}
  %t442 = icmp eq i64 %t440, 22
  store i1 %t442, ptr %l206, !tbaa !21
  br label %bb119
bb119:
  %t443 = load i1, ptr %l206, !tbaa !21
  br i1 %t443, label %bb120, label %bb121
bb120:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr { i64, [4 x i64] }, ptr %t444, i32 0, i32 1
  %t447 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t446, i32 0, i32 1
  %t448 = load { i64, ptr }, ptr %t447
  store { i64, ptr } %t448, ptr %l18, !tbaa !27
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t450 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t451 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t450, ptr %t451)
  br label %bb123
bb123:
  br label %bb153
bb124:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t455 = load ptr, ptr %l213, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb125, label %bb126
bb125:
  %t458 = load ptr, ptr %l213, !tbaa !29
  %t459 = load i64, ptr %t458, !range !{i64 0, i64 28}
  %t461 = icmp eq i64 %t459, 19
  store i1 %t461, ptr %l214, !tbaa !21
  br label %bb126
bb126:
  %t462 = load i1, ptr %l214, !tbaa !21
  br i1 %t462, label %bb127, label %bb128
bb127:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr { i64, [4 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t465, i32 0, i32 1
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l19, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr { i64, [4 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t471, i32 0, i32 2
  %t473 = load { i64, ptr }, ptr %t472
  store { i64, ptr } %t473, ptr %l20, !tbaa !27
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t475 = load ptr, ptr %l19, !tbaa !29
  %t477 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t475, ptr %t477)
  br label %bb130
bb130:
  %t480 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t481 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t480, ptr %t481)
  br label %bb131
bb131:
  br label %bb153
bb132:
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t485 = load ptr, ptr %l226, !tbaa !29
  %t486 = icmp ne ptr %t485, null
  br i1 %t486, label %bb133, label %bb134
bb133:
  %t488 = load ptr, ptr %l226, !tbaa !29
  %t489 = load i64, ptr %t488, !range !{i64 0, i64 28}
  %t491 = icmp eq i64 %t489, 21
  store i1 %t491, ptr %l227, !tbaa !21
  br label %bb134
bb134:
  %t492 = load i1, ptr %l227, !tbaa !21
  br i1 %t492, label %bb135, label %bb136
bb135:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr { i64, [4 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", ptr }, ptr %t495, i32 0, i32 1
  %t497 = load ptr, ptr %t496
  store ptr %t497, ptr %l21, !tbaa !29
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t499 = load ptr, ptr %l21, !tbaa !29
  %t500 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t499, ptr %t500)
  br label %bb138
bb138:
  br label %bb153
bb139:
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t504 = load ptr, ptr %l234, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb140, label %bb141
bb140:
  %t507 = load ptr, ptr %l234, !tbaa !29
  %t508 = load i64, ptr %t507, !range !{i64 0, i64 28}
  %t510 = icmp eq i64 %t508, 18
  store i1 %t510, ptr %l235, !tbaa !21
  br label %bb141
bb141:
  %t511 = load i1, ptr %l235, !tbaa !21
  br i1 %t511, label %bb142, label %bb143
bb142:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr { i64, [4 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", ptr }, ptr %t514, i32 0, i32 1
  %t516 = load ptr, ptr %t515
  store ptr %t516, ptr %l22, !tbaa !29
  br label %bb144
bb143:
  br label %bb148
bb144:
  %t518 = load ptr, ptr %l22, !tbaa !29
  %t520 = getelementptr %"compiler/ast:Compr", ptr %t518, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !29
  %t523 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t521, ptr %t523)
  br label %bb145
bb145:
  %t526 = load ptr, ptr %l22, !tbaa !29
  %t528 = getelementptr %"compiler/ast:Compr", ptr %t526, i32 0, i32 4
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t529, ptr %t531)
  br label %bb146
bb146:
  %t534 = load ptr, ptr %l22, !tbaa !29
  %t536 = getelementptr %"compiler/ast:Compr", ptr %t534, i32 0, i32 5
  %t537 = load ptr, ptr %t536, !tbaa !29
  %t538 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t537, ptr %t538)
  br label %bb147
bb147:
  br label %bb153
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_9cea8b157736196b_cebcd42f5be7b27)
  unreachable
bb153:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2eunchecked(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca ptr
  %t49 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l2, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 54}
  store i32 %t26, ptr %l3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 4}
  store i32 %t32, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t40 = load i32, ptr %l4, !range !{i32 0, i32 4}
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = load %"compiler/source:Span", ptr %l1
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 0
  store i64 9, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t45, 0
  %t54 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t52, i32 %t46, 1
  %t56 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t54, i32 %t47, 2
  %t58 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t56, i32 0, 3
  %t60 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t58, { i64, ptr } %t48, 4
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t60, ptr %t61
  %t62 = load { i64, [5 x i64] }, ptr %t49
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t62, ptr %t64
  store ptr %t64, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_119ba3895c46c2f1_96434e6a233c01d5)
  unreachable
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i64
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca %"compiler/check:b5aWalk"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call ptr @__olang_scope_hold(ptr %v0)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l10, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l10
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t10)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e1
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l10
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr %t22
  %t30 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr %t29
  call void @__olang_region_settle_in(ptr %t15, ptr %t36)
  br label %bb5
bb5:
  %t37 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l2
  %t38 = call ptr @__olang_scope_hold(ptr %v0)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l14, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e2
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = call ptr @__olang_region_make(ptr %v0)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l14
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t45, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l16
  br label %bb8
bb8:
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e2
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l14
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_region_or(ptr %t53, ptr null)
  %t55 = call ptr @__olang_region_home(ptr %t54)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t50, ptr %t57)
  br label %bb10
bb10:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l3
  %t59 = call ptr @__olang_scope_hold(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l18, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e3
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = call ptr @__olang_region_make(ptr %v0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l18, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l18
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t66, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l20
  br label %bb13
bb13:
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e3
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l18
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = call ptr @__olang_region_home(ptr %t75)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t78)
  br label %bb15
bb15:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l4
  %t80 = call ptr @__olang_scope_hold(ptr %v0)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l22, !tbaa !24
  %t82 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e4
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = call ptr @__olang_region_make(ptr %v0)
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l22, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l22
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t87)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %l24
  br label %bb18
bb18:
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e4
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load i64, ptr %l22
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = call ptr @__olang_region_home(ptr %t96)
  %t98 = icmp ne ptr %t97, null
  %t99 = select i1 %t98, ptr %t97, ptr null
  %t100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr %t99
  %t107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = call ptr @__olang_region_or(ptr %t109, ptr null)
  %t111 = call ptr @__olang_region_home(ptr %t110)
  %t112 = icmp ne ptr %t111, null
  %t113 = select i1 %t112, ptr %t111, ptr %t106
  call void @__olang_region_settle_in(ptr %t92, ptr %t113)
  br label %bb20
bb20:
  %t114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l5
  %t115 = call ptr @__olang_scope_hold(ptr %v0)
  %t116 = ptrtoint ptr %t115 to i64
  store i64 %t116, ptr %l26, !tbaa !24
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e5
  br i1 %t117, label %bb21, label %bb22
bb21:
  %t119 = call ptr @__olang_region_make(ptr %v0)
  %t120 = ptrtoint ptr %t119 to i64
  store i64 %t120, ptr %l26, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l26
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %t122)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t123, ptr %l28
  br label %bb23
bb23:
  %t124 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e5
  br i1 %t124, label %bb24, label %bb25
bb24:
  %t126 = load i64, ptr %l26
  %t127 = inttoptr i64 %t126 to ptr
  %t128 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 2
  %t129 = load { i64, ptr }, ptr %t128
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = call ptr @__olang_region_home(ptr %t131)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, ptr %t132, ptr null
  %t135 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 1
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr %t134
  %t142 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = call ptr @__olang_region_or(ptr %t144, ptr null)
  %t146 = call ptr @__olang_region_home(ptr %t145)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr %t141
  call void @__olang_region_settle_in(ptr %t127, ptr %t148)
  br label %bb25
bb25:
  %t149 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t150 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 0
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %t150, !tbaa !24
  %t152 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 1
  %t153 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t153, ptr %t152
  %t154 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 2
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %t154
  %t156 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 3
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %t156
  %t158 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 4
  %t159 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t159, ptr %t158
  %t160 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t149, ptr %t160
  %t162 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 6
  store i1 false, ptr %t162, !tbaa !21
  %t164 = getelementptr %"compiler/check:b5aWalk", ptr %l30, i32 0, i32 7
  store i1 false, ptr %t164, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/check:ctSource"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:ctSource" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/check:ctSource" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/check:ctSource" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/check:ctSource" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:ctSource" %t18, { i64, ptr } %a4, 4
  store %"compiler/check:ctSource" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ctSource", ptr %rv
  ret %"compiler/check:ctSource" %rr
}

define dso_local %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6) #0 {
entry:
  %rv = alloca %"compiler/check:factRead"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/check:factRead" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/check:factRead" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/check:factRead" %t18, { i64, ptr } %a2, 2
  %t22 = insertvalue %"compiler/check:factRead" %t20, i1 %a3, 3
  %t24 = insertvalue %"compiler/check:factRead" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/check:factRead" %t24, %"compiler/source:Span" %a5, 5
  %t28 = insertvalue %"compiler/check:factRead" %t26, { i64, ptr } %a6, 6
  store %"compiler/check:factRead" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factRead", ptr %rv
  ret %"compiler/check:factRead" %rr
}

define dso_local %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/check:idleCall"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:idleCall" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:idleCall" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:idleCall" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:idleCall" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/check:idleCall" %t18, ptr %a4, 4
  store %"compiler/check:idleCall" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:idleCall", ptr %rv
  ret %"compiler/check:idleCall" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eanySpawned_2elocal_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare void @__olang_region_release(ptr) noinline
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a call of a name of this kind" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2 = weak hidden constant i1 false
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@olang_2esole_2ecompiler_2fcheck_3anarrowed_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3anullNarrow_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3aerrNarrow_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3aChecker_2e66 = weak hidden constant i1 false
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3actSource_2e4 = weak hidden constant i1 false
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"copy" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d20 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d21 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aframe_2e50 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2ecompiler_2fcheck_3aframe_2e46 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3aframe_2e62 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2e0 = weak hidden constant i1 false
@.d24 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3afactRead_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2efnFact_2elocal_2e13 = weak hidden constant i1 false
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<T>." }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<T>." }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d31 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a generator whose Generator has no constructor" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ejudgeSlot_2elocal_2e5 = weak hidden constant i1 false
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:Verdict"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca %"compiler/effects:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:Verdict", ptr %a0
  store %"compiler/effects:Verdict" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l11, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l13, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t70 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  store { i64, ptr } %t69, ptr %t70, !tbaa !27
  %t71 = load %"compiler/effects:Verdict", ptr %l1
  store %"compiler/effects:Verdict" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e7 = weak hidden constant i1 false
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d37 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Array<I64>[]" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aTaskClause_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aClause_2e1 = weak hidden constant i1 false
@olang_2esole_2eArray_3ccompiler_2ftyped_3aConst_26_3e_2e_2d1 = weak hidden constant i1 false
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eunknownType_2elocal_2e6 = weak hidden constant i1 false
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a function type" }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"an any" }>, align 8
@.d44 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"an extern type" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"an array" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a function type" }>, align 8
@.d49 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"no struct or enum" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d51 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@.d53 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Commutes" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3ab5aWalk_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@olang_loc_5d13064994ae0ba3_8fd3ca0506e03b5f = external constant [0 x i8]
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f696ab3dd58ed55_6fb72788626d8d91 = external constant [0 x i8]
@olang_loc_53a208522c5b83d_88406af5a3018049 = external constant [0 x i8]
@olang_loc_396e8fee6f4dc59f_ecca1e109e67d07b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_6af63211fe08a219_4bcf48e786826ca5 = external constant [0 x i8]
@olang_loc_31ceea79ef23e30c_3748df63b5867238 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, i32 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodMeant(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionSelf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFnCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, %"compiler/generic:Desc" %a3, { i64, ptr } %a4)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordCalled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b1d60606349c196f_148fe1dbe07e141b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_f3fef639868d2bb5_dd9676d0e98a8921 = external constant [0 x i8]
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_df1f5fd28061949_6fd2bc487e6b648d = external constant [0 x i8]
@olang_loc_adf1079d57e55808_9269da6a723799fc = external constant [0 x i8]
@olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a = external constant [0 x i8]
@olang_loc_92a21335b7ae999a_7e07c1814bb2a646 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_abe1ff4556bedc08_80ba96099639cb2c = external constant [0 x i8]
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7 = external constant [0 x i8]
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b4897252f2a0467_e1365b27726b9d63 = external constant [0 x i8]
@olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2 = external constant [0 x i8]
@olang_loc_e882b6948f69dce8_e6367676615923ec = external constant [0 x i8]
@olang_loc_9e6114e2cf841093_fa90ce222875bd2f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c349e4c9332250dd_9daf9d91ff07ef41 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_90c216d2a7707e63_13ebc04feeb9a31f = external constant [0 x i8]
@olang_loc_e7cf760e54914750_8299ab19ca729e9c = external constant [0 x i8]
@olang_loc_2de9afb4b96dcf94_71a46e56f9644858 = external constant [0 x i8]
@olang_loc_6d051d6c732886d2_d9cb433bcdc0e6 = external constant [0 x i8]
@olang_loc_fd3792a3478c708a_bd2f712e645466e6 = external constant [0 x i8]
@olang_loc_12b3dc107423b434_482fbf8ad69d32f8 = external constant [0 x i8]
@olang_loc_4090f31281295d0b_b76133cd00d27c97 = external constant [0 x i8]
@olang_loc_ee572ef2923bf685_6f413c271381cde1 = external constant [0 x i8]
@olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f9674bcb1008789c_bed0ff146db7b878 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_7d2067b11442aa69_727f8f68f20a38e5 = external constant [0 x i8]
@olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_db85c439bc9f5684_3c0400873f27ba78 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fast_2eRequirements(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_7d341668197b23b8_39fb9abd34d1e724 = external constant [0 x i8]
@olang_loc_82b8e88501244989_8304f205bc7c5615 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bdeebae2e62e4381_d7e2b33750a898f5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrComparedNotError(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4)
@olang_loc_fde34f6ad3d04e85_8bb8dc064f471149 = external constant [0 x i8]
@olang_loc_7e2870e38111b7d4_913a9c3a02b86678 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorMethodGiven(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8e26fbb1c5557eef_13e6cc5de085742b = external constant [0 x i8]
@olang_loc_6d702b04e725ae1a_71c02c55b3dfc416 = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0)
@olang_loc_602058b5bbdc5ba4_407e96c83aaf1680 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ePush_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:idleCall" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_a929affe4386ca95_c275f1e9d349f711 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dd139b797ad07c59_48ae02fb28d54045 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ce477a1e17d80ea_6907ddc3684fedfe = external constant [0 x i8]
declare %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %a0, %"compiler/check:factsMark" %a1)
declare i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factRead" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2eConservative(i32 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9cda55992b6a58cc_f4ed715c72ea34c8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValueAway(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenSlot(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
@olang_loc_15eb6f7c806fc73b_bac9f6515206ea7f = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eGenFromReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i64 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8107208a4245ff9c_ccbe9a9f570baf38 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feffects_2eEffectWords = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\7F\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %v0)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eJudgeFacts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eFirstCallee(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eBlame(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/effects:Verdict" %a1, i64 %a2, { i64, ptr } %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMethodEffect(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteEffect(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_24a46e21631caff9_33b011dc8e05d16d = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eLaneSel = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWorksIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %out, ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDotShape(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMissingIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotInModule(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrVarNotType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgCountMet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, %"compiler/names:Ref" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
@olang_loc_4d0d10dbd8c28898_8d57e58513238834 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEnds(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoTarget(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownMap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_78b67e7b86d014f7_b202530d028f16d3 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownElem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elayRows(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e10ca684bef0956d_f742028d37a3af11 = external constant [0 x i8]
@olang_loc_c3afd3921db70d3f_27f9f6390ccac16b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_da760de622febe3_df78aa298e2a00e7 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0)
@olang_loc_5ca7d448b00003f5_5d17299a767670c1 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCFuncTask(ptr %v0)
@olang_loc_a0a2b29f181c5519_be518ce768fc1fe5 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ebab815881a318c_398bac8a238c0b80 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e78286934eafcc6f_802ae2752731a35b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_3727962a9e2e15db_7cf774666c9d4227 = external constant [0 x i8]
@olang_loc_81d441761e2a717d_f45e749fdf1e1e81 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
@olang_loc_4caebcac4cec7311_26f3d9a9847d99e5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %a0, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeStd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownConstraint(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f342226b8bcffe86_cb7cec1b8bc140d2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a797700ef8100967_b92f0bde838bc4d3 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_d5cbe87213397023_e63da241b79e21f = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_922ae0a799ba69ce_f9cc72ab99b0ec2 = external constant [0 x i8]
@olang_loc_46a0e749826cef18_3e2809181fcd5dac = external constant [0 x i8]
@olang_loc_2f12767f94a228d4_8b6b4888798b3f68 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1)
@olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a = external constant [0 x i8]
@olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf = external constant [0 x i8]
@olang_loc_5df9bd969218a728_7fa184e5bc45956c = external constant [0 x i8]
@olang_loc_69c4f09cb804b315_a031ca4d3ae928f9 = external constant [0 x i8]
@olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9cea8b157736196b_cebcd42f5be7b27 = external constant [0 x i8]
@olang_loc_119ba3895c46c2f1_96434e6a233c01d5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
