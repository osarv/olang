; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_9799f17155897ea8_ecf4214bd60fd3c4 = weak_odr constant [55 x i8] c"std/prelude/print.olang:24: slice bounds out of range\0A\00"
