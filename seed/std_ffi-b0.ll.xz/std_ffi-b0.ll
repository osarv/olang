; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
define dso_local { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i8 %a3, i64 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l26 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l48 = alloca i1
  %l58 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l78 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l93 = alloca { i64, ptr }
  %l113 = alloca i32
  %l127 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i8 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb22
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t15, ptr %l26, !tbaa !27
  %t16 = load i64, ptr %l7, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l9, !tbaa !22
  %t23 = load i8, ptr %l9, !tbaa !22
  %t25 = icmp eq i8 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t28, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load i8, ptr %l9, !tbaa !22
  %t31 = icmp ult i8 %t29, -128
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l5, !tbaa !24
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sge i64 %t38, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t47 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t47, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l42, !tbaa !27
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i64, ptr %t52, i64 %t49
  %t54 = load i64, ptr %t53, !tbaa !85
  store i64 %t54, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp slt i64 %t57, 0
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb16
bb15:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t72 = mul i64 %t70, 8
  %t75 = icmp sgt i64 %t61, %t72
  store i1 %t75, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t79 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t79, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t80 = load i64, ptr %l5, !tbaa !24
  store i64 %t80, ptr %l58, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  store i64 %t81, ptr %l59, !tbaa !24
  %t82 = load i8, ptr %l9, !tbaa !22
  %t84 = and i8 %t82, 127
  %t86 = call i64 @std_2fffi_2ewidth(i8 %t84)
  store i64 %t86, ptr %l62
  br label %bb20
bb20:
  %t87 = load i64, ptr %l59, !tbaa !24
  %t88 = load i64, ptr %l62, !tbaa !24
  %t89 = mul i64 %t87, %t88
  %t91 = add i64 %t89, 7
  %t93 = sdiv i64 %t91, 8
  %t95 = add i64 1, %t93
  %t96 = load i64, ptr %l58, !tbaa !24
  %t98 = add i64 %t96, %t95
  store i64 %t98, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb1
bb22:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = icmp sgt i64 %t105, %t108
  br i1 %t111, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t114 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t114, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l78, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  %t121 = icmp sge i64 %t120, 0
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load i64, ptr %l78, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l11, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t129, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = sub i64 %t135, 1
  store i64 %t136, ptr %l84, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = icmp slt i64 %t137, 2147483648
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = icmp sge i64 %t139, 0
  %t143 = and i1 %t138, %t140
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_8abc9384c4eef1e5_cd004ffb84c268d1)
  unreachable
bb28:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t154, ptr %l93, !tbaa !27
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t155
  %t160 = load i8, ptr %t159, !tbaa !32
  %t166 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t152
  store i8 %t160, ptr %t168, !tbaa !32
  br label %bb32
bb32:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb28
bb33:
  %t176 = extractvalue { i64, ptr } %a0, 1
  %t177 = extractvalue { i64, ptr } %a0, 0
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = getelementptr i8, ptr %t181, i64 %t177
  call void @olang_textcopy(ptr %t182, ptr %t178, i64 %t179)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  store { i64, ptr } %t184, ptr %l17, !tbaa !27
  %t186 = load i64, ptr %l4, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t192 = icmp sgt i64 %t186, %t189
  br i1 %t192, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t195 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t195, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t196 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t199 = load i8, ptr %l3, !tbaa !22
  %t200 = load i64, ptr %l4, !tbaa !24
  %t202 = extractvalue { i64, ptr } %t196, 1
  %t203 = extractvalue { i64, ptr } %t196, 0
  %t205 = extractvalue { i64, ptr } %t198, 1
  %t206 = extractvalue { i64, ptr } %t198, 0
  %t209 = call i32 @__olang_dyncall_var_check(ptr %t202, ptr %t205, i8 zeroext %t199, i64 %t200)
  store i32 %t209, ptr %l113
  br label %bb37
bb37:
  %t210 = load i32, ptr %l113, !tbaa !23
  store i32 %t210, ptr %l18, !tbaa !23
  %t211 = load i32, ptr %l18, !tbaa !23
  %t213 = icmp eq i32 %t211, 1
  br i1 %t213, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t216 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t216, ptr %rv
  br label %ret
bb41:
  %t217 = load i32, ptr %l18, !tbaa !23
  %t219 = icmp eq i32 %t217, 2
  br i1 %t219, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t222 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t222, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ff20c9fa943c3ec7_a348c6c6ec1ff0ab)
  unreachable
bb50:
  %t223 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t228 = load i8, ptr %l3, !tbaa !22
  %t229 = load i64, ptr %l4, !tbaa !24
  %t231 = extractvalue { i64, ptr } %t223, 1
  %t232 = extractvalue { i64, ptr } %t223, 0
  %t234 = extractvalue { i64, ptr } %t225, 1
  %t235 = extractvalue { i64, ptr } %t225, 0
  %t237 = extractvalue { i64, ptr } %t226, 1
  %t238 = extractvalue { i64, ptr } %t226, 0
  %t241 = call i64 @__olang_dyncall_var(ptr %t231, ptr %t234, ptr %t237, i8 zeroext %t228, i64 %t229)
  store i64 %t241, ptr %l127
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t242 = load i64, ptr %l127, !tbaa !65
  %t243 = insertvalue { i32, i64 } zeroinitializer, i64 %t242, 1
  store { i32, i64 } %t243, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @std_2fffi_2ewidth(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 5
  br i1 %t7, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i64 1, ptr %l1, !tbaa !24
  br label %bb29
bb6:
  %t9 = load i8, ptr %l0, !tbaa !22
  %t11 = icmp eq i8 %t9, 2
  br i1 %t11, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t13 = load i8, ptr %l0, !tbaa !22
  %t15 = icmp eq i8 %t13, 6
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t17 = load i8, ptr %l0, !tbaa !22
  %t19 = icmp eq i8 %t17, 9
  br i1 %t19, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t21 = load i8, ptr %l0, !tbaa !22
  %t23 = icmp eq i8 %t21, 10
  br i1 %t23, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 2, ptr %l1, !tbaa !24
  br label %bb29
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 3
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t29 = load i8, ptr %l0, !tbaa !22
  %t31 = icmp eq i8 %t29, 7
  br i1 %t31, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t33 = load i8, ptr %l0, !tbaa !22
  %t35 = icmp eq i8 %t33, 11
  br i1 %t35, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 4, ptr %l1, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 8, ptr %l1, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_693223463d286ace_cb376d1b1db73152)
  unreachable
bb29:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i32 @__olang_dyncall_var_check(ptr, ptr, i8 zeroext, i64)
declare i64 @__olang_dyncall_var(ptr, ptr, ptr, i8 zeroext, i64)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_8abc9384c4eef1e5_cd004ffb84c268d1 = external constant [0 x i8]
@olang_loc_ff20c9fa943c3ec7_a348c6c6ec1ff0ab = external constant [0 x i8]
@olang_loc_693223463d286ace_cb376d1b1db73152 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
