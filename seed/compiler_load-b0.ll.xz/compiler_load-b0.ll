; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"compiler/cond:Scope" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:Translation" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/cond:Decision" = type { i32, i1 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/diagmsg:Msg", i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
define dso_local i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t11)
  store i1 %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 0
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp eq i8 %t19, 95
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l8, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb12, label %bb13
bb12:
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  store i8 %t48, ptr %l4, !tbaa !22
  %t50 = load i8, ptr %l4, !tbaa !22
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t50)
  store i1 %t52, ptr %l29
  br label %bb15
bb15:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t54 = load i8, ptr %l4, !tbaa !22
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t54)
  store i1 %t56, ptr %l32
  br label %bb18
bb18:
  %t57 = load i1, ptr %l32, !tbaa !21
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb22
bb21:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = icmp eq i8 %t59, 95
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb23, label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l2, !tbaa !24
  br label %bb11
bb27:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fload_2eCTypeDecls(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca %"std/prelude/text:LineIter"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l71 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i64
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp2
  %t8 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t8, !tbaa !27
  %t9 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t10, ptr %l3
  %t13 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load %"std/prelude/text:LineIter", ptr %l11
  store %"std/prelude/text:LineIter" %t14, ptr %l4
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l4)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l15
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store { i64, ptr } %t17, ptr %l14
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  br label %bb8
bb6:
  %t22 = load i32, ptr %l15, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb8:
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  %t27 = load ptr, ptr %lp2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = extractvalue { i64, ptr } %t34, 0
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = getelementptr i8, ptr %t41, i64 %t37
  call void @olang_textcopy(ptr %t42, ptr %t38, i64 %t39)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t44)
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t48, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t50, ptr %l40
  br label %bb23
bb12:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t51, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t53, ptr %l26
  br label %bb13
bb13:
  %t54 = load i1, ptr %l26, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %lp1
  store ptr %t57, ptr %l28, !tbaa !29
  %t58 = load ptr, ptr %lp2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = call ptr @__olang_scope_hold(ptr %v1)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l30, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = call ptr @__olang_region_make(ptr %v1)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb18
bb18:
  %t66 = load i64, ptr %l30
  %t67 = inttoptr i64 %t66 to ptr
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t67, ptr %l3)
  store { i64, ptr } %t69, ptr %l33
  br label %bb19
bb19:
  %t70 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t71 = load ptr, ptr %l28, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v1, ptr %v1, ptr %v1, ptr %t71, { i64, ptr } %t72, { i64, ptr } %t70)
  br label %bb20
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t75 = load ptr, ptr %lp2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l37, !tbaa !27
  %t78 = load ptr, ptr %lp2
  store { i64, ptr } %t74, ptr %t78, !tbaa !27
  %t79 = load i1, ptr @olang_2esole_2ecompiler__2fload__2eCTypeDecls_2elocal_2e2
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load { i64, ptr }, ptr %l37
  %t82 = extractvalue { i64, ptr } %t81, 1
  call void @__olang_region_release(ptr %t82)
  store { i64, ptr } zeroinitializer, ptr %l37
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb23:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t84, ptr %l42, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t85, 0
  store i64 %t88, ptr %l45, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l46, !tbaa !24
  %t91 = icmp sge i64 9, 0
  br i1 %t91, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb33
bb26:
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = icmp sle i64 9, %t93
  br i1 %t94, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_53160a2f7dd07190_f4bb70ca8fd9d2a4)
  unreachable
bb28:
  %t96 = load i64, ptr %l45, !tbaa !24
  %t97 = load i64, ptr %l46, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_53160a2f7dd07190_f4bb70ca8fd9d2a4)
  unreachable
bb30:
  %t100 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = getelementptr i8, ptr %t101, i64 9
  %t104 = sub i64 %t102, 9
  %t105 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t110 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t106, { i64, ptr } %t109)
  store i1 %t110, ptr %l53
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_53160a2f7dd07190_f4bb70ca8fd9d2a4)
  unreachable
bb32:
  %t111 = load i1, ptr %l53, !tbaa !21
  %t112 = xor i1 %t111, true
  store i1 %t112, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t114 = load i1, ptr %l41, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t115 = load ptr, ptr %lp1
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = call ptr @__olang_scope_hold(ptr %v1)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l56, !tbaa !24
  %t118 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t118, label %bb36, label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s10, { i64, ptr } %t120, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t122, ptr %l83
  br label %bb53
bb36:
  %t123 = call ptr @__olang_region_make(ptr %v1)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l56, !tbaa !24
  br label %bb37
bb37:
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l58, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t126, 0
  store i64 %t129, ptr %l61, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l62, !tbaa !24
  %t132 = icmp sge i64 9, 0
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t134 = load i64, ptr %l61, !tbaa !24
  %t135 = icmp sle i64 9, %t134
  br i1 %t135, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb40:
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb42:
  %t141 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l61, !tbaa !24
  %t144 = getelementptr i8, ptr %t142, i64 9
  %t145 = sub i64 %t143, 9
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = load i64, ptr %l56
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_held_alloc(ptr %t152, i64 %t150)
  call void @olang_textcopy(ptr %t153, ptr %t149, i64 %t150)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l68, !tbaa !27
  %t157 = call ptr @__olang_scope_hold(ptr %v1)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l69, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t159, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb44:
  %t161 = call ptr @__olang_region_make(ptr %v1)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l69, !tbaa !24
  br label %bb45
bb45:
  %t163 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t164, 0
  store i64 %t167, ptr %l74, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l75, !tbaa !24
  %t170 = icmp sge i64 4, 0
  br i1 %t170, label %bb46, label %bb47
bb46:
  %t172 = load i64, ptr %l74, !tbaa !24
  %t173 = icmp sle i64 4, %t172
  br i1 %t173, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb48:
  %t175 = load i64, ptr %l74, !tbaa !24
  %t176 = load i64, ptr %l75, !tbaa !24
  %t177 = icmp sle i64 %t175, %t176
  br i1 %t177, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb50:
  %t179 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l74, !tbaa !24
  %t182 = getelementptr i8, ptr %t180, i64 4
  %t183 = sub i64 %t181, 4
  %t184 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = extractvalue { i64, ptr } %t185, 0
  %t189 = load i64, ptr %l69
  %t190 = inttoptr i64 %t189 to ptr
  %t191 = call ptr @__olang_held_alloc(ptr %t190, i64 %t188)
  call void @olang_textcopy(ptr %t191, ptr %t187, i64 %t188)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t195 = load ptr, ptr %l55, !tbaa !29
  %t196 = load { i64, ptr }, ptr %l68, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v1, ptr %v1, ptr %v1, ptr %t195, { i64, ptr } %t196, { i64, ptr } %t193)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_15d40d4750690f6d_e4c87d10d7941391)
  unreachable
bb52:
  br label %bb68
bb53:
  %t198 = load i1, ptr %l83, !tbaa !21
  br i1 %t198, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t199 = call ptr @__olang_scope_hold(ptr %v1)
  %t200 = ptrtoint ptr %t199 to i64
  store i64 %t200, ptr %l84, !tbaa !24
  %t201 = load i1, ptr @olang_2esole_2ecompiler__2fload__2eCTypeDecls_2elocal_2e2
  br i1 %t201, label %bb56, label %bb57
bb55:
  br label %bb67
bb56:
  %t203 = call ptr @__olang_region_make(ptr %v1)
  %t204 = ptrtoint ptr %t203 to i64
  store i64 %t204, ptr %l84, !tbaa !24
  br label %bb57
bb57:
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t206 = load i64, ptr %l84
  %t207 = inttoptr i64 %t206 to ptr
  %t209 = call { i64, ptr } @compiler_2fload_2etypeWord(ptr %v0, ptr %t207, { i64, ptr } %t205)
  store { i64, ptr } %t209, ptr %l87
  br label %bb58
bb58:
  %t210 = load i1, ptr @olang_2esole_2ecompiler__2fload__2eCTypeDecls_2elocal_2e2
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t212 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t215 = icmp eq i64 %t213, 0
  br i1 %t215, label %bb61, label %bb62
bb60:
  %t217 = load ptr, ptr %lp2
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l91, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t220 = load ptr, ptr %lp2
  store { i64, ptr } %t219, ptr %t220, !tbaa !27
  %t221 = load i1, ptr @olang_2esole_2ecompiler__2fload__2eCTypeDecls_2elocal_2e2
  br i1 %t221, label %bb63, label %bb64
bb61:
  store { i64, ptr } zeroinitializer, ptr %l87, !tbaa !27
  br label %bb62
bb62:
  %t223 = load i64, ptr %l84
  %t224 = inttoptr i64 %t223 to ptr
  %t225 = load { i64, ptr }, ptr %l87
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = call ptr @__olang_region_or(ptr %t226, ptr null)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr null
  call void @__olang_region_settle_in(ptr %t224, ptr %t229)
  br label %bb60
bb63:
  %t230 = load { i64, ptr }, ptr %l91
  %t231 = extractvalue { i64, ptr } %t230, 1
  call void @__olang_region_release(ptr %t231)
  store { i64, ptr } zeroinitializer, ptr %l91
  br label %bb64
bb64:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %s0, ptr %l3)
  br label %bb65
bb65:
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = extractvalue { i64, ptr } %t233, 0
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t235, i64 %t236)
  %t241 = getelementptr i8, ptr %t240, i64 %t236
  call void @olang_textcopy(ptr %t241, ptr %t237, i64 %t238)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l3, { i64, ptr } %t243)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s6)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  br label %bb4
bb71:
  %t247 = load ptr, ptr %lp1
  %t248 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t247
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t248, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local i1 @compiler_2fload_2eLinkIsFile(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb4
bb4:
  %t10 = load i1, ptr %l7, !tbaa !21
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb9
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb8
bb8:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb13
bb11:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t19, ptr %l13
  br label %bb12
bb12:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb17
bb15:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t26 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } %t25)
  store i1 %t26, ptr %l18
  br label %bb16
bb16:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fload_2eLinkName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb32
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  store i8 %t30, ptr %l5, !tbaa !22
  %t32 = load i8, ptr %l5, !tbaa !22
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t32)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t36)
  store i1 %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load i1, ptr %l25, !tbaa !21
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb27
bb17:
  %t45 = load i8, ptr %l5, !tbaa !22
  %t47 = icmp ne i8 %t45, 95
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp ne i8 %t49, 45
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t54 = load i8, ptr %l5, !tbaa !22
  %t56 = icmp ne i8 %t54, 43
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load i8, ptr %l5, !tbaa !22
  %t61 = icmp ne i8 %t59, 46
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t63 = load i1, ptr %l37, !tbaa !21
  store i1 %t63, ptr %l28, !tbaa !21
  br label %bb27
bb27:
  %t64 = load i1, ptr %l28, !tbaa !21
  br i1 %t64, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb4
bb32:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fload_2eLoader_2etest(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/cond:Consts"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l13 = alloca %"compiler/fetch:Fetcher"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca %"compiler/source:Names"
  %l18 = alloca ptr
  %l19 = alloca %"compiler/diag:Diagnostics"
  %l21 = alloca %"compiler/load:Loader"
  %t1 = alloca %"compiler/cond:Consts", align 8
  %t38 = alloca %"compiler/fetch:Fetcher", align 8
  %t61 = alloca %"compiler/diag:Diagnostics", align 8
  %t63 = alloca %"compiler/load:Loader", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcond_3aConsts_2ector(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %t1, i64 256, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 256, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l2, i64 256, i1 false)
  %t4 = load ptr, ptr %lp1
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, i64 128, i64 0, i1 false, i1 false, i1 false, i64 0)
  br label %bb2
bb2:
  %t6 = load ptr, ptr %lp1
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_hold(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e2
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = call ptr @__olang_region_make(ptr %v1)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = load i64, ptr %l5
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_scope_hold(ptr %t15)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l8, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l5
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = call ptr @__olang_region_make(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l8
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  call void @olang_textcopy(ptr %t33, ptr %t26, i64 %t27)
  %t34 = getelementptr i8, ptr %t33, i64 %t27
  call void @olang_textcopy(ptr %t34, ptr %t28, i64 %t29)
  %t35 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t39 = load i64, ptr %l5
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = load i64, ptr %l5
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t38, ptr %v0, ptr %t40, ptr %v1, ptr %t42, { i64, ptr } %t43, { i64, ptr } %t36, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d18, i32 0, i32 1) }, i1 false, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t38, i64 184, i1 false)
  br label %bb7
bb7:
  %t45 = load i64, ptr %l5
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_scope_alloc_a(ptr %t46, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %l13, i64 184, i1 false)
  store ptr %t47, ptr %l14, !tbaa !29
  %t48 = call ptr @__olang_scope_hold(ptr %v1)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l15, !tbaa !24
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t50, label %bb8, label %bb9
bb8:
  %t52 = call ptr @__olang_region_make(ptr %v1)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t54 = load i64, ptr %l15
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %t55)
  store %"compiler/source:Names" %t56, ptr %l17
  br label %bb10
bb10:
  %t57 = load %"compiler/source:Names", ptr %l17
  %t58 = load i64, ptr %l15
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_scope_alloc_a(ptr %t59, i64 104, i64 8)
  store %"compiler/source:Names" %t57, ptr %t60
  store ptr %t60, ptr %l18, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t61, ptr %v1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t61, i64 704, i1 false)
  br label %bb11
bb11:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %l19, i64 704, i1 false)
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load ptr, ptr %l14, !tbaa !29
  %t66 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t63, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t64, ptr %t65, ptr %t66, ptr %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t63, i64 864, i1 false)
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l21, i64 864, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fload_2eNormalize(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l54 = alloca %"std/prelude/text:StringBuilder"
  %l56 = alloca i1
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, ptr %v0, { i64, ptr } %t3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store { i64, ptr } %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb5:
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i1, ptr %l26, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb11
bb9:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t33, ptr %l29
  br label %bb10
bb10:
  %t34 = load i1, ptr %l29, !tbaa !21
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb13:
  br label %bb14
bb14:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t36, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t38, ptr %l31
  br label %bb15
bb15:
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l1)
  store i64 %t41, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  %t42 = load i64, ptr %l34, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  store i1 %t43, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l32, !tbaa !21
  br i1 %t45, label %bb20, label %bb21
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l1)
  store i64 %t47, ptr %l39
  br label %bb22
bb21:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb25
bb22:
  %t48 = load i64, ptr %l39, !tbaa !24
  %t49 = sub i64 %t48, 1
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t52 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t50, i64 %t49)
  store { i64, ptr } %t52, ptr %l41
  br label %bb23
bb23:
  %t53 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t54, ptr %l42
  br label %bb24
bb24:
  %t55 = load i1, ptr %l42, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %s0, ptr %s4, ptr %l1)
  %t61 = extractvalue { i32, { i64, ptr } } %t60, 1
  %t62 = extractvalue { i32, { i64, ptr } } %t60, 0
  store i32 %t62, ptr %l47
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb29, label %ok.64, !prof !99
ok.64:
  store { i64, ptr } %t61, ptr %l46
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t65 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t66, label %bb31, label %bb32
bb29:
  br label %bb30
bb30:
  br label %bb33
bb31:
  %t68 = load { i64, ptr }, ptr %l44
  %t69 = extractvalue { i64, ptr } %t68, 1
  call void @__olang_region_release(ptr %t69)
  store { i64, ptr } zeroinitializer, ptr %l44
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb34:
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t70)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb3
bb37:
  call void @__olang_scope_close(ptr %s1)
  %t78 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t78, ptr %l54
  br label %bb38
bb38:
  %t79 = load %"std/prelude/text:StringBuilder", ptr %l54
  store %"std/prelude/text:StringBuilder" %t79, ptr %l6
  %t80 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t80, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t82, ptr %l56
  br label %bb39
bb39:
  %t83 = load i1, ptr %l56, !tbaa !21
  br i1 %t83, label %bb40, label %bb41
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 47)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  store i64 0, ptr %l7, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l1)
  store i64 %t86, ptr %l59
  br label %bb44
bb44:
  %t87 = load i64, ptr %l59, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb45, label %bb46
bb45:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb50
bb47:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l66, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb49
bb49:
  %t114 = load i64, ptr %l66, !tbaa !24
  store i64 %t114, ptr %l63, !tbaa !24
  br label %bb50
bb50:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb51
bb51:
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 47)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  store ptr %l6, ptr %l87, !tbaa !29
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l1, i64 %t139)
  store { i64, ptr } %t142, ptr %l90
  br label %bb59
bb59:
  %t143 = load ptr, ptr %l87, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t143, { i64, ptr } %t144)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb51
bb62:
  %t151 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l6)
  store i64 %t151, ptr %l95
  br label %bb63
bb63:
  %t152 = load i64, ptr %l95, !tbaa !24
  %t153 = icmp eq i64 %t152, 0
  br i1 %t153, label %bb64, label %bb65
bb64:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l98, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t155, ptr %l97, !tbaa !27
  br label %bb67
bb65:
  %t158 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t158, ptr %l101
  br label %bb66
bb66:
  %t159 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t159, ptr %l97, !tbaa !27
  br label %bb67
bb67:
  %t160 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l102, !tbaa !24
  %t162 = load i64, ptr %l102, !tbaa !24
  %t163 = mul i64 %t162, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l103, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l102, !tbaa !24
  %t172 = mul i64 %t171, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t173, ptr %l97, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t174 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb7
bb7:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l14
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb12, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l13
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t32, ptr %l12, !tbaa !27
  br label %bb16
bb12:
  %t33 = load i32, ptr %l14, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  store i1 %t36, ptr %l16, !tbaa !21
  %t37 = load i32, ptr %l14, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t42, ptr %l20, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l21, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l22, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t56, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb16:
  %t58 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t61 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, ptr %s0, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l24
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = getelementptr i8, ptr %t68, i64 %t64
  call void @olang_textcopy(ptr %t69, ptr %t65, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fload_2ebraceOrColon(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 114 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 79 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ecachedTranslation(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/os:FileInfo"
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/text:LineIter"
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i32
  %l71 = alloca i64
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca %"std/os:FileInfo"
  %l99 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca %"std/os:FileInfo"
  %l113 = alloca i32
  %l115 = alloca i1
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l140 = alloca i1
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l14
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l13
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  br label %bb6
bb2:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l16, !tbaa !21
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l21, !tbaa !24
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb6:
  %t45 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t45)
  store %"std/prelude/text:LineIter" %t48, ptr %l24
  br label %bb7
bb7:
  %t49 = load %"std/prelude/text:LineIter", ptr %l24
  store %"std/prelude/text:LineIter" %t49, ptr %l2
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l2)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l28
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb10, label %ok.55, !prof !99
ok.55:
  store { i64, ptr } %t52, ptr %l27
  br label %bb9
bb9:
  %t56 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t56, ptr %l25, !tbaa !27
  br label %bb12
bb10:
  %t57 = load i32, ptr %l28, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb74
bb12:
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t61, ptr %l3, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t64, ptr %l32
  br label %bb13
bb13:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb73
bb15:
  br label %bb16
bb16:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t66, i8 32)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l37
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73, !prof !99
ok.73:
  store i64 %t70, ptr %l36
  br label %bb17
bb17:
  %t74 = load i64, ptr %l36, !tbaa !24
  store i64 %t74, ptr %l33, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t75, ptr %l39, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l40, !tbaa !24
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l41, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l40, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t89, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load i64, ptr %l33, !tbaa !24
  store i64 %t91, ptr %l4, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l43, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l45, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t96, 0
  store i64 %t99, ptr %l48, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l49, !tbaa !24
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l48, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_58a0a66c848bdb67_cd5865ffada34e5b)
  unreachable
bb23:
  %t109 = load i64, ptr %l48, !tbaa !24
  %t110 = load i64, ptr %l49, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_58a0a66c848bdb67_cd5865ffada34e5b)
  unreachable
bb25:
  %t113 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l45, !tbaa !24
  %t116 = load i64, ptr %l48, !tbaa !24
  %t117 = getelementptr i8, ptr %t114, i64 %t115
  %t118 = sub i64 %t116, %t115
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t120, i8 32)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l56
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb28, label %ok.127, !prof !99
ok.127:
  store i64 %t124, ptr %l55
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_58a0a66c848bdb67_cd5865ffada34e5b)
  unreachable
bb27:
  %t128 = load i64, ptr %l55, !tbaa !24
  store i64 %t128, ptr %l42, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t129, ptr %l58, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l59, !tbaa !24
  %t132 = load i64, ptr %l59, !tbaa !24
  %t133 = mul i64 %t132, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l60, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = load i64, ptr %l59, !tbaa !24
  %t142 = mul i64 %t141, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t138, ptr %t140, i64 %t142, i1 false)
  %t143 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t143, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
bb30:
  %t145 = load i64, ptr %l42, !tbaa !24
  store i64 %t145, ptr %l5, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t146, ptr %l62, !tbaa !27
  %t147 = load i64, ptr %l4, !tbaa !24
  store i64 %t147, ptr %l63, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l64, !tbaa !24
  %t150 = icmp sge i64 0, 0
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t152 = load i64, ptr %l63, !tbaa !24
  %t153 = icmp sle i64 0, %t152
  br i1 %t153, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_78711dd37968488a_7166c24cf999555e)
  unreachable
bb33:
  %t155 = load i64, ptr %l63, !tbaa !24
  %t156 = load i64, ptr %l64, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_78711dd37968488a_7166c24cf999555e)
  unreachable
bb35:
  %t159 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = getelementptr i8, ptr %t160, i64 0
  %t163 = sub i64 %t161, 0
  %t164 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  store { i64, ptr } %t165, ptr %l68, !tbaa !27
  %t166 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l70
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb38, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l69
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_78711dd37968488a_7166c24cf999555e)
  unreachable
bb37:
  %t171 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t172 = load i64, ptr %l69, !tbaa !24
  %t173 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t171, i64 %t172)
  %t174 = extractvalue { i32, i64 } %t173, 1
  %t175 = extractvalue { i32, i64 } %t173, 0
  store i32 %t175, ptr %l72
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb41, label %ok.177, !prof !99
ok.177:
  store i64 %t174, ptr %l71
  br label %bb40
bb38:
  br label %bb39
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t178, ptr %l74, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l75, !tbaa !24
  %t181 = load i64, ptr %l75, !tbaa !24
  %t182 = mul i64 %t181, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l75, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  %t192 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t192, ptr %l74, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t193 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t193, ptr %rv
  br label %ret
bb40:
  %t194 = load i64, ptr %l71, !tbaa !24
  store i64 %t194, ptr %l61, !tbaa !24
  br label %bb42
bb41:
  br label %bb39
bb42:
  %t195 = load i64, ptr %l61, !tbaa !24
  store i64 %t195, ptr %l6, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t196, ptr %l78, !tbaa !27
  %t197 = load i64, ptr %l4, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l80, !tbaa !24
  %t200 = load i64, ptr %l4, !tbaa !24
  %t202 = add i64 %t200, 1
  %t203 = load i64, ptr %l5, !tbaa !24
  %t206 = add i64 %t202, %t203
  store i64 %t206, ptr %l84, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l85, !tbaa !24
  %t209 = load i64, ptr %l80, !tbaa !24
  %t210 = icmp sge i64 %t209, 0
  br i1 %t210, label %bb43, label %bb44
bb43:
  %t212 = load i64, ptr %l80, !tbaa !24
  %t213 = load i64, ptr %l84, !tbaa !24
  %t214 = icmp sle i64 %t212, %t213
  br i1 %t214, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_dccc239ae56f9ba9_1ecb5d6f56d7fcbd)
  unreachable
bb45:
  %t216 = load i64, ptr %l84, !tbaa !24
  %t217 = load i64, ptr %l85, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_dccc239ae56f9ba9_1ecb5d6f56d7fcbd)
  unreachable
bb47:
  %t220 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = load i64, ptr %l80, !tbaa !24
  %t223 = load i64, ptr %l84, !tbaa !24
  %t224 = getelementptr i8, ptr %t221, i64 %t222
  %t225 = sub i64 %t223, %t222
  %t226 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t224, 1
  store { i64, ptr } %t227, ptr %l89, !tbaa !27
  %t228 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t229 = extractvalue { i32, i64 } %t228, 1
  %t230 = extractvalue { i32, i64 } %t228, 0
  store i32 %t230, ptr %l91
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb50, label %ok.232, !prof !99
ok.232:
  store i64 %t229, ptr %l90
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_dccc239ae56f9ba9_1ecb5d6f56d7fcbd)
  unreachable
bb49:
  %t233 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t234 = load i64, ptr %l90, !tbaa !24
  %t235 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t233, i64 %t234)
  %t236 = extractvalue { i32, i64 } %t235, 1
  %t237 = extractvalue { i32, i64 } %t235, 0
  store i32 %t237, ptr %l93
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb53, label %ok.239, !prof !99
ok.239:
  store i64 %t236, ptr %l92
  br label %bb52
bb50:
  br label %bb51
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t240, ptr %l95, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l96, !tbaa !24
  %t243 = load i64, ptr %l96, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l97, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l96, !tbaa !24
  %t253 = mul i64 %t252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t254, ptr %l95, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
bb52:
  %t256 = load i64, ptr %l92, !tbaa !24
  store i64 %t256, ptr %l77, !tbaa !24
  br label %bb54
bb53:
  br label %bb51
bb54:
  %t257 = load i64, ptr %l77, !tbaa !24
  store i64 %t257, ptr %l7, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t258, ptr %l99, !tbaa !27
  %t259 = load i64, ptr %l4, !tbaa !24
  %t261 = add i64 %t259, 2
  %t262 = load i64, ptr %l5, !tbaa !24
  %t265 = add i64 %t261, %t262
  store i64 %t265, ptr %l103, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t266, 0
  store i64 %t269, ptr %l106, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  store i64 %t271, ptr %l107, !tbaa !24
  %t272 = load i64, ptr %l103, !tbaa !24
  %t273 = icmp sge i64 %t272, 0
  br i1 %t273, label %bb55, label %bb56
bb55:
  %t275 = load i64, ptr %l103, !tbaa !24
  %t276 = load i64, ptr %l106, !tbaa !24
  %t277 = icmp sle i64 %t275, %t276
  br i1 %t277, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_756dde8889a2c3bc_572c106a043d4f60)
  unreachable
bb57:
  %t279 = load i64, ptr %l106, !tbaa !24
  %t280 = load i64, ptr %l107, !tbaa !24
  %t281 = icmp sle i64 %t279, %t280
  br i1 %t281, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_756dde8889a2c3bc_572c106a043d4f60)
  unreachable
bb59:
  %t283 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l103, !tbaa !24
  %t286 = load i64, ptr %l106, !tbaa !24
  %t287 = getelementptr i8, ptr %t284, i64 %t285
  %t288 = sub i64 %t286, %t285
  %t289 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t287, 1
  %t292 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t290)
  %t293 = extractvalue { i32, %"std/os:FileInfo" } %t292, 1
  %t294 = extractvalue { i32, %"std/os:FileInfo" } %t292, 0
  store i32 %t294, ptr %l113
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb62, label %ok.296, !prof !99
ok.296:
  store %"std/os:FileInfo" %t293, ptr %l112
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_756dde8889a2c3bc_572c106a043d4f60)
  unreachable
bb61:
  %t297 = load %"std/os:FileInfo", ptr %l112
  store %"std/os:FileInfo" %t297, ptr %l98
  br label %bb66
bb62:
  %t298 = load i32, ptr %l113, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  store i1 %t301, ptr %l115, !tbaa !21
  %t302 = load i32, ptr %l113, !tbaa !23
  %t303 = ashr i32 %t302, 16
  %t305 = icmp eq i32 %t303, 1
  br i1 %t305, label %bb63, label %bb64
bb63:
  call void @__olang_errpay_pop()
  br label %bb64
bb64:
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t307, ptr %l119, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l120, !tbaa !24
  %t310 = load i64, ptr %l120, !tbaa !24
  %t311 = mul i64 %t310, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t311)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, ptr } %t314, ptr %l121, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = load i64, ptr %l120, !tbaa !24
  %t320 = mul i64 %t319, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t316, ptr %t318, i64 %t320, i1 false)
  %t321 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t321, ptr %l119, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t322 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t322, ptr %rv
  br label %ret
bb66:
  %t323 = load %"std/os:FileInfo", ptr %l98
  store %"std/os:FileInfo" %t323, ptr %l8
  %t324 = getelementptr %"std/os:FileInfo", ptr %l8, i32 0, i32 1
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = load i64, ptr %l6, !tbaa !24
  %t329 = icmp ne i64 %t325, %t326
  br i1 %t329, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb69
bb68:
  %t331 = getelementptr %"std/os:FileInfo", ptr %l8, i32 0, i32 2
  %t332 = load i64, ptr %t331, !tbaa !24
  %t333 = load i64, ptr %l7, !tbaa !24
  %t336 = icmp ne i64 %t332, %t333
  store i1 %t336, ptr %l125, !tbaa !21
  br label %bb69
bb69:
  %t338 = load i1, ptr %l125, !tbaa !21
  br i1 %t338, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l129, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t339, ptr %l130, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l131, !tbaa !24
  %t342 = load i64, ptr %l131, !tbaa !24
  %t343 = mul i64 %t342, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t343)
  %t345 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  store { i64, ptr } %t346, ptr %l132, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = load i64, ptr %l131, !tbaa !24
  %t352 = mul i64 %t351, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t348, ptr %t350, i64 %t352, i1 false)
  %t353 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t353, ptr %l130, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t354 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t354, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s4)
  br label %bb73
bb73:
  br label %bb8
bb74:
  %t355 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = extractvalue { i64, ptr } %t355, 0
  %t359 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t360 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t361 = add i64 %t358, %t360
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t357, i64 %t358)
  %t363 = getelementptr i8, ptr %t362, i64 %t358
  call void @olang_textcopy(ptr %t363, ptr %t359, i64 %t360)
  %t364 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t362, 1
  %t368 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %v1, { i64, ptr } %t365)
  %t369 = extractvalue { i32, { i64, ptr } } %t368, 1
  %t370 = extractvalue { i32, { i64, ptr } } %t368, 0
  store i32 %t370, ptr %l138
  %t371 = icmp ne i32 %t370, 0
  br i1 %t371, label %bb76, label %ok.372, !prof !99
ok.372:
  store { i64, ptr } %t369, ptr %l137
  br label %bb75
bb75:
  %t373 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t373, ptr %l133, !tbaa !27
  br label %bb80
bb76:
  %t374 = load i32, ptr %l138, !tbaa !23
  %t375 = ashr i32 %t374, 16
  %t377 = icmp eq i32 %t375, 1
  store i1 %t377, ptr %l140, !tbaa !21
  %t378 = load i32, ptr %l138, !tbaa !23
  %t379 = ashr i32 %t378, 16
  %t381 = icmp eq i32 %t379, 1
  br i1 %t381, label %bb77, label %bb78
bb77:
  call void @__olang_errpay_pop()
  br label %bb78
bb78:
  br label %bb79
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l133, !tbaa !27
  br label %bb80
bb80:
  %t383 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t383, ptr %l143, !tbaa !27
  %t384 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t384, 0
  store i64 %t385, ptr %l144, !tbaa !24
  %t386 = load i64, ptr %l144, !tbaa !24
  %t387 = mul i64 %t386, 1
  %t388 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t387)
  %t389 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  store { i64, ptr } %t390, ptr %l145, !tbaa !27
  %t391 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = load i64, ptr %l144, !tbaa !24
  %t396 = mul i64 %t395, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t392, ptr %t394, i64 %t396, i1 false)
  %t397 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t397, ptr %l143, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t398 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t398, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %lp14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/diag:Diagnostics"
  %l30 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca ptr
  %l65 = alloca %"compiler/parse:Parser"
  %l67 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca %"compiler/cond:Scope"
  %l82 = alloca i64
  %l84 = alloca i64
  %l89 = alloca i64
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l121 = alloca i1
  %l136 = alloca { i64, ptr }
  %l142 = alloca i1
  %l146 = alloca { i64, ptr }
  %l150 = alloca i1
  %l151 = alloca { i64, ptr }
  %l155 = alloca i64
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca i64
  %l177 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l205 = alloca i64
  %l209 = alloca i1
  %l212 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l218 = alloca %"compiler/source:Span"
  %l223 = alloca ptr
  %l224 = alloca i64
  %l232 = alloca { i64, ptr }
  %l234 = alloca i64
  %l236 = alloca i64
  %l237 = alloca i64
  %l249 = alloca %"compiler/cond:Global"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t11 = alloca %"compiler/diag:Diagnostics", align 8
  %t101 = alloca %"compiler/parse:Parser", align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 27
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t11, ptr %v1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t11, i64 704, i1 false)
  br label %bb4
bb4:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l24, i64 704, i1 false)
  %t14 = load ptr, ptr %l23, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 28
  store ptr %t12, ptr %t15, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 28
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 28
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l30, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l32, !tbaa !27
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 6
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 6
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t49 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v1, ptr %v1, ptr %v1, ptr %t46, { i64, ptr } %t47, { i64, ptr } %t45, i1 false)
  store i64 %t49, ptr %l40
  br label %bb11
bb11:
  %t50 = load i64, ptr %l40, !tbaa !24
  store i64 %t50, ptr %l2, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l41, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/load:Module", ptr %t52, i32 0, i32 6
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 6
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l46, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 7
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 7
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l51, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l53, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 12
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 12
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l58, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/load:Module", ptr %t89, i32 0, i32 28
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb22:
  br label %bb23
bb23:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/load:Module", ptr %t96, i32 0, i32 28
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = load ptr, ptr %l46, !tbaa !29
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load ptr, ptr %l53, !tbaa !29
  %t105 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fparse_3aParser_2ector(ptr %t101, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t102, ptr %t103, ptr %t104, ptr %t105, ptr %t99, i64 %t100)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t101, i64 1016, i1 false)
  br label %bb24
bb24:
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 1016, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %l65, i64 1016, i1 false)
  %t110 = load ptr, ptr %l41, !tbaa !29
  %t111 = getelementptr %"compiler/load:Module", ptr %t110, i32 0, i32 27
  store ptr %t108, ptr %t111, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l67, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t118, ptr %l70
  br label %bb25
bb25:
  %t119 = load i1, ptr %l70, !tbaa !21
  %t120 = call %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v1, i1 %t119)
  store %"compiler/cond:Scope" %t120, ptr %l71
  br label %bb26
bb26:
  %t121 = load %"compiler/cond:Scope", ptr %l71
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 104, i64 8)
  store %"compiler/cond:Scope" %t121, ptr %t122
  %t124 = load ptr, ptr %l67, !tbaa !29
  %t125 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 26
  store ptr %t122, ptr %t125, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/load:Module", ptr %t126, i32 0, i32 7
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4d8cd44e3790675d_2617b874cf4b9361)
  unreachable
bb28:
  br label %bb29
bb29:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 7
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t139 = getelementptr %"compiler/scan:Tokens", ptr %t136, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l3, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/load:Module", ptr %t142, i32 0, i32 25
  store ptr %t144, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t146 = load i64, ptr %l5, !tbaa !24
  store i64 %t146, ptr %l82, !tbaa !24
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t147)
  store i64 %t149, ptr %l84
  br label %bb31
bb31:
  %t150 = load i64, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l84, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb33:
  br label %bb34
bb34:
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load i64, ptr %l5, !tbaa !24
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t156, i64 %t157)
  store i64 %t160, ptr %l89
  br label %bb35
bb35:
  %t161 = load i64, ptr %l89, !tbaa !24
  store i64 %t161, ptr %l6, !tbaa !24
  %t162 = load i64, ptr %l6, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i64 -1, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t166, ptr %l92, !tbaa !27
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr %"compiler/token:Token", ptr %t170, i64 %t167
  %t172 = getelementptr %"compiler/token:Token", ptr %t171, i32 0, i32 0
  %t173 = load i32, ptr %t172, !range !{i32 0, i32 116}
  store i32 %t173, ptr %l12
  %t175 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t177 = trunc i64 0 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb39
bb38:
  %t180 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t182 = trunc i64 8 to i32
  %t183 = icmp eq i32 %t180, %t182
  store i1 %t183, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t185 = load i1, ptr %l97, !tbaa !21
  br i1 %t185, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb42
bb41:
  %t186 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t188 = trunc i64 114 to i32
  %t189 = icmp eq i32 %t186, %t188
  store i1 %t189, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t191 = load i1, ptr %l100, !tbaa !21
  br i1 %t191, label %bb43, label %bb44
bb43:
  br label %bb71
bb44:
  br label %bb45
bb45:
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = icmp eq i64 %t192, 0
  br i1 %t194, label %bb46, label %bb47
bb46:
  %t196 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t198 = trunc i64 78 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb48, label %bb49
bb47:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb51
bb48:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb50
bb49:
  %t201 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t203 = trunc i64 80 to i32
  %t204 = icmp eq i32 %t201, %t203
  store i1 %t204, ptr %l108, !tbaa !21
  br label %bb50
bb50:
  %t206 = load i1, ptr %l108, !tbaa !21
  store i1 %t206, ptr %l105, !tbaa !21
  br label %bb51
bb51:
  %t207 = load i1, ptr %l105, !tbaa !21
  br i1 %t207, label %bb52, label %bb53
bb52:
  br label %bb71
bb53:
  br label %bb54
bb54:
  %t208 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t210 = trunc i64 110 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb57
bb56:
  %t213 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t215 = trunc i64 112 to i32
  %t216 = icmp eq i32 %t213, %t215
  store i1 %t216, ptr %l113, !tbaa !21
  br label %bb57
bb57:
  %t218 = load i1, ptr %l113, !tbaa !21
  br i1 %t218, label %bb58, label %bb59
bb58:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l11, !tbaa !24
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t224 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t226 = trunc i64 111 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb63
bb62:
  %t229 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t231 = trunc i64 113 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l121, !tbaa !21
  br label %bb63
bb63:
  %t234 = load i1, ptr %l121, !tbaa !21
  br i1 %t234, label %bb64, label %bb65
bb64:
  %t235 = load i64, ptr %l11, !tbaa !24
  %t238 = sub i64 %t235, 1
  store i64 %t238, ptr %l11, !tbaa !24
  br label %bb66
bb65:
  br label %bb66
bb66:
  %t240 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t242 = trunc i64 39 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb69
bb68:
  %t245 = load i64, ptr %l9, !tbaa !24
  %t248 = add i64 %t245, 1
  store i64 %t248, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l7, !tbaa !24
  store i64 %t250, ptr %l10, !tbaa !24
  br label %bb69
bb69:
  %t252 = load i64, ptr %l7, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l7, !tbaa !24
  br label %bb70
bb70:
  br label %bb36
bb71:
  %t257 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t257, ptr %l136, !tbaa !27
  %t258 = load i64, ptr %l7, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr %"compiler/token:Token", ptr %t261, i64 %t258
  %t263 = getelementptr %"compiler/token:Token", ptr %t262, i32 0, i32 0
  %t264 = load i32, ptr %t263, !range !{i32 0, i32 116}
  store i32 %t264, ptr %l13
  %t266 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t268 = trunc i64 78 to i32
  %t269 = icmp eq i32 %t266, %t268
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb72, label %bb73
bb72:
  %t273 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t275 = trunc i64 80 to i32
  %t276 = icmp eq i32 %t273, %t275
  %t278 = xor i1 %t276, true
  store i1 %t278, ptr %l142, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb74
bb74:
  %t280 = load i1, ptr %l142, !tbaa !21
  br i1 %t280, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb76:
  br label %bb77
bb77:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l146, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t282 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t282, ptr %lp14
  %t284 = load ptr, ptr %lp14
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load i64, ptr %l9, !tbaa !24
  %t287 = icmp eq i64 %t285, 1
  br i1 %t287, label %bb78, label %bb79
bb78:
  %t289 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t289, ptr %l151, !tbaa !27
  %t290 = load i64, ptr %l10, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr %"compiler/token:Token", ptr %t293, i64 %t290
  %t295 = getelementptr %"compiler/token:Token", ptr %t294, i32 0, i32 0
  %t296 = load i32, ptr %t295, !range !{i32 0, i32 116}
  %t298 = trunc i64 1 to i32
  %t299 = icmp eq i32 %t296, %t298
  store i1 %t299, ptr %l150, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb80
bb80:
  %t301 = load i1, ptr %l150, !tbaa !21
  br i1 %t301, label %bb81, label %bb82
bb81:
  %t302 = call ptr @__olang_scope_hold(ptr %v1)
  %t303 = ptrtoint ptr %t302 to i64
  store i64 %t303, ptr %l155, !tbaa !24
  %t304 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eCondParser_2elocal_2e14
  br i1 %t304, label %bb83, label %bb84
bb82:
  %t306 = load i64, ptr %l9, !tbaa !24
  %t308 = icmp sgt i64 %t306, 0
  br i1 %t308, label %bb100, label %bb101
bb83:
  %t310 = call ptr @__olang_region_make(ptr %v1)
  %t311 = ptrtoint ptr %t310 to i64
  store i64 %t311, ptr %l155, !tbaa !24
  br label %bb84
bb84:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr %"compiler/load:Module", ptr %t312, i32 0, i32 6
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = icmp eq ptr %t315, null
  br i1 %t317, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_37ad9edc8de7e2f6_d0344632fdf871da)
  unreachable
bb86:
  br label %bb87
bb87:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr %"compiler/load:Module", ptr %t319, i32 0, i32 6
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t325 = getelementptr %"compiler/source:Source", ptr %t322, i32 0, i32 1
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l163, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t327, ptr %l164, !tbaa !27
  %t328 = load i64, ptr %l10, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr %"compiler/token:Token", ptr %t331, i64 %t328
  %t333 = getelementptr %"compiler/token:Token", ptr %t332, i32 0, i32 2
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  store i64 %t336, ptr %l167, !tbaa !24
  %t337 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t337, ptr %l168, !tbaa !27
  %t338 = load i64, ptr %l10, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr %"compiler/token:Token", ptr %t341, i64 %t338
  %t343 = getelementptr %"compiler/token:Token", ptr %t342, i32 0, i32 3
  %t344 = load i32, ptr %t343, !tbaa !23
  %t346 = sext i32 %t344 to i64
  store i64 %t346, ptr %l171, !tbaa !24
  %t347 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  store i64 %t348, ptr %l172, !tbaa !24
  %t349 = load i64, ptr %l167, !tbaa !24
  %t350 = icmp sge i64 %t349, 0
  br i1 %t350, label %bb88, label %bb89
bb88:
  %t352 = load i64, ptr %l167, !tbaa !24
  %t353 = load i64, ptr %l171, !tbaa !24
  %t354 = icmp sle i64 %t352, %t353
  br i1 %t354, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_ee319d06991d9051_474f59f05ada826d)
  unreachable
bb90:
  %t356 = load i64, ptr %l171, !tbaa !24
  %t357 = load i64, ptr %l172, !tbaa !24
  %t358 = icmp sle i64 %t356, %t357
  br i1 %t358, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_ee319d06991d9051_474f59f05ada826d)
  unreachable
bb92:
  %t360 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = load i64, ptr %l167, !tbaa !24
  %t363 = load i64, ptr %l171, !tbaa !24
  %t364 = getelementptr i8, ptr %t361, i64 %t362
  %t365 = sub i64 %t363, %t362
  %t366 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t364, 1
  %t369 = extractvalue { i64, ptr } %t367, 1
  %t370 = extractvalue { i64, ptr } %t367, 0
  %t371 = load i64, ptr %l155
  %t372 = inttoptr i64 %t371 to ptr
  %t373 = call ptr @__olang_held_alloc(ptr %t372, i64 %t370)
  call void @olang_textcopy(ptr %t373, ptr %t369, i64 %t370)
  %t374 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l177, !tbaa !27
  %t376 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eCondParser_2elocal_2e14
  br i1 %t376, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_ee319d06991d9051_474f59f05ada826d)
  unreachable
bb94:
  %t378 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t381 = icmp eq i64 %t379, 0
  br i1 %t381, label %bb96, label %bb97
bb95:
  %t383 = load ptr, ptr %lp14
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l181, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t386 = load ptr, ptr %lp14
  store { i64, ptr } %t385, ptr %t386, !tbaa !27
  %t387 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eCondParser_2elocal_2e14
  br i1 %t387, label %bb98, label %bb99
bb96:
  store { i64, ptr } zeroinitializer, ptr %l177, !tbaa !27
  br label %bb97
bb97:
  %t389 = load i64, ptr %l155
  %t390 = inttoptr i64 %t389 to ptr
  %t391 = load { i64, ptr }, ptr %l177
  %t392 = extractvalue { i64, ptr } %t391, 1
  %t393 = call ptr @__olang_region_or(ptr %t392, ptr null)
  %t394 = icmp ne ptr %t393, null
  %t395 = select i1 %t394, ptr %t393, ptr null
  call void @__olang_region_settle_in(ptr %t390, ptr %t395)
  br label %bb95
bb98:
  %t396 = load { i64, ptr }, ptr %l181
  %t397 = extractvalue { i64, ptr } %t396, 1
  call void @__olang_region_release(ptr %t397)
  store { i64, ptr } zeroinitializer, ptr %l181
  br label %bb99
bb99:
  br label %bb105
bb100:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l185, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t399 = load ptr, ptr %lp14
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  store { i64, ptr } %t400, ptr %l187, !tbaa !27
  %t402 = load ptr, ptr %lp14
  store { i64, ptr } %t398, ptr %t402, !tbaa !27
  %t403 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eCondParser_2elocal_2e14
  br i1 %t403, label %bb102, label %bb103
bb101:
  br label %bb104
bb102:
  %t405 = load { i64, ptr }, ptr %l187
  %t406 = extractvalue { i64, ptr } %t405, 1
  call void @__olang_region_release(ptr %t406)
  store { i64, ptr } zeroinitializer, ptr %l187
  br label %bb103
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr %"compiler/load:Module", ptr %t407, i32 0, i32 27
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t412 = icmp eq ptr %t410, null
  br i1 %t412, label %bb106, label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_57e236369a85f00c_b06e30e0c965afa8)
  unreachable
bb107:
  br label %bb108
bb108:
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr %"compiler/load:Module", ptr %t414, i32 0, i32 27
  %t417 = load ptr, ptr %t416, !tbaa !29
  %t418 = load i64, ptr %l7, !tbaa !24
  %t420 = add i64 %t418, 1
  %t423 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v1, ptr %v1, ptr %t417, i64 %t420)
  %t424 = extractvalue { i32, ptr } %t423, 1
  %t425 = extractvalue { i32, ptr } %t423, 0
  store i32 %t425, ptr %l198
  %t426 = icmp ne i32 %t425, 0
  br i1 %t426, label %bb110, label %ok.427, !prof !99
ok.427:
  store ptr %t424, ptr %l197
  br label %bb109
bb109:
  %t428 = load ptr, ptr %l197, !tbaa !29
  store ptr %t428, ptr %l189, !tbaa !29
  br label %bb112
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb112:
  %t429 = load ptr, ptr %l189, !tbaa !29
  store ptr %t429, ptr %l15, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t430, ptr %l199, !tbaa !27
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr %"compiler/load:Module", ptr %t431, i32 0, i32 27
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  br i1 %t436, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_64a34b454640941_8ed0e4b282ed07d)
  unreachable
bb114:
  br label %bb115
bb115:
  %t438 = load ptr, ptr %l1, !tbaa !29
  %t440 = getelementptr %"compiler/load:Module", ptr %t438, i32 0, i32 27
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v1, ptr %t441)
  store i64 %t443, ptr %l205
  br label %bb116
bb116:
  %t444 = load i64, ptr %l205, !tbaa !24
  %t445 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr %"compiler/token:Token", ptr %t446, i64 %t444
  %t448 = getelementptr %"compiler/token:Token", ptr %t447, i32 0, i32 0
  %t449 = load i32, ptr %t448, !range !{i32 0, i32 116}
  store i32 %t449, ptr %l16
  %t451 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t453 = trunc i64 8 to i32
  %t454 = icmp eq i32 %t451, %t453
  br i1 %t454, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l209, !tbaa !21
  br label %bb119
bb118:
  %t456 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t458 = trunc i64 0 to i32
  %t459 = icmp eq i32 %t456, %t458
  store i1 %t459, ptr %l209, !tbaa !21
  br label %bb119
bb119:
  %t461 = load i1, ptr %l209, !tbaa !21
  store i1 %t461, ptr %l17, !tbaa !21
  %t462 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t462, ptr %l212, !tbaa !27
  %t463 = load i64, ptr %l6, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr %"compiler/token:Token", ptr %t466, i64 %t463
  %t468 = getelementptr %"compiler/token:Token", ptr %t467, i32 0, i32 2
  %t469 = load i32, ptr %t468, !tbaa !23
  %t470 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t470, ptr %l215, !tbaa !27
  %t471 = load i64, ptr %l6, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr %"compiler/token:Token", ptr %t474, i64 %t471
  %t476 = getelementptr %"compiler/token:Token", ptr %t475, i32 0, i32 3
  %t477 = load i32, ptr %t476, !tbaa !23
  %t480 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t469, i32 %t477)
  store %"compiler/source:Span" %t480, ptr %l218
  br label %bb120
bb120:
  %t481 = load %"compiler/source:Span", ptr %l218
  store %"compiler/source:Span" %t481, ptr %l18
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr %"compiler/load:Module", ptr %t482, i32 0, i32 26
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = icmp eq ptr %t485, null
  br i1 %t487, label %bb121, label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_64e62a75e1515ba_854f46de0e9c2096)
  unreachable
bb122:
  br label %bb123
bb123:
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr %"compiler/load:Module", ptr %t489, i32 0, i32 26
  %t492 = load ptr, ptr %t491, !tbaa !29
  store ptr %t492, ptr %l223, !tbaa !29
  %t493 = call ptr @__olang_scope_hold(ptr %v1)
  %t494 = ptrtoint ptr %t493 to i64
  store i64 %t494, ptr %l224, !tbaa !24
  %t495 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aGlobal_2e0
  br i1 %t495, label %bb124, label %bb125
bb124:
  %t497 = call ptr @__olang_region_make(ptr %v1)
  %t498 = ptrtoint ptr %t497 to i64
  store i64 %t498, ptr %l224, !tbaa !24
  br label %bb125
bb125:
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr %"compiler/load:Module", ptr %t499, i32 0, i32 6
  %t502 = load ptr, ptr %t501, !tbaa !29
  %t504 = icmp eq ptr %t502, null
  br i1 %t504, label %bb126, label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_64e62a75e1515ba_854f46de0e9c2096)
  unreachable
bb127:
  br label %bb128
bb128:
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr %"compiler/load:Module", ptr %t506, i32 0, i32 6
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t512 = getelementptr %"compiler/source:Source", ptr %t509, i32 0, i32 1
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l232, !tbaa !27
  %t514 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t515 = load i32, ptr %t514, !tbaa !23
  %t517 = sext i32 %t515 to i64
  store i64 %t517, ptr %l234, !tbaa !24
  %t518 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t519 = load i32, ptr %t518, !tbaa !23
  %t521 = sext i32 %t519 to i64
  store i64 %t521, ptr %l236, !tbaa !24
  %t522 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  store i64 %t523, ptr %l237, !tbaa !24
  %t524 = load i64, ptr %l234, !tbaa !24
  %t525 = icmp sge i64 %t524, 0
  br i1 %t525, label %bb129, label %bb130
bb129:
  %t527 = load i64, ptr %l234, !tbaa !24
  %t528 = load i64, ptr %l236, !tbaa !24
  %t529 = icmp sle i64 %t527, %t528
  br i1 %t529, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @olang_loc_edaf45632a5c2555_299361976cec5e59)
  unreachable
bb131:
  %t531 = load i64, ptr %l236, !tbaa !24
  %t532 = load i64, ptr %l237, !tbaa !24
  %t533 = icmp sle i64 %t531, %t532
  br i1 %t533, label %bb133, label %bb134
bb132:
  call void @__olang_check_failed(ptr @olang_loc_edaf45632a5c2555_299361976cec5e59)
  unreachable
bb133:
  %t535 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = load i64, ptr %l234, !tbaa !24
  %t538 = load i64, ptr %l236, !tbaa !24
  %t539 = getelementptr i8, ptr %t536, i64 %t537
  %t540 = sub i64 %t538, %t537
  %t541 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  %t544 = extractvalue { i64, ptr } %t542, 1
  %t545 = extractvalue { i64, ptr } %t542, 0
  %t546 = load i64, ptr %l224
  %t547 = inttoptr i64 %t546 to ptr
  %t548 = call ptr @__olang_held_alloc(ptr %t547, i64 %t545)
  call void @olang_textcopy(ptr %t548, ptr %t544, i64 %t545)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  %t552 = load %"compiler/source:Span", ptr %l18
  %t553 = load i1, ptr %l8, !tbaa !21
  %t554 = load ptr, ptr %lp14
  %t555 = load { i64, ptr }, ptr %t554, !tbaa !27
  %t556 = load ptr, ptr %l15, !tbaa !29
  %t557 = load i1, ptr %l17, !tbaa !21
  %t564 = call %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t550, %"compiler/source:Span" %t552, i1 %t553, { i64, ptr } %t555, ptr %t556, i1 %t557)
  store %"compiler/cond:Global" %t564, ptr %l249
  br label %bb135
bb134:
  call void @__olang_check_failed(ptr @olang_loc_edaf45632a5c2555_299361976cec5e59)
  unreachable
bb135:
  %t565 = load %"compiler/cond:Global", ptr %l249
  %t566 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/cond:Global" %t565, ptr %t566
  %t567 = load ptr, ptr %l223, !tbaa !29
  call void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v1, ptr %v1, ptr %t567, ptr %t566)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t569 = load i64, ptr %l5, !tbaa !24
  %t572 = add i64 %t569, 1
  store i64 %t572, ptr %l5, !tbaa !24
  br label %bb30
bb138:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l60 = alloca i32
  %l63 = alloca i1
  %l67 = alloca i64
  %l76 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i1
  %l111 = alloca i64
  %l125 = alloca i64
  %l128 = alloca i64
  %l129 = alloca ptr
  %l135 = alloca ptr
  %l141 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i64
  %l172 = alloca ptr
  %l175 = alloca i1
  %l180 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i1
  %l199 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 17
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l32
  br label %bb2
bb2:
  %t14 = load i64, ptr %l32, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l39, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l39, !tbaa !24
  store i64 %t41, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l36, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb45
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l10, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 17
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l60
  br label %bb13
bb13:
  %t69 = load i32, ptr %l60, !tbaa !23
  %t71 = icmp ne i32 %t69, %a2
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb17
bb15:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 19
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l67
  br label %bb16
bb16:
  %t80 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t81 = load i64, ptr %l67, !tbaa !24
  %t83 = icmp ne i64 %t81, %t80
  store i1 %t83, ptr %l63, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l63, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb44
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 19
  %t89 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89, i64 %a3)
  br label %bb21
bb21:
  store i64 0, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 17
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l76
  br label %bb22
bb22:
  %t99 = load i64, ptr %l76, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb28
bb25:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l83, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l83, !tbaa !24
  store i64 %t126, ptr %l80, !tbaa !24
  br label %bb28
bb28:
  %t127 = load i64, ptr %l80, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  br label %bb43
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l16, !tbaa !24
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/load:Module", ptr %t146, i32 0, i32 19
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l104
  br label %bb33
bb33:
  %t153 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t154 = load i64, ptr %l104, !tbaa !24
  %t156 = icmp eq i64 %t154, %t153
  br i1 %t156, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l4, !tbaa !29
  %t160 = getelementptr %"compiler/load:Module", ptr %t158, i32 0, i32 18
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l111
  br label %bb36
bb35:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb37
bb36:
  %t165 = load i64, ptr %l111, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  store i1 %t166, ptr %l107, !tbaa !21
  br label %bb37
bb37:
  %t168 = load i1, ptr %l107, !tbaa !21
  br i1 %t168, label %bb38, label %bb39
bb38:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/load:Module", ptr %t169, i32 0, i32 19
  %t172 = load i64, ptr %l16, !tbaa !24
  %t173 = load i64, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172, i64 %t173)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb29
bb43:
  br label %bb44
bb44:
  %t182 = load i64, ptr %l9, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l9, !tbaa !24
  br label %bb9
bb45:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/load:Loader", ptr %t187, i32 0, i32 10
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l125
  br label %bb46
bb46:
  %t192 = load i64, ptr %l125, !tbaa !24
  store i64 %t192, ptr %l17, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l1, !tbaa !24
  %t197 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etargets(ptr %v0, ptr %t193, i64 %t194)
  store i64 %t197, ptr %l128
  br label %bb47
bb47:
  %t198 = load i64, ptr %l128, !tbaa !24
  store i64 %t198, ptr %l18, !tbaa !24
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l129, !tbaa !29
  %t200 = load ptr, ptr %l129, !tbaa !29
  %t201 = getelementptr %"compiler/load:Loader", ptr %t200, i32 0, i32 23
  %t202 = load i64, ptr %t201, !tbaa !24
  %t205 = add i64 %t202, 1
  %t207 = load ptr, ptr %l129, !tbaa !29
  %t208 = getelementptr %"compiler/load:Loader", ptr %t207, i32 0, i32 23
  store i64 %t205, ptr %t208, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t209, i64 %t210)
  br label %bb48
bb48:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l135, !tbaa !29
  %t214 = load ptr, ptr %l135, !tbaa !29
  %t215 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 23
  %t216 = load i64, ptr %t215, !tbaa !24
  %t219 = sub i64 %t216, 1
  %t221 = load ptr, ptr %l135, !tbaa !29
  %t222 = getelementptr %"compiler/load:Loader", ptr %t221, i32 0, i32 23
  store i64 %t219, ptr %t222, !tbaa !24
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i64, ptr %l1, !tbaa !24
  %t227 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etargets(ptr %v0, ptr %t223, i64 %t224)
  store i64 %t227, ptr %l141
  br label %bb49
bb49:
  %t228 = load i64, ptr %l18, !tbaa !24
  %t229 = load i64, ptr %l141, !tbaa !24
  %t231 = icmp sgt i64 %t229, %t228
  br i1 %t231, label %bb50, label %bb51
bb50:
  store i64 0, ptr %l19, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  store i64 %t233, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l19, !tbaa !24
  %t239 = icmp sgt i64 %t235, %t236
  br i1 %t239, label %bb52, label %bb53
bb51:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l1, !tbaa !24
  %t243 = load ptr, ptr %l4, !tbaa !29
  %t245 = getelementptr %"compiler/load:Module", ptr %t243, i32 0, i32 8
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v0, ptr %t241, i64 %t242, { i64, ptr } %t246)
  br label %bb77
bb52:
  %t250 = load i64, ptr %l21, !tbaa !24
  %t252 = icmp sgt i64 %t250, 0
  br i1 %t252, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb57
bb54:
  %t254 = load i64, ptr %l20, !tbaa !24
  %t255 = load i64, ptr %l19, !tbaa !24
  %t258 = sub i64 %t254, %t255
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = add i64 %t258, %t259
  %t264 = sub i64 %t262, 1
  %t265 = load i64, ptr %l21, !tbaa !24
  %t268 = sdiv i64 %t264, %t265
  store i64 %t268, ptr %l151, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb56
bb56:
  %t270 = load i64, ptr %l151, !tbaa !24
  store i64 %t270, ptr %l148, !tbaa !24
  br label %bb57
bb57:
  %t271 = load i64, ptr %l148, !tbaa !24
  store i64 %t271, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t272 = load i64, ptr %l23, !tbaa !24
  %t273 = load i64, ptr %l22, !tbaa !24
  %t276 = icmp slt i64 %t272, %t273
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb59, label %bb60
bb59:
  br label %bb76
bb60:
  br label %bb61
bb61:
  %t280 = load i64, ptr %l19, !tbaa !24
  %t281 = load i64, ptr %l23, !tbaa !24
  %t282 = load i64, ptr %l21, !tbaa !24
  %t285 = mul i64 %t281, %t282
  %t288 = add i64 %t280, %t285
  store i64 %t288, ptr %l24, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/load:Loader", ptr %t290, i32 0, i32 10
  %t293 = load i64, ptr %l24, !tbaa !24
  %t296 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t292, i64 %t293)
  store ptr %t296, ptr %l172
  br label %bb62
bb62:
  %t297 = load ptr, ptr %l172, !tbaa !29
  %t299 = getelementptr %"compiler/load:Module", ptr %t297, i32 0, i32 14
  %t300 = load i1, ptr %t299, !tbaa !21
  br i1 %t300, label %bb63, label %bb64
bb63:
  %t302 = load i64, ptr %l24, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/load:Loader", ptr %t304, i32 0, i32 24
  %t310 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t306, i64 %t302)
  store i1 %t310, ptr %l180
  br label %bb65
bb64:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb66
bb65:
  %t311 = load i1, ptr %l180, !tbaa !21
  %t312 = xor i1 %t311, true
  store i1 %t312, ptr %l175, !tbaa !21
  br label %bb66
bb66:
  %t314 = load i1, ptr %l175, !tbaa !21
  br i1 %t314, label %bb67, label %bb68
bb67:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i64, ptr %l24, !tbaa !24
  %t317 = load i64, ptr %l1, !tbaa !24
  %t321 = call i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2ereaches(ptr %v0, ptr %t315, i64 %t316, i64 %t317, i64 0)
  store i1 %t321, ptr %l186
  br label %bb69
bb68:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb70
bb69:
  %t322 = load i1, ptr %l186, !tbaa !21
  store i1 %t322, ptr %l182, !tbaa !21
  br label %bb70
bb70:
  %t323 = load i1, ptr %l182, !tbaa !21
  br i1 %t323, label %bb71, label %bb72
bb71:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/load:Loader", ptr %t324, i32 0, i32 24
  %t327 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t326, i64 %t327)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t330 = load i64, ptr %l23, !tbaa !24
  %t333 = add i64 %t330, 1
  store i64 %t333, ptr %l23, !tbaa !24
  br label %bb58
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/load:Loader", ptr %t335, i32 0, i32 10
  %t339 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t337)
  store i64 %t339, ptr %l199
  br label %bb79
bb79:
  %t340 = load i64, ptr %l17, !tbaa !24
  %t341 = load i64, ptr %l199, !tbaa !24
  %t343 = icmp sgt i64 %t341, %t340
  br i1 %t343, label %bb80, label %bb81
bb80:
  %t345 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t345)
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %lp21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l35 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l43 = alloca { { i64, ptr }, { i64, ptr } }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { { i64, ptr }, { i64, ptr } }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i32
  %l102 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l119 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca i1
  %l135 = alloca i64
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l147 = alloca i1
  %l149 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i1
  %l156 = alloca { i64, ptr }
  %l161 = alloca i1
  %l169 = alloca i1
  %l171 = alloca i1
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l177 = alloca i1
  %l178 = alloca i64
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l206 = alloca { i64, ptr }
  %l207 = alloca i64
  %l212 = alloca i64
  %l215 = alloca i64
  %l233 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l241 = alloca i64
  %l243 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i32
  %l251 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca i32
  %l264 = alloca i1
  %l265 = alloca i1
  %l270 = alloca i1
  %l280 = alloca i1
  %l283 = alloca i1
  %l291 = alloca i1
  %l297 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l300 = alloca i32
  %l302 = alloca i1
  %l311 = alloca i64
  %l317 = alloca i64
  %l320 = alloca i1
  %l326 = alloca { i64, ptr }
  %l341 = alloca i64
  %l343 = alloca i64
  %l348 = alloca { i64, ptr }
  %l351 = alloca i1
  %l360 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l365 = alloca i32
  %l368 = alloca { i64, ptr }
  %l370 = alloca { { i64, ptr }, { i64, ptr } }
  %l371 = alloca { i64, ptr }
  %l372 = alloca i64
  %l373 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 0, i64 8)
  store ptr %t1, ptr %lp3
  %t3 = load ptr, ptr %lp3
  store [0 x i8] zeroinitializer, ptr %t3
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l35, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %lp3
  %t20 = insertvalue { i64, ptr } undef, i64 0, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t24 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t21, 0
  %t26 = insertvalue { { i64, ptr }, { i64, ptr } } %t24, { i64, ptr } %t22, 1
  store { { i64, ptr }, { i64, ptr } } %t26, ptr %l43
  %t27 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l43, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l44, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l45, !tbaa !24
  %t31 = load i64, ptr %l45, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l46, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l45, !tbaa !24
  %t41 = mul i64 %t40, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t43 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l43, i32 0, i32 1
  store { i64, ptr } %t42, ptr %t43, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { { i64, ptr }, { i64, ptr } }, ptr %l43
  store { { i64, ptr }, { i64, ptr } } %t44, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sge i64 %t47, 4096
  br i1 %t49, label %bb5, label %bb6
bb5:
  %t51 = load ptr, ptr %lp3
  %t53 = insertvalue { i64, ptr } undef, i64 0, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  store { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t57 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t54, 0
  %t59 = insertvalue { { i64, ptr }, { i64, ptr } } %t57, { i64, ptr } %t55, 1
  store { { i64, ptr }, { i64, ptr } } %t59, ptr %l54
  %t60 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l54, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l55, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l56, !tbaa !24
  %t64 = load i64, ptr %l56, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l57, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l56, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t76 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l54, i32 0, i32 1
  store { i64, ptr } %t75, ptr %t76, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { { i64, ptr }, { i64, ptr } }, ptr %l54
  store { { i64, ptr }, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %s0, { i64, ptr } %t81)
  store { i64, ptr } %t83, ptr %l60
  br label %bb8
bb8:
  %t84 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t84, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t86, ptr %lp6
  %t88 = load ptr, ptr %lp6
  store { i64, ptr } %t85, ptr %t88, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t89, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t91, ptr %l64
  br label %bb9
bb9:
  %t92 = load i1, ptr %l64, !tbaa !21
  br i1 %t92, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb13
bb11:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t95, ptr %l67
  br label %bb12
bb12:
  %t96 = load i1, ptr %l67, !tbaa !21
  store i1 %t96, ptr %l65, !tbaa !21
  br label %bb13
bb13:
  %t97 = load i1, ptr %l65, !tbaa !21
  br i1 %t97, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = call ptr @__olang_scope_hold(ptr %v2)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l68, !tbaa !24
  %t100 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t100, label %bb16, label %bb17
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t102 = call ptr @__olang_scope_hold(ptr %v2)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l78, !tbaa !24
  %t104 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t104, label %bb25, label %bb26
bb16:
  %t106 = call ptr @__olang_region_make(ptr %v2)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l68, !tbaa !24
  br label %bb17
bb17:
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s3, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l71
  br label %bb18
bb18:
  %t111 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = load i64, ptr %l68
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call ptr @__olang_held_alloc(ptr %t115, i64 %t113)
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l72, !tbaa !27
  %t119 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t119, label %bb19, label %bb20
bb19:
  %t121 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb21, label %bb22
bb20:
  %t126 = load ptr, ptr %lp6
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l76, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t129 = load ptr, ptr %lp6
  store { i64, ptr } %t128, ptr %t129, !tbaa !27
  %t130 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t130, label %bb23, label %bb24
bb21:
  store { i64, ptr } zeroinitializer, ptr %l72, !tbaa !27
  br label %bb22
bb22:
  %t132 = load i64, ptr %l68
  %t133 = inttoptr i64 %t132 to ptr
  %t134 = load { i64, ptr }, ptr %l72
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr null
  call void @__olang_region_settle_in(ptr %t133, ptr %t138)
  br label %bb20
bb23:
  %t139 = load { i64, ptr }, ptr %l76
  %t140 = extractvalue { i64, ptr } %t139, 1
  call void @__olang_region_release(ptr %t140)
  store { i64, ptr } zeroinitializer, ptr %l76
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb25:
  %t141 = call ptr @__olang_region_make(ptr %v2)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l78, !tbaa !24
  br label %bb26
bb26:
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = extractvalue { i64, ptr } %t143, 0
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t144, 1
  %t153 = extractvalue { i64, ptr } %t144, 0
  %t154 = add i64 %t150, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t146, i64 %t147)
  %t156 = getelementptr i8, ptr %t155, i64 %t147
  call void @olang_textcopy(ptr %t156, ptr %t148, i64 %t149)
  %t157 = getelementptr i8, ptr %t156, i64 %t149
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t155, 1
  %t162 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s5, ptr %s5, { i64, ptr } %t159)
  store { i64, ptr } %t162, ptr %l84
  br label %bb27
bb27:
  %t163 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = load i64, ptr %l78
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_held_alloc(ptr %t167, i64 %t165)
  call void @olang_textcopy(ptr %t168, ptr %t164, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l85, !tbaa !27
  %t171 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t171, label %bb28, label %bb29
bb28:
  %t173 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t176 = icmp eq i64 %t174, 0
  br i1 %t176, label %bb30, label %bb31
bb29:
  %t178 = load ptr, ptr %lp6
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l89, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t181 = load ptr, ptr %lp6
  store { i64, ptr } %t180, ptr %t181, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6
  br i1 %t182, label %bb32, label %bb33
bb30:
  store { i64, ptr } zeroinitializer, ptr %l85, !tbaa !27
  br label %bb31
bb31:
  %t184 = load i64, ptr %l78
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = load { i64, ptr }, ptr %l85
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t190)
  br label %bb29
bb32:
  %t191 = load { i64, ptr }, ptr %l89
  %t192 = extractvalue { i64, ptr } %t191, 1
  call void @__olang_region_release(ptr %t192)
  store { i64, ptr } zeroinitializer, ptr %l89
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t195 = getelementptr %"compiler/load:Module", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l92, !tbaa !27
  %t197 = load ptr, ptr %l4, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 2
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t203 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t200, i8 47)
  %t204 = extractvalue { i32, i64 } %t203, 1
  %t205 = extractvalue { i32, i64 } %t203, 0
  store i32 %t205, ptr %l98
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb36, label %ok.207, !prof !99
ok.207:
  store i64 %t204, ptr %l97
  br label %bb35
bb35:
  %t208 = load i64, ptr %l97, !tbaa !24
  store i64 %t208, ptr %l93, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = getelementptr %"compiler/load:Module", ptr %t209, i32 0, i32 2
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 0
  store i64 %t214, ptr %l93, !tbaa !24
  br label %bb38
bb38:
  %t216 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l102, !tbaa !24
  %t218 = icmp sge i64 0, 0
  br i1 %t218, label %bb39, label %bb40
bb39:
  %t220 = load i64, ptr %l93, !tbaa !24
  %t221 = icmp sle i64 0, %t220
  br i1 %t221, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_9daea36ebb972439_574e08d4d8c23575)
  unreachable
bb41:
  %t223 = load i64, ptr %l93, !tbaa !24
  %t224 = load i64, ptr %l102, !tbaa !24
  %t225 = icmp sle i64 %t223, %t224
  br i1 %t225, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_9daea36ebb972439_574e08d4d8c23575)
  unreachable
bb43:
  %t227 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l93, !tbaa !24
  %t230 = getelementptr i8, ptr %t228, i64 0
  %t231 = sub i64 %t229, 0
  %t232 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  store { i64, ptr } %t233, ptr %l7, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t239 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t235, { i64, ptr } %t238)
  store i1 %t239, ptr %l110
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_9daea36ebb972439_574e08d4d8c23575)
  unreachable
bb45:
  %t240 = load i1, ptr %l110, !tbaa !21
  br i1 %t240, label %bb46, label %bb47
bb46:
  %t241 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t241, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t243, ptr %l113
  br label %bb48
bb47:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb49
bb48:
  %t244 = load i1, ptr %l113, !tbaa !21
  %t245 = xor i1 %t244, true
  store i1 %t245, ptr %l111, !tbaa !21
  br label %bb49
bb49:
  %t247 = load i1, ptr %l111, !tbaa !21
  br i1 %t247, label %bb50, label %bb51
bb50:
  %t248 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t250 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t248, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t250, ptr %l117
  br label %bb52
bb51:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb53
bb52:
  %t251 = load i1, ptr %l117, !tbaa !21
  %t252 = xor i1 %t251, true
  store i1 %t252, ptr %l115, !tbaa !21
  br label %bb53
bb53:
  %t254 = load i1, ptr %l115, !tbaa !21
  store i1 %t254, ptr %l8, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l119, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t255, ptr %l9, !tbaa !27
  %t257 = load ptr, ptr %l4, !tbaa !29
  %t259 = getelementptr %"compiler/load:Module", ptr %t257, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t260, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t262, ptr %l123
  br label %bb54
bb54:
  %t263 = load i1, ptr %l123, !tbaa !21
  br i1 %t263, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t265, ptr %l126, !tbaa !27
  store { i64, ptr } %t264, ptr %l9, !tbaa !27
  %t267 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e9
  br i1 %t267, label %bb57, label %bb58
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t269 = load i1, ptr %l8, !tbaa !21
  br i1 %t269, label %bb59, label %bb60
bb57:
  %t271 = load { i64, ptr }, ptr %l126
  %t272 = extractvalue { i64, ptr } %t271, 1
  call void @__olang_region_release(ptr %t272)
  store { i64, ptr } zeroinitializer, ptr %l126
  br label %bb58
bb58:
  br label %bb75
bb59:
  %t273 = load ptr, ptr %l4, !tbaa !29
  %t275 = getelementptr %"compiler/load:Module", ptr %t273, i32 0, i32 2
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l133, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t280 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s9, { i64, ptr } %t276, { i64, ptr } %t279)
  store i1 %t280, ptr %l134
  br label %bb61
bb60:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb62
bb61:
  %t281 = load i1, ptr %l134, !tbaa !21
  store i1 %t281, ptr %l129, !tbaa !21
  br label %bb62
bb62:
  %t282 = load i1, ptr %l129, !tbaa !21
  br i1 %t282, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t283 = call ptr @__olang_scope_hold(ptr %s0)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l135, !tbaa !24
  %t285 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e9
  br i1 %t285, label %bb65, label %bb66
bb64:
  br label %bb74
bb65:
  %t287 = call ptr @__olang_region_make(ptr %s0)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l135, !tbaa !24
  br label %bb66
bb66:
  %t289 = load ptr, ptr %l4, !tbaa !29
  %t291 = getelementptr %"compiler/load:Module", ptr %t289, i32 0, i32 2
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t294 = call { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, ptr %s10, { i64, ptr } %t292, i64 3)
  store { i64, ptr } %t294, ptr %l139
  br label %bb67
bb67:
  %t295 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = load i64, ptr %l135
  %t299 = inttoptr i64 %t298 to ptr
  %t300 = call ptr @__olang_held_alloc(ptr %t299, i64 %t297)
  call void @olang_textcopy(ptr %t300, ptr %t296, i64 %t297)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l140, !tbaa !27
  %t303 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e9
  br i1 %t303, label %bb68, label %bb69
bb68:
  %t305 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  %t308 = icmp eq i64 %t306, 0
  br i1 %t308, label %bb70, label %bb71
bb69:
  %t310 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t310, ptr %l144, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t311, ptr %l9, !tbaa !27
  %t312 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e9
  br i1 %t312, label %bb72, label %bb73
bb70:
  store { i64, ptr } zeroinitializer, ptr %l140, !tbaa !27
  br label %bb71
bb71:
  %t314 = load i64, ptr %l135
  %t315 = inttoptr i64 %t314 to ptr
  %t316 = load { i64, ptr }, ptr %l140
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = call ptr @__olang_region_or(ptr %t317, ptr null)
  %t319 = icmp ne ptr %t318, null
  %t320 = select i1 %t319, ptr %t318, ptr null
  call void @__olang_region_settle_in(ptr %t315, ptr %t320)
  br label %bb69
bb72:
  %t321 = load { i64, ptr }, ptr %l144
  %t322 = extractvalue { i64, ptr } %t321, 1
  call void @__olang_region_release(ptr %t322)
  store { i64, ptr } zeroinitializer, ptr %l144
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s10)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  br label %bb75
bb75:
  %t323 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t325 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t323, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t325, ptr %l147
  br label %bb76
bb76:
  %t326 = load i1, ptr %l147, !tbaa !21
  %t327 = xor i1 %t326, true
  br i1 %t327, label %bb77, label %bb78
bb77:
  %t329 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t331 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t329, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t331, ptr %l151
  br label %bb79
bb78:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb85
bb79:
  %t332 = load i1, ptr %l151, !tbaa !21
  br i1 %t332, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb84
bb81:
  %t333 = load ptr, ptr %l4, !tbaa !29
  %t335 = getelementptr %"compiler/load:Module", ptr %t333, i32 0, i32 2
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t340 = call { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t336, { i64, ptr } %t337)
  store { i64, ptr } %t340, ptr %l156
  br label %bb82
bb82:
  %t341 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 1
  %t345 = extractvalue { i64, ptr } %t342, 0
  %t346 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t348 = add i64 %t345, %t347
  %t349 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t344, i64 %t345)
  %t350 = getelementptr i8, ptr %t349, i64 %t345
  call void @olang_textcopy(ptr %t350, ptr %t346, i64 %t347)
  %t351 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t349, 1
  %t356 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t341, { i64, ptr } %t352)
  store i1 %t356, ptr %l161
  br label %bb83
bb83:
  %t357 = load i1, ptr %l161, !tbaa !21
  %t358 = xor i1 %t357, true
  store i1 %t358, ptr %l152, !tbaa !21
  br label %bb84
bb84:
  %t360 = load i1, ptr %l152, !tbaa !21
  store i1 %t360, ptr %l149, !tbaa !21
  br label %bb85
bb85:
  %t361 = load i1, ptr %l149, !tbaa !21
  br i1 %t361, label %bb86, label %bb87
bb86:
  %t362 = load ptr, ptr %lp3
  %t364 = insertvalue { i64, ptr } undef, i64 0, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t362, 1
  %t366 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t367 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t370 = extractvalue { i64, ptr } %t366, 1
  %t371 = extractvalue { i64, ptr } %t366, 0
  %t372 = add i64 %t368, %t371
  %t373 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t372)
  call void @olang_textcopy(ptr %t373, ptr %t367, i64 %t368)
  %t374 = getelementptr i8, ptr %t373, i64 %t368
  call void @olang_textcopy(ptr %t374, ptr %t370, i64 %t371)
  %t375 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t373, 1
  %t378 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t365, 0
  %t380 = insertvalue { { i64, ptr }, { i64, ptr } } %t378, { i64, ptr } %t376, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t380, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t382 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t384 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t382, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t384, ptr %l169
  br label %bb89
bb89:
  %t385 = load i1, ptr %l169, !tbaa !21
  %t386 = xor i1 %t385, true
  br i1 %t386, label %bb90, label %bb91
bb90:
  %t388 = load ptr, ptr %lp6
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t391 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t389)
  store i1 %t391, ptr %l173
  br label %bb92
bb91:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb93
bb92:
  %t392 = load i1, ptr %l173, !tbaa !21
  store i1 %t392, ptr %l171, !tbaa !21
  br label %bb93
bb93:
  %t393 = load i1, ptr %l171, !tbaa !21
  br i1 %t393, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l174, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t394, ptr %l10, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t398 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s15, { i64, ptr } %t396, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t398, ptr %l177
  br label %bb96
bb95:
  br label %bb154
bb96:
  %t399 = load i1, ptr %l177, !tbaa !21
  br i1 %t399, label %bb97, label %bb98
bb97:
  %t400 = call ptr @__olang_scope_hold(ptr %s15)
  %t401 = ptrtoint ptr %t400 to i64
  store i64 %t401, ptr %l178, !tbaa !24
  %t402 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t402, label %bb99, label %bb100
bb98:
  store %olang.scope zeroinitializer, ptr %s17
  %t404 = load ptr, ptr %l4, !tbaa !29
  %t406 = getelementptr %"compiler/load:Module", ptr %t404, i32 0, i32 2
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  store { i64, ptr } %t407, ptr %l189, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l192, !tbaa !24
  %t413 = load ptr, ptr %l4, !tbaa !29
  %t415 = getelementptr %"compiler/load:Module", ptr %t413, i32 0, i32 2
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t416, 0
  store i64 %t419, ptr %l196, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 0
  store i64 %t421, ptr %l197, !tbaa !24
  %t422 = load i64, ptr %l192, !tbaa !24
  %t423 = icmp sge i64 %t422, 0
  br i1 %t423, label %bb105, label %bb106
bb99:
  %t425 = call ptr @__olang_region_make(ptr %s15)
  %t426 = ptrtoint ptr %t425 to i64
  store i64 %t426, ptr %l178, !tbaa !24
  br label %bb100
bb100:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/load:Loader", ptr %t427, i32 0, i32 15
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l182, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  store i64 %t433, ptr %l183, !tbaa !24
  %t434 = load i64, ptr %l183, !tbaa !24
  %t435 = mul i64 %t434, 1
  %t436 = load i64, ptr %l178
  %t437 = inttoptr i64 %t436 to ptr
  %t438 = call ptr @__olang_held_alloc(ptr %t437, i64 %t435)
  %t439 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  store { i64, ptr } %t440, ptr %l184, !tbaa !27
  %t441 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = load i64, ptr %l183, !tbaa !24
  %t446 = mul i64 %t445, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t442, ptr %t444, i64 %t446, i1 false)
  %t447 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t447, ptr %l185, !tbaa !27
  %t448 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t448, ptr %l10, !tbaa !27
  %t449 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t449, label %bb101, label %bb102
bb101:
  %t451 = load { i64, ptr }, ptr %l185
  %t452 = extractvalue { i64, ptr } %t451, 1
  call void @__olang_region_release(ptr %t452)
  store { i64, ptr } zeroinitializer, ptr %l185
  br label %bb102
bb102:
  %t453 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t453, label %bb103, label %bb104
bb103:
  %t455 = load i64, ptr %l178
  %t456 = inttoptr i64 %t455 to ptr
  %t457 = load { i64, ptr }, ptr %l10
  %t458 = extractvalue { i64, ptr } %t457, 1
  %t459 = call ptr @__olang_region_or(ptr %t458, ptr null)
  %t460 = icmp ne ptr %t459, null
  %t461 = select i1 %t460, ptr %t459, ptr null
  call void @__olang_region_settle_in(ptr %t456, ptr %t461)
  br label %bb104
bb104:
  br label %bb139
bb105:
  %t462 = load i64, ptr %l192, !tbaa !24
  %t463 = load i64, ptr %l196, !tbaa !24
  %t464 = icmp sle i64 %t462, %t463
  br i1 %t464, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_af475931a368800c_57263df876e21e18)
  unreachable
bb107:
  %t466 = load i64, ptr %l196, !tbaa !24
  %t467 = load i64, ptr %l197, !tbaa !24
  %t468 = icmp sle i64 %t466, %t467
  br i1 %t468, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_af475931a368800c_57263df876e21e18)
  unreachable
bb109:
  %t470 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = load i64, ptr %l192, !tbaa !24
  %t473 = load i64, ptr %l196, !tbaa !24
  %t474 = getelementptr i8, ptr %t471, i64 %t472
  %t475 = sub i64 %t473, %t472
  %t476 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t474, 1
  %t479 = load ptr, ptr %l4, !tbaa !29
  %t481 = getelementptr %"compiler/load:Module", ptr %t479, i32 0, i32 0
  %t482 = load { i64, ptr }, ptr %t481, !tbaa !27
  store { i64, ptr } %t482, ptr %l12, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s18
  store i64 0, ptr %l13, !tbaa !24
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l206, !tbaa !27
  %t487 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t488 = call i64 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eCountOf_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s18, { i64, ptr } %t477, { i64, ptr } %t487)
  store i64 %t488, ptr %l207
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_af475931a368800c_57263df876e21e18)
  unreachable
bb111:
  %t489 = load i64, ptr %l207, !tbaa !24
  %t490 = add i64 %t489, 1
  store i64 %t490, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t492 = load i64, ptr %l14, !tbaa !24
  %t493 = load i64, ptr %l13, !tbaa !24
  %t496 = icmp sgt i64 %t492, %t493
  br i1 %t496, label %bb112, label %bb113
bb112:
  %t498 = load i64, ptr %l15, !tbaa !24
  %t500 = icmp sgt i64 %t498, 0
  br i1 %t500, label %bb114, label %bb115
bb113:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb117
bb114:
  %t502 = load i64, ptr %l14, !tbaa !24
  %t503 = load i64, ptr %l13, !tbaa !24
  %t506 = sub i64 %t502, %t503
  %t507 = load i64, ptr %l15, !tbaa !24
  %t510 = add i64 %t506, %t507
  %t512 = sub i64 %t510, 1
  %t513 = load i64, ptr %l15, !tbaa !24
  %t516 = sdiv i64 %t512, %t513
  store i64 %t516, ptr %l215, !tbaa !24
  br label %bb116
bb115:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb116
bb116:
  %t518 = load i64, ptr %l215, !tbaa !24
  store i64 %t518, ptr %l212, !tbaa !24
  br label %bb117
bb117:
  %t519 = load i64, ptr %l212, !tbaa !24
  store i64 %t519, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s19
  %t520 = load i64, ptr %l17, !tbaa !24
  %t521 = load i64, ptr %l16, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s19)
  br label %bb124
bb120:
  br label %bb121
bb121:
  %t528 = load i64, ptr %l13, !tbaa !24
  %t529 = load i64, ptr %l17, !tbaa !24
  %t530 = load i64, ptr %l15, !tbaa !24
  %t533 = mul i64 %t529, %t530
  %t536 = add i64 %t528, %t533
  store i64 %t536, ptr %l18, !tbaa !24
  %t538 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t538, ptr %l233, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 1
  %t541 = call ptr @__olang_scope_of(ptr %t540, ptr null)
  %t542 = call ptr @__olang_scope_hold(ptr %t541)
  %t543 = ptrtoint ptr %t542 to i64
  %t545 = inttoptr i64 %t543 to ptr
  %t546 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t547 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %t545, ptr %s19, { i64, ptr } %t546)
  store { i64, ptr } %t547, ptr %l235
  br label %bb122
bb122:
  %t548 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 1
  %t550 = extractvalue { i64, ptr } %t548, 0
  %t551 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t549, i64 %t550)
  %t552 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  store { i64, ptr } %t553, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb123
bb123:
  %t556 = load i64, ptr %l17, !tbaa !24
  %t559 = add i64 %t556, 1
  store i64 %t559, ptr %l17, !tbaa !24
  br label %bb118
bb124:
  call void @__olang_scope_close(ptr %s18)
  %t561 = call ptr @__olang_scope_hold(ptr %s15)
  %t562 = ptrtoint ptr %t561 to i64
  store i64 %t562, ptr %l241, !tbaa !24
  %t563 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t563, label %bb125, label %bb126
bb125:
  %t565 = call ptr @__olang_region_make(ptr %s15)
  %t566 = ptrtoint ptr %t565 to i64
  store i64 %t566, ptr %l241, !tbaa !24
  br label %bb126
bb126:
  %t567 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t567, ptr %l244, !tbaa !27
  %t568 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = call ptr @__olang_scope_of(ptr %t569, ptr null)
  %t571 = call ptr @__olang_scope_hold(ptr %t570)
  %t572 = ptrtoint ptr %t571 to i64
  %t574 = inttoptr i64 %t572 to ptr
  %t575 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t576 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %t574, ptr %s17, { i64, ptr } %t575)
  %t577 = extractvalue { i32, { i64, ptr } } %t576, 1
  %t578 = extractvalue { i32, { i64, ptr } } %t576, 0
  store i32 %t578, ptr %l247
  %t579 = icmp ne i32 %t578, 0
  br i1 %t579, label %bb128, label %ok.580, !prof !99
ok.580:
  store { i64, ptr } %t577, ptr %l246
  br label %bb127
bb127:
  %t581 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t581, ptr %l243, !tbaa !27
  br label %bb132
bb128:
  %t582 = load i32, ptr %l247, !tbaa !23
  %t583 = ashr i32 %t582, 16
  %t585 = icmp eq i32 %t583, 1
  br i1 %t585, label %bb129, label %bb130
bb129:
  call void @__olang_errpay_pop()
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t587 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t587, ptr %l243, !tbaa !27
  br label %bb132
bb132:
  %t589 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t589, 1
  %t591 = extractvalue { i64, ptr } %t589, 0
  %t592 = load i64, ptr %l241
  %t593 = inttoptr i64 %t592 to ptr
  %t594 = call ptr @__olang_held_alloc(ptr %t593, i64 %t591)
  call void @olang_textcopy(ptr %t594, ptr %t590, i64 %t591)
  %t595 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t594, 1
  store { i64, ptr } %t596, ptr %l251, !tbaa !27
  %t597 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t597, label %bb133, label %bb134
bb133:
  %t599 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t599, 0
  %t602 = icmp eq i64 %t600, 0
  br i1 %t602, label %bb135, label %bb136
bb134:
  %t604 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t604, ptr %l255, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t605, ptr %l10, !tbaa !27
  %t606 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10
  br i1 %t606, label %bb137, label %bb138
bb135:
  store { i64, ptr } zeroinitializer, ptr %l251, !tbaa !27
  br label %bb136
bb136:
  %t608 = load i64, ptr %l241
  %t609 = inttoptr i64 %t608 to ptr
  %t610 = load { i64, ptr }, ptr %l251
  %t611 = extractvalue { i64, ptr } %t610, 1
  %t612 = call ptr @__olang_region_or(ptr %t611, ptr null)
  %t613 = icmp ne ptr %t612, null
  %t614 = select i1 %t613, ptr %t612, ptr null
  call void @__olang_region_settle_in(ptr %t609, ptr %t614)
  br label %bb134
bb137:
  %t615 = load { i64, ptr }, ptr %l255
  %t616 = extractvalue { i64, ptr } %t615, 1
  call void @__olang_region_release(ptr %t616)
  store { i64, ptr } zeroinitializer, ptr %l255
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s17)
  br label %bb139
bb139:
  %t617 = load ptr, ptr %lp6
  %t618 = load { i64, ptr }, ptr %t617, !tbaa !27
  %t620 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v2, ptr %s15, { i64, ptr } %t618)
  %t621 = extractvalue { i32, { i64, ptr } } %t620, 1
  %t622 = extractvalue { i32, { i64, ptr } } %t620, 0
  store i32 %t622, ptr %l260
  %t623 = icmp ne i32 %t622, 0
  br i1 %t623, label %bb141, label %ok.624, !prof !99
ok.624:
  store { i64, ptr } %t621, ptr %l259
  br label %bb140
bb140:
  %t625 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t625, ptr %l257, !tbaa !27
  br label %bb145
bb141:
  %t626 = load i32, ptr %l260, !tbaa !23
  %t627 = ashr i32 %t626, 16
  %t629 = icmp eq i32 %t627, 1
  br i1 %t629, label %bb142, label %bb143
bb142:
  call void @__olang_errpay_pop()
  br label %bb143
bb143:
  br label %bb144
bb144:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l257, !tbaa !27
  br label %bb145
bb145:
  %t631 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t631, ptr %l19, !tbaa !27
  %t632 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t634 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t632, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t634, ptr %l264
  br label %bb146
bb146:
  %t635 = load i1, ptr %l264, !tbaa !21
  br i1 %t635, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l265, !tbaa !21
  br label %bb150
bb148:
  %t636 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t637, 1
  %t640 = extractvalue { i64, ptr } %t637, 0
  %t641 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t642 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t643 = add i64 %t640, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t639, i64 %t640)
  %t645 = getelementptr i8, ptr %t644, i64 %t640
  call void @olang_textcopy(ptr %t645, ptr %t641, i64 %t642)
  %t646 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t644, 1
  %t651 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s15, ptr %s15, { i64, ptr } %t636, { i64, ptr } %t647)
  store i1 %t651, ptr %l270
  br label %bb149
bb149:
  %t652 = load i1, ptr %l270, !tbaa !21
  %t653 = xor i1 %t652, true
  store i1 %t653, ptr %l265, !tbaa !21
  br label %bb150
bb150:
  %t655 = load i1, ptr %l265, !tbaa !21
  br i1 %t655, label %bb151, label %bb152
bb151:
  %t656 = load ptr, ptr %lp3
  %t658 = insertvalue { i64, ptr } undef, i64 0, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t656, 1
  %t660 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t661 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t664 = extractvalue { i64, ptr } %t660, 1
  %t665 = extractvalue { i64, ptr } %t660, 0
  %t666 = add i64 %t662, %t665
  %t667 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t668 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t669 = add i64 %t666, %t668
  %t670 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t661, i64 %t662)
  %t671 = getelementptr i8, ptr %t670, i64 %t662
  call void @olang_textcopy(ptr %t671, ptr %t664, i64 %t665)
  %t672 = getelementptr i8, ptr %t671, i64 %t665
  call void @olang_textcopy(ptr %t672, ptr %t667, i64 %t668)
  %t673 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t670, 1
  %t676 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t659, 0
  %t678 = insertvalue { { i64, ptr }, { i64, ptr } } %t676, { i64, ptr } %t674, 1
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t678, ptr %rv
  br label %ret
bb152:
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s15)
  br label %bb154
bb154:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/load:Loader", ptr %t680, i32 0, i32 17
  %t683 = load ptr, ptr %lp6
  %t684 = load { i64, ptr }, ptr %t683, !tbaa !27
  %t687 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H31dec199381f6e2bb0c82058ea887922(ptr %v0, ptr %v2, ptr %t682, { i64, ptr } %t684)
  store i1 %t687, ptr %l280
  br label %bb155
bb155:
  %t688 = load i1, ptr %l280, !tbaa !21
  %t689 = xor i1 %t688, true
  br i1 %t689, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s26
  %t691 = load ptr, ptr %lp6
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  %t694 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t692)
  store i1 %t694, ptr %l283
  br label %bb158
bb157:
  br label %bb181
bb158:
  %t695 = load i1, ptr %l283, !tbaa !21
  %t696 = xor i1 %t695, true
  br i1 %t696, label %bb159, label %bb160
bb159:
  %t698 = load ptr, ptr %lp3
  %t700 = insertvalue { i64, ptr } undef, i64 0, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t698, 1
  %t702 = load ptr, ptr %lp6
  %t703 = load { i64, ptr }, ptr %t702, !tbaa !27
  %t704 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t705 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t707 = extractvalue { i64, ptr } %t703, 1
  %t708 = extractvalue { i64, ptr } %t703, 0
  %t709 = add i64 %t705, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t704, i64 %t705)
  %t711 = getelementptr i8, ptr %t710, i64 %t705
  call void @olang_textcopy(ptr %t711, ptr %t707, i64 %t708)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t710, 1
  %t715 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t701, 0
  %t717 = insertvalue { { i64, ptr }, { i64, ptr } } %t715, { i64, ptr } %t713, 1
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t717, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  %t719 = load ptr, ptr %lp6
  %t720 = load { i64, ptr }, ptr %t719, !tbaa !27
  %t722 = call i1 @std_2fos_2eIsDir(ptr %v2, { i64, ptr } %t720)
  store i1 %t722, ptr %l291
  br label %bb162
bb162:
  %t723 = load i1, ptr %l291, !tbaa !21
  br i1 %t723, label %bb163, label %bb164
bb163:
  %t724 = load ptr, ptr %lp3
  %t726 = insertvalue { i64, ptr } undef, i64 0, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t724, 1
  %t728 = load ptr, ptr %lp6
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t729, 1
  %t732 = extractvalue { i64, ptr } %t729, 0
  %t733 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t735 = add i64 %t732, %t734
  %t736 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t735)
  call void @olang_textcopy(ptr %t736, ptr %t731, i64 %t732)
  %t737 = getelementptr i8, ptr %t736, i64 %t732
  call void @olang_textcopy(ptr %t737, ptr %t733, i64 %t734)
  %t738 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t736, 1
  %t741 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t727, 0
  %t743 = insertvalue { { i64, ptr }, { i64, ptr } } %t741, { i64, ptr } %t739, 1
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t743, ptr %rv
  br label %ret
bb164:
  br label %bb165
bb165:
  %t745 = load ptr, ptr %lp6
  %t746 = load { i64, ptr }, ptr %t745, !tbaa !27
  %t748 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v2, ptr %s26, { i64, ptr } %t746)
  %t749 = extractvalue { i32, { i64, ptr } } %t748, 1
  %t750 = extractvalue { i32, { i64, ptr } } %t748, 0
  store i32 %t750, ptr %l300
  %t751 = icmp ne i32 %t750, 0
  br i1 %t751, label %bb167, label %ok.752, !prof !99
ok.752:
  store { i64, ptr } %t749, ptr %l299
  br label %bb166
bb166:
  %t753 = load { i64, ptr }, ptr %l299, !tbaa !27
  store { i64, ptr } %t753, ptr %l297, !tbaa !27
  br label %bb171
bb167:
  %t754 = load i32, ptr %l300, !tbaa !23
  %t755 = ashr i32 %t754, 16
  %t757 = icmp eq i32 %t755, 1
  store i1 %t757, ptr %l302, !tbaa !21
  %t758 = load i32, ptr %l300, !tbaa !23
  %t759 = ashr i32 %t758, 16
  %t761 = icmp eq i32 %t759, 1
  br i1 %t761, label %bb168, label %bb169
bb168:
  call void @__olang_errpay_pop()
  br label %bb169
bb169:
  br label %bb170
bb170:
  %t763 = load ptr, ptr %lp3
  %t765 = insertvalue { i64, ptr } undef, i64 0, 0
  %t766 = insertvalue { i64, ptr } %t765, ptr %t763, 1
  %t767 = load ptr, ptr %lp6
  %t768 = load { i64, ptr }, ptr %t767, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 1
  %t771 = extractvalue { i64, ptr } %t768, 0
  %t772 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t773 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t774 = add i64 %t771, %t773
  %t775 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t774)
  call void @olang_textcopy(ptr %t775, ptr %t770, i64 %t771)
  %t776 = getelementptr i8, ptr %t775, i64 %t771
  call void @olang_textcopy(ptr %t776, ptr %t772, i64 %t773)
  %t777 = insertvalue { i64, ptr } undef, i64 %t774, 0
  %t778 = insertvalue { i64, ptr } %t777, ptr %t775, 1
  %t780 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t766, 0
  %t782 = insertvalue { { i64, ptr }, { i64, ptr } } %t780, { i64, ptr } %t778, 1
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, { i64, ptr } } %t782, ptr %rv
  br label %ret
bb171:
  %t784 = load { i64, ptr }, ptr %l297, !tbaa !27
  store { i64, ptr } %t784, ptr %l20, !tbaa !27
  %t785 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t787 = extractvalue { i64, ptr } %t785, 0
  store i64 %t787, ptr %l311, !tbaa !24
  %t788 = load i64, ptr %l311, !tbaa !24
  %t789 = icmp sge i64 %t788, 0
  br i1 %t789, label %bb172, label %bb173
bb172:
  %t791 = load i64, ptr %l311, !tbaa !24
  %t792 = mul i64 %t791, 1
  %t793 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t792)
  %t794 = insertvalue { i64, ptr } undef, i64 %t791, 0
  %t795 = insertvalue { i64, ptr } %t794, ptr %t793, 1
  %t796 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t796, ptr %lp21
  %t798 = load ptr, ptr %lp21
  store { i64, ptr } %t795, ptr %t798, !tbaa !27
  %t799 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t799, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t801 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t801, 0
  store i64 %t803, ptr %l24, !tbaa !24
  %t805 = load i64, ptr %l24, !tbaa !24
  %t806 = sub i64 %t805, 1
  store i64 %t806, ptr %l317, !tbaa !24
  %t807 = load i64, ptr %l24, !tbaa !24
  %t808 = icmp slt i64 %t807, 2147483648
  %t809 = load i64, ptr %l23, !tbaa !24
  %t810 = icmp sge i64 %t809, 0
  %t813 = and i1 %t808, %t810
  store i1 %t813, ptr %l320, !tbaa !21
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_5aefafbfcb5eb6b7_7e4be8b78a5947cb)
  unreachable
bb174:
  %t814 = load i64, ptr %l23, !tbaa !24
  %t815 = load i64, ptr %l24, !tbaa !24
  %t818 = icmp slt i64 %t814, %t815
  %t820 = xor i1 %t818, true
  br i1 %t820, label %bb175, label %bb176
bb175:
  br label %bb179
bb176:
  br label %bb177
bb177:
  %t822 = load i64, ptr %l23, !tbaa !24
  %t824 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t824, ptr %l326, !tbaa !27
  %t825 = load i64, ptr %l23, !tbaa !24
  %t827 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !27
  %t829 = getelementptr i8, ptr %t828, i64 %t825
  %t830 = load i8, ptr %t829, !tbaa !32
  %t836 = load ptr, ptr %lp21
  %t838 = getelementptr { i64, ptr }, ptr %t836, i32 0, i32 1
  %t839 = load ptr, ptr %t838, !tbaa !27
  %t840 = getelementptr i8, ptr %t839, i64 %t822
  store i8 %t830, ptr %t840, !tbaa !32
  br label %bb178
bb178:
  %t841 = load i64, ptr %l23, !tbaa !24
  %t844 = add i64 %t841, 1
  store i64 %t844, ptr %l23, !tbaa !24
  br label %bb174
bb179:
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t848 = getelementptr %"compiler/load:Loader", ptr %t846, i32 0, i32 17
  %t849 = load ptr, ptr %lp6
  %t850 = load { i64, ptr }, ptr %t849, !tbaa !27
  %t851 = load ptr, ptr %lp21
  %t852 = load { i64, ptr }, ptr %t851, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha0f924a08ec45a4a582ec1782d69c4be(ptr %v0, ptr %v2, ptr %v0, ptr %t848, { i64, ptr } %t850, { i64, ptr } %t852)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s26)
  br label %bb181
bb181:
  store i1 false, ptr %l27, !tbaa !21
  %t856 = load ptr, ptr %l4, !tbaa !29
  %t858 = getelementptr %"compiler/load:Module", ptr %t856, i32 0, i32 32
  store ptr %t858, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb182
bb182:
  %t860 = load i64, ptr %l29, !tbaa !24
  store i64 %t860, ptr %l341, !tbaa !24
  %t861 = load ptr, ptr %l28, !tbaa !29
  %t863 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t861)
  store i64 %t863, ptr %l343
  br label %bb183
bb183:
  %t864 = load i64, ptr %l341, !tbaa !24
  %t865 = load i64, ptr %l343, !tbaa !24
  %t866 = icmp slt i64 %t864, %t865
  %t868 = xor i1 %t866, true
  br i1 %t868, label %bb184, label %bb185
bb184:
  br label %bb193
bb185:
  br label %bb186
bb186:
  %t870 = load ptr, ptr %l28, !tbaa !29
  %t871 = load i64, ptr %l29, !tbaa !24
  %t874 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t870, i64 %t871)
  store { i64, ptr } %t874, ptr %l348
  br label %bb187
bb187:
  %t875 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t877 = load ptr, ptr %lp6
  %t878 = load { i64, ptr }, ptr %t877, !tbaa !27
  %t881 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t875, { i64, ptr } %t878)
  store i1 %t881, ptr %l351
  br label %bb188
bb188:
  %t882 = load i1, ptr %l351, !tbaa !21
  br i1 %t882, label %bb189, label %bb190
bb189:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb191
bb190:
  br label %bb191
bb191:
  br label %bb192
bb192:
  %t883 = load i64, ptr %l29, !tbaa !24
  %t886 = add i64 %t883, 1
  store i64 %t886, ptr %l29, !tbaa !24
  br label %bb182
bb193:
  %t888 = load i1, ptr %l27, !tbaa !21
  %t890 = xor i1 %t888, true
  br i1 %t890, label %bb194, label %bb195
bb194:
  %t892 = load ptr, ptr %l4, !tbaa !29
  %t894 = getelementptr %"compiler/load:Module", ptr %t892, i32 0, i32 32
  %t895 = load ptr, ptr %lp6
  %t896 = load { i64, ptr }, ptr %t895, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v2, ptr %t894, { i64, ptr } %t896)
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb197
bb197:
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t901 = getelementptr %"compiler/load:Loader", ptr %t899, i32 0, i32 17
  %t902 = load ptr, ptr %lp6
  %t903 = load { i64, ptr }, ptr %t902, !tbaa !27
  %t906 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H412951a1c1c3c34f4f6a5a14e25e5986(ptr %v0, ptr %v2, ptr %v2, ptr %t901, { i64, ptr } %t903)
  %t907 = extractvalue { i32, { i64, ptr } } %t906, 1
  %t908 = extractvalue { i32, { i64, ptr } } %t906, 0
  store i32 %t908, ptr %l365
  %t909 = icmp ne i32 %t908, 0
  br i1 %t909, label %bb199, label %ok.910, !prof !99
ok.910:
  store { i64, ptr } %t907, ptr %l364
  br label %bb198
bb198:
  %t911 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t911, ptr %l360, !tbaa !27
  br label %bb201
bb199:
  br label %bb200
bb200:
  %t912 = load ptr, ptr %lp3
  %t914 = insertvalue { i64, ptr } undef, i64 0, 0
  %t915 = insertvalue { i64, ptr } %t914, ptr %t912, 1
  store { i64, ptr } %t915, ptr %l360, !tbaa !27
  br label %bb201
bb201:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l368, !tbaa !27
  %t917 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t918 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t919 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t918, 0
  %t921 = insertvalue { { i64, ptr }, { i64, ptr } } %t919, { i64, ptr } %t917, 1
  store { { i64, ptr }, { i64, ptr } } %t921, ptr %l370
  %t922 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l370, i32 0, i32 1
  %t923 = load { i64, ptr }, ptr %t922, !tbaa !27
  store { i64, ptr } %t923, ptr %l371, !tbaa !27
  %t924 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t925 = extractvalue { i64, ptr } %t924, 0
  store i64 %t925, ptr %l372, !tbaa !24
  %t926 = load i64, ptr %l372, !tbaa !24
  %t927 = mul i64 %t926, 1
  %t928 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t927)
  %t929 = insertvalue { i64, ptr } undef, i64 %t926, 0
  %t930 = insertvalue { i64, ptr } %t929, ptr %t928, 1
  store { i64, ptr } %t930, ptr %l373, !tbaa !27
  %t931 = getelementptr { i64, ptr }, ptr %l373, i32 0, i32 1
  %t932 = load ptr, ptr %t931, !tbaa !27
  %t933 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t934 = load ptr, ptr %t933, !tbaa !27
  %t935 = load i64, ptr %l372, !tbaa !24
  %t936 = mul i64 %t935, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t932, ptr %t934, i64 %t936, i1 false)
  %t937 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t938 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l370, i32 0, i32 1
  store { i64, ptr } %t937, ptr %t938, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t939 = load { { i64, ptr }, { i64, ptr } }, ptr %l370
  store { { i64, ptr }, { i64, ptr } } %t939, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eGraph(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/load:Import"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l65 = alloca %"std/prelude/text:StringBuilder"
  %l73 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca %"compiler/load:Import"
  %l98 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t93 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load i64, ptr %l23, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l23, !tbaa !24
  %t10 = icmp sle i64 %t9, 1152921504606846975
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_53eff658f30813a6_f347cd1231cef772)
  unreachable
bb4:
  %t12 = load i64, ptr %l23, !tbaa !24
  %t13 = mul i64 %t12, 8
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_53eff658f30813a6_f347cd1231cef772)
  unreachable
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb8:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l32, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t50, 1
  store i64 %t51, ptr %l44, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t52, 2147483648
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  %t58 = and i1 %t53, %t55
  store i1 %t58, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t77
  store i64 %t78, ptr %t83, !tbaa !34
  br label %bb16
bb16:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb12
bb17:
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t92 = ptrtoint ptr %t91 to i64
  %t94 = getelementptr { ptr, ptr }, ptr %t93, i32 0, i32 0
  store ptr %t90, ptr %t94, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t96 = call ptr @__olang_scope_hold(ptr %v0)
  %t97 = getelementptr { ptr, ptr }, ptr %t93, i32 0, i32 1
  store ptr %t96, ptr %t97, !tbaa !28
  %t98 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_77, 0
  %t99 = insertvalue { ptr, ptr } %t98, ptr %t93, 1
  %t102 = extractvalue { ptr, ptr } %t99, 0
  %t103 = extractvalue { ptr, ptr } %t99, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t89, ptr %t102, ptr %t103)
  br label %bb18
bb18:
  %t104 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t104, ptr %l65
  br label %bb19
bb19:
  %t105 = load %"std/prelude/text:StringBuilder", ptr %l65
  store %"std/prelude/text:StringBuilder" %t105, ptr %l8
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load i64, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb22:
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t120, ptr %l73, !tbaa !27
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i64, ptr %t124, i64 %t121
  %t126 = load i64, ptr %t125, !tbaa !34
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/load:Loader", ptr %t128, i32 0, i32 10
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t130, i64 %t126)
  store ptr %t134, ptr %l79
  br label %bb24
bb24:
  %t135 = load ptr, ptr %l79, !tbaa !29
  store ptr %t135, ptr %l13, !tbaa !29
  %t136 = load ptr, ptr %l13, !tbaa !29
  %t138 = getelementptr %"compiler/load:Module", ptr %t136, i32 0, i32 2
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t143 = extractvalue { i64, ptr } %t139, 1
  %t144 = extractvalue { i64, ptr } %t139, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l8, { i64, ptr } %t153)
  br label %bb25
bb25:
  %t157 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l85
  br label %bb26
bb26:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l14
  %t159 = load ptr, ptr %l13, !tbaa !29
  %t161 = getelementptr %"compiler/load:Module", ptr %t159, i32 0, i32 11
  store ptr %t161, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  %t163 = load i64, ptr %l16, !tbaa !24
  store i64 %t163, ptr %l88, !tbaa !24
  %t164 = load ptr, ptr %l15, !tbaa !29
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t164)
  store i64 %t166, ptr %l90
  br label %bb28
bb28:
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = load i64, ptr %l90, !tbaa !24
  %t169 = icmp slt i64 %t167, %t168
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l15, !tbaa !29
  %t174 = load i64, ptr %l16, !tbaa !24
  %t177 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store %"compiler/load:Import" %t177, ptr %l95
  br label %bb32
bb32:
  %t178 = load %"compiler/load:Import", ptr %l95
  store %"compiler/load:Import" %t178, ptr %l17
  %t179 = getelementptr %"compiler/load:Import", ptr %l17, i32 0, i32 5
  %t180 = load i64, ptr %t179, !tbaa !24
  %t182 = icmp sge i64 %t180, 0
  br i1 %t182, label %bb33, label %bb34
bb33:
  store ptr %l14, ptr %l98, !tbaa !29
  %t184 = call ptr @__olang_scope_hold(ptr %s5)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l99, !tbaa !24
  %t186 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t186, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  %t188 = call ptr @__olang_region_make(ptr %s5)
  %t189 = ptrtoint ptr %t188 to i64
  store i64 %t189, ptr %l99, !tbaa !24
  br label %bb36
bb36:
  %t190 = getelementptr %"compiler/load:Import", ptr %l17, i32 0, i32 2
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l101, !tbaa !27
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/load:Loader", ptr %t192, i32 0, i32 10
  %t195 = getelementptr %"compiler/load:Import", ptr %l17, i32 0, i32 5
  %t196 = load i64, ptr %t195, !tbaa !24
  %t199 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t194, i64 %t196)
  store ptr %t199, ptr %l105
  br label %bb37
bb37:
  %t200 = load ptr, ptr %l105, !tbaa !29
  %t202 = getelementptr %"compiler/load:Module", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t206 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t214 = extractvalue { i64, ptr } %t203, 1
  %t215 = extractvalue { i64, ptr } %t203, 0
  %t216 = add i64 %t212, %t215
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t220 = load i64, ptr %l99
  %t221 = inttoptr i64 %t220 to ptr
  %t222 = call ptr @__olang_held_alloc(ptr %t221, i64 %t219)
  call void @olang_textcopy(ptr %t222, ptr %t204, i64 %t205)
  %t223 = getelementptr i8, ptr %t222, i64 %t205
  call void @olang_textcopy(ptr %t223, ptr %t207, i64 %t208)
  %t224 = getelementptr i8, ptr %t223, i64 %t208
  call void @olang_textcopy(ptr %t224, ptr %t210, i64 %t211)
  %t225 = getelementptr i8, ptr %t224, i64 %t211
  call void @olang_textcopy(ptr %t225, ptr %t214, i64 %t215)
  %t226 = getelementptr i8, ptr %t225, i64 %t215
  call void @olang_textcopy(ptr %t226, ptr %t217, i64 %t218)
  %t227 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t222, 1
  %t230 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %s5, ptr %t230, { i64, ptr } %t228)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t232 = load i64, ptr %l16, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l16, !tbaa !24
  br label %bb27
bb41:
  %t237 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_83, 0
  %t238 = insertvalue { ptr, ptr } %t237, ptr null, 1
  %t241 = extractvalue { ptr, ptr } %t238, 0
  %t242 = extractvalue { ptr, ptr } %t238, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s5, ptr %s5, ptr %l14, ptr %t241, ptr %t242)
  br label %bb42
bb42:
  store ptr %l14, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  %t244 = load i64, ptr %l19, !tbaa !24
  store i64 %t244, ptr %l116, !tbaa !24
  %t245 = load ptr, ptr %l18, !tbaa !29
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s5, ptr %t245)
  store i64 %t247, ptr %l118
  br label %bb44
bb44:
  %t248 = load i64, ptr %l116, !tbaa !24
  %t249 = load i64, ptr %l118, !tbaa !24
  %t250 = icmp slt i64 %t248, %t249
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb45, label %bb46
bb45:
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t254 = load ptr, ptr %l18, !tbaa !29
  %t255 = load i64, ptr %l19, !tbaa !24
  %t258 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s5, ptr %s5, ptr %t254, i64 %t255)
  store { i64, ptr } %t258, ptr %l123
  br label %bb48
bb48:
  %t259 = load { i64, ptr }, ptr %l123, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l8, { i64, ptr } %t259)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t263 = load i64, ptr %l19, !tbaa !24
  %t266 = add i64 %t263, 1
  store i64 %t266, ptr %l19, !tbaa !24
  br label %bb43
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t268 = load i64, ptr %l10, !tbaa !24
  %t271 = add i64 %t268, 1
  store i64 %t271, ptr %l10, !tbaa !24
  br label %bb20
bb53:
  %t274 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t274, ptr %l133
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t275 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t275, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l10 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l20 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l38 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca { i64, [3 x i64] }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t119 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t4)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l7
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb6
bb6:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t21, ptr %l12
  br label %bb7
bb7:
  %t22 = load i1, ptr %l12, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = call ptr @__olang_scope_hold(ptr %v0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l15, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e15
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = call ptr @__olang_scope_hold(ptr %v0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l20, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e15
  br i1 %t31, label %bb12, label %bb13
bb10:
  %t33 = call ptr @__olang_region_make(ptr %v0)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb11
bb11:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = load i64, ptr %l15
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = call ptr @__olang_held_alloc(ptr %t40, i64 %t38)
  call void @olang_textcopy(ptr %t41, ptr %t37, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l14, !tbaa !27
  br label %bb14
bb12:
  %t46 = call ptr @__olang_region_make(ptr %v0)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = load i64, ptr %l20
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t53, i64 %t54)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l14, !tbaa !27
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 15
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l26, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t66 = load ptr, ptr %l10, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t66, i32 0, i32 15
  store { i64, ptr } %t65, ptr %t67, !tbaa !27
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e15
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = load { i64, ptr }, ptr %l26
  %t71 = extractvalue { i64, ptr } %t70, 1
  call void @__olang_region_release(ptr %t71)
  store { i64, ptr } zeroinitializer, ptr %l26
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l28, !tbaa !29
  %t73 = call ptr @__olang_scope_hold(ptr %v0)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l29, !tbaa !24
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e16
  br i1 %t75, label %bb17, label %bb18
bb17:
  %t77 = call ptr @__olang_region_make(ptr %v0)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l29, !tbaa !24
  br label %bb18
bb18:
  %t79 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t80 = extractvalue { i32, { i64, ptr } } %t79, 1
  %t81 = extractvalue { i32, { i64, ptr } } %t79, 0
  store i32 %t81, ptr %l33
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb20, label %ok.83, !prof !99
ok.83:
  store { i64, ptr } %t80, ptr %l32
  br label %bb19
bb19:
  %t84 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t84, ptr %l31, !tbaa !27
  br label %bb24
bb20:
  %t85 = load i32, ptr %l33, !tbaa !23
  %t86 = ashr i32 %t85, 16
  %t88 = icmp eq i32 %t86, 1
  br i1 %t88, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l31, !tbaa !27
  br label %bb24
bb24:
  %t90 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = load i64, ptr %l29
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call ptr @__olang_held_alloc(ptr %t94, i64 %t92)
  call void @olang_textcopy(ptr %t95, ptr %t91, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = load ptr, ptr %l28, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t99, i32 0, i32 16
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l38, !tbaa !27
  %t103 = load ptr, ptr %l28, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t103, i32 0, i32 16
  store { i64, ptr } %t97, ptr %t104, !tbaa !27
  %t105 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e16
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t107 = load { i64, ptr }, ptr %l38
  %t108 = extractvalue { i64, ptr } %t107, 1
  call void @__olang_region_release(ptr %t108)
  store { i64, ptr } zeroinitializer, ptr %l38
  br label %bb26
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %t109)
  br label %bb27
bb27:
  %t111 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t113 = call i1 @std_2fos_2eIsDir(ptr %v1, { i64, ptr } %t111)
  store i1 %t113, ptr %l42
  br label %bb28
bb28:
  %t114 = load i1, ptr %l42, !tbaa !21
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 4
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l44, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 0
  store i64 0, ptr %t120
  %t121 = load { i64, [3 x i64] }, ptr %t119
  store { i64, [3 x i64] } %t121, ptr %l45
  %t122 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
  store %"compiler/diagmsg:Msg" %t122, ptr %l46
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t123 = load ptr, ptr %l44, !tbaa !29
  %t124 = load { i64, [3 x i64] }, ptr %l45
  %t125 = load %"compiler/diagmsg:Msg", ptr %l46
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v0, ptr %t123, { i64, [3 x i64] } %t124, %"compiler/diagmsg:Msg" %t125)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l48, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l49, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t129, ptr %l50, !tbaa !27
  %t130 = call ptr @__olang_scope_hold(ptr %v0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l51, !tbaa !24
  %t132 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e2
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = call ptr @__olang_region_make(ptr %v0)
  %t135 = ptrtoint ptr %t134 to i64
  store i64 %t135, ptr %l51, !tbaa !24
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t138 = load i64, ptr %l51
  %t139 = inttoptr i64 %t138 to ptr
  %t142 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %t139, ptr %t136, { i64, ptr } %t137)
  store { i64, ptr } %t142, ptr %l55
  br label %bb36
bb36:
  %t143 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t144 = load ptr, ptr %l49, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t147 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t144, { i64, ptr } %t145, { i64, ptr } %t143, i1 false, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i64 %t147, ptr %l57
  br label %bb37
bb37:
  %t148 = load i64, ptr %l57, !tbaa !24
  %t149 = load ptr, ptr %l48, !tbaa !29
  %t150 = getelementptr %"compiler/load:Loader", ptr %t149, i32 0, i32 12
  store i64 %t148, ptr %t150, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t151)
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 12
  %t156 = load i64, ptr %t155, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t156, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [2 x { i64, ptr }]
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca [2 x { i64, ptr }]
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/scan:Tokens"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i32
  %l74 = alloca i1
  %l78 = alloca %"compiler/scan:Tokens"
  %l81 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca i64
  %l89 = alloca { i64, ptr }
  %l100 = alloca i64
  %l102 = alloca i64
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t4, 0
  %t7 = insertvalue [2 x { i64, ptr }] %t6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t7, ptr %l1
  %t10 = insertvalue { i64, ptr } undef, i64 2, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %l1, 1
  %t13 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t11)
  store { i64, ptr } %t13, ptr %l27
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t15)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l31
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb3, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l30
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t22, ptr %l28, !tbaa !27
  br label %bb7
bb3:
  %t23 = load i32, ptr %l31, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l33, !tbaa !21
  %t27 = load i32, ptr %l31, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  br i1 %t30, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l36
  br label %bb8
bb8:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l4
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t49, ptr %l44, !tbaa !27
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %t53, i64 %t50
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !37
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t60 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t57, 0
  %t62 = insertvalue [2 x { i64, ptr }] %t60, { i64, ptr } %t58, 1
  store [2 x { i64, ptr }] %t62, ptr %l9
  %t65 = insertvalue { i64, ptr } undef, i64 2, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %l9, 1
  %t68 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %v0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l52
  br label %bb13
bb13:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t69, ptr %lp10
  %t70 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t71 = load ptr, ptr %lp10
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t72, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t74, ptr %l54
  br label %bb14
bb14:
  %t75 = load i1, ptr %l54, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %lp10
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %l4, { i64, ptr } %t77)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  store ptr %l4, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load i64, ptr %l12, !tbaa !24
  store i64 %t86, ptr %l61, !tbaa !24
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l63
  br label %bb22
bb22:
  %t90 = load i64, ptr %l61, !tbaa !24
  %t91 = load i64, ptr %l63, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb24:
  br label %bb25
bb25:
  %t96 = load ptr, ptr %l11, !tbaa !29
  %t97 = load i64, ptr %l12, !tbaa !24
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  store { i64, ptr } %t100, ptr %l68
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t104 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v0, { i64, ptr } %t101)
  %t105 = extractvalue { i32, { i64, ptr } } %t104, 1
  %t106 = extractvalue { i32, { i64, ptr } } %t104, 0
  store i32 %t106, ptr %l72
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb28, label %ok.108, !prof !99
ok.108:
  store { i64, ptr } %t105, ptr %l71
  br label %bb27
bb27:
  %t109 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t109, ptr %l69, !tbaa !27
  br label %bb32
bb28:
  %t110 = load i32, ptr %l72, !tbaa !23
  %t111 = ashr i32 %t110, 16
  %t113 = icmp eq i32 %t111, 1
  store i1 %t113, ptr %l74, !tbaa !21
  %t114 = load i32, ptr %l72, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  br i1 %t117, label %bb29, label %bb30
bb29:
  call void @__olang_errpay_pop()
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb32:
  %t119 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t119, ptr %l14, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t122 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %s7, { i64, ptr } %t120)
  store %"compiler/scan:Tokens" %t122, ptr %l78
  br label %bb33
bb33:
  %t123 = load %"compiler/scan:Tokens", ptr %l78
  store %"compiler/scan:Tokens" %t123, ptr %l15
  %t124 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t127 = call ptr @compiler_2fload_2etypeNames(ptr %v0, ptr %s7, ptr %v0, { i64, ptr } %t124, ptr %l15)
  store ptr %t127, ptr %l81
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l81, !tbaa !29
  store ptr %t128, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb35
bb35:
  %t129 = load i64, ptr %l17, !tbaa !24
  store i64 %t129, ptr %l82, !tbaa !24
  %t130 = load ptr, ptr %l16, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l84
  br label %bb36
bb36:
  %t133 = load i64, ptr %l82, !tbaa !24
  %t134 = load i64, ptr %l84, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l16, !tbaa !29
  %t140 = load i64, ptr %l17, !tbaa !24
  %t143 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t139, i64 %t140)
  store { i64, ptr } %t143, ptr %l89
  br label %bb40
bb40:
  %t144 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/load:Loader", ptr %t145, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t147, { i64, ptr } %t144)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t151 = load i64, ptr %l17, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l17, !tbaa !24
  br label %bb35
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l12, !tbaa !24
  br label %bb21
bb45:
  store ptr %l4, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb46:
  %t162 = load i64, ptr %l20, !tbaa !24
  store i64 %t162, ptr %l100, !tbaa !24
  %t163 = load ptr, ptr %l19, !tbaa !29
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l102
  br label %bb47
bb47:
  %t166 = load i64, ptr %l100, !tbaa !24
  %t167 = load i64, ptr %l102, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb48, label %bb49
bb48:
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t172 = load ptr, ptr %l19, !tbaa !29
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l107
  br label %bb51
bb51:
  %t177 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t177, ptr %l21, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l108, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t179, ptr %l109, !tbaa !27
  %t180 = call ptr @__olang_scope_hold(ptr %v0)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l110, !tbaa !24
  %t182 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e2
  br i1 %t182, label %bb52, label %bb53
bb52:
  %t184 = call ptr @__olang_region_make(ptr %v0)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l110, !tbaa !24
  br label %bb53
bb53:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t188 = load i64, ptr %l110
  %t189 = inttoptr i64 %t188 to ptr
  %t192 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v0, ptr %t189, ptr %t186, { i64, ptr } %t187)
  store { i64, ptr } %t192, ptr %l114
  br label %bb54
bb54:
  %t193 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t194 = load ptr, ptr %l108, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t197 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t194, { i64, ptr } %t195, { i64, ptr } %t193, i1 true, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i64 %t197, ptr %l116
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t198 = load i64, ptr %l20, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l20, !tbaa !24
  br label %bb46
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eaddLink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca [2 x { i64, ptr }]
  %l12 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l75 = alloca { i64, [3 x i64] }
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i64
  %l83 = alloca i1
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t157 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 6
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_d2a36b1a0f33f2c5_8bb351bc5bea8f1)
  unreachable
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 6
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t22 = getelementptr %"compiler/source:Source", ptr %t19, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = sub i64 %t33, 1
  store i64 %t35, ptr %l25, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c887c5acf0277416_b8456d2f32e25a62)
  unreachable
bb7:
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c887c5acf0277416_b8456d2f32e25a62)
  unreachable
bb9:
  %t49 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l22, !tbaa !24
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = getelementptr i8, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t59, ptr %lp7
  %t61 = load ptr, ptr %lp7
  store { i64, ptr } %t58, ptr %t61, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = call i1 @compiler_2fload_2eLinkIsFile(ptr %v0, { i64, ptr } %t62)
  store i1 %t64, ptr %l34
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c887c5acf0277416_b8456d2f32e25a62)
  unreachable
bb11:
  %t65 = load i1, ptr %l34, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t66 = call ptr @__olang_scope_hold(ptr %v2)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l35, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t68, label %bb14, label %bb15
bb13:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call i1 @compiler_2fload_2eLinkName(ptr %v0, { i64, ptr } %t70)
  store i1 %t72, ptr %l57
  br label %bb28
bb14:
  %t73 = call ptr @__olang_region_make(ptr %v2)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = call i1 @std_2ffilepath_2eIsAbs(ptr %v0, { i64, ptr } %t75)
  store i1 %t77, ptr %l38
  br label %bb16
bb16:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t79, ptr %l39, !tbaa !27
  br label %bb21
bb18:
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s1, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l43
  br label %bb19
bb19:
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t89 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t88, 0
  %t91 = insertvalue [2 x { i64, ptr }] %t89, { i64, ptr } %t87, 1
  store [2 x { i64, ptr }] %t91, ptr %l8
  %t94 = insertvalue { i64, ptr } undef, i64 2, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %l8, 1
  %t97 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %v0, { i64, ptr } %t95)
  store { i64, ptr } %t97, ptr %l48
  br label %bb20
bb20:
  %t98 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l39, !tbaa !27
  br label %bb21
bb21:
  %t106 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = load i64, ptr %l35
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_held_alloc(ptr %t110, i64 %t108)
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l50, !tbaa !27
  %t114 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t119 = icmp eq i64 %t117, 0
  br i1 %t119, label %bb24, label %bb25
bb23:
  %t121 = load ptr, ptr %lp7
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l54, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t124 = load ptr, ptr %lp7
  store { i64, ptr } %t123, ptr %t124, !tbaa !27
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t125, label %bb26, label %bb27
bb24:
  store { i64, ptr } zeroinitializer, ptr %l50, !tbaa !27
  br label %bb25
bb25:
  %t127 = load i64, ptr %l35
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = load { i64, ptr }, ptr %l50
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr null
  call void @__olang_region_settle_in(ptr %t128, ptr %t133)
  br label %bb23
bb26:
  %t134 = load { i64, ptr }, ptr %l54
  %t135 = extractvalue { i64, ptr } %t134, 1
  call void @__olang_region_release(ptr %t135)
  store { i64, ptr } zeroinitializer, ptr %l54
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb28:
  %t136 = load i1, ptr %l57, !tbaa !21
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t137 = call ptr @__olang_scope_hold(ptr %v2)
  %t138 = ptrtoint ptr %t137 to i64
  store i64 %t138, ptr %l58, !tbaa !24
  %t139 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t139, label %bb31, label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 4
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l68, !tbaa !29
  %t145 = load ptr, ptr %l5, !tbaa !29
  %t147 = getelementptr %"compiler/load:Module", ptr %t145, i32 0, i32 4
  %t148 = load i64, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t150 = load i32, ptr %t149, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t153 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t160 = insertvalue { i64, i64, i64 } undef, i64 %t148, 0
  %t162 = insertvalue { i64, i64, i64 } %t160, i64 %t152, 1
  %t164 = insertvalue { i64, i64, i64 } %t162, i64 %t156, 2
  %t165 = getelementptr { i64, [3 x i64] }, ptr %t157, i32 0, i32 1
  store { i64, i64, i64 } %t164, ptr %t165
  %t166 = load { i64, [3 x i64] }, ptr %t157
  store { i64, [3 x i64] } %t166, ptr %l75
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s6, { i64, ptr } %t167)
  store { i64, ptr } %t169, ptr %l77
  br label %bb39
bb31:
  %t170 = call ptr @__olang_region_make(ptr %v2)
  %t171 = ptrtoint ptr %t170 to i64
  store i64 %t171, ptr %l58, !tbaa !24
  br label %bb32
bb32:
  %t172 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = load i64, ptr %l58
  %t180 = inttoptr i64 %t179 to ptr
  %t181 = call ptr @__olang_held_alloc(ptr %t180, i64 %t178)
  call void @olang_textcopy(ptr %t181, ptr %t173, i64 %t174)
  %t182 = getelementptr i8, ptr %t181, i64 %t174
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  store { i64, ptr } %t184, ptr %l61, !tbaa !27
  %t185 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t185, label %bb33, label %bb34
bb33:
  %t187 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t190 = icmp eq i64 %t188, 0
  br i1 %t190, label %bb35, label %bb36
bb34:
  %t192 = load ptr, ptr %lp7
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l65, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t195 = load ptr, ptr %lp7
  store { i64, ptr } %t194, ptr %t195, !tbaa !27
  %t196 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7
  br i1 %t196, label %bb37, label %bb38
bb35:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb36
bb36:
  %t198 = load i64, ptr %l58
  %t199 = inttoptr i64 %t198 to ptr
  %t200 = load { i64, ptr }, ptr %l61
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr null
  call void @__olang_region_settle_in(ptr %t199, ptr %t204)
  br label %bb34
bb37:
  %t205 = load { i64, ptr }, ptr %l65
  %t206 = extractvalue { i64, ptr } %t205, 1
  call void @__olang_region_release(ptr %t206)
  store { i64, ptr } zeroinitializer, ptr %l65
  br label %bb38
bb38:
  br label %bb42
bb39:
  %t207 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t209 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkName(ptr %s6, ptr %v0, { i64, ptr } %t207)
  store %"compiler/diagmsg:Msg" %t209, ptr %l79
  br label %bb40
bb40:
  %t210 = load ptr, ptr %l68, !tbaa !29
  %t211 = load { i64, [3 x i64] }, ptr %l75
  %t212 = load %"compiler/diagmsg:Msg", ptr %l79
  %t213 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t210, { i64, [3 x i64] } %t211, %"compiler/diagmsg:Msg" %t212)
  store i64 %t213, ptr %l80
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb42:
  br label %bb43
bb43:
  %t214 = load ptr, ptr %l4, !tbaa !29
  %t215 = load ptr, ptr %lp7
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t219 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v2, ptr %v2, ptr %t214, { i64, ptr } %t216)
  store i1 %t219, ptr %l83
  br label %bb44
bb44:
  %t220 = load i1, ptr %l83, !tbaa !21
  br i1 %t220, label %bb45, label %bb46
bb45:
  br label %ret
bb46:
  br label %bb47
bb47:
  %t221 = load ptr, ptr %l4, !tbaa !29
  %t222 = load ptr, ptr %lp7
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v2, ptr %v2, ptr %t221, { i64, ptr } %t223, i1 true)
  br label %bb48
bb48:
  %t227 = load ptr, ptr %lp7
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v2, ptr %a3, { i64, ptr } %t228)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eafterBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_17616d64a992214_c045be96c2de0040)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/token:Token", ptr %t19, i64 %t16
  %t21 = getelementptr %"compiler/token:Token", ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 116}
  %t26 = trunc i64 10 to i32
  %t27 = icmp eq i32 %t22, %t26
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb6
bb5:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t3, i64 %a2)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/load:Module", ptr %t7, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t9, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 23
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchClose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l15 = alloca { i64, ptr }
  %l26 = alloca i32
  %l34 = alloca { i64, ptr }
  %l39 = alloca i1
  %l42 = alloca i1
  %l55 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_e6755cf0c7ea5c6a_c534e9e23f397d86)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/token:Token", ptr %t21, i64 %t18
  %t23 = getelementptr %"compiler/token:Token", ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 116}
  %t26 = trunc i64 114 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 7
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5079a6433cc29871_c7557f1318c6a06d)
  unreachable
bb7:
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 7
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t45 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t39, i32 %t42)
  store i32 %t45, ptr %l26
  br label %bb9
bb9:
  %t46 = load i32, ptr %l26, !tbaa !23
  %t47 = sext i32 %t46 to i64
  store i64 %t47, ptr %rv
  br label %ret
bb10:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t61, ptr %l34, !tbaa !27
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr %"compiler/token:Token", ptr %t65, i64 %t62
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i32 0, i32 0
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 116}
  store i32 %t68, ptr %l6
  %t70 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t72 = trunc i64 8 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb17
bb16:
  %t75 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t77 = trunc i64 10 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l39, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb20
bb19:
  %t81 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t83 = trunc i64 0 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t87 = load i64, ptr %l5, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t89 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t91 = trunc i64 114 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 7
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb26, label %bb27
bb25:
  br label %bb33
bb26:
  call void @__olang_check_failed(ptr @olang_loc_aae654c03cd30c7c_21b926dbd63a1158)
  unreachable
bb27:
  br label %bb28
bb28:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/load:Module", ptr %t101, i32 0, i32 7
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = trunc i64 %t105 to i32
  %t110 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t104, i32 %t107)
  store i32 %t110, ptr %l55
  br label %bb29
bb29:
  %t111 = load i32, ptr %l55, !tbaa !23
  %t112 = sext i32 %t111 to i64
  store i64 %t112, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp slt i64 %t114, 0
  br i1 %t116, label %bb30, label %bb31
bb30:
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  %t121 = load i64, ptr %l5, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l5, !tbaa !24
  br label %bb34
bb34:
  br label %bb11
bb35:
  %t126 = load i64, ptr %l3, !tbaa !24
  store i64 %t126, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ecImport(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/load:Import" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/load:Import"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %lp11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/bindgen:Translation"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"std/os:FileInfo"
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %lp38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca %"std/prelude/text:LineIter"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l51 = alloca ptr
  %l55 = alloca { i64, [3 x i64] }
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca i64
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l117 = alloca i1
  %l119 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l154 = alloca i64
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i1
  %l172 = alloca i1
  %l173 = alloca i1
  %l175 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca { i64, [3 x i64] }
  %l180 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca i64
  %l183 = alloca i64
  %l186 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l192 = alloca i64
  %l195 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l203 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i64
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l213 = alloca i64
  %l217 = alloca %"std/prelude/text:StringBuilder"
  %l226 = alloca i64
  %l228 = alloca i64
  %l233 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca i64
  %l251 = alloca ptr
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i64
  %l268 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l276 = alloca i1
  %l282 = alloca i1
  %l283 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l292 = alloca %"compiler/bindgen:Translation"
  %l294 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca { i64, [3 x i64] }
  %l301 = alloca %"compiler/diagmsg:Msg"
  %l302 = alloca i64
  %l304 = alloca ptr
  %l305 = alloca { i64, [3 x i64] }
  %l308 = alloca %"compiler/diagmsg:Msg"
  %l309 = alloca i64
  %l311 = alloca %"std/prelude/text:StringBuilder"
  %l313 = alloca i64
  %l315 = alloca i64
  %l320 = alloca { i64, ptr }
  %l321 = alloca %"std/os:FileInfo"
  %l323 = alloca %"std/os:FileInfo"
  %l324 = alloca i32
  %l326 = alloca i1
  %l339 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l343 = alloca i64
  %l349 = alloca i1
  %l350 = alloca { i64, ptr }
  %l360 = alloca i1
  %l362 = alloca i1
  %l368 = alloca i1
  %l370 = alloca i1
  %l371 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l378 = alloca i1
  %l381 = alloca ptr
  %l382 = alloca { i64, [3 x i64] }
  %l387 = alloca %"compiler/diagmsg:Msg"
  %l388 = alloca i64
  %l390 = alloca i64
  %l393 = alloca { i64, ptr }
  %l394 = alloca i64
  %l395 = alloca { i64, ptr }
  %l396 = alloca { i64, ptr }
  %l401 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca i32
  %l411 = alloca i64
  %l415 = alloca i64
  %l418 = alloca i64
  %l437 = alloca i1
  %l439 = alloca i1
  %l443 = alloca ptr
  %l447 = alloca i1
  %l454 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l455 = alloca ptr
  %l456 = alloca i64
  %l460 = alloca { i64, ptr }
  %l461 = alloca { i64, ptr }
  %l463 = alloca i64
  %l465 = alloca { i64, ptr }
  %l468 = alloca { i64, ptr }
  %l470 = alloca i64
  %l475 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l476 = alloca { i64, ptr }
  %l478 = alloca { i64, ptr }
  %l479 = alloca i32
  %l481 = alloca i1
  %l485 = alloca ptr
  %l487 = alloca ptr
  %l488 = alloca { i64, ptr }
  %l489 = alloca i64
  %l492 = alloca i64
  %l493 = alloca i32
  %l498 = alloca ptr
  %l502 = alloca i1
  %l503 = alloca i1
  %l504 = alloca %"std/os:FileInfo"
  %l508 = alloca %"std/os:FileInfo"
  %l509 = alloca i32
  %l511 = alloca i1
  %l515 = alloca %"std/os:FileInfo"
  %l518 = alloca ptr
  %l519 = alloca i64
  %l524 = alloca { i64, ptr }
  %l527 = alloca %"std/prelude/text:LineIter"
  %l528 = alloca { i64, ptr }
  %l530 = alloca { i64, ptr }
  %l531 = alloca i32
  %l533 = alloca i1
  %l535 = alloca i1
  %l536 = alloca { i64, ptr }
  %l539 = alloca i64
  %l540 = alloca i64
  %l545 = alloca { i64, ptr }
  %l550 = alloca ptr
  %l551 = alloca i64
  %l553 = alloca { i64, ptr }
  %l556 = alloca { i64, ptr }
  %l557 = alloca i64
  %l559 = alloca { i64, ptr }
  %l564 = alloca i1
  %l566 = alloca i1
  %l568 = alloca i1
  %l569 = alloca i64
  %l571 = alloca i64
  %l572 = alloca i32
  %l576 = alloca ptr
  %l577 = alloca i64
  %l579 = alloca { i64, ptr }
  %l580 = alloca i64
  %l581 = alloca i64
  %l587 = alloca { i64, ptr }
  %l588 = alloca i64
  %l590 = alloca { i64, ptr }
  %l592 = alloca i64
  %l595 = alloca i64
  %l596 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s67 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/load:Import" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l51
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l51, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 0
  %t12 = load %"compiler/source:Span", ptr %t11
  %t16 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t9, ptr %t10, %"compiler/source:Span" %t12)
  store { i64, [3 x i64] } %t16, ptr %l55
  br label %bb2
bb2:
  %t17 = load { i64, [3 x i64] }, ptr %l55
  store { i64, [3 x i64] } %t17, ptr %l4
  %t18 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t23, ptr %l58
  br label %bb3
bb3:
  %t24 = load i1, ptr %l58, !tbaa !21
  store i1 %t24, ptr %l6, !tbaa !21
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = call { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %s0, { i64, ptr } %t28)
  store { i64, ptr } %t30, ptr %l61
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t31, ptr %l7, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t34, ptr %l63
  br label %bb5
bb5:
  %t35 = load i1, ptr %l63, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb9
bb7:
  %t36 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t38, ptr %l66
  br label %bb8
bb8:
  %t39 = load i1, ptr %l66, !tbaa !21
  store i1 %t39, ptr %l64, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l64, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = call ptr @__olang_scope_hold(ptr %s0)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l68, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t43, label %bb12, label %bb13
bb11:
  %t45 = call ptr @__olang_scope_hold(ptr %s0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l76, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t47, label %bb19, label %bb20
bb12:
  %t49 = call ptr @__olang_region_make(ptr %s0)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l68, !tbaa !24
  br label %bb13
bb13:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t53 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s0, { i64, ptr } %t51)
  store { i64, ptr } %t53, ptr %l71
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = load i64, ptr %l68
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t55, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l72, !tbaa !27
  %t62 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t67 = icmp eq i64 %t65, 0
  br i1 %t67, label %bb17, label %bb18
bb16:
  %t69 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t69, ptr %l67, !tbaa !27
  br label %bb26
bb17:
  store { i64, ptr } zeroinitializer, ptr %l72, !tbaa !27
  br label %bb18
bb18:
  %t70 = load i64, ptr %l68
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = load { i64, ptr }, ptr %l72
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = call ptr @__olang_region_or(ptr %t73, ptr null)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t76)
  br label %bb16
bb19:
  %t77 = call ptr @__olang_region_make(ptr %s0)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l76, !tbaa !24
  br label %bb20
bb20:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = extractvalue { i64, ptr } %t79, 0
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t88 = extractvalue { i64, ptr } %t80, 1
  %t89 = extractvalue { i64, ptr } %t80, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  %t98 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s0, ptr %s0, { i64, ptr } %t95)
  store { i64, ptr } %t98, ptr %l82
  br label %bb21
bb21:
  %t99 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = load i64, ptr %l76
  %t103 = inttoptr i64 %t102 to ptr
  %t104 = call ptr @__olang_held_alloc(ptr %t103, i64 %t101)
  call void @olang_textcopy(ptr %t104, ptr %t100, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l83, !tbaa !27
  %t107 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t109 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb24, label %bb25
bb23:
  %t114 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t114, ptr %l67, !tbaa !27
  br label %bb26
bb24:
  store { i64, ptr } zeroinitializer, ptr %l83, !tbaa !27
  br label %bb25
bb25:
  %t115 = load i64, ptr %l76
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = load { i64, ptr }, ptr %l83
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = call ptr @__olang_region_or(ptr %t118, ptr null)
  %t120 = icmp ne ptr %t119, null
  %t121 = select i1 %t120, ptr %t119, ptr null
  call void @__olang_region_settle_in(ptr %t116, ptr %t121)
  br label %bb23
bb26:
  %t122 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t122, ptr %l8, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t125, ptr %l88
  br label %bb27
bb27:
  %t126 = load i1, ptr %l88, !tbaa !21
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t127 = call ptr @__olang_scope_hold(ptr %s0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l89, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t129, label %bb30, label %bb31
bb29:
  br label %bb38
bb30:
  %t131 = call ptr @__olang_region_make(ptr %s0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = load i64, ptr %l89
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call ptr @__olang_held_alloc(ptr %t138, i64 %t136)
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l92, !tbaa !27
  %t142 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t142, label %bb32, label %bb33
bb32:
  %t144 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t147 = icmp eq i64 %t145, 0
  br i1 %t147, label %bb34, label %bb35
bb33:
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t149, ptr %l96, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  %t151 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8
  br i1 %t151, label %bb36, label %bb37
bb34:
  store { i64, ptr } zeroinitializer, ptr %l92, !tbaa !27
  br label %bb35
bb35:
  %t153 = load i64, ptr %l89
  %t154 = inttoptr i64 %t153 to ptr
  %t155 = load { i64, ptr }, ptr %l92
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = icmp ne ptr %t157, null
  %t159 = select i1 %t158, ptr %t157, ptr null
  call void @__olang_region_settle_in(ptr %t154, ptr %t159)
  br label %bb33
bb36:
  %t160 = load { i64, ptr }, ptr %l96
  %t161 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release(ptr %t161)
  store { i64, ptr } zeroinitializer, ptr %l96
  br label %bb37
bb37:
  br label %bb38
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l98, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t162, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t164, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l102, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t167 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t167, ptr %lp11
  %t169 = load ptr, ptr %lp11
  store { i64, ptr } %t166, ptr %t169, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t172 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t170)
  store i1 %t172, ptr %l105
  br label %bb39
bb39:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb40, label %bb41
bb40:
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t176 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t174)
  store i1 %t176, ptr %l108
  br label %bb42
bb41:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb43
bb42:
  %t177 = load i1, ptr %l108, !tbaa !21
  %t178 = xor i1 %t177, true
  store i1 %t178, ptr %l106, !tbaa !21
  br label %bb43
bb43:
  %t180 = load i1, ptr %l106, !tbaa !21
  br i1 %t180, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t181 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t183 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s6, { i64, ptr } %t181)
  %t184 = extractvalue { i32, { i64, ptr } } %t183, 1
  %t185 = extractvalue { i32, { i64, ptr } } %t183, 0
  store i32 %t185, ptr %l113
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb47, label %ok.187, !prof !99
ok.187:
  store { i64, ptr } %t184, ptr %l112
  br label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s14
  %t188 = load i1, ptr %l6, !tbaa !21
  br i1 %t188, label %bb95, label %bb96
bb46:
  %t190 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t190, ptr %l110, !tbaa !27
  br label %bb51
bb47:
  %t191 = load i32, ptr %l113, !tbaa !23
  %t192 = ashr i32 %t191, 16
  %t194 = icmp eq i32 %t192, 1
  br i1 %t194, label %bb48, label %bb49
bb48:
  call void @__olang_errpay_pop()
  br label %bb49
bb49:
  br label %bb50
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l110, !tbaa !27
  br label %bb51
bb51:
  %t196 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t196, ptr %l12, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t197, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t199, ptr %l117
  br label %bb52
bb52:
  %t200 = load i1, ptr %l117, !tbaa !21
  %t201 = xor i1 %t200, true
  br i1 %t201, label %bb53, label %bb54
bb53:
  %t203 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 1
  %t206 = extractvalue { i64, ptr } %t203, 0
  %t207 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t205, i64 %t206)
  %t208 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l119, !tbaa !27
  br label %bb55
bb54:
  %t211 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = extractvalue { i64, ptr } %t211, 0
  %t215 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t213, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l119, !tbaa !27
  br label %bb55
bb55:
  %t219 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t219, ptr %l13, !tbaa !27
  %t220 = call ptr @__olang_scope_hold(ptr %s0)
  %t221 = ptrtoint ptr %t220 to i64
  store i64 %t221, ptr %l124, !tbaa !24
  %t222 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t224 = call ptr @__olang_region_make(ptr %s0)
  %t225 = ptrtoint ptr %t224 to i64
  store i64 %t225, ptr %l124, !tbaa !24
  br label %bb57
bb57:
  %t226 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t227 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t230 = extractvalue { i64, ptr } %t226, 1
  %t231 = extractvalue { i64, ptr } %t226, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = load i64, ptr %l124
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = call ptr @__olang_held_alloc(ptr %t237, i64 %t235)
  call void @olang_textcopy(ptr %t238, ptr %t227, i64 %t228)
  %t239 = getelementptr i8, ptr %t238, i64 %t228
  call void @olang_textcopy(ptr %t239, ptr %t230, i64 %t231)
  %t240 = getelementptr i8, ptr %t239, i64 %t231
  call void @olang_textcopy(ptr %t240, ptr %t233, i64 %t234)
  %t241 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t238, 1
  store { i64, ptr } %t242, ptr %l127, !tbaa !27
  %t243 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t243, label %bb58, label %bb59
bb58:
  %t245 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t248 = icmp eq i64 %t246, 0
  br i1 %t248, label %bb60, label %bb61
bb59:
  %t250 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t250, ptr %l131, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t251, ptr %l9, !tbaa !27
  %t252 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t252, label %bb62, label %bb63
bb60:
  store { i64, ptr } zeroinitializer, ptr %l127, !tbaa !27
  br label %bb61
bb61:
  %t254 = load i64, ptr %l124
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = load { i64, ptr }, ptr %l127
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = call ptr @__olang_region_or(ptr %t257, ptr null)
  %t259 = icmp ne ptr %t258, null
  %t260 = select i1 %t259, ptr %t258, ptr null
  call void @__olang_region_settle_in(ptr %t255, ptr %t260)
  br label %bb59
bb62:
  %t261 = load { i64, ptr }, ptr %l131
  %t262 = extractvalue { i64, ptr } %t261, 1
  call void @__olang_region_release(ptr %t262)
  store { i64, ptr } zeroinitializer, ptr %l131
  br label %bb63
bb63:
  %t263 = load i1, ptr %l6, !tbaa !21
  br i1 %t263, label %bb64, label %bb65
bb64:
  %t265 = call ptr @__olang_scope_hold(ptr %s0)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l134, !tbaa !24
  %t267 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e10
  br i1 %t267, label %bb66, label %bb67
bb65:
  br label %bb74
bb66:
  %t269 = call ptr @__olang_region_make(ptr %s0)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l134, !tbaa !24
  br label %bb67
bb67:
  %t271 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 1
  %t274 = extractvalue { i64, ptr } %t271, 0
  %t275 = load i64, ptr %l134
  %t276 = inttoptr i64 %t275 to ptr
  %t277 = call ptr @__olang_held_alloc(ptr %t276, i64 %t274)
  call void @olang_textcopy(ptr %t277, ptr %t273, i64 %t274)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l137, !tbaa !27
  %t280 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e10
  br i1 %t280, label %bb68, label %bb69
bb68:
  %t282 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  %t285 = icmp eq i64 %t283, 0
  br i1 %t285, label %bb70, label %bb71
bb69:
  %t287 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t287, ptr %l141, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t288, ptr %l10, !tbaa !27
  %t289 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e10
  br i1 %t289, label %bb72, label %bb73
bb70:
  store { i64, ptr } zeroinitializer, ptr %l137, !tbaa !27
  br label %bb71
bb71:
  %t291 = load i64, ptr %l134
  %t292 = inttoptr i64 %t291 to ptr
  %t293 = load { i64, ptr }, ptr %l137
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = call ptr @__olang_region_or(ptr %t294, ptr null)
  %t296 = icmp ne ptr %t295, null
  %t297 = select i1 %t296, ptr %t295, ptr null
  call void @__olang_region_settle_in(ptr %t292, ptr %t297)
  br label %bb69
bb72:
  %t298 = load { i64, ptr }, ptr %l141
  %t299 = extractvalue { i64, ptr } %t298, 1
  call void @__olang_region_release(ptr %t299)
  store { i64, ptr } zeroinitializer, ptr %l141
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t302 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s6, { i64, ptr } %t300, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t302, ptr %l144
  br label %bb75
bb75:
  %t303 = load i1, ptr %l144, !tbaa !21
  br i1 %t303, label %bb76, label %bb77
bb76:
  %t304 = call ptr @__olang_scope_hold(ptr %v0)
  %t305 = ptrtoint ptr %t304 to i64
  store i64 %t305, ptr %l146, !tbaa !24
  %t306 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t306, label %bb78, label %bb79
bb77:
  %t308 = call ptr @__olang_scope_hold(ptr %v0)
  %t309 = ptrtoint ptr %t308 to i64
  store i64 %t309, ptr %l154, !tbaa !24
  %t310 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t310, label %bb85, label %bb86
bb78:
  %t312 = call ptr @__olang_region_make(ptr %v0)
  %t313 = ptrtoint ptr %t312 to i64
  store i64 %t313, ptr %l146, !tbaa !24
  br label %bb79
bb79:
  %t314 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t316 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %s6, { i64, ptr } %t314)
  store { i64, ptr } %t316, ptr %l149
  br label %bb80
bb80:
  %t317 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = load i64, ptr %l146
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = call ptr @__olang_held_alloc(ptr %t321, i64 %t319)
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l150, !tbaa !27
  %t325 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t325, label %bb81, label %bb82
bb81:
  %t327 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 0
  %t330 = icmp eq i64 %t328, 0
  br i1 %t330, label %bb83, label %bb84
bb82:
  %t332 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t332, ptr %l145, !tbaa !27
  br label %bb92
bb83:
  store { i64, ptr } zeroinitializer, ptr %l150, !tbaa !27
  br label %bb84
bb84:
  %t333 = load i64, ptr %l146
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = load { i64, ptr }, ptr %l150
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = call ptr @__olang_region_or(ptr %t336, ptr null)
  %t338 = icmp ne ptr %t337, null
  %t339 = select i1 %t338, ptr %t337, ptr null
  call void @__olang_region_settle_in(ptr %t334, ptr %t339)
  br label %bb82
bb85:
  %t340 = call ptr @__olang_region_make(ptr %v0)
  %t341 = ptrtoint ptr %t340 to i64
  store i64 %t341, ptr %l154, !tbaa !24
  br label %bb86
bb86:
  %t342 = load ptr, ptr %l3, !tbaa !29
  %t344 = getelementptr %"compiler/load:Module", ptr %t342, i32 0, i32 2
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t349 = call { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %s6, { i64, ptr } %t345, { i64, ptr } %t346)
  store { i64, ptr } %t349, ptr %l159
  br label %bb87
bb87:
  %t350 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = load i64, ptr %l154
  %t354 = inttoptr i64 %t353 to ptr
  %t355 = call ptr @__olang_held_alloc(ptr %t354, i64 %t352)
  call void @olang_textcopy(ptr %t355, ptr %t351, i64 %t352)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  store { i64, ptr } %t357, ptr %l160, !tbaa !27
  %t358 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t358, label %bb88, label %bb89
bb88:
  %t360 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 0
  %t363 = icmp eq i64 %t361, 0
  br i1 %t363, label %bb90, label %bb91
bb89:
  %t365 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t365, ptr %l145, !tbaa !27
  br label %bb92
bb90:
  store { i64, ptr } zeroinitializer, ptr %l160, !tbaa !27
  br label %bb91
bb91:
  %t366 = load i64, ptr %l154
  %t367 = inttoptr i64 %t366 to ptr
  %t368 = load { i64, ptr }, ptr %l160
  %t369 = extractvalue { i64, ptr } %t368, 1
  %t370 = call ptr @__olang_region_or(ptr %t369, ptr null)
  %t371 = icmp ne ptr %t370, null
  %t372 = select i1 %t371, ptr %t370, ptr null
  call void @__olang_region_settle_in(ptr %t367, ptr %t372)
  br label %bb89
bb92:
  %t373 = load ptr, ptr %lp11
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l164, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t376 = load ptr, ptr %lp11
  store { i64, ptr } %t375, ptr %t376, !tbaa !27
  %t377 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t377, label %bb93, label %bb94
bb93:
  %t379 = load { i64, ptr }, ptr %l164
  %t380 = extractvalue { i64, ptr } %t379, 1
  call void @__olang_region_release(ptr %t380)
  store { i64, ptr } zeroinitializer, ptr %l164
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s6)
  br label %bb128
bb95:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb98
bb96:
  %t381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t383 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s14, { i64, ptr } %t381, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t383, ptr %l169
  br label %bb97
bb97:
  %t384 = load i1, ptr %l169, !tbaa !21
  store i1 %t384, ptr %l167, !tbaa !21
  br label %bb98
bb98:
  %t385 = load i1, ptr %l167, !tbaa !21
  br i1 %t385, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb102
bb100:
  %t386 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s14, { i64, ptr } %t386, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store i1 %t388, ptr %l172
  br label %bb101
bb101:
  %t389 = load i1, ptr %l172, !tbaa !21
  store i1 %t389, ptr %l170, !tbaa !21
  br label %bb102
bb102:
  %t390 = load i1, ptr %l170, !tbaa !21
  br i1 %t390, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb106
bb104:
  %t391 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t393 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s14, { i64, ptr } %t391, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store i1 %t393, ptr %l175
  br label %bb105
bb105:
  %t394 = load i1, ptr %l175, !tbaa !21
  store i1 %t394, ptr %l173, !tbaa !21
  br label %bb106
bb106:
  %t395 = load i1, ptr %l173, !tbaa !21
  br i1 %t395, label %bb107, label %bb108
bb107:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/load:Loader", ptr %t396, i32 0, i32 4
  %t399 = load ptr, ptr %t398, !tbaa !29
  store ptr %t399, ptr %l177, !tbaa !29
  %t400 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t400, ptr %l178
  %t401 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t403 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCFileNotFound(ptr %s0, ptr %v0, { i64, ptr } %t401)
  store %"compiler/diagmsg:Msg" %t403, ptr %l180
  br label %bb109
bb108:
  %t404 = call ptr @__olang_scope_hold(ptr %s0)
  %t405 = ptrtoint ptr %t404 to i64
  store i64 %t405, ptr %l183, !tbaa !24
  %t406 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t406, label %bb111, label %bb112
bb109:
  %t408 = load ptr, ptr %l177, !tbaa !29
  %t409 = load { i64, [3 x i64] }, ptr %l178
  %t410 = load %"compiler/diagmsg:Msg", ptr %l180
  %t411 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t408, { i64, [3 x i64] } %t409, %"compiler/diagmsg:Msg" %t410)
  store i64 %t411, ptr %l181
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb111:
  %t413 = call ptr @__olang_region_make(ptr %s0)
  %t414 = ptrtoint ptr %t413 to i64
  store i64 %t414, ptr %l183, !tbaa !24
  br label %bb112
bb112:
  %t415 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t416 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t419 = extractvalue { i64, ptr } %t415, 1
  %t420 = extractvalue { i64, ptr } %t415, 0
  %t421 = add i64 %t417, %t420
  %t422 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t424 = add i64 %t421, %t423
  %t425 = load i64, ptr %l183
  %t426 = inttoptr i64 %t425 to ptr
  %t427 = call ptr @__olang_held_alloc(ptr %t426, i64 %t424)
  call void @olang_textcopy(ptr %t427, ptr %t416, i64 %t417)
  %t428 = getelementptr i8, ptr %t427, i64 %t417
  call void @olang_textcopy(ptr %t428, ptr %t419, i64 %t420)
  %t429 = getelementptr i8, ptr %t428, i64 %t420
  call void @olang_textcopy(ptr %t429, ptr %t422, i64 %t423)
  %t430 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t427, 1
  store { i64, ptr } %t431, ptr %l186, !tbaa !27
  %t432 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t432, label %bb113, label %bb114
bb113:
  %t434 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 0
  %t437 = icmp eq i64 %t435, 0
  br i1 %t437, label %bb115, label %bb116
bb114:
  %t439 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t439, ptr %l190, !tbaa !27
  %t440 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t440, ptr %l9, !tbaa !27
  %t441 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9
  br i1 %t441, label %bb117, label %bb118
bb115:
  store { i64, ptr } zeroinitializer, ptr %l186, !tbaa !27
  br label %bb116
bb116:
  %t443 = load i64, ptr %l183
  %t444 = inttoptr i64 %t443 to ptr
  %t445 = load { i64, ptr }, ptr %l186
  %t446 = extractvalue { i64, ptr } %t445, 1
  %t447 = call ptr @__olang_region_or(ptr %t446, ptr null)
  %t448 = icmp ne ptr %t447, null
  %t449 = select i1 %t448, ptr %t447, ptr null
  call void @__olang_region_settle_in(ptr %t444, ptr %t449)
  br label %bb114
bb117:
  %t450 = load { i64, ptr }, ptr %l190
  %t451 = extractvalue { i64, ptr } %t450, 1
  call void @__olang_region_release(ptr %t451)
  store { i64, ptr } zeroinitializer, ptr %l190
  br label %bb118
bb118:
  %t452 = call ptr @__olang_scope_hold(ptr %v0)
  %t453 = ptrtoint ptr %t452 to i64
  store i64 %t453, ptr %l192, !tbaa !24
  %t454 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t454, label %bb119, label %bb120
bb119:
  %t456 = call ptr @__olang_region_make(ptr %v0)
  %t457 = ptrtoint ptr %t456 to i64
  store i64 %t457, ptr %l192, !tbaa !24
  br label %bb120
bb120:
  %t458 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t459 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t462 = extractvalue { i64, ptr } %t458, 1
  %t463 = extractvalue { i64, ptr } %t458, 0
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t468 = load i64, ptr %l192
  %t469 = inttoptr i64 %t468 to ptr
  %t470 = call ptr @__olang_held_alloc(ptr %t469, i64 %t467)
  call void @olang_textcopy(ptr %t470, ptr %t459, i64 %t460)
  %t471 = getelementptr i8, ptr %t470, i64 %t460
  call void @olang_textcopy(ptr %t471, ptr %t462, i64 %t463)
  %t472 = getelementptr i8, ptr %t471, i64 %t463
  call void @olang_textcopy(ptr %t472, ptr %t465, i64 %t466)
  %t473 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t470, 1
  store { i64, ptr } %t474, ptr %l195, !tbaa !27
  %t475 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t475, label %bb121, label %bb122
bb121:
  %t477 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 0
  %t480 = icmp eq i64 %t478, 0
  br i1 %t480, label %bb123, label %bb124
bb122:
  %t482 = load ptr, ptr %lp11
  %t483 = load { i64, ptr }, ptr %t482, !tbaa !27
  store { i64, ptr } %t483, ptr %l199, !tbaa !27
  %t484 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t485 = load ptr, ptr %lp11
  store { i64, ptr } %t484, ptr %t485, !tbaa !27
  %t486 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11
  br i1 %t486, label %bb125, label %bb126
bb123:
  store { i64, ptr } zeroinitializer, ptr %l195, !tbaa !27
  br label %bb124
bb124:
  %t488 = load i64, ptr %l192
  %t489 = inttoptr i64 %t488 to ptr
  %t490 = load { i64, ptr }, ptr %l195
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = call ptr @__olang_region_or(ptr %t491, ptr null)
  %t493 = icmp ne ptr %t492, null
  %t494 = select i1 %t493, ptr %t492, ptr null
  call void @__olang_region_settle_in(ptr %t489, ptr %t494)
  br label %bb122
bb125:
  %t495 = load { i64, ptr }, ptr %l199
  %t496 = extractvalue { i64, ptr } %t495, 1
  call void @__olang_region_release(ptr %t496)
  store { i64, ptr } zeroinitializer, ptr %l199
  br label %bb126
bb126:
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s14)
  br label %bb128
bb128:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/load:Loader", ptr %t497, i32 0, i32 20
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  %t502 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t500, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d112, i32 0, i32 1) })
  store i1 %t502, ptr %l203
  br label %bb129
bb129:
  %t503 = load i1, ptr %l203, !tbaa !21
  br i1 %t503, label %bb130, label %bb131
bb130:
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l204, !tbaa !29
  %t505 = call ptr @__olang_scope_hold(ptr %v0)
  %t506 = ptrtoint ptr %t505 to i64
  store i64 %t506, ptr %l205, !tbaa !24
  %t507 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e20
  br i1 %t507, label %bb132, label %bb133
bb131:
  br label %bb137
bb132:
  %t509 = call ptr @__olang_region_make(ptr %v0)
  %t510 = ptrtoint ptr %t509 to i64
  store i64 %t510, ptr %l205, !tbaa !24
  br label %bb133
bb133:
  %t511 = load i64, ptr %l205
  %t512 = inttoptr i64 %t511 to ptr
  %t513 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %t512)
  store { i64, ptr } %t513, ptr %l207
  br label %bb134
bb134:
  %t514 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t515 = load i64, ptr %l205
  %t516 = inttoptr i64 %t515 to ptr
  %t517 = extractvalue { i64, ptr } %t514, 0
  %t518 = extractvalue { i64, ptr } %t514, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_held_alloc(ptr %t516, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t523 = load ptr, ptr %l204, !tbaa !29
  %t524 = getelementptr %"compiler/load:Loader", ptr %t523, i32 0, i32 20
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l209, !tbaa !27
  %t527 = load ptr, ptr %l204, !tbaa !29
  %t528 = getelementptr %"compiler/load:Loader", ptr %t527, i32 0, i32 20
  store { i64, ptr } %t522, ptr %t528, !tbaa !27
  %t529 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e20
  br i1 %t529, label %bb135, label %bb136
bb135:
  %t531 = load { i64, ptr }, ptr %l209
  %t532 = extractvalue { i64, ptr } %t531, 1
  call void @__olang_region_release(ptr %t532)
  store { i64, ptr } zeroinitializer, ptr %l209
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/load:Loader", ptr %t533, i32 0, i32 21
  %t537 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t535)
  store i64 %t537, ptr %l213
  br label %bb138
bb138:
  %t538 = load i64, ptr %l213, !tbaa !24
  %t539 = icmp eq i64 %t538, 0
  br i1 %t539, label %bb139, label %bb140
bb139:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/load:Loader", ptr %t541, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t543, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb142
bb142:
  %t545 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t545, ptr %l217
  br label %bb143
bb143:
  %t546 = load %"std/prelude/text:StringBuilder", ptr %l217
  store %"std/prelude/text:StringBuilder" %t546, ptr %l14
  %t547 = load { i64, ptr }, ptr @G_2ecompiler_2fload_2eCImportFormat, !tbaa !27
  %t548 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t549 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t547, 1
  %t552 = extractvalue { i64, ptr } %t547, 0
  %t553 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t555 = add i64 %t552, %t554
  %t557 = extractvalue { i64, ptr } %t548, 1
  %t558 = extractvalue { i64, ptr } %t548, 0
  %t559 = add i64 %t555, %t558
  %t560 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t562 = add i64 %t559, %t561
  %t564 = extractvalue { i64, ptr } %t549, 1
  %t565 = extractvalue { i64, ptr } %t549, 0
  %t566 = add i64 %t562, %t565
  %t567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t569 = add i64 %t566, %t568
  %t570 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t569)
  call void @olang_textcopy(ptr %t570, ptr %t551, i64 %t552)
  %t571 = getelementptr i8, ptr %t570, i64 %t552
  call void @olang_textcopy(ptr %t571, ptr %t553, i64 %t554)
  %t572 = getelementptr i8, ptr %t571, i64 %t554
  call void @olang_textcopy(ptr %t572, ptr %t557, i64 %t558)
  %t573 = getelementptr i8, ptr %t572, i64 %t558
  call void @olang_textcopy(ptr %t573, ptr %t560, i64 %t561)
  %t574 = getelementptr i8, ptr %t573, i64 %t561
  call void @olang_textcopy(ptr %t574, ptr %t564, i64 %t565)
  %t575 = getelementptr i8, ptr %t574, i64 %t565
  call void @olang_textcopy(ptr %t575, ptr %t567, i64 %t568)
  %t576 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t570, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t577)
  br label %bb144
bb144:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/load:Loader", ptr %t581, i32 0, i32 21
  store ptr %t583, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb145
bb145:
  store %olang.scope zeroinitializer, ptr %s23
  %t585 = load i64, ptr %l16, !tbaa !24
  store i64 %t585, ptr %l226, !tbaa !24
  %t586 = load ptr, ptr %l15, !tbaa !29
  %t588 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t586)
  store i64 %t588, ptr %l228
  br label %bb146
bb146:
  %t589 = load i64, ptr %l226, !tbaa !24
  %t590 = load i64, ptr %l228, !tbaa !24
  %t591 = icmp slt i64 %t589, %t590
  %t593 = xor i1 %t591, true
  br i1 %t593, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s23)
  br label %bb153
bb148:
  br label %bb149
bb149:
  %t595 = load ptr, ptr %l15, !tbaa !29
  %t596 = load i64, ptr %l16, !tbaa !24
  %t599 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t595, i64 %t596)
  store { i64, ptr } %t599, ptr %l233
  br label %bb150
bb150:
  %t600 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = extractvalue { i64, ptr } %t600, 0
  %t605 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t606 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t607 = add i64 %t604, %t606
  %t608 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t607)
  call void @olang_textcopy(ptr %t608, ptr %t603, i64 %t604)
  %t609 = getelementptr i8, ptr %t608, i64 %t604
  call void @olang_textcopy(ptr %t609, ptr %t605, i64 %t606)
  %t610 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t608, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l14, { i64, ptr } %t611)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s23)
  br label %bb152
bb152:
  %t615 = load i64, ptr %l16, !tbaa !24
  %t618 = add i64 %t615, 1
  store i64 %t618, ptr %l16, !tbaa !24
  br label %bb145
bb153:
  %t621 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l14)
  store { i64, ptr } %t621, ptr %l242
  br label %bb154
bb154:
  %t622 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t622, 0
  %t625 = extractvalue { i64, ptr } %t622, 1
  %t626 = mul i64 %t624, 1
  %t627 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t626)
  call void @llvm.memcpy.p0.p0.i64(ptr %t627, ptr %t625, i64 %t626, i1 false)
  %t628 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  %t631 = call { i64, ptr } @std_2fsha256_2eHex(ptr %s0, ptr %s0, { i64, ptr } %t629)
  store { i64, ptr } %t631, ptr %l245
  br label %bb155
bb155:
  %t632 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 0
  store i64 %t633, ptr %l246, !tbaa !24
  %t634 = icmp sge i64 0, 0
  br i1 %t634, label %bb156, label %bb157
bb156:
  %t636 = icmp sle i64 0, 12
  br i1 %t636, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @olang_loc_4449aa9d363b5b4e_4db0be62c6b6e3d2)
  unreachable
bb158:
  %t638 = load i64, ptr %l246, !tbaa !24
  %t639 = icmp sle i64 12, %t638
  br i1 %t639, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @olang_loc_4449aa9d363b5b4e_4db0be62c6b6e3d2)
  unreachable
bb160:
  %t641 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr i8, ptr %t642, i64 0
  %t644 = sub i64 12, 0
  %t645 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t643, 1
  store { i64, ptr } %t646, ptr %l18, !tbaa !27
  store ptr %l14, ptr %l251, !tbaa !29
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/load:Loader", ptr %t648, i32 0, i32 20
  %t651 = load { i64, ptr }, ptr %t650, !tbaa !27
  %t653 = call { i64, ptr } @compiler_2fload_2efileStamp(ptr %v0, ptr %s0, { i64, ptr } %t651)
  store { i64, ptr } %t653, ptr %l254
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_4449aa9d363b5b4e_4db0be62c6b6e3d2)
  unreachable
bb162:
  %t654 = call { i64, ptr } @compiler_2fload_2efileStamp(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store { i64, ptr } %t654, ptr %l255
  br label %bb163
bb163:
  %t655 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t655, 1
  %t657 = extractvalue { i64, ptr } %t655, 0
  %t658 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t660 = add i64 %t657, %t659
  %t661 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 1
  %t663 = extractvalue { i64, ptr } %t661, 0
  %t664 = add i64 %t660, %t663
  %t665 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t666 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t667 = add i64 %t664, %t666
  %t668 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t667)
  call void @olang_textcopy(ptr %t668, ptr %t656, i64 %t657)
  %t669 = getelementptr i8, ptr %t668, i64 %t657
  call void @olang_textcopy(ptr %t669, ptr %t658, i64 %t659)
  %t670 = getelementptr i8, ptr %t669, i64 %t659
  call void @olang_textcopy(ptr %t670, ptr %t662, i64 %t663)
  %t671 = getelementptr i8, ptr %t670, i64 %t663
  call void @olang_textcopy(ptr %t671, ptr %t665, i64 %t666)
  %t672 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t673 = insertvalue { i64, ptr } %t672, ptr %t668, 1
  %t675 = load ptr, ptr %l251, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t675, { i64, ptr } %t673)
  br label %bb164
bb164:
  %t678 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l14)
  store { i64, ptr } %t678, ptr %l259
  br label %bb165
bb165:
  %t679 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = extractvalue { i64, ptr } %t679, 1
  %t683 = mul i64 %t681, 1
  %t684 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t684, ptr %t682, i64 %t683, i1 false)
  %t685 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  %t688 = call { i64, ptr } @std_2fsha256_2eHex(ptr %s0, ptr %s0, { i64, ptr } %t686)
  store { i64, ptr } %t688, ptr %l262
  br label %bb166
bb166:
  %t689 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t690 = extractvalue { i64, ptr } %t689, 0
  store i64 %t690, ptr %l263, !tbaa !24
  %t691 = icmp sge i64 0, 0
  br i1 %t691, label %bb167, label %bb168
bb167:
  %t693 = icmp sle i64 0, 32
  br i1 %t693, label %bb169, label %bb170
bb168:
  call void @__olang_check_failed(ptr @olang_loc_7c6f8f6ffdbdf94b_ce4c5ade044a53cf)
  unreachable
bb169:
  %t695 = load i64, ptr %l263, !tbaa !24
  %t696 = icmp sle i64 32, %t695
  br i1 %t696, label %bb171, label %bb172
bb170:
  call void @__olang_check_failed(ptr @olang_loc_7c6f8f6ffdbdf94b_ce4c5ade044a53cf)
  unreachable
bb171:
  %t698 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr i8, ptr %t699, i64 0
  %t701 = sub i64 32, 0
  %t702 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t700, 1
  store { i64, ptr } %t703, ptr %l19, !tbaa !27
  %t705 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %s0)
  store { i64, ptr } %t705, ptr %l268
  br label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_7c6f8f6ffdbdf94b_ce4c5ade044a53cf)
  unreachable
bb173:
  %t706 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t710 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t711 = add i64 %t708, %t710
  %t712 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t711)
  call void @olang_textcopy(ptr %t712, ptr %t707, i64 %t708)
  %t713 = getelementptr i8, ptr %t712, i64 %t708
  call void @olang_textcopy(ptr %t713, ptr %t709, i64 %t710)
  %t714 = insertvalue { i64, ptr } undef, i64 %t711, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t712, 1
  store { i64, ptr } %t715, ptr %l20, !tbaa !27
  %t717 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t718 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t717, 1
  %t721 = extractvalue { i64, ptr } %t717, 0
  %t722 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t723 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t724 = add i64 %t721, %t723
  %t726 = extractvalue { i64, ptr } %t718, 1
  %t727 = extractvalue { i64, ptr } %t718, 0
  %t728 = add i64 %t724, %t727
  %t729 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t728)
  call void @olang_textcopy(ptr %t729, ptr %t720, i64 %t721)
  %t730 = getelementptr i8, ptr %t729, i64 %t721
  call void @olang_textcopy(ptr %t730, ptr %t722, i64 %t723)
  %t731 = getelementptr i8, ptr %t730, i64 %t723
  call void @olang_textcopy(ptr %t731, ptr %t726, i64 %t727)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t729, 1
  store { i64, ptr } %t733, ptr %l21, !tbaa !27
  %t735 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t737 = call { i64, ptr } @compiler_2fload_2ecachedTranslation(ptr %s0, ptr %s0, { i64, ptr } %t735)
  store { i64, ptr } %t737, ptr %l274
  br label %bb174
bb174:
  %t738 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t738, ptr %l22, !tbaa !27
  %t739 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t741 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t739, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store i1 %t741, ptr %l276
  br label %bb175
bb175:
  %t742 = load i1, ptr %l276, !tbaa !21
  %t743 = xor i1 %t742, true
  br i1 %t743, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s29
  %t745 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t745, 1
  %t748 = extractvalue { i64, ptr } %t745, 0
  %t749 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t751 = add i64 %t748, %t750
  %t752 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t751)
  call void @olang_textcopy(ptr %t752, ptr %t747, i64 %t748)
  %t753 = getelementptr i8, ptr %t752, i64 %t748
  call void @olang_textcopy(ptr %t753, ptr %t749, i64 %t750)
  %t754 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t755 = insertvalue { i64, ptr } %t754, ptr %t752, 1
  call void @compiler_2fbuild_2eTouch(ptr %s29, { i64, ptr } %t755)
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s29)
  br label %bb179
bb179:
  %t758 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t760 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t758, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t760, ptr %l282
  br label %bb180
bb180:
  %t761 = load i1, ptr %l282, !tbaa !21
  br i1 %t761, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s31
  %t762 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t762, ptr %l283, !tbaa !27
  %t763 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t763, ptr %l284, !tbaa !27
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t766 = getelementptr %"compiler/load:Loader", ptr %t764, i32 0, i32 20
  %t767 = load { i64, ptr }, ptr %t766, !tbaa !27
  store { i64, ptr } %t767, ptr %l286, !tbaa !27
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t770 = getelementptr %"compiler/load:Loader", ptr %t768, i32 0, i32 21
  %t772 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t770)
  store { i64, ptr } %t772, ptr %l289
  br label %bb183
bb182:
  br label %bb246
bb183:
  %t773 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t774 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t775 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t776 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t777 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t778 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t781 = call %"compiler/bindgen:Translation" @compiler_2fbindgen_2eTranslation_2eTranslate(ptr %s0, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %v1, ptr %s31, { i64, ptr } %t775, { i64, ptr } %t776, { i64, ptr } %t777, { i64, ptr } %t778, { i64, ptr } %t773, { i64, ptr } %t774)
  store %"compiler/bindgen:Translation" %t781, ptr %l292
  br label %bb184
bb184:
  %t782 = load %"compiler/bindgen:Translation", ptr %l292
  store %"compiler/bindgen:Translation" %t782, ptr %l23
  %t783 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 3
  %t784 = load { i64, ptr }, ptr %t783, !tbaa !27
  %t786 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s31, { i64, ptr } %t784, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t786, ptr %l294
  br label %bb185
bb185:
  %t787 = load i1, ptr %l294, !tbaa !21
  %t788 = xor i1 %t787, true
  br i1 %t788, label %bb186, label %bb187
bb186:
  %t790 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 4
  %t791 = load i1, ptr %t790, !tbaa !21
  br i1 %t791, label %bb188, label %bb189
bb187:
  br label %bb195
bb188:
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t795 = getelementptr %"compiler/load:Loader", ptr %t793, i32 0, i32 4
  %t796 = load ptr, ptr %t795, !tbaa !29
  store ptr %t796, ptr %l298, !tbaa !29
  %t797 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t797, ptr %l299
  %t798 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t800 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCHeaderNotFound(ptr %v1, ptr %v0, { i64, ptr } %t798)
  store %"compiler/diagmsg:Msg" %t800, ptr %l301
  br label %bb190
bb189:
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/load:Loader", ptr %t801, i32 0, i32 4
  %t804 = load ptr, ptr %t803, !tbaa !29
  store ptr %t804, ptr %l304, !tbaa !29
  %t805 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t805, ptr %l305
  %t806 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t807 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 3
  %t808 = load { i64, ptr }, ptr %t807, !tbaa !27
  %t811 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCImportFailed(ptr %v1, ptr %s31, ptr %v0, { i64, ptr } %t806, { i64, ptr } %t808)
  store %"compiler/diagmsg:Msg" %t811, ptr %l308
  br label %bb192
bb190:
  %t812 = load ptr, ptr %l298, !tbaa !29
  %t813 = load { i64, [3 x i64] }, ptr %l299
  %t814 = load %"compiler/diagmsg:Msg", ptr %l301
  %t815 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t812, { i64, [3 x i64] } %t813, %"compiler/diagmsg:Msg" %t814)
  store i64 %t815, ptr %l302
  br label %bb191
bb191:
  br label %bb194
bb192:
  %t816 = load ptr, ptr %l304, !tbaa !29
  %t817 = load { i64, [3 x i64] }, ptr %l305
  %t818 = load %"compiler/diagmsg:Msg", ptr %l308
  %t819 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t816, { i64, [3 x i64] } %t817, %"compiler/diagmsg:Msg" %t818)
  store i64 %t819, ptr %l309
  br label %bb193
bb193:
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb195:
  %t821 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s31)
  store %"std/prelude/text:StringBuilder" %t821, ptr %l311
  br label %bb196
bb196:
  %t822 = load %"std/prelude/text:StringBuilder", ptr %l311
  store %"std/prelude/text:StringBuilder" %t822, ptr %l24
  %t823 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 2
  store ptr %t823, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb197
bb197:
  store %olang.scope zeroinitializer, ptr %s36
  %t825 = load i64, ptr %l26, !tbaa !24
  store i64 %t825, ptr %l313, !tbaa !24
  %t826 = load ptr, ptr %l25, !tbaa !29
  %t828 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s31, ptr %t826)
  store i64 %t828, ptr %l315
  br label %bb198
bb198:
  %t829 = load i64, ptr %l313, !tbaa !24
  %t830 = load i64, ptr %l315, !tbaa !24
  %t831 = icmp slt i64 %t829, %t830
  %t833 = xor i1 %t831, true
  br i1 %t833, label %bb199, label %bb200
bb199:
  call void @__olang_scope_close(ptr %s36)
  br label %bb211
bb200:
  br label %bb201
bb201:
  %t835 = load ptr, ptr %l25, !tbaa !29
  %t836 = load i64, ptr %l26, !tbaa !24
  %t839 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s31, ptr %s31, ptr %t835, i64 %t836)
  store { i64, ptr } %t839, ptr %l320
  br label %bb202
bb202:
  %t840 = load { i64, ptr }, ptr %l320, !tbaa !27
  store { i64, ptr } %t840, ptr %l27, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t843 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s31, { i64, ptr } %t841)
  %t844 = extractvalue { i32, %"std/os:FileInfo" } %t843, 1
  %t845 = extractvalue { i32, %"std/os:FileInfo" } %t843, 0
  store i32 %t845, ptr %l324
  %t846 = icmp ne i32 %t845, 0
  br i1 %t846, label %bb204, label %ok.847, !prof !99
ok.847:
  store %"std/os:FileInfo" %t844, ptr %l323
  br label %bb203
bb203:
  %t848 = load %"std/os:FileInfo", ptr %l323
  store %"std/os:FileInfo" %t848, ptr %l321
  br label %bb208
bb204:
  %t849 = load i32, ptr %l324, !tbaa !23
  %t850 = ashr i32 %t849, 16
  %t852 = icmp eq i32 %t850, 1
  store i1 %t852, ptr %l326, !tbaa !21
  %t853 = load i32, ptr %l324, !tbaa !23
  %t854 = ashr i32 %t853, 16
  %t856 = icmp eq i32 %t854, 1
  br i1 %t856, label %bb205, label %bb206
bb205:
  call void @__olang_errpay_pop()
  br label %bb206
bb206:
  br label %bb207
bb207:
  call void @__olang_scope_close(ptr %s36)
  br label %bb210
bb208:
  %t858 = load %"std/os:FileInfo", ptr %l321
  store %"std/os:FileInfo" %t858, ptr %l28
  %t859 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 1
  %t860 = load i64, ptr %t859, !tbaa !24
  %t861 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 2
  %t862 = load i64, ptr %t861, !tbaa !24
  %t863 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t865 = call i64 @__olang_fmt_i64(ptr null, i64 %t860)
  %t866 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t868 = add i64 %t865, %t867
  %t870 = call i64 @__olang_fmt_i64(ptr null, i64 %t862)
  %t871 = add i64 %t868, %t870
  %t872 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t873 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t874 = add i64 %t871, %t873
  %t876 = extractvalue { i64, ptr } %t863, 1
  %t877 = extractvalue { i64, ptr } %t863, 0
  %t878 = add i64 %t874, %t877
  %t879 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t880 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t881 = add i64 %t878, %t880
  %t882 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t881)
  %t883 = call i64 @__olang_fmt_i64(ptr %t882, i64 %t860)
  %t884 = getelementptr i8, ptr %t882, i64 %t865
  call void @olang_textcopy(ptr %t884, ptr %t866, i64 %t867)
  %t885 = getelementptr i8, ptr %t884, i64 %t867
  %t886 = call i64 @__olang_fmt_i64(ptr %t885, i64 %t862)
  %t887 = getelementptr i8, ptr %t885, i64 %t870
  call void @olang_textcopy(ptr %t887, ptr %t872, i64 %t873)
  %t888 = getelementptr i8, ptr %t887, i64 %t873
  call void @olang_textcopy(ptr %t888, ptr %t876, i64 %t877)
  %t889 = getelementptr i8, ptr %t888, i64 %t877
  call void @olang_textcopy(ptr %t889, ptr %t879, i64 %t880)
  %t890 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t891 = insertvalue { i64, ptr } %t890, ptr %t882, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s31, ptr %s36, ptr %l24, { i64, ptr } %t891)
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s36)
  br label %bb210
bb210:
  %t895 = load i64, ptr %l26, !tbaa !24
  %t898 = add i64 %t895, 1
  store i64 %t898, ptr %l26, !tbaa !24
  br label %bb197
bb211:
  %t901 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s31, ptr %s31, ptr %l24)
  store { i64, ptr } %t901, ptr %l339
  br label %bb212
bb212:
  %t902 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t902, 0
  %t905 = extractvalue { i64, ptr } %t902, 1
  %t906 = mul i64 %t904, 1
  %t907 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t906)
  call void @llvm.memcpy.p0.p0.i64(ptr %t907, ptr %t905, i64 %t906, i1 false)
  %t908 = insertvalue { i64, ptr } undef, i64 %t904, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t907, 1
  %t911 = call { i64, ptr } @std_2fsha256_2eHex(ptr %s31, ptr %s31, { i64, ptr } %t909)
  store { i64, ptr } %t911, ptr %l342
  br label %bb213
bb213:
  %t912 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t912, 0
  store i64 %t913, ptr %l343, !tbaa !24
  %t914 = icmp sge i64 0, 0
  br i1 %t914, label %bb214, label %bb215
bb214:
  %t916 = icmp sle i64 0, 16
  br i1 %t916, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_cc736817fb6c70d0_6e757e50f6c823e4)
  unreachable
bb216:
  %t918 = load i64, ptr %l343, !tbaa !24
  %t919 = icmp sle i64 16, %t918
  br i1 %t919, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @olang_loc_cc736817fb6c70d0_6e757e50f6c823e4)
  unreachable
bb218:
  %t921 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t922 = load ptr, ptr %t921, !tbaa !27
  %t923 = getelementptr i8, ptr %t922, i64 0
  %t924 = sub i64 16, 0
  %t925 = insertvalue { i64, ptr } undef, i64 %t924, 0
  %t926 = insertvalue { i64, ptr } %t925, ptr %t923, 1
  store { i64, ptr } %t926, ptr %l29, !tbaa !27
  %t928 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 1
  %t929 = load { i64, ptr }, ptr %t928, !tbaa !27
  %t931 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s31, ptr %s31, { i64, ptr } %t929, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t931, ptr %l349
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_cc736817fb6c70d0_6e757e50f6c823e4)
  unreachable
bb220:
  %t932 = load i1, ptr %l349, !tbaa !21
  br i1 %t932, label %bb221, label %bb222
bb221:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l350, !tbaa !27
  br label %bb223
bb222:
  %t933 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t934 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 1
  %t935 = load { i64, ptr }, ptr %t934, !tbaa !27
  %t936 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t937 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t939 = extractvalue { i64, ptr } %t933, 1
  %t940 = extractvalue { i64, ptr } %t933, 0
  %t941 = add i64 %t937, %t940
  %t942 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t943 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t944 = add i64 %t941, %t943
  %t946 = extractvalue { i64, ptr } %t935, 1
  %t947 = extractvalue { i64, ptr } %t935, 0
  %t948 = add i64 %t944, %t947
  %t949 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t948)
  call void @olang_textcopy(ptr %t949, ptr %t936, i64 %t937)
  %t950 = getelementptr i8, ptr %t949, i64 %t937
  call void @olang_textcopy(ptr %t950, ptr %t939, i64 %t940)
  %t951 = getelementptr i8, ptr %t950, i64 %t940
  call void @olang_textcopy(ptr %t951, ptr %t942, i64 %t943)
  %t952 = getelementptr i8, ptr %t951, i64 %t943
  call void @olang_textcopy(ptr %t952, ptr %t946, i64 %t947)
  %t953 = insertvalue { i64, ptr } undef, i64 %t948, 0
  %t954 = insertvalue { i64, ptr } %t953, ptr %t949, 1
  store { i64, ptr } %t954, ptr %l350, !tbaa !27
  br label %bb223
bb223:
  %t957 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t957, ptr %l30, !tbaa !27
  %t958 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t959 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t961 = extractvalue { i64, ptr } %t959, 1
  %t962 = extractvalue { i64, ptr } %t959, 0
  %t963 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t964 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t965 = add i64 %t962, %t964
  %t966 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t965)
  call void @olang_textcopy(ptr %t966, ptr %t961, i64 %t962)
  %t967 = getelementptr i8, ptr %t966, i64 %t962
  call void @olang_textcopy(ptr %t967, ptr %t963, i64 %t964)
  %t968 = insertvalue { i64, ptr } undef, i64 %t965, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t966, 1
  %t971 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 0
  %t972 = load { i64, ptr }, ptr %t971, !tbaa !27
  %t976 = call i1 @compiler_2fload_2ekeepFile(ptr %s0, ptr %s31, ptr %s31, { i64, ptr } %t958, { i64, ptr } %t969, { i64, ptr } %t972)
  store i1 %t976, ptr %l360
  br label %bb224
bb224:
  %t977 = load i1, ptr %l360, !tbaa !21
  %t978 = xor i1 %t977, true
  br i1 %t978, label %bb225, label %bb226
bb225:
  store i1 true, ptr %l362, !tbaa !21
  br label %bb228
bb226:
  %t980 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t981 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t983 = extractvalue { i64, ptr } %t981, 1
  %t984 = extractvalue { i64, ptr } %t981, 0
  %t985 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t986 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t987 = add i64 %t984, %t986
  %t988 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t987)
  call void @olang_textcopy(ptr %t988, ptr %t983, i64 %t984)
  %t989 = getelementptr i8, ptr %t988, i64 %t984
  call void @olang_textcopy(ptr %t989, ptr %t985, i64 %t986)
  %t990 = insertvalue { i64, ptr } undef, i64 %t987, 0
  %t991 = insertvalue { i64, ptr } %t990, ptr %t988, 1
  %t993 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t997 = call i1 @compiler_2fload_2ekeepFile(ptr %s0, ptr %s31, ptr %s31, { i64, ptr } %t980, { i64, ptr } %t991, { i64, ptr } %t993)
  store i1 %t997, ptr %l368
  br label %bb227
bb227:
  %t998 = load i1, ptr %l368, !tbaa !21
  %t999 = xor i1 %t998, true
  store i1 %t999, ptr %l362, !tbaa !21
  br label %bb228
bb228:
  %t1001 = load i1, ptr %l362, !tbaa !21
  br i1 %t1001, label %bb229, label %bb230
bb229:
  store i1 true, ptr %l370, !tbaa !21
  br label %bb233
bb230:
  %t1002 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t1002, ptr %l371, !tbaa !27
  %t1003 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1005 = extractvalue { i64, ptr } %t1003, 1
  %t1006 = extractvalue { i64, ptr } %t1003, 0
  %t1007 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t1008 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t1009 = add i64 %t1006, %t1008
  %t1010 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1009)
  call void @olang_textcopy(ptr %t1010, ptr %t1005, i64 %t1006)
  %t1011 = getelementptr i8, ptr %t1010, i64 %t1006
  call void @olang_textcopy(ptr %t1011, ptr %t1007, i64 %t1008)
  %t1012 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1013 = insertvalue { i64, ptr } %t1012, ptr %t1010, 1
  store { i64, ptr } %t1013, ptr %l374, !tbaa !27
  %t1016 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s31, ptr %s31, ptr %l24)
  store { i64, ptr } %t1016, ptr %l376
  br label %bb231
bb231:
  %t1017 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t1018 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t1019 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t1021 = call i1 @compiler_2fload_2ekeepFile(ptr %s0, ptr %s31, ptr %s31, { i64, ptr } %t1018, { i64, ptr } %t1019, { i64, ptr } %t1017)
  store i1 %t1021, ptr %l378
  br label %bb232
bb232:
  %t1022 = load i1, ptr %l378, !tbaa !21
  %t1023 = xor i1 %t1022, true
  store i1 %t1023, ptr %l370, !tbaa !21
  br label %bb233
bb233:
  %t1025 = load i1, ptr %l370, !tbaa !21
  br i1 %t1025, label %bb234, label %bb235
bb234:
  store %olang.scope zeroinitializer, ptr %s44
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/load:Loader", ptr %t1026, i32 0, i32 4
  %t1029 = load ptr, ptr %t1028, !tbaa !29
  store ptr %t1029, ptr %l381, !tbaa !29
  %t1030 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t1030, ptr %l382
  %t1031 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1032 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1033 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t1034 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t1036 = extractvalue { i64, ptr } %t1032, 1
  %t1037 = extractvalue { i64, ptr } %t1032, 0
  %t1038 = add i64 %t1034, %t1037
  %t1039 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1038)
  call void @olang_textcopy(ptr %t1039, ptr %t1033, i64 %t1034)
  %t1040 = getelementptr i8, ptr %t1039, i64 %t1034
  call void @olang_textcopy(ptr %t1040, ptr %t1036, i64 %t1037)
  %t1041 = insertvalue { i64, ptr } undef, i64 %t1038, 0
  %t1042 = insertvalue { i64, ptr } %t1041, ptr %t1039, 1
  %t1046 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCImportFailed(ptr %v1, ptr %s44, ptr %v0, { i64, ptr } %t1031, { i64, ptr } %t1042)
  store %"compiler/diagmsg:Msg" %t1046, ptr %l387
  br label %bb236
bb235:
  br label %bb238
bb236:
  %t1047 = load ptr, ptr %l381, !tbaa !29
  %t1048 = load { i64, [3 x i64] }, ptr %l382
  %t1049 = load %"compiler/diagmsg:Msg", ptr %l387
  %t1050 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t1047, { i64, [3 x i64] } %t1048, %"compiler/diagmsg:Msg" %t1049)
  store i64 %t1050, ptr %l388
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb238:
  %t1052 = call ptr @__olang_scope_hold(ptr %s0)
  %t1053 = ptrtoint ptr %t1052 to i64
  store i64 %t1053, ptr %l390, !tbaa !24
  %t1054 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e22
  br i1 %t1054, label %bb239, label %bb240
bb239:
  %t1056 = call ptr @__olang_region_make(ptr %s0)
  %t1057 = ptrtoint ptr %t1056 to i64
  store i64 %t1057, ptr %l390, !tbaa !24
  br label %bb240
bb240:
  %t1058 = getelementptr %"compiler/bindgen:Translation", ptr %l23, i32 0, i32 0
  %t1059 = load { i64, ptr }, ptr %t1058, !tbaa !27
  store { i64, ptr } %t1059, ptr %l393, !tbaa !27
  %t1061 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t1062 = extractvalue { i64, ptr } %t1061, 0
  store i64 %t1062, ptr %l394, !tbaa !24
  %t1063 = load i64, ptr %l394, !tbaa !24
  %t1064 = mul i64 %t1063, 1
  %t1065 = load i64, ptr %l390
  %t1066 = inttoptr i64 %t1065 to ptr
  %t1067 = call ptr @__olang_held_alloc(ptr %t1066, i64 %t1064)
  %t1068 = insertvalue { i64, ptr } undef, i64 %t1063, 0
  %t1069 = insertvalue { i64, ptr } %t1068, ptr %t1067, 1
  store { i64, ptr } %t1069, ptr %l395, !tbaa !27
  %t1070 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t1071 = load ptr, ptr %t1070, !tbaa !27
  %t1072 = getelementptr { i64, ptr }, ptr %l393, i32 0, i32 1
  %t1073 = load ptr, ptr %t1072, !tbaa !27
  %t1074 = load i64, ptr %l394, !tbaa !24
  %t1075 = mul i64 %t1074, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1071, ptr %t1073, i64 %t1075, i1 false)
  %t1076 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t1076, ptr %l396, !tbaa !27
  %t1077 = load { i64, ptr }, ptr %l395, !tbaa !27
  store { i64, ptr } %t1077, ptr %l22, !tbaa !27
  %t1078 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e22
  br i1 %t1078, label %bb241, label %bb242
bb241:
  %t1080 = load { i64, ptr }, ptr %l396
  %t1081 = extractvalue { i64, ptr } %t1080, 1
  call void @__olang_region_release(ptr %t1081)
  store { i64, ptr } zeroinitializer, ptr %l396
  br label %bb242
bb242:
  %t1082 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e22
  br i1 %t1082, label %bb243, label %bb244
bb243:
  %t1084 = load i64, ptr %l390
  %t1085 = inttoptr i64 %t1084 to ptr
  %t1086 = load { i64, ptr }, ptr %l22
  %t1087 = extractvalue { i64, ptr } %t1086, 1
  %t1088 = call ptr @__olang_region_or(ptr %t1087, ptr null)
  %t1089 = icmp ne ptr %t1088, null
  %t1090 = select i1 %t1089, ptr %t1088, ptr null
  call void @__olang_region_settle_in(ptr %t1085, ptr %t1090)
  br label %bb244
bb244:
  %t1091 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t1092 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2fload_2etrimCImports(ptr %s0, ptr %s0, { i64, ptr } %t1091, { i64, ptr } %t1092)
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s31)
  br label %bb246
bb246:
  %t1095 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1097 = extractvalue { i64, ptr } %t1095, 1
  %t1098 = extractvalue { i64, ptr } %t1095, 0
  %t1099 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t1100 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t1101 = add i64 %t1098, %t1100
  %t1102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1101)
  call void @olang_textcopy(ptr %t1102, ptr %t1097, i64 %t1098)
  %t1103 = getelementptr i8, ptr %t1102, i64 %t1098
  call void @olang_textcopy(ptr %t1103, ptr %t1099, i64 %t1100)
  %t1104 = insertvalue { i64, ptr } undef, i64 %t1101, 0
  %t1105 = insertvalue { i64, ptr } %t1104, ptr %t1102, 1
  %t1108 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } %t1105)
  %t1109 = extractvalue { i32, { i64, ptr } } %t1108, 1
  %t1110 = extractvalue { i32, { i64, ptr } } %t1108, 0
  store i32 %t1110, ptr %l406
  %t1111 = icmp ne i32 %t1110, 0
  br i1 %t1111, label %bb248, label %ok.1112, !prof !99
ok.1112:
  store { i64, ptr } %t1109, ptr %l405
  br label %bb247
bb247:
  %t1113 = load { i64, ptr }, ptr %l405, !tbaa !27
  store { i64, ptr } %t1113, ptr %l401, !tbaa !27
  br label %bb252
bb248:
  %t1114 = load i32, ptr %l406, !tbaa !23
  %t1115 = ashr i32 %t1114, 16
  %t1117 = icmp eq i32 %t1115, 1
  br i1 %t1117, label %bb249, label %bb250
bb249:
  call void @__olang_errpay_pop()
  br label %bb250
bb250:
  br label %bb251
bb251:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l401, !tbaa !27
  br label %bb252
bb252:
  %t1119 = load { i64, ptr }, ptr %l401, !tbaa !27
  store { i64, ptr } %t1119, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t1120 = load ptr, ptr %l0, !tbaa !29
  %t1122 = getelementptr %"compiler/load:Loader", ptr %t1120, i32 0, i32 10
  %t1124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t1122)
  store i64 %t1124, ptr %l411
  br label %bb253
bb253:
  %t1125 = load i64, ptr %l411, !tbaa !24
  store i64 %t1125, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t1126 = load i64, ptr %l33, !tbaa !24
  %t1127 = load i64, ptr %l32, !tbaa !24
  %t1130 = icmp sgt i64 %t1126, %t1127
  br i1 %t1130, label %bb254, label %bb255
bb254:
  %t1132 = load i64, ptr %l34, !tbaa !24
  %t1134 = icmp sgt i64 %t1132, 0
  br i1 %t1134, label %bb256, label %bb257
bb255:
  store i64 0, ptr %l415, !tbaa !24
  br label %bb259
bb256:
  %t1136 = load i64, ptr %l33, !tbaa !24
  %t1137 = load i64, ptr %l32, !tbaa !24
  %t1140 = sub i64 %t1136, %t1137
  %t1141 = load i64, ptr %l34, !tbaa !24
  %t1144 = add i64 %t1140, %t1141
  %t1146 = sub i64 %t1144, 1
  %t1147 = load i64, ptr %l34, !tbaa !24
  %t1150 = sdiv i64 %t1146, %t1147
  store i64 %t1150, ptr %l418, !tbaa !24
  br label %bb258
bb257:
  store i64 0, ptr %l418, !tbaa !24
  br label %bb258
bb258:
  %t1152 = load i64, ptr %l418, !tbaa !24
  store i64 %t1152, ptr %l415, !tbaa !24
  br label %bb259
bb259:
  %t1153 = load i64, ptr %l415, !tbaa !24
  store i64 %t1153, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb260
bb260:
  store %olang.scope zeroinitializer, ptr %s48
  %t1154 = load i64, ptr %l36, !tbaa !24
  %t1155 = load i64, ptr %l35, !tbaa !24
  %t1158 = icmp slt i64 %t1154, %t1155
  %t1160 = xor i1 %t1158, true
  br i1 %t1160, label %bb261, label %bb262
bb261:
  call void @__olang_scope_close(ptr %s48)
  br label %bb274
bb262:
  br label %bb263
bb263:
  %t1162 = load i64, ptr %l32, !tbaa !24
  %t1163 = load i64, ptr %l36, !tbaa !24
  %t1164 = load i64, ptr %l34, !tbaa !24
  %t1167 = mul i64 %t1163, %t1164
  %t1170 = add i64 %t1162, %t1167
  store i64 %t1170, ptr %l37, !tbaa !24
  %t1172 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s48, { i64, ptr } %t1172, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t1174, ptr %l437
  br label %bb264
bb264:
  %t1175 = load i1, ptr %l437, !tbaa !21
  %t1176 = xor i1 %t1175, true
  br i1 %t1176, label %bb265, label %bb266
bb265:
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1180 = getelementptr %"compiler/load:Loader", ptr %t1178, i32 0, i32 10
  %t1181 = load i64, ptr %l37, !tbaa !24
  %t1184 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1180, i64 %t1181)
  store ptr %t1184, ptr %l443
  br label %bb267
bb266:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb269
bb267:
  %t1185 = load ptr, ptr %l443, !tbaa !29
  %t1187 = getelementptr %"compiler/load:Module", ptr %t1185, i32 0, i32 1
  %t1188 = load { i64, ptr }, ptr %t1187, !tbaa !27
  %t1189 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1188, { i64, ptr } %t1189)
  store i1 %t1192, ptr %l447
  br label %bb268
bb268:
  %t1193 = load i1, ptr %l447, !tbaa !21
  store i1 %t1193, ptr %l439, !tbaa !21
  br label %bb269
bb269:
  %t1194 = load i1, ptr %l439, !tbaa !21
  br i1 %t1194, label %bb270, label %bb271
bb270:
  %t1195 = load i64, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s48)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t1195, ptr %rv
  br label %ret
bb271:
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s48)
  br label %bb273
bb273:
  %t1197 = load i64, ptr %l36, !tbaa !24
  %t1200 = add i64 %t1197, 1
  store i64 %t1200, ptr %l36, !tbaa !24
  br label %bb260
bb274:
  %t1202 = load ptr, ptr %l0, !tbaa !29
  %t1203 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1206 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fload_2ecompiler_2fload_3aLoader_2esharedCTypes(ptr %v0, ptr %s0, ptr %v0, ptr %t1202, { i64, ptr } %t1203)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1206, ptr %l454
  br label %bb275
bb275:
  %t1207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t1207, ptr %lp38
  %t1208 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l454
  %t1209 = load ptr, ptr %lp38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1208, ptr %t1209
  %t1210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1210, ptr %l455, !tbaa !29
  %t1211 = call ptr @__olang_scope_hold(ptr %v0)
  %t1212 = ptrtoint ptr %t1211 to i64
  store i64 %t1212, ptr %l456, !tbaa !24
  %t1213 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e0
  br i1 %t1213, label %bb276, label %bb277
bb276:
  %t1215 = call ptr @__olang_region_make(ptr %v0)
  %t1216 = ptrtoint ptr %t1215 to i64
  store i64 %t1216, ptr %l456, !tbaa !24
  br label %bb277
bb277:
  %t1217 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1219 = extractvalue { i64, ptr } %t1217, 1
  %t1220 = extractvalue { i64, ptr } %t1217, 0
  %t1221 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t1222 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t1223 = add i64 %t1220, %t1222
  %t1224 = load i64, ptr %l456
  %t1225 = inttoptr i64 %t1224 to ptr
  %t1226 = call ptr @__olang_held_alloc(ptr %t1225, i64 %t1223)
  call void @olang_textcopy(ptr %t1226, ptr %t1219, i64 %t1220)
  %t1227 = getelementptr i8, ptr %t1226, i64 %t1220
  call void @olang_textcopy(ptr %t1227, ptr %t1221, i64 %t1222)
  %t1228 = insertvalue { i64, ptr } undef, i64 %t1223, 0
  %t1229 = insertvalue { i64, ptr } %t1228, ptr %t1226, 1
  store { i64, ptr } %t1229, ptr %l460, !tbaa !27
  %t1231 = load ptr, ptr %lp11
  %t1232 = load { i64, ptr }, ptr %t1231, !tbaa !27
  store { i64, ptr } %t1232, ptr %l461, !tbaa !27
  %t1233 = load ptr, ptr %lp38
  %t1235 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %v0, ptr %t1233)
  store i64 %t1235, ptr %l463
  br label %bb278
bb278:
  %t1236 = load i64, ptr %l463, !tbaa !24
  %t1237 = icmp sgt i64 %t1236, 0
  br i1 %t1237, label %bb279, label %bb280
bb279:
  %t1239 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1240 = load ptr, ptr %lp38
  %t1243 = call { i64, ptr } @compiler_2fload_2ewithoutCTypes(ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t1239, ptr %t1240)
  store { i64, ptr } %t1243, ptr %l468
  br label %bb281
bb280:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l465, !tbaa !27
  br label %bb282
bb281:
  %t1244 = load { i64, ptr }, ptr %l468, !tbaa !27
  store { i64, ptr } %t1244, ptr %l465, !tbaa !27
  br label %bb282
bb282:
  %t1246 = load ptr, ptr %l455, !tbaa !29
  %t1247 = load { i64, ptr }, ptr %l460, !tbaa !27
  %t1248 = load { i64, ptr }, ptr %l461, !tbaa !27
  %t1249 = load { i64, ptr }, ptr %l465, !tbaa !27
  %t1250 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1246, { i64, ptr } %t1247, { i64, ptr } %t1248, i1 false, i1 true, { i64, ptr } %t1249)
  store i64 %t1250, ptr %l470
  br label %bb283
bb283:
  %t1251 = load i64, ptr %l470, !tbaa !24
  store i64 %t1251, ptr %l39, !tbaa !24
  %t1252 = load i64, ptr %l39, !tbaa !24
  %t1254 = icmp slt i64 %t1252, 0
  br i1 %t1254, label %bb284, label %bb285
bb284:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb285:
  br label %bb286
bb286:
  %t1257 = load ptr, ptr %lp38
  %t1259 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H48e651c05c949f01bc365c3f5aed05e5(ptr %v0, ptr %v0, ptr %t1257)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t1259, ptr %l475
  br label %bb287
bb287:
  %t1260 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l475
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t1260, ptr %l40
  br label %bb288
bb288:
  %t1262 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_Haa4821f40e4709ffaa64d7939c192aa7(ptr %v0, ptr %v0, ptr %l40)
  %t1263 = extractvalue { i32, { i64, ptr } } %t1262, 1
  %t1264 = extractvalue { i32, { i64, ptr } } %t1262, 0
  store i32 %t1264, ptr %l479
  %t1265 = icmp ne i32 %t1264, 0
  br i1 %t1265, label %bb290, label %ok.1266, !prof !99
ok.1266:
  store { i64, ptr } %t1263, ptr %l478
  br label %bb289
bb289:
  %t1267 = load { i64, ptr }, ptr %l478, !tbaa !27
  store { i64, ptr } %t1267, ptr %l476, !tbaa !27
  br label %bb292
bb290:
  %t1268 = load i32, ptr %l479, !tbaa !23
  %t1269 = ashr i32 %t1268, 16
  %t1271 = icmp eq i32 %t1269, 1
  store i1 %t1271, ptr %l481, !tbaa !21
  br label %bb291
bb291:
  br label %bb301
bb292:
  %t1272 = load { i64, ptr }, ptr %l476, !tbaa !27
  store { i64, ptr } %t1272, ptr %l41, !tbaa !27
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1275 = getelementptr %"compiler/load:Loader", ptr %t1273, i32 0, i32 10
  %t1276 = load i64, ptr %l39, !tbaa !24
  %t1279 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1275, i64 %t1276)
  store ptr %t1279, ptr %l485
  br label %bb293
bb293:
  %t1280 = load ptr, ptr %l485, !tbaa !29
  %t1282 = getelementptr %"compiler/load:Module", ptr %t1280, i32 0, i32 37
  store ptr %t1282, ptr %l487, !tbaa !29
  %t1283 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1283, ptr %l488, !tbaa !27
  %t1284 = load ptr, ptr %lp38
  %t1285 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1288 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t1284, { i64, ptr } %t1285)
  %t1289 = extractvalue { i32, i64 } %t1288, 1
  %t1290 = extractvalue { i32, i64 } %t1288, 0
  store i32 %t1290, ptr %l493
  %t1291 = icmp ne i32 %t1290, 0
  br i1 %t1291, label %bb295, label %ok.1292, !prof !99
ok.1292:
  store i64 %t1289, ptr %l492
  br label %bb294
bb294:
  %t1293 = load i64, ptr %l492, !tbaa !24
  store i64 %t1293, ptr %l489, !tbaa !24
  br label %bb298
bb295:
  %t1294 = load i32, ptr %l493, !tbaa !23
  %t1295 = icmp eq i32 %t1294, 65536
  br i1 %t1295, label %bb296, label %bb297
bb296:
  call void @__olang_bang_failed_plain(ptr @olang_loc_390d71ace96962ec_ea4878fb110dc7f0)
  unreachable
bb297:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8d4df4585930a33a_b93e06b5ac523ace)
  unreachable
bb298:
  %t1297 = load ptr, ptr %l487, !tbaa !29
  %t1298 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t1299 = load i64, ptr %l489, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t1297, { i64, ptr } %t1298, i64 %t1299)
  br label %bb299
bb299:
  br label %bb300
bb300:
  br label %bb288
bb301:
  %t1300 = load ptr, ptr %l0, !tbaa !29
  %t1302 = getelementptr %"compiler/load:Loader", ptr %t1300, i32 0, i32 10
  %t1303 = load i64, ptr %l39, !tbaa !24
  %t1306 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1302, i64 %t1303)
  store ptr %t1306, ptr %l498
  br label %bb302
bb302:
  %t1307 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1307, ptr %l42, !tbaa !29
  %t1308 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1310 = extractvalue { i64, ptr } %t1308, 1
  %t1311 = extractvalue { i64, ptr } %t1308, 0
  %t1312 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t1313 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t1314 = add i64 %t1311, %t1313
  %t1315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1314)
  call void @olang_textcopy(ptr %t1315, ptr %t1310, i64 %t1311)
  %t1316 = getelementptr i8, ptr %t1315, i64 %t1311
  call void @olang_textcopy(ptr %t1316, ptr %t1312, i64 %t1313)
  %t1317 = insertvalue { i64, ptr } undef, i64 %t1314, 0
  %t1318 = insertvalue { i64, ptr } %t1317, ptr %t1315, 1
  %t1321 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t1318)
  store i1 %t1321, ptr %l502
  br label %bb303
bb303:
  %t1322 = load i1, ptr %l502, !tbaa !21
  br i1 %t1322, label %bb304, label %bb305
bb304:
  %t1323 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1325 = extractvalue { i64, ptr } %t1323, 1
  %t1326 = extractvalue { i64, ptr } %t1323, 0
  %t1327 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t1328 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t1329 = add i64 %t1326, %t1328
  %t1330 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1329)
  call void @olang_textcopy(ptr %t1330, ptr %t1325, i64 %t1326)
  %t1331 = getelementptr i8, ptr %t1330, i64 %t1326
  call void @olang_textcopy(ptr %t1331, ptr %t1327, i64 %t1328)
  %t1332 = insertvalue { i64, ptr } undef, i64 %t1329, 0
  %t1333 = insertvalue { i64, ptr } %t1332, ptr %t1330, 1
  %t1336 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t1333)
  %t1337 = extractvalue { i32, %"std/os:FileInfo" } %t1336, 1
  %t1338 = extractvalue { i32, %"std/os:FileInfo" } %t1336, 0
  store i32 %t1338, ptr %l509
  %t1339 = icmp ne i32 %t1338, 0
  br i1 %t1339, label %bb307, label %ok.1340, !prof !99
ok.1340:
  store %"std/os:FileInfo" %t1337, ptr %l508
  br label %bb306
bb305:
  store i1 false, ptr %l503, !tbaa !21
  br label %bb313
bb306:
  %t1341 = load %"std/os:FileInfo", ptr %l508
  store %"std/os:FileInfo" %t1341, ptr %l504
  br label %bb312
bb307:
  %t1342 = load i32, ptr %l509, !tbaa !23
  %t1343 = ashr i32 %t1342, 16
  %t1345 = icmp eq i32 %t1343, 1
  store i1 %t1345, ptr %l511, !tbaa !21
  %t1346 = load i32, ptr %l509, !tbaa !23
  %t1347 = ashr i32 %t1346, 16
  %t1349 = icmp eq i32 %t1347, 1
  br i1 %t1349, label %bb308, label %bb309
bb308:
  call void @__olang_errpay_pop()
  br label %bb309
bb309:
  br label %bb310
bb310:
  %t1352 = call %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %s0, i32 2, i64 0, i64 0)
  store %"std/os:FileInfo" %t1352, ptr %l515
  br label %bb311
bb311:
  %t1353 = load %"std/os:FileInfo", ptr %l515
  store %"std/os:FileInfo" %t1353, ptr %l504
  br label %bb312
bb312:
  %t1354 = getelementptr %"std/os:FileInfo", ptr %l504, i32 0, i32 1
  %t1355 = load i64, ptr %t1354, !tbaa !24
  %t1357 = icmp sgt i64 %t1355, 0
  store i1 %t1357, ptr %l503, !tbaa !21
  br label %bb313
bb313:
  %t1359 = load i1, ptr %l503, !tbaa !21
  br i1 %t1359, label %bb314, label %bb315
bb314:
  %t1360 = load ptr, ptr %l42, !tbaa !29
  store ptr %t1360, ptr %l518, !tbaa !29
  %t1361 = call ptr @__olang_scope_hold(ptr %v0)
  %t1362 = ptrtoint ptr %t1361 to i64
  store i64 %t1362, ptr %l519, !tbaa !24
  %t1363 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e34
  br i1 %t1363, label %bb316, label %bb317
bb315:
  br label %bb320
bb316:
  %t1365 = call ptr @__olang_region_make(ptr %v0)
  %t1366 = ptrtoint ptr %t1365 to i64
  store i64 %t1366, ptr %l519, !tbaa !24
  br label %bb317
bb317:
  %t1367 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1369 = extractvalue { i64, ptr } %t1367, 1
  %t1370 = extractvalue { i64, ptr } %t1367, 0
  %t1371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t1372 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t1373 = add i64 %t1370, %t1372
  %t1374 = load i64, ptr %l519
  %t1375 = inttoptr i64 %t1374 to ptr
  %t1376 = call ptr @__olang_held_alloc(ptr %t1375, i64 %t1373)
  call void @olang_textcopy(ptr %t1376, ptr %t1369, i64 %t1370)
  %t1377 = getelementptr i8, ptr %t1376, i64 %t1370
  call void @olang_textcopy(ptr %t1377, ptr %t1371, i64 %t1372)
  %t1378 = insertvalue { i64, ptr } undef, i64 %t1373, 0
  %t1379 = insertvalue { i64, ptr } %t1378, ptr %t1376, 1
  %t1381 = load ptr, ptr %l518, !tbaa !29
  %t1382 = getelementptr %"compiler/load:Module", ptr %t1381, i32 0, i32 34
  %t1383 = load { i64, ptr }, ptr %t1382, !tbaa !27
  store { i64, ptr } %t1383, ptr %l524, !tbaa !27
  %t1385 = load ptr, ptr %l518, !tbaa !29
  %t1386 = getelementptr %"compiler/load:Module", ptr %t1385, i32 0, i32 34
  store { i64, ptr } %t1379, ptr %t1386, !tbaa !27
  %t1387 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e34
  br i1 %t1387, label %bb318, label %bb319
bb318:
  %t1389 = load { i64, ptr }, ptr %l524
  %t1390 = extractvalue { i64, ptr } %t1389, 1
  call void @__olang_region_release(ptr %t1390)
  store { i64, ptr } zeroinitializer, ptr %l524
  br label %bb319
bb319:
  br label %bb320
bb320:
  store i1 false, ptr %l43, !tbaa !21
  %t1391 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1393 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t1391)
  store %"std/prelude/text:LineIter" %t1393, ptr %l527
  br label %bb321
bb321:
  %t1394 = load %"std/prelude/text:LineIter", ptr %l527
  store %"std/prelude/text:LineIter" %t1394, ptr %l44
  br label %bb322
bb322:
  store %olang.scope zeroinitializer, ptr %s60
  %t1396 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l44)
  %t1397 = extractvalue { i32, { i64, ptr } } %t1396, 1
  %t1398 = extractvalue { i32, { i64, ptr } } %t1396, 0
  store i32 %t1398, ptr %l531
  %t1399 = icmp ne i32 %t1398, 0
  br i1 %t1399, label %bb324, label %ok.1400, !prof !99
ok.1400:
  store { i64, ptr } %t1397, ptr %l530
  br label %bb323
bb323:
  %t1401 = load { i64, ptr }, ptr %l530, !tbaa !27
  store { i64, ptr } %t1401, ptr %l528, !tbaa !27
  br label %bb326
bb324:
  %t1402 = load i32, ptr %l531, !tbaa !23
  %t1403 = ashr i32 %t1402, 16
  %t1405 = icmp eq i32 %t1403, 1
  store i1 %t1405, ptr %l533, !tbaa !21
  br label %bb325
bb325:
  call void @__olang_scope_close(ptr %s60)
  br label %bb382
bb326:
  %t1406 = load { i64, ptr }, ptr %l528, !tbaa !27
  store { i64, ptr } %t1406, ptr %l45, !tbaa !27
  %t1407 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1409 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s60, { i64, ptr } %t1407, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store i1 %t1409, ptr %l535
  br label %bb327
bb327:
  %t1410 = load i1, ptr %l535, !tbaa !21
  br i1 %t1410, label %bb328, label %bb329
bb328:
  store %olang.scope zeroinitializer, ptr %s61
  %t1411 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1411, ptr %l536, !tbaa !27
  %t1412 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1415 = extractvalue { i64, ptr } %t1412, 0
  store i64 %t1415, ptr %l539, !tbaa !24
  %t1416 = load { i64, ptr }, ptr %l536, !tbaa !27
  %t1417 = extractvalue { i64, ptr } %t1416, 0
  store i64 %t1417, ptr %l540, !tbaa !24
  %t1418 = icmp sge i64 9, 0
  br i1 %t1418, label %bb330, label %bb331
bb329:
  store %olang.scope zeroinitializer, ptr %s65
  %t1420 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1422 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s65, { i64, ptr } %t1420, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t1422, ptr %l564
  br label %bb345
bb330:
  %t1423 = load i64, ptr %l539, !tbaa !24
  %t1424 = icmp sle i64 9, %t1423
  br i1 %t1424, label %bb332, label %bb333
bb331:
  call void @__olang_check_failed(ptr @olang_loc_946ee3836eb302af_c914571e601006eb)
  unreachable
bb332:
  %t1426 = load i64, ptr %l539, !tbaa !24
  %t1427 = load i64, ptr %l540, !tbaa !24
  %t1428 = icmp sle i64 %t1426, %t1427
  br i1 %t1428, label %bb334, label %bb335
bb333:
  call void @__olang_check_failed(ptr @olang_loc_946ee3836eb302af_c914571e601006eb)
  unreachable
bb334:
  %t1430 = getelementptr { i64, ptr }, ptr %l536, i32 0, i32 1
  %t1431 = load ptr, ptr %t1430, !tbaa !27
  %t1432 = load i64, ptr %l539, !tbaa !24
  %t1433 = getelementptr i8, ptr %t1431, i64 9
  %t1434 = sub i64 %t1432, 9
  %t1435 = insertvalue { i64, ptr } undef, i64 %t1434, 0
  %t1436 = insertvalue { i64, ptr } %t1435, ptr %t1433, 1
  %t1438 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s61, ptr %s61, { i64, ptr } %t1436, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store { i64, ptr } %t1438, ptr %l545
  br label %bb336
bb335:
  call void @__olang_check_failed(ptr @olang_loc_946ee3836eb302af_c914571e601006eb)
  unreachable
bb336:
  %t1439 = load { i64, ptr }, ptr %l545, !tbaa !27
  store { i64, ptr } %t1439, ptr %l46, !tbaa !27
  %t1440 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1442 = extractvalue { i64, ptr } %t1440, 0
  %t1444 = icmp eq i64 %t1442, 2
  br i1 %t1444, label %bb337, label %bb338
bb337:
  %t1446 = load ptr, ptr %l42, !tbaa !29
  %t1448 = getelementptr %"compiler/load:Module", ptr %t1446, i32 0, i32 35
  store ptr %t1448, ptr %l550, !tbaa !29
  %t1449 = call ptr @__olang_scope_hold(ptr %v0)
  %t1450 = ptrtoint ptr %t1449 to i64
  store i64 %t1450, ptr %l551, !tbaa !24
  %t1451 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t1451, label %bb339, label %bb340
bb338:
  br label %bb344
bb339:
  %t1453 = call ptr @__olang_region_make(ptr %v0)
  %t1454 = ptrtoint ptr %t1453 to i64
  store i64 %t1454, ptr %l551, !tbaa !24
  br label %bb340
bb340:
  %t1455 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1455, ptr %l553, !tbaa !27
  %t1456 = getelementptr { i64, ptr }, ptr %l553, i32 0, i32 1
  %t1457 = load ptr, ptr %t1456, !tbaa !27
  %t1458 = getelementptr { i64, ptr }, ptr %t1457, i64 0
  %t1459 = load { i64, ptr }, ptr %t1458, !tbaa !37
  %t1461 = extractvalue { i64, ptr } %t1459, 1
  %t1462 = extractvalue { i64, ptr } %t1459, 0
  %t1463 = load i64, ptr %l551
  %t1464 = inttoptr i64 %t1463 to ptr
  %t1465 = call ptr @__olang_held_alloc(ptr %t1464, i64 %t1462)
  call void @olang_textcopy(ptr %t1465, ptr %t1461, i64 %t1462)
  %t1466 = insertvalue { i64, ptr } undef, i64 %t1462, 0
  %t1467 = insertvalue { i64, ptr } %t1466, ptr %t1465, 1
  store { i64, ptr } %t1467, ptr %l556, !tbaa !27
  %t1469 = call ptr @__olang_scope_hold(ptr %v0)
  %t1470 = ptrtoint ptr %t1469 to i64
  store i64 %t1470, ptr %l557, !tbaa !24
  %t1471 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t1471, label %bb341, label %bb342
bb341:
  %t1473 = call ptr @__olang_region_make(ptr %v0)
  %t1474 = ptrtoint ptr %t1473 to i64
  store i64 %t1474, ptr %l557, !tbaa !24
  br label %bb342
bb342:
  %t1475 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1475, ptr %l559, !tbaa !27
  %t1476 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1477 = load ptr, ptr %t1476, !tbaa !27
  %t1478 = getelementptr { i64, ptr }, ptr %t1477, i64 1
  %t1479 = load { i64, ptr }, ptr %t1478, !tbaa !37
  %t1481 = extractvalue { i64, ptr } %t1479, 1
  %t1482 = extractvalue { i64, ptr } %t1479, 0
  %t1483 = load i64, ptr %l557
  %t1484 = inttoptr i64 %t1483 to ptr
  %t1485 = call ptr @__olang_held_alloc(ptr %t1484, i64 %t1482)
  call void @olang_textcopy(ptr %t1485, ptr %t1481, i64 %t1482)
  %t1486 = insertvalue { i64, ptr } undef, i64 %t1482, 0
  %t1487 = insertvalue { i64, ptr } %t1486, ptr %t1485, 1
  %t1489 = load ptr, ptr %l550, !tbaa !29
  %t1490 = load { i64, ptr }, ptr %l556, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t1489, { i64, ptr } %t1490, { i64, ptr } %t1487)
  br label %bb343
bb343:
  br label %bb344
bb344:
  call void @__olang_scope_close(ptr %s61)
  br label %bb380
bb345:
  %t1492 = load i1, ptr %l564, !tbaa !21
  br i1 %t1492, label %bb346, label %bb347
bb346:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb379
bb347:
  store %olang.scope zeroinitializer, ptr %s67
  %t1493 = load i1, ptr %l43, !tbaa !21
  br i1 %t1493, label %bb348, label %bb349
bb348:
  %t1495 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1497 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s67, { i64, ptr } %t1495, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t1497, ptr %l568
  br label %bb350
bb349:
  store i1 false, ptr %l566, !tbaa !21
  br label %bb351
bb350:
  %t1498 = load i1, ptr %l568, !tbaa !21
  store i1 %t1498, ptr %l566, !tbaa !21
  br label %bb351
bb351:
  %t1499 = load i1, ptr %l566, !tbaa !21
  br i1 %t1499, label %bb352, label %bb353
bb352:
  store %olang.scope zeroinitializer, ptr %s68
  %t1500 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1502 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s68, { i64, ptr } %t1500, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d146, i32 0, i32 1) })
  %t1503 = extractvalue { i32, i64 } %t1502, 1
  %t1504 = extractvalue { i32, i64 } %t1502, 0
  store i32 %t1504, ptr %l572
  %t1505 = icmp ne i32 %t1504, 0
  br i1 %t1505, label %bb355, label %ok.1506, !prof !99
ok.1506:
  store i64 %t1503, ptr %l571
  br label %bb354
bb353:
  br label %bb378
bb354:
  %t1507 = load i64, ptr %l571, !tbaa !24
  store i64 %t1507, ptr %l569, !tbaa !24
  br label %bb357
bb355:
  br label %bb356
bb356:
  store i64 -1, ptr %l569, !tbaa !24
  br label %bb357
bb357:
  %t1508 = load i64, ptr %l569, !tbaa !24
  store i64 %t1508, ptr %l47, !tbaa !24
  %t1509 = load i64, ptr %l47, !tbaa !24
  %t1511 = icmp sgt i64 %t1509, 4
  br i1 %t1511, label %bb358, label %bb359
bb358:
  %t1513 = load ptr, ptr %l42, !tbaa !29
  %t1515 = getelementptr %"compiler/load:Module", ptr %t1513, i32 0, i32 36
  store ptr %t1515, ptr %l576, !tbaa !29
  %t1516 = call ptr @__olang_scope_hold(ptr %v0)
  %t1517 = ptrtoint ptr %t1516 to i64
  store i64 %t1517, ptr %l577, !tbaa !24
  %t1518 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t1518, label %bb360, label %bb361
bb359:
  br label %bb377
bb360:
  %t1520 = call ptr @__olang_region_make(ptr %v0)
  %t1521 = ptrtoint ptr %t1520 to i64
  store i64 %t1521, ptr %l577, !tbaa !24
  br label %bb361
bb361:
  %t1522 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1522, ptr %l579, !tbaa !27
  %t1523 = load i64, ptr %l47, !tbaa !24
  store i64 %t1523, ptr %l580, !tbaa !24
  %t1524 = load { i64, ptr }, ptr %l579, !tbaa !27
  %t1525 = extractvalue { i64, ptr } %t1524, 0
  store i64 %t1525, ptr %l581, !tbaa !24
  %t1526 = icmp sge i64 4, 0
  br i1 %t1526, label %bb362, label %bb363
bb362:
  %t1528 = load i64, ptr %l580, !tbaa !24
  %t1529 = icmp sle i64 4, %t1528
  br i1 %t1529, label %bb364, label %bb365
bb363:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb364:
  %t1531 = load i64, ptr %l580, !tbaa !24
  %t1532 = load i64, ptr %l581, !tbaa !24
  %t1533 = icmp sle i64 %t1531, %t1532
  br i1 %t1533, label %bb366, label %bb367
bb365:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb366:
  %t1535 = getelementptr { i64, ptr }, ptr %l579, i32 0, i32 1
  %t1536 = load ptr, ptr %t1535, !tbaa !27
  %t1537 = load i64, ptr %l580, !tbaa !24
  %t1538 = getelementptr i8, ptr %t1536, i64 4
  %t1539 = sub i64 %t1537, 4
  %t1540 = insertvalue { i64, ptr } undef, i64 %t1539, 0
  %t1541 = insertvalue { i64, ptr } %t1540, ptr %t1538, 1
  %t1543 = extractvalue { i64, ptr } %t1541, 1
  %t1544 = extractvalue { i64, ptr } %t1541, 0
  %t1545 = load i64, ptr %l577
  %t1546 = inttoptr i64 %t1545 to ptr
  %t1547 = call ptr @__olang_held_alloc(ptr %t1546, i64 %t1544)
  call void @olang_textcopy(ptr %t1547, ptr %t1543, i64 %t1544)
  %t1548 = insertvalue { i64, ptr } undef, i64 %t1544, 0
  %t1549 = insertvalue { i64, ptr } %t1548, ptr %t1547, 1
  store { i64, ptr } %t1549, ptr %l587, !tbaa !27
  %t1551 = call ptr @__olang_scope_hold(ptr %v0)
  %t1552 = ptrtoint ptr %t1551 to i64
  store i64 %t1552, ptr %l588, !tbaa !24
  %t1553 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t1553, label %bb368, label %bb369
bb367:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb368:
  %t1555 = call ptr @__olang_region_make(ptr %v0)
  %t1556 = ptrtoint ptr %t1555 to i64
  store i64 %t1556, ptr %l588, !tbaa !24
  br label %bb369
bb369:
  %t1557 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1557, ptr %l590, !tbaa !27
  %t1558 = load i64, ptr %l47, !tbaa !24
  %t1560 = add i64 %t1558, 2
  store i64 %t1560, ptr %l592, !tbaa !24
  %t1561 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1564 = extractvalue { i64, ptr } %t1561, 0
  store i64 %t1564, ptr %l595, !tbaa !24
  %t1565 = load { i64, ptr }, ptr %l590, !tbaa !27
  %t1566 = extractvalue { i64, ptr } %t1565, 0
  store i64 %t1566, ptr %l596, !tbaa !24
  %t1567 = load i64, ptr %l592, !tbaa !24
  %t1568 = icmp sge i64 %t1567, 0
  br i1 %t1568, label %bb370, label %bb371
bb370:
  %t1570 = load i64, ptr %l592, !tbaa !24
  %t1571 = load i64, ptr %l595, !tbaa !24
  %t1572 = icmp sle i64 %t1570, %t1571
  br i1 %t1572, label %bb372, label %bb373
bb371:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb372:
  %t1574 = load i64, ptr %l595, !tbaa !24
  %t1575 = load i64, ptr %l596, !tbaa !24
  %t1576 = icmp sle i64 %t1574, %t1575
  br i1 %t1576, label %bb374, label %bb375
bb373:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb374:
  %t1578 = getelementptr { i64, ptr }, ptr %l590, i32 0, i32 1
  %t1579 = load ptr, ptr %t1578, !tbaa !27
  %t1580 = load i64, ptr %l592, !tbaa !24
  %t1581 = load i64, ptr %l595, !tbaa !24
  %t1582 = getelementptr i8, ptr %t1579, i64 %t1580
  %t1583 = sub i64 %t1581, %t1580
  %t1584 = insertvalue { i64, ptr } undef, i64 %t1583, 0
  %t1585 = insertvalue { i64, ptr } %t1584, ptr %t1582, 1
  %t1587 = extractvalue { i64, ptr } %t1585, 1
  %t1588 = extractvalue { i64, ptr } %t1585, 0
  %t1589 = load i64, ptr %l588
  %t1590 = inttoptr i64 %t1589 to ptr
  %t1591 = call ptr @__olang_held_alloc(ptr %t1590, i64 %t1588)
  call void @olang_textcopy(ptr %t1591, ptr %t1587, i64 %t1588)
  %t1592 = insertvalue { i64, ptr } undef, i64 %t1588, 0
  %t1593 = insertvalue { i64, ptr } %t1592, ptr %t1591, 1
  %t1595 = load ptr, ptr %l576, !tbaa !29
  %t1596 = load { i64, ptr }, ptr %l587, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t1595, { i64, ptr } %t1596, { i64, ptr } %t1593)
  br label %bb376
bb375:
  call void @__olang_check_failed(ptr @olang_loc_bd0734fef4495944_f844247d18b1c970)
  unreachable
bb376:
  br label %bb377
bb377:
  call void @__olang_scope_close(ptr %s68)
  br label %bb378
bb378:
  call void @__olang_scope_close(ptr %s67)
  br label %bb379
bb379:
  call void @__olang_scope_close(ptr %s65)
  br label %bb380
bb380:
  call void @__olang_scope_close(ptr %s60)
  br label %bb381
bb381:
  br label %bb322
bb382:
  %t1598 = load i64, ptr %l39, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t1598, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/load:Import"
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca %"compiler/load:Import"
  %l39 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sge i64 %t1, 4
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/load:Loader", ptr %t5, i32 0, i32 10
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t7, i64 %a2)
  store ptr %t11, ptr %l20
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 11
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load i64, ptr %l6, !tbaa !24
  store i64 %t16, ptr %l23, !tbaa !24
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l25
  br label %bb6
bb6:
  %t20 = load i64, ptr %l23, !tbaa !24
  %t21 = load i64, ptr %l25, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store %"compiler/load:Import" %t30, ptr %l30
  br label %bb10
bb10:
  %t31 = load %"compiler/load:Import", ptr %l30
  store %"compiler/load:Import" %t31, ptr %l7
  %t32 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t38 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %a3, 1
  %t42 = extractvalue { i64, ptr } %a3, 0
  %t44 = extractvalue { i64, ptr } %t39, 1
  %t45 = extractvalue { i64, ptr } %t39, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 10
  %t55 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t54, i64 %t56)
  store ptr %t59, ptr %l39
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t62 = getelementptr %"compiler/load:Module", ptr %t60, i32 0, i32 9
  store ptr %t62, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l10, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load ptr, ptr %l9, !tbaa !29
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = load i64, ptr %l44, !tbaa !24
  %t70 = icmp slt i64 %t68, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store { i64, ptr } %t78, ptr %l49
  br label %bb20
bb20:
  %t79 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/load:Loader", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s3, ptr %v0, ptr %t80, ptr %t84, { i64, ptr } %t85, { i64, ptr } %t79)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/load:Loader", ptr %t96, i32 0, i32 10
  %t99 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t100 = load i64, ptr %t99, !tbaa !24
  %t103 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t98, i64 %t100)
  store ptr %t103, ptr %l61
  br label %bb24
bb24:
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t106 = getelementptr %"compiler/load:Module", ptr %t104, i32 0, i32 10
  store ptr %t106, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t108 = load i64, ptr %l13, !tbaa !24
  store i64 %t108, ptr %l64, !tbaa !24
  %t109 = load ptr, ptr %l12, !tbaa !29
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l66
  br label %bb26
bb26:
  %t112 = load i64, ptr %l64, !tbaa !24
  %t113 = load i64, ptr %l66, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l12, !tbaa !29
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l71
  br label %bb30
bb30:
  %t123 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v1, ptr %v0, ptr %s3, ptr %v0, ptr %t124, ptr %t128, { i64, ptr } %t129, { i64, ptr } %t123)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l13, !tbaa !24
  br label %bb25
bb33:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = extractvalue { i64, ptr } %t144, 0
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = getelementptr i8, ptr %t151, i64 %t147
  call void @olang_textcopy(ptr %t152, ptr %t148, i64 %t149)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  %t156 = load i64, ptr %l4, !tbaa !24
  %t158 = add i64 %t156, 1
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %s3, ptr %t140, ptr %t141, i64 %t143, { i64, ptr } %t154, i64 %t158)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l6, !tbaa !24
  br label %bb5
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l62 = alloca i1
  %l73 = alloca i32
  %l82 = alloca i1
  %l85 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f27e16b36a34913f_9730f0a664aef8cb)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 %a2, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp slt i64 %t19, %a3
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb64
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load i64, ptr %l7, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 116}
  store i32 %t34, ptr %l8
  %t36 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t38 = trunc i64 110 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t43 = trunc i64 112 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t52 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t54 = trunc i64 111 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t57 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t59 = trunc i64 113 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l35, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = sub i64 %t63, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t68 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t70 = trunc i64 31 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t73 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t75 = trunc i64 37 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb25
bb24:
  %t79 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t81 = trunc i64 12 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb25
bb25:
  %t84 = load i1, ptr %l46, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t85 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t87 = trunc i64 79 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = icmp eq i64 %t90, 0
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load i1, ptr %l6, !tbaa !21
  %t97 = xor i1 %t95, true
  store i1 %t97, ptr %l54, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb35, label %bb36
bb35:
  %t100 = load i64, ptr %l7, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t102 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t104 = trunc i64 114 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb38, label %bb39
bb38:
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = icmp eq i64 %t107, 0
  br i1 %t109, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  %t111 = load i1, ptr %l6, !tbaa !21
  %t113 = xor i1 %t111, true
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb42
bb42:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb43, label %bb44
bb43:
  %t116 = load i64, ptr %l7, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 7
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = icmp eq ptr %t121, null
  br i1 %t123, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_f6bd06efaafe5f20_6d37165570c63ddc)
  unreachable
bb47:
  br label %bb48
bb48:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/load:Module", ptr %t125, i32 0, i32 7
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = load i64, ptr %l7, !tbaa !24
  %t131 = trunc i64 %t129 to i32
  %t134 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t128, i32 %t131)
  store i32 %t134, ptr %l73
  br label %bb49
bb49:
  %t135 = load i32, ptr %l73, !tbaa !23
  %t136 = sext i32 %t135 to i64
  store i64 %t136, ptr %l9, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp slt i64 %t138, 0
  br i1 %t140, label %bb50, label %bb51
bb50:
  store i64 -1, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  store i1 false, ptr %l6, !tbaa !21
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l7, !tbaa !24
  br label %bb63
bb53:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t149 = icmp sle i64 %t147, 0
  br i1 %t149, label %bb54, label %bb55
bb54:
  %t151 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t153 = trunc i64 8 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb59
bb56:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb58
bb57:
  %t156 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t158 = trunc i64 0 to i32
  %t159 = icmp eq i32 %t156, %t158
  store i1 %t159, ptr %l85, !tbaa !21
  br label %bb58
bb58:
  %t161 = load i1, ptr %l85, !tbaa !21
  store i1 %t161, ptr %l82, !tbaa !21
  br label %bb59
bb59:
  %t162 = load i1, ptr %l82, !tbaa !21
  br i1 %t162, label %bb60, label %bb61
bb60:
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l7, !tbaa !24
  br label %bb63
bb63:
  br label %bb4
bb64:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/cond:Decision" @compiler_2fload_2ecompiler_2fload_3aLoader_2eevalCond(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/cond:Decision"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { %"compiler/source:Span", %"compiler/diagmsg:Msg" }
  %l11 = alloca %"compiler/diagmsg:Msg"
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca %"compiler/cond:Decision"
  %l35 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca i1
  %l46 = alloca %"compiler/cond:Decision"
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l63 = alloca %"compiler/cond:Eval"
  %l67 = alloca %"compiler/cond:Decision"
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l105 = alloca { %"compiler/source:Span", %"compiler/diagmsg:Msg" }
  %l109 = alloca ptr
  %l113 = alloca { i64, [3 x i64] }
  %l115 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Decision"
  %t113 = alloca %"compiler/cond:Eval", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l15, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t9, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 27
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_10115782cae2d59a_b13624e5abc6764e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 27
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t27 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %v0, ptr %t23, i64 %a2)
  %t28 = extractvalue { i32, ptr } %t27, 1
  %t29 = extractvalue { i32, ptr } %t27, 0
  store i32 %t29, ptr %l26
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb7, label %ok.31, !prof !99
ok.31:
  store ptr %t28, ptr %l25
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l25, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  br label %bb10
bb7:
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s1, i32 2, i1 false)
  store %"compiler/cond:Decision" %t34, ptr %l28
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t35 = load %"compiler/cond:Decision", ptr %l28
  store %"compiler/cond:Decision" %t35, ptr %rv
  br label %ret
bb10:
  %t36 = load ptr, ptr %l18, !tbaa !29
  store ptr %t36, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/load:Module", ptr %t37, i32 0, i32 7
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5)
  unreachable
bb12:
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 7
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = getelementptr %"compiler/scan:Tokens", ptr %t47, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/load:Module", ptr %t52, i32 0, i32 27
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5)
  unreachable
bb15:
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 27
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l41
  br label %bb17
bb17:
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i64 %t65
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 116}
  %t72 = call i1 @compiler_2fload_2ebraceOrColon(i32 %t70)
  store i1 %t72, ptr %l43
  br label %bb18
bb18:
  %t73 = load i1, ptr %l43, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s2, i32 1, i1 false)
  store %"compiler/cond:Decision" %t77, ptr %l46
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  %t78 = load %"compiler/cond:Decision", ptr %l46
  store %"compiler/cond:Decision" %t78, ptr %rv
  br label %ret
bb22:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/load:Module", ptr %t79, i32 0, i32 6
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_b990dbcfbe082b6c_e09e9a90e433de0)
  unreachable
bb24:
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 6
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/source:Source", ptr %t89, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l53, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l55, !tbaa !29
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/load:Module", ptr %t98, i32 0, i32 26
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b990dbcfbe082b6c_e09e9a90e433de0)
  unreachable
bb27:
  br label %bb28
bb28:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = getelementptr %"compiler/load:Module", ptr %t105, i32 0, i32 26
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t115 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fcond_3aEval_2ector(ptr %t113, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t114, ptr %t115, ptr %t108, ptr %t112)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t113, i64 184, i1 false)
  br label %bb29
bb29:
  %t118 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %l63, i64 184, i1 false)
  store ptr %t118, ptr %l5, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t124 = call %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v0, ptr %t120, ptr %t121)
  store %"compiler/cond:Decision" %t124, ptr %l67
  br label %bb30
bb30:
  %t125 = load %"compiler/cond:Decision", ptr %l67
  store %"compiler/cond:Decision" %t125, ptr %l6
  %t126 = getelementptr %"compiler/cond:Decision", ptr %l6, i32 0, i32 0
  %t127 = load i32, ptr %t126, !range !{i32 0, i32 5}
  %t129 = trunc i64 0 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb31, label %bb32
bb31:
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t134 = call i1 @compiler_2fast_2eLitComparison(ptr %v0, ptr %t132)
  store i1 %t134, ptr %l72
  br label %bb33
bb32:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb34
bb33:
  %t135 = load i1, ptr %l72, !tbaa !21
  store i1 %t135, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t136 = load i1, ptr %l70, !tbaa !21
  br i1 %t136, label %bb35, label %bb36
bb35:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l74
  br label %bb37
bb36:
  br label %bb53
bb37:
  %t140 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t140, ptr %l7
  %t141 = getelementptr %"compiler/cond:Decision", ptr %l6, i32 0, i32 1
  %t142 = load i1, ptr %t141, !tbaa !21
  br i1 %t142, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb40
bb40:
  %t144 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/load:Loader", ptr %t145, i32 0, i32 4
  %t148 = load ptr, ptr %t147, !tbaa !29
  store ptr %t148, ptr %l78, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l7
  %t155 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t149, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, [3 x i64] } %t155, ptr %l82
  br label %bb41
bb41:
  %t156 = load ptr, ptr %l3, !tbaa !29
  %t158 = getelementptr %"compiler/load:Module", ptr %t156, i32 0, i32 6
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_834f60adf702f65b_ad4cc829cd9d3aff)
  unreachable
bb43:
  br label %bb44
bb44:
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t165 = getelementptr %"compiler/load:Module", ptr %t163, i32 0, i32 6
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t169 = getelementptr %"compiler/source:Source", ptr %t166, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l89, !tbaa !27
  %t171 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  store i64 %t174, ptr %l91, !tbaa !24
  %t175 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = sext i32 %t176 to i64
  store i64 %t178, ptr %l93, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l94, !tbaa !24
  %t181 = load i64, ptr %l91, !tbaa !24
  %t182 = icmp sge i64 %t181, 0
  br i1 %t182, label %bb45, label %bb46
bb45:
  %t184 = load i64, ptr %l91, !tbaa !24
  %t185 = load i64, ptr %l93, !tbaa !24
  %t186 = icmp sle i64 %t184, %t185
  br i1 %t186, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_98393be07dd60b4e_346d755782035a4a)
  unreachable
bb47:
  %t188 = load i64, ptr %l93, !tbaa !24
  %t189 = load i64, ptr %l94, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  br i1 %t190, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_98393be07dd60b4e_346d755782035a4a)
  unreachable
bb49:
  %t192 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l91, !tbaa !24
  %t195 = load i64, ptr %l93, !tbaa !24
  %t196 = getelementptr i8, ptr %t193, i64 %t194
  %t197 = sub i64 %t195, %t194
  %t198 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  %t200 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t201 = load ptr, ptr @__olang_prog_scope
  %t204 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLitCompare(ptr %v0, ptr %t201, ptr %v0, { i64, ptr } %t199, { i64, ptr } %t200)
  store %"compiler/diagmsg:Msg" %t204, ptr %l100
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_98393be07dd60b4e_346d755782035a4a)
  unreachable
bb51:
  %t205 = load ptr, ptr %l78, !tbaa !29
  %t206 = load { i64, [3 x i64] }, ptr %l82
  %t207 = load %"compiler/diagmsg:Msg", ptr %l100
  %t208 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t205, { i64, [3 x i64] } %t206, %"compiler/diagmsg:Msg" %t207)
  store i64 %t208, ptr %l101
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t209 = getelementptr %"compiler/cond:Decision", ptr %l6, i32 0, i32 0
  %t210 = load i32, ptr %t209, !range !{i32 0, i32 5}
  %t212 = trunc i64 2 to i32
  %t213 = icmp eq i32 %t210, %t212
  br i1 %t213, label %bb54, label %bb55
bb54:
  %t215 = load ptr, ptr %l5, !tbaa !29
  %t217 = call { %"compiler/source:Span", %"compiler/diagmsg:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v0, ptr %t215)
  store { %"compiler/source:Span", %"compiler/diagmsg:Msg" } %t217, ptr %l105
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t218 = load { %"compiler/source:Span", %"compiler/diagmsg:Msg" }, ptr %l105
  store { %"compiler/source:Span", %"compiler/diagmsg:Msg" } %t218, ptr %l9
  %t219 = getelementptr { %"compiler/source:Span", %"compiler/diagmsg:Msg" }, ptr %l9, i32 0, i32 0
  %t220 = load %"compiler/source:Span", ptr %t219
  %t222 = getelementptr { %"compiler/source:Span", %"compiler/diagmsg:Msg" }, ptr %l9, i32 0, i32 1
  %t223 = load %"compiler/diagmsg:Msg", ptr %t222
  store %"compiler/diagmsg:Msg" %t223, ptr %l11
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/load:Loader", ptr %t225, i32 0, i32 4
  %t228 = load ptr, ptr %t227, !tbaa !29
  store ptr %t228, ptr %l109, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l3, !tbaa !29
  %t235 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t229, ptr %t230, %"compiler/source:Span" %t220)
  store { i64, [3 x i64] } %t235, ptr %l113
  br label %bb57
bb57:
  %t236 = load %"compiler/diagmsg:Msg", ptr %l11
  %t237 = load ptr, ptr %l109, !tbaa !29
  %t238 = load { i64, [3 x i64] }, ptr %l113
  %t240 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t237, { i64, [3 x i64] } %t238, %"compiler/diagmsg:Msg" %t236)
  store i64 %t240, ptr %l115
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t241 = load %"compiler/cond:Decision", ptr %l6
  store %"compiler/cond:Decision" %t241, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eimportAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca %"compiler/load:Import"
  %l114 = alloca { i64, ptr }
  %l119 = alloca i1
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i64
  %l142 = alloca i1
  %l143 = alloca i1
  %l144 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca ptr
  %l160 = alloca i64
  %l168 = alloca { i64, ptr }
  %l171 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_88eba3596c4d138c_c1530d55fa80a9b0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t19 = add i64 %a2, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t22, ptr %lp6
  %t24 = load ptr, ptr %lp6
  store { i64, ptr } %t21, ptr %t24, !tbaa !27
  %t25 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t25, ptr %l22
  br label %bb4
bb4:
  %t26 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t26, ptr %l7
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 116}
  %t36 = trunc i64 1 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l27, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/token:Token", ptr %t43, i64 %t40
  %t45 = getelementptr %"compiler/token:Token", ptr %t44, i32 0, i32 2
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t47, ptr %l30, !tbaa !27
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/token:Token", ptr %t51, i64 %t48
  %t53 = getelementptr %"compiler/token:Token", ptr %t52, i32 0, i32 3
  %t54 = load i32, ptr %t53, !tbaa !23
  %t57 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t46, i32 %t54)
  store %"compiler/source:Span" %t57, ptr %l33
  br label %bb7
bb6:
  br label %bb25
bb7:
  %t58 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t58, ptr %l7
  %t59 = call ptr @__olang_scope_hold(ptr %v1)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l34, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t61, label %bb8, label %bb9
bb8:
  %t63 = call ptr @__olang_region_make(ptr %v1)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/load:Module", ptr %t65, i32 0, i32 6
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_17f5e01691795fb_80a050950937648f)
  unreachable
bb11:
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 6
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = getelementptr %"compiler/source:Source", ptr %t75, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l42, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l43, !tbaa !27
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr %"compiler/token:Token", ptr %t84, i64 %t81
  %t86 = getelementptr %"compiler/token:Token", ptr %t85, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  store i64 %t89, ptr %l46, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l47, !tbaa !27
  %t91 = load i64, ptr %l5, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/token:Token", ptr %t94, i64 %t91
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i32 0, i32 3
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  store i64 %t99, ptr %l50, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l51, !tbaa !24
  %t102 = load i64, ptr %l46, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb13, label %bb14
bb13:
  %t105 = load i64, ptr %l46, !tbaa !24
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb15:
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = load i64, ptr %l51, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb17:
  %t113 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l46, !tbaa !24
  %t116 = load i64, ptr %l50, !tbaa !24
  %t117 = getelementptr i8, ptr %t114, i64 %t115
  %t118 = sub i64 %t116, %t115
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = extractvalue { i64, ptr } %t120, 0
  %t124 = load i64, ptr %l34
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call ptr @__olang_held_alloc(ptr %t125, i64 %t123)
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t129, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb19:
  %t131 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t134 = icmp eq i64 %t132, 0
  br i1 %t134, label %bb21, label %bb22
bb20:
  %t136 = load ptr, ptr %lp6
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l60, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t139 = load ptr, ptr %lp6
  store { i64, ptr } %t138, ptr %t139, !tbaa !27
  %t140 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t140, label %bb23, label %bb24
bb21:
  store { i64, ptr } zeroinitializer, ptr %l56, !tbaa !27
  br label %bb22
bb22:
  %t142 = load i64, ptr %l34
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = load { i64, ptr }, ptr %l56
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr null)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr null
  call void @__olang_region_settle_in(ptr %t143, ptr %t148)
  br label %bb20
bb23:
  %t149 = load { i64, ptr }, ptr %l60
  %t150 = extractvalue { i64, ptr } %t149, 1
  call void @__olang_region_release(ptr %t150)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %bb24
bb24:
  %t151 = load i64, ptr %l5, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb25:
  %t156 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t156, ptr %l65, !tbaa !27
  %t157 = load i64, ptr %l5, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr %"compiler/token:Token", ptr %t160, i64 %t157
  %t162 = getelementptr %"compiler/token:Token", ptr %t161, i32 0, i32 0
  %t163 = load i32, ptr %t162, !range !{i32 0, i32 116}
  %t165 = trunc i64 5 to i32
  %t166 = icmp eq i32 %t163, %t165
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  br label %bb28
bb28:
  %t170 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t170, ptr %l70, !tbaa !27
  %t171 = load i64, ptr %l5, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr %"compiler/token:Token", ptr %t174, i64 %t171
  %t176 = getelementptr %"compiler/token:Token", ptr %t175, i32 0, i32 2
  %t177 = load i32, ptr %t176, !tbaa !23
  %t178 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t178, ptr %l73, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr %"compiler/token:Token", ptr %t182, i64 %t179
  %t184 = getelementptr %"compiler/token:Token", ptr %t183, i32 0, i32 3
  %t185 = load i32, ptr %t184, !tbaa !23
  %t188 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t177, i32 %t185)
  store %"compiler/source:Span" %t188, ptr %l76
  br label %bb29
bb29:
  %t189 = load %"compiler/source:Span", ptr %l76
  store %"compiler/source:Span" %t189, ptr %l8
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr %"compiler/load:Module", ptr %t190, i32 0, i32 6
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  br i1 %t195, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3753a1d7262b2cc1_bd09a853d1b85305)
  unreachable
bb31:
  br label %bb32
bb32:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 6
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t203 = getelementptr %"compiler/source:Source", ptr %t200, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l83, !tbaa !27
  %t205 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = sext i32 %t206 to i64
  store i64 %t208, ptr %l85, !tbaa !24
  %t209 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  store i64 %t212, ptr %l87, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l88, !tbaa !24
  %t215 = load i64, ptr %l85, !tbaa !24
  %t216 = icmp sge i64 %t215, 0
  br i1 %t216, label %bb33, label %bb34
bb33:
  %t218 = load i64, ptr %l85, !tbaa !24
  %t219 = load i64, ptr %l87, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb35:
  %t222 = load i64, ptr %l87, !tbaa !24
  %t223 = load i64, ptr %l88, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb37:
  %t226 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l85, !tbaa !24
  %t229 = load i64, ptr %l87, !tbaa !24
  %t230 = getelementptr i8, ptr %t227, i64 %t228
  %t231 = sub i64 %t229, %t228
  %t232 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t235 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v1, ptr %v1, { i64, ptr } %t233)
  store { i64, ptr } %t235, ptr %l93
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb39:
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t236, ptr %lp9
  %t237 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t238 = load ptr, ptr %lp9
  store { i64, ptr } %t237, ptr %t238, !tbaa !27
  %t239 = load ptr, ptr %lp6
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t240, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t242, ptr %l95
  br label %bb40
bb40:
  %t243 = load i1, ptr %l95, !tbaa !21
  br i1 %t243, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s4
  %t244 = call ptr @__olang_scope_hold(ptr %v1)
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l96, !tbaa !24
  %t246 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t246, label %bb43, label %bb44
bb42:
  br label %bb52
bb43:
  %t248 = call ptr @__olang_region_make(ptr %v1)
  %t249 = ptrtoint ptr %t248 to i64
  store i64 %t249, ptr %l96, !tbaa !24
  br label %bb44
bb44:
  %t250 = load ptr, ptr %lp9
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t253 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v1, ptr %s4, { i64, ptr } %t251)
  store { i64, ptr } %t253, ptr %l99
  br label %bb45
bb45:
  %t254 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = load i64, ptr %l96
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = call ptr @__olang_held_alloc(ptr %t258, i64 %t256)
  call void @olang_textcopy(ptr %t259, ptr %t255, i64 %t256)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l100, !tbaa !27
  %t262 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t262, label %bb46, label %bb47
bb46:
  %t264 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t267 = icmp eq i64 %t265, 0
  br i1 %t267, label %bb48, label %bb49
bb47:
  %t269 = load ptr, ptr %lp6
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l104, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t272 = load ptr, ptr %lp6
  store { i64, ptr } %t271, ptr %t272, !tbaa !27
  %t273 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6
  br i1 %t273, label %bb50, label %bb51
bb48:
  store { i64, ptr } zeroinitializer, ptr %l100, !tbaa !27
  br label %bb49
bb49:
  %t275 = load i64, ptr %l96
  %t276 = inttoptr i64 %t275 to ptr
  %t277 = load { i64, ptr }, ptr %l100
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = call ptr @__olang_region_or(ptr %t278, ptr null)
  %t280 = icmp ne ptr %t279, null
  %t281 = select i1 %t280, ptr %t279, ptr null
  call void @__olang_region_settle_in(ptr %t276, ptr %t281)
  br label %bb47
bb50:
  %t282 = load { i64, ptr }, ptr %l104
  %t283 = extractvalue { i64, ptr } %t282, 1
  call void @__olang_region_release(ptr %t283)
  store { i64, ptr } zeroinitializer, ptr %l104
  br label %bb51
bb51:
  %t284 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t284, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb52:
  %t286 = load %"compiler/source:Span", ptr %l8
  %t287 = load %"compiler/source:Span", ptr %l7
  %t288 = load ptr, ptr %lp6
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  %t290 = load ptr, ptr %lp9
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  %t298 = call %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t286, %"compiler/source:Span" %t287, { i64, ptr } %t289, { i64, ptr } %t291, i64 %a3)
  store %"compiler/load:Import" %t298, ptr %l112
  br label %bb53
bb53:
  %t299 = load %"compiler/load:Import", ptr %l112
  %t300 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/load:Import" %t299, ptr %t300
  store ptr %t300, ptr %l10, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t302, ptr %l114, !tbaa !27
  %t303 = load i64, ptr %l5, !tbaa !24
  %t305 = add i64 %t303, 1
  %t307 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr %"compiler/token:Token", ptr %t308, i64 %t305
  %t310 = getelementptr %"compiler/token:Token", ptr %t309, i32 0, i32 0
  %t311 = load i32, ptr %t310, !range !{i32 0, i32 116}
  %t313 = trunc i64 1 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb54, label %bb55
bb54:
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr %"compiler/load:Module", ptr %t316, i32 0, i32 6
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb66
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8e32ae472cd64327_c149890ad1056c3)
  unreachable
bb57:
  br label %bb58
bb58:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr %"compiler/load:Module", ptr %t323, i32 0, i32 6
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t329 = getelementptr %"compiler/source:Source", ptr %t326, i32 0, i32 1
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  store { i64, ptr } %t330, ptr %l126, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t331, ptr %l127, !tbaa !27
  %t332 = load i64, ptr %l5, !tbaa !24
  %t334 = add i64 %t332, 1
  %t336 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr %"compiler/token:Token", ptr %t337, i64 %t334
  %t339 = getelementptr %"compiler/token:Token", ptr %t338, i32 0, i32 2
  %t340 = load i32, ptr %t339, !tbaa !23
  %t342 = sext i32 %t340 to i64
  store i64 %t342, ptr %l131, !tbaa !24
  %t343 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t343, ptr %l132, !tbaa !27
  %t344 = load i64, ptr %l5, !tbaa !24
  %t346 = add i64 %t344, 1
  %t348 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr %"compiler/token:Token", ptr %t349, i64 %t346
  %t351 = getelementptr %"compiler/token:Token", ptr %t350, i32 0, i32 3
  %t352 = load i32, ptr %t351, !tbaa !23
  %t354 = sext i32 %t352 to i64
  store i64 %t354, ptr %l136, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  store i64 %t356, ptr %l137, !tbaa !24
  %t357 = load i64, ptr %l131, !tbaa !24
  %t358 = icmp sge i64 %t357, 0
  br i1 %t358, label %bb59, label %bb60
bb59:
  %t360 = load i64, ptr %l131, !tbaa !24
  %t361 = load i64, ptr %l136, !tbaa !24
  %t362 = icmp sle i64 %t360, %t361
  br i1 %t362, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_a448ee53d606ecee_601f65a9d3b58c7a)
  unreachable
bb61:
  %t364 = load i64, ptr %l136, !tbaa !24
  %t365 = load i64, ptr %l137, !tbaa !24
  %t366 = icmp sle i64 %t364, %t365
  br i1 %t366, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a448ee53d606ecee_601f65a9d3b58c7a)
  unreachable
bb63:
  %t368 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = load i64, ptr %l131, !tbaa !24
  %t371 = load i64, ptr %l136, !tbaa !24
  %t372 = getelementptr i8, ptr %t369, i64 %t370
  %t373 = sub i64 %t371, %t370
  %t374 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t372, 1
  %t377 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t375, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t377, ptr %l142
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_a448ee53d606ecee_601f65a9d3b58c7a)
  unreachable
bb65:
  %t378 = load i1, ptr %l142, !tbaa !21
  store i1 %t378, ptr %l119, !tbaa !21
  br label %bb66
bb66:
  %t379 = load i1, ptr %l119, !tbaa !21
  br i1 %t379, label %bb67, label %bb68
bb67:
  %t380 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t380, ptr %l144, !tbaa !27
  %t381 = load i64, ptr %l5, !tbaa !24
  %t383 = add i64 %t381, 2
  %t385 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr %"compiler/token:Token", ptr %t386, i64 %t383
  %t388 = getelementptr %"compiler/token:Token", ptr %t387, i32 0, i32 0
  %t389 = load i32, ptr %t388, !range !{i32 0, i32 116}
  %t391 = trunc i64 5 to i32
  %t392 = icmp eq i32 %t389, %t391
  store i1 %t392, ptr %l143, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb69
bb69:
  %t394 = load i1, ptr %l143, !tbaa !21
  br i1 %t394, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s6
  %t395 = load ptr, ptr %l10, !tbaa !29
  store ptr %t395, ptr %l149, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t396, ptr %l150, !tbaa !27
  %t397 = load i64, ptr %l5, !tbaa !24
  %t399 = add i64 %t397, 2
  %t401 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr %"compiler/token:Token", ptr %t402, i64 %t399
  %t404 = getelementptr %"compiler/token:Token", ptr %t403, i32 0, i32 2
  %t405 = load i32, ptr %t404, !tbaa !23
  %t406 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t406, ptr %l154, !tbaa !27
  %t407 = load i64, ptr %l5, !tbaa !24
  %t409 = add i64 %t407, 2
  %t411 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr %"compiler/token:Token", ptr %t412, i64 %t409
  %t414 = getelementptr %"compiler/token:Token", ptr %t413, i32 0, i32 3
  %t415 = load i32, ptr %t414, !tbaa !23
  %t418 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t405, i32 %t415)
  store %"compiler/source:Span" %t418, ptr %l158
  br label %bb72
bb71:
  br label %bb87
bb72:
  %t419 = load %"compiler/source:Span", ptr %l158
  %t420 = load ptr, ptr %l149, !tbaa !29
  %t421 = getelementptr %"compiler/load:Import", ptr %t420, i32 0, i32 7
  store %"compiler/source:Span" %t419, ptr %t421
  %t422 = load ptr, ptr %l10, !tbaa !29
  store ptr %t422, ptr %l159, !tbaa !29
  %t423 = call ptr @__olang_scope_hold(ptr %v1)
  %t424 = ptrtoint ptr %t423 to i64
  store i64 %t424, ptr %l160, !tbaa !24
  %t425 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aImport_2e6
  br i1 %t425, label %bb73, label %bb74
bb73:
  %t427 = call ptr @__olang_region_make(ptr %v1)
  %t428 = ptrtoint ptr %t427 to i64
  store i64 %t428, ptr %l160, !tbaa !24
  br label %bb74
bb74:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr %"compiler/load:Module", ptr %t429, i32 0, i32 6
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = icmp eq ptr %t432, null
  br i1 %t434, label %bb75, label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_7e96417109578add_9add255974295329)
  unreachable
bb76:
  br label %bb77
bb77:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr %"compiler/load:Module", ptr %t436, i32 0, i32 6
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t442 = getelementptr %"compiler/source:Source", ptr %t439, i32 0, i32 1
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  store { i64, ptr } %t443, ptr %l168, !tbaa !27
  %t444 = load ptr, ptr %l10, !tbaa !29
  %t446 = getelementptr %"compiler/load:Import", ptr %t444, i32 0, i32 7
  %t447 = getelementptr %"compiler/source:Span", ptr %t446, i32 0, i32 0
  %t448 = load i32, ptr %t447, !tbaa !23
  %t450 = sext i32 %t448 to i64
  store i64 %t450, ptr %l171, !tbaa !24
  %t451 = load ptr, ptr %l10, !tbaa !29
  %t453 = getelementptr %"compiler/load:Import", ptr %t451, i32 0, i32 7
  %t454 = getelementptr %"compiler/source:Span", ptr %t453, i32 0, i32 1
  %t455 = load i32, ptr %t454, !tbaa !23
  %t457 = sext i32 %t455 to i64
  store i64 %t457, ptr %l174, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  store i64 %t459, ptr %l175, !tbaa !24
  %t460 = load i64, ptr %l171, !tbaa !24
  %t461 = icmp sge i64 %t460, 0
  br i1 %t461, label %bb78, label %bb79
bb78:
  %t463 = load i64, ptr %l171, !tbaa !24
  %t464 = load i64, ptr %l174, !tbaa !24
  %t465 = icmp sle i64 %t463, %t464
  br i1 %t465, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_7fc0c111e9e5248c_f920a424be87ad0)
  unreachable
bb80:
  %t467 = load i64, ptr %l174, !tbaa !24
  %t468 = load i64, ptr %l175, !tbaa !24
  %t469 = icmp sle i64 %t467, %t468
  br i1 %t469, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_7fc0c111e9e5248c_f920a424be87ad0)
  unreachable
bb82:
  %t471 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = load i64, ptr %l171, !tbaa !24
  %t474 = load i64, ptr %l174, !tbaa !24
  %t475 = getelementptr i8, ptr %t472, i64 %t473
  %t476 = sub i64 %t474, %t473
  %t477 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t475, 1
  %t480 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v1, ptr %s6, { i64, ptr } %t478)
  store { i64, ptr } %t480, ptr %l180
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_7fc0c111e9e5248c_f920a424be87ad0)
  unreachable
bb84:
  %t481 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = load i64, ptr %l160
  %t485 = inttoptr i64 %t484 to ptr
  %t486 = call ptr @__olang_held_alloc(ptr %t485, i64 %t483)
  call void @olang_textcopy(ptr %t486, ptr %t482, i64 %t483)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t490 = load ptr, ptr %l159, !tbaa !29
  %t491 = getelementptr %"compiler/load:Import", ptr %t490, i32 0, i32 6
  %t492 = load { i64, ptr }, ptr %t491, !tbaa !27
  store { i64, ptr } %t492, ptr %l183, !tbaa !27
  %t494 = load ptr, ptr %l159, !tbaa !29
  %t495 = getelementptr %"compiler/load:Import", ptr %t494, i32 0, i32 6
  store { i64, ptr } %t488, ptr %t495, !tbaa !27
  %t496 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aImport_2e6
  br i1 %t496, label %bb85, label %bb86
bb85:
  %t498 = load { i64, ptr }, ptr %l183
  %t499 = extractvalue { i64, ptr } %t498, 1
  call void @__olang_region_release(ptr %t499)
  store { i64, ptr } zeroinitializer, ptr %l183
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb87:
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr %"compiler/load:Module", ptr %t500, i32 0, i32 11
  %t503 = load ptr, ptr %l10, !tbaa !29
  %t505 = load %"compiler/load:Import", ptr %t503
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v1, ptr %v1, ptr %t502, %"compiler/load:Import" %t505)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/scan:Diag"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l67 = alloca ptr
  %l71 = alloca i1
  %l78 = alloca i64
  %l80 = alloca ptr
  %l85 = alloca %"compiler/load:Module"
  %l90 = alloca ptr
  %l92 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i64
  %l100 = alloca %"compiler/source:Source"
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i32
  %l123 = alloca %"compiler/source:Source"
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca %"compiler/source:Source"
  %l133 = alloca %"compiler/source:Source"
  %l134 = alloca i32
  %l136 = alloca i1
  %l143 = alloca i64
  %l145 = alloca ptr
  %l147 = alloca { i64, [3 x i64] }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %l157 = alloca ptr
  %l161 = alloca ptr
  %l163 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l175 = alloca i1
  %l176 = alloca i1
  %l178 = alloca i64
  %l179 = alloca ptr
  %l187 = alloca %"compiler/scan:Tokens"
  %l202 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l214 = alloca { i64, [3 x i64] }
  %l215 = alloca i32
  %l217 = alloca { i64, ptr }
  %l218 = alloca i64
  %l221 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l228 = alloca i64
  %l231 = alloca { i64, ptr }
  %l233 = alloca %"compiler/diagmsg:Msg"
  %l234 = alloca i64
  %l240 = alloca ptr
  %l241 = alloca i64
  %l243 = alloca %"compiler/parse:Oracle"
  %l245 = alloca ptr
  %l249 = alloca ptr
  %l255 = alloca ptr
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t130 = alloca %"compiler/load:Module", align 8
  %t297 = alloca { i64, [3 x i64] }, align 8
  %t455 = alloca { i64, [3 x i64] }, align 8
  %t554 = alloca %"compiler/parse:Oracle", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l26
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l25
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t8, ptr %l23, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l26, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb6
bb6:
  %t14 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t17, ptr %l30
  br label %bb7
bb7:
  %t18 = load i1, ptr %l30, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l32, !tbaa !27
  br label %bb10
bb9:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = extractvalue { i64, ptr } %t29, 0
  %t33 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t31, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l32, !tbaa !27
  br label %bb10
bb10:
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t37, ptr %lp7
  %t38 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t39 = load ptr, ptr %lp7
  store { i64, ptr } %t38, ptr %t39, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 10
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l39
  br label %bb11
bb11:
  %t45 = load i64, ptr %l39, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb17
bb14:
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l10, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l46, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l46, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l43, !tbaa !24
  store i64 %t73, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb18
bb18:
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l13, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/load:Loader", ptr %t92, i32 0, i32 10
  %t95 = load i64, ptr %l13, !tbaa !24
  %t98 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t94, i64 %t95)
  store ptr %t98, ptr %l67
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l67, !tbaa !29
  %t101 = getelementptr %"compiler/load:Module", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t103 = load ptr, ptr %lp7
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t102, { i64, ptr } %t104)
  store i1 %t107, ptr %l71
  br label %bb23
bb23:
  %t108 = load i1, ptr %l71, !tbaa !21
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t109 = load i64, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t109, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l12, !tbaa !24
  br label %bb18
bb28:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 10
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t118)
  store i64 %t120, ptr %l78
  br label %bb29
bb29:
  %t121 = load i64, ptr %l78, !tbaa !24
  store i64 %t121, ptr %l14, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 10
  store ptr %t124, ptr %l80, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = load ptr, ptr %lp7
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  call void @compiler_2fload_3aModule_2ector(ptr %t130, ptr %v1, ptr %v0, ptr %v2, ptr %v0, { i64, ptr } %t125, { i64, ptr } %t127, { i64, ptr } %a2, i1 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l85, ptr %t130, i64 864, i1 false)
  br label %bb30
bb30:
  %t135 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 864, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t135, ptr %l85, i64 864, i1 false)
  %t136 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hadc5a27c7dd302cda1d0e8a7732d6686(ptr %v0, ptr %v0, ptr %t136, ptr %t135)
  br label %bb31
bb31:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/load:Loader", ptr %t138, i32 0, i32 10
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l90
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l90, !tbaa !29
  store ptr %t145, ptr %l15, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t148, ptr %l92
  br label %bb33
bb33:
  %t149 = load i1, ptr %l92, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb34, label %bb35
bb34:
  %t152 = load ptr, ptr %l15, !tbaa !29
  store ptr %t152, ptr %l94, !tbaa !29
  %t153 = call ptr @__olang_scope_hold(ptr %v0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l95, !tbaa !24
  %t155 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t155, label %bb36, label %bb37
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t157 = load ptr, ptr %lp7
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l104, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l105, !tbaa !24
  %t161 = load i64, ptr %l105, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l106, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l105, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 13
  %t179 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s8, ptr %t175, { i64, ptr } %t172)
  store i1 %t179, ptr %l110
  br label %bb41
bb36:
  %t180 = call ptr @__olang_region_make(ptr %v0)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l95, !tbaa !24
  br label %bb37
bb37:
  %t182 = load ptr, ptr %l15, !tbaa !29
  %t184 = getelementptr %"compiler/load:Module", ptr %t182, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t187 = load i64, ptr %l95
  %t188 = inttoptr i64 %t187 to ptr
  %t191 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v3, ptr %t188, { i64, ptr } %t185, { i64, ptr } %t186)
  store %"compiler/source:Source" %t191, ptr %l100
  br label %bb38
bb38:
  %t192 = load %"compiler/source:Source", ptr %l100
  %t193 = load i64, ptr %l95
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = call ptr @__olang_scope_alloc_a(ptr %t194, i64 48, i64 8)
  store %"compiler/source:Source" %t192, ptr %t195
  %t196 = load ptr, ptr %l94, !tbaa !29
  %t197 = getelementptr %"compiler/load:Module", ptr %t196, i32 0, i32 6
  %t198 = load ptr, ptr %t197, !tbaa !29
  store ptr %t198, ptr %l102, !tbaa !29
  %t200 = load ptr, ptr %l94, !tbaa !29
  %t201 = getelementptr %"compiler/load:Module", ptr %t200, i32 0, i32 6
  store ptr %t195, ptr %t201, !tbaa !29
  %t202 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t202, label %bb39, label %bb40
bb39:
  %t204 = load ptr, ptr %l102
  call void @__olang_region_release(ptr %t204)
  store ptr null, ptr %l102
  br label %bb40
bb40:
  br label %bb72
bb41:
  %t205 = load i1, ptr %l110, !tbaa !21
  br i1 %t205, label %bb42, label %bb43
bb42:
  %t206 = load ptr, ptr %l15, !tbaa !29
  store ptr %t206, ptr %l111, !tbaa !29
  %t207 = call ptr @__olang_scope_hold(ptr %v0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l112, !tbaa !24
  %t209 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t209, label %bb44, label %bb45
bb43:
  %t211 = load ptr, ptr %l15, !tbaa !29
  store ptr %t211, ptr %l127, !tbaa !29
  %t212 = call ptr @__olang_scope_hold(ptr %v0)
  %t213 = ptrtoint ptr %t212 to i64
  store i64 %t213, ptr %l128, !tbaa !24
  %t214 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t214, label %bb54, label %bb55
bb44:
  %t216 = call ptr @__olang_region_make(ptr %v0)
  %t217 = ptrtoint ptr %t216 to i64
  store i64 %t217, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t218 = load ptr, ptr %l15, !tbaa !29
  %t220 = getelementptr %"compiler/load:Module", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l115, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 13
  %t225 = load ptr, ptr %lp7
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t229 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t224, { i64, ptr } %t226)
  %t230 = extractvalue { i32, { i64, ptr } } %t229, 1
  %t231 = extractvalue { i32, { i64, ptr } } %t229, 0
  store i32 %t231, ptr %l121
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb47, label %ok.233, !prof !99
ok.233:
  store { i64, ptr } %t230, ptr %l120
  br label %bb46
bb46:
  %t234 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t234, ptr %l116, !tbaa !27
  br label %bb50
bb47:
  %t235 = load i32, ptr %l121, !tbaa !23
  %t236 = icmp eq i32 %t235, 65536
  br i1 %t236, label %bb48, label %bb49
bb48:
  call void @__olang_bang_failed_plain(ptr @olang_loc_67b56c0a83b8bd03_8d743f7b3592caff)
  unreachable
bb49:
  call void @__olang_bang_failed_plain(ptr @olang_loc_867763f6879c47c1_85ff3e3f6e82a415)
  unreachable
bb50:
  %t238 = load i64, ptr %l112
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t242 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v0, ptr %t239, { i64, ptr } %t240, { i64, ptr } %t241)
  store %"compiler/source:Source" %t242, ptr %l123
  br label %bb51
bb51:
  %t243 = load %"compiler/source:Source", ptr %l123
  %t244 = load i64, ptr %l112
  %t245 = inttoptr i64 %t244 to ptr
  %t246 = call ptr @__olang_scope_alloc_a(ptr %t245, i64 48, i64 8)
  store %"compiler/source:Source" %t243, ptr %t246
  %t247 = load ptr, ptr %l111, !tbaa !29
  %t248 = getelementptr %"compiler/load:Module", ptr %t247, i32 0, i32 6
  %t249 = load ptr, ptr %t248, !tbaa !29
  store ptr %t249, ptr %l125, !tbaa !29
  %t251 = load ptr, ptr %l111, !tbaa !29
  %t252 = getelementptr %"compiler/load:Module", ptr %t251, i32 0, i32 6
  store ptr %t246, ptr %t252, !tbaa !29
  %t253 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t253, label %bb52, label %bb53
bb52:
  %t255 = load ptr, ptr %l125
  call void @__olang_region_release(ptr %t255)
  store ptr null, ptr %l125
  br label %bb53
bb53:
  br label %bb71
bb54:
  %t256 = call ptr @__olang_region_make(ptr %v0)
  %t257 = ptrtoint ptr %t256 to i64
  store i64 %t257, ptr %l128, !tbaa !24
  br label %bb55
bb55:
  %t258 = load ptr, ptr %l15, !tbaa !29
  %t260 = getelementptr %"compiler/load:Module", ptr %t258, i32 0, i32 0
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l128
  %t263 = inttoptr i64 %t262 to ptr
  %t265 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eSource_2eRead(ptr %v0, ptr %t263, { i64, ptr } %t261)
  %t266 = extractvalue { i32, %"compiler/source:Source" } %t265, 1
  %t267 = extractvalue { i32, %"compiler/source:Source" } %t265, 0
  store i32 %t267, ptr %l134
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb57, label %ok.269, !prof !99
ok.269:
  store %"compiler/source:Source" %t266, ptr %l133
  br label %bb56
bb56:
  %t270 = load %"compiler/source:Source", ptr %l133
  store %"compiler/source:Source" %t270, ptr %l130
  br label %bb68
bb57:
  %t271 = load i32, ptr %l134, !tbaa !23
  %t272 = ashr i32 %t271, 16
  %t274 = icmp eq i32 %t272, 1
  store i1 %t274, ptr %l136, !tbaa !21
  %t275 = load i32, ptr %l134, !tbaa !23
  %t276 = ashr i32 %t275, 16
  %t278 = icmp eq i32 %t276, 1
  br i1 %t278, label %bb58, label %bb59
bb58:
  call void @__olang_errpay_pop()
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load ptr, ptr %l15, !tbaa !29
  %t286 = getelementptr %"compiler/load:Module", ptr %t284, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t290 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t283, { i64, ptr } %t287, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d156, i32 0, i32 1) }, i1 false)
  store i64 %t290, ptr %l143
  br label %bb61
bb61:
  %t291 = load i64, ptr %l143, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/load:Loader", ptr %t292, i32 0, i32 4
  %t295 = load ptr, ptr %t294, !tbaa !29
  store ptr %t295, ptr %l145, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t297
  %t298 = getelementptr { i64, [3 x i64] }, ptr %t297, i32 0, i32 0
  store i64 1, ptr %t298
  %t300 = insertvalue { i64 } undef, i64 %t291, 0
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t297, i32 0, i32 1
  store { i64 } %t300, ptr %t301
  %t302 = load { i64, [3 x i64] }, ptr %t297
  store { i64, [3 x i64] } %t302, ptr %l147
  %t303 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
  store %"compiler/diagmsg:Msg" %t303, ptr %l148
  br label %bb62
bb62:
  %t304 = load ptr, ptr %l145, !tbaa !29
  %t305 = load { i64, [3 x i64] }, ptr %l147
  %t306 = load %"compiler/diagmsg:Msg", ptr %l148
  %t307 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t304, { i64, [3 x i64] } %t305, %"compiler/diagmsg:Msg" %t306)
  store i64 %t307, ptr %l149
  br label %bb63
bb63:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/load:Loader", ptr %t308, i32 0, i32 10
  %t312 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H30b952b85dc190b6cd5306b9d98a7749(ptr %v0, ptr %v0, ptr %t310)
  %t313 = extractvalue { i32, ptr } %t312, 1
  %t314 = extractvalue { i32, ptr } %t312, 0
  store i32 %t314, ptr %l154
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb65, label %ok.316, !prof !99
ok.316:
  store ptr %t313, ptr %l153
  br label %bb64
bb64:
  %t317 = load ptr, ptr %l153, !tbaa !29
  store ptr %t317, ptr %l150, !tbaa !29
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb68:
  %t319 = load %"compiler/source:Source", ptr %l130
  %t320 = load i64, ptr %l128
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = call ptr @__olang_scope_alloc_a(ptr %t321, i64 48, i64 8)
  store %"compiler/source:Source" %t319, ptr %t322
  %t323 = load ptr, ptr %l127, !tbaa !29
  %t324 = getelementptr %"compiler/load:Module", ptr %t323, i32 0, i32 6
  %t325 = load ptr, ptr %t324, !tbaa !29
  store ptr %t325, ptr %l157, !tbaa !29
  %t327 = load ptr, ptr %l127, !tbaa !29
  %t328 = getelementptr %"compiler/load:Module", ptr %t327, i32 0, i32 6
  store ptr %t322, ptr %t328, !tbaa !29
  %t329 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e6
  br i1 %t329, label %bb69, label %bb70
bb69:
  %t331 = load ptr, ptr %l157
  call void @__olang_region_release(ptr %t331)
  store ptr null, ptr %l157
  br label %bb70
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb72:
  %t332 = load ptr, ptr %l15, !tbaa !29
  %t333 = load i1, ptr %l4, !tbaa !21
  %t336 = getelementptr %"compiler/load:Module", ptr %t332, i32 0, i32 33
  store i1 %t333, ptr %t336, !tbaa !21
  %t337 = load ptr, ptr %l15, !tbaa !29
  store ptr %t337, ptr %l161, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/load:Loader", ptr %t338, i32 0, i32 4
  %t341 = load ptr, ptr %t340, !tbaa !29
  store ptr %t341, ptr %l163, !tbaa !29
  %t342 = load ptr, ptr %l15, !tbaa !29
  %t344 = getelementptr %"compiler/load:Module", ptr %t342, i32 0, i32 0
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  store { i64, ptr } %t345, ptr %l165, !tbaa !27
  %t346 = load ptr, ptr %l15, !tbaa !29
  %t348 = getelementptr %"compiler/load:Module", ptr %t346, i32 0, i32 6
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = icmp eq ptr %t349, null
  br i1 %t351, label %bb73, label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_bf0719959bfa757a_6a83aba191150c56)
  unreachable
bb74:
  br label %bb75
bb75:
  %t353 = load ptr, ptr %l15, !tbaa !29
  %t355 = getelementptr %"compiler/load:Module", ptr %t353, i32 0, i32 6
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t359 = getelementptr %"compiler/source:Source", ptr %t356, i32 0, i32 1
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l172, !tbaa !27
  %t361 = load ptr, ptr %l15, !tbaa !29
  %t363 = getelementptr %"compiler/load:Module", ptr %t361, i32 0, i32 2
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  %t366 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t364, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d157, i32 0, i32 1) })
  store i1 %t366, ptr %l175
  br label %bb76
bb76:
  %t367 = load i1, ptr %l175, !tbaa !21
  br i1 %t367, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb79
bb78:
  %t368 = load i1, ptr %l4, !tbaa !21
  store i1 %t368, ptr %l176, !tbaa !21
  br label %bb79
bb79:
  %t370 = load ptr, ptr %l163, !tbaa !29
  %t371 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t373 = load i1, ptr %l176, !tbaa !21
  %t374 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t370, { i64, ptr } %t371, { i64, ptr } %t372, i1 %t373)
  store i64 %t374, ptr %l178
  br label %bb80
bb80:
  %t375 = load i64, ptr %l178, !tbaa !24
  %t376 = load ptr, ptr %l161, !tbaa !29
  %t377 = getelementptr %"compiler/load:Module", ptr %t376, i32 0, i32 4
  store i64 %t375, ptr %t377, !tbaa !24
  %t378 = load ptr, ptr %l15, !tbaa !29
  store ptr %t378, ptr %l179, !tbaa !29
  %t379 = load ptr, ptr %l15, !tbaa !29
  %t381 = getelementptr %"compiler/load:Module", ptr %t379, i32 0, i32 6
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t384 = icmp eq ptr %t382, null
  br i1 %t384, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_97fda29c929b9401_a297b77e137a783d)
  unreachable
bb82:
  br label %bb83
bb83:
  %t386 = load ptr, ptr %l15, !tbaa !29
  %t388 = getelementptr %"compiler/load:Module", ptr %t386, i32 0, i32 6
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t392 = getelementptr %"compiler/source:Source", ptr %t389, i32 0, i32 1
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  %t395 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v0, { i64, ptr } %t393)
  store %"compiler/scan:Tokens" %t395, ptr %l187
  br label %bb84
bb84:
  %t396 = load %"compiler/scan:Tokens", ptr %l187
  %t397 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/scan:Tokens" %t396, ptr %t397
  %t399 = load ptr, ptr %l179, !tbaa !29
  %t400 = getelementptr %"compiler/load:Module", ptr %t399, i32 0, i32 7
  store ptr %t397, ptr %t400, !tbaa !29
  %t401 = load ptr, ptr %l15, !tbaa !29
  %t403 = getelementptr %"compiler/load:Module", ptr %t401, i32 0, i32 7
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  br i1 %t406, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_8eb73d0fe26fae48_56cde13f0d79d76c)
  unreachable
bb86:
  br label %bb87
bb87:
  %t408 = load ptr, ptr %l15, !tbaa !29
  %t410 = getelementptr %"compiler/load:Module", ptr %t408, i32 0, i32 7
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t414 = getelementptr %"compiler/scan:Tokens", ptr %t411, i32 0, i32 3
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  store { i64, ptr } %t415, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t417 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  store i64 %t419, ptr %l20, !tbaa !24
  br label %bb88
bb88:
  %t421 = load i64, ptr %l19, !tbaa !24
  %t422 = load i64, ptr %l20, !tbaa !24
  %t425 = icmp slt i64 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb89, label %bb90
bb89:
  br label %bb105
bb90:
  br label %bb91
bb91:
  %t429 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t429, ptr %l202, !tbaa !27
  %t430 = load i64, ptr %l19, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr %"compiler/scan:Diag", ptr %t433, i64 %t430
  %t435 = load %"compiler/scan:Diag", ptr %t434
  store %"compiler/scan:Diag" %t435, ptr %l21
  %t437 = getelementptr %"compiler/scan:Diag", ptr %l21, i32 0, i32 1
  %t438 = load i32, ptr %t437, !tbaa !23
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/load:Loader", ptr %t440, i32 0, i32 4
  %t443 = load ptr, ptr %t442, !tbaa !29
  store ptr %t443, ptr %l207, !tbaa !29
  %t444 = load ptr, ptr %l15, !tbaa !29
  %t446 = getelementptr %"compiler/load:Module", ptr %t444, i32 0, i32 4
  %t447 = load i64, ptr %t446, !tbaa !24
  %t450 = sext i32 %t438 to i64
  %t451 = getelementptr %"compiler/scan:Diag", ptr %l21, i32 0, i32 2
  %t452 = load i32, ptr %t451, !tbaa !23
  %t454 = sext i32 %t452 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t455
  %t456 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 0
  store i64 3, ptr %t456
  %t458 = insertvalue { i64, i64, i64 } undef, i64 %t447, 0
  %t460 = insertvalue { i64, i64, i64 } %t458, i64 %t450, 1
  %t462 = insertvalue { i64, i64, i64 } %t460, i64 %t454, 2
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 1
  store { i64, i64, i64 } %t462, ptr %t463
  %t464 = load { i64, [3 x i64] }, ptr %t455
  store { i64, [3 x i64] } %t464, ptr %l214
  store i32 67, ptr %l215
  %t465 = load %"compiler/scan:Diag", ptr %l21
  %t467 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %t465)
  store { i64, ptr } %t467, ptr %l217
  br label %bb92
bb92:
  %t468 = call ptr @__olang_scope_hold(ptr %v0)
  %t469 = ptrtoint ptr %t468 to i64
  store i64 %t469, ptr %l218, !tbaa !24
  %t470 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t470, label %bb93, label %bb94
bb93:
  %t472 = call ptr @__olang_region_make(ptr %v0)
  %t473 = ptrtoint ptr %t472 to i64
  store i64 %t473, ptr %l218, !tbaa !24
  br label %bb94
bb94:
  %t474 = load %"compiler/scan:Diag", ptr %l21
  %t475 = load i64, ptr %l218
  %t476 = inttoptr i64 %t475 to ptr
  %t478 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %t476, %"compiler/scan:Diag" %t474)
  store { i64, ptr } %t478, ptr %l221
  br label %bb95
bb95:
  %t479 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t480 = load i64, ptr %l218
  %t481 = inttoptr i64 %t480 to ptr
  %t482 = extractvalue { i64, ptr } %t479, 0
  %t483 = extractvalue { i64, ptr } %t479, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_held_alloc(ptr %t481, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  store { i64, ptr } %t487, ptr %l222, !tbaa !27
  %t488 = call ptr @__olang_scope_hold(ptr %v0)
  %t489 = ptrtoint ptr %t488 to i64
  store i64 %t489, ptr %l223, !tbaa !24
  %t490 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t490, label %bb96, label %bb97
bb96:
  %t492 = call ptr @__olang_region_make(ptr %v0)
  %t493 = ptrtoint ptr %t492 to i64
  store i64 %t493, ptr %l223, !tbaa !24
  br label %bb97
bb97:
  %t494 = load %"compiler/scan:Diag", ptr %l21
  %t495 = load i64, ptr %l223
  %t496 = inttoptr i64 %t495 to ptr
  %t498 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eNote(ptr %t496, %"compiler/scan:Diag" %t494)
  store { i64, ptr } %t498, ptr %l226
  br label %bb98
bb98:
  %t499 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t500 = load i64, ptr %l223
  %t501 = inttoptr i64 %t500 to ptr
  %t502 = extractvalue { i64, ptr } %t499, 0
  %t503 = extractvalue { i64, ptr } %t499, 1
  %t504 = mul i64 %t502, 1
  %t505 = call ptr @__olang_held_alloc(ptr %t501, i64 %t504)
  call void @llvm.memcpy.p0.p0.i64(ptr %t505, ptr %t503, i64 %t504, i1 false)
  %t506 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  store { i64, ptr } %t507, ptr %l227, !tbaa !27
  %t508 = call ptr @__olang_scope_hold(ptr %v0)
  %t509 = ptrtoint ptr %t508 to i64
  store i64 %t509, ptr %l228, !tbaa !24
  %t510 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t510, label %bb99, label %bb100
bb99:
  %t512 = call ptr @__olang_region_make(ptr %v0)
  %t513 = ptrtoint ptr %t512 to i64
  store i64 %t513, ptr %l228, !tbaa !24
  br label %bb100
bb100:
  %t514 = load %"compiler/scan:Diag", ptr %l21
  %t515 = load i64, ptr %l228
  %t516 = inttoptr i64 %t515 to ptr
  %t518 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eHelp(ptr %t516, %"compiler/scan:Diag" %t514)
  store { i64, ptr } %t518, ptr %l231
  br label %bb101
bb101:
  %t519 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t520 = load i64, ptr %l228
  %t521 = inttoptr i64 %t520 to ptr
  %t522 = extractvalue { i64, ptr } %t519, 0
  %t523 = extractvalue { i64, ptr } %t519, 1
  %t524 = mul i64 %t522, 1
  %t525 = call ptr @__olang_held_alloc(ptr %t521, i64 %t524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t525, ptr %t523, i64 %t524, i1 false)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t528 = load i32, ptr %l215, !range !{i32 0, i32 949}
  %t529 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t530 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t533 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t528, { i64, ptr } %t529, { i64, ptr } %t530, { i64, ptr } %t531, { i64, ptr } %t527)
  store %"compiler/diagmsg:Msg" %t533, ptr %l233
  br label %bb102
bb102:
  %t534 = load ptr, ptr %l207, !tbaa !29
  %t535 = load { i64, [3 x i64] }, ptr %l214
  %t536 = load %"compiler/diagmsg:Msg", ptr %l233
  %t537 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t534, { i64, [3 x i64] } %t535, %"compiler/diagmsg:Msg" %t536)
  store i64 %t537, ptr %l234
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t538 = load i64, ptr %l19, !tbaa !24
  %t541 = add i64 %t538, 1
  store i64 %t541, ptr %l19, !tbaa !24
  br label %bb88
bb105:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v0, ptr %t543, ptr %t544)
  br label %bb106
bb106:
  %t547 = load ptr, ptr %l15, !tbaa !29
  store ptr %t547, ptr %l240, !tbaa !29
  %t548 = call ptr @__olang_scope_hold(ptr %v0)
  %t549 = ptrtoint ptr %t548 to i64
  store i64 %t549, ptr %l241, !tbaa !24
  %t550 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e12
  br i1 %t550, label %bb107, label %bb108
bb107:
  %t552 = call ptr @__olang_region_make(ptr %v0)
  %t553 = ptrtoint ptr %t552 to i64
  store i64 %t553, ptr %l241, !tbaa !24
  br label %bb108
bb108:
  %t555 = load i64, ptr %l241
  %t556 = inttoptr i64 %t555 to ptr
  call void @compiler_2fparse_3aOracle_2ector(ptr %t554, ptr %t556)
  call void @llvm.memmove.p0.p0.i64(ptr %l243, ptr %t554, i64 288, i1 false)
  br label %bb109
bb109:
  %t557 = load i64, ptr %l241
  %t558 = inttoptr i64 %t557 to ptr
  %t559 = call ptr @__olang_scope_alloc_a(ptr %t558, i64 288, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t559, ptr %l243, i64 288, i1 false)
  %t560 = load ptr, ptr %l240, !tbaa !29
  %t561 = getelementptr %"compiler/load:Module", ptr %t560, i32 0, i32 12
  %t562 = load ptr, ptr %t561, !tbaa !29
  store ptr %t562, ptr %l245, !tbaa !29
  %t564 = load ptr, ptr %l240, !tbaa !29
  %t565 = getelementptr %"compiler/load:Module", ptr %t564, i32 0, i32 12
  store ptr %t559, ptr %t565, !tbaa !29
  %t566 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e12
  br i1 %t566, label %bb110, label %bb111
bb110:
  %t568 = load ptr, ptr %l245
  call void @__olang_region_release(ptr %t568)
  store ptr null, ptr %l245
  br label %bb111
bb111:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v0, ptr %t569, ptr %t570)
  br label %bb112
bb112:
  %t573 = load ptr, ptr %l0, !tbaa !29
  store ptr %t573, ptr %l249, !tbaa !29
  %t574 = load ptr, ptr %l249, !tbaa !29
  %t575 = getelementptr %"compiler/load:Loader", ptr %t574, i32 0, i32 23
  %t576 = load i64, ptr %t575, !tbaa !24
  %t579 = add i64 %t576, 1
  %t581 = load ptr, ptr %l249, !tbaa !29
  %t582 = getelementptr %"compiler/load:Loader", ptr %t581, i32 0, i32 23
  store i64 %t579, ptr %t582, !tbaa !24
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t583, i64 %t584)
  br label %bb113
bb113:
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l255, !tbaa !29
  %t588 = load ptr, ptr %l255, !tbaa !29
  %t589 = getelementptr %"compiler/load:Loader", ptr %t588, i32 0, i32 23
  %t590 = load i64, ptr %t589, !tbaa !24
  %t593 = sub i64 %t590, 1
  %t595 = load ptr, ptr %l255, !tbaa !29
  %t596 = getelementptr %"compiler/load:Loader", ptr %t595, i32 0, i32 23
  store i64 %t593, ptr %t596, !tbaa !24
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = getelementptr %"compiler/load:Loader", ptr %t597, i32 0, i32 24
  %t600 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t599, i64 %t600)
  br label %bb114
bb114:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/load:Loader", ptr %t603, i32 0, i32 23
  %t606 = load i64, ptr %t605, !tbaa !24
  %t608 = icmp eq i64 %t606, 0
  br i1 %t608, label %bb115, label %bb116
bb115:
  %t610 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparseLoaded(ptr %v0, ptr %t610)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t612 = load i64, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t612, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { { i64, ptr }, { i64, ptr } }
  %lp15 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l60 = alloca %"compiler/load:Import"
  %l63 = alloca i1
  %l69 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca { i64, [3 x i64] }
  %l88 = alloca %"compiler/diagmsg:Msg"
  %l89 = alloca i64
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca i64
  %l100 = alloca i1
  %l103 = alloca ptr
  %l107 = alloca { i64, [3 x i64] }
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i64
  %l110 = alloca { { i64, ptr }, { i64, ptr } }
  %l114 = alloca { { i64, ptr }, { i64, ptr } }
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca i64
  %l130 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l158 = alloca i1
  %l162 = alloca %"compiler/load:Import"
  %l165 = alloca i1
  %l169 = alloca %"compiler/load:Import"
  %l172 = alloca i1
  %l178 = alloca ptr
  %l182 = alloca { i64, [3 x i64] }
  %l184 = alloca %"compiler/diagmsg:Msg"
  %l185 = alloca i64
  %l190 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l32
  br label %bb2
bb2:
  %t14 = load i64, ptr %l32, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l39, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l39, !tbaa !24
  store i64 %t41, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l36, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/load:Import" %t67, ptr %l60
  br label %bb13
bb13:
  %t68 = load %"compiler/load:Import", ptr %l60
  store %"compiler/load:Import" %t68, ptr %l9
  %t69 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp sge i64 %t70, 0
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb16
bb15:
  %t74 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = icmp eq i64 %t75, -2
  store i1 %t77, ptr %l63, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb18:
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t82 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  %t87 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t80, i64 %t81, i64 %t83)
  store i64 %t87, ptr %l69
  br label %bb20
bb20:
  %t88 = load i64, ptr %l69, !tbaa !24
  %t89 = icmp ne i64 %t88, 1
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb22:
  br label %bb23
bb23:
  %t91 = load i64, ptr %l8, !tbaa !24
  store i64 -2, ptr %l11, !tbaa !24
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/load:Module", ptr %t93, i32 0, i32 11
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eRefMut_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t91)
  store ptr %t99, ptr %l75
  br label %bb24
bb24:
  %t100 = load ptr, ptr %l75, !tbaa !29
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr %"compiler/load:Import", ptr %t100, i32 0, i32 5
  store i64 %t102, ptr %t105, !tbaa !24
  %t106 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = call i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %t107)
  store i1 %t109, ptr %l79
  br label %bb25
bb25:
  %t110 = load i1, ptr %l79, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 4
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l82, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t120 = load %"compiler/source:Span", ptr %t119
  %t124 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t117, ptr %t118, %"compiler/source:Span" %t120)
  store { i64, [3 x i64] } %t124, ptr %l86
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t125 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v0, { i64, ptr } %t126)
  store %"compiler/diagmsg:Msg" %t128, ptr %l88
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l82, !tbaa !29
  %t130 = load { i64, [3 x i64] }, ptr %l86
  %t131 = load %"compiler/diagmsg:Msg", ptr %l88
  %t132 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t129, { i64, [3 x i64] } %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l89
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb31:
  store i64 -1, ptr %l13, !tbaa !24
  %t133 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 3
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t134, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t136, ptr %l91
  br label %bb32
bb32:
  %t137 = load i1, ptr %l91, !tbaa !21
  br i1 %t137, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb36
bb34:
  %t138 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 3
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t139, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t141, ptr %l94
  br label %bb35
bb35:
  %t142 = load i1, ptr %l94, !tbaa !21
  store i1 %t142, ptr %l92, !tbaa !21
  br label %bb36
bb36:
  %t143 = load i1, ptr %l92, !tbaa !21
  br i1 %t143, label %bb37, label %bb38
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l1, !tbaa !24
  %t146 = load %"compiler/load:Import", ptr %l9
  %t150 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ecImport(ptr %v0, ptr %v0, ptr %t144, i64 %t145, %"compiler/load:Import" %t146)
  store i64 %t150, ptr %l98
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t151 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 6
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t152, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d160, i32 0, i32 1) })
  store i1 %t154, ptr %l100
  br label %bb40
bb39:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  br label %bb52
bb40:
  %t156 = load i1, ptr %l100, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb41, label %bb42
bb41:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/load:Loader", ptr %t159, i32 0, i32 4
  %t162 = load ptr, ptr %t161, !tbaa !29
  store ptr %t162, ptr %l103, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t165 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 7
  %t166 = load %"compiler/source:Span", ptr %t165
  %t170 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t163, ptr %t164, %"compiler/source:Span" %t166)
  store { i64, [3 x i64] } %t170, ptr %l107
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t171 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkOnOlangImport(ptr %v0)
  store %"compiler/diagmsg:Msg" %t171, ptr %l108
  br label %bb44
bb44:
  %t172 = load ptr, ptr %l103, !tbaa !29
  %t173 = load { i64, [3 x i64] }, ptr %l107
  %t174 = load %"compiler/diagmsg:Msg", ptr %l108
  %t175 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t172, { i64, [3 x i64] } %t173, %"compiler/diagmsg:Msg" %t174)
  store i64 %t175, ptr %l109
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb46:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l1, !tbaa !24
  %t178 = load %"compiler/load:Import", ptr %l9
  %t182 = call { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v0, ptr %v0, ptr %t176, i64 %t177, %"compiler/load:Import" %t178)
  %t183 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t182, 1
  %t184 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t182, 0
  store i32 %t184, ptr %l115
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb48, label %ok.186, !prof !99
ok.186:
  store { { i64, ptr }, { i64, ptr } } %t183, ptr %l114
  br label %bb47
bb47:
  %t187 = load { { i64, ptr }, { i64, ptr } }, ptr %l114
  store { { i64, ptr }, { i64, ptr } } %t187, ptr %l110
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb50:
  %t188 = load { { i64, ptr }, { i64, ptr } }, ptr %l110
  store { { i64, ptr }, { i64, ptr } } %t188, ptr %l14
  %t189 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l14, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l116, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l117, !tbaa !24
  %t193 = load i64, ptr %l117, !tbaa !24
  %t194 = mul i64 %t193, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l118, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l117, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  %t204 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t204, ptr %lp15
  %t205 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t206 = load ptr, ptr %lp15
  store { i64, ptr } %t205, ptr %t206, !tbaa !27
  %t207 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l14, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l119, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l120, !tbaa !24
  %t211 = load i64, ptr %l120, !tbaa !24
  %t212 = mul i64 %t211, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t212)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l121, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l120, !tbaa !24
  %t221 = mul i64 %t220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t222, ptr %lp16
  %t223 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t224 = load ptr, ptr %lp16
  store { i64, ptr } %t223, ptr %t224, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %lp15
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load ptr, ptr %lp16
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  %t233 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t225, { i64, ptr } %t227, { i64, ptr } %t229, i1 false, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i64 %t233, ptr %l125
  br label %bb51
bb51:
  %t234 = load i64, ptr %l125, !tbaa !24
  store i64 %t234, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t235 = load i64, ptr %l13, !tbaa !24
  %t237 = icmp slt i64 %t235, 0
  br i1 %t237, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb54:
  br label %bb55
bb55:
  store i1 false, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/load:Module", ptr %t239, i32 0, i32 11
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t241)
  store i64 %t243, ptr %l130
  br label %bb56
bb56:
  %t244 = load i64, ptr %l130, !tbaa !24
  store i64 %t244, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t245 = load i64, ptr %l19, !tbaa !24
  %t246 = load i64, ptr %l18, !tbaa !24
  %t249 = icmp sgt i64 %t245, %t246
  br i1 %t249, label %bb57, label %bb58
bb57:
  %t251 = load i64, ptr %l20, !tbaa !24
  %t253 = icmp sgt i64 %t251, 0
  br i1 %t253, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb62
bb59:
  %t255 = load i64, ptr %l19, !tbaa !24
  %t256 = load i64, ptr %l18, !tbaa !24
  %t259 = sub i64 %t255, %t256
  %t260 = load i64, ptr %l20, !tbaa !24
  %t263 = add i64 %t259, %t260
  %t265 = sub i64 %t263, 1
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = sdiv i64 %t265, %t266
  store i64 %t269, ptr %l137, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb61
bb61:
  %t271 = load i64, ptr %l137, !tbaa !24
  store i64 %t271, ptr %l134, !tbaa !24
  br label %bb62
bb62:
  %t272 = load i64, ptr %l134, !tbaa !24
  store i64 %t272, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load i64, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t281 = load i64, ptr %l18, !tbaa !24
  %t282 = load i64, ptr %l22, !tbaa !24
  %t283 = load i64, ptr %l20, !tbaa !24
  %t286 = mul i64 %t282, %t283
  %t289 = add i64 %t281, %t286
  store i64 %t289, ptr %l23, !tbaa !24
  %t291 = load i64, ptr %l23, !tbaa !24
  %t292 = load i64, ptr %l8, !tbaa !24
  %t295 = icmp ne i64 %t291, %t292
  br i1 %t295, label %bb67, label %bb68
bb67:
  %t297 = load ptr, ptr %l2, !tbaa !29
  %t299 = getelementptr %"compiler/load:Module", ptr %t297, i32 0, i32 11
  %t300 = load i64, ptr %l23, !tbaa !24
  %t303 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %s12, ptr %t299, i64 %t300)
  store %"compiler/load:Import" %t303, ptr %l162
  br label %bb69
bb68:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb70
bb69:
  %t304 = getelementptr %"compiler/load:Import", ptr %l162, i32 0, i32 5
  %t305 = load i64, ptr %t304, !tbaa !24
  %t307 = icmp sge i64 %t305, 0
  store i1 %t307, ptr %l158, !tbaa !21
  br label %bb70
bb70:
  %t309 = load i1, ptr %l158, !tbaa !21
  br i1 %t309, label %bb71, label %bb72
bb71:
  %t310 = load ptr, ptr %l2, !tbaa !29
  %t312 = getelementptr %"compiler/load:Module", ptr %t310, i32 0, i32 11
  %t313 = load i64, ptr %l23, !tbaa !24
  %t316 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t312, i64 %t313)
  store %"compiler/load:Import" %t316, ptr %l169
  br label %bb73
bb72:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb75
bb73:
  %t317 = getelementptr %"compiler/load:Import", ptr %l169, i32 0, i32 2
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t319 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t318, { i64, ptr } %t320)
  store i1 %t323, ptr %l172
  br label %bb74
bb74:
  %t324 = load i1, ptr %l172, !tbaa !21
  store i1 %t324, ptr %l165, !tbaa !21
  br label %bb75
bb75:
  %t325 = load i1, ptr %l165, !tbaa !21
  br i1 %t325, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb78
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = add i64 %t326, 1
  store i64 %t329, ptr %l22, !tbaa !24
  br label %bb63
bb80:
  %t331 = load i1, ptr %l17, !tbaa !21
  br i1 %t331, label %bb81, label %bb82
bb81:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/load:Loader", ptr %t333, i32 0, i32 4
  %t336 = load ptr, ptr %t335, !tbaa !29
  store ptr %t336, ptr %l178, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l2, !tbaa !29
  %t339 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t340 = load %"compiler/source:Span", ptr %t339
  %t344 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t337, ptr %t338, %"compiler/source:Span" %t340)
  store { i64, [3 x i64] } %t344, ptr %l182
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t345 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  %t348 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v0, { i64, ptr } %t346)
  store %"compiler/diagmsg:Msg" %t348, ptr %l184
  br label %bb84
bb84:
  %t349 = load ptr, ptr %l178, !tbaa !29
  %t350 = load { i64, [3 x i64] }, ptr %l182
  %t351 = load %"compiler/diagmsg:Msg", ptr %l184
  %t352 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t349, { i64, [3 x i64] } %t350, %"compiler/diagmsg:Msg" %t351)
  store i64 %t352, ptr %l185
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb86:
  %t353 = load i64, ptr %l8, !tbaa !24
  %t355 = load ptr, ptr %l2, !tbaa !29
  %t357 = getelementptr %"compiler/load:Module", ptr %t355, i32 0, i32 11
  %t361 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eRefMut_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t357, i64 %t353)
  store ptr %t361, ptr %l190
  br label %bb87
bb87:
  %t362 = load ptr, ptr %l190, !tbaa !29
  %t364 = load i64, ptr %l13, !tbaa !24
  %t367 = getelementptr %"compiler/load:Import", ptr %t362, i32 0, i32 5
  store i64 %t364, ptr %t367, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb88:
  %t368 = load i64, ptr %l7, !tbaa !24
  %t371 = add i64 %t368, 1
  store i64 %t371, ptr %l7, !tbaa !24
  br label %bb9
bb89:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 6
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/source:Source", ptr %t11, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 7
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 7
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t29 = call ptr @compiler_2fload_2etypeNames(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t27, ptr %t26)
  store ptr %t29, ptr %l20
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l20, !tbaa !29
  store ptr %t30, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l21, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t32)
  store i64 %t34, ptr %l23
  br label %bb9
bb9:
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t41, i64 %t42)
  store { i64, ptr } %t45, ptr %l28
  br label %bb13
bb13:
  %t46 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t49, { i64, ptr } %t46)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb8
bb16:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/load:Module", ptr %t58, i32 0, i32 6
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4a5bc26e34bf81_f78399c125ad415d)
  unreachable
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/load:Module", ptr %t65, i32 0, i32 6
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/source:Source", ptr %t68, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l41, !tbaa !27
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 7
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  br i1 %t78, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4a5bc26e34bf81_f78399c125ad415d)
  unreachable
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/load:Module", ptr %t80, i32 0, i32 7
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t86 = call ptr @compiler_2fparse_2eGenericFnNames(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t84, ptr %t83)
  store ptr %t86, ptr %l47
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l47, !tbaa !29
  store ptr %t87, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  %t88 = load i64, ptr %l6, !tbaa !24
  store i64 %t88, ptr %l48, !tbaa !24
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l50
  br label %bb25
bb25:
  %t92 = load i64, ptr %l48, !tbaa !24
  %t93 = load i64, ptr %l50, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l55
  br label %bb29
bb29:
  %t103 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/load:Module", ptr %t104, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t106, { i64, ptr } %t103)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb24
bb32:
  store ptr %a0, ptr %l62, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l63, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/load:Module", ptr %t117, i32 0, i32 7
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_75be0ecbfd40364c_3ba616ba9e8cb88)
  unreachable
bb34:
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 7
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/scan:Tokens", ptr %t127, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = sub i64 %t133, 1
  %t136 = load ptr, ptr %l62, !tbaa !29
  %t137 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t136, ptr %t137, i64 0, i64 %t135, i64 -1)
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2ereaches(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/load:Import"
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/load:Import"
  %l30 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 3
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l17
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 11
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l20, !tbaa !24
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l22
  br label %bb9
bb9:
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = load i64, ptr %l22, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store %"compiler/load:Import" %t38, ptr %l27
  br label %bb13
bb13:
  %t39 = load %"compiler/load:Import", ptr %l27
  store %"compiler/load:Import" %t39, ptr %l6
  %t40 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t49, 1
  %t56 = call i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2ereaches(ptr %v0, ptr %t45, i64 %t47, i64 %t48, i64 %t51)
  store i1 %t56, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t60, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb8
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/load:Import" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/load:Import"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca { i64, [3 x i64] }
  %l37 = alloca ptr
  %l38 = alloca { i64, [3 x i64] }
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, [3 x i64] }
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l121 = alloca i1
  %l124 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca { i64, [3 x i64] }
  %l131 = alloca %"compiler/diagmsg:Msg"
  %l132 = alloca i64
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca i32
  %l151 = alloca ptr
  %l152 = alloca { i64, [3 x i64] }
  %l153 = alloca %"compiler/diagmsg:Msg"
  %l154 = alloca i64
  %l155 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca { i64, [3 x i64] }
  %l161 = alloca { i64, ptr }
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %l165 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l171 = alloca { i64, ptr }
  %l173 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l178 = alloca ptr
  %l179 = alloca { i64, [3 x i64] }
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/diagmsg:Msg"
  %l184 = alloca i64
  %l185 = alloca { i64, ptr }
  %l187 = alloca i64
  %l188 = alloca { i64, ptr }
  %l190 = alloca i1
  %l192 = alloca %"std/prelude/text:StringBuilder"
  %l200 = alloca i64
  %l203 = alloca i64
  %l223 = alloca { i64, ptr }
  %l230 = alloca i64
  %l233 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l242 = alloca i64
  %l245 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l258 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca { i64, [3 x i64] }
  %l264 = alloca %"compiler/diagmsg:Msg"
  %l265 = alloca i64
  %l269 = alloca { i64, ptr }
  %l271 = alloca i1
  %l272 = alloca i1
  %l274 = alloca i1
  %l275 = alloca i64
  %l280 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l287 = alloca i64
  %l293 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l301 = alloca i1
  %l302 = alloca { i64, ptr }
  %l303 = alloca i64
  %l306 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l311 = alloca i64
  %l316 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l327 = alloca i64
  %l331 = alloca i64
  %l332 = alloca i32
  %l336 = alloca i64
  %l343 = alloca { i64, ptr }
  %l344 = alloca i1
  %l345 = alloca i1
  %l347 = alloca i1
  %l349 = alloca i1
  %l351 = alloca i1
  %l355 = alloca i1
  %l356 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l361 = alloca i1
  %l365 = alloca { i64, ptr }
  %l366 = alloca i1
  %l367 = alloca i64
  %l371 = alloca { i64, ptr }
  %l372 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l379 = alloca i1
  %l381 = alloca i1
  %l386 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca { i64, [3 x i64] }
  %l392 = alloca %"compiler/diagmsg:Msg"
  %l393 = alloca i64
  %l396 = alloca i1
  %l398 = alloca i1
  %l400 = alloca i1
  %l402 = alloca ptr
  %l403 = alloca { i64, [3 x i64] }
  %l405 = alloca %"compiler/diagmsg:Msg"
  %l406 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, { i64, ptr } } }
  store ptr %a0, ptr %l0
  store %"compiler/load:Import" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l27, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 0
  %t12 = load %"compiler/source:Span", ptr %t11
  %t16 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t9, ptr %t10, %"compiler/source:Span" %t12)
  store { i64, [3 x i64] } %t16, ptr %l31
  br label %bb2
bb2:
  %t17 = load { i64, [3 x i64] }, ptr %l31
  store { i64, [3 x i64] } %t17, ptr %l4
  %t18 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sge i64 %t23, 4096
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 4
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l37, !tbaa !29
  %t31 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t31, ptr %l38
  %t32 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0)
  store %"compiler/diagmsg:Msg" %t32, ptr %l39
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t33 = load ptr, ptr %l37, !tbaa !29
  %t34 = load { i64, [3 x i64] }, ptr %l38
  %t35 = load %"compiler/diagmsg:Msg", ptr %l39
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/diagmsg:Msg" %t35)
  store i64 %t36, ptr %l40
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) })
  store i1 %t41, ptr %l43
  br label %bb8
bb8:
  %t42 = load i1, ptr %l43, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l45, !tbaa !29
  %t47 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t47, ptr %l46
  %t48 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0)
  store %"compiler/diagmsg:Msg" %t48, ptr %l47
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t49 = load ptr, ptr %l45, !tbaa !29
  %t50 = load { i64, [3 x i64] }, ptr %l46
  %t51 = load %"compiler/diagmsg:Msg", ptr %l47
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t49, { i64, [3 x i64] } %t50, %"compiler/diagmsg:Msg" %t51)
  store i64 %t52, ptr %l48
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t54 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t55, i8 47)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l54
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb15, label %ok.62, !prof !99
ok.62:
  store i64 %t59, ptr %l53
  br label %bb14
bb14:
  %t63 = load i64, ptr %l53, !tbaa !24
  store i64 %t63, ptr %l50, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l50, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l50, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t69, ptr %l57, !tbaa !27
  store i64 %t68, ptr %l58, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l59, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l58, !tbaa !24
  %t76 = icmp sle i64 0, %t75
  br i1 %t76, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb20:
  %t78 = load i64, ptr %l58, !tbaa !24
  %t79 = load i64, ptr %l59, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb22:
  %t82 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = getelementptr i8, ptr %t83, i64 0
  %t86 = sub i64 %t84, 0
  %t87 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d162, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t91, ptr %lp8
  %t93 = load ptr, ptr %lp8
  store { i64, ptr } %t90, ptr %t93, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d163, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t95, ptr %lp9
  %t97 = load ptr, ptr %lp9
  store { i64, ptr } %t94, ptr %t97, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d164, i32 0, i32 1) })
  store i1 %t100, ptr %l69
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb24:
  %t101 = load i1, ptr %l69, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t102 = call ptr @__olang_scope_hold(ptr %v2)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l70, !tbaa !24
  %t104 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t104, label %bb27, label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, ptr %l113, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t110 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s8, { i64, ptr } %t106, { i64, ptr } %t109)
  store i1 %t110, ptr %l114
  br label %bb57
bb27:
  %t111 = call ptr @__olang_region_make(ptr %v2)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l73, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l74, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t118, 0
  store i64 %t121, ptr %l77, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l78, !tbaa !24
  %t124 = icmp sge i64 4, 0
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t126 = load i64, ptr %l77, !tbaa !24
  %t127 = icmp sle i64 4, %t126
  br i1 %t127, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb31:
  %t129 = load i64, ptr %l77, !tbaa !24
  %t130 = load i64, ptr %l78, !tbaa !24
  %t131 = icmp sle i64 %t129, %t130
  br i1 %t131, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb33:
  %t133 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l77, !tbaa !24
  %t136 = getelementptr i8, ptr %t134, i64 4
  %t137 = sub i64 %t135, 4
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t140 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t147 = extractvalue { i64, ptr } %t139, 1
  %t148 = extractvalue { i64, ptr } %t139, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t141, i64 %t142)
  %t154 = getelementptr i8, ptr %t153, i64 %t142
  call void @olang_textcopy(ptr %t154, ptr %t143, i64 %t144)
  %t155 = getelementptr i8, ptr %t154, i64 %t144
  call void @olang_textcopy(ptr %t155, ptr %t147, i64 %t148)
  %t156 = getelementptr i8, ptr %t155, i64 %t148
  call void @olang_textcopy(ptr %t156, ptr %t150, i64 %t151)
  %t157 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t153, 1
  %t161 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s3, ptr %s3, { i64, ptr } %t158)
  store { i64, ptr } %t161, ptr %l85
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb35:
  %t162 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = load i64, ptr %l70
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  call void @olang_textcopy(ptr %t167, ptr %t163, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l86, !tbaa !27
  %t170 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t170, label %bb36, label %bb37
bb36:
  %t172 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb38, label %bb39
bb37:
  %t177 = load ptr, ptr %lp8
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l90, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t180 = load ptr, ptr %lp8
  store { i64, ptr } %t179, ptr %t180, !tbaa !27
  %t181 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t181, label %bb40, label %bb41
bb38:
  store { i64, ptr } zeroinitializer, ptr %l86, !tbaa !27
  br label %bb39
bb39:
  %t183 = load i64, ptr %l70
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = load { i64, ptr }, ptr %l86
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = icmp ne ptr %t187, null
  %t189 = select i1 %t188, ptr %t187, ptr null
  call void @__olang_region_settle_in(ptr %t184, ptr %t189)
  br label %bb37
bb40:
  %t190 = load { i64, ptr }, ptr %l90
  %t191 = extractvalue { i64, ptr } %t190, 1
  call void @__olang_region_release(ptr %t191)
  store { i64, ptr } zeroinitializer, ptr %l90
  br label %bb41
bb41:
  %t192 = call ptr @__olang_scope_hold(ptr %v2)
  %t193 = ptrtoint ptr %t192 to i64
  store i64 %t193, ptr %l92, !tbaa !24
  %t194 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t194, label %bb42, label %bb43
bb42:
  %t196 = call ptr @__olang_region_make(ptr %v2)
  %t197 = ptrtoint ptr %t196 to i64
  store i64 %t197, ptr %l92, !tbaa !24
  br label %bb43
bb43:
  %t198 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t200 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s3, { i64, ptr } %t198)
  store { i64, ptr } %t200, ptr %l95
  br label %bb44
bb44:
  %t201 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load i64, ptr %l92
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = call ptr @__olang_held_alloc(ptr %t205, i64 %t203)
  call void @olang_textcopy(ptr %t206, ptr %t202, i64 %t203)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l96, !tbaa !27
  %t209 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t209, label %bb45, label %bb46
bb45:
  %t211 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t214 = icmp eq i64 %t212, 0
  br i1 %t214, label %bb47, label %bb48
bb46:
  %t216 = load ptr, ptr %lp9
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l100, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t219 = load ptr, ptr %lp9
  store { i64, ptr } %t218, ptr %t219, !tbaa !27
  %t220 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t220, label %bb49, label %bb50
bb47:
  store { i64, ptr } zeroinitializer, ptr %l96, !tbaa !27
  br label %bb48
bb48:
  %t222 = load i64, ptr %l92
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load { i64, ptr }, ptr %l96
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t228)
  br label %bb46
bb49:
  %t229 = load { i64, ptr }, ptr %l100
  %t230 = extractvalue { i64, ptr } %t229, 1
  call void @__olang_region_release(ptr %t230)
  store { i64, ptr } zeroinitializer, ptr %l100
  br label %bb50
bb50:
  %t231 = load ptr, ptr %lp9
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t234 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s3, { i64, ptr } %t232, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i1 %t234, ptr %l103
  br label %bb51
bb51:
  %t235 = load i1, ptr %l103, !tbaa !21
  %t236 = xor i1 %t235, true
  br i1 %t236, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 4
  %t241 = load ptr, ptr %t240, !tbaa !29
  store ptr %t241, ptr %l106, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t242, ptr %l107
  %t243 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s7, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t243, ptr %l108
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t244 = load ptr, ptr %l106, !tbaa !29
  %t245 = load { i64, [3 x i64] }, ptr %l107
  %t246 = load %"compiler/diagmsg:Msg", ptr %l108
  %t247 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t244, { i64, [3 x i64] } %t245, %"compiler/diagmsg:Msg" %t246)
  store i64 %t247, ptr %l109
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t249, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb246
bb57:
  %t250 = load i1, ptr %l114, !tbaa !21
  br i1 %t250, label %bb58, label %bb59
bb58:
  %t251 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t253 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t251, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) })
  store i1 %t253, ptr %l117
  br label %bb60
bb59:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb61
bb60:
  %t254 = load i1, ptr %l117, !tbaa !21
  %t255 = xor i1 %t254, true
  store i1 %t255, ptr %l115, !tbaa !21
  br label %bb61
bb61:
  %t257 = load i1, ptr %l115, !tbaa !21
  br i1 %t257, label %bb62, label %bb63
bb62:
  %t258 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t260 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t258, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t260, ptr %l121
  br label %bb64
bb63:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb65
bb64:
  %t261 = load i1, ptr %l121, !tbaa !21
  %t262 = xor i1 %t261, true
  store i1 %t262, ptr %l119, !tbaa !21
  br label %bb65
bb65:
  %t264 = load i1, ptr %l119, !tbaa !21
  br i1 %t264, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s9
  %t265 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t267 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s9, ptr %s9, { i64, ptr } %t265, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  store { i64, ptr } %t267, ptr %l124
  br label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s23
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = getelementptr %"compiler/load:Module", ptr %t268, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t273 = call { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %s23, { i64, ptr } %t271)
  store { i64, ptr } %t273, ptr %l269
  br label %bb147
bb68:
  %t274 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t274, ptr %l10, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp slt i64 %t277, 4
  br i1 %t279, label %bb69, label %bb70
bb69:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/load:Loader", ptr %t281, i32 0, i32 4
  %t284 = load ptr, ptr %t283, !tbaa !29
  store ptr %t284, ptr %l129, !tbaa !29
  %t285 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t285, ptr %l130
  %t286 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0)
  store %"compiler/diagmsg:Msg" %t286, ptr %l131
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t287 = load ptr, ptr %l129, !tbaa !29
  %t288 = load { i64, [3 x i64] }, ptr %l130
  %t289 = load %"compiler/diagmsg:Msg", ptr %l131
  %t290 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t287, { i64, [3 x i64] } %t288, %"compiler/diagmsg:Msg" %t289)
  store i64 %t290, ptr %l132
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t292 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t292, ptr %rv
  br label %ret
bb73:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/load:Loader", ptr %t293, i32 0, i32 2
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t297 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t297, ptr %l137, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %t299, i64 0
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !37
  %t302 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t302, ptr %l139, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr { i64, ptr }, ptr %t304, i64 1
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !37
  %t307 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t307, ptr %l141, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %t309, i64 2
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !37
  %t316 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %s9, ptr %t296, { i64, ptr } %t301, { i64, ptr } %t306, { i64, ptr } %t311)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l144
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb75, label %ok.320, !prof !99
ok.320:
  store { i64, ptr } %t317, ptr %l143
  br label %bb74
bb74:
  %t321 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t321, ptr %l134, !tbaa !27
  br label %bb99
bb75:
  %t322 = load i32, ptr %l144, !tbaa !23
  %t323 = icmp eq i32 %t322, 65536
  br i1 %t323, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  %t325 = load i32, ptr %l144, !tbaa !23
  %t326 = icmp eq i32 %t325, 65537
  br i1 %t326, label %bb79, label %bb80
bb78:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/load:Loader", ptr %t328, i32 0, i32 4
  %t331 = load ptr, ptr %t330, !tbaa !29
  store ptr %t331, ptr %l151, !tbaa !29
  %t332 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t332, ptr %l152
  %t333 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t333, ptr %l153
  br label %bb88
bb79:
  br label %bb81
bb80:
  %t334 = load i32, ptr %l144, !tbaa !23
  %t335 = icmp eq i32 %t334, 65538
  br i1 %t335, label %bb82, label %bb83
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/load:Loader", ptr %t337, i32 0, i32 4
  %t340 = load ptr, ptr %t339, !tbaa !29
  store ptr %t340, ptr %l158, !tbaa !29
  %t341 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t341, ptr %l159
  %t342 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t344 = call { i64, ptr } @compiler_2fload_2ekey(ptr %s9, ptr %s12, { i64, ptr } %t342)
  store { i64, ptr } %t344, ptr %l161
  br label %bb90
bb82:
  br label %bb84
bb83:
  %t345 = load i32, ptr %l144, !tbaa !23
  %t346 = icmp eq i32 %t345, 65539
  br i1 %t346, label %bb85, label %bb86
bb84:
  store %olang.scope zeroinitializer, ptr %s13
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/load:Loader", ptr %t348, i32 0, i32 4
  %t351 = load ptr, ptr %t350, !tbaa !29
  store ptr %t351, ptr %l168, !tbaa !29
  %t352 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t352, ptr %l169
  %t353 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t355 = call { i64, ptr } @compiler_2fload_2ekey(ptr %s9, ptr %s13, { i64, ptr } %t353)
  store { i64, ptr } %t355, ptr %l171
  br label %bb93
bb85:
  br label %bb87
bb86:
  %t356 = load i32, ptr %l144, !tbaa !23
  %t357 = lshr i32 %t356, 16
  %t358 = and i32 %t356, 65535
  %t359 = icmp eq i32 %t357, 1
  %t360 = select i1 %t359, i32 0, i32 0
  %t361 = icmp eq i32 %t356, 0
  %t362 = shl i32 %t360, 16
  %t363 = or i32 %t362, %t358
  %t364 = select i1 %t361, i32 0, i32 %t363
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t366 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t364, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t366, ptr %rv
  br label %ret
bb87:
  store %olang.scope zeroinitializer, ptr %s14
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/load:Loader", ptr %t367, i32 0, i32 4
  %t370 = load ptr, ptr %t369, !tbaa !29
  store ptr %t370, ptr %l178, !tbaa !29
  %t371 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t371, ptr %l179
  %t372 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t374 = call { i64, ptr } @compiler_2fload_2ekey(ptr %s9, ptr %s14, { i64, ptr } %t372)
  store { i64, ptr } %t374, ptr %l181
  br label %bb96
bb88:
  %t375 = load ptr, ptr %l151, !tbaa !29
  %t376 = load { i64, [3 x i64] }, ptr %l152
  %t377 = load %"compiler/diagmsg:Msg", ptr %l153
  %t378 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t375, { i64, [3 x i64] } %t376, %"compiler/diagmsg:Msg" %t377)
  store i64 %t378, ptr %l154
  br label %bb89
bb89:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l155, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t379, ptr %l134, !tbaa !27
  br label %bb99
bb90:
  %t381 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t383 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %s12, ptr %v0, { i64, ptr } %t381)
  store %"compiler/diagmsg:Msg" %t383, ptr %l163
  br label %bb91
bb91:
  %t384 = load ptr, ptr %l158, !tbaa !29
  %t385 = load { i64, [3 x i64] }, ptr %l159
  %t386 = load %"compiler/diagmsg:Msg", ptr %l163
  %t387 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t384, { i64, [3 x i64] } %t385, %"compiler/diagmsg:Msg" %t386)
  store i64 %t387, ptr %l164
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l165, !tbaa !27
  %t388 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t388, ptr %l134, !tbaa !27
  br label %bb99
bb93:
  %t390 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t392 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %s13, ptr %v0, { i64, ptr } %t390)
  store %"compiler/diagmsg:Msg" %t392, ptr %l173
  br label %bb94
bb94:
  %t393 = load ptr, ptr %l168, !tbaa !29
  %t394 = load { i64, [3 x i64] }, ptr %l169
  %t395 = load %"compiler/diagmsg:Msg", ptr %l173
  %t396 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t393, { i64, [3 x i64] } %t394, %"compiler/diagmsg:Msg" %t395)
  store i64 %t396, ptr %l174
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s13)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d175, i32 0, i32 1) }, ptr %l175, !tbaa !27
  %t397 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t397, ptr %l134, !tbaa !27
  br label %bb99
bb96:
  %t399 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t401 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %s14, ptr %v0, { i64, ptr } %t399)
  store %"compiler/diagmsg:Msg" %t401, ptr %l183
  br label %bb97
bb97:
  %t402 = load ptr, ptr %l178, !tbaa !29
  %t403 = load { i64, [3 x i64] }, ptr %l179
  %t404 = load %"compiler/diagmsg:Msg", ptr %l183
  %t405 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t402, { i64, [3 x i64] } %t403, %"compiler/diagmsg:Msg" %t404)
  store i64 %t405, ptr %l184
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s14)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d176, i32 0, i32 1) }, ptr %l185, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t406, ptr %l134, !tbaa !27
  br label %bb99
bb99:
  %t408 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 0
  store i64 %t409, ptr %l187, !tbaa !24
  %t410 = load i64, ptr %l187, !tbaa !24
  %t411 = mul i64 %t410, 1
  %t412 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t411)
  %t413 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t412, 1
  store { i64, ptr } %t414, ptr %l188, !tbaa !27
  %t415 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l187, !tbaa !24
  %t420 = mul i64 %t419, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t416, ptr %t418, i64 %t420, i1 false)
  %t421 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t421, ptr %l11, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t424 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t422, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d177, i32 0, i32 1) })
  store i1 %t424, ptr %l190
  br label %bb100
bb100:
  %t425 = load i1, ptr %l190, !tbaa !21
  br i1 %t425, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t427 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t427, ptr %rv
  br label %ret
bb102:
  br label %bb103
bb103:
  %t428 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t428, ptr %l192
  br label %bb104
bb104:
  %t429 = load %"std/prelude/text:StringBuilder", ptr %l192
  store %"std/prelude/text:StringBuilder" %t429, ptr %l12
  %t430 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l12, { i64, ptr } %t430)
  br label %bb105
bb105:
  store i64 3, ptr %l13, !tbaa !24
  %t433 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t433, 0
  store i64 %t435, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t437 = load i64, ptr %l14, !tbaa !24
  %t438 = load i64, ptr %l13, !tbaa !24
  %t441 = icmp sgt i64 %t437, %t438
  br i1 %t441, label %bb106, label %bb107
bb106:
  %t443 = load i64, ptr %l15, !tbaa !24
  %t445 = icmp sgt i64 %t443, 0
  br i1 %t445, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb111
bb108:
  %t447 = load i64, ptr %l14, !tbaa !24
  %t448 = load i64, ptr %l13, !tbaa !24
  %t451 = sub i64 %t447, %t448
  %t452 = load i64, ptr %l15, !tbaa !24
  %t455 = add i64 %t451, %t452
  %t457 = sub i64 %t455, 1
  %t458 = load i64, ptr %l15, !tbaa !24
  %t461 = sdiv i64 %t457, %t458
  store i64 %t461, ptr %l203, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb110
bb110:
  %t463 = load i64, ptr %l203, !tbaa !24
  store i64 %t463, ptr %l200, !tbaa !24
  br label %bb111
bb111:
  %t464 = load i64, ptr %l200, !tbaa !24
  store i64 %t464, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb112
bb112:
  %t465 = load i64, ptr %l17, !tbaa !24
  %t466 = load i64, ptr %l16, !tbaa !24
  %t469 = icmp slt i64 %t465, %t466
  %t471 = xor i1 %t469, true
  br i1 %t471, label %bb113, label %bb114
bb113:
  br label %bb119
bb114:
  br label %bb115
bb115:
  %t473 = load i64, ptr %l13, !tbaa !24
  %t474 = load i64, ptr %l17, !tbaa !24
  %t475 = load i64, ptr %l15, !tbaa !24
  %t478 = mul i64 %t474, %t475
  %t481 = add i64 %t473, %t478
  store i64 %t481, ptr %l18, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l12, i8 47)
  br label %bb116
bb116:
  %t484 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t484, ptr %l223, !tbaa !27
  %t485 = load i64, ptr %l18, !tbaa !24
  %t487 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr { i64, ptr }, ptr %t488, i64 %t485
  %t490 = load { i64, ptr }, ptr %t489, !tbaa !37
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l12, { i64, ptr } %t490)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t493 = load i64, ptr %l17, !tbaa !24
  %t496 = add i64 %t493, 1
  store i64 %t496, ptr %l17, !tbaa !24
  br label %bb112
bb119:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l12, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d178, i32 0, i32 1) })
  br label %bb120
bb120:
  %t499 = call ptr @__olang_scope_hold(ptr %v2)
  %t500 = ptrtoint ptr %t499 to i64
  store i64 %t500, ptr %l230, !tbaa !24
  %t501 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t501, label %bb121, label %bb122
bb121:
  %t503 = call ptr @__olang_region_make(ptr %v2)
  %t504 = ptrtoint ptr %t503 to i64
  store i64 %t504, ptr %l230, !tbaa !24
  br label %bb122
bb122:
  %t506 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %l12)
  store { i64, ptr } %t506, ptr %l233
  br label %bb123
bb123:
  %t507 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t509 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s9, ptr %s9, { i64, ptr } %t507)
  store { i64, ptr } %t509, ptr %l235
  br label %bb124
bb124:
  %t510 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 1
  %t512 = extractvalue { i64, ptr } %t510, 0
  %t513 = load i64, ptr %l230
  %t514 = inttoptr i64 %t513 to ptr
  %t515 = call ptr @__olang_held_alloc(ptr %t514, i64 %t512)
  call void @olang_textcopy(ptr %t515, ptr %t511, i64 %t512)
  %t516 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  store { i64, ptr } %t517, ptr %l236, !tbaa !27
  %t518 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t518, label %bb125, label %bb126
bb125:
  %t520 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t520, 0
  %t523 = icmp eq i64 %t521, 0
  br i1 %t523, label %bb127, label %bb128
bb126:
  %t525 = load ptr, ptr %lp8
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  store { i64, ptr } %t526, ptr %l240, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t528 = load ptr, ptr %lp8
  store { i64, ptr } %t527, ptr %t528, !tbaa !27
  %t529 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t529, label %bb129, label %bb130
bb127:
  store { i64, ptr } zeroinitializer, ptr %l236, !tbaa !27
  br label %bb128
bb128:
  %t531 = load i64, ptr %l230
  %t532 = inttoptr i64 %t531 to ptr
  %t533 = load { i64, ptr }, ptr %l236
  %t534 = extractvalue { i64, ptr } %t533, 1
  %t535 = call ptr @__olang_region_or(ptr %t534, ptr null)
  %t536 = icmp ne ptr %t535, null
  %t537 = select i1 %t536, ptr %t535, ptr null
  call void @__olang_region_settle_in(ptr %t532, ptr %t537)
  br label %bb126
bb129:
  %t538 = load { i64, ptr }, ptr %l240
  %t539 = extractvalue { i64, ptr } %t538, 1
  call void @__olang_region_release(ptr %t539)
  store { i64, ptr } zeroinitializer, ptr %l240
  br label %bb130
bb130:
  %t540 = call ptr @__olang_scope_hold(ptr %v2)
  %t541 = ptrtoint ptr %t540 to i64
  store i64 %t541, ptr %l242, !tbaa !24
  %t542 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t542, label %bb131, label %bb132
bb131:
  %t544 = call ptr @__olang_region_make(ptr %v2)
  %t545 = ptrtoint ptr %t544 to i64
  store i64 %t545, ptr %l242, !tbaa !24
  br label %bb132
bb132:
  %t546 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t548 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s9, { i64, ptr } %t546)
  store { i64, ptr } %t548, ptr %l245
  br label %bb133
bb133:
  %t549 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t549, 1
  %t551 = extractvalue { i64, ptr } %t549, 0
  %t552 = load i64, ptr %l242
  %t553 = inttoptr i64 %t552 to ptr
  %t554 = call ptr @__olang_held_alloc(ptr %t553, i64 %t551)
  call void @olang_textcopy(ptr %t554, ptr %t550, i64 %t551)
  %t555 = insertvalue { i64, ptr } undef, i64 %t551, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  store { i64, ptr } %t556, ptr %l246, !tbaa !27
  %t557 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t557, label %bb134, label %bb135
bb134:
  %t559 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 0
  %t562 = icmp eq i64 %t560, 0
  br i1 %t562, label %bb136, label %bb137
bb135:
  %t564 = load ptr, ptr %lp9
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !27
  store { i64, ptr } %t565, ptr %l250, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t567 = load ptr, ptr %lp9
  store { i64, ptr } %t566, ptr %t567, !tbaa !27
  %t568 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t568, label %bb138, label %bb139
bb136:
  store { i64, ptr } zeroinitializer, ptr %l246, !tbaa !27
  br label %bb137
bb137:
  %t570 = load i64, ptr %l242
  %t571 = inttoptr i64 %t570 to ptr
  %t572 = load { i64, ptr }, ptr %l246
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = call ptr @__olang_region_or(ptr %t573, ptr null)
  %t575 = icmp ne ptr %t574, null
  %t576 = select i1 %t575, ptr %t574, ptr null
  call void @__olang_region_settle_in(ptr %t571, ptr %t576)
  br label %bb135
bb138:
  %t577 = load { i64, ptr }, ptr %l250
  %t578 = extractvalue { i64, ptr } %t577, 1
  call void @__olang_region_release(ptr %t578)
  store { i64, ptr } zeroinitializer, ptr %l250
  br label %bb139
bb139:
  %t579 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t581 = call { i64, ptr } @compiler_2fload_2ekey(ptr %s9, ptr %s9, { i64, ptr } %t579)
  store { i64, ptr } %t581, ptr %l253
  br label %bb140
bb140:
  %t582 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t582, ptr %l19, !tbaa !27
  %t583 = load ptr, ptr %lp9
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t585, 1
  %t588 = extractvalue { i64, ptr } %t585, 0
  %t589 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t591 = add i64 %t588, %t590
  %t592 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t587, i64 %t588)
  %t593 = getelementptr i8, ptr %t592, i64 %t588
  call void @olang_textcopy(ptr %t593, ptr %t589, i64 %t590)
  %t594 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t595 = insertvalue { i64, ptr } %t594, ptr %t592, 1
  %t599 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s9, { i64, ptr } %t584, { i64, ptr } %t595)
  store i1 %t599, ptr %l258
  br label %bb141
bb141:
  %t600 = load i1, ptr %l258, !tbaa !21
  %t601 = xor i1 %t600, true
  br i1 %t601, label %bb142, label %bb143
bb142:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/load:Loader", ptr %t603, i32 0, i32 4
  %t606 = load ptr, ptr %t605, !tbaa !29
  store ptr %t606, ptr %l261, !tbaa !29
  %t607 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t607, ptr %l262
  %t608 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t610 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s9, ptr %v0, { i64, ptr } %t608)
  store %"compiler/diagmsg:Msg" %t610, ptr %l264
  br label %bb144
bb143:
  br label %bb146
bb144:
  %t611 = load ptr, ptr %l261, !tbaa !29
  %t612 = load { i64, [3 x i64] }, ptr %l262
  %t613 = load %"compiler/diagmsg:Msg", ptr %l264
  %t614 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t611, { i64, [3 x i64] } %t612, %"compiler/diagmsg:Msg" %t613)
  store i64 %t614, ptr %l265
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t616 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t616, ptr %rv
  br label %ret
bb146:
  call void @__olang_scope_close(ptr %s9)
  br label %bb245
bb147:
  %t617 = load { i64, ptr }, ptr %l269, !tbaa !27
  store { i64, ptr } %t617, ptr %l20, !tbaa !27
  %t618 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t620 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t618, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t620, ptr %l271
  br label %bb148
bb148:
  %t621 = load i1, ptr %l271, !tbaa !21
  br i1 %t621, label %bb149, label %bb150
bb149:
  store i1 true, ptr %l272, !tbaa !21
  br label %bb152
bb150:
  %t622 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t624 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t622, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) })
  store i1 %t624, ptr %l274
  br label %bb151
bb151:
  %t625 = load i1, ptr %l274, !tbaa !21
  store i1 %t625, ptr %l272, !tbaa !21
  br label %bb152
bb152:
  %t626 = load i1, ptr %l272, !tbaa !21
  br i1 %t626, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s24
  %t627 = call ptr @__olang_scope_hold(ptr %v2)
  %t628 = ptrtoint ptr %t627 to i64
  store i64 %t628, ptr %l275, !tbaa !24
  %t629 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t629, label %bb155, label %bb156
bb154:
  store %olang.scope zeroinitializer, ptr %s27
  %t631 = call ptr @__olang_scope_hold(ptr %v2)
  %t632 = ptrtoint ptr %t631 to i64
  store i64 %t632, ptr %l287, !tbaa !24
  %t633 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t633, label %bb164, label %bb165
bb155:
  %t635 = call ptr @__olang_region_make(ptr %v2)
  %t636 = ptrtoint ptr %t635 to i64
  store i64 %t636, ptr %l275, !tbaa !24
  br label %bb156
bb156:
  %t637 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t637, 1
  %t640 = extractvalue { i64, ptr } %t637, 0
  %t641 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t642 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t643 = add i64 %t640, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t639, i64 %t640)
  %t645 = getelementptr i8, ptr %t644, i64 %t640
  call void @olang_textcopy(ptr %t645, ptr %t641, i64 %t642)
  %t646 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t644, 1
  %t650 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s24, ptr %s24, { i64, ptr } %t647)
  store { i64, ptr } %t650, ptr %l280
  br label %bb157
bb157:
  %t651 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t651, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = load i64, ptr %l275
  %t655 = inttoptr i64 %t654 to ptr
  %t656 = call ptr @__olang_held_alloc(ptr %t655, i64 %t653)
  call void @olang_textcopy(ptr %t656, ptr %t652, i64 %t653)
  %t657 = insertvalue { i64, ptr } undef, i64 %t653, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t656, 1
  store { i64, ptr } %t658, ptr %l281, !tbaa !27
  %t659 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t659, label %bb158, label %bb159
bb158:
  %t661 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 0
  %t664 = icmp eq i64 %t662, 0
  br i1 %t664, label %bb160, label %bb161
bb159:
  %t666 = load ptr, ptr %lp8
  %t667 = load { i64, ptr }, ptr %t666, !tbaa !27
  store { i64, ptr } %t667, ptr %l285, !tbaa !27
  %t668 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t669 = load ptr, ptr %lp8
  store { i64, ptr } %t668, ptr %t669, !tbaa !27
  %t670 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t670, label %bb162, label %bb163
bb160:
  store { i64, ptr } zeroinitializer, ptr %l281, !tbaa !27
  br label %bb161
bb161:
  %t672 = load i64, ptr %l275
  %t673 = inttoptr i64 %t672 to ptr
  %t674 = load { i64, ptr }, ptr %l281
  %t675 = extractvalue { i64, ptr } %t674, 1
  %t676 = call ptr @__olang_region_or(ptr %t675, ptr null)
  %t677 = icmp ne ptr %t676, null
  %t678 = select i1 %t677, ptr %t676, ptr null
  call void @__olang_region_settle_in(ptr %t673, ptr %t678)
  br label %bb159
bb162:
  %t679 = load { i64, ptr }, ptr %l285
  %t680 = extractvalue { i64, ptr } %t679, 1
  call void @__olang_region_release(ptr %t680)
  store { i64, ptr } zeroinitializer, ptr %l285
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s24)
  br label %bb173
bb164:
  %t681 = call ptr @__olang_region_make(ptr %v2)
  %t682 = ptrtoint ptr %t681 to i64
  store i64 %t682, ptr %l287, !tbaa !24
  br label %bb165
bb165:
  %t683 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t684 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t686 = extractvalue { i64, ptr } %t683, 1
  %t687 = extractvalue { i64, ptr } %t683, 0
  %t688 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t692 = extractvalue { i64, ptr } %t684, 1
  %t693 = extractvalue { i64, ptr } %t684, 0
  %t694 = add i64 %t690, %t693
  %t695 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t696 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t697 = add i64 %t694, %t696
  %t698 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t697)
  call void @olang_textcopy(ptr %t698, ptr %t686, i64 %t687)
  %t699 = getelementptr i8, ptr %t698, i64 %t687
  call void @olang_textcopy(ptr %t699, ptr %t688, i64 %t689)
  %t700 = getelementptr i8, ptr %t699, i64 %t689
  call void @olang_textcopy(ptr %t700, ptr %t692, i64 %t693)
  %t701 = getelementptr i8, ptr %t700, i64 %t693
  call void @olang_textcopy(ptr %t701, ptr %t695, i64 %t696)
  %t702 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t698, 1
  %t706 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s27, ptr %s27, { i64, ptr } %t703)
  store { i64, ptr } %t706, ptr %l293
  br label %bb166
bb166:
  %t707 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 1
  %t709 = extractvalue { i64, ptr } %t707, 0
  %t710 = load i64, ptr %l287
  %t711 = inttoptr i64 %t710 to ptr
  %t712 = call ptr @__olang_held_alloc(ptr %t711, i64 %t709)
  call void @olang_textcopy(ptr %t712, ptr %t708, i64 %t709)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t712, 1
  store { i64, ptr } %t714, ptr %l294, !tbaa !27
  %t715 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t715, label %bb167, label %bb168
bb167:
  %t717 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t718 = extractvalue { i64, ptr } %t717, 0
  %t720 = icmp eq i64 %t718, 0
  br i1 %t720, label %bb169, label %bb170
bb168:
  %t722 = load ptr, ptr %lp8
  %t723 = load { i64, ptr }, ptr %t722, !tbaa !27
  store { i64, ptr } %t723, ptr %l298, !tbaa !27
  %t724 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t725 = load ptr, ptr %lp8
  store { i64, ptr } %t724, ptr %t725, !tbaa !27
  %t726 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8
  br i1 %t726, label %bb171, label %bb172
bb169:
  store { i64, ptr } zeroinitializer, ptr %l294, !tbaa !27
  br label %bb170
bb170:
  %t728 = load i64, ptr %l287
  %t729 = inttoptr i64 %t728 to ptr
  %t730 = load { i64, ptr }, ptr %l294
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = call ptr @__olang_region_or(ptr %t731, ptr null)
  %t733 = icmp ne ptr %t732, null
  %t734 = select i1 %t733, ptr %t732, ptr null
  call void @__olang_region_settle_in(ptr %t729, ptr %t734)
  br label %bb168
bb171:
  %t735 = load { i64, ptr }, ptr %l298
  %t736 = extractvalue { i64, ptr } %t735, 1
  call void @__olang_region_release(ptr %t736)
  store { i64, ptr } zeroinitializer, ptr %l298
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s27)
  br label %bb173
bb173:
  %t737 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t739 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t737, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i1 %t739, ptr %l301
  br label %bb174
bb174:
  %t740 = load i1, ptr %l301, !tbaa !21
  br i1 %t740, label %bb175, label %bb176
bb175:
  %t741 = call ptr @__olang_scope_hold(ptr %v2)
  %t742 = ptrtoint ptr %t741 to i64
  store i64 %t742, ptr %l303, !tbaa !24
  %t743 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t743, label %bb177, label %bb178
bb176:
  %t745 = call ptr @__olang_scope_hold(ptr %v2)
  %t746 = ptrtoint ptr %t745 to i64
  store i64 %t746, ptr %l311, !tbaa !24
  %t747 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t747, label %bb184, label %bb185
bb177:
  %t749 = call ptr @__olang_region_make(ptr %v2)
  %t750 = ptrtoint ptr %t749 to i64
  store i64 %t750, ptr %l303, !tbaa !24
  br label %bb178
bb178:
  %t751 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t753 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %s23, { i64, ptr } %t751)
  store { i64, ptr } %t753, ptr %l306
  br label %bb179
bb179:
  %t754 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t755 = extractvalue { i64, ptr } %t754, 1
  %t756 = extractvalue { i64, ptr } %t754, 0
  %t757 = load i64, ptr %l303
  %t758 = inttoptr i64 %t757 to ptr
  %t759 = call ptr @__olang_held_alloc(ptr %t758, i64 %t756)
  call void @olang_textcopy(ptr %t759, ptr %t755, i64 %t756)
  %t760 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t759, 1
  store { i64, ptr } %t761, ptr %l307, !tbaa !27
  %t762 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t762, label %bb180, label %bb181
bb180:
  %t764 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t765 = extractvalue { i64, ptr } %t764, 0
  %t767 = icmp eq i64 %t765, 0
  br i1 %t767, label %bb182, label %bb183
bb181:
  %t769 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t769, ptr %l302, !tbaa !27
  br label %bb191
bb182:
  store { i64, ptr } zeroinitializer, ptr %l307, !tbaa !27
  br label %bb183
bb183:
  %t770 = load i64, ptr %l303
  %t771 = inttoptr i64 %t770 to ptr
  %t772 = load { i64, ptr }, ptr %l307
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = call ptr @__olang_region_or(ptr %t773, ptr null)
  %t775 = icmp ne ptr %t774, null
  %t776 = select i1 %t775, ptr %t774, ptr null
  call void @__olang_region_settle_in(ptr %t771, ptr %t776)
  br label %bb181
bb184:
  %t777 = call ptr @__olang_region_make(ptr %v2)
  %t778 = ptrtoint ptr %t777 to i64
  store i64 %t778, ptr %l311, !tbaa !24
  br label %bb185
bb185:
  %t779 = load ptr, ptr %l3, !tbaa !29
  %t781 = getelementptr %"compiler/load:Module", ptr %t779, i32 0, i32 2
  %t782 = load { i64, ptr }, ptr %t781, !tbaa !27
  %t783 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t786 = call { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %s23, { i64, ptr } %t782, { i64, ptr } %t783)
  store { i64, ptr } %t786, ptr %l316
  br label %bb186
bb186:
  %t787 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = load i64, ptr %l311
  %t791 = inttoptr i64 %t790 to ptr
  %t792 = call ptr @__olang_held_alloc(ptr %t791, i64 %t789)
  call void @olang_textcopy(ptr %t792, ptr %t788, i64 %t789)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  store { i64, ptr } %t794, ptr %l317, !tbaa !27
  %t795 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t795, label %bb187, label %bb188
bb187:
  %t797 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t797, 0
  %t800 = icmp eq i64 %t798, 0
  br i1 %t800, label %bb189, label %bb190
bb188:
  %t802 = load { i64, ptr }, ptr %l317, !tbaa !27
  store { i64, ptr } %t802, ptr %l302, !tbaa !27
  br label %bb191
bb189:
  store { i64, ptr } zeroinitializer, ptr %l317, !tbaa !27
  br label %bb190
bb190:
  %t803 = load i64, ptr %l311
  %t804 = inttoptr i64 %t803 to ptr
  %t805 = load { i64, ptr }, ptr %l317
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = call ptr @__olang_region_or(ptr %t806, ptr null)
  %t808 = icmp ne ptr %t807, null
  %t809 = select i1 %t808, ptr %t807, ptr null
  call void @__olang_region_settle_in(ptr %t804, ptr %t809)
  br label %bb188
bb191:
  %t810 = load ptr, ptr %lp9
  %t811 = load { i64, ptr }, ptr %t810, !tbaa !27
  store { i64, ptr } %t811, ptr %l321, !tbaa !27
  %t812 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t813 = load ptr, ptr %lp9
  store { i64, ptr } %t812, ptr %t813, !tbaa !27
  %t814 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9
  br i1 %t814, label %bb192, label %bb193
bb192:
  %t816 = load { i64, ptr }, ptr %l321
  %t817 = extractvalue { i64, ptr } %t816, 1
  call void @__olang_region_release(ptr %t817)
  store { i64, ptr } zeroinitializer, ptr %l321
  br label %bb193
bb193:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d186, i32 0, i32 1) }, ptr %l323, !tbaa !27
  %t818 = load { i64, ptr }, ptr %l323, !tbaa !27
  store { i64, ptr } %t818, ptr %l21, !tbaa !27
  %t820 = load ptr, ptr %l3, !tbaa !29
  %t822 = getelementptr %"compiler/load:Module", ptr %t820, i32 0, i32 2
  %t823 = load { i64, ptr }, ptr %t822, !tbaa !27
  store { i64, ptr } %t823, ptr %l326, !tbaa !27
  %t824 = load ptr, ptr %l3, !tbaa !29
  %t826 = getelementptr %"compiler/load:Module", ptr %t824, i32 0, i32 2
  %t827 = load { i64, ptr }, ptr %t826, !tbaa !27
  %t830 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t827, i8 47)
  %t831 = extractvalue { i32, i64 } %t830, 1
  %t832 = extractvalue { i32, i64 } %t830, 0
  store i32 %t832, ptr %l332
  %t833 = icmp ne i32 %t832, 0
  br i1 %t833, label %bb195, label %ok.834, !prof !99
ok.834:
  store i64 %t831, ptr %l331
  br label %bb194
bb194:
  %t835 = load i64, ptr %l331, !tbaa !24
  store i64 %t835, ptr %l327, !tbaa !24
  br label %bb197
bb195:
  br label %bb196
bb196:
  %t836 = load ptr, ptr %l3, !tbaa !29
  %t838 = getelementptr %"compiler/load:Module", ptr %t836, i32 0, i32 2
  %t839 = load { i64, ptr }, ptr %t838, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t839, 0
  store i64 %t841, ptr %l327, !tbaa !24
  br label %bb197
bb197:
  %t843 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t843, 0
  store i64 %t844, ptr %l336, !tbaa !24
  %t845 = icmp sge i64 0, 0
  br i1 %t845, label %bb198, label %bb199
bb198:
  %t847 = load i64, ptr %l327, !tbaa !24
  %t848 = icmp sle i64 0, %t847
  br i1 %t848, label %bb200, label %bb201
bb199:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb200:
  %t850 = load i64, ptr %l327, !tbaa !24
  %t851 = load i64, ptr %l336, !tbaa !24
  %t852 = icmp sle i64 %t850, %t851
  br i1 %t852, label %bb202, label %bb203
bb201:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb202:
  %t854 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = load i64, ptr %l327, !tbaa !24
  %t857 = getelementptr i8, ptr %t855, i64 0
  %t858 = sub i64 %t856, 0
  %t859 = insertvalue { i64, ptr } undef, i64 %t858, 0
  %t860 = insertvalue { i64, ptr } %t859, ptr %t857, 1
  store { i64, ptr } %t860, ptr %l22, !tbaa !27
  %t862 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, ptr %l343, !tbaa !27
  %t865 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t866 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s23, { i64, ptr } %t862, { i64, ptr } %t865)
  store i1 %t866, ptr %l344
  br label %bb204
bb203:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb204:
  %t867 = load i1, ptr %l344, !tbaa !21
  br i1 %t867, label %bb205, label %bb206
bb205:
  %t868 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t870 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t868, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) })
  store i1 %t870, ptr %l347
  br label %bb207
bb206:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb208
bb207:
  %t871 = load i1, ptr %l347, !tbaa !21
  %t872 = xor i1 %t871, true
  store i1 %t872, ptr %l345, !tbaa !21
  br label %bb208
bb208:
  %t874 = load i1, ptr %l345, !tbaa !21
  br i1 %t874, label %bb209, label %bb210
bb209:
  %t875 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t877 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t875, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store i1 %t877, ptr %l351
  br label %bb211
bb210:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb212
bb211:
  %t878 = load i1, ptr %l351, !tbaa !21
  %t879 = xor i1 %t878, true
  store i1 %t879, ptr %l349, !tbaa !21
  br label %bb212
bb212:
  %t881 = load i1, ptr %l349, !tbaa !21
  store i1 %t881, ptr %l23, !tbaa !21
  %t882 = load ptr, ptr %l3, !tbaa !29
  %t884 = getelementptr %"compiler/load:Module", ptr %t882, i32 0, i32 2
  %t885 = load { i64, ptr }, ptr %t884, !tbaa !27
  %t887 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s23, { i64, ptr } %t885, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d190, i32 0, i32 1) })
  store i1 %t887, ptr %l355
  br label %bb213
bb213:
  %t888 = load i1, ptr %l355, !tbaa !21
  br i1 %t888, label %bb214, label %bb215
bb214:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l356, !tbaa !27
  %t889 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t890 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t890, ptr %l358, !tbaa !27
  store { i64, ptr } %t889, ptr %l21, !tbaa !27
  %t892 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e21
  br i1 %t892, label %bb216, label %bb217
bb215:
  store %olang.scope zeroinitializer, ptr %s33
  %t894 = load i1, ptr %l23, !tbaa !21
  br i1 %t894, label %bb218, label %bb219
bb216:
  %t896 = load { i64, ptr }, ptr %l358
  %t897 = extractvalue { i64, ptr } %t896, 1
  call void @__olang_region_release(ptr %t897)
  store { i64, ptr } zeroinitializer, ptr %l358
  br label %bb217
bb217:
  br label %bb234
bb218:
  %t898 = load ptr, ptr %l3, !tbaa !29
  %t900 = getelementptr %"compiler/load:Module", ptr %t898, i32 0, i32 2
  %t901 = load { i64, ptr }, ptr %t900, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) }, ptr %l365, !tbaa !27
  %t904 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t905 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s33, { i64, ptr } %t901, { i64, ptr } %t904)
  store i1 %t905, ptr %l366
  br label %bb220
bb219:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb221
bb220:
  %t906 = load i1, ptr %l366, !tbaa !21
  store i1 %t906, ptr %l361, !tbaa !21
  br label %bb221
bb221:
  %t907 = load i1, ptr %l361, !tbaa !21
  br i1 %t907, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s34
  %t908 = call ptr @__olang_scope_hold(ptr %s23)
  %t909 = ptrtoint ptr %t908 to i64
  store i64 %t909, ptr %l367, !tbaa !24
  %t910 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e21
  br i1 %t910, label %bb224, label %bb225
bb223:
  br label %bb233
bb224:
  %t912 = call ptr @__olang_region_make(ptr %s23)
  %t913 = ptrtoint ptr %t912 to i64
  store i64 %t913, ptr %l367, !tbaa !24
  br label %bb225
bb225:
  %t914 = load ptr, ptr %l3, !tbaa !29
  %t916 = getelementptr %"compiler/load:Module", ptr %t914, i32 0, i32 2
  %t917 = load { i64, ptr }, ptr %t916, !tbaa !27
  %t919 = call { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, ptr %s34, { i64, ptr } %t917, i64 3)
  store { i64, ptr } %t919, ptr %l371
  br label %bb226
bb226:
  %t920 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t921 = extractvalue { i64, ptr } %t920, 1
  %t922 = extractvalue { i64, ptr } %t920, 0
  %t923 = load i64, ptr %l367
  %t924 = inttoptr i64 %t923 to ptr
  %t925 = call ptr @__olang_held_alloc(ptr %t924, i64 %t922)
  call void @olang_textcopy(ptr %t925, ptr %t921, i64 %t922)
  %t926 = insertvalue { i64, ptr } undef, i64 %t922, 0
  %t927 = insertvalue { i64, ptr } %t926, ptr %t925, 1
  store { i64, ptr } %t927, ptr %l372, !tbaa !27
  %t928 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e21
  br i1 %t928, label %bb227, label %bb228
bb227:
  %t930 = load { i64, ptr }, ptr %l372, !tbaa !27
  %t931 = extractvalue { i64, ptr } %t930, 0
  %t933 = icmp eq i64 %t931, 0
  br i1 %t933, label %bb229, label %bb230
bb228:
  %t935 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t935, ptr %l376, !tbaa !27
  %t936 = load { i64, ptr }, ptr %l372, !tbaa !27
  store { i64, ptr } %t936, ptr %l21, !tbaa !27
  %t937 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e21
  br i1 %t937, label %bb231, label %bb232
bb229:
  store { i64, ptr } zeroinitializer, ptr %l372, !tbaa !27
  br label %bb230
bb230:
  %t939 = load i64, ptr %l367
  %t940 = inttoptr i64 %t939 to ptr
  %t941 = load { i64, ptr }, ptr %l372
  %t942 = extractvalue { i64, ptr } %t941, 1
  %t943 = call ptr @__olang_region_or(ptr %t942, ptr null)
  %t944 = icmp ne ptr %t943, null
  %t945 = select i1 %t944, ptr %t943, ptr null
  call void @__olang_region_settle_in(ptr %t940, ptr %t945)
  br label %bb228
bb231:
  %t946 = load { i64, ptr }, ptr %l376
  %t947 = extractvalue { i64, ptr } %t946, 1
  call void @__olang_region_release(ptr %t947)
  store { i64, ptr } zeroinitializer, ptr %l376
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s34)
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s33)
  br label %bb234
bb234:
  %t948 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t950 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t948, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) })
  store i1 %t950, ptr %l379
  br label %bb235
bb235:
  %t951 = load i1, ptr %l379, !tbaa !21
  %t952 = xor i1 %t951, true
  br i1 %t952, label %bb236, label %bb237
bb236:
  %t954 = load ptr, ptr %lp9
  %t955 = load { i64, ptr }, ptr %t954, !tbaa !27
  %t956 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t958 = extractvalue { i64, ptr } %t956, 1
  %t959 = extractvalue { i64, ptr } %t956, 0
  %t960 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t961 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t962 = add i64 %t959, %t961
  %t963 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t962)
  call void @olang_textcopy(ptr %t963, ptr %t958, i64 %t959)
  %t964 = getelementptr i8, ptr %t963, i64 %t959
  call void @olang_textcopy(ptr %t964, ptr %t960, i64 %t961)
  %t965 = insertvalue { i64, ptr } undef, i64 %t962, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t963, 1
  %t970 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s23, { i64, ptr } %t955, { i64, ptr } %t966)
  store i1 %t970, ptr %l386
  br label %bb238
bb237:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb239
bb238:
  %t971 = load i1, ptr %l386, !tbaa !21
  %t972 = xor i1 %t971, true
  store i1 %t972, ptr %l381, !tbaa !21
  br label %bb239
bb239:
  %t974 = load i1, ptr %l381, !tbaa !21
  br i1 %t974, label %bb240, label %bb241
bb240:
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t977 = getelementptr %"compiler/load:Loader", ptr %t975, i32 0, i32 4
  %t978 = load ptr, ptr %t977, !tbaa !29
  store ptr %t978, ptr %l389, !tbaa !29
  %t979 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t979, ptr %l390
  %t980 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t982 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s23, ptr %v0, { i64, ptr } %t980)
  store %"compiler/diagmsg:Msg" %t982, ptr %l392
  br label %bb242
bb241:
  br label %bb244
bb242:
  %t983 = load ptr, ptr %l389, !tbaa !29
  %t984 = load { i64, [3 x i64] }, ptr %l390
  %t985 = load %"compiler/diagmsg:Msg", ptr %l392
  %t986 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t983, { i64, [3 x i64] } %t984, %"compiler/diagmsg:Msg" %t985)
  store i64 %t986, ptr %l393
  br label %bb243
bb243:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t988 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t988, ptr %rv
  br label %ret
bb244:
  call void @__olang_scope_close(ptr %s23)
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s8)
  br label %bb246
bb246:
  %t989 = load ptr, ptr %lp8
  %t990 = load { i64, ptr }, ptr %t989, !tbaa !27
  %t992 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t990)
  store i1 %t992, ptr %l396
  br label %bb247
bb247:
  %t993 = load i1, ptr %l396, !tbaa !21
  %t994 = xor i1 %t993, true
  br i1 %t994, label %bb248, label %bb249
bb248:
  store i1 true, ptr %l398, !tbaa !21
  br label %bb251
bb249:
  %t996 = load ptr, ptr %lp8
  %t997 = load { i64, ptr }, ptr %t996, !tbaa !27
  %t999 = call i1 @std_2fos_2eIsDir(ptr %v2, { i64, ptr } %t997)
  store i1 %t999, ptr %l400
  br label %bb250
bb250:
  %t1000 = load i1, ptr %l400, !tbaa !21
  store i1 %t1000, ptr %l398, !tbaa !21
  br label %bb251
bb251:
  %t1001 = load i1, ptr %l398, !tbaa !21
  br i1 %t1001, label %bb252, label %bb253
bb252:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1004 = getelementptr %"compiler/load:Loader", ptr %t1002, i32 0, i32 4
  %t1005 = load ptr, ptr %t1004, !tbaa !29
  store ptr %t1005, ptr %l402, !tbaa !29
  %t1006 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t1006, ptr %l403
  %t1007 = load ptr, ptr %lp8
  %t1008 = load { i64, ptr }, ptr %t1007, !tbaa !27
  %t1010 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v2, ptr %v0, { i64, ptr } %t1008)
  store %"compiler/diagmsg:Msg" %t1010, ptr %l405
  br label %bb254
bb253:
  br label %bb256
bb254:
  %t1011 = load ptr, ptr %l402, !tbaa !29
  %t1012 = load { i64, [3 x i64] }, ptr %l403
  %t1013 = load %"compiler/diagmsg:Msg", ptr %l405
  %t1014 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t1011, { i64, [3 x i64] } %t1012, %"compiler/diagmsg:Msg" %t1013)
  store i64 %t1014, ptr %l406
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s0)
  %t1016 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t1016, ptr %rv
  br label %ret
bb256:
  %t1017 = load ptr, ptr %lp8
  %t1018 = load { i64, ptr }, ptr %t1017, !tbaa !27
  %t1019 = load ptr, ptr %lp9
  %t1020 = load { i64, ptr }, ptr %t1019, !tbaa !27
  %t1022 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1018, 0
  %t1024 = insertvalue { { i64, ptr }, { i64, ptr } } %t1022, { i64, ptr } %t1020, 1
  call void @__olang_scope_close(ptr %s0)
  %t1026 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, { { i64, ptr }, { i64, ptr } } %t1024, 1
  store { i32, { { i64, ptr }, { i64, ptr } } } %t1026, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, { i64, ptr } } }, ptr %rv
  ret { i32, { { i64, ptr }, { i64, ptr } } } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca i64
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l73 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb6
bb6:
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t17, ptr %l14
  br label %bb7
bb7:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb10
bb9:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = extractvalue { i64, ptr } %t29, 0
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t31, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l16, !tbaa !27
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 15
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t54, ptr %t50, i64 %t51)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t42, { i64, ptr } %t56)
  store i1 %t60, ptr %l30
  br label %bb11
bb11:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t62 = call ptr @__olang_scope_hold(ptr %s0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l31, !tbaa !24
  %t64 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t64, label %bb14, label %bb15
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 16
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = extractvalue { i64, ptr } %t70, 0
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = getelementptr i8, ptr %t77, i64 %t73
  call void @olang_textcopy(ptr %t78, ptr %t74, i64 %t75)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t66, { i64, ptr } %t80)
  store i1 %t84, ptr %l59
  br label %bb30
bb14:
  %t85 = call ptr @__olang_region_make(ptr %s0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/load:Loader", ptr %t87, i32 0, i32 15
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l36, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l38, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l39, !tbaa !24
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb16, label %bb17
bb16:
  %t103 = load i64, ptr %l36, !tbaa !24
  %t104 = load i64, ptr %l38, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb18:
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = load i64, ptr %l39, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb20:
  %t111 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l36, !tbaa !24
  %t114 = load i64, ptr %l38, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = load i64, ptr %l31
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = call ptr @__olang_held_alloc(ptr %t123, i64 %t121)
  call void @olang_textcopy(ptr %t124, ptr %t120, i64 %t121)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l44, !tbaa !27
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t127, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb22:
  %t129 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb24, label %bb25
bb23:
  %t134 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t134, ptr %l48, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t135, ptr %l4, !tbaa !27
  %t136 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t136, label %bb26, label %bb27
bb24:
  store { i64, ptr } zeroinitializer, ptr %l44, !tbaa !27
  br label %bb25
bb25:
  %t138 = load i64, ptr %l31
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = load { i64, ptr }, ptr %l44
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = call ptr @__olang_region_or(ptr %t141, ptr null)
  %t143 = icmp ne ptr %t142, null
  %t144 = select i1 %t143, ptr %t142, ptr null
  call void @__olang_region_settle_in(ptr %t139, ptr %t144)
  br label %bb23
bb26:
  %t145 = load { i64, ptr }, ptr %l48
  %t146 = extractvalue { i64, ptr } %t145, 1
  call void @__olang_region_release(ptr %t146)
  store { i64, ptr } zeroinitializer, ptr %l48
  br label %bb27
bb27:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t148, ptr %l52, !tbaa !27
  store { i64, ptr } %t147, ptr %l5, !tbaa !27
  %t150 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e5
  br i1 %t150, label %bb28, label %bb29
bb28:
  %t152 = load { i64, ptr }, ptr %l52
  %t153 = extractvalue { i64, ptr } %t152, 1
  call void @__olang_region_release(ptr %t153)
  store { i64, ptr } zeroinitializer, ptr %l52
  br label %bb29
bb29:
  br label %bb48
bb30:
  %t154 = load i1, ptr %l59, !tbaa !21
  br i1 %t154, label %bb31, label %bb32
bb31:
  %t155 = call ptr @__olang_scope_hold(ptr %s0)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l60, !tbaa !24
  %t157 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t157, label %bb33, label %bb34
bb32:
  br label %bb47
bb33:
  %t159 = call ptr @__olang_region_make(ptr %s0)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l60, !tbaa !24
  br label %bb34
bb34:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/load:Loader", ptr %t161, i32 0, i32 16
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l65, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l67, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  store i64 %t173, ptr %l68, !tbaa !24
  %t174 = load i64, ptr %l65, !tbaa !24
  %t175 = icmp sge i64 %t174, 0
  br i1 %t175, label %bb35, label %bb36
bb35:
  %t177 = load i64, ptr %l65, !tbaa !24
  %t178 = load i64, ptr %l67, !tbaa !24
  %t179 = icmp sle i64 %t177, %t178
  br i1 %t179, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb37:
  %t181 = load i64, ptr %l67, !tbaa !24
  %t182 = load i64, ptr %l68, !tbaa !24
  %t183 = icmp sle i64 %t181, %t182
  br i1 %t183, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb39:
  %t185 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l65, !tbaa !24
  %t188 = load i64, ptr %l67, !tbaa !24
  %t189 = getelementptr i8, ptr %t186, i64 %t187
  %t190 = sub i64 %t188, %t187
  %t191 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t189, 1
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = extractvalue { i64, ptr } %t192, 0
  %t196 = load i64, ptr %l60
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = call ptr @__olang_held_alloc(ptr %t197, i64 %t195)
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l73, !tbaa !27
  %t201 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t201, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb41:
  %t203 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t206 = icmp eq i64 %t204, 0
  br i1 %t206, label %bb43, label %bb44
bb42:
  %t208 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t208, ptr %l77, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t209, ptr %l4, !tbaa !27
  %t210 = load i1, ptr @olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4
  br i1 %t210, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l73, !tbaa !27
  br label %bb44
bb44:
  %t212 = load i64, ptr %l60
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = load { i64, ptr }, ptr %l73
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = call ptr @__olang_region_or(ptr %t215, ptr null)
  %t217 = icmp ne ptr %t216, null
  %t218 = select i1 %t217, ptr %t216, ptr null
  call void @__olang_region_settle_in(ptr %t213, ptr %t218)
  br label %bb42
bb45:
  %t219 = load { i64, ptr }, ptr %l77
  %t220 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release(ptr %t220)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t221 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t221, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d202, i32 0, i32 1) })
  store i1 %t223, ptr %l80
  br label %bb49
bb49:
  %t224 = load i1, ptr %l80, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb50, label %bb51
bb50:
  %t227 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t227, 1
  %t231 = extractvalue { i64, ptr } %t227, 0
  %t233 = extractvalue { i64, ptr } %t228, 1
  %t234 = extractvalue { i64, ptr } %t228, 0
  %t235 = add i64 %t231, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = getelementptr i8, ptr %t236, i64 %t231
  call void @olang_textcopy(ptr %t237, ptr %t233, i64 %t234)
  %t238 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t236, 1
  store { i64, ptr } %t239, ptr %l82, !tbaa !27
  br label %bb53
bb51:
  %t241 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s0, { i64, ptr } %t241)
  store { i64, ptr } %t243, ptr %l87
  br label %bb52
bb52:
  %t244 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t245, i64 %t246)
  %t248 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l82, !tbaa !27
  br label %bb53
bb53:
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t251, ptr %lp6
  %t252 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t253 = load ptr, ptr %lp6
  store { i64, ptr } %t252, ptr %t253, !tbaa !27
  %t254 = load ptr, ptr %lp6
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t257 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s0, { i64, ptr } %t255, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d203, i32 0, i32 1) })
  store i1 %t257, ptr %l90
  br label %bb54
bb54:
  %t258 = load i1, ptr %l90, !tbaa !21
  br i1 %t258, label %bb55, label %bb56
bb55:
  %t259 = load ptr, ptr %lp6
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t264 = sub i64 %t262, 6
  store i64 %t264, ptr %l94, !tbaa !24
  %t265 = load ptr, ptr %lp6
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l95, !tbaa !24
  %t268 = icmp sge i64 0, 0
  br i1 %t268, label %bb57, label %bb58
bb56:
  %t270 = load ptr, ptr %lp6
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  store { i64, ptr } %t271, ptr %l91, !tbaa !27
  br label %bb63
bb57:
  %t273 = load i64, ptr %l94, !tbaa !24
  %t274 = icmp sle i64 0, %t273
  br i1 %t274, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb59:
  %t276 = load i64, ptr %l94, !tbaa !24
  %t277 = load i64, ptr %l95, !tbaa !24
  %t278 = icmp sle i64 %t276, %t277
  br i1 %t278, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb61:
  %t280 = load ptr, ptr %lp6
  %t281 = getelementptr { i64, ptr }, ptr %t280, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l94, !tbaa !24
  %t284 = getelementptr i8, ptr %t282, i64 0
  %t285 = sub i64 %t283, 0
  %t286 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t284, 1
  %t289 = extractvalue { i64, ptr } %t287, 1
  %t290 = extractvalue { i64, ptr } %t287, 0
  %t291 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t290)
  call void @olang_textcopy(ptr %t291, ptr %t289, i64 %t290)
  %t292 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l91, !tbaa !27
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t295 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t295, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fload_2ecompiler_2fload_3aLoader_2esharedCTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i1
  %l45 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fload_2eCTypeDecls(ptr %v1, ptr %v2, { i64, ptr } %a1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  %t10 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %t10
  %t11 = load ptr, ptr %lp3
  %t13 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v2, ptr %v2, ptr %t11)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t13, ptr %l12
  br label %bb3
bb3:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t14, ptr %lp4
  %t15 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l12
  %t16 = load ptr, ptr %lp4
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t15, ptr %t16
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %lp4
  %t19 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v2, ptr %v2, ptr %t17)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23, !prof !99
ok.23:
  store { i64, ptr } %t20, ptr %l15
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  br label %bb8
bb6:
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  store i1 %t28, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb8:
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = load ptr, ptr %lp3
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v2, ptr %v2, ptr %s2, ptr %t31, { i64, ptr } %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l24
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb10, label %ok.39, !prof !99
ok.39:
  store { i64, ptr } %t36, ptr %l23
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  br label %bb13
bb10:
  %t41 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t41, 65536
  br i1 %t42, label %bb11, label %bb12
bb11:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a82b02dae8c2ac74_a1c9be326debd858)
  unreachable
bb12:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cb2680ed80c29ba8_266600b794f46714)
  unreachable
bb13:
  %t44 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t47, i64 %t48)
  %t56 = getelementptr i8, ptr %t55, i64 %t48
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t59, ptr %lp6
  %t61 = load ptr, ptr %lp6
  store { i64, ptr } %t58, ptr %t61, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 22
  %t65 = load ptr, ptr %lp6
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t69 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t64, { i64, ptr } %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l32
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb15, label %ok.73, !prof !99
ok.73:
  store i64 %t70, ptr %l31
  br label %bb14
bb14:
  %t74 = load i64, ptr %l31, !tbaa !24
  store i64 %t74, ptr %l27, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb17
bb17:
  %t75 = load i64, ptr %l27, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp sge i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t80 = load i64, ptr %l7, !tbaa !24
  store i64 %t80, ptr %l36, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/load:Loader", ptr %t81, i32 0, i32 10
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l39
  br label %bb20
bb19:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb21
bb20:
  %t86 = load i64, ptr %l36, !tbaa !24
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 10
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t93, i64 %t94)
  store ptr %t97, ptr %l45
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t98 = load ptr, ptr %l45, !tbaa !29
  %t100 = getelementptr %"compiler/load:Module", ptr %t98, i32 0, i32 33
  %t101 = load i1, ptr %t100, !tbaa !21
  store i1 %t101, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t103 = load i1, ptr %l41, !tbaa !21
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t104 = load ptr, ptr %lp2
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t106 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v2, ptr %v2, ptr %t104, { i64, ptr } %t105, i64 %t106)
  br label %bb28
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 22
  store ptr %t112, ptr %l52, !tbaa !29
  %t113 = load ptr, ptr %lp6
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l53, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 10
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l56
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t122 = load i64, ptr %l56, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t120, { i64, ptr } %t121, i64 %t122)
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb4
bb33:
  %t123 = load ptr, ptr %lp2
  %t124 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t123
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t124, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etargets(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/load:Import"
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/load:Import"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t3 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 11
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i64, ptr %l12, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/load:Import" %t26, ptr %l19
  br label %bb7
bb7:
  %t27 = load %"compiler/load:Import", ptr %l19
  store %"compiler/load:Import" %t27, ptr %l5
  %t28 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l42 = alloca i64
  %l49 = alloca i64
  %l62 = alloca i64
  %l70 = alloca i64
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l118 = alloca i64
  %l129 = alloca i64
  %l139 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f33836f530001f0a_3e5ddd8b9e2e63ae)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 17
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load i64, ptr %l23, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 17
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t25, i32 %t35)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t40, i64 %a4)
  br label %bb6
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 19
  %t47 = load i64, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t46, i64 %t47)
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/load:Module", ptr %t50, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v1, ptr %t52, i1 false)
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 21
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 22
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t59)
  store i64 %t61, ptr %l42
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t63 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t62, i64 %t63)
  br label %bb10
bb10:
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t68, 1
  %t71 = load i64, ptr %l3, !tbaa !24
  %t76 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i64 %t70, i64 %t71)
  store i64 %t76, ptr %l49
  br label %bb12
bb12:
  %t77 = load i64, ptr %l49, !tbaa !24
  store i64 %t77, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb13, label %bb14
bb13:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 22
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t88, i64 %t91)
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t102 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchClose(ptr %v0, ptr %v1, ptr %t94, ptr %t95, i64 %t96, i64 %t97)
  store i64 %t102, ptr %l62
  br label %bb17
bb17:
  %t103 = load i64, ptr %l62, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp slt i64 %t104, 0
  br i1 %t106, label %bb18, label %bb19
bb18:
  %t108 = load i64, ptr %l3, !tbaa !24
  store i64 %t108, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t118 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t110, ptr %t111, i64 %t112, i64 %t113)
  store i64 %t118, ptr %l70
  br label %bb21
bb21:
  %t119 = load i64, ptr %l70, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t122, 1
  %t125 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t120, ptr %t121, i64 %t124, i64 %t125, i64 %t119)
  br label %bb22
bb22:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t134 = load i64, ptr %l10, !tbaa !24
  %t138 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eafterBranch(ptr %v0, ptr %v1, ptr %t132, ptr %t133, i64 %t134)
  store i64 %t138, ptr %l80
  br label %bb23
bb23:
  %t139 = load i64, ptr %l80, !tbaa !24
  store i64 %t139, ptr %l7, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l81, !tbaa !27
  %t141 = load i64, ptr %l7, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/token:Token", ptr %t144, i64 %t141
  %t146 = getelementptr %"compiler/token:Token", ptr %t145, i32 0, i32 0
  %t147 = load i32, ptr %t146, !range !{i32 0, i32 116}
  %t149 = trunc i64 10 to i32
  %t150 = icmp eq i32 %t147, %t149
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb24, label %bb25
bb24:
  %t154 = load i64, ptr %l7, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l8, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t161, ptr %l90, !tbaa !27
  %t162 = load i64, ptr %l7, !tbaa !24
  %t164 = add i64 %t162, 1
  %t166 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr %"compiler/token:Token", ptr %t167, i64 %t164
  %t169 = getelementptr %"compiler/token:Token", ptr %t168, i32 0, i32 0
  %t170 = load i32, ptr %t169, !range !{i32 0, i32 116}
  %t172 = trunc i64 9 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb27, label %bb28
bb27:
  %t175 = load i64, ptr %l7, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l7, !tbaa !24
  br label %bb44
bb28:
  br label %bb29
bb29:
  %t180 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t180, ptr %l98, !tbaa !27
  %t181 = load i64, ptr %l7, !tbaa !24
  %t183 = add i64 %t181, 1
  %t185 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr %"compiler/token:Token", ptr %t186, i64 %t183
  %t188 = getelementptr %"compiler/token:Token", ptr %t187, i32 0, i32 0
  %t189 = load i32, ptr %t188, !range !{i32 0, i32 116}
  %t191 = trunc i64 114 to i32
  %t192 = icmp eq i32 %t189, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb30, label %bb31
bb30:
  %t196 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t196, ptr %l105, !tbaa !27
  %t197 = load i64, ptr %l7, !tbaa !24
  %t199 = add i64 %t197, 1
  %t201 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr %"compiler/token:Token", ptr %t202, i64 %t199
  %t204 = getelementptr %"compiler/token:Token", ptr %t203, i32 0, i32 0
  %t205 = load i32, ptr %t204, !range !{i32 0, i32 116}
  %t207 = trunc i64 79 to i32
  %t208 = icmp eq i32 %t205, %t207
  %t210 = xor i1 %t208, true
  store i1 %t210, ptr %l104, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t212 = load i1, ptr %l104, !tbaa !21
  br i1 %t212, label %bb33, label %bb34
bb33:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t219, 1
  %t222 = load i64, ptr %l3, !tbaa !24
  %t227 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchClose(ptr %v0, ptr %v1, ptr %t217, ptr %t218, i64 %t221, i64 %t222)
  store i64 %t227, ptr %l118
  br label %bb36
bb36:
  %t228 = load i64, ptr %l118, !tbaa !24
  store i64 %t228, ptr %l12, !tbaa !24
  %t229 = load i64, ptr %l12, !tbaa !24
  %t231 = icmp slt i64 %t229, 0
  br i1 %t231, label %bb37, label %bb38
bb37:
  %t233 = load i64, ptr %l3, !tbaa !24
  store i64 %t233, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/load:Module", ptr %t235, i32 0, i32 20
  %t238 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v1, ptr %t237, i64 %t238, i1 true)
  br label %bb40
bb40:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t243 = load i64, ptr %l6, !tbaa !24
  %t244 = load i64, ptr %l8, !tbaa !24
  %t249 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t241, ptr %t242, i64 %t243, i64 %t244)
  store i64 %t249, ptr %l129
  br label %bb41
bb41:
  %t250 = load i64, ptr %l129, !tbaa !24
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t253 = load i64, ptr %l7, !tbaa !24
  %t255 = add i64 %t253, 2
  %t256 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t251, ptr %t252, i64 %t255, i64 %t256, i64 %t250)
  br label %bb42
bb42:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t265 = load i64, ptr %l12, !tbaa !24
  %t269 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eafterBranch(ptr %v0, ptr %v1, ptr %t263, ptr %t264, i64 %t265)
  store i64 %t269, ptr %l139
  br label %bb43
bb43:
  %t270 = load i64, ptr %l139, !tbaa !24
  store i64 %t270, ptr %rv
  br label %ret
bb44:
  br label %bb11
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2efileStamp(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/os:FileInfo"
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca %"std/os:FileInfo"
  %l23 = alloca %"std/os:FileInfo"
  %l24 = alloca i32
  %l26 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d205, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %s0, { i64, ptr } %t21)
  store { i64, ptr } %t23, ptr %l11
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t26 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } %t24)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb7, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l13
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  br label %bb11
bb7:
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t37, ptr %l1, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d208, i32 0, i32 1) })
  store i1 %t40, ptr %l18
  br label %bb12
bb12:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t52 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t50)
  %t53 = extractvalue { i32, %"std/os:FileInfo" } %t52, 1
  %t54 = extractvalue { i32, %"std/os:FileInfo" } %t52, 0
  store i32 %t54, ptr %l24
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store %"std/os:FileInfo" %t53, ptr %l23
  br label %bb16
bb16:
  %t57 = load %"std/os:FileInfo", ptr %l23
  store %"std/os:FileInfo" %t57, ptr %l21
  br label %bb21
bb17:
  %t58 = load i32, ptr %l24, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  store i1 %t61, ptr %l26, !tbaa !21
  %t62 = load i32, ptr %l24, !tbaa !23
  %t63 = ashr i32 %t62, 16
  %t65 = icmp eq i32 %t63, 1
  br i1 %t65, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb21:
  %t75 = load %"std/os:FileInfo", ptr %l21
  store %"std/os:FileInfo" %t75, ptr %l2
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t77 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 1
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 2
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = extractvalue { i64, ptr } %t76, 1
  %t83 = extractvalue { i64, ptr } %t76, 0
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t78)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t94 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t82, i64 %t83)
  %t97 = getelementptr i8, ptr %t96, i64 %t83
  call void @olang_textcopy(ptr %t97, ptr %t84, i64 %t85)
  %t98 = getelementptr i8, ptr %t97, i64 %t85
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t78)
  %t100 = getelementptr i8, ptr %t98, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t90, i64 %t91)
  %t101 = getelementptr i8, ptr %t100, i64 %t91
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t80)
  %t103 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l60 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l103 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = mul i64 0, %t19
  %t22 = add i64 0, %t20
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = mul i64 1, %t23
  %t26 = add i64 0, %t24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = mul i64 0, %t27
  %t30 = add i64 0, %t28
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t32 = mul i64 1, %t31
  %t34 = add i64 0, %t32
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = icmp sgt i64 0, -4611686018427387904
  %t36 = icmp slt i64 0, 4611686018427387904
  %t39 = and i1 %t35, %t36
  %t42 = and i1 %t15, %t39
  %t43 = icmp sgt i64 0, -4611686018427387904
  %t44 = icmp slt i64 0, 4611686018427387904
  %t47 = and i1 %t43, %t44
  %t50 = and i1 %t42, %t47
  %t51 = icmp sgt i64 0, -2147483648
  %t52 = icmp slt i64 0, 2147483648
  %t55 = and i1 %t51, %t52
  %t58 = and i1 %t50, %t55
  %t59 = icmp sgt i64 1, -2147483648
  %t60 = icmp slt i64 1, 2147483648
  %t63 = and i1 %t59, %t60
  %t66 = and i1 %t58, %t63
  %t67 = load i64, ptr %l18, !tbaa !24
  %t68 = icmp sle i64 0, %t67
  %t71 = and i1 %t66, %t68
  %t72 = load i64, ptr %l22, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  %t76 = and i1 %t71, %t73
  %t77 = load i64, ptr %l18, !tbaa !24
  %t78 = load i64, ptr %l20, !tbaa !24
  %t79 = icmp sle i64 %t77, %t78
  %t82 = and i1 %t76, %t79
  %t83 = load i64, ptr %l22, !tbaa !24
  %t84 = load i64, ptr %l24, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  %t88 = and i1 %t82, %t85
  %t89 = load i64, ptr %l20, !tbaa !24
  %t90 = load i64, ptr %l16, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  %t94 = and i1 %t88, %t91
  %t95 = load i64, ptr %l24, !tbaa !24
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  %t100 = and i1 %t94, %t97
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  %t106 = or i1 %t103, %t100
  br i1 %t106, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb15
bb3:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t116 = load i64, ptr %l4, !tbaa !24
  store i64 %t116, ptr %l6, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %l60, !tbaa !27
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i8, ptr %t122, i64 %t119
  %t124 = load i8, ptr %t123, !tbaa !32
  store i8 %t124, ptr %l7, !tbaa !22
  %t126 = load i8, ptr %l7, !tbaa !22
  %t128 = icmp eq i8 %t126, 47
  br i1 %t128, label %bb7, label %bb8
bb7:
  %t130 = load i64, ptr %l2, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l2, !tbaa !24
  %t135 = load i64, ptr %l2, !tbaa !24
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp eq i64 %t135, %t136
  br i1 %t139, label %bb9, label %bb10
bb8:
  br label %bb12
bb9:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l71, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t146 = getelementptr i8, ptr %t144, i64 0
  %t147 = sub i64 %t142, 0
  %t148 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  store { i64, ptr } %t149, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t151 = load i64, ptr %l4, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  br label %bb33
bb15:
  %t156 = load i64, ptr %l4, !tbaa !24
  %t157 = load i64, ptr %l5, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb16, label %bb17
bb16:
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t164 = load i64, ptr %l4, !tbaa !24
  store i64 %t164, ptr %l6, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t166, ptr %l82, !tbaa !27
  %t167 = load i64, ptr %l4, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i8, ptr %t170, i64 %t167
  %t172 = load i8, ptr %t171, !tbaa !32
  store i8 %t172, ptr %l7, !tbaa !22
  %t174 = load i8, ptr %l7, !tbaa !22
  %t176 = icmp eq i8 %t174, 47
  br i1 %t176, label %bb19, label %bb20
bb19:
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l2, !tbaa !24
  %t183 = load i64, ptr %l2, !tbaa !24
  %t184 = load i64, ptr %l1, !tbaa !24
  %t187 = icmp eq i64 %t183, %t184
  br i1 %t187, label %bb21, label %bb22
bb20:
  br label %bb30
bb21:
  %t189 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t189, ptr %l93, !tbaa !27
  %t190 = load i64, ptr %l6, !tbaa !24
  store i64 %t190, ptr %l94, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l95, !tbaa !24
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb23, label %bb24
bb22:
  br label %bb29
bb23:
  %t195 = load i64, ptr %l94, !tbaa !24
  %t196 = icmp sle i64 0, %t195
  br i1 %t196, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb25:
  %t198 = load i64, ptr %l94, !tbaa !24
  %t199 = load i64, ptr %l95, !tbaa !24
  %t200 = icmp sle i64 %t198, %t199
  br i1 %t200, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb27:
  %t202 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = load i64, ptr %l94, !tbaa !24
  %t205 = getelementptr i8, ptr %t203, i64 0
  %t206 = sub i64 %t204, 0
  %t207 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  store { i64, ptr } %t208, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t210 = load i64, ptr %l4, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l4, !tbaa !24
  br label %bb15
bb32:
  br label %bb33
bb33:
  %t215 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t215, ptr %l103, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t216, 0
  store i64 %t219, ptr %l106, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l107, !tbaa !24
  %t222 = icmp sge i64 0, 0
  br i1 %t222, label %bb34, label %bb35
bb34:
  %t224 = load i64, ptr %l106, !tbaa !24
  %t225 = icmp sle i64 0, %t224
  br i1 %t225, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
bb36:
  %t227 = load i64, ptr %l106, !tbaa !24
  %t228 = load i64, ptr %l107, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
bb38:
  %t231 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l106, !tbaa !24
  %t234 = getelementptr i8, ptr %t232, i64 0
  %t235 = sub i64 %t233, 0
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  store { i64, ptr } %t237, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fload_2ekeepFile(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i1
  %l31 = alloca i32
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l7, !tbaa !21
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = call i32 @compiler_2ftarget_2ePid()
  store i32 %t17, ptr %l12
  br label %bb7
bb7:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = load i32, ptr %l12, !tbaa !23
  %t25 = sext i32 %t24 to i64
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t19, i64 %t20)
  %t32 = getelementptr i8, ptr %t31, i64 %t20
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  %t34 = call i64 @__olang_fmt_i64(ptr %t33, i64 %t25)
  %t35 = getelementptr i8, ptr %t33, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t31, 1
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t39, { i64, ptr } %a2)
  store i32 %t44, ptr %l17
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb9, label %ok.46, !prof !99
ok.46:
  br label %bb8
bb8:
  br label %bb13
bb9:
  %t47 = load i32, ptr %l17, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l19, !tbaa !21
  %t51 = load i32, ptr %l17, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb13:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t61 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v1, { i64, ptr } %t57, { i64, ptr } %t58)
  store i32 %t61, ptr %l25
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb15, label %ok.63, !prof !99
ok.63:
  br label %bb14
bb14:
  br label %bb25
bb15:
  %t64 = load i32, ptr %l25, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  store i1 %t67, ptr %l27, !tbaa !21
  %t68 = load i32, ptr %l25, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  br i1 %t71, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t73)
  store i32 %t75, ptr %l31
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb20, label %ok.77, !prof !99
ok.77:
  br label %bb19
bb19:
  br label %bb24
bb20:
  %t78 = load i32, ptr %l31, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l33, !tbaa !21
  %t82 = load i32, ptr %l31, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  br i1 %t85, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ekey(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %t3, i64 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !37
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %t8, i64 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !37
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %t13, i64 2
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t17 = extractvalue { i64, ptr } %t5, 1
  %t18 = extractvalue { i64, ptr } %t5, 0
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %t10, 1
  %t24 = extractvalue { i64, ptr } %t10, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t15, 1
  %t31 = extractvalue { i64, ptr } %t15, 0
  %t32 = add i64 %t28, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t17, i64 %t18)
  %t34 = getelementptr i8, ptr %t33, i64 %t18
  call void @olang_textcopy(ptr %t34, ptr %t19, i64 %t20)
  %t35 = getelementptr i8, ptr %t34, i64 %t20
  call void @olang_textcopy(ptr %t35, ptr %t23, i64 %t24)
  %t36 = getelementptr i8, ptr %t35, i64 %t24
  call void @olang_textcopy(ptr %t36, ptr %t26, i64 %t27)
  %t37 = getelementptr i8, ptr %t36, i64 %t27
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t33, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fload_2ememberAhead(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l17 = alloca i64
  %l20 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i1
  %l42 = alloca { i64, ptr }
  %l62 = alloca i1
  %l65 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = sub i64 %t5, 1
  store i64 %t7, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t37, 1
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t39, 2147483648
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  %t45 = and i1 %t40, %t42
  store i1 %t45, ptr %l32, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb8, label %bb9
bb8:
  br label %bb36
bb9:
  br label %bb10
bb10:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l8, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l42, !tbaa !27
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i64 %t65
  %t70 = getelementptr %"compiler/token:Token", ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70, !range !{i32 0, i32 116}
  store i32 %t71, ptr %l9
  %t73 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t75 = trunc i64 98 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb11, label %bb12
bb11:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l2, !tbaa !24
  br label %bb28
bb12:
  %t83 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t85 = trunc i64 100 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb13, label %bb14
bb13:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = sub i64 %t88, 1
  store i64 %t91, ptr %l2, !tbaa !24
  br label %bb27
bb14:
  %t93 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t95 = trunc i64 109 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb15, label %bb16
bb15:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = sub i64 %t98, 2
  store i64 %t101, ptr %l2, !tbaa !24
  br label %bb26
bb16:
  %t103 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t105 = trunc i64 8 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb19
bb18:
  %t108 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t110 = trunc i64 114 to i32
  %t111 = icmp eq i32 %t108, %t110
  store i1 %t111, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l62, !tbaa !21
  br i1 %t113, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb22
bb21:
  %t114 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t116 = trunc i64 78 to i32
  %t117 = icmp eq i32 %t114, %t116
  store i1 %t117, ptr %l65, !tbaa !21
  br label %bb22
bb22:
  %t119 = load i1, ptr %l65, !tbaa !21
  br i1 %t119, label %bb23, label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t121 = load i64, ptr %l2, !tbaa !24
  %t123 = icmp sle i64 %t121, 0
  br i1 %t123, label %bb29, label %bb30
bb29:
  %t125 = load i64, ptr %l2, !tbaa !24
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb31, label %bb32
bb30:
  br label %bb34
bb31:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t129, ptr %l74, !tbaa !27
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = add i64 %t130, 1
  %t134 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr %"compiler/token:Token", ptr %t135, i64 %t132
  %t137 = getelementptr %"compiler/token:Token", ptr %t136, i32 0, i32 0
  %t138 = load i32, ptr %t137, !range !{i32 0, i32 116}
  %t140 = trunc i64 76 to i32
  %t141 = icmp eq i32 %t138, %t140
  store i1 %t141, ptr %l73, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l7, !tbaa !24
  br label %bb7
bb36:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ereceiverWord(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l7, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t21, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l10, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t24, 0
  store i64 %t27, ptr %l13, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l14, !tbaa !24
  %t30 = icmp sge i64 6, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = icmp sle i64 6, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c3decf4b04a6151d_670214acefcfbe1)
  unreachable
bb7:
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c3decf4b04a6151d_670214acefcfbe1)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l13, !tbaa !24
  %t42 = getelementptr i8, ptr %t40, i64 6
  %t43 = sub i64 %t41, 6
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l1, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t47, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d215, i32 0, i32 1) })
  store i1 %t49, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c3decf4b04a6151d_670214acefcfbe1)
  unreachable
bb11:
  %t50 = load i1, ptr %l20, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l21, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t52, 0
  store i64 %t55, ptr %l24, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l25, !tbaa !24
  %t58 = icmp sge i64 4, 0
  br i1 %t58, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t60 = load i64, ptr %l24, !tbaa !24
  %t61 = icmp sle i64 4, %t60
  br i1 %t61, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_32e96ed36b9449c0_57b465eb96245df4)
  unreachable
bb16:
  %t63 = load i64, ptr %l24, !tbaa !24
  %t64 = load i64, ptr %l25, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_32e96ed36b9449c0_57b465eb96245df4)
  unreachable
bb18:
  %t67 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l24, !tbaa !24
  %t70 = getelementptr i8, ptr %t68, i64 4
  %t71 = sub i64 %t69, 4
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l1, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_32e96ed36b9449c0_57b465eb96245df4)
  unreachable
bb20:
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d216, i32 0, i32 1) })
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l33
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb22, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l32
  br label %bb21
bb21:
  %t82 = load i64, ptr %l32, !tbaa !24
  store i64 %t82, ptr %l30, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb24
bb24:
  %t83 = load i64, ptr %l30, !tbaa !24
  store i64 %t83, ptr %l2, !tbaa !24
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l38, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l39, !tbaa !24
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb27, label %bb28
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d217, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t94, ptr %l36, !tbaa !27
  br label %bb33
bb27:
  %t96 = load i64, ptr %l38, !tbaa !24
  %t97 = icmp sle i64 0, %t96
  br i1 %t97, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_661253d1350526bb_c7d472f3993d1cdf)
  unreachable
bb29:
  %t99 = load i64, ptr %l38, !tbaa !24
  %t100 = load i64, ptr %l39, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_661253d1350526bb_c7d472f3993d1cdf)
  unreachable
bb31:
  %t103 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l38, !tbaa !24
  %t106 = getelementptr i8, ptr %t104, i64 0
  %t107 = sub i64 %t105, 0
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l36, !tbaa !27
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_661253d1350526bb_c7d472f3993d1cdf)
  unreachable
bb33:
  %t117 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l47, !tbaa !24
  %t119 = load i64, ptr %l47, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l48, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l47, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t130, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2etrimCImports(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v1, ptr %l2, { i64, ptr } %a1, i1 true)
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %s0, { i64, ptr } %t6, i64 1, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  store ptr %l3, ptr %l10, !tbaa !29
  store ptr %l2, ptr %l11, !tbaa !29
  %t11 = call i64 @compiler_2fbuild_2eRecent()
  store i64 %t11, ptr %l12
  br label %bb4
bb4:
  %t12 = load i64, ptr @G_2ecompiler_2fload_2eCImportCacheCap, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fbuild_2eTrim(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t13, ptr %t14, ptr %t15, i64 %t16, i64 %t12)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fload_2etypeNames(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l64 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 2
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb36
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i64 %t63
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68, !range !{i32 0, i32 116}
  %t71 = trunc i64 33 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb14
bb13:
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = add i64 %t77, 1
  %t81 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/token:Token", ptr %t82, i64 %t79
  %t84 = getelementptr %"compiler/token:Token", ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 116}
  %t87 = trunc i64 1 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  store i1 %t90, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t92 = load i1, ptr %l46, !tbaa !21
  br i1 %t92, label %bb15, label %bb16
bb15:
  br label %bb35
bb16:
  br label %bb17
bb17:
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t93, ptr %l53, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t94, 2
  %t98 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/token:Token", ptr %t99, i64 %t96
  %t101 = getelementptr %"compiler/token:Token", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !range !{i32 0, i32 116}
  %t104 = trunc i64 76 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb24
bb19:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t107, ptr %l59, !tbaa !27
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = add i64 %t108, 2
  %t112 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/token:Token", ptr %t113, i64 %t110
  %t115 = getelementptr %"compiler/token:Token", ptr %t114, i32 0, i32 0
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 116}
  %t118 = trunc i64 98 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb20, label %bb21
bb20:
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t122, 2
  %t127 = call i1 @compiler_2fload_2ememberAhead(ptr %v1, { i64, ptr } %t121, i64 %t124)
  store i1 %t127, ptr %l68
  br label %bb22
bb21:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  %t128 = load i1, ptr %l68, !tbaa !21
  store i1 %t128, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t130 = load i1, ptr %l58, !tbaa !21
  br i1 %t130, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  br label %bb27
bb27:
  %t131 = load ptr, ptr %l2, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  store { i64, ptr } %a0, ptr %l70, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t133, ptr %l71, !tbaa !27
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  %t138 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/token:Token", ptr %t139, i64 %t136
  %t141 = getelementptr %"compiler/token:Token", ptr %t140, i32 0, i32 2
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = sext i32 %t142 to i64
  store i64 %t144, ptr %l75, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t145, ptr %l76, !tbaa !27
  %t146 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t146, 1
  %t150 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr %"compiler/token:Token", ptr %t151, i64 %t148
  %t153 = getelementptr %"compiler/token:Token", ptr %t152, i32 0, i32 3
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  store i64 %t156, ptr %l80, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l81, !tbaa !24
  %t159 = load i64, ptr %l75, !tbaa !24
  %t160 = icmp sge i64 %t159, 0
  br i1 %t160, label %bb28, label %bb29
bb28:
  %t162 = load i64, ptr %l75, !tbaa !24
  %t163 = load i64, ptr %l80, !tbaa !24
  %t164 = icmp sle i64 %t162, %t163
  br i1 %t164, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb30:
  %t166 = load i64, ptr %l80, !tbaa !24
  %t167 = load i64, ptr %l81, !tbaa !24
  %t168 = icmp sle i64 %t166, %t167
  br i1 %t168, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb32:
  %t170 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = load i64, ptr %l75, !tbaa !24
  %t173 = load i64, ptr %l80, !tbaa !24
  %t174 = getelementptr i8, ptr %t171, i64 %t172
  %t175 = sub i64 %t173, %t172
  %t176 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  %t178 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %t178, { i64, ptr } %t177)
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb34:
  br label %bb35
bb35:
  %t180 = load i64, ptr %l8, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l8, !tbaa !24
  br label %bb8
bb36:
  %t185 = load ptr, ptr %l2, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ewithoutCTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca %"std/prelude/text:LineIter"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l11
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l15
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l14
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t13, ptr %l12, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l15, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb7:
  %t18 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load i1, ptr %l3, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) })
  store i1 %t23, ptr %l20
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb13
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb14:
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t25, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d219, i32 0, i32 1) })
  store i1 %t27, ptr %l22
  br label %bb15
bb15:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb16, label %bb17
bb16:
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t30, 0
  store i64 %t33, ptr %l27, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l28, !tbaa !24
  %t36 = icmp sge i64 9, 0
  br i1 %t36, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb25
bb18:
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp sle i64 9, %t38
  br i1 %t39, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9dd61c4642011e0a_35372b414a82eaf6)
  unreachable
bb20:
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9dd61c4642011e0a_35372b414a82eaf6)
  unreachable
bb22:
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l27, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 9
  %t49 = sub i64 %t47, 9
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t57 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v1, ptr %v0, ptr %t53, { i64, ptr } %t51)
  store i1 %t57, ptr %l35
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9dd61c4642011e0a_35372b414a82eaf6)
  unreachable
bb24:
  %t58 = load i1, ptr %l35, !tbaa !21
  store i1 %t58, ptr %l23, !tbaa !21
  br label %bb25
bb25:
  %t59 = load i1, ptr %l23, !tbaa !21
  br i1 %t59, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb27:
  br label %bb28
bb28:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t60, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store i1 %t62, ptr %l37
  br label %bb29
bb29:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb30, label %bb31
bb30:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = call { i64, ptr } @compiler_2fload_2etypeWord(ptr %v0, ptr %s2, { i64, ptr } %t64)
  store { i64, ptr } %t66, ptr %l40
  br label %bb32
bb31:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb34
bb32:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v1, ptr %s2, ptr %t68, { i64, ptr } %t67)
  store i1 %t72, ptr %l43
  br label %bb33
bb33:
  %t73 = load i1, ptr %l43, !tbaa !21
  store i1 %t73, ptr %l38, !tbaa !21
  br label %bb34
bb34:
  %t74 = load i1, ptr %l38, !tbaa !21
  br i1 %t74, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb39
bb36:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = call { i64, ptr } @compiler_2fload_2ereceiverWord(ptr %v0, ptr %s2, { i64, ptr } %t75)
  store { i64, ptr } %t77, ptr %l46
  br label %bb37
bb37:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v1, ptr %s2, ptr %t79, { i64, ptr } %t78)
  store i1 %t83, ptr %l49
  br label %bb38
bb38:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb39
bb39:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = getelementptr i8, ptr %t93, i64 %t89
  call void @olang_textcopy(ptr %t94, ptr %t90, i64 %t91)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t96)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  br label %bb3
bb45:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t101, ptr %l55
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/load:Import"
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a0, ptr %l5
  store %"compiler/source:Span" %a1, ptr %l6
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store { i64, ptr } %a3, ptr %l8, !tbaa !27
  store i64 %a4, ptr %l9, !tbaa !24
  store i64 -1, ptr %l10, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t11 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t11, ptr %l18
  br label %bb1
bb1:
  %t12 = load %"compiler/source:Span", ptr %l18
  %t13 = load %"compiler/source:Span", ptr %l5
  %t14 = insertvalue %"compiler/load:Import" undef, %"compiler/source:Span" %t13, 0
  %t15 = load %"compiler/source:Span", ptr %l6
  %t16 = insertvalue %"compiler/load:Import" %t14, %"compiler/source:Span" %t15, 1
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t18 = insertvalue %"compiler/load:Import" %t16, { i64, ptr } %t17, 2
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t20 = insertvalue %"compiler/load:Import" %t18, { i64, ptr } %t19, 3
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = insertvalue %"compiler/load:Import" %t20, i64 %t21, 4
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = insertvalue %"compiler/load:Import" %t22, i64 %t23, 5
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t26 = insertvalue %"compiler/load:Import" %t24, { i64, ptr } %t25, 6
  %t28 = insertvalue %"compiler/load:Import" %t26, %"compiler/source:Span" %t12, 7
  store %"compiler/load:Import" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Import", ptr %rv
  ret %"compiler/load:Import" %rr
}

define dso_local void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca i64
  %l35 = alloca i64
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l64 = alloca i64
  %l66 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca i64
  %l70 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca %"compiler/load:Loader"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store ptr %a1, ptr %l6, !tbaa !29
  store ptr %a2, ptr %l7, !tbaa !29
  store ptr %a3, ptr %l8, !tbaa !29
  store ptr %a4, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_scope_hold(ptr %v5)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l35, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e5
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = call ptr @__olang_region_make(ptr %v5)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l35, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l35
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t18)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t19, ptr %l37
  br label %bb3
bb3:
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e5
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l35
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  %t31 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = call ptr @__olang_region_or(ptr %t33, ptr null)
  %t35 = call ptr @__olang_region_home(ptr %t34)
  %t36 = icmp ne ptr %t35, null
  %t37 = select i1 %t36, ptr %t35, ptr %t30
  %t38 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = call ptr @__olang_region_home(ptr %t41)
  %t43 = icmp ne ptr %t42, null
  %t44 = select i1 %t43, ptr %t42, ptr %t37
  call void @__olang_region_settle_in(ptr %t23, ptr %t44)
  br label %bb5
bb5:
  %t45 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, ptr %l10
  %t46 = call ptr @__olang_scope_hold(ptr %v5)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l39, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e6
  br i1 %t48, label %bb6, label %bb7
bb6:
  %t50 = call ptr @__olang_region_make(ptr %v5)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l39, !tbaa !24
  br label %bb7
bb7:
  %t52 = load i64, ptr %l39
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t53)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l41
  br label %bb8
bb8:
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e6
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = load i64, ptr %l39
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  %t66 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = call ptr @__olang_region_home(ptr %t69)
  %t71 = icmp ne ptr %t70, null
  %t72 = select i1 %t71, ptr %t70, ptr %t65
  %t73 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = call ptr @__olang_region_home(ptr %t76)
  %t78 = icmp ne ptr %t77, null
  %t79 = select i1 %t78, ptr %t77, ptr %t72
  call void @__olang_region_settle_in(ptr %t58, ptr %t79)
  br label %bb10
bb10:
  %t80 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t80, ptr %l11
  %t81 = call ptr @__olang_scope_hold(ptr %v5)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l43, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e7
  br i1 %t83, label %bb11, label %bb12
bb11:
  %t85 = call ptr @__olang_region_make(ptr %v5)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  br label %bb12
bb12:
  %t87 = load i64, ptr %l43
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t88)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t89, ptr %l45
  br label %bb13
bb13:
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e7
  br i1 %t90, label %bb14, label %bb15
bb14:
  %t92 = load i64, ptr %l43
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %t94
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = call ptr @__olang_region_or(ptr %t96, ptr null)
  %t98 = call ptr @__olang_region_home(ptr %t97)
  %t99 = icmp ne ptr %t98, null
  %t100 = select i1 %t99, ptr %t98, ptr null
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = call ptr @__olang_region_or(ptr %t103, ptr null)
  %t105 = call ptr @__olang_region_home(ptr %t104)
  %t106 = icmp ne ptr %t105, null
  %t107 = select i1 %t106, ptr %t105, ptr %t100
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = call ptr @__olang_region_or(ptr %t110, ptr null)
  %t112 = call ptr @__olang_region_home(ptr %t111)
  %t113 = icmp ne ptr %t112, null
  %t114 = select i1 %t113, ptr %t112, ptr %t107
  call void @__olang_region_settle_in(ptr %t93, ptr %t114)
  br label %bb15
bb15:
  %t115 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t115, ptr %l12
  store i1 true, ptr %l13, !tbaa !21
  %t116 = call ptr @__olang_scope_hold(ptr %v5)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l47, !tbaa !24
  %t118 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e9
  br i1 %t118, label %bb16, label %bb17
bb16:
  %t120 = call ptr @__olang_region_make(ptr %v5)
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l47, !tbaa !24
  br label %bb17
bb17:
  %t122 = load i64, ptr %l47
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t123, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %l49
  br label %bb18
bb18:
  %t125 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e9
  br i1 %t125, label %bb19, label %bb20
bb19:
  %t127 = load i64, ptr %l47
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = call ptr @__olang_region_home(ptr %t132)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t128, ptr %t135)
  br label %bb20
bb20:
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l14
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l51
  br label %bb21
bb21:
  %t138 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l15
  %t139 = call ptr @__olang_scope_hold(ptr %v5)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l52, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e11
  br i1 %t141, label %bb22, label %bb23
bb22:
  %t143 = call ptr @__olang_region_make(ptr %v5)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t145 = load i64, ptr %l52
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t146, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l54
  br label %bb24
bb24:
  %t148 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e11
  br i1 %t148, label %bb25, label %bb26
bb25:
  %t150 = load i64, ptr %l52
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = call ptr @__olang_region_or(ptr %t154, ptr null)
  %t156 = call ptr @__olang_region_home(ptr %t155)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr null
  call void @__olang_region_settle_in(ptr %t151, ptr %t158)
  br label %bb26
bb26:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l16
  store i64 -1, ptr %l17, !tbaa !24
  %t160 = call ptr @__olang_scope_hold(ptr %v5)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l56, !tbaa !24
  %t162 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e13
  br i1 %t162, label %bb27, label %bb28
bb27:
  %t164 = call ptr @__olang_region_make(ptr %v5)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l56, !tbaa !24
  br label %bb28
bb28:
  %t166 = load i64, ptr %l56
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t167)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t168, ptr %l58
  br label %bb29
bb29:
  %t169 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e13
  br i1 %t169, label %bb30, label %bb31
bb30:
  %t171 = load i64, ptr %l56
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr null)
  %t177 = call ptr @__olang_region_home(ptr %t176)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr null
  %t180 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = call ptr @__olang_region_or(ptr %t182, ptr null)
  %t184 = call ptr @__olang_region_home(ptr %t183)
  %t185 = icmp ne ptr %t184, null
  %t186 = select i1 %t185, ptr %t184, ptr %t179
  %t187 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = call ptr @__olang_region_home(ptr %t190)
  %t192 = icmp ne ptr %t191, null
  %t193 = select i1 %t192, ptr %t191, ptr %t186
  call void @__olang_region_settle_in(ptr %t172, ptr %t193)
  br label %bb31
bb31:
  %t194 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t194, ptr %l18
  %t195 = call ptr @__olang_scope_hold(ptr %v5)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l60, !tbaa !24
  %t197 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e14
  br i1 %t197, label %bb32, label %bb33
bb32:
  %t199 = call ptr @__olang_region_make(ptr %v5)
  %t200 = ptrtoint ptr %t199 to i64
  store i64 %t200, ptr %l60, !tbaa !24
  br label %bb33
bb33:
  %t201 = load i64, ptr %l60
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t202)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t203, ptr %l62
  br label %bb34
bb34:
  %t204 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e14
  br i1 %t204, label %bb35, label %bb36
bb35:
  %t206 = load i64, ptr %l60
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 2
  %t209 = load { i64, ptr }, ptr %t208
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = call ptr @__olang_region_or(ptr %t210, ptr null)
  %t212 = call ptr @__olang_region_home(ptr %t211)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr null
  %t215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = call ptr @__olang_region_or(ptr %t217, ptr null)
  %t219 = call ptr @__olang_region_home(ptr %t218)
  %t220 = icmp ne ptr %t219, null
  %t221 = select i1 %t220, ptr %t219, ptr %t214
  %t222 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 0
  %t223 = load { i64, ptr }, ptr %t222
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = call ptr @__olang_region_or(ptr %t224, ptr null)
  %t226 = call ptr @__olang_region_home(ptr %t225)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr %t221
  call void @__olang_region_settle_in(ptr %t207, ptr %t228)
  br label %bb36
bb36:
  %t229 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t229, ptr %l19
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) }, ptr %l20, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t230 = call ptr @__olang_scope_hold(ptr %v5)
  %t231 = ptrtoint ptr %t230 to i64
  store i64 %t231, ptr %l64, !tbaa !24
  %t232 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e17
  br i1 %t232, label %bb37, label %bb38
bb37:
  %t234 = call ptr @__olang_region_make(ptr %v5)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l64, !tbaa !24
  br label %bb38
bb38:
  %t236 = load i64, ptr %l64
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cU8_3e_26_3e(ptr %t237)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t238, ptr %l66
  br label %bb39
bb39:
  %t239 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e17
  br i1 %t239, label %bb40, label %bb41
bb40:
  %t241 = load i64, ptr %l64
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 2
  %t244 = load { i64, ptr }, ptr %t243
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = call ptr @__olang_region_or(ptr %t245, ptr null)
  %t247 = call ptr @__olang_region_home(ptr %t246)
  %t248 = icmp ne ptr %t247, null
  %t249 = select i1 %t248, ptr %t247, ptr null
  %t250 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 1
  %t251 = load { i64, ptr }, ptr %t250
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = call ptr @__olang_region_or(ptr %t252, ptr null)
  %t254 = call ptr @__olang_region_home(ptr %t253)
  %t255 = icmp ne ptr %t254, null
  %t256 = select i1 %t255, ptr %t254, ptr %t249
  %t257 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = call ptr @__olang_region_or(ptr %t259, ptr null)
  %t261 = call ptr @__olang_region_home(ptr %t260)
  %t262 = icmp ne ptr %t261, null
  %t263 = select i1 %t262, ptr %t261, ptr %t256
  call void @__olang_region_settle_in(ptr %t242, ptr %t263)
  br label %bb41
bb41:
  %t264 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t264, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  %t265 = call ptr @__olang_scope_hold(ptr %v5)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l68, !tbaa !24
  %t267 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e19
  br i1 %t267, label %bb42, label %bb43
bb42:
  %t269 = call ptr @__olang_region_make(ptr %v5)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l68, !tbaa !24
  br label %bb43
bb43:
  %t271 = load i64, ptr %l68
  %t272 = inttoptr i64 %t271 to ptr
  %t273 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t272)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t273, ptr %l70
  br label %bb44
bb44:
  %t274 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e19
  br i1 %t274, label %bb45, label %bb46
bb45:
  %t276 = load i64, ptr %l68
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70, i32 0, i32 2
  %t279 = load { i64, ptr }, ptr %t278
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = call ptr @__olang_region_or(ptr %t280, ptr null)
  %t282 = call ptr @__olang_region_home(ptr %t281)
  %t283 = icmp ne ptr %t282, null
  %t284 = select i1 %t283, ptr %t282, ptr null
  %t285 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = call ptr @__olang_region_or(ptr %t287, ptr null)
  %t289 = call ptr @__olang_region_home(ptr %t288)
  %t290 = icmp ne ptr %t289, null
  %t291 = select i1 %t290, ptr %t289, ptr %t284
  %t292 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = call ptr @__olang_region_or(ptr %t294, ptr null)
  %t296 = call ptr @__olang_region_home(ptr %t295)
  %t297 = icmp ne ptr %t296, null
  %t298 = select i1 %t297, ptr %t296, ptr %t291
  call void @__olang_region_settle_in(ptr %t277, ptr %t298)
  br label %bb46
bb46:
  %t299 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t299, ptr %l24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t300 = call ptr @__olang_scope_hold(ptr %v5)
  %t301 = ptrtoint ptr %t300 to i64
  store i64 %t301, ptr %l72, !tbaa !24
  %t302 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e21
  br i1 %t302, label %bb47, label %bb48
bb47:
  %t304 = call ptr @__olang_region_make(ptr %v5)
  %t305 = ptrtoint ptr %t304 to i64
  store i64 %t305, ptr %l72, !tbaa !24
  br label %bb48
bb48:
  %t306 = load i64, ptr %l72
  %t307 = inttoptr i64 %t306 to ptr
  %t308 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t307, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %l74
  br label %bb49
bb49:
  %t309 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e21
  br i1 %t309, label %bb50, label %bb51
bb50:
  %t311 = load i64, ptr %l72
  %t312 = inttoptr i64 %t311 to ptr
  %t313 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74, i32 0, i32 0
  %t314 = load { i64, ptr }, ptr %t313
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = call ptr @__olang_region_or(ptr %t315, ptr null)
  %t317 = call ptr @__olang_region_home(ptr %t316)
  %t318 = icmp ne ptr %t317, null
  %t319 = select i1 %t318, ptr %t317, ptr null
  call void @__olang_region_settle_in(ptr %t312, ptr %t319)
  br label %bb51
bb51:
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %l26
  %t321 = call ptr @__olang_scope_hold(ptr %v5)
  %t322 = ptrtoint ptr %t321 to i64
  store i64 %t322, ptr %l76, !tbaa !24
  %t323 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e22
  br i1 %t323, label %bb52, label %bb53
bb52:
  %t325 = call ptr @__olang_region_make(ptr %v5)
  %t326 = ptrtoint ptr %t325 to i64
  store i64 %t326, ptr %l76, !tbaa !24
  br label %bb53
bb53:
  %t327 = load i64, ptr %l76
  %t328 = inttoptr i64 %t327 to ptr
  %t329 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t328)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t329, ptr %l78
  br label %bb54
bb54:
  %t330 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e22
  br i1 %t330, label %bb55, label %bb56
bb55:
  %t332 = load i64, ptr %l76
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 2
  %t335 = load { i64, ptr }, ptr %t334
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = call ptr @__olang_region_or(ptr %t336, ptr null)
  %t338 = call ptr @__olang_region_home(ptr %t337)
  %t339 = icmp ne ptr %t338, null
  %t340 = select i1 %t339, ptr %t338, ptr null
  %t341 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 1
  %t342 = load { i64, ptr }, ptr %t341
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = call ptr @__olang_region_or(ptr %t343, ptr null)
  %t345 = call ptr @__olang_region_home(ptr %t344)
  %t346 = icmp ne ptr %t345, null
  %t347 = select i1 %t346, ptr %t345, ptr %t340
  %t348 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 0
  %t349 = load { i64, ptr }, ptr %t348
  %t350 = extractvalue { i64, ptr } %t349, 1
  %t351 = call ptr @__olang_region_or(ptr %t350, ptr null)
  %t352 = call ptr @__olang_region_home(ptr %t351)
  %t353 = icmp ne ptr %t352, null
  %t354 = select i1 %t353, ptr %t352, ptr %t347
  call void @__olang_region_settle_in(ptr %t333, ptr %t354)
  br label %bb56
bb56:
  %t355 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t355, ptr %l27
  store i64 0, ptr %l28, !tbaa !24
  %t356 = call ptr @__olang_scope_hold(ptr %v5)
  %t357 = ptrtoint ptr %t356 to i64
  store i64 %t357, ptr %l80, !tbaa !24
  %t358 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e24
  br i1 %t358, label %bb57, label %bb58
bb57:
  %t360 = call ptr @__olang_region_make(ptr %v5)
  %t361 = ptrtoint ptr %t360 to i64
  store i64 %t361, ptr %l80, !tbaa !24
  br label %bb58
bb58:
  %t362 = load i64, ptr %l80
  %t363 = inttoptr i64 %t362 to ptr
  %t364 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t363, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %l82
  br label %bb59
bb59:
  %t365 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e24
  br i1 %t365, label %bb60, label %bb61
bb60:
  %t367 = load i64, ptr %l80
  %t368 = inttoptr i64 %t367 to ptr
  %t369 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82, i32 0, i32 0
  %t370 = load { i64, ptr }, ptr %t369
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = call ptr @__olang_region_or(ptr %t371, ptr null)
  %t373 = call ptr @__olang_region_home(ptr %t372)
  %t374 = icmp ne ptr %t373, null
  %t375 = select i1 %t374, ptr %t373, ptr null
  call void @__olang_region_settle_in(ptr %t368, ptr %t375)
  br label %bb61
bb61:
  %t376 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  %t377 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 0
  %t378 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t378, ptr %t377, !tbaa !27
  %t379 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 1
  %t380 = load ptr, ptr %l6, !tbaa !29
  store ptr %t380, ptr %t379, !tbaa !29
  %t381 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 2
  %t382 = load ptr, ptr %l7, !tbaa !29
  store ptr %t382, ptr %t381, !tbaa !29
  %t383 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 3
  %t384 = load ptr, ptr %l8, !tbaa !29
  store ptr %t384, ptr %t383, !tbaa !29
  %t385 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 4
  %t386 = load ptr, ptr %l9, !tbaa !29
  store ptr %t386, ptr %t385, !tbaa !29
  %t387 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 5
  %t388 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t388, ptr %t387
  %t389 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 6
  %t390 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t390, ptr %t389
  %t391 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 7
  %t392 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t392, ptr %t391
  %t393 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 8
  %t394 = load i1, ptr %l13, !tbaa !21
  store i1 %t394, ptr %t393, !tbaa !21
  %t395 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 9
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %t395
  %t397 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 10
  %t398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %t397
  %t399 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 11
  %t400 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t400, ptr %t399
  %t401 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 12
  %t402 = load i64, ptr %l17, !tbaa !24
  store i64 %t402, ptr %t401, !tbaa !24
  %t403 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 13
  %t404 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t404, ptr %t403
  %t405 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 14
  %t406 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t406, ptr %t405
  %t407 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 15
  %t408 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t408, ptr %t407, !tbaa !27
  %t409 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 16
  %t410 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t410, ptr %t409, !tbaa !27
  %t411 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 17
  %t412 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t412, ptr %t411
  %t413 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 18
  %t414 = load i1, ptr %l23, !tbaa !21
  store i1 %t414, ptr %t413, !tbaa !21
  %t415 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 19
  %t416 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t416, ptr %t415
  %t417 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 20
  %t418 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t418, ptr %t417, !tbaa !27
  %t419 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 21
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %t419
  %t421 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 22
  %t422 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t422, ptr %t421
  %t423 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 23
  %t424 = load i64, ptr %l28, !tbaa !24
  store i64 %t424, ptr %t423, !tbaa !24
  %t425 = getelementptr %"compiler/load:Loader", ptr %l84, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t376, ptr %t425
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l84, i64 864, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_3aModule_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i64
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca i64
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca i64
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i64
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca i64
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i64
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca i64
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l109 = alloca i64
  %l111 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l113 = alloca i64
  %l115 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l117 = alloca %"compiler/load:Module"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store { i64, ptr } %a2, ptr %l6, !tbaa !27
  store i1 %a3, ptr %l7, !tbaa !21
  store i64 -1, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store ptr null, ptr %l10, !tbaa !29
  store ptr null, ptr %l11, !tbaa !29
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sle i64 0, 1152921504606846975
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f)
  unreachable
bb3:
  %t13 = mul i64 0, 8
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t17 = call ptr @__olang_scope_hold(ptr %v3)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l49, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e9
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f)
  unreachable
bb5:
  %t21 = call ptr @__olang_region_make(ptr %v3)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l49, !tbaa !24
  br label %bb6
bb6:
  %t23 = load i64, ptr %l49
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t24, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l51
  br label %bb7
bb7:
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e9
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l49
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr null
  call void @__olang_region_settle_in(ptr %t29, ptr %t36)
  br label %bb9
bb9:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l13
  %t38 = call ptr @__olang_scope_hold(ptr %v3)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l53, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e10
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = call ptr @__olang_region_make(ptr %v3)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l53, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l53
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t45, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l55
  br label %bb12
bb12:
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e10
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load i64, ptr %l53
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_region_or(ptr %t53, ptr null)
  %t55 = call ptr @__olang_region_home(ptr %t54)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t50, ptr %t57)
  br label %bb14
bb14:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l14
  %t59 = call ptr @__olang_scope_hold(ptr %v3)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l57, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e11
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t63 = call ptr @__olang_region_make(ptr %v3)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l57, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l57
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %t66, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l59
  br label %bb17
bb17:
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e11
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = load i64, ptr %l57
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = call ptr @__olang_region_home(ptr %t75)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t78)
  br label %bb19
bb19:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l15
  store ptr null, ptr %l16, !tbaa !29
  store ptr null, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t80 = call ptr @__olang_scope_hold(ptr %v3)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l61, !tbaa !24
  %t82 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e17
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = call ptr @__olang_region_make(ptr %v3)
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l61, !tbaa !24
  br label %bb21
bb21:
  %t86 = load i64, ptr %l61
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t87, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l63
  br label %bb22
bb22:
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e17
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load i64, ptr %l61
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = call ptr @__olang_region_home(ptr %t96)
  %t98 = icmp ne ptr %t97, null
  %t99 = select i1 %t98, ptr %t97, ptr null
  call void @__olang_region_settle_in(ptr %t92, ptr %t99)
  br label %bb24
bb24:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l21
  %t101 = call ptr @__olang_scope_hold(ptr %v3)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l65, !tbaa !24
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e18
  br i1 %t103, label %bb25, label %bb26
bb25:
  %t105 = call ptr @__olang_region_make(ptr %v3)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l65, !tbaa !24
  br label %bb26
bb26:
  %t107 = load i64, ptr %l65
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t108, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l67
  br label %bb27
bb27:
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e18
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = load i64, ptr %l65
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t113, ptr %t120)
  br label %bb29
bb29:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l22
  %t122 = call ptr @__olang_scope_hold(ptr %v3)
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l69, !tbaa !24
  %t124 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e19
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t126 = call ptr @__olang_region_make(ptr %v3)
  %t127 = ptrtoint ptr %t126 to i64
  store i64 %t127, ptr %l69, !tbaa !24
  br label %bb31
bb31:
  %t128 = load i64, ptr %l69
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t129, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l71
  br label %bb32
bb32:
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e19
  br i1 %t131, label %bb33, label %bb34
bb33:
  %t133 = load i64, ptr %l69
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t141)
  br label %bb34
bb34:
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l23
  %t143 = call ptr @__olang_scope_hold(ptr %v3)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l73, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e20
  br i1 %t145, label %bb35, label %bb36
bb35:
  %t147 = call ptr @__olang_region_make(ptr %v3)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l73, !tbaa !24
  br label %bb36
bb36:
  %t149 = load i64, ptr %l73
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t150, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l75
  br label %bb37
bb37:
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e20
  br i1 %t152, label %bb38, label %bb39
bb38:
  %t154 = load i64, ptr %l73
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = call ptr @__olang_region_or(ptr %t158, ptr null)
  %t160 = call ptr @__olang_region_home(ptr %t159)
  %t161 = icmp ne ptr %t160, null
  %t162 = select i1 %t161, ptr %t160, ptr null
  call void @__olang_region_settle_in(ptr %t155, ptr %t162)
  br label %bb39
bb39:
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l24
  %t164 = call ptr @__olang_scope_hold(ptr %v3)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l77, !tbaa !24
  %t166 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e21
  br i1 %t166, label %bb40, label %bb41
bb40:
  %t168 = call ptr @__olang_region_make(ptr %v3)
  %t169 = ptrtoint ptr %t168 to i64
  store i64 %t169, ptr %l77, !tbaa !24
  br label %bb41
bb41:
  %t170 = load i64, ptr %l77
  %t171 = inttoptr i64 %t170 to ptr
  %t172 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t171, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l79
  br label %bb42
bb42:
  %t173 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t175 = load i64, ptr %l77
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = call ptr @__olang_region_or(ptr %t179, ptr null)
  %t181 = call ptr @__olang_region_home(ptr %t180)
  %t182 = icmp ne ptr %t181, null
  %t183 = select i1 %t182, ptr %t181, ptr null
  call void @__olang_region_settle_in(ptr %t176, ptr %t183)
  br label %bb44
bb44:
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l25
  %t185 = call ptr @__olang_scope_hold(ptr %v3)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l81, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e22
  br i1 %t187, label %bb45, label %bb46
bb45:
  %t189 = call ptr @__olang_region_make(ptr %v3)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l81, !tbaa !24
  br label %bb46
bb46:
  %t191 = load i64, ptr %l81
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t192, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l83
  br label %bb47
bb47:
  %t194 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e22
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t196 = load i64, ptr %l81
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = call ptr @__olang_region_home(ptr %t201)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr null
  call void @__olang_region_settle_in(ptr %t197, ptr %t204)
  br label %bb49
bb49:
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l26
  %t206 = call ptr @__olang_scope_hold(ptr %v3)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l85, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e23
  br i1 %t208, label %bb50, label %bb51
bb50:
  %t210 = call ptr @__olang_region_make(ptr %v3)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l85, !tbaa !24
  br label %bb51
bb51:
  %t212 = load i64, ptr %l85
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t213, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l87
  br label %bb52
bb52:
  %t215 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e23
  br i1 %t215, label %bb53, label %bb54
bb53:
  %t217 = load i64, ptr %l85
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87, i32 0, i32 0
  %t220 = load { i64, ptr }, ptr %t219
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = call ptr @__olang_region_or(ptr %t221, ptr null)
  %t223 = call ptr @__olang_region_home(ptr %t222)
  %t224 = icmp ne ptr %t223, null
  %t225 = select i1 %t224, ptr %t223, ptr null
  call void @__olang_region_settle_in(ptr %t218, ptr %t225)
  br label %bb54
bb54:
  %t226 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l27
  %t227 = call ptr @__olang_scope_hold(ptr %v3)
  %t228 = ptrtoint ptr %t227 to i64
  store i64 %t228, ptr %l89, !tbaa !24
  %t229 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e24
  br i1 %t229, label %bb55, label %bb56
bb55:
  %t231 = call ptr @__olang_region_make(ptr %v3)
  %t232 = ptrtoint ptr %t231 to i64
  store i64 %t232, ptr %l89, !tbaa !24
  br label %bb56
bb56:
  %t233 = load i64, ptr %l89
  %t234 = inttoptr i64 %t233 to ptr
  %t235 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t234, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l91
  br label %bb57
bb57:
  %t236 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e24
  br i1 %t236, label %bb58, label %bb59
bb58:
  %t238 = load i64, ptr %l89
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91, i32 0, i32 0
  %t241 = load { i64, ptr }, ptr %t240
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = call ptr @__olang_region_or(ptr %t242, ptr null)
  %t244 = call ptr @__olang_region_home(ptr %t243)
  %t245 = icmp ne ptr %t244, null
  %t246 = select i1 %t245, ptr %t244, ptr null
  call void @__olang_region_settle_in(ptr %t239, ptr %t246)
  br label %bb59
bb59:
  %t247 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l28
  %t248 = call ptr @__olang_scope_hold(ptr %v3)
  %t249 = ptrtoint ptr %t248 to i64
  store i64 %t249, ptr %l93, !tbaa !24
  %t250 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e25
  br i1 %t250, label %bb60, label %bb61
bb60:
  %t252 = call ptr @__olang_region_make(ptr %v3)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l93, !tbaa !24
  br label %bb61
bb61:
  %t254 = load i64, ptr %l93
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t255, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l95
  br label %bb62
bb62:
  %t257 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e25
  br i1 %t257, label %bb63, label %bb64
bb63:
  %t259 = load i64, ptr %l93
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = call ptr @__olang_region_or(ptr %t263, ptr null)
  %t265 = call ptr @__olang_region_home(ptr %t264)
  %t266 = icmp ne ptr %t265, null
  %t267 = select i1 %t266, ptr %t265, ptr null
  call void @__olang_region_settle_in(ptr %t260, ptr %t267)
  br label %bb64
bb64:
  %t268 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l29
  store ptr null, ptr %l30, !tbaa !29
  store ptr null, ptr %l31, !tbaa !29
  store ptr null, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  store i1 false, ptr %l34, !tbaa !21
  %t269 = call ptr @__olang_scope_hold(ptr %v3)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l97, !tbaa !24
  %t271 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e31
  br i1 %t271, label %bb65, label %bb66
bb65:
  %t273 = call ptr @__olang_region_make(ptr %v3)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l97, !tbaa !24
  br label %bb66
bb66:
  %t275 = load i64, ptr %l97
  %t276 = inttoptr i64 %t275 to ptr
  %t277 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t276, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l99
  br label %bb67
bb67:
  %t278 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e31
  br i1 %t278, label %bb68, label %bb69
bb68:
  %t280 = load i64, ptr %l97
  %t281 = inttoptr i64 %t280 to ptr
  %t282 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99, i32 0, i32 0
  %t283 = load { i64, ptr }, ptr %t282
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = call ptr @__olang_region_or(ptr %t284, ptr null)
  %t286 = call ptr @__olang_region_home(ptr %t285)
  %t287 = icmp ne ptr %t286, null
  %t288 = select i1 %t287, ptr %t286, ptr null
  call void @__olang_region_settle_in(ptr %t281, ptr %t288)
  br label %bb69
bb69:
  %t289 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %l35
  %t290 = call ptr @__olang_scope_hold(ptr %v3)
  %t291 = ptrtoint ptr %t290 to i64
  store i64 %t291, ptr %l101, !tbaa !24
  %t292 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e32
  br i1 %t292, label %bb70, label %bb71
bb70:
  %t294 = call ptr @__olang_region_make(ptr %v3)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l101, !tbaa !24
  br label %bb71
bb71:
  %t296 = load i64, ptr %l101
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t297, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %l103
  br label %bb72
bb72:
  %t299 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e32
  br i1 %t299, label %bb73, label %bb74
bb73:
  %t301 = load i64, ptr %l101
  %t302 = inttoptr i64 %t301 to ptr
  %t303 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103, i32 0, i32 0
  %t304 = load { i64, ptr }, ptr %t303
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = call ptr @__olang_region_or(ptr %t305, ptr null)
  %t307 = call ptr @__olang_region_home(ptr %t306)
  %t308 = icmp ne ptr %t307, null
  %t309 = select i1 %t308, ptr %t307, ptr null
  call void @__olang_region_settle_in(ptr %t302, ptr %t309)
  br label %bb74
bb74:
  %t310 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %l36
  store i1 false, ptr %l37, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t311 = call ptr @__olang_scope_hold(ptr %v3)
  %t312 = ptrtoint ptr %t311 to i64
  store i64 %t312, ptr %l105, !tbaa !24
  %t313 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e35
  br i1 %t313, label %bb75, label %bb76
bb75:
  %t315 = call ptr @__olang_region_make(ptr %v3)
  %t316 = ptrtoint ptr %t315 to i64
  store i64 %t316, ptr %l105, !tbaa !24
  br label %bb76
bb76:
  %t317 = load i64, ptr %l105
  %t318 = inttoptr i64 %t317 to ptr
  %t319 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t318)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t319, ptr %l107
  br label %bb77
bb77:
  %t320 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e35
  br i1 %t320, label %bb78, label %bb79
bb78:
  %t322 = load i64, ptr %l105
  %t323 = inttoptr i64 %t322 to ptr
  %t324 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l107, i32 0, i32 2
  %t325 = load { i64, ptr }, ptr %t324
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = call ptr @__olang_region_or(ptr %t326, ptr null)
  %t328 = call ptr @__olang_region_home(ptr %t327)
  %t329 = icmp ne ptr %t328, null
  %t330 = select i1 %t329, ptr %t328, ptr null
  %t331 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l107, i32 0, i32 1
  %t332 = load { i64, ptr }, ptr %t331
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = call ptr @__olang_region_or(ptr %t333, ptr null)
  %t335 = call ptr @__olang_region_home(ptr %t334)
  %t336 = icmp ne ptr %t335, null
  %t337 = select i1 %t336, ptr %t335, ptr %t330
  %t338 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l107, i32 0, i32 0
  %t339 = load { i64, ptr }, ptr %t338
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = call ptr @__olang_region_or(ptr %t340, ptr null)
  %t342 = call ptr @__olang_region_home(ptr %t341)
  %t343 = icmp ne ptr %t342, null
  %t344 = select i1 %t343, ptr %t342, ptr %t337
  call void @__olang_region_settle_in(ptr %t323, ptr %t344)
  br label %bb79
bb79:
  %t345 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l107
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t345, ptr %l39
  %t346 = call ptr @__olang_scope_hold(ptr %v3)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l109, !tbaa !24
  %t348 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e36
  br i1 %t348, label %bb80, label %bb81
bb80:
  %t350 = call ptr @__olang_region_make(ptr %v3)
  %t351 = ptrtoint ptr %t350 to i64
  store i64 %t351, ptr %l109, !tbaa !24
  br label %bb81
bb81:
  %t352 = load i64, ptr %l109
  %t353 = inttoptr i64 %t352 to ptr
  %t354 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t353)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t354, ptr %l111
  br label %bb82
bb82:
  %t355 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e36
  br i1 %t355, label %bb83, label %bb84
bb83:
  %t357 = load i64, ptr %l109
  %t358 = inttoptr i64 %t357 to ptr
  %t359 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111, i32 0, i32 2
  %t360 = load { i64, ptr }, ptr %t359
  %t361 = extractvalue { i64, ptr } %t360, 1
  %t362 = call ptr @__olang_region_or(ptr %t361, ptr null)
  %t363 = call ptr @__olang_region_home(ptr %t362)
  %t364 = icmp ne ptr %t363, null
  %t365 = select i1 %t364, ptr %t363, ptr null
  %t366 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111, i32 0, i32 1
  %t367 = load { i64, ptr }, ptr %t366
  %t368 = extractvalue { i64, ptr } %t367, 1
  %t369 = call ptr @__olang_region_or(ptr %t368, ptr null)
  %t370 = call ptr @__olang_region_home(ptr %t369)
  %t371 = icmp ne ptr %t370, null
  %t372 = select i1 %t371, ptr %t370, ptr %t365
  %t373 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = call ptr @__olang_region_or(ptr %t375, ptr null)
  %t377 = call ptr @__olang_region_home(ptr %t376)
  %t378 = icmp ne ptr %t377, null
  %t379 = select i1 %t378, ptr %t377, ptr %t372
  call void @__olang_region_settle_in(ptr %t358, ptr %t379)
  br label %bb84
bb84:
  %t380 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t380, ptr %l40
  %t381 = call ptr @__olang_scope_hold(ptr %v3)
  %t382 = ptrtoint ptr %t381 to i64
  store i64 %t382, ptr %l113, !tbaa !24
  %t383 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e37
  br i1 %t383, label %bb85, label %bb86
bb85:
  %t385 = call ptr @__olang_region_make(ptr %v3)
  %t386 = ptrtoint ptr %t385 to i64
  store i64 %t386, ptr %l113, !tbaa !24
  br label %bb86
bb86:
  %t387 = load i64, ptr %l113
  %t388 = inttoptr i64 %t387 to ptr
  %t389 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t388)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t389, ptr %l115
  br label %bb87
bb87:
  %t390 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e37
  br i1 %t390, label %bb88, label %bb89
bb88:
  %t392 = load i64, ptr %l113
  %t393 = inttoptr i64 %t392 to ptr
  %t394 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l115, i32 0, i32 2
  %t395 = load { i64, ptr }, ptr %t394
  %t396 = extractvalue { i64, ptr } %t395, 1
  %t397 = call ptr @__olang_region_or(ptr %t396, ptr null)
  %t398 = call ptr @__olang_region_home(ptr %t397)
  %t399 = icmp ne ptr %t398, null
  %t400 = select i1 %t399, ptr %t398, ptr null
  %t401 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l115, i32 0, i32 1
  %t402 = load { i64, ptr }, ptr %t401
  %t403 = extractvalue { i64, ptr } %t402, 1
  %t404 = call ptr @__olang_region_or(ptr %t403, ptr null)
  %t405 = call ptr @__olang_region_home(ptr %t404)
  %t406 = icmp ne ptr %t405, null
  %t407 = select i1 %t406, ptr %t405, ptr %t400
  %t408 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l115, i32 0, i32 0
  %t409 = load { i64, ptr }, ptr %t408
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = call ptr @__olang_region_or(ptr %t410, ptr null)
  %t412 = call ptr @__olang_region_home(ptr %t411)
  %t413 = icmp ne ptr %t412, null
  %t414 = select i1 %t413, ptr %t412, ptr %t407
  call void @__olang_region_settle_in(ptr %t393, ptr %t414)
  br label %bb89
bb89:
  %t415 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l115
  %t416 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 0
  %t417 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t417, ptr %t416, !tbaa !27
  %t418 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 1
  %t419 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t419, ptr %t418, !tbaa !27
  %t420 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 2
  %t421 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t421, ptr %t420, !tbaa !27
  %t422 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 3
  %t423 = load i1, ptr %l7, !tbaa !21
  store i1 %t423, ptr %t422, !tbaa !21
  %t424 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 4
  %t425 = load i64, ptr %l8, !tbaa !24
  store i64 %t425, ptr %t424, !tbaa !24
  %t426 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 5
  %t427 = load i1, ptr %l9, !tbaa !21
  store i1 %t427, ptr %t426, !tbaa !21
  %t428 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 6
  %t429 = load ptr, ptr %l10, !tbaa !29
  store ptr %t429, ptr %t428, !tbaa !29
  %t430 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 7
  %t431 = load ptr, ptr %l11, !tbaa !29
  store ptr %t431, ptr %t430, !tbaa !29
  %t432 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 8
  %t433 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t433, ptr %t432, !tbaa !27
  %t434 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 9
  %t435 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t435, ptr %t434
  %t436 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 10
  %t437 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t437, ptr %t436
  %t438 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 11
  %t439 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439, ptr %t438
  %t440 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 12
  %t441 = load ptr, ptr %l16, !tbaa !29
  store ptr %t441, ptr %t440, !tbaa !29
  %t442 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 13
  %t443 = load ptr, ptr %l17, !tbaa !29
  store ptr %t443, ptr %t442, !tbaa !29
  %t444 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 14
  %t445 = load i1, ptr %l18, !tbaa !21
  store i1 %t445, ptr %t444, !tbaa !21
  %t446 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 15
  %t447 = load i64, ptr %l19, !tbaa !24
  store i64 %t447, ptr %t446, !tbaa !24
  %t448 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 16
  %t449 = load i64, ptr %l20, !tbaa !24
  store i64 %t449, ptr %t448, !tbaa !24
  %t450 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 17
  %t451 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t451, ptr %t450
  %t452 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 18
  %t453 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t453, ptr %t452
  %t454 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 19
  %t455 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t455, ptr %t454
  %t456 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 20
  %t457 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t457, ptr %t456
  %t458 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 21
  %t459 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t459, ptr %t458
  %t460 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 22
  %t461 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t461, ptr %t460
  %t462 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 23
  %t463 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t463, ptr %t462
  %t464 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 24
  %t465 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t465, ptr %t464
  %t466 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 25
  %t467 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t467, ptr %t466
  %t468 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 26
  %t469 = load ptr, ptr %l30, !tbaa !29
  store ptr %t469, ptr %t468, !tbaa !29
  %t470 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 27
  %t471 = load ptr, ptr %l31, !tbaa !29
  store ptr %t471, ptr %t470, !tbaa !29
  %t472 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 28
  %t473 = load ptr, ptr %l32, !tbaa !29
  store ptr %t473, ptr %t472, !tbaa !29
  %t474 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 29
  %t475 = load i1, ptr %l33, !tbaa !21
  store i1 %t475, ptr %t474, !tbaa !21
  %t476 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 30
  %t477 = load i1, ptr %l34, !tbaa !21
  store i1 %t477, ptr %t476, !tbaa !21
  %t478 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 31
  %t479 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t479, ptr %t478
  %t480 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 32
  %t481 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t481, ptr %t480
  %t482 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 33
  %t483 = load i1, ptr %l37, !tbaa !21
  store i1 %t483, ptr %t482, !tbaa !21
  %t484 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 34
  %t485 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t485, ptr %t484, !tbaa !27
  %t486 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 35
  %t487 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t487, ptr %t486
  %t488 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 36
  %t489 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t489, ptr %t488
  %t490 = getelementptr %"compiler/load:Module", ptr %l117, i32 0, i32 37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t415, ptr %t490
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l117, i64 864, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"    type " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fload__2eCTypeDecls_2elocal_2e2 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
declare void @__olang_check_failed(ptr) cold noreturn
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670 = weak hidden constant i1 false
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".a" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".so." }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1 = weak hidden constant i1 false
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".cache" }>, align 8
@.d18 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"file:///nowhere/" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"OLANG_STD" }>, align 8
declare void @__olang_errpay_pop()
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"/../std" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".deps" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eCondParser_2elocal_2e14 = weak hidden constant i1 false
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@olang_2esole_2ecompiler_2fcond_3aGlobal_2e0 = weak hidden constant i1 false
@.d47 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"an empty path names no file" }>, align 8
@.d48 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a path of 4096 characters or more" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e6 = weak hidden constant i1 false
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e9 = weak hidden constant i1 false
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d63 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"it leaves " }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eEmbed_2elocal_2e10 = weak hidden constant i1 false
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d71 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"it leaves " }>, align 8
@.d72 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", through a link" }>, align 8
@.d73 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no file " }>, align 8
@.d74 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is a directory" }>, align 8
@.d75 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be read" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_77(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 10
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %vc0, ptr %vc0, ptr %t14, i64 %a1)
  store ptr %t18, ptr %l12
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 2
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t23, { i64, ptr } %t22)
  store i1 %t25, ptr %l15
  br label %bb3
bb3:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d78 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_83(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e16 = weak hidden constant i1 false
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e2 = weak hidden constant i1 false
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d89 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eaddLink_2elocal_2e7 = weak hidden constant i1 false
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e8 = weak hidden constant i1 false
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e9 = weak hidden constant i1 false
@.d102 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"#include \22" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e10 = weak hidden constant i1 false
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e11 = weak hidden constant i1 false
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d106 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d107 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d108 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"#include <" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d112 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e20 = weak hidden constant i1 false
@.d113 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-D_GNU_SOURCE" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d116 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d118 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/cimport" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d120 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d121 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"/* " }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" */\0A" }>, align 8
@.d130 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d131 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d132 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".deps" }>, align 8
@.d133 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"its translation cannot be written into " }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2ecImport_2elocal_2e22 = weak hidden constant i1 false
@.d134 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d135 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d136 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e0 = weak hidden constant i1 false
@.d137 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d140 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e34 = weak hidden constant i1 false
@.d141 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d142 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"# symbol " }>, align 8
@.d143 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"# not declared:" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d145 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#   " }>, align 8
@.d146 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d149 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d150 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eimportAt_2elocal_2e6 = weak hidden constant i1 false
@.d151 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d152 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@olang_2esole_2ecompiler_2fload_3aImport_2e6 = weak hidden constant i1 false
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e6 = weak hidden constant i1 false
@.d156 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d157 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e12 = weak hidden constant i1 false
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d159 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d160 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d161 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d162 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d163 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d164 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e8 = weak hidden constant i1 false
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e9 = weak hidden constant i1 false
@.d168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d169 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d171 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d176 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d177 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d178 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d181 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d182 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d184 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d185 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d186 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d190 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d191 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2eresolve_2elocal_2e21 = weak hidden constant i1 false
@.d192 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d194 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d195 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e4 = weak hidden constant i1 false
@.d200 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d201 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2ecompiler__2fload__2ecompiler__2fload__3aLoader__2erootIdentity_2elocal_2e5 = weak hidden constant i1 false
@.d202 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d203 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d204 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d205 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d206 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d207 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d208 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d210 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d211 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d213 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fn (s " }>, align 8
@.d214 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d215 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d216 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&)" }>, align 8
@.d217 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d219 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"    type " }>, align 8
@.d220 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d222 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fload_3aLoader_2e6 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fload_3aLoader_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e13 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fload_3aLoader_2e14 = weak hidden constant i1 false
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e17 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cU8_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cU8_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fload_3aLoader_2e19 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e22 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fload_3aLoader_2e24 = weak hidden constant i1 false
@__olang_empty_array = external constant [16 x i64]
@olang_2esole_2ecompiler_2fload_3aModule_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e24 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e31 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e32 = weak hidden constant i1 false
@.d226 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e35 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e36 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aModule_2e37 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_53160a2f7dd07190_f4bb70ca8fd9d2a4 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_15d40d4750690f6d_e4c87d10d7941391 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2etypeWord(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcond_3aConsts_2ector(ptr %out, ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8, i64 %a9)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_58a0a66c848bdb67_cd5865ffada34e5b = external constant [0 x i8]
@olang_loc_78711dd37968488a_7166c24cf999555e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_dccc239ae56f9ba9_1ecb5d6f56d7fcbd = external constant [0 x i8]
@olang_loc_756dde8889a2c3bc_572c106a043d4f60 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac = external constant [0 x i8]
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v0, i1 %a0)
@olang_loc_4d8cd44e3790675d_2617b874cf4b9361 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_37ad9edc8de7e2f6_d0344632fdf871da = external constant [0 x i8]
@olang_loc_ee319d06991d9051_474f59f05ada826d = external constant [0 x i8]
@olang_loc_57e236369a85f00c_b06e30e0c965afa8 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_64a34b454640941_8ed0e4b282ed07d = external constant [0 x i8]
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_64e62a75e1515ba_854f46de0e9c2096 = external constant [0 x i8]
@olang_loc_edaf45632a5c2555_299361976cec5e59 = external constant [0 x i8]
declare %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5)
declare void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fload_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fload_2eNotYet = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9daea36ebb972439_574e08d4d8c23575 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_af475931a368800c_57263df876e21e18 = external constant [0 x i8]
declare i64 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eCountOf_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H31dec199381f6e2bb0c82058ea887922(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_5aefafbfcb5eb6b7_7e4be8b78a5947cb = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha0f924a08ec45a4a582ec1782d69c4be(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H412951a1c1c3c34f4f6a5a14e25e5986(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_53eff658f30813a6_f347cd1231cef772 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d2a36b1a0f33f2c5_8bb351bc5bea8f1 = external constant [0 x i8]
@olang_loc_c887c5acf0277416_b8456d2f32e25a62 = external constant [0 x i8]
declare i1 @std_2ffilepath_2eIsAbs(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_17616d64a992214_c045be96c2de0040 = external constant [0 x i8]
@olang_loc_e6755cf0c7ea5c6a_c534e9e23f397d86 = external constant [0 x i8]
@olang_loc_5079a6433cc29871_c7557f1318c6a06d = external constant [0 x i8]
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_aae654c03cd30c7c_21b926dbd63a1158 = external constant [0 x i8]
declare { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
@G_2ecompiler_2fload_2eCImportFormat = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @std_2fsha256_2eHex(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4449aa9d363b5b4e_4db0be62c6b6e3d2 = external constant [0 x i8]
@olang_loc_7c6f8f6ffdbdf94b_ce4c5ade044a53cf = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/bindgen:Translation" @compiler_2fbindgen_2eTranslation_2eTranslate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCHeaderNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCImportFailed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_cc736817fb6c70d0_6e757e50f6c823e4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H48e651c05c949f01bc365c3f5aed05e5(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_Haa4821f40e4709ffaa64d7939c192aa7(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_390d71ace96962ec_ea4878fb110dc7f0 = external constant [0 x i8]
@olang_loc_8d4df4585930a33a_b93e06b5ac523ace = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2)
@olang_loc_946ee3836eb302af_c914571e601006eb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_bd0734fef4495944_f844247d18b1c970 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_f27e16b36a34913f_9730f0a664aef8cb = external constant [0 x i8]
@olang_loc_f6bd06efaafe5f20_6d37165570c63ddc = external constant [0 x i8]
@olang_loc_10115782cae2d59a_b13624e5abc6764e = external constant [0 x i8]
declare %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %v0, i32 %a0, i1 %a1)
@olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5 = external constant [0 x i8]
@olang_loc_b990dbcfbe082b6c_e09e9a90e433de0 = external constant [0 x i8]
declare void @compiler_2fcond_3aEval_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fast_2eLitComparison(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_834f60adf702f65b_ad4cc829cd9d3aff = external constant [0 x i8]
@olang_loc_98393be07dd60b4e_346d755782035a4a = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLitCompare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { %"compiler/source:Span", %"compiler/diagmsg:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_88eba3596c4d138c_c1530d55fa80a9b0 = external constant [0 x i8]
@olang_loc_17f5e01691795fb_80a050950937648f = external constant [0 x i8]
@olang_loc_fd1d115e36d277d2_104a63438b39a3d6 = external constant [0 x i8]
@olang_loc_3753a1d7262b2cc1_bd09a853d1b85305 = external constant [0 x i8]
@olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8e32ae472cd64327_c149890ad1056c3 = external constant [0 x i8]
@olang_loc_a448ee53d606ecee_601f65a9d3b58c7a = external constant [0 x i8]
@olang_loc_7e96417109578add_9add255974295329 = external constant [0 x i8]
@olang_loc_7fc0c111e9e5248c_f920a424be87ad0 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/load:Import" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hadc5a27c7dd302cda1d0e8a7732d6686(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_67b56c0a83b8bd03_8d743f7b3592caff = external constant [0 x i8]
@olang_loc_867763f6879c47c1_85ff3e3f6e82a415 = external constant [0 x i8]
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eSource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H30b952b85dc190b6cd5306b9d98a7749(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_bf0719959bfa757a_6a83aba191150c56 = external constant [0 x i8]
@olang_loc_97fda29c929b9401_a297b77e137a783d = external constant [0 x i8]
@olang_loc_8eb73d0fe26fae48_56cde13f0d79d76c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eNote(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eHelp(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare void @compiler_2fparse_3aOracle_2ector(ptr %out, ptr %v0)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparseLoaded(ptr %v0, ptr %a0)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eRefMut_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkOnOlangImport(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6 = external constant [0 x i8]
@olang_loc_4a5bc26e34bf81_f78399c125ad415d = external constant [0 x i8]
declare ptr @compiler_2fparse_2eGenericFnNames(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_75be0ecbfd40364c_3ba616ba9e8cb88 = external constant [0 x i8]
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0)
@olang_loc_6772f502359d02a_1b697b2141371efe = external constant [0 x i8]
@olang_loc_c7e55e824de13607_c088d15fef4da17b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_91ed1932ac5cd85c_f28264288e99980 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d9612e2b18e8b492_6662b34d58c1f606 = external constant [0 x i8]
@olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3 = external constant [0 x i8]
@olang_loc_281d6687dd267da4_55752feab9766ac8 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a82b02dae8c2ac74_a1c9be326debd858 = external constant [0 x i8]
@olang_loc_cb2680ed80c29ba8_266600b794f46714 = external constant [0 x i8]
@olang_loc_f33836f530001f0a_3e5ddd8b9e2e63ae = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4f7ff751eb66f618_e3b0711c9f747694 = external constant [0 x i8]
@olang_loc_4fa7c22e4d470d75_c9a9030dc047401 = external constant [0 x i8]
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2ftarget_2ePid()
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
@olang_loc_c3decf4b04a6151d_670214acefcfbe1 = external constant [0 x i8]
@olang_loc_32e96ed36b9449c0_57b465eb96245df4 = external constant [0 x i8]
@olang_loc_661253d1350526bb_c7d472f3993d1cdf = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fbuild_2eRecent()
@G_2ecompiler_2fload_2eCImportCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\10\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2eTrim(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_61485bf8b9fa4014_95a81608270a26e0 = external constant [0 x i8]
@olang_loc_9dd61c4642011e0a_35372b414a82eaf6 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cU8_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
