; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/json:reader" = type { { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64 }
%"std/json:writer" = type { { i64, ptr }, i32, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local void @std_2fjson_2ekeyInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca i8
  %l14 = alloca i8
  %l21 = alloca i8
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l67 = alloca i8
  %l68 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca i8
  %l101 = alloca i8
  %l103 = alloca i8
  %l107 = alloca ptr
  %l109 = alloca i8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t12 = trunc i64 2 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i8 95, ptr %l21, !tbaa !22
  br label %bb7
bb6:
  store i8 45, ptr %l21, !tbaa !22
  br label %bb7
bb7:
  %t15 = load i8, ptr %l21, !tbaa !22
  store i8 %t15, ptr %l3, !tbaa !22
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb13
bb10:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l30, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l30, !tbaa !24
  store i64 %t46, ptr %l27, !tbaa !24
  br label %bb13
bb13:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %bb69
bb16:
  br label %bb17
bb17:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t66, ptr %l48, !tbaa !27
  %t67 = load i64, ptr %l11, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l12, !tbaa !22
  %t74 = load i8, ptr %l12, !tbaa !22
  %t76 = icmp eq i8 %t74, 95
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb68
bb19:
  br label %bb20
bb20:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i8, ptr %l12, !tbaa !22
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t82)
  store i1 %t84, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t85 = load i1, ptr %l57, !tbaa !21
  store i1 %t85, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l55, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l58, !tbaa !27
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 %t90
  %t95 = load i8, ptr %t94, !tbaa !32
  store i8 %t95, ptr %l13, !tbaa !22
  %t97 = load i64, ptr %l11, !tbaa !24
  %t99 = add i64 %t97, 1
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t105 = icmp slt i64 %t99, %t102
  br i1 %t105, label %bb27, label %bb28
bb26:
  br label %bb46
bb27:
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l68, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  store i8 %t115, ptr %l67, !tbaa !22
  br label %bb29
bb28:
  store i8 32, ptr %l67, !tbaa !22
  br label %bb29
bb29:
  %t117 = load i8, ptr %l67, !tbaa !22
  store i8 %t117, ptr %l14, !tbaa !22
  %t118 = load i8, ptr %l13, !tbaa !22
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t118)
  store i1 %t120, ptr %l73
  br label %bb30
bb30:
  %t121 = load i1, ptr %l73, !tbaa !21
  br i1 %t121, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb34
bb32:
  %t122 = load i8, ptr %l13, !tbaa !22
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t122)
  store i1 %t124, ptr %l76
  br label %bb33
bb33:
  %t125 = load i1, ptr %l76, !tbaa !21
  store i1 %t125, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t126 = load i1, ptr %l74, !tbaa !21
  br i1 %t126, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb42
bb36:
  %t127 = load i8, ptr %l13, !tbaa !22
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t127)
  store i1 %t129, ptr %l79
  br label %bb37
bb37:
  %t130 = load i1, ptr %l79, !tbaa !21
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t131 = load i8, ptr %l14, !tbaa !22
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t131)
  store i1 %t133, ptr %l82
  br label %bb40
bb39:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  %t134 = load i1, ptr %l82, !tbaa !21
  store i1 %t134, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t135 = load i1, ptr %l80, !tbaa !21
  store i1 %t135, ptr %l77, !tbaa !21
  br label %bb42
bb42:
  %t136 = load i1, ptr %l77, !tbaa !21
  br i1 %t136, label %bb43, label %bb44
bb43:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb47, label %bb48
bb47:
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb49, label %bb50
bb48:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l107, !tbaa !29
  %t146 = load i8, ptr %l12, !tbaa !22
  %t148 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t146)
  store i8 %t148, ptr %l109
  br label %bb65
bb49:
  %t149 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t151 = trunc i64 1 to i32
  %t152 = icmp eq i32 %t149, %t151
  %t154 = xor i1 %t152, true
  store i1 %t154, ptr %l87, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb51
bb51:
  %t156 = load i1, ptr %l87, !tbaa !21
  br i1 %t156, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i8, ptr %l3, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t157, i8 %t158)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l93, !tbaa !29
  %t162 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t164 = trunc i64 1 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb56, label %bb57
bb56:
  %t167 = load i64, ptr %l4, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  store i1 %t169, ptr %l96, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb58
bb58:
  %t171 = load i1, ptr %l96, !tbaa !21
  br i1 %t171, label %bb59, label %bb60
bb59:
  %t172 = load i8, ptr %l12, !tbaa !22
  %t174 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t172)
  store i8 %t174, ptr %l101
  br label %bb61
bb60:
  %t175 = load i8, ptr %l12, !tbaa !22
  %t177 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t175)
  store i8 %t177, ptr %l103
  br label %bb62
bb61:
  %t178 = load i8, ptr %l101, !tbaa !22
  store i8 %t178, ptr %l99, !tbaa !22
  br label %bb63
bb62:
  %t179 = load i8, ptr %l103, !tbaa !22
  store i8 %t179, ptr %l99, !tbaa !22
  br label %bb63
bb63:
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = load i8, ptr %l99, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t180, i8 %t181)
  br label %bb64
bb64:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l4, !tbaa !24
  br label %bb67
bb65:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load i8, ptr %l109, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t187, i8 %t188)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t189 = load i64, ptr %l5, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l5, !tbaa !24
  br label %bb68
bb68:
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %l10, !tbaa !24
  br label %bb14
bb69:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fjson_2enameIndex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l27 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l87 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sle i64 %t5, 8
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t11 = icmp sle i64 0, 2305843009213693951
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bc241580f27121ab_ca64d2d20e518e77)
  unreachable
bb5:
  %t13 = mul i64 0, 4
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bc241580f27121ab_ca64d2d20e518e77)
  unreachable
bb7:
  store i64 16, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = mul i64 2, %t18
  %t23 = icmp slt i64 %t17, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = mul i64 %t27, 2
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb8
bb13:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %l27, !tbaa !24
  %t33 = load i64, ptr %l27, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp sle i64 %t36, 2305843009213693951
  br i1 %t37, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2)
  unreachable
bb16:
  %t39 = load i64, ptr %l27, !tbaa !24
  %t40 = mul i64 %t39, 4
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2)
  unreachable
bb18:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb23
bb20:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l40, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb22
bb22:
  %t77 = load i64, ptr %l40, !tbaa !24
  store i64 %t77, ptr %l37, !tbaa !24
  br label %bb23
bb23:
  %t78 = load i64, ptr %l37, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l10, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %t101, i64 %t98
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !37
  %t105 = call i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t103)
  store i64 %t105, ptr %l61
  br label %bb28
bb28:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t107 = load i64, ptr %l61, !tbaa !24
  %t109 = and i64 %t107, %t106
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t111 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t111, ptr %l64, !tbaa !27
  %t112 = load i64, ptr %l11, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l69, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t122, ptr %l70, !tbaa !27
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  %t130 = sext i32 %t128 to i64
  %t132 = sub i64 %t130, 1
  %t134 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %t135, i64 %t132
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !37
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t138, ptr %l76, !tbaa !27
  %t139 = load i64, ptr %l10, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %t142, i64 %t139
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !37
  %t147 = call i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v0, { i64, ptr } %t137, { i64, ptr } %t144)
  store i1 %t147, ptr %l79
  br label %bb32
bb31:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb33
bb32:
  %t148 = load i1, ptr %l79, !tbaa !21
  %t149 = xor i1 %t148, true
  store i1 %t149, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t151 = load i1, ptr %l68, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t154, 1
  %t158 = load i64, ptr %l4, !tbaa !24
  %t161 = and i64 %t157, %t158
  store i64 %t161, ptr %l11, !tbaa !24
  br label %bb37
bb37:
  br label %bb29
bb38:
  %t163 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t163, ptr %l87, !tbaa !27
  %t164 = load i64, ptr %l11, !tbaa !24
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = add i64 %t165, 1
  %t169 = trunc i64 %t167 to i32
  %t172 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i32, ptr %t173, i64 %t164
  store i32 %t169, ptr %t174, !tbaa !33
  br label %bb39
bb39:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l9, !tbaa !24
  br label %bb24
bb40:
  %t180 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2fjson_2enumEq(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca double
  %l3 = alloca double
  %l4 = alloca i128
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l34 = alloca i128
  %l36 = alloca i128
  %l37 = alloca i32
  %l41 = alloca i128
  %l43 = alloca i128
  %l44 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l2, !tbaa !26
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { double }, ptr %t27, i32 0, i32 0
  %t29 = load double, ptr %t28
  store double %t29, ptr %l3, !tbaa !26
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load double, ptr %l2, !tbaa !26
  %t32 = load double, ptr %l3, !tbaa !26
  %t35 = fcmp oeq double %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6a96f216a7a18db5_c7851721732fae9)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2a2c934c6745fec4_9721022dc2e60418)
  unreachable
bb22:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb23, label %bb24
bb23:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 8}
  %t44 = icmp eq i64 %t42, 2
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb24
bb24:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb27, label %bb28
bb27:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb28
bb28:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb31, label %bb32
bb31:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb32
bb32:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_247b9c864b1325ff_f9e87c5eec2e2b33)
  unreachable
bb41:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %t65)
  %t68 = extractvalue { i32, i128 } %t67, 1
  %t69 = extractvalue { i32, i128 } %t67, 0
  store i32 %t69, ptr %l37
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb43, label %ok.71, !prof !99
ok.71:
  store i128 %t68, ptr %l36
  br label %bb42
bb42:
  %t72 = load i128, ptr %l36
  store i128 %t72, ptr %l34
  br label %bb47
bb43:
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  br i1 %t76, label %bb44, label %bb45
bb44:
  call void @__olang_errpay_pop()
  br label %bb45
bb45:
  br label %bb46
bb46:
  store i1 false, ptr %rv
  br label %ret
bb47:
  %t79 = load i128, ptr %l34
  store i128 %t79, ptr %l4
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v1, ptr %t80)
  %t83 = extractvalue { i32, i128 } %t82, 1
  %t84 = extractvalue { i32, i128 } %t82, 0
  store i32 %t84, ptr %l44
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb49, label %ok.86, !prof !99
ok.86:
  store i128 %t83, ptr %l43
  br label %bb48
bb48:
  %t87 = load i128, ptr %l43
  store i128 %t87, ptr %l41
  br label %bb53
bb49:
  %t88 = load i32, ptr %l44, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  br i1 %t91, label %bb50, label %bb51
bb50:
  call void @__olang_errpay_pop()
  br label %bb51
bb51:
  br label %bb52
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  %t94 = load i128, ptr %l41
  %t95 = load i128, ptr %l4
  %t99 = icmp eq i128 %t95, %t94
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2eplainEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i8
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l3, !tbaa !22
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp eq i8 %t21, 34
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i8, ptr %l3, !tbaa !22
  %t27 = icmp eq i8 %t25, 92
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t30 = load i8, ptr %l3, !tbaa !22
  %t32 = icmp ult i8 %t30, 32
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = icmp uge i8 %t35, -128
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fjson_2eputUtf8(ptr %v0, i64 %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 128
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = trunc i64 %t13 to i8
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  store i8 %t15, ptr %t20, !tbaa !32
  br label %bb5
bb4:
  br label %bb5
bb5:
  store i64 1, ptr %rv
  br label %ret
bb6:
  %t22 = load i64, ptr %l0, !tbaa !24
  %t24 = icmp slt i64 %t22, 2048
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  br label %bb12
bb9:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l0, !tbaa !24
  %t36 = ashr i64 %t34, 6
  %t38 = or i64 192, %t36
  %t40 = trunc i64 %t38 to i8
  %t43 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t33
  store i8 %t40, ptr %t45, !tbaa !32
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t46, ptr %l24, !tbaa !27
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = add i64 %t47, 1
  %t50 = load i64, ptr %l0, !tbaa !24
  %t52 = and i64 %t50, 63
  %t54 = or i64 128, %t52
  %t56 = trunc i64 %t54 to i8
  %t59 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t49
  store i8 %t56, ptr %t61, !tbaa !32
  br label %bb11
bb10:
  br label %bb11
bb11:
  store i64 2, ptr %rv
  br label %ret
bb12:
  %t63 = load i64, ptr %l0, !tbaa !24
  %t65 = icmp slt i64 %t63, 65536
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l37, !tbaa !27
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l0, !tbaa !24
  %t77 = ashr i64 %t75, 12
  %t79 = or i64 224, %t77
  %t81 = trunc i64 %t79 to i8
  %t84 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 %t74
  store i8 %t81, ptr %t86, !tbaa !32
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l43, !tbaa !27
  %t88 = load i64, ptr %l1, !tbaa !24
  %t90 = add i64 %t88, 1
  %t91 = load i64, ptr %l0, !tbaa !24
  %t93 = ashr i64 %t91, 6
  %t95 = and i64 %t93, 63
  %t97 = or i64 128, %t95
  %t99 = trunc i64 %t97 to i8
  %t102 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i8, ptr %t103, i64 %t90
  store i8 %t99, ptr %t104, !tbaa !32
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l51, !tbaa !27
  %t106 = load i64, ptr %l1, !tbaa !24
  %t108 = add i64 %t106, 2
  %t109 = load i64, ptr %l0, !tbaa !24
  %t111 = and i64 %t109, 63
  %t113 = or i64 128, %t111
  %t115 = trunc i64 %t113 to i8
  %t118 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t108
  store i8 %t115, ptr %t120, !tbaa !32
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 3, ptr %rv
  br label %ret
bb18:
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb19, label %bb20
bb19:
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l62, !tbaa !27
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load i64, ptr %l0, !tbaa !24
  %t132 = ashr i64 %t130, 18
  %t134 = or i64 240, %t132
  %t136 = trunc i64 %t134 to i8
  %t139 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t129
  store i8 %t136, ptr %t141, !tbaa !32
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t142, ptr %l68, !tbaa !27
  %t143 = load i64, ptr %l1, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load i64, ptr %l0, !tbaa !24
  %t148 = ashr i64 %t146, 12
  %t150 = and i64 %t148, 63
  %t152 = or i64 128, %t150
  %t154 = trunc i64 %t152 to i8
  %t157 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t145
  store i8 %t154, ptr %t159, !tbaa !32
  %t160 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t160, ptr %l76, !tbaa !27
  %t161 = load i64, ptr %l1, !tbaa !24
  %t163 = add i64 %t161, 2
  %t164 = load i64, ptr %l0, !tbaa !24
  %t166 = ashr i64 %t164, 6
  %t168 = and i64 %t166, 63
  %t170 = or i64 128, %t168
  %t172 = trunc i64 %t170 to i8
  %t175 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t163
  store i8 %t172, ptr %t177, !tbaa !32
  %t178 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t178, ptr %l84, !tbaa !27
  %t179 = load i64, ptr %l1, !tbaa !24
  %t181 = add i64 %t179, 3
  %t182 = load i64, ptr %l0, !tbaa !24
  %t184 = and i64 %t182, 63
  %t186 = or i64 128, %t184
  %t188 = trunc i64 %t186 to i8
  %t191 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i8, ptr %t192, i64 %t181
  store i8 %t188, ptr %t193, !tbaa !32
  br label %bb21
bb20:
  br label %bb21
bb21:
  store i64 4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l150 = alloca i64
  %l152 = alloca i64
  %l156 = alloca i64
  %l160 = alloca i64
  %l163 = alloca i64
  %l181 = alloca i64
  %l184 = alloca { i64, ptr }
  %l187 = alloca i64
  %l188 = alloca i32
  %l190 = alloca i64
  %l193 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca i32
  %l200 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l207 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t2 = load ptr, ptr %l24, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l25, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t11 = load ptr, ptr %l28, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t18 = load i1, ptr %l29, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t20 = load ptr, ptr %l32, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l32, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l33, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { i1 }, ptr %t30, i32 0, i32 0
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l38, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 8}
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l39, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i1 }, ptr %t45, i32 0, i32 0
  %t47 = load i1, ptr %t46
  store i1 %t47, ptr %l3, !tbaa !21
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t49 = load i1, ptr %l2, !tbaa !21
  %t50 = load i1, ptr %l3, !tbaa !21
  %t53 = icmp eq i1 %t49, %t50
  store i1 %t53, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a7b0a92300089828_a6e8a6d400231804)
  unreachable
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t64 = load i1, ptr %l49, !tbaa !21
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb37
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t66 = load ptr, ptr %l52, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb29, label %bb30
bb29:
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t75 = load ptr, ptr %l56, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb33, label %bb34
bb33:
  %t78 = load ptr, ptr %l56, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 8}
  %t81 = icmp eq i64 %t79, 4
  store i1 %t81, ptr %l57, !tbaa !21
  br label %bb34
bb34:
  %t82 = load i1, ptr %l57, !tbaa !21
  br i1 %t82, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t87 = call i1 @std_2fjson_2enumEq(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store i1 %t87, ptr %l62
  br label %bb38
bb38:
  %t88 = load i1, ptr %l62, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb39:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb40, label %bb41
bb40:
  %t93 = load ptr, ptr %l63, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l64, !tbaa !21
  br label %bb41
bb41:
  %t97 = load i1, ptr %l64, !tbaa !21
  br i1 %t97, label %bb42, label %bb43
bb42:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { { i64, ptr } }, ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101
  store { i64, ptr } %t102, ptr %l4, !tbaa !27
  br label %bb44
bb43:
  br label %bb56
bb44:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t105 = load ptr, ptr %l69, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb45, label %bb46
bb45:
  %t108 = load ptr, ptr %l69, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t112 = load i1, ptr %l70, !tbaa !21
  br i1 %t112, label %bb47, label %bb48
bb47:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { { i64, ptr } }, ptr %t115, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t119, { i64, ptr } %t120)
  store i1 %t123, ptr %l77
  br label %bb50
bb50:
  %t124 = load i1, ptr %l77, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a07ba4d7ff0a56f9_d8356302010b83f5)
  unreachable
bb56:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t127 = load ptr, ptr %l79, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb57, label %bb58
bb57:
  %t130 = load ptr, ptr %l79, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 8}
  %t133 = icmp eq i64 %t131, 6
  store i1 %t133, ptr %l80, !tbaa !21
  br label %bb58
bb58:
  %t134 = load i1, ptr %l80, !tbaa !21
  br i1 %t134, label %bb59, label %bb60
bb59:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138
  store { i64, ptr } %t139, ptr %l6, !tbaa !27
  br label %bb61
bb60:
  br label %bb91
bb61:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t142 = load ptr, ptr %l85, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb62, label %bb63
bb62:
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 8}
  %t148 = icmp eq i64 %t146, 6
  store i1 %t148, ptr %l86, !tbaa !21
  br label %bb63
bb63:
  %t149 = load i1, ptr %l86, !tbaa !21
  br i1 %t149, label %bb64, label %bb65
bb64:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [2 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { { i64, ptr } }, ptr %t152, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb86
bb66:
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t164 = icmp ne i64 %t158, %t161
  br i1 %t164, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  store i64 0, ptr %l8, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp sgt i64 %t171, %t172
  br i1 %t175, label %bb70, label %bb71
bb70:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb75
bb72:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l8, !tbaa !24
  %t185 = sub i64 %t181, %t182
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = add i64 %t185, %t186
  %t191 = sub i64 %t189, 1
  %t192 = load i64, ptr %l10, !tbaa !24
  %t195 = sdiv i64 %t191, %t192
  store i64 %t195, ptr %l105, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb74
bb74:
  %t197 = load i64, ptr %l105, !tbaa !24
  store i64 %t197, ptr %l102, !tbaa !24
  br label %bb75
bb75:
  %t198 = load i64, ptr %l102, !tbaa !24
  store i64 %t198, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb76
bb76:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb77, label %bb78
bb77:
  br label %bb85
bb78:
  br label %bb79
bb79:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load i64, ptr %l10, !tbaa !24
  %t212 = mul i64 %t208, %t209
  %t215 = add i64 %t207, %t212
  store i64 %t215, ptr %l13, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t217, ptr %l123, !tbaa !27
  %t218 = load i64, ptr %l13, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t224 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t224, ptr %l126, !tbaa !27
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 %t225
  %t230 = load ptr, ptr %t229, !tbaa !39
  %t233 = call i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %t223, ptr %t230)
  store i1 %t233, ptr %l129
  br label %bb80
bb80:
  %t234 = load i1, ptr %l129, !tbaa !21
  %t235 = xor i1 %t234, true
  br i1 %t235, label %bb81, label %bb82
bb81:
  store i1 false, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t238 = load i64, ptr %l12, !tbaa !24
  %t241 = add i64 %t238, 1
  store i64 %t241, ptr %l12, !tbaa !24
  br label %bb76
bb85:
  store i1 true, ptr %rv
  br label %ret
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_22f1698915dd4682_a0313dce564b9a3e)
  unreachable
bb91:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t246 = load ptr, ptr %l137, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb92, label %bb93
bb92:
  %t249 = load ptr, ptr %l137, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 8}
  %t252 = icmp eq i64 %t250, 7
  store i1 %t252, ptr %l138, !tbaa !21
  br label %bb93
bb93:
  %t253 = load i1, ptr %l138, !tbaa !21
  br i1 %t253, label %bb94, label %bb95
bb94:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr { i64, [2 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { ptr }, ptr %t256, i32 0, i32 0
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l14, !tbaa !29
  br label %bb96
bb95:
  br label %bb137
bb96:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t261 = load ptr, ptr %l143, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb97, label %bb98
bb97:
  %t264 = load ptr, ptr %l143, !tbaa !29
  %t265 = load i64, ptr %t264, !range !{i64 0, i64 8}
  %t267 = icmp eq i64 %t265, 7
  store i1 %t267, ptr %l144, !tbaa !21
  br label %bb98
bb98:
  %t268 = load i1, ptr %l144, !tbaa !21
  br i1 %t268, label %bb99, label %bb100
bb99:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [2 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { ptr }, ptr %t271, i32 0, i32 0
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l15, !tbaa !29
  br label %bb101
bb100:
  br label %bb132
bb101:
  %t275 = load ptr, ptr %l14, !tbaa !29
  %t277 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t275)
  store i64 %t277, ptr %l150
  br label %bb102
bb102:
  %t278 = load ptr, ptr %l15, !tbaa !29
  %t280 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t278)
  store i64 %t280, ptr %l152
  br label %bb103
bb103:
  %t281 = load i64, ptr %l150, !tbaa !24
  %t282 = load i64, ptr %l152, !tbaa !24
  %t283 = icmp ne i64 %t281, %t282
  br i1 %t283, label %bb104, label %bb105
bb104:
  store i1 false, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  store i64 0, ptr %l16, !tbaa !24
  %t286 = load ptr, ptr %l14, !tbaa !29
  %t288 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t286)
  store i64 %t288, ptr %l156
  br label %bb107
bb107:
  %t289 = load i64, ptr %l156, !tbaa !24
  store i64 %t289, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t290 = load i64, ptr %l17, !tbaa !24
  %t291 = load i64, ptr %l16, !tbaa !24
  %t294 = icmp sgt i64 %t290, %t291
  br i1 %t294, label %bb108, label %bb109
bb108:
  %t296 = load i64, ptr %l18, !tbaa !24
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb110, label %bb111
bb109:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb113
bb110:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t301 = load i64, ptr %l16, !tbaa !24
  %t304 = sub i64 %t300, %t301
  %t305 = load i64, ptr %l18, !tbaa !24
  %t308 = add i64 %t304, %t305
  %t310 = sub i64 %t308, 1
  %t311 = load i64, ptr %l18, !tbaa !24
  %t314 = sdiv i64 %t310, %t311
  store i64 %t314, ptr %l163, !tbaa !24
  br label %bb112
bb111:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb112
bb112:
  %t316 = load i64, ptr %l163, !tbaa !24
  store i64 %t316, ptr %l160, !tbaa !24
  br label %bb113
bb113:
  %t317 = load i64, ptr %l160, !tbaa !24
  store i64 %t317, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb114
bb114:
  %t318 = load i64, ptr %l20, !tbaa !24
  %t319 = load i64, ptr %l19, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb115, label %bb116
bb115:
  br label %bb131
bb116:
  br label %bb117
bb117:
  %t326 = load i64, ptr %l16, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t328 = load i64, ptr %l18, !tbaa !24
  %t331 = mul i64 %t327, %t328
  %t334 = add i64 %t326, %t331
  store i64 %t334, ptr %l21, !tbaa !24
  %t336 = load ptr, ptr %l15, !tbaa !29
  %t337 = load ptr, ptr %l14, !tbaa !29
  %t339 = getelementptr %"std/json:Object", ptr %t337, i32 0, i32 0
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l184, !tbaa !27
  %t341 = load i64, ptr %l21, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %t344, i64 %t341
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !37
  %t349 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %v0, ptr %t336, { i64, ptr } %t346)
  %t350 = extractvalue { i32, i64 } %t349, 1
  %t351 = extractvalue { i32, i64 } %t349, 0
  store i32 %t351, ptr %l188
  %t352 = icmp ne i32 %t351, 0
  br i1 %t352, label %bb119, label %ok.353, !prof !99
ok.353:
  store i64 %t350, ptr %l187
  br label %bb118
bb118:
  %t354 = load i64, ptr %l187, !tbaa !24
  store i64 %t354, ptr %l181, !tbaa !24
  br label %bb121
bb119:
  br label %bb120
bb120:
  store i1 false, ptr %rv
  br label %ret
bb121:
  %t356 = load i64, ptr %l181, !tbaa !24
  store i64 %t356, ptr %l22, !tbaa !24
  %t357 = load ptr, ptr %l14, !tbaa !29
  %t358 = load ptr, ptr %l14, !tbaa !29
  %t360 = getelementptr %"std/json:Object", ptr %t358, i32 0, i32 0
  %t361 = load { i64, ptr }, ptr %t360, !tbaa !27
  store { i64, ptr } %t361, ptr %l193, !tbaa !27
  %t362 = load i64, ptr %l21, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %t365, i64 %t362
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !37
  %t370 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v0, ptr %t357, { i64, ptr } %t367)
  %t371 = extractvalue { i32, i64 } %t370, 1
  %t372 = extractvalue { i32, i64 } %t370, 0
  store i32 %t372, ptr %l197
  %t373 = icmp ne i32 %t372, 0
  br i1 %t373, label %bb123, label %ok.374, !prof !99
ok.374:
  store i64 %t371, ptr %l196
  br label %bb122
bb122:
  %t375 = load i64, ptr %l196, !tbaa !24
  store i64 %t375, ptr %l190, !tbaa !24
  br label %bb125
bb123:
  br label %bb124
bb124:
  store i1 false, ptr %rv
  br label %ret
bb125:
  %t377 = load i64, ptr %l190, !tbaa !24
  %t378 = load ptr, ptr %l14, !tbaa !29
  %t380 = getelementptr %"std/json:Object", ptr %t378, i32 0, i32 1
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  store { i64, ptr } %t381, ptr %l200, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t377
  %t387 = load ptr, ptr %t386, !tbaa !39
  %t388 = load ptr, ptr %l15, !tbaa !29
  %t390 = getelementptr %"std/json:Object", ptr %t388, i32 0, i32 1
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  store { i64, ptr } %t391, ptr %l204, !tbaa !27
  %t392 = load i64, ptr %l22, !tbaa !24
  %t394 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr ptr, ptr %t395, i64 %t392
  %t397 = load ptr, ptr %t396, !tbaa !39
  %t400 = call i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %t387, ptr %t397)
  store i1 %t400, ptr %l207
  br label %bb126
bb126:
  %t401 = load i1, ptr %l207, !tbaa !21
  %t402 = xor i1 %t401, true
  br i1 %t402, label %bb127, label %bb128
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t405 = load i64, ptr %l20, !tbaa !24
  %t408 = add i64 %t405, 1
  store i64 %t408, ptr %l20, !tbaa !24
  br label %bb114
bb131:
  store i1 true, ptr %rv
  br label %ret
bb132:
  br i1 true, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  store i1 false, ptr %rv
  br label %ret
bb136:
  call void @__olang_check_failed(ptr @olang_loc_e7435678738af803_3f3d624b6ec28d3f)
  unreachable
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  store i1 false, ptr %rv
  br label %ret
bb141:
  call void @__olang_check_failed(ptr @olang_loc_cd6f075822d3ba64_2e9ce5061183e548)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca double
  %l3 = alloca i128
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca double
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i128
  %l58 = alloca i128
  %l59 = alloca i32
  %l66 = alloca i128
  %l75 = alloca i1
  %l81 = alloca double
  %l87 = alloca i64
  %l90 = alloca i64
  %l92 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i1
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i1
  %l115 = alloca { i64, ptr }
  %l119 = alloca i64
  %l121 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca i1
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l159 = alloca i64
  %l161 = alloca { i64, ptr }
  %l164 = alloca i64
  %l166 = alloca { i64, ptr }
  %l169 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i64
  %t129 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i64 1, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t12 = load ptr, ptr %l27, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l27, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 1
  store i1 %t18, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l28, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i1 }, ptr %t22, i32 0, i32 0
  %t24 = load i1, ptr %t23
  store i1 %t24, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t26 = load i1, ptr %l1, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  store i64 2, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 3, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t28 = load i64, ptr %l34, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb15:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t30 = load ptr, ptr %l35, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t33 = load ptr, ptr %l35, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t37 = load i1, ptr %l36, !tbaa !21
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { double }, ptr %t40, i32 0, i32 0
  %t42 = load double, ptr %t41
  store double %t42, ptr %l2, !tbaa !26
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t44 = load double, ptr %l2, !tbaa !26
  %t46 = fcmp oeq double %t44, 0x0000000000000000
  br i1 %t46, label %bb21, label %bb22
bb21:
  store i64 4, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t49 = load double, ptr %l2, !tbaa !26
  %t51 = bitcast double %t49 to i64
  %t54 = mul i64 %t51, 1099511628211
  store i64 %t54, ptr %rv
  br label %ret
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t64 = load i1, ptr %l49, !tbaa !21
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t66 = load ptr, ptr %l52, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb29, label %bb30
bb29:
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb56
bb33:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %t74)
  %t77 = extractvalue { i32, i128 } %t76, 1
  %t78 = extractvalue { i32, i128 } %t76, 0
  store i32 %t78, ptr %l59
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb35, label %ok.80, !prof !99
ok.80:
  store i128 %t77, ptr %l58
  br label %bb34
bb34:
  %t81 = load i128, ptr %l58
  store i128 %t81, ptr %l56
  br label %bb39
bb35:
  %t82 = load i32, ptr %l59, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  br i1 %t85, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  store i64 0, ptr %rv
  br label %ret
bb39:
  %t88 = load i128, ptr %l56
  store i128 %t88, ptr %l3
  %t89 = load i128, ptr %l3
  %t91 = icmp slt i128 %t89, 0
  store i1 %t91, ptr %l4, !tbaa !21
  %t93 = load i1, ptr %l4, !tbaa !21
  br i1 %t93, label %bb40, label %bb41
bb40:
  %t95 = load i128, ptr %l3
  %t97 = sub i128 0, %t95
  store i128 %t97, ptr %l66
  br label %bb42
bb41:
  %t99 = load i128, ptr %l3
  store i128 %t99, ptr %l66
  br label %bb42
bb42:
  %t101 = load i128, ptr %l66
  %t102 = trunc i128 %t101 to i64
  store i64 %t102, ptr %l5, !tbaa !65
  %t104 = load i64, ptr %l5, !tbaa !65
  %t106 = uitofp i64 %t104 to double
  store double %t106, ptr %l6, !tbaa !26
  %t108 = load double, ptr %l6, !tbaa !26
  %t110 = fcmp olt double %t108, 0x43f0000000000000
  br i1 %t110, label %bb43, label %bb44
bb43:
  %t112 = load double, ptr %l6, !tbaa !26
  %t114 = fptoui double %t112 to i64
  %t115 = load i64, ptr %l5, !tbaa !65
  %t118 = icmp eq i64 %t114, %t115
  store i1 %t118, ptr %l75, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l75, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t121 = load i1, ptr %l4, !tbaa !21
  br i1 %t121, label %bb48, label %bb49
bb47:
  br label %bb52
bb48:
  %t123 = load double, ptr %l6, !tbaa !26
  %t125 = fneg double %t123
  store double %t125, ptr %l81, !tbaa !26
  br label %bb50
bb49:
  %t127 = load double, ptr %l6, !tbaa !26
  store double %t127, ptr %l81, !tbaa !26
  br label %bb50
bb50:
  store { i64, [2 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 0
  store i64 2, ptr %t130
  %t131 = load double, ptr %l81, !tbaa !26
  %t132 = insertvalue { double } undef, double %t131, 0
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 1
  store { double } %t132, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t129
  %t136 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 24, i64 8)
  store { i64, [2 x i64] } %t134, ptr %t136
  %t138 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %s7, ptr %t136)
  store i64 %t138, ptr %l87
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  %t139 = load i64, ptr %l87, !tbaa !24
  store i64 %t139, ptr %rv
  br label %ret
bb52:
  %t140 = load i64, ptr %l5, !tbaa !65
  %t143 = mul i64 %t140, 1099511628211
  store i64 %t143, ptr %l90, !tbaa !24
  %t144 = load i1, ptr %l4, !tbaa !21
  br i1 %t144, label %bb53, label %bb54
bb53:
  store i64 7, ptr %l92, !tbaa !24
  br label %bb55
bb54:
  store i64 9, ptr %l92, !tbaa !24
  br label %bb55
bb55:
  %t146 = load i64, ptr %l90, !tbaa !24
  %t147 = load i64, ptr %l92, !tbaa !24
  %t148 = add i64 %t146, %t147
  store i64 %t148, ptr %rv
  br label %ret
bb56:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t151 = load ptr, ptr %l94, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb57, label %bb58
bb57:
  %t154 = load ptr, ptr %l94, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 8}
  %t157 = icmp eq i64 %t155, 5
  store i1 %t157, ptr %l95, !tbaa !21
  br label %bb58
bb58:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb59, label %bb60
bb59:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { { i64, ptr } }, ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162
  store { i64, ptr } %t163, ptr %l7, !tbaa !27
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t165)
  store i64 %t167, ptr %l101
  br label %bb62
bb62:
  %t168 = load i64, ptr %l101, !tbaa !24
  store i64 %t168, ptr %rv
  br label %ret
bb63:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t170 = load ptr, ptr %l102, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb64, label %bb65
bb64:
  %t173 = load ptr, ptr %l102, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 8}
  %t176 = icmp eq i64 %t174, 6
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb65
bb65:
  %t177 = load i1, ptr %l103, !tbaa !21
  br i1 %t177, label %bb66, label %bb67
bb66:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  store { i64, ptr } %t182, ptr %l8, !tbaa !27
  br label %bb68
bb67:
  br label %bb76
bb68:
  store i64 5, ptr %l9, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t184, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l12, !tbaa !24
  br label %bb69
bb69:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l12, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb70, label %bb71
bb70:
  br label %bb75
bb71:
  br label %bb72
bb72:
  %t198 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t198, ptr %l115, !tbaa !27
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 %t199
  %t204 = load ptr, ptr %t203, !tbaa !39
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = mul i64 %t206, 31
  store i64 %t208, ptr %l119, !tbaa !24
  %t211 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %t204)
  store i64 %t211, ptr %l121
  br label %bb73
bb73:
  %t212 = load i64, ptr %l119, !tbaa !24
  %t213 = load i64, ptr %l121, !tbaa !24
  %t214 = add i64 %t212, %t213
  store i64 %t214, ptr %l9, !tbaa !24
  br label %bb74
bb74:
  %t216 = load i64, ptr %l11, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l11, !tbaa !24
  br label %bb69
bb75:
  %t221 = load i64, ptr %l9, !tbaa !24
  store i64 %t221, ptr %rv
  br label %ret
bb76:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t224 = load ptr, ptr %l127, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb77, label %bb78
bb77:
  %t227 = load ptr, ptr %l127, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 8}
  %t230 = icmp eq i64 %t228, 7
  store i1 %t230, ptr %l128, !tbaa !21
  br label %bb78
bb78:
  %t231 = load i1, ptr %l128, !tbaa !21
  br i1 %t231, label %bb79, label %bb80
bb79:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [2 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { ptr }, ptr %t234, i32 0, i32 0
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l14, !tbaa !29
  br label %bb81
bb80:
  br label %bb97
bb81:
  store i64 6, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t238)
  store i64 %t240, ptr %l134
  br label %bb82
bb82:
  %t241 = load i64, ptr %l134, !tbaa !24
  store i64 %t241, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t242 = load i64, ptr %l17, !tbaa !24
  %t243 = load i64, ptr %l16, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb83, label %bb84
bb83:
  %t248 = load i64, ptr %l18, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb88
bb85:
  %t252 = load i64, ptr %l17, !tbaa !24
  %t253 = load i64, ptr %l16, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l18, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l141, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb87
bb87:
  %t268 = load i64, ptr %l141, !tbaa !24
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb88
bb88:
  %t269 = load i64, ptr %l138, !tbaa !24
  store i64 %t269, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb89
bb89:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l19, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  br label %bb92
bb92:
  %t278 = load i64, ptr %l16, !tbaa !24
  %t279 = load i64, ptr %l20, !tbaa !24
  %t280 = load i64, ptr %l18, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l21, !tbaa !24
  %t288 = load i64, ptr %l15, !tbaa !24
  store i64 %t288, ptr %l159, !tbaa !24
  %t289 = load ptr, ptr %l14, !tbaa !29
  %t291 = getelementptr %"std/json:Object", ptr %t289, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l161, !tbaa !27
  %t293 = load i64, ptr %l21, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, ptr }, ptr %t296, i64 %t293
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !37
  %t300 = call i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t298)
  store i64 %t300, ptr %l164
  br label %bb93
bb93:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = getelementptr %"std/json:Object", ptr %t301, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l166, !tbaa !27
  %t305 = load i64, ptr %l21, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t305
  %t310 = load ptr, ptr %t309, !tbaa !39
  %t312 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %t310)
  store i64 %t312, ptr %l169
  br label %bb94
bb94:
  %t313 = load i64, ptr %l164, !tbaa !24
  %t314 = load i64, ptr %l169, !tbaa !24
  %t315 = xor i64 %t313, %t314
  %t317 = mul i64 %t315, 1099511628211
  %t318 = load i64, ptr %l159, !tbaa !24
  %t320 = add i64 %t318, %t317
  store i64 %t320, ptr %l15, !tbaa !24
  br label %bb95
bb95:
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = add i64 %t322, 1
  store i64 %t325, ptr %l20, !tbaa !24
  br label %bb89
bb96:
  %t327 = load i64, ptr %l15, !tbaa !24
  store i64 %t327, ptr %rv
  br label %ret
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  store i64 0, ptr %rv
  br label %ret
bb101:
  call void @__olang_check_failed(ptr @olang_loc_664da5dbc2e51de6_83a7e6ee135f5f2a)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca double
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i64
  %l27 = alloca { i64, [2 x i64] }
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca i64
  %l43 = alloca { i64, [2 x i64] }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca { i64, [2 x i64] }
  %l66 = alloca i64
  %l68 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i128 }
  %t41 = alloca { i64, [2 x i64] }, align 8
  %t78 = alloca { i64, [2 x i64] }, align 8
  %t141 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l1, !tbaa !26
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t16 = load double, ptr %l1, !tbaa !26
  %t17 = load double, ptr %l1, !tbaa !26
  %t20 = fcmp une double %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t22 = load double, ptr %l1, !tbaa !26
  %t23 = load double, ptr %l1, !tbaa !26
  %t26 = fsub double %t22, %t23
  %t28 = fcmp une double %t26, 0x0000000000000000
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb11
bb10:
  %t31 = load double, ptr %l1, !tbaa !26
  %t33 = fcmp oge double %t31, 0x43f0000000000000
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t36 = load double, ptr %l1, !tbaa !26
  %t38 = fcmp olt double %t36, 0xc3e0000000000000
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  store { i64, [2 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 0
  store i64 8, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t41
  store { i64, [2 x i64] } %t43, ptr %l24
  %t44 = call ptr @__olang_errpay_push()
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l25
  %t47 = inttoptr i64 %t46 to ptr
  %t49 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t47, ptr %l24)
  store { i64, [2 x i64] } %t49, ptr %l27
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t50 = load { i64, [2 x i64] }, ptr %l27
  %t51 = load i64, ptr %l25
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_scope_alloc_a(ptr %t52, i64 24, i64 8)
  store { i64, [2 x i64] } %t50, ptr %t53
  call void @__olang_errpay_set(ptr %t53)
  %t56 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t56, ptr %rv
  br label %ret
bb18:
  %t57 = load double, ptr %l1, !tbaa !26
  %t59 = fcmp oge double %t57, 0x43e0000000000000
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load double, ptr %l1, !tbaa !26
  %t63 = fptoui double %t61 to i64
  %t65 = zext i64 %t63 to i128
  %t67 = insertvalue { i32, i128 } zeroinitializer, i128 %t65, 1
  store { i32, i128 } %t67, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t68 = load double, ptr %l1, !tbaa !26
  %t70 = fptosi double %t68 to i64
  %t72 = sitofp i64 %t70 to double
  %t73 = load double, ptr %l1, !tbaa !26
  %t76 = fcmp une double %t72, %t73
  br i1 %t76, label %bb22, label %bb23
bb22:
  store { i64, [2 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 0
  store i64 8, ptr %t79
  %t80 = load { i64, [2 x i64] }, ptr %t78
  store { i64, [2 x i64] } %t80, ptr %l40
  %t81 = call ptr @__olang_errpay_push()
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l41, !tbaa !24
  %t83 = load i64, ptr %l41
  %t84 = inttoptr i64 %t83 to ptr
  %t86 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t84, ptr %l40)
  store { i64, [2 x i64] } %t86, ptr %l43
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t87 = load { i64, [2 x i64] }, ptr %l43
  %t88 = load i64, ptr %l41
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call ptr @__olang_scope_alloc_a(ptr %t89, i64 24, i64 8)
  store { i64, [2 x i64] } %t87, ptr %t90
  call void @__olang_errpay_set(ptr %t90)
  %t93 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t93, ptr %rv
  br label %ret
bb25:
  %t94 = load double, ptr %l1, !tbaa !26
  %t96 = fptosi double %t94 to i64
  %t98 = sext i64 %t96 to i128
  %t100 = insertvalue { i32, i128 } zeroinitializer, i128 %t98, 1
  store { i32, i128 } %t100, ptr %rv
  br label %ret
bb26:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 8}
  %t108 = icmp eq i64 %t106, 3
  store i1 %t108, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t109 = load i1, ptr %l50, !tbaa !21
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { i64 }, ptr %t112, i32 0, i32 0
  %t114 = load i64, ptr %t113
  store i64 %t114, ptr %l2, !tbaa !24
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = sext i64 %t116 to i128
  %t120 = insertvalue { i32, i128 } zeroinitializer, i128 %t118, 1
  store { i32, i128 } %t120, ptr %rv
  br label %ret
bb32:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l58, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [2 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { i64 }, ptr %t132, i32 0, i32 0
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l3, !tbaa !65
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t136 = load i64, ptr %l3, !tbaa !65
  %t138 = zext i64 %t136 to i128
  %t140 = insertvalue { i32, i128 } zeroinitializer, i128 %t138, 1
  store { i32, i128 } %t140, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb43
bb41:
  store { i64, [2 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t141, i32 0, i32 0
  store i64 8, ptr %t142
  %t143 = load { i64, [2 x i64] }, ptr %t141
  store { i64, [2 x i64] } %t143, ptr %l65
  %t144 = call ptr @__olang_errpay_push()
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l66, !tbaa !24
  %t146 = load i64, ptr %l66
  %t147 = inttoptr i64 %t146 to ptr
  %t149 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t147, ptr %l65)
  store { i64, [2 x i64] } %t149, ptr %l68
  br label %bb42
bb42:
  %t150 = load { i64, [2 x i64] }, ptr %l68
  %t151 = load i64, ptr %l66
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_scope_alloc_a(ptr %t152, i64 24, i64 8)
  store { i64, [2 x i64] } %t150, ptr %t153
  call void @__olang_errpay_set(ptr %t153)
  %t156 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t156, ptr %rv
  br label %ret
bb43:
  call void @__olang_check_failed(ptr @olang_loc_3d7deb9fd92cdf7_48602bd2c42c5c33)
  unreachable
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l87 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca %"std/json:Object"
  %l136 = alloca %"std/json:Object"
  %l137 = alloca i32
  %l143 = alloca ptr
  %t53 = alloca i64
  %t163 = alloca { i64, [2 x i64] }, align 8
  %t192 = alloca i64
  %t300 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 8
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = sub i64 %t4, 1
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = getelementptr %"std/json:reader", ptr %t9, i32 0, i32 8
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/json:reader", ptr %t11, i32 0, i32 6
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l23, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 8
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t18
  %t23 = load i64, ptr %t22, !tbaa !34
  store i64 %t23, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/json:reader", ptr %t25, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = sub i64 %t28, %t29
  store i64 %t32, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l31, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/json:reader", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l33, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 0
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l34, !tbaa !29
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb1, label %bb2
bb1:
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = icmp sle i64 %t46, 1152921504606846975
  br i1 %t47, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4cf869d60c4ca172_ef56e6f5157a9496)
  unreachable
bb3:
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = mul i64 %t49, 8
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = load ptr, ptr %l34, !tbaa !29
  store i64 0, ptr %t53
  br label %fill.54
fill.54:
  %t57 = load i64, ptr %t53
  %t58 = icmp slt i64 %t57, %t49
  br i1 %t58, label %fillb.55, label %filld.56
fillb.55:
  %t59 = getelementptr ptr, ptr %t51, i64 %t57
  store ptr %t52, ptr %t59
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %t53
  br label %fill.54
filld.56:
  %t61 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t51, 1
  store { i64, ptr } %t62, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4cf869d60c4ca172_ef56e6f5157a9496)
  unreachable
bb5:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb10
bb7:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l45, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb9
bb9:
  %t92 = load i64, ptr %l45, !tbaa !24
  store i64 %t92, ptr %l42, !tbaa !24
  br label %bb10
bb10:
  %t93 = load i64, ptr %l42, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t112, ptr %l63, !tbaa !27
  %t113 = load i64, ptr %l9, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"std/json:reader", ptr %t114, i32 0, i32 2
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l66, !tbaa !27
  %t118 = load i64, ptr %l1, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t130 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t113
  store ptr %t127, ptr %t132, !tbaa !39
  br label %bb15
bb15:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l8, !tbaa !24
  br label %bb11
bb16:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l1, !tbaa !24
  %t142 = getelementptr %"std/json:reader", ptr %t138, i32 0, i32 3
  store i64 %t139, ptr %t142, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"std/json:reader", ptr %t143, i32 0, i32 7
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l77, !tbaa !27
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"std/json:reader", ptr %t147, i32 0, i32 8
  %t150 = load i64, ptr %t149, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t150
  %t155 = load i64, ptr %t154, !tbaa !34
  store i64 %t155, ptr %l10, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t159 = icmp slt i64 %t157, 0
  br i1 %t159, label %bb17, label %bb18
bb17:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [2 x i64] }, ptr %t163, i32 0, i32 0
  store i64 6, ptr %t164
  %t166 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t162, 0
  %t167 = getelementptr { i64, [2 x i64] }, ptr %t163, i32 0, i32 1
  store { { i64, ptr } } %t166, ptr %t167
  %t168 = load { i64, [2 x i64] }, ptr %t163
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t168, ptr %t170
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t161, ptr %t170)
  br label %bb19
bb18:
  %t173 = load i64, ptr %l2, !tbaa !24
  store i64 %t173, ptr %l87, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"std/json:reader", ptr %t174, i32 0, i32 4
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l89, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %t179, i64 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !37
  store { i64, ptr } %t181, ptr %l90, !tbaa !27
  %t182 = load i64, ptr %l87, !tbaa !24
  %t183 = icmp sge i64 %t182, 0
  br i1 %t183, label %bb20, label %bb21
bb19:
  br label %bb43
bb20:
  %t185 = load i64, ptr %l87, !tbaa !24
  %t186 = icmp sle i64 %t185, 576460752303423487
  br i1 %t186, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a4e4729341d0d567_917d86fd422044ab)
  unreachable
bb22:
  %t188 = load i64, ptr %l87, !tbaa !24
  %t189 = mul i64 %t188, 16
  %t190 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t189)
  %t191 = load { i64, ptr }, ptr %l90, !tbaa !27
  store i64 0, ptr %t192
  br label %fill.193
fill.193:
  %t196 = load i64, ptr %t192
  %t197 = icmp slt i64 %t196, %t188
  br i1 %t197, label %fillb.194, label %filld.195
fillb.194:
  %t198 = getelementptr { i64, ptr }, ptr %t190, i64 %t196
  store { i64, ptr } %t191, ptr %t198
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %t192
  br label %fill.193
filld.195:
  %t200 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t190, 1
  store { i64, ptr } %t201, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l2, !tbaa !24
  store i64 %t203, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l13, !tbaa !24
  %t206 = load i64, ptr %l12, !tbaa !24
  %t209 = icmp sgt i64 %t205, %t206
  br i1 %t209, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a4e4729341d0d567_917d86fd422044ab)
  unreachable
bb24:
  %t211 = load i64, ptr %l14, !tbaa !24
  %t213 = icmp sgt i64 %t211, 0
  br i1 %t213, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb29
bb26:
  %t215 = load i64, ptr %l13, !tbaa !24
  %t216 = load i64, ptr %l12, !tbaa !24
  %t219 = sub i64 %t215, %t216
  %t220 = load i64, ptr %l14, !tbaa !24
  %t223 = add i64 %t219, %t220
  %t225 = sub i64 %t223, 1
  %t226 = load i64, ptr %l14, !tbaa !24
  %t229 = sdiv i64 %t225, %t226
  store i64 %t229, ptr %l101, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb28
bb28:
  %t231 = load i64, ptr %l101, !tbaa !24
  store i64 %t231, ptr %l98, !tbaa !24
  br label %bb29
bb29:
  %t232 = load i64, ptr %l98, !tbaa !24
  store i64 %t232, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t234 = load i64, ptr %l15, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t242 = load i64, ptr %l16, !tbaa !24
  %t243 = load i64, ptr %l14, !tbaa !24
  %t246 = mul i64 %t242, %t243
  %t249 = add i64 %t241, %t246
  store i64 %t249, ptr %l17, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t251, ptr %l119, !tbaa !27
  %t252 = load i64, ptr %l17, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"std/json:reader", ptr %t253, i32 0, i32 4
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l122, !tbaa !27
  %t257 = load i64, ptr %l10, !tbaa !24
  %t258 = load i64, ptr %l17, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %t264, i64 %t261
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !37
  %t269 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %t270, i64 %t252
  store { i64, ptr } %t266, ptr %t271, !tbaa !37
  br label %bb34
bb34:
  %t272 = load i64, ptr %l16, !tbaa !24
  %t275 = add i64 %t272, 1
  store i64 %t275, ptr %l16, !tbaa !24
  br label %bb30
bb35:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = getelementptr %"std/json:reader", ptr %t277, i32 0, i32 5
  store i64 %t278, ptr %t281, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l132, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t287 = call { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t283, { i64, ptr } %t284)
  %t288 = extractvalue { i32, %"std/json:Object" } %t287, 1
  %t289 = extractvalue { i32, %"std/json:Object" } %t287, 0
  store i32 %t289, ptr %l137
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb37, label %ok.291, !prof !99
ok.291:
  store %"std/json:Object" %t288, ptr %l136
  br label %bb36
bb36:
  %t292 = load %"std/json:Object", ptr %l136
  store %"std/json:Object" %t292, ptr %l133
  br label %bb41
bb37:
  %t293 = load i32, ptr %l137, !tbaa !23
  %t294 = ashr i32 %t293, 16
  %t296 = icmp eq i32 %t294, 1
  br i1 %t296, label %bb38, label %bb39
bb38:
  call void @__olang_errpay_pop()
  br label %bb39
bb39:
  br label %bb40
bb40:
  call void @__olang_check_failed(ptr @olang_loc_78dc4052a96c39eb_b95510f79f72ba17)
  unreachable
bb41:
  %t298 = load %"std/json:Object", ptr %l133
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"std/json:Object" %t298, ptr %t299
  store { i64, [2 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 0
  store i64 7, ptr %t301
  %t303 = insertvalue { ptr } undef, ptr %t299, 0
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 1
  store { ptr } %t303, ptr %t304
  %t305 = load { i64, [2 x i64] }, ptr %t300
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t305, ptr %t307
  %t308 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t308, ptr %t307)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l143, !tbaa !29
  %t311 = load ptr, ptr %l143, !tbaa !29
  %t312 = getelementptr %"std/json:reader", ptr %t311, i32 0, i32 1
  %t313 = load i64, ptr %t312, !tbaa !24
  %t316 = add i64 %t313, 1
  %t318 = load ptr, ptr %l143, !tbaa !29
  %t319 = getelementptr %"std/json:reader", ptr %t318, i32 0, i32 1
  store i64 %t316, ptr %t319, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp slt i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/json:reader", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t21)
  store i1 %t23, ptr %l12
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l26 = alloca { i64, [2 x i64] }
  %l30 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l56 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l66 = alloca ptr
  %l72 = alloca i1
  %l78 = alloca i64
  %l80 = alloca i64
  %l81 = alloca { i64, [2 x i64] }
  %l82 = alloca i64
  %l84 = alloca { i64, [2 x i64] }
  %l89 = alloca i1
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l106 = alloca i1
  %l108 = alloca { i64, ptr }
  %l117 = alloca i64
  %l119 = alloca i64
  %l120 = alloca { i64, [2 x i64] }
  %l121 = alloca i64
  %l123 = alloca { i64, [2 x i64] }
  %l126 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i32
  %l136 = alloca i1
  %l142 = alloca i64
  %l144 = alloca i64
  %l145 = alloca { i64, [2 x i64] }
  %l146 = alloca i64
  %l148 = alloca { i64, [2 x i64] }
  %l151 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i64
  %l170 = alloca i64
  %l171 = alloca { i64, [2 x i64] }
  %l172 = alloca i64
  %l174 = alloca { i64, [2 x i64] }
  %l180 = alloca { i64, ptr }
  %l183 = alloca ptr
  %rv = alloca { i32, i64 }
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t175 = alloca { i64, [2 x i64] }, align 8
  %t268 = alloca { i64, [2 x i64] }, align 8
  %t336 = alloca { i64, [2 x i64] }, align 8
  %t394 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/json:reader", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp eq i64 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = getelementptr %"std/json:reader", ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = add i64 %t20, 1
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t25, i32 0, i32 1
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l20
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb4
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = insertvalue { i64, i64 } undef, i64 %t35, 0
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = insertvalue { i64, i64 } %t36, i64 %t37, 1
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i64, i64 } %t38, ptr %t39
  %t40 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t40, ptr %l23
  %t41 = call ptr @__olang_errpay_push()
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l24, !tbaa !24
  %t43 = load i64, ptr %l24
  %t44 = inttoptr i64 %t43 to ptr
  %t46 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t44, ptr %l23)
  store { i64, [2 x i64] } %t46, ptr %l26
  br label %bb5
bb5:
  %t47 = load { i64, [2 x i64] }, ptr %l26
  %t48 = load i64, ptr %l24
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call ptr @__olang_scope_alloc_a(ptr %t49, i64 24, i64 8)
  store { i64, [2 x i64] } %t47, ptr %t50
  call void @__olang_errpay_set(ptr %t50)
  %t53 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t53, ptr %rv
  br label %ret
bb6:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/json:reader", ptr %t54, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"std/json:reader", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = add i64 %t61, 1
  %t65 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t63
  %t68 = load i8, ptr %t67, !tbaa !32
  store i8 %t68, ptr %l3, !tbaa !22
  store i8 0, ptr %l4, !tbaa !22
  %t70 = load i8, ptr %l3, !tbaa !22
  %t72 = icmp eq i8 %t70, 34
  br i1 %t72, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb9
bb8:
  %t74 = load i8, ptr %l3, !tbaa !22
  %t76 = icmp eq i8 %t74, 92
  store i1 %t76, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb11:
  %t79 = load i8, ptr %l3, !tbaa !22
  %t81 = icmp eq i8 %t79, 47
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb13, label %bb14
bb13:
  %t84 = load i8, ptr %l3, !tbaa !22
  store i8 %t84, ptr %l4, !tbaa !22
  br label %bb78
bb14:
  %t86 = load i8, ptr %l3, !tbaa !22
  %t88 = icmp eq i8 %t86, 110
  br i1 %t88, label %bb15, label %bb16
bb15:
  store i8 10, ptr %l4, !tbaa !22
  br label %bb77
bb16:
  %t90 = load i8, ptr %l3, !tbaa !22
  %t92 = icmp eq i8 %t90, 116
  br i1 %t92, label %bb17, label %bb18
bb17:
  store i8 9, ptr %l4, !tbaa !22
  br label %bb76
bb18:
  %t94 = load i8, ptr %l3, !tbaa !22
  %t96 = icmp eq i8 %t94, 114
  br i1 %t96, label %bb19, label %bb20
bb19:
  store i8 13, ptr %l4, !tbaa !22
  br label %bb75
bb20:
  %t98 = load i8, ptr %l3, !tbaa !22
  %t100 = icmp eq i8 %t98, 98
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i8 8, ptr %l4, !tbaa !22
  br label %bb74
bb22:
  %t102 = load i8, ptr %l3, !tbaa !22
  %t104 = icmp eq i8 %t102, 102
  br i1 %t104, label %bb23, label %bb24
bb23:
  store i8 12, ptr %l4, !tbaa !22
  br label %bb73
bb24:
  %t106 = load i8, ptr %l3, !tbaa !22
  %t108 = icmp eq i8 %t106, 117
  br i1 %t108, label %bb25, label %bb26
bb25:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"std/json:reader", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = add i64 %t114, 2
  %t119 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %t110, i64 %t116)
  %t120 = extractvalue { i32, i64 } %t119, 1
  %t121 = extractvalue { i32, i64 } %t119, 0
  store i32 %t121, ptr %l62
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb28, label %ok.123, !prof !99
ok.123:
  store i64 %t120, ptr %l61
  br label %bb27
bb26:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l168
  br label %bb70
bb27:
  %t127 = load i64, ptr %l61, !tbaa !24
  store i64 %t127, ptr %l56, !tbaa !24
  br label %bb29
bb28:
  %t128 = load i32, ptr %l62, !tbaa !23
  %t129 = lshr i32 %t128, 16
  %t130 = and i32 %t128, 65535
  %t131 = icmp eq i32 %t129, 1
  %t132 = select i1 %t131, i32 1, i32 0
  %t133 = icmp eq i32 %t128, 0
  %t134 = shl i32 %t132, 16
  %t135 = or i32 %t134, %t130
  %t136 = select i1 %t133, i32 0, i32 %t135
  %t138 = insertvalue { i32, i64 } zeroinitializer, i32 %t136, 0
  store { i32, i64 } %t138, ptr %rv
  br label %ret
bb29:
  %t139 = load i64, ptr %l56, !tbaa !24
  store i64 %t139, ptr %l5, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"std/json:reader", ptr %t140, i32 0, i32 1
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l6, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l66, !tbaa !29
  %t146 = load ptr, ptr %l66, !tbaa !29
  %t147 = getelementptr %"std/json:reader", ptr %t146, i32 0, i32 1
  %t148 = load i64, ptr %t147, !tbaa !24
  %t151 = add i64 %t148, 6
  %t153 = load ptr, ptr %l66, !tbaa !29
  %t154 = getelementptr %"std/json:reader", ptr %t153, i32 0, i32 1
  store i64 %t151, ptr %t154, !tbaa !24
  %t155 = load i64, ptr %l5, !tbaa !24
  %t157 = icmp sge i64 %t155, 56320
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sle i64 %t159, 57343
  store i1 %t161, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t163 = load i1, ptr %l72, !tbaa !21
  br i1 %t163, label %bb33, label %bb34
bb33:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l6, !tbaa !24
  %t168 = getelementptr %"std/json:reader", ptr %t164, i32 0, i32 1
  store i64 %t165, ptr %t168, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l78
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l80
  br label %bb36
bb36:
  store { i64, [2 x i64] } zeroinitializer, ptr %t175
  %t176 = getelementptr { i64, [2 x i64] }, ptr %t175, i32 0, i32 0
  store i64 2, ptr %t176
  %t177 = load i64, ptr %l78, !tbaa !24
  %t178 = insertvalue { i64, i64 } undef, i64 %t177, 0
  %t179 = load i64, ptr %l80, !tbaa !24
  %t180 = insertvalue { i64, i64 } %t178, i64 %t179, 1
  %t181 = getelementptr { i64, [2 x i64] }, ptr %t175, i32 0, i32 1
  store { i64, i64 } %t180, ptr %t181
  %t182 = load { i64, [2 x i64] }, ptr %t175
  store { i64, [2 x i64] } %t182, ptr %l81
  %t183 = call ptr @__olang_errpay_push()
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l82, !tbaa !24
  %t185 = load i64, ptr %l82
  %t186 = inttoptr i64 %t185 to ptr
  %t188 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t186, ptr %l81)
  store { i64, [2 x i64] } %t188, ptr %l84
  br label %bb37
bb37:
  %t189 = load { i64, [2 x i64] }, ptr %l84
  %t190 = load i64, ptr %l82
  %t191 = inttoptr i64 %t190 to ptr
  %t192 = call ptr @__olang_scope_alloc_a(ptr %t191, i64 24, i64 8)
  store { i64, [2 x i64] } %t189, ptr %t192
  call void @__olang_errpay_set(ptr %t192)
  %t195 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t195, ptr %rv
  br label %ret
bb38:
  %t196 = load i64, ptr %l5, !tbaa !24
  %t198 = icmp sge i64 %t196, 55296
  br i1 %t198, label %bb39, label %bb40
bb39:
  %t200 = load i64, ptr %l5, !tbaa !24
  %t202 = icmp sle i64 %t200, 56319
  store i1 %t202, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t204 = load i1, ptr %l89, !tbaa !21
  br i1 %t204, label %bb42, label %bb43
bb42:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"std/json:reader", ptr %t205, i32 0, i32 1
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = add i64 %t208, 1
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"std/json:reader", ptr %t211, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t219 = icmp sge i64 %t210, %t216
  br i1 %t219, label %bb44, label %bb45
bb43:
  br label %bb68
bb44:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb46
bb45:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"std/json:reader", ptr %t221, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l101, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/json:reader", ptr %t225, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i8, ptr %t231, i64 %t228
  %t233 = load i8, ptr %t232, !tbaa !32
  %t235 = icmp ne i8 %t233, 92
  store i1 %t235, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t237 = load i1, ptr %l99, !tbaa !21
  br i1 %t237, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb49
bb48:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"std/json:reader", ptr %t238, i32 0, i32 0
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  store { i64, ptr } %t241, ptr %l108, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"std/json:reader", ptr %t242, i32 0, i32 1
  %t245 = load i64, ptr %t244, !tbaa !24
  %t247 = add i64 %t245, 1
  %t249 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i8, ptr %t250, i64 %t247
  %t252 = load i8, ptr %t251, !tbaa !32
  %t254 = icmp ne i8 %t252, 117
  store i1 %t254, ptr %l106, !tbaa !21
  br label %bb49
bb49:
  %t256 = load i1, ptr %l106, !tbaa !21
  br i1 %t256, label %bb50, label %bb51
bb50:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l6, !tbaa !24
  %t261 = getelementptr %"std/json:reader", ptr %t257, i32 0, i32 1
  store i64 %t258, ptr %t261, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t262)
  store i64 %t264, ptr %l117
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t265)
  store i64 %t267, ptr %l119
  br label %bb53
bb53:
  store { i64, [2 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [2 x i64] }, ptr %t268, i32 0, i32 0
  store i64 2, ptr %t269
  %t270 = load i64, ptr %l117, !tbaa !24
  %t271 = insertvalue { i64, i64 } undef, i64 %t270, 0
  %t272 = load i64, ptr %l119, !tbaa !24
  %t273 = insertvalue { i64, i64 } %t271, i64 %t272, 1
  %t274 = getelementptr { i64, [2 x i64] }, ptr %t268, i32 0, i32 1
  store { i64, i64 } %t273, ptr %t274
  %t275 = load { i64, [2 x i64] }, ptr %t268
  store { i64, [2 x i64] } %t275, ptr %l120
  %t276 = call ptr @__olang_errpay_push()
  %t277 = ptrtoint ptr %t276 to i64
  store i64 %t277, ptr %l121, !tbaa !24
  %t278 = load i64, ptr %l121
  %t279 = inttoptr i64 %t278 to ptr
  %t281 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t279, ptr %l120)
  store { i64, [2 x i64] } %t281, ptr %l123
  br label %bb54
bb54:
  %t282 = load { i64, [2 x i64] }, ptr %l123
  %t283 = load i64, ptr %l121
  %t284 = inttoptr i64 %t283 to ptr
  %t285 = call ptr @__olang_scope_alloc_a(ptr %t284, i64 24, i64 8)
  store { i64, [2 x i64] } %t282, ptr %t285
  call void @__olang_errpay_set(ptr %t285)
  %t288 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t288, ptr %rv
  br label %ret
bb55:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"std/json:reader", ptr %t290, i32 0, i32 1
  %t293 = load i64, ptr %t292, !tbaa !24
  %t295 = add i64 %t293, 2
  %t298 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %t289, i64 %t295)
  %t299 = extractvalue { i32, i64 } %t298, 1
  %t300 = extractvalue { i32, i64 } %t298, 0
  store i32 %t300, ptr %l132
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb57, label %ok.302, !prof !99
ok.302:
  store i64 %t299, ptr %l131
  br label %bb56
bb56:
  %t303 = load i64, ptr %l131, !tbaa !24
  store i64 %t303, ptr %l126, !tbaa !24
  br label %bb58
bb57:
  %t304 = load i32, ptr %l132, !tbaa !23
  %t305 = lshr i32 %t304, 16
  %t306 = and i32 %t304, 65535
  %t307 = icmp eq i32 %t305, 1
  %t308 = select i1 %t307, i32 1, i32 0
  %t309 = icmp eq i32 %t304, 0
  %t310 = shl i32 %t308, 16
  %t311 = or i32 %t310, %t306
  %t312 = select i1 %t309, i32 0, i32 %t311
  %t314 = insertvalue { i32, i64 } zeroinitializer, i32 %t312, 0
  store { i32, i64 } %t314, ptr %rv
  br label %ret
bb58:
  %t315 = load i64, ptr %l126, !tbaa !24
  store i64 %t315, ptr %l7, !tbaa !24
  %t316 = load i64, ptr %l7, !tbaa !24
  %t318 = icmp slt i64 %t316, 56320
  br i1 %t318, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb61
bb60:
  %t320 = load i64, ptr %l7, !tbaa !24
  %t322 = icmp sgt i64 %t320, 57343
  store i1 %t322, ptr %l136, !tbaa !21
  br label %bb61
bb61:
  %t324 = load i1, ptr %l136, !tbaa !21
  br i1 %t324, label %bb62, label %bb63
bb62:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i64, ptr %l6, !tbaa !24
  %t329 = getelementptr %"std/json:reader", ptr %t325, i32 0, i32 1
  store i64 %t326, ptr %t329, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l142
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t333)
  store i64 %t335, ptr %l144
  br label %bb65
bb65:
  store { i64, [2 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [2 x i64] }, ptr %t336, i32 0, i32 0
  store i64 2, ptr %t337
  %t338 = load i64, ptr %l142, !tbaa !24
  %t339 = insertvalue { i64, i64 } undef, i64 %t338, 0
  %t340 = load i64, ptr %l144, !tbaa !24
  %t341 = insertvalue { i64, i64 } %t339, i64 %t340, 1
  %t342 = getelementptr { i64, [2 x i64] }, ptr %t336, i32 0, i32 1
  store { i64, i64 } %t341, ptr %t342
  %t343 = load { i64, [2 x i64] }, ptr %t336
  store { i64, [2 x i64] } %t343, ptr %l145
  %t344 = call ptr @__olang_errpay_push()
  %t345 = ptrtoint ptr %t344 to i64
  store i64 %t345, ptr %l146, !tbaa !24
  %t346 = load i64, ptr %l146
  %t347 = inttoptr i64 %t346 to ptr
  %t349 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t347, ptr %l145)
  store { i64, [2 x i64] } %t349, ptr %l148
  br label %bb66
bb66:
  %t350 = load { i64, [2 x i64] }, ptr %l148
  %t351 = load i64, ptr %l146
  %t352 = inttoptr i64 %t351 to ptr
  %t353 = call ptr @__olang_scope_alloc_a(ptr %t352, i64 24, i64 8)
  store { i64, [2 x i64] } %t350, ptr %t353
  call void @__olang_errpay_set(ptr %t353)
  %t356 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t356, ptr %rv
  br label %ret
bb67:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l151, !tbaa !29
  %t358 = load ptr, ptr %l151, !tbaa !29
  %t359 = getelementptr %"std/json:reader", ptr %t358, i32 0, i32 1
  %t360 = load i64, ptr %t359, !tbaa !24
  %t363 = add i64 %t360, 6
  %t365 = load ptr, ptr %l151, !tbaa !29
  %t366 = getelementptr %"std/json:reader", ptr %t365, i32 0, i32 1
  store i64 %t363, ptr %t366, !tbaa !24
  %t367 = load i64, ptr %l5, !tbaa !24
  %t370 = sub i64 %t367, 55296
  %t372 = shl i64 %t370, 10
  %t374 = add i64 65536, %t372
  %t375 = load i64, ptr %l7, !tbaa !24
  %t377 = sub i64 %t375, 56320
  %t380 = add i64 %t374, %t377
  store i64 %t380, ptr %l5, !tbaa !24
  br label %bb68
bb68:
  %t382 = load i64, ptr %l5, !tbaa !24
  %t383 = load i64, ptr %l1, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t388 = call i64 @std_2fjson_2eputUtf8(ptr %v1, i64 %t382, i64 %t383, { i64, ptr } %t384)
  store i64 %t388, ptr %l166
  br label %bb69
bb69:
  %t389 = load i64, ptr %l166, !tbaa !24
  %t390 = insertvalue { i32, i64 } zeroinitializer, i64 %t389, 1
  store { i32, i64 } %t390, ptr %rv
  br label %ret
bb70:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l170
  br label %bb71
bb71:
  store { i64, [2 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [2 x i64] }, ptr %t394, i32 0, i32 0
  store i64 2, ptr %t395
  %t396 = load i64, ptr %l168, !tbaa !24
  %t397 = insertvalue { i64, i64 } undef, i64 %t396, 0
  %t398 = load i64, ptr %l170, !tbaa !24
  %t399 = insertvalue { i64, i64 } %t397, i64 %t398, 1
  %t400 = getelementptr { i64, [2 x i64] }, ptr %t394, i32 0, i32 1
  store { i64, i64 } %t399, ptr %t400
  %t401 = load { i64, [2 x i64] }, ptr %t394
  store { i64, [2 x i64] } %t401, ptr %l171
  %t402 = call ptr @__olang_errpay_push()
  %t403 = ptrtoint ptr %t402 to i64
  store i64 %t403, ptr %l172, !tbaa !24
  %t404 = load i64, ptr %l172
  %t405 = inttoptr i64 %t404 to ptr
  %t407 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t405, ptr %l171)
  store { i64, [2 x i64] } %t407, ptr %l174
  br label %bb72
bb72:
  %t408 = load { i64, [2 x i64] }, ptr %l174
  %t409 = load i64, ptr %l172
  %t410 = inttoptr i64 %t409 to ptr
  %t411 = call ptr @__olang_scope_alloc_a(ptr %t410, i64 24, i64 8)
  store { i64, [2 x i64] } %t408, ptr %t411
  call void @__olang_errpay_set(ptr %t411)
  %t414 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t414, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t415 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t419 = icmp sgt i64 %t417, 0
  br i1 %t419, label %bb79, label %bb80
bb79:
  %t421 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t421, ptr %l180, !tbaa !27
  %t422 = load i64, ptr %l1, !tbaa !24
  %t423 = load i8, ptr %l4, !tbaa !22
  %t426 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr i8, ptr %t427, i64 %t422
  store i8 %t423, ptr %t428, !tbaa !32
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l183, !tbaa !29
  %t430 = load ptr, ptr %l183, !tbaa !29
  %t431 = getelementptr %"std/json:reader", ptr %t430, i32 0, i32 1
  %t432 = load i64, ptr %t431, !tbaa !24
  %t435 = add i64 %t432, 2
  %t437 = load ptr, ptr %l183, !tbaa !29
  %t438 = getelementptr %"std/json:reader", ptr %t437, i32 0, i32 1
  store i64 %t435, ptr %t438, !tbaa !24
  %t440 = insertvalue { i32, i64 } zeroinitializer, i64 1, 1
  store { i32, i64 } %t440, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local ptr @std_2fjson_2estd_2fjson_3areader_2eexact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, double %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca double
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i32
  %l65 = alloca i64
  %l66 = alloca i32
  %l72 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t50 = alloca { i64, [2 x i64] }, align 8
  %t96 = alloca { i64, [2 x i64] }, align 8
  %t138 = alloca { i64, [2 x i64] }, align 8
  %t163 = alloca { i64, [2 x i64] }, align 8
  %t173 = alloca { i64, [2 x i64] }, align 8
  %t202 = alloca { i64, [2 x i64] }, align 8
  %t212 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store double %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l11, !tbaa !27
  store i64 %a1, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sle i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb5:
  %t23 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l12, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = getelementptr i8, ptr %t24, i64 %t25
  %t28 = sub i64 %t26, %t25
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 0
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = icmp eq i8 %t39, 45
  br i1 %t41, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb7:
  store i64 1, ptr %l25, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = sub i64 %t43, %t44
  %t47 = icmp sle i64 %t45, 15
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 0
  store i64 2, ptr %t51
  %t53 = insertvalue { double } undef, double %t49, 0
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  store { double } %t53, ptr %t54
  %t55 = load { i64, [2 x i64] }, ptr %t50
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t55, ptr %t57
  call void @__olang_scope_close(ptr %s0)
  store ptr %t57, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l38, !tbaa !27
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l7, !tbaa !22
  %t81 = load i8, ptr %l7, !tbaa !22
  %t83 = icmp eq i8 %t81, 46
  br i1 %t83, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t85 = load i8, ptr %l7, !tbaa !22
  %t87 = icmp eq i8 %t85, 101
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb22
bb21:
  %t90 = load i8, ptr %l7, !tbaa !22
  %t92 = icmp eq i8 %t90, 69
  store i1 %t92, ptr %l46, !tbaa !21
  br label %bb22
bb22:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t95 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 0
  store i64 2, ptr %t97
  %t99 = insertvalue { double } undef, double %t95, 0
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  store { double } %t99, ptr %t100
  %t101 = load { i64, [2 x i64] }, ptr %t96
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t101, ptr %t103
  call void @__olang_scope_close(ptr %s0)
  store ptr %t103, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l5, !tbaa !24
  br label %bb13
bb27:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  %t111 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t112 = extractvalue { i32, i64 } %t111, 1
  %t113 = extractvalue { i32, i64 } %t111, 0
  store i32 %t113, ptr %l58
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb29, label %ok.115, !prof !99
ok.115:
  store i64 %t112, ptr %l57
  br label %bb28
bb28:
  %t116 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t117 = load i64, ptr %l57, !tbaa !24
  %t118 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t116, i64 %t117)
  %t119 = extractvalue { i32, i64 } %t118, 1
  %t120 = extractvalue { i32, i64 } %t118, 0
  store i32 %t120, ptr %l60
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb32, label %ok.122, !prof !99
ok.122:
  store i64 %t119, ptr %l59
  br label %bb31
bb29:
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l62, !tbaa !27
  %t124 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t125 = extractvalue { i32, i64 } %t124, 1
  %t126 = extractvalue { i32, i64 } %t124, 0
  store i32 %t126, ptr %l64
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb34, label %ok.128, !prof !99
ok.128:
  store i64 %t125, ptr %l63
  br label %bb33
bb31:
  %t129 = load i64, ptr %l59, !tbaa !24
  store i64 %t129, ptr %l55, !tbaa !24
  br label %bb45
bb32:
  br label %bb30
bb33:
  %t130 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t131 = load i64, ptr %l63, !tbaa !24
  %t132 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t130, i64 %t131)
  %t133 = extractvalue { i32, i64 } %t132, 1
  %t134 = extractvalue { i32, i64 } %t132, 0
  store i32 %t134, ptr %l66
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb37, label %ok.136, !prof !99
ok.136:
  store i64 %t133, ptr %l65
  br label %bb36
bb34:
  br label %bb35
bb35:
  %t137 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t138, i32 0, i32 0
  store i64 2, ptr %t139
  %t141 = insertvalue { double } undef, double %t137, 0
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t138, i32 0, i32 1
  store { double } %t141, ptr %t142
  %t143 = load { i64, [2 x i64] }, ptr %t138
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t143, ptr %t145
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t145, ptr %rv
  br label %ret
bb36:
  %t147 = load i64, ptr %l65, !tbaa !65
  store i64 %t147, ptr %l61, !tbaa !65
  br label %bb38
bb37:
  br label %bb35
bb38:
  %t148 = load i64, ptr %l61, !tbaa !65
  store i64 %t148, ptr %l8, !tbaa !65
  %t149 = load double, ptr %l2, !tbaa !26
  %t151 = fcmp olt double %t149, 0x43f0000000000000
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t153 = load double, ptr %l2, !tbaa !26
  %t155 = fptoui double %t153 to i64
  %t156 = load i64, ptr %l8, !tbaa !65
  %t159 = icmp eq i64 %t155, %t156
  store i1 %t159, ptr %l72, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb41
bb41:
  %t161 = load i1, ptr %l72, !tbaa !21
  br i1 %t161, label %bb42, label %bb43
bb42:
  %t162 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [2 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t166 = insertvalue { double } undef, double %t162, 0
  %t167 = getelementptr { i64, [2 x i64] }, ptr %t163, i32 0, i32 1
  store { double } %t166, ptr %t167
  %t168 = load { i64, [2 x i64] }, ptr %t163
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t168, ptr %t170
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t170, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t172 = load i64, ptr %l8, !tbaa !65
  store { i64, [2 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 0
  store i64 4, ptr %t174
  %t176 = insertvalue { i64 } undef, i64 %t172, 0
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 1
  store { i64 } %t176, ptr %t177
  %t178 = load { i64, [2 x i64] }, ptr %t173
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t178, ptr %t180
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t180, ptr %rv
  br label %ret
bb45:
  %t182 = load i64, ptr %l55, !tbaa !24
  store i64 %t182, ptr %l9, !tbaa !24
  %t183 = load double, ptr %l2, !tbaa !26
  %t185 = fcmp oge double %t183, 0xc3e0000000000000
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t187 = load double, ptr %l2, !tbaa !26
  %t189 = fcmp olt double %t187, 0x43e0000000000000
  store i1 %t189, ptr %l85, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb48
bb48:
  %t191 = load i1, ptr %l85, !tbaa !21
  br i1 %t191, label %bb49, label %bb50
bb49:
  %t192 = load double, ptr %l2, !tbaa !26
  %t194 = fptosi double %t192 to i64
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  store i1 %t198, ptr %l88, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb51
bb51:
  %t200 = load i1, ptr %l88, !tbaa !21
  br i1 %t200, label %bb52, label %bb53
bb52:
  %t201 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [2 x i64] }, ptr %t202, i32 0, i32 0
  store i64 2, ptr %t203
  %t205 = insertvalue { double } undef, double %t201, 0
  %t206 = getelementptr { i64, [2 x i64] }, ptr %t202, i32 0, i32 1
  store { double } %t205, ptr %t206
  %t207 = load { i64, [2 x i64] }, ptr %t202
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t207, ptr %t209
  call void @__olang_scope_close(ptr %s0)
  store ptr %t209, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t211 = load i64, ptr %l9, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 0
  store i64 3, ptr %t213
  %t215 = insertvalue { i64 } undef, i64 %t211, 0
  %t216 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 1
  store { i64 } %t215, ptr %t216
  %t217 = load { i64, [2 x i64] }, ptr %t212
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t217, ptr %t219
  call void @__olang_scope_close(ptr %s0)
  store ptr %t219, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l51 = alloca { i64, [2 x i64] }
  %l52 = alloca i64
  %l54 = alloca { i64, [2 x i64] }
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l71 = alloca i1
  %l80 = alloca i1
  %l90 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, [2 x i64] }
  %l94 = alloca i64
  %l96 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i64 }
  %t80 = alloca { i64, [2 x i64] }, align 8
  %t172 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = add i64 %t3, 4
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l20, !tbaa !24
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb39
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/json:reader", ptr %t54, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t62 = icmp sge i64 %t53, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/json:reader", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = getelementptr %"std/json:reader", ptr %t64, i32 0, i32 1
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t74)
  store i64 %t76, ptr %l48
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l50
  br label %bb14
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 0
  store i64 1, ptr %t81
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = insertvalue { i64, i64 } undef, i64 %t82, 0
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = insertvalue { i64, i64 } %t83, i64 %t84, 1
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 1
  store { i64, i64 } %t85, ptr %t86
  %t87 = load { i64, [2 x i64] }, ptr %t80
  store { i64, [2 x i64] } %t87, ptr %l51
  %t88 = call ptr @__olang_errpay_push()
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = load i64, ptr %l52
  %t91 = inttoptr i64 %t90 to ptr
  %t93 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t91, ptr %l51)
  store { i64, [2 x i64] } %t93, ptr %l54
  br label %bb15
bb15:
  %t94 = load { i64, [2 x i64] }, ptr %l54
  %t95 = load i64, ptr %l52
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call ptr @__olang_scope_alloc_a(ptr %t96, i64 24, i64 8)
  store { i64, [2 x i64] } %t94, ptr %t97
  call void @__olang_errpay_set(ptr %t97)
  %t100 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t100, ptr %rv
  br label %ret
bb16:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/json:reader", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l58, !tbaa !27
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t105
  %t110 = load i8, ptr %t109, !tbaa !32
  store i8 %t110, ptr %l9, !tbaa !22
  store i64 0, ptr %l10, !tbaa !24
  %t112 = load i8, ptr %l9, !tbaa !22
  %t114 = icmp uge i8 %t112, 48
  br i1 %t114, label %bb17, label %bb18
bb17:
  %t116 = load i8, ptr %l9, !tbaa !22
  %t118 = icmp ule i8 %t116, 57
  store i1 %t118, ptr %l63, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb19
bb19:
  %t120 = load i1, ptr %l63, !tbaa !21
  br i1 %t120, label %bb20, label %bb21
bb20:
  %t121 = load i8, ptr %l9, !tbaa !22
  %t123 = sub i8 %t121, 48
  %t125 = zext i8 %t123 to i64
  store i64 %t125, ptr %l10, !tbaa !24
  br label %bb37
bb21:
  %t127 = load i8, ptr %l9, !tbaa !22
  %t129 = icmp uge i8 %t127, 97
  br i1 %t129, label %bb22, label %bb23
bb22:
  %t131 = load i8, ptr %l9, !tbaa !22
  %t133 = icmp ule i8 %t131, 102
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb24
bb24:
  %t135 = load i1, ptr %l71, !tbaa !21
  br i1 %t135, label %bb25, label %bb26
bb25:
  %t136 = load i8, ptr %l9, !tbaa !22
  %t138 = sub i8 %t136, 97
  %t140 = zext i8 %t138 to i64
  %t142 = add i64 %t140, 10
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb36
bb26:
  %t144 = load i8, ptr %l9, !tbaa !22
  %t146 = icmp uge i8 %t144, 65
  br i1 %t146, label %bb27, label %bb28
bb27:
  %t148 = load i8, ptr %l9, !tbaa !22
  %t150 = icmp ule i8 %t148, 70
  store i1 %t150, ptr %l80, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb29
bb29:
  %t152 = load i1, ptr %l80, !tbaa !21
  br i1 %t152, label %bb30, label %bb31
bb30:
  %t153 = load i8, ptr %l9, !tbaa !22
  %t155 = sub i8 %t153, 65
  %t157 = zext i8 %t155 to i64
  %t159 = add i64 %t157, 10
  store i64 %t159, ptr %l10, !tbaa !24
  br label %bb35
bb31:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l8, !tbaa !24
  %t165 = getelementptr %"std/json:reader", ptr %t161, i32 0, i32 1
  store i64 %t162, ptr %t165, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t166)
  store i64 %t168, ptr %l90
  br label %bb32
bb32:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l92
  br label %bb33
bb33:
  store { i64, [2 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 0
  store i64 2, ptr %t173
  %t174 = load i64, ptr %l90, !tbaa !24
  %t175 = insertvalue { i64, i64 } undef, i64 %t174, 0
  %t176 = load i64, ptr %l92, !tbaa !24
  %t177 = insertvalue { i64, i64 } %t175, i64 %t176, 1
  %t178 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  store { i64, i64 } %t177, ptr %t178
  %t179 = load { i64, [2 x i64] }, ptr %t172
  store { i64, [2 x i64] } %t179, ptr %l93
  %t180 = call ptr @__olang_errpay_push()
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l94, !tbaa !24
  %t182 = load i64, ptr %l94
  %t183 = inttoptr i64 %t182 to ptr
  %t185 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t183, ptr %l93)
  store { i64, [2 x i64] } %t185, ptr %l96
  br label %bb34
bb34:
  %t186 = load { i64, [2 x i64] }, ptr %l96
  %t187 = load i64, ptr %l94
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call ptr @__olang_scope_alloc_a(ptr %t188, i64 24, i64 8)
  store { i64, [2 x i64] } %t186, ptr %t189
  call void @__olang_errpay_set(ptr %t189)
  %t192 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t192, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t193 = load i64, ptr %l2, !tbaa !24
  %t196 = mul i64 %t193, 16
  %t197 = load i64, ptr %l10, !tbaa !24
  %t200 = add i64 %t196, %t197
  store i64 %t200, ptr %l2, !tbaa !24
  br label %bb38
bb38:
  %t202 = load i64, ptr %l7, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l7, !tbaa !24
  br label %bb7
bb39:
  %t207 = load i64, ptr %l2, !tbaa !24
  %t209 = insertvalue { i32, i64 } zeroinitializer, i64 %t207, 1
  store { i32, i64 } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 8
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  %t17 = icmp sge i64 %t15, 0
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l31 = alloca { i64, [2 x i64] }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, [2 x i64] }
  %l54 = alloca i64
  %l56 = alloca { i64, [2 x i64] }
  %l60 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, [2 x i64] }
  %l70 = alloca i64
  %l72 = alloca { i64, [2 x i64] }
  %l75 = alloca ptr
  %rv = alloca i32
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t65 = alloca { i64, [2 x i64] }, align 8
  %t136 = alloca { i64, [2 x i64] }, align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/json:reader", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/json:reader", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp eq i64 %t6, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l9
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l11
  br label %bb5
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 1, ptr %t24
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = insertvalue { i64, i64 } undef, i64 %t25, 0
  %t27 = load i64, ptr %l11, !tbaa !24
  %t28 = insertvalue { i64, i64 } %t26, i64 %t27, 1
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  store { i64, i64 } %t28, ptr %t29
  %t30 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t30, ptr %l12
  %t31 = call ptr @__olang_errpay_push()
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l13, !tbaa !24
  %t33 = load i64, ptr %l13
  %t34 = inttoptr i64 %t33 to ptr
  %t36 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t34, ptr %l12)
  store { i64, [2 x i64] } %t36, ptr %l15
  br label %bb6
bb6:
  %t37 = load { i64, [2 x i64] }, ptr %l15
  %t38 = load i64, ptr %l13
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_scope_alloc_a(ptr %t39, i64 24, i64 8)
  store { i64, [2 x i64] } %t37, ptr %t40
  call void @__olang_errpay_set(ptr %t40)
  store i32 65537, ptr %rv
  br label %ret
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/json:reader", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l19, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"std/json:reader", ptr %t47, i32 0, i32 1
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp ne i8 %t55, 34
  br i1 %t57, label %bb8, label %bb9
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l25
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l27
  br label %bb11
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 0
  store i64 0, ptr %t66
  %t67 = load i64, ptr %l25, !tbaa !24
  %t68 = insertvalue { i64, i64 } undef, i64 %t67, 0
  %t69 = load i64, ptr %l27, !tbaa !24
  %t70 = insertvalue { i64, i64 } %t68, i64 %t69, 1
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 1
  store { i64, i64 } %t70, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t65
  store { i64, [2 x i64] } %t72, ptr %l28
  %t73 = call ptr @__olang_errpay_push()
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l29, !tbaa !24
  %t75 = load i64, ptr %l29
  %t76 = inttoptr i64 %t75 to ptr
  %t78 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t76, ptr %l28)
  store { i64, [2 x i64] } %t78, ptr %l31
  br label %bb12
bb12:
  %t79 = load { i64, [2 x i64] }, ptr %l31
  %t80 = load i64, ptr %l29
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 24, i64 8)
  store { i64, [2 x i64] } %t79, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  store i32 65536, ptr %rv
  br label %ret
bb13:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l34, !tbaa !29
  %t86 = call ptr @__olang_scope_hold(ptr %v0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l36, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = call ptr @__olang_region_make(ptr %v0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l36
  %t94 = inttoptr i64 %t93 to ptr
  %t96 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %t94, ptr %t92)
  %t97 = extractvalue { i32, { i64, ptr } } %t96, 1
  %t98 = extractvalue { i32, { i64, ptr } } %t96, 0
  store i32 %t98, ptr %l40
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb17, label %ok.100, !prof !99
ok.100:
  store { i64, ptr } %t97, ptr %l39
  br label %bb16
bb16:
  %t101 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t101, ptr %l35, !tbaa !27
  br label %bb18
bb17:
  %t102 = load i32, ptr %l40, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  store i32 %t110, ptr %rv
  br label %ret
bb18:
  %t112 = load ptr, ptr %l34, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @std_2fjson_2estd_2fjson_3areader_2epushName(ptr %v0, ptr %v0, ptr %t112, { i64, ptr } %t113)
  br label %bb19
bb19:
  %t114 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t114)
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"std/json:reader", ptr %t116, i32 0, i32 1
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"std/json:reader", ptr %t120, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t128 = icmp eq i64 %t119, %t125
  br i1 %t128, label %bb21, label %bb22
bb21:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l50
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l52
  br label %bb24
bb24:
  store { i64, [2 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [2 x i64] }, ptr %t136, i32 0, i32 0
  store i64 1, ptr %t137
  %t138 = load i64, ptr %l50, !tbaa !24
  %t139 = insertvalue { i64, i64 } undef, i64 %t138, 0
  %t140 = load i64, ptr %l52, !tbaa !24
  %t141 = insertvalue { i64, i64 } %t139, i64 %t140, 1
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t136, i32 0, i32 1
  store { i64, i64 } %t141, ptr %t142
  %t143 = load { i64, [2 x i64] }, ptr %t136
  store { i64, [2 x i64] } %t143, ptr %l53
  %t144 = call ptr @__olang_errpay_push()
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l54, !tbaa !24
  %t146 = load i64, ptr %l54
  %t147 = inttoptr i64 %t146 to ptr
  %t149 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t147, ptr %l53)
  store { i64, [2 x i64] } %t149, ptr %l56
  br label %bb25
bb25:
  %t150 = load { i64, [2 x i64] }, ptr %l56
  %t151 = load i64, ptr %l54
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_scope_alloc_a(ptr %t152, i64 24, i64 8)
  store { i64, [2 x i64] } %t150, ptr %t153
  call void @__olang_errpay_set(ptr %t153)
  store i32 65537, ptr %rv
  br label %ret
bb26:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"std/json:reader", ptr %t156, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l60, !tbaa !27
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"std/json:reader", ptr %t160, i32 0, i32 1
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i8, ptr %t166, i64 %t163
  %t168 = load i8, ptr %t167, !tbaa !32
  %t170 = icmp ne i8 %t168, 58
  br i1 %t170, label %bb27, label %bb28
bb27:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l66
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l68
  br label %bb30
bb30:
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t180 = load i64, ptr %l66, !tbaa !24
  %t181 = insertvalue { i64, i64 } undef, i64 %t180, 0
  %t182 = load i64, ptr %l68, !tbaa !24
  %t183 = insertvalue { i64, i64 } %t181, i64 %t182, 1
  %t184 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  store { i64, i64 } %t183, ptr %t184
  %t185 = load { i64, [2 x i64] }, ptr %t178
  store { i64, [2 x i64] } %t185, ptr %l69
  %t186 = call ptr @__olang_errpay_push()
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l70, !tbaa !24
  %t188 = load i64, ptr %l70
  %t189 = inttoptr i64 %t188 to ptr
  %t191 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t189, ptr %l69)
  store { i64, [2 x i64] } %t191, ptr %l72
  br label %bb31
bb31:
  %t192 = load { i64, [2 x i64] }, ptr %l72
  %t193 = load i64, ptr %l70
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = call ptr @__olang_scope_alloc_a(ptr %t194, i64 24, i64 8)
  store { i64, [2 x i64] } %t192, ptr %t195
  call void @__olang_errpay_set(ptr %t195)
  store i32 65536, ptr %rv
  br label %ret
bb32:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l75, !tbaa !29
  %t199 = load ptr, ptr %l75, !tbaa !29
  %t200 = getelementptr %"std/json:reader", ptr %t199, i32 0, i32 1
  %t201 = load i64, ptr %t200, !tbaa !24
  %t204 = add i64 %t201, 1
  %t206 = load ptr, ptr %l75, !tbaa !29
  %t207 = getelementptr %"std/json:reader", ptr %t206, i32 0, i32 1
  store i64 %t204, ptr %t207, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, double } @std_2fjson_2estd_2fjson_3areader_2enumber(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l10 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca i64
  %l32 = alloca { i64, [2 x i64] }
  %l36 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l48 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, [2 x i64] }
  %l54 = alloca i64
  %l56 = alloca { i64, [2 x i64] }
  %l62 = alloca i1
  %l68 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l90 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l104 = alloca i1
  %l107 = alloca i64
  %l109 = alloca i64
  %l110 = alloca { i64, [2 x i64] }
  %l111 = alloca i64
  %l113 = alloca { i64, [2 x i64] }
  %l119 = alloca i1
  %l121 = alloca ptr
  %l131 = alloca i1
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l155 = alloca i1
  %l157 = alloca { i64, ptr }
  %l162 = alloca i1
  %l164 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l176 = alloca i1
  %l179 = alloca i64
  %l181 = alloca i64
  %l182 = alloca { i64, [2 x i64] }
  %l183 = alloca i64
  %l185 = alloca { i64, [2 x i64] }
  %l191 = alloca i1
  %l193 = alloca ptr
  %l199 = alloca double
  %l205 = alloca double
  %l207 = alloca { i64, ptr }
  %l208 = alloca i64
  %l210 = alloca i64
  %l211 = alloca i64
  %l216 = alloca double
  %l217 = alloca i32
  %l221 = alloca i64
  %l223 = alloca i64
  %l224 = alloca { i64, [2 x i64] }
  %l225 = alloca i64
  %l227 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, double }
  %t51 = alloca { i64, [2 x i64] }, align 8
  %t113 = alloca { i64, [2 x i64] }, align 8
  %t247 = alloca { i64, [2 x i64] }, align 8
  %t422 = alloca { i64, [2 x i64] }, align 8
  %t528 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:reader", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 %t13
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = icmp eq i8 %t18, 45
  store i1 %t20, ptr %l2, !tbaa !21
  %t22 = load i1, ptr %l2, !tbaa !21
  br i1 %t22, label %bb1, label %bb2
bb1:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = add i64 %t27, 1
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = getelementptr %"std/json:reader", ptr %t32, i32 0, i32 1
  store i64 %t30, ptr %t33, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/json:reader", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t34, i64 %t38)
  store i1 %t41, ptr %l23
  br label %bb4
bb4:
  %t42 = load i1, ptr %l23, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l26
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l28
  br label %bb8
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [2 x i64] }, ptr %t51, i32 0, i32 0
  store i64 3, ptr %t52
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = insertvalue { i64, i64 } undef, i64 %t53, 0
  %t55 = load i64, ptr %l28, !tbaa !24
  %t56 = insertvalue { i64, i64 } %t54, i64 %t55, 1
  %t57 = getelementptr { i64, [2 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i64 } %t56, ptr %t57
  %t58 = load { i64, [2 x i64] }, ptr %t51
  store { i64, [2 x i64] } %t58, ptr %l29
  %t59 = call ptr @__olang_errpay_push()
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l30, !tbaa !24
  %t61 = load i64, ptr %l30
  %t62 = inttoptr i64 %t61 to ptr
  %t64 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t62, ptr %l29)
  store { i64, [2 x i64] } %t64, ptr %l32
  br label %bb9
bb9:
  %t65 = load { i64, [2 x i64] }, ptr %l32
  %t66 = load i64, ptr %l30
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = call ptr @__olang_scope_alloc_a(ptr %t67, i64 24, i64 8)
  store { i64, [2 x i64] } %t65, ptr %t68
  call void @__olang_errpay_set(ptr %t68)
  %t71 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t71, ptr %rv
  br label %ret
bb10:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/json:reader", ptr %t72, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/json:reader", ptr %t76, i32 0, i32 1
  %t79 = load i64, ptr %t78, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 %t79
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 48
  br i1 %t86, label %bb11, label %bb12
bb11:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l41, !tbaa !29
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = getelementptr %"std/json:reader", ptr %t89, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t94 = add i64 %t91, 1
  %t96 = load ptr, ptr %l41, !tbaa !29
  %t97 = getelementptr %"std/json:reader", ptr %t96, i32 0, i32 1
  store i64 %t94, ptr %t97, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/json:reader", ptr %t99, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t98, i64 %t102)
  store i1 %t105, ptr %l48
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t106 = load i1, ptr %l48, !tbaa !21
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l50
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l52
  br label %bb17
bb17:
  store { i64, [2 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 0
  store i64 3, ptr %t114
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = insertvalue { i64, i64 } undef, i64 %t115, 0
  %t117 = load i64, ptr %l52, !tbaa !24
  %t118 = insertvalue { i64, i64 } %t116, i64 %t117, 1
  %t119 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 1
  store { i64, i64 } %t118, ptr %t119
  %t120 = load { i64, [2 x i64] }, ptr %t113
  store { i64, [2 x i64] } %t120, ptr %l53
  %t121 = call ptr @__olang_errpay_push()
  %t122 = ptrtoint ptr %t121 to i64
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load i64, ptr %l54
  %t124 = inttoptr i64 %t123 to ptr
  %t126 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t124, ptr %l53)
  store { i64, [2 x i64] } %t126, ptr %l56
  br label %bb18
bb18:
  %t127 = load { i64, [2 x i64] }, ptr %l56
  %t128 = load i64, ptr %l54
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call ptr @__olang_scope_alloc_a(ptr %t129, i64 24, i64 8)
  store { i64, [2 x i64] } %t127, ptr %t130
  call void @__olang_errpay_set(ptr %t130)
  %t133 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t133, ptr %rv
  br label %ret
bb19:
  br label %bb27
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"std/json:reader", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t141 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t134, i64 %t138)
  store i1 %t141, ptr %l62
  br label %bb21
bb21:
  %t142 = load i1, ptr %l62, !tbaa !21
  %t143 = xor i1 %t142, true
  br i1 %t143, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t145 = load i64, ptr %l3, !tbaa !24
  %t148 = mul i64 %t145, 10
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"std/json:reader", ptr %t149, i32 0, i32 0
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  store { i64, ptr } %t152, ptr %l68, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"std/json:reader", ptr %t153, i32 0, i32 1
  %t156 = load i64, ptr %t155, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i8, ptr %t159, i64 %t156
  %t161 = load i8, ptr %t160, !tbaa !32
  %t163 = sub i8 %t161, 48
  %t165 = zext i8 %t163 to i64
  %t168 = add i64 %t148, %t165
  store i64 %t168, ptr %l3, !tbaa !24
  %t170 = load i64, ptr %l4, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l4, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l78, !tbaa !29
  %t176 = load ptr, ptr %l78, !tbaa !29
  %t177 = getelementptr %"std/json:reader", ptr %t176, i32 0, i32 1
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = add i64 %t178, 1
  %t183 = load ptr, ptr %l78, !tbaa !29
  %t184 = getelementptr %"std/json:reader", ptr %t183, i32 0, i32 1
  store i64 %t181, ptr %t184, !tbaa !24
  br label %bb25
bb25:
  br label %bb20
bb26:
  br label %bb27
bb27:
  %t185 = load i64, ptr %l4, !tbaa !24
  %t187 = icmp sle i64 %t185, 15
  store i1 %t187, ptr %l5, !tbaa !21
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"std/json:reader", ptr %t189, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"std/json:reader", ptr %t193, i32 0, i32 0
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t192, %t198
  br i1 %t201, label %bb28, label %bb29
bb28:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"std/json:reader", ptr %t203, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"std/json:reader", ptr %t207, i32 0, i32 1
  %t210 = load i64, ptr %t209, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i8, ptr %t213, i64 %t210
  %t215 = load i8, ptr %t214, !tbaa !32
  %t217 = icmp eq i8 %t215, 46
  store i1 %t217, ptr %l90, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb30
bb30:
  %t219 = load i1, ptr %l90, !tbaa !21
  br i1 %t219, label %bb31, label %bb32
bb31:
  store i1 false, ptr %l5, !tbaa !21
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l97, !tbaa !29
  %t221 = load ptr, ptr %l97, !tbaa !29
  %t222 = getelementptr %"std/json:reader", ptr %t221, i32 0, i32 1
  %t223 = load i64, ptr %t222, !tbaa !24
  %t226 = add i64 %t223, 1
  %t228 = load ptr, ptr %l97, !tbaa !29
  %t229 = getelementptr %"std/json:reader", ptr %t228, i32 0, i32 1
  store i64 %t226, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"std/json:reader", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t230, i64 %t234)
  store i1 %t237, ptr %l104
  br label %bb33
bb32:
  br label %bb47
bb33:
  %t238 = load i1, ptr %l104, !tbaa !21
  %t239 = xor i1 %t238, true
  br i1 %t239, label %bb34, label %bb35
bb34:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t241)
  store i64 %t243, ptr %l107
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l109
  br label %bb37
bb37:
  store { i64, [2 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [2 x i64] }, ptr %t247, i32 0, i32 0
  store i64 3, ptr %t248
  %t249 = load i64, ptr %l107, !tbaa !24
  %t250 = insertvalue { i64, i64 } undef, i64 %t249, 0
  %t251 = load i64, ptr %l109, !tbaa !24
  %t252 = insertvalue { i64, i64 } %t250, i64 %t251, 1
  %t253 = getelementptr { i64, [2 x i64] }, ptr %t247, i32 0, i32 1
  store { i64, i64 } %t252, ptr %t253
  %t254 = load { i64, [2 x i64] }, ptr %t247
  store { i64, [2 x i64] } %t254, ptr %l110
  %t255 = call ptr @__olang_errpay_push()
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l111, !tbaa !24
  %t257 = load i64, ptr %l111
  %t258 = inttoptr i64 %t257 to ptr
  %t260 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t258, ptr %l110)
  store { i64, [2 x i64] } %t260, ptr %l113
  br label %bb38
bb38:
  %t261 = load { i64, [2 x i64] }, ptr %l113
  %t262 = load i64, ptr %l111
  %t263 = inttoptr i64 %t262 to ptr
  %t264 = call ptr @__olang_scope_alloc_a(ptr %t263, i64 24, i64 8)
  store { i64, [2 x i64] } %t261, ptr %t264
  call void @__olang_errpay_set(ptr %t264)
  %t267 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t267, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/json:reader", ptr %t269, i32 0, i32 1
  %t272 = load i64, ptr %t271, !tbaa !24
  %t275 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t268, i64 %t272)
  store i1 %t275, ptr %l119
  br label %bb41
bb41:
  %t276 = load i1, ptr %l119, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l121, !tbaa !29
  %t280 = load ptr, ptr %l121, !tbaa !29
  %t281 = getelementptr %"std/json:reader", ptr %t280, i32 0, i32 1
  %t282 = load i64, ptr %t281, !tbaa !24
  %t285 = add i64 %t282, 1
  %t287 = load ptr, ptr %l121, !tbaa !29
  %t288 = getelementptr %"std/json:reader", ptr %t287, i32 0, i32 1
  store i64 %t285, ptr %t288, !tbaa !24
  br label %bb45
bb45:
  br label %bb40
bb46:
  br label %bb47
bb47:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"std/json:reader", ptr %t289, i32 0, i32 1
  %t292 = load i64, ptr %t291, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"std/json:reader", ptr %t293, i32 0, i32 0
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t301 = icmp slt i64 %t292, %t298
  br i1 %t301, label %bb48, label %bb49
bb48:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/json:reader", ptr %t303, i32 0, i32 0
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  store { i64, ptr } %t306, ptr %l133, !tbaa !27
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/json:reader", ptr %t307, i32 0, i32 1
  %t310 = load i64, ptr %t309, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i8, ptr %t313, i64 %t310
  %t315 = load i8, ptr %t314, !tbaa !32
  %t317 = icmp eq i8 %t315, 101
  br i1 %t317, label %bb50, label %bb51
bb49:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb53
bb50:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb52
bb51:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"std/json:reader", ptr %t319, i32 0, i32 0
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l140, !tbaa !27
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"std/json:reader", ptr %t323, i32 0, i32 1
  %t326 = load i64, ptr %t325, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i8, ptr %t329, i64 %t326
  %t331 = load i8, ptr %t330, !tbaa !32
  %t333 = icmp eq i8 %t331, 69
  store i1 %t333, ptr %l138, !tbaa !21
  br label %bb52
bb52:
  %t335 = load i1, ptr %l138, !tbaa !21
  store i1 %t335, ptr %l131, !tbaa !21
  br label %bb53
bb53:
  %t336 = load i1, ptr %l131, !tbaa !21
  br i1 %t336, label %bb54, label %bb55
bb54:
  store i1 false, ptr %l5, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l145, !tbaa !29
  %t338 = load ptr, ptr %l145, !tbaa !29
  %t339 = getelementptr %"std/json:reader", ptr %t338, i32 0, i32 1
  %t340 = load i64, ptr %t339, !tbaa !24
  %t343 = add i64 %t340, 1
  %t345 = load ptr, ptr %l145, !tbaa !29
  %t346 = getelementptr %"std/json:reader", ptr %t345, i32 0, i32 1
  store i64 %t343, ptr %t346, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"std/json:reader", ptr %t347, i32 0, i32 1
  %t350 = load i64, ptr %t349, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"std/json:reader", ptr %t351, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t359 = icmp slt i64 %t350, %t356
  br i1 %t359, label %bb56, label %bb57
bb55:
  br label %bb79
bb56:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"std/json:reader", ptr %t361, i32 0, i32 0
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  store { i64, ptr } %t364, ptr %l157, !tbaa !27
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"std/json:reader", ptr %t365, i32 0, i32 1
  %t368 = load i64, ptr %t367, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i8, ptr %t371, i64 %t368
  %t373 = load i8, ptr %t372, !tbaa !32
  %t375 = icmp eq i8 %t373, 43
  br i1 %t375, label %bb58, label %bb59
bb57:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb61
bb58:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb60
bb59:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"std/json:reader", ptr %t377, i32 0, i32 0
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !27
  store { i64, ptr } %t380, ptr %l164, !tbaa !27
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"std/json:reader", ptr %t381, i32 0, i32 1
  %t384 = load i64, ptr %t383, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i8, ptr %t387, i64 %t384
  %t389 = load i8, ptr %t388, !tbaa !32
  %t391 = icmp eq i8 %t389, 45
  store i1 %t391, ptr %l162, !tbaa !21
  br label %bb60
bb60:
  %t393 = load i1, ptr %l162, !tbaa !21
  store i1 %t393, ptr %l155, !tbaa !21
  br label %bb61
bb61:
  %t394 = load i1, ptr %l155, !tbaa !21
  br i1 %t394, label %bb62, label %bb63
bb62:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l169, !tbaa !29
  %t396 = load ptr, ptr %l169, !tbaa !29
  %t397 = getelementptr %"std/json:reader", ptr %t396, i32 0, i32 1
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = add i64 %t398, 1
  %t403 = load ptr, ptr %l169, !tbaa !29
  %t404 = getelementptr %"std/json:reader", ptr %t403, i32 0, i32 1
  store i64 %t401, ptr %t404, !tbaa !24
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"std/json:reader", ptr %t406, i32 0, i32 1
  %t409 = load i64, ptr %t408, !tbaa !24
  %t412 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t405, i64 %t409)
  store i1 %t412, ptr %l176
  br label %bb65
bb65:
  %t413 = load i1, ptr %l176, !tbaa !21
  %t414 = xor i1 %t413, true
  br i1 %t414, label %bb66, label %bb67
bb66:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t416)
  store i64 %t418, ptr %l179
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t419)
  store i64 %t421, ptr %l181
  br label %bb69
bb69:
  store { i64, [2 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [2 x i64] }, ptr %t422, i32 0, i32 0
  store i64 3, ptr %t423
  %t424 = load i64, ptr %l179, !tbaa !24
  %t425 = insertvalue { i64, i64 } undef, i64 %t424, 0
  %t426 = load i64, ptr %l181, !tbaa !24
  %t427 = insertvalue { i64, i64 } %t425, i64 %t426, 1
  %t428 = getelementptr { i64, [2 x i64] }, ptr %t422, i32 0, i32 1
  store { i64, i64 } %t427, ptr %t428
  %t429 = load { i64, [2 x i64] }, ptr %t422
  store { i64, [2 x i64] } %t429, ptr %l182
  %t430 = call ptr @__olang_errpay_push()
  %t431 = ptrtoint ptr %t430 to i64
  store i64 %t431, ptr %l183, !tbaa !24
  %t432 = load i64, ptr %l183
  %t433 = inttoptr i64 %t432 to ptr
  %t435 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t433, ptr %l182)
  store { i64, [2 x i64] } %t435, ptr %l185
  br label %bb70
bb70:
  %t436 = load { i64, [2 x i64] }, ptr %l185
  %t437 = load i64, ptr %l183
  %t438 = inttoptr i64 %t437 to ptr
  %t439 = call ptr @__olang_scope_alloc_a(ptr %t438, i64 24, i64 8)
  store { i64, [2 x i64] } %t436, ptr %t439
  call void @__olang_errpay_set(ptr %t439)
  %t442 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t442, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"std/json:reader", ptr %t444, i32 0, i32 1
  %t447 = load i64, ptr %t446, !tbaa !24
  %t450 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t443, i64 %t447)
  store i1 %t450, ptr %l191
  br label %bb73
bb73:
  %t451 = load i1, ptr %l191, !tbaa !21
  %t452 = xor i1 %t451, true
  br i1 %t452, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  br label %bb76
bb76:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l193, !tbaa !29
  %t455 = load ptr, ptr %l193, !tbaa !29
  %t456 = getelementptr %"std/json:reader", ptr %t455, i32 0, i32 1
  %t457 = load i64, ptr %t456, !tbaa !24
  %t460 = add i64 %t457, 1
  %t462 = load ptr, ptr %l193, !tbaa !29
  %t463 = getelementptr %"std/json:reader", ptr %t462, i32 0, i32 1
  store i64 %t460, ptr %t463, !tbaa !24
  br label %bb77
bb77:
  br label %bb72
bb78:
  br label %bb79
bb79:
  %t464 = load i1, ptr %l5, !tbaa !21
  br i1 %t464, label %bb80, label %bb81
bb80:
  %t466 = load i1, ptr %l2, !tbaa !21
  br i1 %t466, label %bb82, label %bb83
bb81:
  br label %bb85
bb82:
  %t468 = load i64, ptr %l3, !tbaa !24
  %t470 = sitofp i64 %t468 to double
  %t472 = fneg double %t470
  store double %t472, ptr %l199, !tbaa !26
  br label %bb84
bb83:
  %t474 = load i64, ptr %l3, !tbaa !24
  %t476 = sitofp i64 %t474 to double
  store double %t476, ptr %l199, !tbaa !26
  br label %bb84
bb84:
  %t478 = load double, ptr %l199, !tbaa !26
  %t479 = insertvalue { i32, double } zeroinitializer, double %t478, 1
  store { i32, double } %t479, ptr %rv
  br label %ret
bb85:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"std/json:reader", ptr %t480, i32 0, i32 0
  %t483 = load { i64, ptr }, ptr %t482, !tbaa !27
  store { i64, ptr } %t483, ptr %l207, !tbaa !27
  %t484 = load i64, ptr %l1, !tbaa !24
  store i64 %t484, ptr %l208, !tbaa !24
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"std/json:reader", ptr %t485, i32 0, i32 1
  %t488 = load i64, ptr %t487, !tbaa !24
  store i64 %t488, ptr %l210, !tbaa !24
  %t489 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t489, 0
  store i64 %t490, ptr %l211, !tbaa !24
  %t491 = load i64, ptr %l208, !tbaa !24
  %t492 = icmp sge i64 %t491, 0
  br i1 %t492, label %bb86, label %bb87
bb86:
  %t494 = load i64, ptr %l208, !tbaa !24
  %t495 = load i64, ptr %l210, !tbaa !24
  %t496 = icmp sle i64 %t494, %t495
  br i1 %t496, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb88:
  %t498 = load i64, ptr %l210, !tbaa !24
  %t499 = load i64, ptr %l211, !tbaa !24
  %t500 = icmp sle i64 %t498, %t499
  br i1 %t500, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb90:
  %t502 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = load i64, ptr %l208, !tbaa !24
  %t505 = load i64, ptr %l210, !tbaa !24
  %t506 = getelementptr i8, ptr %t503, i64 %t504
  %t507 = sub i64 %t505, %t504
  %t508 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t506, 1
  %t511 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %t509)
  %t512 = extractvalue { i32, double } %t511, 1
  %t513 = extractvalue { i32, double } %t511, 0
  store i32 %t513, ptr %l217
  %t514 = icmp ne i32 %t513, 0
  br i1 %t514, label %bb93, label %ok.515, !prof !99
ok.515:
  store double %t512, ptr %l216
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb92:
  %t516 = load double, ptr %l216, !tbaa !26
  store double %t516, ptr %l205, !tbaa !26
  br label %bb98
bb93:
  br label %bb94
bb94:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load i64, ptr %l1, !tbaa !24
  %t521 = getelementptr %"std/json:reader", ptr %t517, i32 0, i32 1
  store i64 %t518, ptr %t521, !tbaa !24
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t522)
  store i64 %t524, ptr %l221
  br label %bb95
bb95:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t525)
  store i64 %t527, ptr %l223
  br label %bb96
bb96:
  store { i64, [2 x i64] } zeroinitializer, ptr %t528
  %t529 = getelementptr { i64, [2 x i64] }, ptr %t528, i32 0, i32 0
  store i64 3, ptr %t529
  %t530 = load i64, ptr %l221, !tbaa !24
  %t531 = insertvalue { i64, i64 } undef, i64 %t530, 0
  %t532 = load i64, ptr %l223, !tbaa !24
  %t533 = insertvalue { i64, i64 } %t531, i64 %t532, 1
  %t534 = getelementptr { i64, [2 x i64] }, ptr %t528, i32 0, i32 1
  store { i64, i64 } %t533, ptr %t534
  %t535 = load { i64, [2 x i64] }, ptr %t528
  store { i64, [2 x i64] } %t535, ptr %l224
  %t536 = call ptr @__olang_errpay_push()
  %t537 = ptrtoint ptr %t536 to i64
  store i64 %t537, ptr %l225, !tbaa !24
  %t538 = load i64, ptr %l225
  %t539 = inttoptr i64 %t538 to ptr
  %t541 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t539, ptr %l224)
  store { i64, [2 x i64] } %t541, ptr %l227
  br label %bb97
bb97:
  %t542 = load { i64, [2 x i64] }, ptr %l227
  %t543 = load i64, ptr %l225
  %t544 = inttoptr i64 %t543 to ptr
  %t545 = call ptr @__olang_scope_alloc_a(ptr %t544, i64 24, i64 8)
  store { i64, [2 x i64] } %t542, ptr %t545
  call void @__olang_errpay_set(ptr %t545)
  %t548 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t548, ptr %rv
  br label %ret
bb98:
  %t549 = load double, ptr %l205, !tbaa !26
  %t552 = insertvalue { i32, double } zeroinitializer, double %t549, 1
  store { i32, double } %t552, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l34 = alloca ptr
  %l35 = alloca i64
  %l39 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i1
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l110 = alloca i64
  %l112 = alloca i64
  %l115 = alloca ptr
  %l119 = alloca ptr
  %rv = alloca i32
  %t16 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2estd_2fjson_2eMaxDepth, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l17
  br label %bb4
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t16, i32 0, i32 0
  store i64 6, ptr %t17
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = insertvalue { i64, i64 } undef, i64 %t18, 0
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = insertvalue { i64, i64 } %t19, i64 %t20, 1
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t16, i32 0, i32 1
  store { i64, i64 } %t21, ptr %t22
  %t23 = load { i64, [2 x i64] }, ptr %t16
  store { i64, [2 x i64] } %t23, ptr %l18
  %t24 = call ptr @__olang_errpay_push()
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l19
  %t27 = inttoptr i64 %t26 to ptr
  %t29 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t27, ptr %l18)
  store { i64, [2 x i64] } %t29, ptr %l21
  br label %bb5
bb5:
  %t30 = load { i64, [2 x i64] }, ptr %l21
  %t31 = load i64, ptr %l19
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_scope_alloc_a(ptr %t32, i64 24, i64 8)
  store { i64, [2 x i64] } %t30, ptr %t33
  call void @__olang_errpay_set(ptr %t33)
  store i32 65542, ptr %rv
  br label %ret
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/json:reader", ptr %t36, i32 0, i32 8
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/json:reader", ptr %t40, i32 0, i32 6
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp eq i64 %t39, %t45
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/json:reader", ptr %t50, i32 0, i32 6
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l2, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 7
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = call ptr @__olang_scope_hold(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l35, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e6
  br i1 %t63, label %bb9, label %bb10
bb8:
  br label %bb37
bb9:
  %t65 = call ptr @__olang_region_make(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"std/json:reader", ptr %t67, i32 0, i32 8
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = mul i64 %t70, 2
  store i64 %t72, ptr %l39, !tbaa !24
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb11, label %bb12
bb11:
  %t76 = load i64, ptr %l39, !tbaa !24
  %t77 = icmp sle i64 %t76, 1152921504606846975
  br i1 %t77, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_85df472c87ddc01c_576e573e0ca51428)
  unreachable
bb13:
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = mul i64 %t79, 8
  %t81 = load i64, ptr %l35
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_scope_alloc_zeroed(ptr %t82, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t86 = load ptr, ptr %l34, !tbaa !29
  %t87 = getelementptr %"std/json:reader", ptr %t86, i32 0, i32 6
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l43, !tbaa !27
  %t90 = load ptr, ptr %l34, !tbaa !29
  %t91 = getelementptr %"std/json:reader", ptr %t90, i32 0, i32 6
  store { i64, ptr } %t85, ptr %t91, !tbaa !27
  %t92 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e6
  br i1 %t92, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_85df472c87ddc01c_576e573e0ca51428)
  unreachable
bb15:
  %t94 = load { i64, ptr }, ptr %l43
  %t95 = extractvalue { i64, ptr } %t94, 1
  call void @__olang_region_release(ptr %t95)
  store { i64, ptr } zeroinitializer, ptr %l43
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l45, !tbaa !29
  %t97 = call ptr @__olang_scope_hold(ptr %v0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l46, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e7
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = call ptr @__olang_region_make(ptr %v0)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"std/json:reader", ptr %t103, i32 0, i32 8
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = mul i64 %t106, 2
  store i64 %t108, ptr %l50, !tbaa !24
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb19, label %bb20
bb19:
  %t112 = load i64, ptr %l50, !tbaa !24
  %t113 = icmp sle i64 %t112, 1152921504606846975
  br i1 %t113, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_99863128c17f1e9_63398a4432912015)
  unreachable
bb21:
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = mul i64 %t115, 8
  %t117 = load i64, ptr %l46
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = call ptr @__olang_scope_alloc_zeroed(ptr %t118, i64 %t116)
  %t120 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l45, !tbaa !29
  %t123 = getelementptr %"std/json:reader", ptr %t122, i32 0, i32 7
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l54, !tbaa !27
  %t126 = load ptr, ptr %l45, !tbaa !29
  %t127 = getelementptr %"std/json:reader", ptr %t126, i32 0, i32 7
  store { i64, ptr } %t121, ptr %t127, !tbaa !27
  %t128 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e7
  br i1 %t128, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_99863128c17f1e9_63398a4432912015)
  unreachable
bb23:
  %t130 = load { i64, ptr }, ptr %l54
  %t131 = extractvalue { i64, ptr } %t130, 1
  call void @__olang_region_release(ptr %t131)
  store { i64, ptr } zeroinitializer, ptr %l54
  br label %bb24
bb24:
  store i64 0, ptr %l4, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"std/json:reader", ptr %t132, i32 0, i32 8
  %t135 = load i64, ptr %t134, !tbaa !24
  store i64 %t135, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t137 = load i64, ptr %l5, !tbaa !24
  %t138 = load i64, ptr %l4, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb25, label %bb26
bb25:
  %t143 = load i64, ptr %l6, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb30
bb27:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t148 = load i64, ptr %l4, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l6, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l64, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb29
bb29:
  %t163 = load i64, ptr %l64, !tbaa !24
  store i64 %t163, ptr %l61, !tbaa !24
  br label %bb30
bb30:
  %t164 = load i64, ptr %l61, !tbaa !24
  store i64 %t164, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t165 = load i64, ptr %l7, !tbaa !24
  %t166 = sub i64 %t165, 1
  store i64 %t166, ptr %l73, !tbaa !24
  %t167 = load i64, ptr %l7, !tbaa !24
  %t168 = icmp slt i64 %t167, 2147483648
  %t169 = load i64, ptr %l8, !tbaa !24
  %t170 = icmp sge i64 %t169, 0
  %t173 = and i1 %t168, %t170
  store i1 %t173, ptr %l76, !tbaa !21
  br label %bb31
bb31:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t175 = load i64, ptr %l7, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t183 = load i64, ptr %l8, !tbaa !24
  %t184 = load i64, ptr %l6, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l9, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"std/json:reader", ptr %t192, i32 0, i32 6
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l87, !tbaa !27
  %t196 = load i64, ptr %l9, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t197, ptr %l89, !tbaa !27
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i64, ptr %t201, i64 %t198
  %t203 = load i64, ptr %t202, !tbaa !34
  %t206 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i64, ptr %t207, i64 %t196
  store i64 %t203, ptr %t208, !tbaa !34
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"std/json:reader", ptr %t209, i32 0, i32 7
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l93, !tbaa !27
  %t213 = load i64, ptr %l9, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t214, ptr %l95, !tbaa !27
  %t215 = load i64, ptr %l9, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i64, ptr %t218, i64 %t215
  %t220 = load i64, ptr %t219, !tbaa !34
  %t223 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i64, ptr %t224, i64 %t213
  store i64 %t220, ptr %t225, !tbaa !34
  br label %bb35
bb35:
  %t226 = load i64, ptr %l8, !tbaa !24
  %t229 = add i64 %t226, 1
  store i64 %t229, ptr %l8, !tbaa !24
  br label %bb31
bb36:
  br label %bb37
bb37:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"std/json:reader", ptr %t231, i32 0, i32 6
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l102, !tbaa !27
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"std/json:reader", ptr %t235, i32 0, i32 8
  %t238 = load i64, ptr %t237, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"std/json:reader", ptr %t239, i32 0, i32 3
  %t242 = load i64, ptr %t241, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i64, ptr %t246, i64 %t238
  store i64 %t242, ptr %t247, !tbaa !34
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"std/json:reader", ptr %t248, i32 0, i32 7
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  store { i64, ptr } %t251, ptr %l108, !tbaa !27
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"std/json:reader", ptr %t252, i32 0, i32 8
  %t255 = load i64, ptr %t254, !tbaa !24
  store i64 %t255, ptr %l110, !tbaa !24
  br i1 %a1, label %bb38, label %bb39
bb38:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"std/json:reader", ptr %t258, i32 0, i32 5
  %t261 = load i64, ptr %t260, !tbaa !24
  store i64 %t261, ptr %l112, !tbaa !24
  br label %bb40
bb39:
  store i64 -1, ptr %l112, !tbaa !24
  br label %bb40
bb40:
  %t263 = load i64, ptr %l112, !tbaa !24
  %t264 = load i64, ptr %l110, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i64, ptr %t266, i64 %t264
  store i64 %t263, ptr %t267, !tbaa !34
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l115, !tbaa !29
  %t269 = load ptr, ptr %l115, !tbaa !29
  %t270 = getelementptr %"std/json:reader", ptr %t269, i32 0, i32 8
  %t271 = load i64, ptr %t270, !tbaa !24
  %t274 = add i64 %t271, 1
  %t276 = load ptr, ptr %l115, !tbaa !29
  %t277 = getelementptr %"std/json:reader", ptr %t276, i32 0, i32 8
  store i64 %t274, ptr %t277, !tbaa !24
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l119, !tbaa !29
  %t279 = load ptr, ptr %l119, !tbaa !29
  %t280 = getelementptr %"std/json:reader", ptr %t279, i32 0, i32 1
  %t281 = load i64, ptr %t280, !tbaa !24
  %t284 = add i64 %t281, 1
  %t286 = load ptr, ptr %l119, !tbaa !29
  %t287 = getelementptr %"std/json:reader", ptr %t286, i32 0, i32 1
  store i64 %t284, ptr %t287, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2epushName(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %t50 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 4
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 4
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = call ptr @__olang_scope_hold(ptr %v0)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e4
  br i1 %t23, label %bb3, label %bb4
bb2:
  br label %bb23
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l18, !tbaa !24
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/json:reader", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = mul i64 %t30, 2
  store i64 %t32, ptr %l22, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = icmp sle i64 %t41, 576460752303423487
  br i1 %t42, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d)
  unreachable
bb7:
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = mul i64 %t44, 16
  %t46 = load i64, ptr %l18
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = call ptr @__olang_held_alloc(ptr %t47, i64 %t45)
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  store i64 0, ptr %t50
  br label %fill.51
fill.51:
  %t54 = load i64, ptr %t50
  %t55 = icmp slt i64 %t54, %t44
  br i1 %t55, label %fillb.52, label %filld.53
fillb.52:
  %t56 = getelementptr { i64, ptr }, ptr %t48, i64 %t54
  store { i64, ptr } %t49, ptr %t56
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %t50
  br label %fill.51
filld.53:
  %t58 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t48, 1
  %t60 = load ptr, ptr %l17, !tbaa !29
  %t61 = getelementptr %"std/json:reader", ptr %t60, i32 0, i32 4
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l28, !tbaa !27
  %t64 = load ptr, ptr %l17, !tbaa !29
  %t65 = getelementptr %"std/json:reader", ptr %t64, i32 0, i32 4
  store { i64, ptr } %t59, ptr %t65, !tbaa !27
  %t66 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e4
  br i1 %t66, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d)
  unreachable
bb9:
  %t68 = load { i64, ptr }, ptr %l28
  %t69 = extractvalue { i64, ptr } %t68, 1
  call void @__olang_region_release(ptr %t69)
  store { i64, ptr } zeroinitializer, ptr %l28
  br label %bb10
bb10:
  store i64 0, ptr %l3, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:reader", ptr %t70, i32 0, i32 5
  %t73 = load i64, ptr %t72, !tbaa !24
  store i64 %t73, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb11, label %bb12
bb11:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb16
bb13:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = sub i64 %t85, %t86
  %t90 = load i64, ptr %l5, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t95 = sub i64 %t93, 1
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = sdiv i64 %t95, %t96
  store i64 %t99, ptr %l38, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb15
bb15:
  %t101 = load i64, ptr %l38, !tbaa !24
  store i64 %t101, ptr %l35, !tbaa !24
  br label %bb16
bb16:
  %t102 = load i64, ptr %l35, !tbaa !24
  store i64 %t102, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = mul i64 %t112, %t113
  %t119 = add i64 %t111, %t116
  store i64 %t119, ptr %l8, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/json:reader", ptr %t121, i32 0, i32 4
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l57, !tbaa !27
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t126, ptr %l59, !tbaa !27
  %t127 = load i64, ptr %l8, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %t130, i64 %t127
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !37
  %t135 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %t136, i64 %t125
  store { i64, ptr } %t132, ptr %t137, !tbaa !37
  br label %bb21
bb21:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb17
bb22:
  br label %bb23
bb23:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"std/json:reader", ptr %t143, i32 0, i32 4
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l66, !tbaa !27
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"std/json:reader", ptr %t147, i32 0, i32 5
  %t150 = load i64, ptr %t149, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %t155, i64 %t150
  store { i64, ptr } %a1, ptr %t156, !tbaa !37
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l70, !tbaa !29
  %t158 = load ptr, ptr %l70, !tbaa !29
  %t159 = getelementptr %"std/json:reader", ptr %t158, i32 0, i32 5
  %t160 = load i64, ptr %t159, !tbaa !24
  %t163 = add i64 %t160, 1
  %t165 = load ptr, ptr %l70, !tbaa !29
  %t166 = getelementptr %"std/json:reader", ptr %t165, i32 0, i32 5
  store i64 %t163, ptr %t166, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i8
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, [2 x i64] }
  %l35 = alloca i64
  %l37 = alloca { i64, [2 x i64] }
  %l41 = alloca { i64, ptr }
  %l48 = alloca i32
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l68 = alloca i32
  %l77 = alloca i1
  %l79 = alloca { i64, ptr }
  %l86 = alloca i32
  %l90 = alloca i32
  %l103 = alloca i64
  %l105 = alloca i64
  %l106 = alloca { i64, [2 x i64] }
  %l107 = alloca i64
  %l109 = alloca { i64, [2 x i64] }
  %l120 = alloca i64
  %l122 = alloca i64
  %l123 = alloca { i64, [2 x i64] }
  %l124 = alloca i64
  %l126 = alloca { i64, [2 x i64] }
  %l130 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l141 = alloca i1
  %l143 = alloca i32
  %l145 = alloca i8
  %l147 = alloca i1
  %l148 = alloca i8
  %l152 = alloca i64
  %l154 = alloca i64
  %l155 = alloca { i64, [2 x i64] }
  %l156 = alloca i64
  %l158 = alloca { i64, [2 x i64] }
  %rv = alloca i32
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t274 = alloca { i64, [2 x i64] }, align 8
  %t316 = alloca { i64, [2 x i64] }, align 8
  %t400 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sge i64 %t6, 3
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:reader", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 0
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp eq i8 %t17, -17
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/json:reader", ptr %t22, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l14, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 1
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, -69
  store i1 %t31, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l12, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l19, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 2
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, -65
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/json:reader", ptr %t46, i32 0, i32 1
  store i64 3, ptr %t48, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t49)
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp eq i64 %t54, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l31
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l33
  br label %bb18
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 1, ptr %t72
  %t73 = load i64, ptr %l31, !tbaa !24
  %t74 = insertvalue { i64, i64 } undef, i64 %t73, 0
  %t75 = load i64, ptr %l33, !tbaa !24
  %t76 = insertvalue { i64, i64 } %t74, i64 %t75, 1
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { i64, i64 } %t76, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t78, ptr %l34
  %t79 = call ptr @__olang_errpay_push()
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l35, !tbaa !24
  %t81 = load i64, ptr %l35
  %t82 = inttoptr i64 %t81 to ptr
  %t84 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t82, ptr %l34)
  store { i64, [2 x i64] } %t84, ptr %l37
  br label %bb19
bb19:
  %t85 = load { i64, [2 x i64] }, ptr %l37
  %t86 = load i64, ptr %l35
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call ptr @__olang_scope_alloc_a(ptr %t87, i64 24, i64 8)
  store { i64, [2 x i64] } %t85, ptr %t88
  call void @__olang_errpay_set(ptr %t88)
  store i32 65537, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/json:reader", ptr %t91, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l41, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"std/json:reader", ptr %t95, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  store i8 %t103, ptr %l1, !tbaa !22
  %t105 = load i8, ptr %l1, !tbaa !22
  %t107 = icmp eq i8 %t105, 91
  br i1 %t107, label %bb21, label %bb22
bb21:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %t109, i1 false)
  store i32 %t111, ptr %l48
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb24, label %ok.113, !prof !99
ok.113:
  br label %bb23
bb22:
  %t114 = load i8, ptr %l1, !tbaa !22
  %t116 = icmp eq i8 %t114, 123
  br i1 %t116, label %bb34, label %bb35
bb23:
  br label %bb25
bb24:
  %t118 = load i32, ptr %l48, !tbaa !23
  %t119 = lshr i32 %t118, 16
  %t120 = and i32 %t118, 65535
  %t121 = icmp eq i32 %t119, 1
  %t122 = select i1 %t121, i32 1, i32 0
  %t123 = icmp eq i32 %t118, 0
  %t124 = shl i32 %t122, 16
  %t125 = or i32 %t124, %t120
  %t126 = select i1 %t123, i32 0, i32 %t125
  store i32 %t126, ptr %rv
  br label %ret
bb25:
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t128)
  br label %bb26
bb26:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/json:reader", ptr %t130, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"std/json:reader", ptr %t134, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = icmp slt i64 %t133, %t139
  br i1 %t142, label %bb27, label %bb28
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"std/json:reader", ptr %t144, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l59, !tbaa !27
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/json:reader", ptr %t148, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = icmp eq i8 %t156, 93
  store i1 %t158, ptr %l57, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t160 = load i1, ptr %l57, !tbaa !21
  br i1 %t160, label %bb30, label %bb31
bb30:
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t161)
  br label %bb32
bb31:
  br label %bb96
bb32:
  br label %bb33
bb33:
  br label %bb54
bb34:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = call i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %t163, i1 true)
  store i32 %t165, ptr %l68
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb37, label %ok.167, !prof !99
ok.167:
  br label %bb36
bb35:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i8, ptr %l1, !tbaa !22
  %t172 = call i32 @std_2fjson_2estd_2fjson_3areader_2escalar(ptr %v0, ptr %t168, i8 %t169)
  store i32 %t172, ptr %l90
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb51, label %ok.174, !prof !99
ok.174:
  br label %bb50
bb36:
  br label %bb38
bb37:
  %t175 = load i32, ptr %l68, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  store i32 %t183, ptr %rv
  br label %ret
bb38:
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t185)
  br label %bb39
bb39:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"std/json:reader", ptr %t187, i32 0, i32 1
  %t190 = load i64, ptr %t189, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"std/json:reader", ptr %t191, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp slt i64 %t190, %t196
  br i1 %t199, label %bb40, label %bb41
bb40:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/json:reader", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l79, !tbaa !27
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"std/json:reader", ptr %t205, i32 0, i32 1
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t208
  %t213 = load i8, ptr %t212, !tbaa !32
  %t215 = icmp eq i8 %t213, 125
  store i1 %t215, ptr %l77, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb42
bb42:
  %t217 = load i1, ptr %l77, !tbaa !21
  br i1 %t217, label %bb43, label %bb44
bb43:
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t218)
  br label %bb45
bb44:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = call i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %t220)
  store i32 %t222, ptr %l86
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb47, label %ok.224, !prof !99
ok.224:
  br label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb48
bb47:
  %t225 = load i32, ptr %l86, !tbaa !23
  %t226 = lshr i32 %t225, 16
  %t227 = and i32 %t225, 65535
  %t228 = icmp eq i32 %t226, 1
  %t229 = select i1 %t228, i32 1, i32 0
  %t230 = icmp eq i32 %t225, 0
  %t231 = shl i32 %t229, 16
  %t232 = or i32 %t231, %t227
  %t233 = select i1 %t230, i32 0, i32 %t232
  store i32 %t233, ptr %rv
  br label %ret
bb48:
  br label %bb96
bb49:
  br label %bb53
bb50:
  br label %bb52
bb51:
  %t235 = load i32, ptr %l90, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 1, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  store i32 %t243, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"std/json:reader", ptr %t245, i32 0, i32 8
  %t248 = load i64, ptr %t247, !tbaa !24
  %t250 = icmp eq i64 %t248, 0
  br i1 %t250, label %bb56, label %bb57
bb56:
  %t252 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t252)
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"std/json:reader", ptr %t254, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"std/json:reader", ptr %t258, i32 0, i32 0
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t266 = icmp slt i64 %t257, %t263
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t268)
  store i64 %t270, ptr %l103
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l105
  br label %bb62
bb62:
  store { i64, [2 x i64] } zeroinitializer, ptr %t274
  %t275 = getelementptr { i64, [2 x i64] }, ptr %t274, i32 0, i32 0
  store i64 5, ptr %t275
  %t276 = load i64, ptr %l103, !tbaa !24
  %t277 = insertvalue { i64, i64 } undef, i64 %t276, 0
  %t278 = load i64, ptr %l105, !tbaa !24
  %t279 = insertvalue { i64, i64 } %t277, i64 %t278, 1
  %t280 = getelementptr { i64, [2 x i64] }, ptr %t274, i32 0, i32 1
  store { i64, i64 } %t279, ptr %t280
  %t281 = load { i64, [2 x i64] }, ptr %t274
  store { i64, [2 x i64] } %t281, ptr %l106
  %t282 = call ptr @__olang_errpay_push()
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l107, !tbaa !24
  %t284 = load i64, ptr %l107
  %t285 = inttoptr i64 %t284 to ptr
  %t287 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t285, ptr %l106)
  store { i64, [2 x i64] } %t287, ptr %l109
  br label %bb63
bb63:
  %t288 = load { i64, [2 x i64] }, ptr %l109
  %t289 = load i64, ptr %l107
  %t290 = inttoptr i64 %t289 to ptr
  %t291 = call ptr @__olang_scope_alloc_a(ptr %t290, i64 24, i64 8)
  store { i64, [2 x i64] } %t288, ptr %t291
  call void @__olang_errpay_set(ptr %t291)
  store i32 65541, ptr %rv
  br label %ret
bb64:
  store i32 0, ptr %rv
  br label %ret
bb65:
  %t294 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t294)
  br label %bb66
bb66:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"std/json:reader", ptr %t296, i32 0, i32 1
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"std/json:reader", ptr %t300, i32 0, i32 0
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t308 = icmp eq i64 %t299, %t305
  br i1 %t308, label %bb67, label %bb68
bb67:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t310)
  store i64 %t312, ptr %l120
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t313)
  store i64 %t315, ptr %l122
  br label %bb70
bb70:
  store { i64, [2 x i64] } zeroinitializer, ptr %t316
  %t317 = getelementptr { i64, [2 x i64] }, ptr %t316, i32 0, i32 0
  store i64 1, ptr %t317
  %t318 = load i64, ptr %l120, !tbaa !24
  %t319 = insertvalue { i64, i64 } undef, i64 %t318, 0
  %t320 = load i64, ptr %l122, !tbaa !24
  %t321 = insertvalue { i64, i64 } %t319, i64 %t320, 1
  %t322 = getelementptr { i64, [2 x i64] }, ptr %t316, i32 0, i32 1
  store { i64, i64 } %t321, ptr %t322
  %t323 = load { i64, [2 x i64] }, ptr %t316
  store { i64, [2 x i64] } %t323, ptr %l123
  %t324 = call ptr @__olang_errpay_push()
  %t325 = ptrtoint ptr %t324 to i64
  store i64 %t325, ptr %l124, !tbaa !24
  %t326 = load i64, ptr %l124
  %t327 = inttoptr i64 %t326 to ptr
  %t329 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t327, ptr %l123)
  store { i64, [2 x i64] } %t329, ptr %l126
  br label %bb71
bb71:
  %t330 = load { i64, [2 x i64] }, ptr %l126
  %t331 = load i64, ptr %l124
  %t332 = inttoptr i64 %t331 to ptr
  %t333 = call ptr @__olang_scope_alloc_a(ptr %t332, i64 24, i64 8)
  store { i64, [2 x i64] } %t330, ptr %t333
  call void @__olang_errpay_set(ptr %t333)
  store i32 65537, ptr %rv
  br label %ret
bb72:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"std/json:reader", ptr %t336, i32 0, i32 0
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l130, !tbaa !27
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"std/json:reader", ptr %t340, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i8, ptr %t346, i64 %t343
  %t348 = load i8, ptr %t347, !tbaa !32
  store i8 %t348, ptr %l2, !tbaa !22
  %t350 = load i8, ptr %l2, !tbaa !22
  %t352 = icmp eq i8 %t350, 44
  br i1 %t352, label %bb73, label %bb74
bb73:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l136, !tbaa !29
  %t355 = load ptr, ptr %l136, !tbaa !29
  %t356 = getelementptr %"std/json:reader", ptr %t355, i32 0, i32 1
  %t357 = load i64, ptr %t356, !tbaa !24
  %t360 = add i64 %t357, 1
  %t362 = load ptr, ptr %l136, !tbaa !29
  %t363 = getelementptr %"std/json:reader", ptr %t362, i32 0, i32 1
  store i64 %t360, ptr %t363, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %t364)
  store i1 %t366, ptr %l141
  br label %bb75
bb74:
  br label %bb82
bb75:
  %t367 = load i1, ptr %l141, !tbaa !21
  br i1 %t367, label %bb76, label %bb77
bb76:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = call i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %t368)
  store i32 %t370, ptr %l143
  %t371 = icmp ne i32 %t370, 0
  br i1 %t371, label %bb79, label %ok.372, !prof !99
ok.372:
  br label %bb78
bb77:
  br label %bb81
bb78:
  br label %bb80
bb79:
  %t373 = load i32, ptr %l143, !tbaa !23
  %t374 = lshr i32 %t373, 16
  %t375 = and i32 %t373, 65535
  %t376 = icmp eq i32 %t374, 1
  %t377 = select i1 %t376, i32 1, i32 0
  %t378 = icmp eq i32 %t373, 0
  %t379 = shl i32 %t377, 16
  %t380 = or i32 %t379, %t375
  %t381 = select i1 %t378, i32 0, i32 %t380
  store i32 %t381, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  br label %bb95
bb82:
  %t383 = load i8, ptr %l2, !tbaa !22
  store i8 %t383, ptr %l145, !tbaa !22
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = call i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %t384)
  store i1 %t386, ptr %l147
  br label %bb83
bb83:
  %t387 = load i1, ptr %l147, !tbaa !21
  br i1 %t387, label %bb84, label %bb85
bb84:
  store i8 125, ptr %l148, !tbaa !22
  br label %bb86
bb85:
  store i8 93, ptr %l148, !tbaa !22
  br label %bb86
bb86:
  %t388 = load i8, ptr %l145, !tbaa !22
  %t389 = load i8, ptr %l148, !tbaa !22
  %t390 = icmp eq i8 %t388, %t389
  br i1 %t390, label %bb87, label %bb88
bb87:
  %t392 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t392)
  br label %bb89
bb88:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t394)
  store i64 %t396, ptr %l152
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t397)
  store i64 %t399, ptr %l154
  br label %bb91
bb91:
  store { i64, [2 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [2 x i64] }, ptr %t400, i32 0, i32 0
  store i64 0, ptr %t401
  %t402 = load i64, ptr %l152, !tbaa !24
  %t403 = insertvalue { i64, i64 } undef, i64 %t402, 0
  %t404 = load i64, ptr %l154, !tbaa !24
  %t405 = insertvalue { i64, i64 } %t403, i64 %t404, 1
  %t406 = getelementptr { i64, [2 x i64] }, ptr %t400, i32 0, i32 1
  store { i64, i64 } %t405, ptr %t406
  %t407 = load { i64, [2 x i64] }, ptr %t400
  store { i64, [2 x i64] } %t407, ptr %l155
  %t408 = call ptr @__olang_errpay_push()
  %t409 = ptrtoint ptr %t408 to i64
  store i64 %t409, ptr %l156, !tbaa !24
  %t410 = load i64, ptr %l156
  %t411 = inttoptr i64 %t410 to ptr
  %t413 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t411, ptr %l155)
  store { i64, [2 x i64] } %t413, ptr %l158
  br label %bb92
bb92:
  %t414 = load { i64, [2 x i64] }, ptr %l158
  %t415 = load i64, ptr %l156
  %t416 = inttoptr i64 %t415 to ptr
  %t417 = call ptr @__olang_scope_alloc_a(ptr %t416, i64 24, i64 8)
  store { i64, [2 x i64] } %t414, ptr %t417
  call void @__olang_errpay_set(ptr %t417)
  store i32 65536, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  br label %bb55
bb95:
  br label %bb96
bb96:
  br label %bb13
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2escalar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i1
  %l21 = alloca double
  %l23 = alloca double
  %l24 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i32
  %l42 = alloca i32
  %l50 = alloca i32
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, [2 x i64] }
  %l60 = alloca i64
  %l62 = alloca { i64, [2 x i64] }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t101 = alloca { i64, [2 x i64] }, align 8
  %t130 = alloca { i64, [2 x i64] }, align 8
  %t158 = alloca { i64, [2 x i64] }, align 8
  %t168 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 34
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l9
  br label %bb3
bb2:
  %t13 = load i8, ptr %l1, !tbaa !22
  %t15 = icmp eq i8 %t13, 45
  br i1 %t15, label %bb7, label %bb8
bb3:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %l7, !tbaa !27
  br label %bb5
bb4:
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  store i32 %t26, ptr %rv
  br label %ret
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 5, ptr %t29
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t35
  %t36 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t36, ptr %t35)
  br label %bb6
bb6:
  br label %bb43
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t38 = load i8, ptr %l1, !tbaa !22
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l18
  br label %bb9
bb9:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l16, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/json:reader", ptr %t43, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l2, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, double } @std_2fjson_2estd_2fjson_3areader_2enumber(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, double } %t50, 1
  %t52 = extractvalue { i32, double } %t50, 0
  store i32 %t52, ptr %l24
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54, !prof !99
ok.54:
  store double %t51, ptr %l23
  br label %bb13
bb12:
  %t55 = load i8, ptr %l1, !tbaa !22
  %t57 = icmp eq i8 %t55, 116
  br i1 %t57, label %bb18, label %bb19
bb13:
  %t59 = load double, ptr %l23, !tbaa !26
  store double %t59, ptr %l21, !tbaa !26
  br label %bb15
bb14:
  %t60 = load i32, ptr %l24, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %rv
  br label %ret
bb15:
  %t70 = load double, ptr %l21, !tbaa !26
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l26, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l2, !tbaa !24
  %t78 = call ptr @std_2fjson_2estd_2fjson_3areader_2eexact(ptr %v0, ptr %v0, ptr %t72, i64 %t73, double %t70)
  store ptr %t78, ptr %l30
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l26, !tbaa !29
  %t80 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t79, ptr %t80)
  br label %bb17
bb17:
  br label %bb42
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t83, ptr %l34
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb21, label %ok.85, !prof !99
ok.85:
  br label %bb20
bb19:
  %t86 = load i8, ptr %l1, !tbaa !22
  %t88 = icmp eq i8 %t86, 102
  br i1 %t88, label %bb24, label %bb25
bb20:
  br label %bb22
bb21:
  %t90 = load i32, ptr %l34, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  call void @__olang_scope_close(ptr %s5)
  store i32 %t98, ptr %rv
  br label %ret
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 1, ptr %t102
  %t103 = insertvalue { i1 } undef, i1 true, 0
  %t104 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 1
  store { i1 } %t103, ptr %t104
  %t105 = load { i64, [2 x i64] }, ptr %t101
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t105, ptr %t107
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t100, ptr %t107)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s7, ptr %t110, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t112, ptr %l42
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb27, label %ok.114, !prof !99
ok.114:
  br label %bb26
bb25:
  %t115 = load i8, ptr %l1, !tbaa !22
  %t117 = icmp eq i8 %t115, 110
  br i1 %t117, label %bb30, label %bb31
bb26:
  br label %bb28
bb27:
  %t119 = load i32, ptr %l42, !tbaa !23
  %t120 = lshr i32 %t119, 16
  %t121 = and i32 %t119, 65535
  %t122 = icmp eq i32 %t120, 1
  %t123 = select i1 %t122, i32 1, i32 0
  %t124 = icmp eq i32 %t119, 0
  %t125 = shl i32 %t123, 16
  %t126 = or i32 %t125, %t121
  %t127 = select i1 %t124, i32 0, i32 %t126
  call void @__olang_scope_close(ptr %s7)
  store i32 %t127, ptr %rv
  br label %ret
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [2 x i64] }, ptr %t130, i32 0, i32 0
  store i64 1, ptr %t131
  %t132 = insertvalue { i1 } undef, i1 false, 0
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t130, i32 0, i32 1
  store { i1 } %t132, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t130
  %t136 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t134, ptr %t136
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t129, ptr %t136)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s9, ptr %t139, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t141, ptr %l50
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb33, label %ok.143, !prof !99
ok.143:
  br label %bb32
bb31:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l56
  br label %bb36
bb32:
  br label %bb34
bb33:
  %t147 = load i32, ptr %l50, !tbaa !23
  %t148 = lshr i32 %t147, 16
  %t149 = and i32 %t147, 65535
  %t150 = icmp eq i32 %t148, 1
  %t151 = select i1 %t150, i32 1, i32 0
  %t152 = icmp eq i32 %t147, 0
  %t153 = shl i32 %t151, 16
  %t154 = or i32 %t153, %t149
  %t155 = select i1 %t152, i32 0, i32 %t154
  call void @__olang_scope_close(ptr %s9)
  store i32 %t155, ptr %rv
  br label %ret
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [2 x i64] }, ptr %t158, i32 0, i32 0
  store i64 0, ptr %t159
  %t160 = load { i64, [2 x i64] }, ptr %t158
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t160, ptr %t162
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t157, ptr %t162)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb39
bb36:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t165)
  store i64 %t167, ptr %l58
  br label %bb37
bb37:
  store { i64, [2 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [2 x i64] }, ptr %t168, i32 0, i32 0
  store i64 0, ptr %t169
  %t170 = load i64, ptr %l56, !tbaa !24
  %t171 = insertvalue { i64, i64 } undef, i64 %t170, 0
  %t172 = load i64, ptr %l58, !tbaa !24
  %t173 = insertvalue { i64, i64 } %t171, i64 %t172, 1
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t168, i32 0, i32 1
  store { i64, i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t168
  store { i64, [2 x i64] } %t175, ptr %l59
  %t176 = call ptr @__olang_errpay_push()
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l60, !tbaa !24
  %t178 = load i64, ptr %l60
  %t179 = inttoptr i64 %t178 to ptr
  %t181 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t179, ptr %l59)
  store { i64, [2 x i64] } %t181, ptr %l62
  br label %bb38
bb38:
  %t182 = load { i64, [2 x i64] }, ptr %l62
  %t183 = load i64, ptr %l60
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_scope_alloc_a(ptr %t184, i64 24, i64 8)
  store { i64, [2 x i64] } %t182, ptr %t185
  call void @__olang_errpay_set(ptr %t185)
  store i32 65536, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i8
  %l12 = alloca ptr
  %l16 = alloca i64
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l58 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, [2 x i64] }
  %l62 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %l68 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i32
  %l89 = alloca i64
  %l91 = alloca i64
  %l92 = alloca { i64, [2 x i64] }
  %l93 = alloca i64
  %l95 = alloca { i64, [2 x i64] }
  %l103 = alloca ptr
  %l107 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %l116 = alloca ptr
  %l123 = alloca i64
  %l134 = alloca { i64, ptr }
  %l140 = alloca i64
  %l141 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i32
  %l154 = alloca ptr
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t131 = alloca { i64, [2 x i64] }, align 8
  %t220 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/json:reader", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @std_2fjson_2eplainEnd(ptr %v0, { i64, ptr } %t12, i64 %t13)
  store i64 %t16, ptr %l16
  br label %bb1
bb1:
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"std/json:reader", ptr %t18, i32 0, i32 1
  store i64 %t17, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/json:reader", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp slt i64 %t23, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/json:reader", ptr %t38, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t48 = icmp eq i8 %t46, 34
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb5, label %bb6
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = add i64 %t54, 1
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = getelementptr %"std/json:reader", ptr %t59, i32 0, i32 1
  store i64 %t57, ptr %t60, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"std/json:reader", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l35, !tbaa !27
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l36, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:reader", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = sub i64 %t69, 1
  store i64 %t71, ptr %l39, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l40, !tbaa !24
  %t74 = load i64, ptr %l36, !tbaa !24
  %t75 = icmp sge i64 %t74, 0
  br i1 %t75, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = icmp sle i64 %t77, %t78
  br i1 %t79, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb9:
  %t81 = load i64, ptr %l39, !tbaa !24
  %t82 = load i64, ptr %l40, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb11:
  %t85 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l36, !tbaa !24
  %t88 = load i64, ptr %l39, !tbaa !24
  %t89 = getelementptr i8, ptr %t86, i64 %t87
  %t90 = sub i64 %t88, %t87
  %t91 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = extractvalue { i64, ptr } %t92, 0
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t94, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t101 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t98, 1
  store { i32, { i64, ptr } } %t101, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb13:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"std/json:reader", ptr %t102, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = sub i64 %t105, %t106
  store i64 %t109, ptr %l2, !tbaa !24
  br label %bb14
bb14:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"std/json:reader", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/json:reader", ptr %t115, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t123 = icmp eq i64 %t114, %t120
  br i1 %t123, label %bb15, label %bb16
bb15:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t125)
  store i64 %t127, ptr %l58
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t128)
  store i64 %t130, ptr %l60
  br label %bb18
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 0
  store i64 1, ptr %t132
  %t133 = load i64, ptr %l58, !tbaa !24
  %t134 = insertvalue { i64, i64 } undef, i64 %t133, 0
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = insertvalue { i64, i64 } %t134, i64 %t135, 1
  %t137 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 1
  store { i64, i64 } %t136, ptr %t137
  %t138 = load { i64, [2 x i64] }, ptr %t131
  store { i64, [2 x i64] } %t138, ptr %l61
  %t139 = call ptr @__olang_errpay_push()
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l62, !tbaa !24
  %t141 = load i64, ptr %l62
  %t142 = inttoptr i64 %t141 to ptr
  %t144 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t142, ptr %l61)
  store { i64, [2 x i64] } %t144, ptr %l64
  br label %bb19
bb19:
  %t145 = load { i64, [2 x i64] }, ptr %l64
  %t146 = load i64, ptr %l62
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = call ptr @__olang_scope_alloc_a(ptr %t147, i64 24, i64 8)
  store { i64, [2 x i64] } %t145, ptr %t148
  call void @__olang_errpay_set(ptr %t148)
  %t151 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t151, ptr %rv
  br label %ret
bb20:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"std/json:reader", ptr %t152, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l68, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"std/json:reader", ptr %t156, i32 0, i32 1
  %t159 = load i64, ptr %t158, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t159
  %t164 = load i8, ptr %t163, !tbaa !32
  store i8 %t164, ptr %l3, !tbaa !22
  %t166 = load i8, ptr %l3, !tbaa !22
  %t168 = icmp eq i8 %t166, 34
  br i1 %t168, label %bb21, label %bb22
bb21:
  br label %bb45
bb22:
  br label %bb23
bb23:
  %t170 = load i8, ptr %l3, !tbaa !22
  %t172 = icmp eq i8 %t170, 92
  br i1 %t172, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t174 = load i64, ptr %l2, !tbaa !24
  store i64 %t174, ptr %l76, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l78, !tbaa !29
  %t176 = load i64, ptr %l1, !tbaa !24
  store i64 %t176, ptr %l79, !tbaa !24
  %t177 = icmp sge i64 0, 0
  br i1 %t177, label %bb26, label %bb27
bb25:
  %t179 = load i8, ptr %l3, !tbaa !22
  %t181 = icmp ult i8 %t179, 32
  br i1 %t181, label %bb31, label %bb32
bb26:
  %t183 = mul i64 0, 1
  %t184 = insertvalue { i64, ptr } undef, i64 0, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t186 = load ptr, ptr %l78, !tbaa !29
  %t187 = load i64, ptr %l79, !tbaa !24
  %t189 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %s6, ptr %t186, i64 %t187, { i64, ptr } %t185)
  %t190 = extractvalue { i32, i64 } %t189, 1
  %t191 = extractvalue { i32, i64 } %t189, 0
  store i32 %t191, ptr %l83
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb29, label %ok.193, !prof !99
ok.193:
  store i64 %t190, ptr %l82
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c68c402cf703814a_d8009281770a12f6)
  unreachable
bb28:
  %t194 = load i64, ptr %l82, !tbaa !24
  store i64 %t194, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  %t195 = load i32, ptr %l83, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  call void @__olang_scope_close(ptr %s6)
  %t205 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t203, 0
  store { i32, { i64, ptr } } %t205, ptr %rv
  br label %ret
bb30:
  %t206 = load i64, ptr %l76, !tbaa !24
  %t207 = load i64, ptr %l77, !tbaa !24
  %t208 = add i64 %t206, %t207
  store i64 %t208, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb31:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l89
  br label %bb33
bb32:
  %t213 = load i8, ptr %l3, !tbaa !22
  %t215 = icmp ult i8 %t213, -128
  br i1 %t215, label %bb36, label %bb37
bb33:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t217)
  store i64 %t219, ptr %l91
  br label %bb34
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [2 x i64] }, ptr %t220, i32 0, i32 0
  store i64 0, ptr %t221
  %t222 = load i64, ptr %l89, !tbaa !24
  %t223 = insertvalue { i64, i64 } undef, i64 %t222, 0
  %t224 = load i64, ptr %l91, !tbaa !24
  %t225 = insertvalue { i64, i64 } %t223, i64 %t224, 1
  %t226 = getelementptr { i64, [2 x i64] }, ptr %t220, i32 0, i32 1
  store { i64, i64 } %t225, ptr %t226
  %t227 = load { i64, [2 x i64] }, ptr %t220
  store { i64, [2 x i64] } %t227, ptr %l92
  %t228 = call ptr @__olang_errpay_push()
  %t229 = ptrtoint ptr %t228 to i64
  store i64 %t229, ptr %l93, !tbaa !24
  %t230 = load i64, ptr %l93
  %t231 = inttoptr i64 %t230 to ptr
  %t233 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t231, ptr %l92)
  store { i64, [2 x i64] } %t233, ptr %l95
  br label %bb35
bb35:
  %t234 = load { i64, [2 x i64] }, ptr %l95
  %t235 = load i64, ptr %l93
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = call ptr @__olang_scope_alloc_a(ptr %t236, i64 24, i64 8)
  store { i64, [2 x i64] } %t234, ptr %t237
  call void @__olang_errpay_set(ptr %t237)
  %t240 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t240, ptr %rv
  br label %ret
bb36:
  %t241 = load i64, ptr %l2, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l2, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l103, !tbaa !29
  %t247 = load ptr, ptr %l103, !tbaa !29
  %t248 = getelementptr %"std/json:reader", ptr %t247, i32 0, i32 1
  %t249 = load i64, ptr %t248, !tbaa !24
  %t252 = add i64 %t249, 1
  %t254 = load ptr, ptr %l103, !tbaa !29
  %t255 = getelementptr %"std/json:reader", ptr %t254, i32 0, i32 1
  store i64 %t252, ptr %t255, !tbaa !24
  br label %bb41
bb37:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eutf8(ptr %v0, ptr %t256)
  %t259 = extractvalue { i32, i64 } %t258, 1
  %t260 = extractvalue { i32, i64 } %t258, 0
  store i32 %t260, ptr %l110
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb39, label %ok.262, !prof !99
ok.262:
  store i64 %t259, ptr %l109
  br label %bb38
bb38:
  %t263 = load i64, ptr %l109, !tbaa !24
  store i64 %t263, ptr %l107, !tbaa !24
  br label %bb40
bb39:
  %t264 = load i32, ptr %l110, !tbaa !23
  %t265 = lshr i32 %t264, 16
  %t266 = and i32 %t264, 65535
  %t267 = icmp eq i32 %t265, 1
  %t268 = select i1 %t267, i32 1, i32 0
  %t269 = icmp eq i32 %t264, 0
  %t270 = shl i32 %t268, 16
  %t271 = or i32 %t270, %t266
  %t272 = select i1 %t269, i32 0, i32 %t271
  %t274 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t272, 0
  store { i32, { i64, ptr } } %t274, ptr %rv
  br label %ret
bb40:
  %t275 = load i64, ptr %l107, !tbaa !24
  store i64 %t275, ptr %l4, !tbaa !24
  %t276 = load i64, ptr %l2, !tbaa !24
  %t278 = load i64, ptr %l4, !tbaa !24
  %t281 = add i64 %t276, %t278
  store i64 %t281, ptr %l2, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l116, !tbaa !29
  %t284 = load ptr, ptr %l116, !tbaa !29
  %t285 = getelementptr %"std/json:reader", ptr %t284, i32 0, i32 1
  %t286 = load i64, ptr %t285, !tbaa !24
  %t288 = load i64, ptr %l4, !tbaa !24
  %t291 = add i64 %t286, %t288
  %t293 = load ptr, ptr %l116, !tbaa !29
  %t294 = getelementptr %"std/json:reader", ptr %t293, i32 0, i32 1
  store i64 %t291, ptr %t294, !tbaa !24
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb14
bb45:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"std/json:reader", ptr %t295, i32 0, i32 1
  %t298 = load i64, ptr %t297, !tbaa !24
  store i64 %t298, ptr %l5, !tbaa !24
  %t300 = load i64, ptr %l2, !tbaa !24
  store i64 %t300, ptr %l123, !tbaa !24
  %t301 = load i64, ptr %l123, !tbaa !24
  %t302 = icmp sge i64 %t301, 0
  br i1 %t302, label %bb46, label %bb47
bb46:
  %t304 = load i64, ptr %l123, !tbaa !24
  %t305 = mul i64 %t304, 1
  %t306 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t305)
  %t307 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t309 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t309, ptr %lp6
  %t311 = load ptr, ptr %lp6
  store { i64, ptr } %t308, ptr %t311, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l1, !tbaa !24
  %t316 = getelementptr %"std/json:reader", ptr %t312, i32 0, i32 1
  store i64 %t313, ptr %t316, !tbaa !24
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_f95a6a8592b17009_1182728235effc15)
  unreachable
bb48:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"std/json:reader", ptr %t317, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t321 = load i64, ptr %l5, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb49, label %bb50
bb49:
  br label %bb59
bb50:
  br label %bb51
bb51:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"std/json:reader", ptr %t328, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l134, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"std/json:reader", ptr %t332, i32 0, i32 1
  %t335 = load i64, ptr %t334, !tbaa !24
  %t337 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr i8, ptr %t338, i64 %t335
  %t340 = load i8, ptr %t339, !tbaa !32
  store i8 %t340, ptr %l8, !tbaa !22
  %t342 = load i8, ptr %l8, !tbaa !22
  %t344 = icmp eq i8 %t342, 92
  br i1 %t344, label %bb52, label %bb53
bb52:
  %t346 = load i64, ptr %l7, !tbaa !24
  store i64 %t346, ptr %l140, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i64, ptr %l7, !tbaa !24
  %t349 = load ptr, ptr %lp6
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  %t354 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %v1, ptr %t347, i64 %t348, { i64, ptr } %t350)
  %t355 = extractvalue { i32, i64 } %t354, 1
  %t356 = extractvalue { i32, i64 } %t354, 0
  store i32 %t356, ptr %l146
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb55, label %ok.358, !prof !99
ok.358:
  store i64 %t355, ptr %l145
  br label %bb54
bb53:
  %t359 = load i64, ptr %l7, !tbaa !24
  %t360 = load i8, ptr %l8, !tbaa !22
  %t362 = load ptr, ptr %lp6
  %t364 = getelementptr { i64, ptr }, ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i8, ptr %t365, i64 %t359
  store i8 %t360, ptr %t366, !tbaa !32
  %t367 = load i64, ptr %l7, !tbaa !24
  %t370 = add i64 %t367, 1
  store i64 %t370, ptr %l7, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l154, !tbaa !29
  %t373 = load ptr, ptr %l154, !tbaa !29
  %t374 = getelementptr %"std/json:reader", ptr %t373, i32 0, i32 1
  %t375 = load i64, ptr %t374, !tbaa !24
  %t378 = add i64 %t375, 1
  %t380 = load ptr, ptr %l154, !tbaa !29
  %t381 = getelementptr %"std/json:reader", ptr %t380, i32 0, i32 1
  store i64 %t378, ptr %t381, !tbaa !24
  br label %bb57
bb54:
  %t382 = load i64, ptr %l145, !tbaa !24
  store i64 %t382, ptr %l141, !tbaa !24
  br label %bb56
bb55:
  %t383 = load i32, ptr %l146, !tbaa !23
  %t384 = lshr i32 %t383, 16
  %t385 = and i32 %t383, 65535
  %t386 = icmp eq i32 %t384, 1
  %t387 = select i1 %t386, i32 1, i32 0
  %t388 = icmp eq i32 %t383, 0
  %t389 = shl i32 %t387, 16
  %t390 = or i32 %t389, %t385
  %t391 = select i1 %t388, i32 0, i32 %t390
  %t393 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t391, 0
  store { i32, { i64, ptr } } %t393, ptr %rv
  br label %ret
bb56:
  %t394 = load i64, ptr %l140, !tbaa !24
  %t395 = load i64, ptr %l141, !tbaa !24
  %t396 = add i64 %t394, %t395
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb48
bb59:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i64, ptr %l5, !tbaa !24
  %t401 = add i64 %t399, 1
  %t404 = getelementptr %"std/json:reader", ptr %t398, i32 0, i32 1
  store i64 %t401, ptr %t404, !tbaa !24
  %t405 = load ptr, ptr %lp6
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t410 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t406, 1
  store { i32, { i64, ptr } } %t410, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eutf8(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %l24 = alloca i1
  %l33 = alloca i1
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l47 = alloca { i64, [2 x i64] }
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca { i64, [2 x i64] }
  %l63 = alloca i64
  %l65 = alloca { i64, [2 x i64] }
  %l69 = alloca { i64, ptr }
  %l77 = alloca i1
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, [2 x i64] }
  %l86 = alloca i64
  %l88 = alloca { i64, [2 x i64] }
  %l95 = alloca i64
  %l98 = alloca i64
  %l117 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca i64
  %l129 = alloca { i64, [2 x i64] }
  %l130 = alloca i64
  %l132 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i64 }
  %t64 = alloca { i64, [2 x i64] }, align 8
  %t109 = alloca { i64, [2 x i64] }, align 8
  %t165 = alloca { i64, [2 x i64] }, align 8
  %t262 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 %t8
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %l1, !tbaa !22
  store i64 0, ptr %l2, !tbaa !24
  store i8 -128, ptr %l3, !tbaa !22
  store i8 -65, ptr %l4, !tbaa !22
  %t15 = load i8, ptr %l1, !tbaa !22
  %t17 = icmp uge i8 %t15, -62
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i8, ptr %l1, !tbaa !22
  %t21 = icmp ule i8 %t19, -33
  store i1 %t21, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i64 2, ptr %l2, !tbaa !24
  br label %bb33
bb5:
  %t24 = load i8, ptr %l1, !tbaa !22
  %t26 = icmp uge i8 %t24, -32
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i8, ptr %l1, !tbaa !22
  %t30 = icmp ule i8 %t28, -17
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l24, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  store i64 3, ptr %l2, !tbaa !24
  %t33 = load i8, ptr %l1, !tbaa !22
  %t35 = icmp eq i8 %t33, -32
  br i1 %t35, label %bb11, label %bb12
bb10:
  %t37 = load i8, ptr %l1, !tbaa !22
  %t39 = icmp uge i8 %t37, -16
  br i1 %t39, label %bb17, label %bb18
bb11:
  store i8 -96, ptr %l3, !tbaa !22
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t41 = load i8, ptr %l1, !tbaa !22
  %t43 = icmp eq i8 %t41, -19
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i8 -97, ptr %l4, !tbaa !22
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb32
bb17:
  %t45 = load i8, ptr %l1, !tbaa !22
  %t47 = icmp ule i8 %t45, -12
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb20, label %bb21
bb20:
  store i64 4, ptr %l2, !tbaa !24
  %t50 = load i8, ptr %l1, !tbaa !22
  %t52 = icmp eq i8 %t50, -16
  br i1 %t52, label %bb22, label %bb23
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l41
  br label %bb28
bb22:
  store i8 -112, ptr %l3, !tbaa !22
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t57 = load i8, ptr %l1, !tbaa !22
  %t59 = icmp eq i8 %t57, -12
  br i1 %t59, label %bb25, label %bb26
bb25:
  store i8 -113, ptr %l4, !tbaa !22
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb31
bb28:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l43
  br label %bb29
bb29:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 4, ptr %t65
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = insertvalue { i64, i64 } undef, i64 %t66, 0
  %t68 = load i64, ptr %l43, !tbaa !24
  %t69 = insertvalue { i64, i64 } %t67, i64 %t68, 1
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 1
  store { i64, i64 } %t69, ptr %t70
  %t71 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t71, ptr %l44
  %t72 = call ptr @__olang_errpay_push()
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l45
  %t75 = inttoptr i64 %t74 to ptr
  %t77 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t75, ptr %l44)
  store { i64, [2 x i64] } %t77, ptr %l47
  br label %bb30
bb30:
  %t78 = load { i64, [2 x i64] }, ptr %l47
  %t79 = load i64, ptr %l45
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = call ptr @__olang_scope_alloc_a(ptr %t80, i64 24, i64 8)
  store { i64, [2 x i64] } %t78, ptr %t81
  call void @__olang_errpay_set(ptr %t81)
  %t84 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t84, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/json:reader", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"std/json:reader", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp sgt i64 %t92, %t98
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l59
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l61
  br label %bb37
bb37:
  store { i64, [2 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 0
  store i64 4, ptr %t110
  %t111 = load i64, ptr %l59, !tbaa !24
  %t112 = insertvalue { i64, i64 } undef, i64 %t111, 0
  %t113 = load i64, ptr %l61, !tbaa !24
  %t114 = insertvalue { i64, i64 } %t112, i64 %t113, 1
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 1
  store { i64, i64 } %t114, ptr %t115
  %t116 = load { i64, [2 x i64] }, ptr %t109
  store { i64, [2 x i64] } %t116, ptr %l62
  %t117 = call ptr @__olang_errpay_push()
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l63, !tbaa !24
  %t119 = load i64, ptr %l63
  %t120 = inttoptr i64 %t119 to ptr
  %t122 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t120, ptr %l62)
  store { i64, [2 x i64] } %t122, ptr %l65
  br label %bb38
bb38:
  %t123 = load { i64, [2 x i64] }, ptr %l65
  %t124 = load i64, ptr %l63
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call ptr @__olang_scope_alloc_a(ptr %t125, i64 24, i64 8)
  store { i64, [2 x i64] } %t123, ptr %t126
  call void @__olang_errpay_set(ptr %t126)
  %t129 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t129, ptr %rv
  br label %ret
bb39:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/json:reader", ptr %t130, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l69, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"std/json:reader", ptr %t134, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = add i64 %t137, 1
  %t141 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i8, ptr %t142, i64 %t139
  %t144 = load i8, ptr %t143, !tbaa !32
  store i8 %t144, ptr %l5, !tbaa !22
  %t146 = load i8, ptr %l5, !tbaa !22
  %t147 = load i8, ptr %l3, !tbaa !22
  %t150 = icmp ult i8 %t146, %t147
  br i1 %t150, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb42
bb41:
  %t152 = load i8, ptr %l5, !tbaa !22
  %t153 = load i8, ptr %l4, !tbaa !22
  %t156 = icmp ugt i8 %t152, %t153
  store i1 %t156, ptr %l77, !tbaa !21
  br label %bb42
bb42:
  %t158 = load i1, ptr %l77, !tbaa !21
  br i1 %t158, label %bb43, label %bb44
bb43:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l82
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l84
  br label %bb46
bb46:
  store { i64, [2 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [2 x i64] }, ptr %t165, i32 0, i32 0
  store i64 4, ptr %t166
  %t167 = load i64, ptr %l82, !tbaa !24
  %t168 = insertvalue { i64, i64 } undef, i64 %t167, 0
  %t169 = load i64, ptr %l84, !tbaa !24
  %t170 = insertvalue { i64, i64 } %t168, i64 %t169, 1
  %t171 = getelementptr { i64, [2 x i64] }, ptr %t165, i32 0, i32 1
  store { i64, i64 } %t170, ptr %t171
  %t172 = load { i64, [2 x i64] }, ptr %t165
  store { i64, [2 x i64] } %t172, ptr %l85
  %t173 = call ptr @__olang_errpay_push()
  %t174 = ptrtoint ptr %t173 to i64
  store i64 %t174, ptr %l86, !tbaa !24
  %t175 = load i64, ptr %l86
  %t176 = inttoptr i64 %t175 to ptr
  %t178 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t176, ptr %l85)
  store { i64, [2 x i64] } %t178, ptr %l88
  br label %bb47
bb47:
  %t179 = load { i64, [2 x i64] }, ptr %l88
  %t180 = load i64, ptr %l86
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = call ptr @__olang_scope_alloc_a(ptr %t181, i64 24, i64 8)
  store { i64, [2 x i64] } %t179, ptr %t182
  call void @__olang_errpay_set(ptr %t182)
  %t185 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t185, ptr %rv
  br label %ret
bb48:
  store i64 2, ptr %l6, !tbaa !24
  %t186 = load i64, ptr %l2, !tbaa !24
  store i64 %t186, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t188 = load i64, ptr %l7, !tbaa !24
  %t189 = load i64, ptr %l6, !tbaa !24
  %t192 = icmp sgt i64 %t188, %t189
  br i1 %t192, label %bb49, label %bb50
bb49:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb54
bb51:
  %t198 = load i64, ptr %l7, !tbaa !24
  %t199 = load i64, ptr %l6, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l8, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t208 = sub i64 %t206, 1
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = sdiv i64 %t208, %t209
  store i64 %t212, ptr %l98, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb53
bb53:
  %t214 = load i64, ptr %l98, !tbaa !24
  store i64 %t214, ptr %l95, !tbaa !24
  br label %bb54
bb54:
  %t215 = load i64, ptr %l95, !tbaa !24
  store i64 %t215, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb55
bb55:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb56, label %bb57
bb56:
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t224 = load i64, ptr %l6, !tbaa !24
  %t225 = load i64, ptr %l10, !tbaa !24
  %t226 = load i64, ptr %l8, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/json:reader", ptr %t234, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l117, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"std/json:reader", ptr %t238, i32 0, i32 1
  %t241 = load i64, ptr %t240, !tbaa !24
  %t245 = add i64 %t241, %t232
  %t247 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i8, ptr %t248, i64 %t245
  %t250 = load i8, ptr %t249, !tbaa !32
  %t252 = and i8 %t250, -64
  %t254 = icmp ne i8 %t252, -128
  br i1 %t254, label %bb59, label %bb60
bb59:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t256)
  store i64 %t258, ptr %l126
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l128
  br label %bb62
bb62:
  store { i64, [2 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [2 x i64] }, ptr %t262, i32 0, i32 0
  store i64 4, ptr %t263
  %t264 = load i64, ptr %l126, !tbaa !24
  %t265 = insertvalue { i64, i64 } undef, i64 %t264, 0
  %t266 = load i64, ptr %l128, !tbaa !24
  %t267 = insertvalue { i64, i64 } %t265, i64 %t266, 1
  %t268 = getelementptr { i64, [2 x i64] }, ptr %t262, i32 0, i32 1
  store { i64, i64 } %t267, ptr %t268
  %t269 = load { i64, [2 x i64] }, ptr %t262
  store { i64, [2 x i64] } %t269, ptr %l129
  %t270 = call ptr @__olang_errpay_push()
  %t271 = ptrtoint ptr %t270 to i64
  store i64 %t271, ptr %l130, !tbaa !24
  %t272 = load i64, ptr %l130
  %t273 = inttoptr i64 %t272 to ptr
  %t275 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t273, ptr %l129)
  store { i64, [2 x i64] } %t275, ptr %l132
  br label %bb63
bb63:
  %t276 = load { i64, [2 x i64] }, ptr %l132
  %t277 = load i64, ptr %l130
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = call ptr @__olang_scope_alloc_a(ptr %t278, i64 24, i64 8)
  store { i64, [2 x i64] } %t276, ptr %t279
  call void @__olang_errpay_set(ptr %t279)
  %t282 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t282, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t283 = load i64, ptr %l10, !tbaa !24
  %t286 = add i64 %t283, 1
  store i64 %t286, ptr %l10, !tbaa !24
  br label %bb55
bb66:
  %t288 = load i64, ptr %l2, !tbaa !24
  %t290 = insertvalue { i32, i64 } zeroinitializer, i64 %t288, 1
  store { i32, i64 } %t290, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l47 = alloca { i64, [2 x i64] }
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca i64
  %l66 = alloca { i64, [2 x i64] }
  %l69 = alloca ptr
  %rv = alloca i32
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb24
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp eq i64 %t54, %t60
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l41
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l43
  br label %bb14
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 1, ptr %t72
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = insertvalue { i64, i64 } undef, i64 %t73, 0
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = insertvalue { i64, i64 } %t74, i64 %t75, 1
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { i64, i64 } %t76, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t78, ptr %l44
  %t79 = call ptr @__olang_errpay_push()
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l45, !tbaa !24
  %t81 = load i64, ptr %l45
  %t82 = inttoptr i64 %t81 to ptr
  %t84 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t82, ptr %l44)
  store { i64, [2 x i64] } %t84, ptr %l47
  br label %bb15
bb15:
  %t85 = load { i64, [2 x i64] }, ptr %l47
  %t86 = load i64, ptr %l45
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call ptr @__olang_scope_alloc_a(ptr %t87, i64 24, i64 8)
  store { i64, [2 x i64] } %t85, ptr %t88
  call void @__olang_errpay_set(ptr %t88)
  store i32 65537, ptr %rv
  br label %ret
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/json:reader", ptr %t91, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l51, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"std/json:reader", ptr %t95, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t104, ptr %l55, !tbaa !27
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t105
  %t110 = load i8, ptr %t109, !tbaa !32
  %t113 = icmp ne i8 %t103, %t110
  br i1 %t113, label %bb17, label %bb18
bb17:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l60
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %t118)
  store i64 %t120, ptr %l62
  br label %bb20
bb20:
  store { i64, [2 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t123 = load i64, ptr %l60, !tbaa !24
  %t124 = insertvalue { i64, i64 } undef, i64 %t123, 0
  %t125 = load i64, ptr %l62, !tbaa !24
  %t126 = insertvalue { i64, i64 } %t124, i64 %t125, 1
  %t127 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 1
  store { i64, i64 } %t126, ptr %t127
  %t128 = load { i64, [2 x i64] }, ptr %t121
  store { i64, [2 x i64] } %t128, ptr %l63
  %t129 = call ptr @__olang_errpay_push()
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l64, !tbaa !24
  %t131 = load i64, ptr %l64
  %t132 = inttoptr i64 %t131 to ptr
  %t134 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t132, ptr %l63)
  store { i64, [2 x i64] } %t134, ptr %l66
  br label %bb21
bb21:
  %t135 = load { i64, [2 x i64] }, ptr %l66
  %t136 = load i64, ptr %l64
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = call ptr @__olang_scope_alloc_a(ptr %t137, i64 24, i64 8)
  store { i64, [2 x i64] } %t135, ptr %t138
  call void @__olang_errpay_set(ptr %t138)
  store i32 65536, ptr %rv
  br label %ret
bb22:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l69, !tbaa !29
  %t142 = load ptr, ptr %l69, !tbaa !29
  %t143 = getelementptr %"std/json:reader", ptr %t142, i32 0, i32 1
  %t144 = load i64, ptr %t143, !tbaa !24
  %t147 = add i64 %t144, 1
  %t149 = load ptr, ptr %l69, !tbaa !29
  %t150 = getelementptr %"std/json:reader", ptr %t149, i32 0, i32 1
  store i64 %t147, ptr %t150, !tbaa !24
  br label %bb23
bb23:
  %t151 = load i64, ptr %l6, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l6, !tbaa !24
  br label %bb7
bb24:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:writer", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:writer", ptr %t10, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t12, i8 10)
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"std/json:writer", ptr %t62, i32 0, i32 2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/json:writer", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t64, { i64, ptr } %t68)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l17 = alloca i64
  %l20 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:writer", ptr %t1, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 34)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb52
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  store i8 %t61, ptr %l9, !tbaa !22
  %t63 = load i8, ptr %l9, !tbaa !22
  %t65 = icmp uge i8 %t63, 32
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = load i8, ptr %l9, !tbaa !22
  %t69 = icmp ne i8 %t67, 34
  store i1 %t69, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l43, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t72 = load i8, ptr %l9, !tbaa !22
  %t74 = icmp ne i8 %t72, 92
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"std/json:writer", ptr %t77, i32 0, i32 2
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l51, !tbaa !27
  %t81 = load i64, ptr %l2, !tbaa !24
  store i64 %t81, ptr %l52, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  store i64 %t82, ptr %l53, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l54, !tbaa !24
  %t85 = load i64, ptr %l52, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb23:
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = load i64, ptr %l54, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb25:
  %t96 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l53, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t104, { i64, ptr } %t103)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb27:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l2, !tbaa !24
  %t110 = load i8, ptr %l9, !tbaa !22
  %t112 = icmp eq i8 %t110, 34
  br i1 %t112, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"std/json:writer", ptr %t114, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb30
bb29:
  %t118 = load i8, ptr %l9, !tbaa !22
  %t120 = icmp eq i8 %t118, 92
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"std/json:writer", ptr %t122, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t124, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb33
bb32:
  %t126 = load i8, ptr %l9, !tbaa !22
  %t128 = icmp eq i8 %t126, 10
  br i1 %t128, label %bb34, label %bb35
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/json:writer", ptr %t130, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb36
bb35:
  %t134 = load i8, ptr %l9, !tbaa !22
  %t136 = icmp eq i8 %t134, 9
  br i1 %t136, label %bb37, label %bb38
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"std/json:writer", ptr %t138, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb39
bb38:
  %t142 = load i8, ptr %l9, !tbaa !22
  %t144 = icmp eq i8 %t142, 13
  br i1 %t144, label %bb40, label %bb41
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"std/json:writer", ptr %t146, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t148, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s13
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"std/json:writer", ptr %t150, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb43:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/json:writer", ptr %t154, i32 0, i32 2
  %t157 = load i8, ptr %l9, !tbaa !22
  %t159 = lshr i8 %t157, 4
  %t161 = zext i8 %t159 to i64
  %t163 = getelementptr { i64, ptr }, ptr @G_2estd_2fjson_2ehexDigits, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t161
  %t166 = load i8, ptr %t165, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t156, i8 %t166)
  br label %bb44
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"std/json:writer", ptr %t169, i32 0, i32 2
  %t172 = load i8, ptr %l9, !tbaa !22
  %t174 = and i8 %t172, 15
  %t176 = zext i8 %t174 to i64
  %t178 = getelementptr { i64, ptr }, ptr @G_2estd_2fjson_2ehexDigits, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i8, ptr %t179, i64 %t176
  %t181 = load i8, ptr %t180, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t171, i8 %t181)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t184 = load i64, ptr %l7, !tbaa !24
  %t187 = add i64 %t184, 1
  store i64 %t187, ptr %l7, !tbaa !24
  br label %bb8
bb52:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"std/json:writer", ptr %t189, i32 0, i32 2
  store ptr %t191, ptr %l99, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t192, ptr %l100, !tbaa !27
  %t193 = load i64, ptr %l2, !tbaa !24
  store i64 %t193, ptr %l101, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t194, 0
  store i64 %t197, ptr %l104, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l101, !tbaa !24
  %t201 = icmp sge i64 %t200, 0
  br i1 %t201, label %bb53, label %bb54
bb53:
  %t203 = load i64, ptr %l101, !tbaa !24
  %t204 = load i64, ptr %l104, !tbaa !24
  %t205 = icmp sle i64 %t203, %t204
  br i1 %t205, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb55:
  %t207 = load i64, ptr %l104, !tbaa !24
  %t208 = load i64, ptr %l105, !tbaa !24
  %t209 = icmp sle i64 %t207, %t208
  br i1 %t209, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb57:
  %t211 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = load i64, ptr %l101, !tbaa !24
  %t214 = load i64, ptr %l104, !tbaa !24
  %t215 = getelementptr i8, ptr %t212, i64 %t213
  %t216 = sub i64 %t214, %t213
  %t217 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t215, 1
  %t219 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t219, { i64, ptr } %t218)
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb59:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"std/json:writer", ptr %t221, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t223, i8 34)
  br label %bb60
bb60:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca double
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l105 = alloca i64
  %l108 = alloca i64
  %l134 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca i1
  %l153 = alloca i64
  %l160 = alloca i64
  %l164 = alloca i64
  %l167 = alloca i64
  %l194 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:writer", ptr %t10, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t12, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb127
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t15 = load ptr, ptr %l28, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l28, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 8}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l29, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { i1 }, ptr %t25, i32 0, i32 0
  %t27 = load i1, ptr %t26
  store i1 %t27, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/json:writer", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l35, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb15:
  %t34 = load ptr, ptr %l35, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } %t35)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb127
bb17:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t37 = load ptr, ptr %l38, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l38, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l39, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { double }, ptr %t47, i32 0, i32 0
  %t49 = load double, ptr %t48
  store double %t49, ptr %l4, !tbaa !26
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t51 = load double, ptr %l4, !tbaa !26
  %t52 = load double, ptr %l4, !tbaa !26
  %t55 = fcmp une double %t51, %t52
  br i1 %t55, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb25
bb24:
  %t57 = load double, ptr %l4, !tbaa !26
  %t58 = load double, ptr %l4, !tbaa !26
  %t61 = fsub double %t57, %t58
  %t63 = fcmp une double %t61, 0x0000000000000000
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l47, !tbaa !21
  br i1 %t65, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:writer", ptr %t66, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t68, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb28
bb27:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:writer", ptr %t70, i32 0, i32 2
  %t73 = load double, ptr %l4, !tbaa !26
  call void @std_2fjson_2ewriteNumber(ptr %v0, ptr %t72, double %t73)
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb127
bb31:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb32, label %bb33
bb32:
  %t80 = load ptr, ptr %l57, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb33
bb33:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb34, label %bb35
bb34:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { i64 }, ptr %t87, i32 0, i32 0
  %t89 = load i64, ptr %t88
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/json:writer", ptr %t91, i32 0, i32 2
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t97 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t96)
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t93, { i64, ptr } %t100)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb127
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t105 = load ptr, ptr %l68, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb39, label %bb40
bb39:
  %t108 = load ptr, ptr %l68, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 4
  store i1 %t111, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t112 = load i1, ptr %l69, !tbaa !21
  br i1 %t112, label %bb41, label %bb42
bb41:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { i64 }, ptr %t115, i32 0, i32 0
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l6, !tbaa !65
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/json:writer", ptr %t119, i32 0, i32 2
  %t122 = load i64, ptr %l6, !tbaa !65
  %t124 = call i64 @__olang_fmt_u64(ptr null, i64 %t122)
  %t125 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t124)
  %t126 = call i64 @__olang_fmt_u64(ptr %t125, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t121, { i64, ptr } %t128)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb127
bb45:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t133 = load ptr, ptr %l79, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 8}
  %t139 = icmp eq i64 %t137, 5
  store i1 %t139, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t140 = load i1, ptr %l80, !tbaa !21
  br i1 %t140, label %bb48, label %bb49
bb48:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { { i64, ptr } }, ptr %t143, i32 0, i32 0
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l7, !tbaa !27
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %t147, { i64, ptr } %t148)
  br label %bb51
bb51:
  br label %bb127
bb52:
  %t151 = load ptr, ptr %l1, !tbaa !29
  store ptr %t151, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t152 = load ptr, ptr %l87, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb53, label %bb54
bb53:
  %t155 = load ptr, ptr %l87, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 8}
  %t158 = icmp eq i64 %t156, 6
  store i1 %t158, ptr %l88, !tbaa !21
  br label %bb54
bb54:
  %t159 = load i1, ptr %l88, !tbaa !21
  br i1 %t159, label %bb55, label %bb56
bb55:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { { i64, ptr } }, ptr %t162, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163
  store { i64, ptr } %t164, ptr %l8, !tbaa !27
  br label %bb57
bb56:
  br label %bb83
bb57:
  %t166 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s12
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"std/json:writer", ptr %t172, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t174, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb61:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"std/json:writer", ptr %t176, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t178, i8 91)
  br label %bb62
bb62:
  store i64 0, ptr %l9, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l9, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb63, label %bb64
bb63:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb68
bb65:
  %t194 = load i64, ptr %l10, !tbaa !24
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l11, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l11, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l108, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb67
bb67:
  %t210 = load i64, ptr %l108, !tbaa !24
  store i64 %t210, ptr %l105, !tbaa !24
  br label %bb68
bb68:
  %t211 = load i64, ptr %l105, !tbaa !24
  store i64 %t211, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb69
bb69:
  %t212 = load i64, ptr %l13, !tbaa !24
  %t213 = load i64, ptr %l12, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb70, label %bb71
bb70:
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t220 = load i64, ptr %l9, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t222 = load i64, ptr %l11, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l14, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  %t232 = icmp sgt i64 %t230, 0
  br i1 %t232, label %bb73, label %bb74
bb73:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/json:writer", ptr %t234, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t236, i8 44)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l2, !tbaa !24
  %t241 = add i64 %t239, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t238, i64 %t241)
  br label %bb77
bb77:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t245, ptr %l134, !tbaa !27
  %t246 = load i64, ptr %l14, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr ptr, ptr %t249, i64 %t246
  %t251 = load ptr, ptr %t250, !tbaa !39
  %t252 = load i64, ptr %l2, !tbaa !24
  %t254 = add i64 %t252, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %t244, ptr %t251, i64 %t254)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = add i64 %t258, 1
  store i64 %t261, ptr %l13, !tbaa !24
  br label %bb69
bb80:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l2, !tbaa !24
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t263, i64 %t264)
  br label %bb81
bb81:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"std/json:writer", ptr %t267, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t269, i8 93)
  br label %bb82
bb82:
  br label %bb127
bb83:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t272 = load ptr, ptr %l146, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb84, label %bb85
bb84:
  %t275 = load ptr, ptr %l146, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 8}
  %t278 = icmp eq i64 %t276, 7
  store i1 %t278, ptr %l147, !tbaa !21
  br label %bb85
bb85:
  %t279 = load i1, ptr %l147, !tbaa !21
  br i1 %t279, label %bb86, label %bb87
bb86:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { ptr }, ptr %t282, i32 0, i32 0
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l15, !tbaa !29
  br label %bb88
bb87:
  br label %bb121
bb88:
  %t286 = load ptr, ptr %l15, !tbaa !29
  %t288 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t286)
  store i64 %t288, ptr %l153
  br label %bb89
bb89:
  %t289 = load i64, ptr %l153, !tbaa !24
  %t290 = icmp eq i64 %t289, 0
  br i1 %t290, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s18
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"std/json:writer", ptr %t292, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s18, ptr %t294, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s18)
  br label %ret
bb93:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"std/json:writer", ptr %t296, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t298, i8 123)
  br label %bb94
bb94:
  store i64 0, ptr %l16, !tbaa !24
  %t300 = load ptr, ptr %l15, !tbaa !29
  %t302 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t300)
  store i64 %t302, ptr %l160
  br label %bb95
bb95:
  %t303 = load i64, ptr %l160, !tbaa !24
  store i64 %t303, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t304 = load i64, ptr %l17, !tbaa !24
  %t305 = load i64, ptr %l16, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb96, label %bb97
bb96:
  %t310 = load i64, ptr %l18, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb101
bb98:
  %t314 = load i64, ptr %l17, !tbaa !24
  %t315 = load i64, ptr %l16, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l18, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l18, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l167, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb100
bb100:
  %t330 = load i64, ptr %l167, !tbaa !24
  store i64 %t330, ptr %l164, !tbaa !24
  br label %bb101
bb101:
  %t331 = load i64, ptr %l164, !tbaa !24
  store i64 %t331, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s20
  %t332 = load i64, ptr %l20, !tbaa !24
  %t333 = load i64, ptr %l19, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb104:
  br label %bb105
bb105:
  %t340 = load i64, ptr %l16, !tbaa !24
  %t341 = load i64, ptr %l20, !tbaa !24
  %t342 = load i64, ptr %l18, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l21, !tbaa !24
  %t350 = load i64, ptr %l21, !tbaa !24
  %t352 = icmp sgt i64 %t350, 0
  br i1 %t352, label %bb106, label %bb107
bb106:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"std/json:writer", ptr %t354, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t356, i8 44)
  br label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb109
bb109:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i64, ptr %l2, !tbaa !24
  %t361 = add i64 %t359, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t358, i64 %t361)
  br label %bb110
bb110:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l15, !tbaa !29
  %t367 = getelementptr %"std/json:Object", ptr %t365, i32 0, i32 0
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l194, !tbaa !27
  %t369 = load i64, ptr %l21, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr { i64, ptr }, ptr %t372, i64 %t369
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !37
  call void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %t364, { i64, ptr } %t374)
  br label %bb111
bb111:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"std/json:writer", ptr %t377, i32 0, i32 2
  store ptr %t379, ptr %l198, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"std/json:writer", ptr %t380, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t387 = icmp sgt i64 %t385, 0
  br i1 %t387, label %bb112, label %bb113
bb112:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l203, !tbaa !27
  br label %bb114
bb113:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l203, !tbaa !27
  br label %bb114
bb114:
  %t389 = load ptr, ptr %l198, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l203, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s20, ptr %t389, { i64, ptr } %t390)
  br label %bb115
bb115:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l15, !tbaa !29
  %t394 = getelementptr %"std/json:Object", ptr %t392, i32 0, i32 1
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l206, !tbaa !27
  %t396 = load i64, ptr %l21, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr ptr, ptr %t399, i64 %t396
  %t401 = load ptr, ptr %t400, !tbaa !39
  %t402 = load i64, ptr %l2, !tbaa !24
  %t404 = add i64 %t402, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %t391, ptr %t401, i64 %t404)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s20)
  br label %bb117
bb117:
  %t408 = load i64, ptr %l20, !tbaa !24
  %t411 = add i64 %t408, 1
  store i64 %t411, ptr %l20, !tbaa !24
  br label %bb102
bb118:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load i64, ptr %l2, !tbaa !24
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t413, i64 %t414)
  br label %bb119
bb119:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"std/json:writer", ptr %t417, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t419, i8 125)
  br label %bb120
bb120:
  br label %bb127
bb121:
  br i1 true, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb126
bb124:
  store %olang.scope zeroinitializer, ptr %s23
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"std/json:writer", ptr %t421, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s23, ptr %t423, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s23)
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_a9bf92283d37587a_a12d0c4bd2035d0e)
  unreachable
bb127:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2ewriteNumber(ptr %v0, ptr noalias dereferenceable(32) align 8 %a0, double %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = call ptr @__olang_sb_room(ptr %s1, i64 48)
  %t5 = call i64 @__olang_fmt_float(ptr %t4, i64 48, double %a1, i32 0)
  call void @__olang_sb_add(ptr %s1, i64 %t5)
  %t6 = load ptr, ptr %s1
  %t7 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t8 = load i64, ptr %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t6, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t13 = load ptr, ptr %t12
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %sbgrew.15, label %sbdone.16
sbgrew.15:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.16
sbdone.16:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } %t17)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/json:reader" @std_2fjson_3areader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l16 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %rv = alloca %"std/json:reader"
  %t3 = alloca { i64, [2 x i64] }, align 8
  %t15 = alloca i64
  %t40 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t3
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t5, ptr %t7
  store ptr %t7, ptr %l12, !tbaa !29
  %t8 = icmp sge i64 64, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = icmp sle i64 64, 1152921504606846975
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a9d90acfb58a0efc_8cee310d77323458)
  unreachable
bb3:
  %t12 = mul i64 64, 8
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  %t14 = load ptr, ptr %l12, !tbaa !29
  store i64 0, ptr %t15
  br label %fill.16
fill.16:
  %t19 = load i64, ptr %t15
  %t20 = icmp slt i64 %t19, 64
  br i1 %t20, label %fillb.17, label %filld.18
fillb.17:
  %t21 = getelementptr ptr, ptr %t13, i64 %t19
  store ptr %t14, ptr %t21
  %t22 = add i64 %t19, 1
  store i64 %t22, ptr %t15
  br label %fill.16
filld.18:
  %t23 = insertvalue { i64, ptr } undef, i64 64, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t13, 1
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = call ptr @__olang_scope_hold(ptr %v1)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e4
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a9d90acfb58a0efc_8cee310d77323458)
  unreachable
bb5:
  %t30 = call ptr @__olang_region_make(ptr %v1)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t32 = icmp sge i64 16, 0
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = icmp sle i64 16, 576460752303423487
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b0f269ec47121b49_ffa527191fa405c5)
  unreachable
bb9:
  %t36 = mul i64 16, 16
  %t37 = load i64, ptr %l16
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = call ptr @__olang_held_alloc(ptr %t38, i64 %t36)
  store i64 0, ptr %t40
  br label %fill.41
fill.41:
  %t44 = load i64, ptr %t40
  %t45 = icmp slt i64 %t44, 16
  br i1 %t45, label %fillb.42, label %filld.43
fillb.42:
  %t46 = getelementptr { i64, ptr }, ptr %t39, i64 %t44
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %t46
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %t40
  br label %fill.41
filld.43:
  %t48 = insertvalue { i64, ptr } undef, i64 16, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t39, 1
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t51 = call ptr @__olang_scope_hold(ptr %v1)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l21, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e6
  br i1 %t53, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b0f269ec47121b49_ffa527191fa405c5)
  unreachable
bb11:
  %t55 = call ptr @__olang_region_make(ptr %v1)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t57 = icmp sge i64 16, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = icmp sle i64 16, 1152921504606846975
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6)
  unreachable
bb15:
  %t61 = mul i64 16, 8
  %t62 = load i64, ptr %l21
  %t63 = inttoptr i64 %t62 to ptr
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %t63, i64 %t61)
  %t65 = insertvalue { i64, ptr } undef, i64 16, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l7, !tbaa !27
  %t68 = call ptr @__olang_scope_hold(ptr %v1)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l26, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2estd_2fjson_3areader_2e7
  br i1 %t70, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6)
  unreachable
bb17:
  %t72 = call ptr @__olang_region_make(ptr %v1)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l26, !tbaa !24
  br label %bb18
bb18:
  %t74 = icmp sge i64 16, 0
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = icmp sle i64 16, 1152921504606846975
  br i1 %t76, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_8e53cae89060ac5f_4eb6599badda6f3b)
  unreachable
bb21:
  %t78 = mul i64 16, 8
  %t79 = load i64, ptr %l26
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %t80, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 16, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t86 = insertvalue %"std/json:reader" undef, { i64, ptr } %t85, 0
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = insertvalue %"std/json:reader" %t86, i64 %t87, 1
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t90 = insertvalue %"std/json:reader" %t88, { i64, ptr } %t89, 2
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = insertvalue %"std/json:reader" %t90, i64 %t91, 3
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = insertvalue %"std/json:reader" %t92, { i64, ptr } %t93, 4
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = insertvalue %"std/json:reader" %t94, i64 %t95, 5
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = insertvalue %"std/json:reader" %t96, { i64, ptr } %t97, 6
  %t100 = insertvalue %"std/json:reader" %t98, { i64, ptr } %t83, 7
  %t102 = insertvalue %"std/json:reader" %t100, i64 0, 8
  store %"std/json:reader" %t102, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8e53cae89060ac5f_4eb6599badda6f3b)
  unreachable
ret:
  %rr = load %"std/json:reader", ptr %rv
  ret %"std/json:reader" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_errpay_pop()
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  br label %bb1
bb3:
  br label %bb1
bb4:
  br label %bb1
bb5:
  br label %bb1
bb6:
  br label %bb1
bb7:
  br label %bb1
bb8:
  br label %bb1
bb9:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare void @__olang_errpay_set(ptr) cold
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2estd_2fjson_3areader_2e6 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2estd_2fjson_3areader_2e7 = weak hidden constant i1 false
@olang_2esole_2estd_2fjson_3areader_2e4 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\22" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cr" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\5Cu00" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
declare i64 @__olang_fmt_u64(ptr, i64)
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{}" }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_float(ptr, i64, double, i32)
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_sb_grow(ptr, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_bc241580f27121ab_ca64d2d20e518e77 = external constant [0 x i8]
@olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2 = external constant [0 x i8]
declare i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6a96f216a7a18db5_c7851721732fae9 = external constant [0 x i8]
@olang_loc_2a2c934c6745fec4_9721022dc2e60418 = external constant [0 x i8]
@olang_loc_247b9c864b1325ff_f9e87c5eec2e2b33 = external constant [0 x i8]
@olang_loc_a7b0a92300089828_a6e8a6d400231804 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a07ba4d7ff0a56f9_d8356302010b83f5 = external constant [0 x i8]
@olang_loc_22f1698915dd4682_a0313dce564b9a3e = external constant [0 x i8]
declare i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e7435678738af803_3f3d624b6ec28d3f = external constant [0 x i8]
@olang_loc_cd6f075822d3ba64_2e9ce5061183e548 = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
@olang_loc_664da5dbc2e51de6_83a7e6ee135f5f2a = external constant [0 x i8]
@olang_loc_3d7deb9fd92cdf7_48602bd2c42c5c33 = external constant [0 x i8]
@olang_loc_4cf869d60c4ca172_ef56e6f5157a9496 = external constant [0 x i8]
declare void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a4e4729341d0d567_917d86fd422044ab = external constant [0 x i8]
declare { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_78dc4052a96c39eb_b95510f79f72ba17 = external constant [0 x i8]
declare i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %a0)
declare i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %a0)
@olang_loc_9ab7127216e6ddd3_9523f6c3485c577 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %a0)
@olang_loc_1d597537a8745baf_fba5a5429ece169b = external constant [0 x i8]
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
@G_2estd_2fjson_2eMaxDepth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
@olang_loc_85df472c87ddc01c_576e573e0ca51428 = external constant [0 x i8]
@olang_loc_99863128c17f1e9_63398a4432912015 = external constant [0 x i8]
@olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d = external constant [0 x i8]
@olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3 = external constant [0 x i8]
@olang_loc_c68c402cf703814a_d8009281770a12f6 = external constant [0 x i8]
@olang_loc_f95a6a8592b17009_1182728235effc15 = external constant [0 x i8]
@olang_loc_b05733ff18c427e5_772a385d9f13c959 = external constant [0 x i8]
@G_2estd_2fjson_2ehexDigits = external constant <{ [8 x i8], ptr }>
@olang_loc_619d2740d221a188_b21ca0b40d9629ac = external constant [0 x i8]
@olang_loc_a9bf92283d37587a_a12d0c4bd2035d0e = external constant [0 x i8]
@olang_loc_a9d90acfb58a0efc_8cee310d77323458 = external constant [0 x i8]
@olang_loc_b0f269ec47121b49_ffa527191fa405c5 = external constant [0 x i8]
@olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6 = external constant [0 x i8]
@olang_loc_8e53cae89060ac5f_4eb6599badda6f3b = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
