; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:link" = type { i64, i64, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:root" = type { i64, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/effects:pend" = type { i64, i64, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/effects:part" = type { i64, i64, i32, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" = type { { i64, ptr }, i64 }
%"compiler/effects:coldMark" = type { i64, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/effects:given" = type { i64, i64, i64, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/effects:fslot" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/effects:Verdict" = type { { i64, ptr }, { i64, ptr }, i1, i32, { i64, ptr }, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/effects:fpath" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/effects:fret" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local { i64, ptr } @compiler_2feffects_2eCapText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i64
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i64
  %l66 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb30
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Facts", ptr %t51, i32 0, i32 21
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = shl i64 1, %t57
  %t61 = and i64 %t54, %t58
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l8, !tbaa !24
  %t68 = getelementptr %"compiler/effects:Facts", ptr %t65, i32 0, i32 22
  %t70 = getelementptr [6 x i64], ptr %t68, i64 0, i64 %t66
  %t71 = load i64, ptr %t70, !tbaa !34
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = icmp slt i64 %t77, %t80
  store i1 %t83, ptr %l47, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l47, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l52, !tbaa !29
  %t86 = call ptr @__olang_scope_hold(ptr %s0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l53, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t88, label %bb20, label %bb21
bb19:
  store ptr %l2, ptr %l62, !tbaa !29
  %t90 = call ptr @__olang_scope_hold(ptr %s0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l63, !tbaa !24
  %t92 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t92, label %bb24, label %bb25
bb20:
  %t94 = call ptr @__olang_region_make(ptr %s0)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l53, !tbaa !24
  br label %bb21
bb21:
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %s4, i64 %t96)
  store { i64, ptr } %t98, ptr %l56
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t99, ptr %l57, !tbaa !27
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %t103, i64 %t100
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !37
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t105, 1
  %t114 = extractvalue { i64, ptr } %t105, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = load i64, ptr %l53
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_held_alloc(ptr %t120, i64 %t118)
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t109, i64 %t110)
  %t123 = getelementptr i8, ptr %t122, i64 %t110
  call void @olang_textcopy(ptr %t123, ptr %t113, i64 %t114)
  %t124 = getelementptr i8, ptr %t123, i64 %t114
  call void @olang_textcopy(ptr %t124, ptr %t116, i64 %t117)
  %t125 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t121, 1
  %t128 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t126)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb24:
  %t130 = call ptr @__olang_region_make(ptr %s0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l63, !tbaa !24
  br label %bb25
bb25:
  %t132 = load i64, ptr %l8, !tbaa !24
  %t133 = load i64, ptr %l63
  %t134 = inttoptr i64 %t133 to ptr
  %t136 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %t134, i64 %t132)
  store { i64, ptr } %t136, ptr %l66
  br label %bb26
bb26:
  %t137 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t138 = load i64, ptr %l63
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } %t137, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_held_alloc(ptr %t139, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t146, { i64, ptr } %t145)
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t148 = load i64, ptr %l7, !tbaa !24
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %l7, !tbaa !24
  br label %bb8
bb30:
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %v2, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store { i64, ptr } %t154, ptr %l72
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t155 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eDescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i64
  %l97 = alloca { i64, ptr }
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca i64
  %l109 = alloca i64
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca { i64, ptr }
  %l143 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l149 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i64
  %l160 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l208 = alloca i1
  %l211 = alloca i1
  %l214 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 16
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t6, ptr %l21, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l22, !tbaa !24
  %t9 = load i64, ptr %l22, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l23, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l22, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Facts", ptr %t22, i32 0, i32 12
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Facts", ptr %t27, i32 0, i32 13
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l26, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s2, ptr %t33)
  store { i64, ptr } %t35, ptr %l30
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t36 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t38 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Facts", ptr %t47, i32 0, i32 12
  %t50 = load i1, ptr %t49, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s4, ptr %t52)
  store { i64, ptr } %t54, ptr %l35
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t55 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t57 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = add i64 %t56, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = getelementptr i8, ptr %t61, i64 %t56
  call void @olang_textcopy(ptr %t62, ptr %t58, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eIdle(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l38
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l40
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s7, ptr %t74)
  store { i64, ptr } %t76, ptr %l42
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t77 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t79 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = getelementptr i8, ptr %t83, i64 %t78
  call void @olang_textcopy(ptr %t84, ptr %t80, i64 %t81)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %s6, ptr %t88)
  store { i64, ptr } %t90, ptr %l45
  br label %bb23
bb23:
  %t91 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t93 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t91, i64 %t92)
  %t98 = getelementptr i8, ptr %t97, i64 %t92
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t100, ptr %rv
  br label %ret
bb24:
  %t102 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l47
  br label %bb25
bb25:
  %t103 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l2
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l48
  br label %bb26
bb26:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l4, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb32
bb29:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t121 = load i64, ptr %l4, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l6, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l57, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb31
bb31:
  %t136 = load i64, ptr %l57, !tbaa !24
  store i64 %t136, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t137 = load i64, ptr %l54, !tbaa !24
  store i64 %t137, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb33
bb33:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t139 = load i64, ptr %l7, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb34, label %bb35
bb34:
  br label %bb45
bb35:
  br label %bb36
bb36:
  %t146 = load i64, ptr %l4, !tbaa !24
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l6, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l9, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Facts", ptr %t156, i32 0, i32 23
  %t159 = load i64, ptr %t158, !tbaa !24
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = call i1 @compiler_2feffects_2ehasBit(i64 %t159, i64 %t160)
  store i1 %t163, ptr %l78
  br label %bb37
bb37:
  %t164 = load i1, ptr %l78, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store ptr %l3, ptr %l79, !tbaa !29
  %t165 = call ptr @__olang_scope_hold(ptr %s0)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l80, !tbaa !24
  %t167 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t167, label %bb40, label %bb41
bb39:
  br label %bb43
bb40:
  %t169 = call ptr @__olang_region_make(ptr %s0)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l80, !tbaa !24
  br label %bb41
bb41:
  %t171 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t171, ptr %l82, !tbaa !27
  %t172 = load i64, ptr %l9, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %t175, i64 %t172
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !37
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t181 = extractvalue { i64, ptr } %t177, 1
  %t182 = extractvalue { i64, ptr } %t177, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = load i64, ptr %l80
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call ptr @__olang_held_alloc(ptr %t188, i64 %t186)
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = getelementptr i8, ptr %t190, i64 %t182
  call void @olang_textcopy(ptr %t191, ptr %t184, i64 %t185)
  %t192 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t189, 1
  %t195 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t195, { i64, ptr } %t193)
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t197 = load i64, ptr %l8, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l8, !tbaa !24
  br label %bb33
bb45:
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t203, ptr %l91
  br label %bb46
bb46:
  %t204 = load i64, ptr %l91, !tbaa !24
  %t205 = icmp sgt i64 %t204, 0
  br i1 %t205, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s15
  store ptr %l2, ptr %l93, !tbaa !29
  %t207 = call ptr @__olang_scope_hold(ptr %s0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l94, !tbaa !24
  %t209 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t209, label %bb49, label %bb50
bb48:
  br label %bb53
bb49:
  %t211 = call ptr @__olang_region_make(ptr %s0)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l94, !tbaa !24
  br label %bb50
bb50:
  %t214 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s15, ptr %s15, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store { i64, ptr } %t214, ptr %l97
  br label %bb51
bb51:
  %t215 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t217 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = load i64, ptr %l94
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = call ptr @__olang_held_alloc(ptr %t222, i64 %t220)
  call void @olang_textcopy(ptr %t223, ptr %t215, i64 %t216)
  %t224 = getelementptr i8, ptr %t223, i64 %t216
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t228 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t228, { i64, ptr } %t226)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s15)
  br label %bb53
bb53:
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l100
  br label %bb54
bb54:
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  store i64 %t234, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t236 = load i64, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t242 = load i64, ptr %l13, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb60
bb57:
  %t246 = load i64, ptr %l12, !tbaa !24
  %t247 = load i64, ptr %l11, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l13, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l109, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb59
bb59:
  %t262 = load i64, ptr %l109, !tbaa !24
  store i64 %t262, ptr %l106, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l106, !tbaa !24
  store i64 %t263, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb61
bb61:
  %t264 = load i64, ptr %l15, !tbaa !24
  %t265 = load i64, ptr %l14, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb62, label %bb63
bb62:
  br label %bb73
bb63:
  br label %bb64
bb64:
  %t272 = load i64, ptr %l11, !tbaa !24
  %t273 = load i64, ptr %l15, !tbaa !24
  %t274 = load i64, ptr %l13, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l16, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/effects:Facts", ptr %t282, i32 0, i32 24
  %t285 = load i64, ptr %t284, !tbaa !24
  %t286 = load i64, ptr %l16, !tbaa !24
  %t289 = call i1 @compiler_2feffects_2ehasBit(i64 %t285, i64 %t286)
  store i1 %t289, ptr %l130
  br label %bb65
bb65:
  %t290 = load i1, ptr %l130, !tbaa !21
  br i1 %t290, label %bb66, label %bb67
bb66:
  store ptr %l10, ptr %l131, !tbaa !29
  %t291 = call ptr @__olang_scope_hold(ptr %s0)
  %t292 = ptrtoint ptr %t291 to i64
  store i64 %t292, ptr %l132, !tbaa !24
  %t293 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t293, label %bb68, label %bb69
bb67:
  br label %bb71
bb68:
  %t295 = call ptr @__olang_region_make(ptr %s0)
  %t296 = ptrtoint ptr %t295 to i64
  store i64 %t296, ptr %l132, !tbaa !24
  br label %bb69
bb69:
  %t297 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t297, ptr %l134, !tbaa !27
  %t298 = load i64, ptr %l16, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %t301, i64 %t298
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !37
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t307 = extractvalue { i64, ptr } %t303, 1
  %t308 = extractvalue { i64, ptr } %t303, 0
  %t309 = add i64 %t305, %t308
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = load i64, ptr %l132
  %t314 = inttoptr i64 %t313 to ptr
  %t315 = call ptr @__olang_held_alloc(ptr %t314, i64 %t312)
  call void @olang_textcopy(ptr %t315, ptr %t304, i64 %t305)
  %t316 = getelementptr i8, ptr %t315, i64 %t305
  call void @olang_textcopy(ptr %t316, ptr %t307, i64 %t308)
  %t317 = getelementptr i8, ptr %t316, i64 %t308
  call void @olang_textcopy(ptr %t317, ptr %t310, i64 %t311)
  %t318 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t315, 1
  %t321 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t321, { i64, ptr } %t319)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t323 = load i64, ptr %l15, !tbaa !24
  %t326 = add i64 %t323, 1
  store i64 %t326, ptr %l15, !tbaa !24
  br label %bb61
bb73:
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l10)
  store i64 %t329, ptr %l143
  br label %bb74
bb74:
  %t330 = load i64, ptr %l143, !tbaa !24
  %t331 = icmp sgt i64 %t330, 0
  br i1 %t331, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l2, ptr %l145, !tbaa !29
  %t333 = call ptr @__olang_scope_hold(ptr %s0)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l146, !tbaa !24
  %t335 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t335, label %bb77, label %bb78
bb76:
  br label %bb81
bb77:
  %t337 = call ptr @__olang_region_make(ptr %s0)
  %t338 = ptrtoint ptr %t337 to i64
  store i64 %t338, ptr %l146, !tbaa !24
  br label %bb78
bb78:
  %t340 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s22, ptr %s22, ptr %l10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store { i64, ptr } %t340, ptr %l149
  br label %bb79
bb79:
  %t341 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t343 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = load i64, ptr %l146
  %t348 = inttoptr i64 %t347 to ptr
  %t349 = call ptr @__olang_held_alloc(ptr %t348, i64 %t346)
  call void @olang_textcopy(ptr %t349, ptr %t341, i64 %t342)
  %t350 = getelementptr i8, ptr %t349, i64 %t342
  call void @olang_textcopy(ptr %t350, ptr %t344, i64 %t345)
  %t351 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t349, 1
  %t354 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t354, { i64, ptr } %t352)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s22)
  br label %bb81
bb81:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/effects:Facts", ptr %t356, i32 0, i32 3
  %t359 = load i1, ptr %t358, !tbaa !21
  br i1 %t359, label %bb82, label %bb83
bb82:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  store ptr %l2, ptr %l155, !tbaa !29
  %t362 = call ptr @__olang_scope_hold(ptr %s0)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l156, !tbaa !24
  %t364 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t364, label %bb86, label %bb87
bb86:
  %t366 = call ptr @__olang_region_make(ptr %s0)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l156, !tbaa !24
  br label %bb87
bb87:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/effects:Facts", ptr %t368, i32 0, i32 0
  %t371 = load i1, ptr %t370, !tbaa !21
  br i1 %t371, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l161, !tbaa !27
  %t373 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t375 = load i64, ptr %l156
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = extractvalue { i64, ptr } %t373, 0
  %t378 = extractvalue { i64, ptr } %t373, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_held_alloc(ptr %t376, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  store { i64, ptr } %t382, ptr %l160, !tbaa !27
  br label %bb93
bb89:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/effects:Facts", ptr %t384, i32 0, i32 1
  %t387 = load i1, ptr %t386, !tbaa !21
  br i1 %t387, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l167, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t391 = load i64, ptr %l156
  %t392 = inttoptr i64 %t391 to ptr
  %t393 = extractvalue { i64, ptr } %t389, 0
  %t394 = extractvalue { i64, ptr } %t389, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_held_alloc(ptr %t392, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  store { i64, ptr } %t398, ptr %l166, !tbaa !27
  br label %bb92
bb91:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l170, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t402 = load i64, ptr %l156
  %t403 = inttoptr i64 %t402 to ptr
  %t404 = extractvalue { i64, ptr } %t400, 0
  %t405 = extractvalue { i64, ptr } %t400, 1
  %t406 = mul i64 %t404, 1
  %t407 = call ptr @__olang_held_alloc(ptr %t403, i64 %t406)
  call void @llvm.memcpy.p0.p0.i64(ptr %t407, ptr %t405, i64 %t406, i1 false)
  %t408 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t407, 1
  store { i64, ptr } %t409, ptr %l166, !tbaa !27
  br label %bb92
bb92:
  %t411 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t411, ptr %l160, !tbaa !27
  br label %bb93
bb93:
  %t412 = load ptr, ptr %l155, !tbaa !29
  %t413 = load { i64, ptr }, ptr %l160, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t412, { i64, ptr } %t413)
  br label %bb94
bb94:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/effects:Facts", ptr %t414, i32 0, i32 14
  %t417 = load i1, ptr %t416, !tbaa !21
  br i1 %t417, label %bb95, label %bb96
bb95:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/effects:Facts", ptr %t420, i32 0, i32 9
  %t423 = load i1, ptr %t422, !tbaa !21
  br i1 %t423, label %bb99, label %bb100
bb99:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = call { i64, ptr } @compiler_2feffects_2ecapText(ptr %v0, ptr %s0, ptr %t426)
  store { i64, ptr } %t428, ptr %l180
  br label %bb103
bb103:
  %t429 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t429, ptr %l17, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t432 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t430, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t432, ptr %l182
  br label %bb104
bb104:
  %t433 = load i1, ptr %l182, !tbaa !21
  %t434 = xor i1 %t433, true
  br i1 %t434, label %bb105, label %bb106
bb105:
  %t436 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t436)
  br label %bb107
bb106:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/effects:Facts", ptr %t439, i32 0, i32 7
  %t442 = load i1, ptr %t441, !tbaa !21
  br i1 %t442, label %bb108, label %bb109
bb107:
  br label %bb112
bb108:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/effects:Facts", ptr %t445, i32 0, i32 15
  %t448 = load i1, ptr %t447, !tbaa !21
  br i1 %t448, label %bb113, label %bb114
bb113:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb116
bb116:
  store ptr %l2, ptr %l192, !tbaa !29
  %t451 = call ptr @__olang_scope_hold(ptr %s0)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l193, !tbaa !24
  %t453 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t453, label %bb117, label %bb118
bb117:
  %t455 = call ptr @__olang_region_make(ptr %s0)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l193, !tbaa !24
  br label %bb118
bb118:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/effects:Facts", ptr %t457, i32 0, i32 2
  %t460 = load i1, ptr %t459, !tbaa !21
  br i1 %t460, label %bb119, label %bb120
bb119:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l198, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t464 = load i64, ptr %l193
  %t465 = inttoptr i64 %t464 to ptr
  %t466 = extractvalue { i64, ptr } %t462, 0
  %t467 = extractvalue { i64, ptr } %t462, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_held_alloc(ptr %t465, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l197, !tbaa !27
  br label %bb121
bb120:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l201, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t475 = load i64, ptr %l193
  %t476 = inttoptr i64 %t475 to ptr
  %t477 = extractvalue { i64, ptr } %t473, 0
  %t478 = extractvalue { i64, ptr } %t473, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_held_alloc(ptr %t476, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  store { i64, ptr } %t482, ptr %l197, !tbaa !27
  br label %bb121
bb121:
  %t484 = load ptr, ptr %l192, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l197, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t484, { i64, ptr } %t485)
  br label %bb122
bb122:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/effects:Facts", ptr %t486, i32 0, i32 10
  %t489 = load i1, ptr %t488, !tbaa !21
  br i1 %t489, label %bb123, label %bb124
bb123:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb126
bb126:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t492)
  store i1 %t494, ptr %l208
  br label %bb127
bb127:
  %t495 = load i1, ptr %l208, !tbaa !21
  br i1 %t495, label %bb128, label %bb129
bb128:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb131
bb131:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %t497)
  store i1 %t499, ptr %l211
  br label %bb132
bb132:
  %t500 = load i1, ptr %l211, !tbaa !21
  br i1 %t500, label %bb133, label %bb134
bb133:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t503 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %v2, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store { i64, ptr } %t503, ptr %l214
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s0)
  %t504 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t504, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2ecapText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l44 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t53 = getelementptr %"compiler/effects:Facts", ptr %a0, i32 0, i32 21
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = shl i64 1, %t57
  %t61 = and i64 %t54, %t58
  %t63 = icmp ne i64 %t61, 0
  br i1 %t63, label %bb12, label %bb13
bb12:
  store ptr %l1, ptr %l40, !tbaa !29
  %t65 = call ptr @__olang_scope_hold(ptr %s0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l41, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t67, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  %t69 = call ptr @__olang_region_make(ptr %s0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l41, !tbaa !24
  br label %bb15
bb15:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l41
  %t73 = inttoptr i64 %t72 to ptr
  %t75 = call { i64, ptr } @compiler_2feffects_2eCapName(ptr %t73, i64 %t71)
  store { i64, ptr } %t75, ptr %l44
  br label %bb16
bb16:
  %t76 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t77 = load i64, ptr %l41
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = extractvalue { i64, ptr } %t76, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_held_alloc(ptr %t78, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t85 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t85, { i64, ptr } %t84)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t87, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t93 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %v1, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t93, ptr %l50
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargLink(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca %"compiler/effects:link"
  %l19 = alloca i1
  %l21 = alloca ptr
  %l25 = alloca %"compiler/effects:link"
  %l30 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca %"compiler/effects:link"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t20 = call %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %s1, i64 %t14, i64 %t15, i64 %t16)
  store %"compiler/effects:link" %t20, ptr %l16
  br label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargGlobal(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l19
  br label %bb6
bb4:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load %"compiler/effects:link", ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t26, %"compiler/effects:link" %t27)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2feffects_2eglobalParam, !tbaa !24
  %t38 = call %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %s3, i64 %t32, i64 %t33, i64 %t34)
  store %"compiler/effects:link" %t38, ptr %l25
  br label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 2
  %t42 = load i1, ptr %t41, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb9:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load %"compiler/effects:link", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t44, %"compiler/effects:link" %t45)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t50 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargOut(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i64 %t50, ptr %l30
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t51 = load i64, ptr %l30, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp ne i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/effects:Effects", ptr %t56, i32 0, i32 29
  store ptr %t58, ptr %l34, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t65 = call %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %s6, i64 %t59, i64 %t60, i64 %t61)
  store %"compiler/effects:link" %t65, ptr %l38
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load %"compiler/effects:link", ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t66, %"compiler/effects:link" %t67)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca %"compiler/effects:root"
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l26
  br label %bb9
bb9:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l21, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i64 0, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutOf(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i64 %t52, ptr %l31
  br label %bb14
bb14:
  %t53 = load i64, ptr %l31, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t73 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/effects:root" %t73, ptr %l40
  br label %bb21
bb21:
  %t74 = getelementptr %"compiler/effects:root", ptr %l40, i32 0, i32 1
  %t75 = load i1, ptr %t74, !tbaa !21
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t81 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutOf(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store i64 %t81, ptr %l45
  br label %bb24
bb23:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb25
bb24:
  %t82 = load i64, ptr %l45, !tbaa !24
  store i64 %t82, ptr %l42, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l42, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 17
  store i1 %t91, ptr %l47, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l47, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t103 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargOut(ptr %v0, ptr %v1, ptr %t99, ptr %t100)
  store i64 %t103, ptr %l54
  br label %bb32
bb32:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %rv
  br label %ret
bb33:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb34, label %bb35
bb34:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 18}
  %t112 = icmp eq i64 %t110, 6
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 1
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l6, !tbaa !23
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb38
bb37:
  br label %bb51
bb38:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/effects:Effects", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t131, i32 %t132)
  store i1 %t135, ptr %l67
  br label %bb39
bb39:
  %t136 = load i1, ptr %l67, !tbaa !21
  br i1 %t136, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb43
bb41:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/effects:Effects", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l6, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l73
  br label %bb42
bb42:
  %t147 = load i1, ptr %l73, !tbaa !21
  store i1 %t147, ptr %l68, !tbaa !21
  br label %bb43
bb43:
  %t148 = load i1, ptr %l68, !tbaa !21
  br i1 %t148, label %bb44, label %bb45
bb44:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t153 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorCall(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  store i1 %t153, ptr %l77
  br label %bb46
bb45:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb47
bb46:
  %t154 = load i1, ptr %l77, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l74, !tbaa !21
  br label %bb47
bb47:
  %t157 = load i1, ptr %l74, !tbaa !21
  br i1 %t157, label %bb48, label %bb49
bb48:
  %t158 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  store i64 %t158, ptr %l79, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb50
bb50:
  %t160 = load i64, ptr %l79, !tbaa !24
  store i64 %t160, ptr %rv
  br label %ret
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i64 0, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_650dda860f99b242_5ce1da2dd4f47486)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:root"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca %"compiler/effects:root"
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca %"compiler/effects:root"
  %l43 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 31
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store %"compiler/effects:root" %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = getelementptr %"compiler/effects:root", ptr %l27, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l30
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l29
  br label %bb11
bb11:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l22, !tbaa !24
  store i64 %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb29
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t74 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store %"compiler/effects:root" %t74, ptr %l39
  br label %bb21
bb21:
  %t75 = load %"compiler/effects:root", ptr %l39
  store %"compiler/effects:root" %t75, ptr %l5
  %t76 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 1
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Effects", ptr %t82, i32 0, i32 31
  %t85 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t84, i64 %t86)
  %t90 = extractvalue { i32, i64 } %t89, 1
  %t91 = extractvalue { i32, i64 } %t89, 0
  store i32 %t91, ptr %l48
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb26, label %ok.93, !prof !99
ok.93:
  store i64 %t90, ptr %l47
  br label %bb25
bb25:
  %t94 = load i64, ptr %l47, !tbaa !24
  store i64 %t94, ptr %l43, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb28
bb28:
  %t95 = load i64, ptr %l43, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb30, label %bb31
bb30:
  %t100 = load ptr, ptr %l49, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 17
  store i1 %t103, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t115 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store i64 %t115, ptr %l57
  br label %bb35
bb35:
  %t116 = load i64, ptr %l57, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4055e0fe87b920f9_59f1ceb8b6607d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecPointer(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 25
  %t4 = getelementptr %"compiler/effects:Facts", ptr %t3, i32 0, i32 7
  store i1 true, ptr %t4, !tbaa !21
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 25
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t7, i32 0, i32 2
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 25
  %t12 = getelementptr %"compiler/effects:Facts", ptr %t11, i32 0, i32 8
  store i1 true, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 25
  %t16 = getelementptr %"compiler/effects:Facts", ptr %t15, i32 0, i32 12
  store i1 true, ptr %t16, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 25
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t19, i32 0, i32 13
  store i1 true, ptr %t20, !tbaa !21
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr @G_2ecompiler_2feffects_2eCapC, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i1
  %l51 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l99 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l112 = alloca i32
  %l113 = alloca i1
  %l115 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/effects:pend"
  %l127 = alloca ptr
  %l128 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i1
  %l159 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca i1
  %l168 = alloca i1
  %l171 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca i64
  %l183 = alloca ptr
  %l184 = alloca i1
  %l190 = alloca ptr
  %l192 = alloca %"compiler/effects:pend"
  %l204 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca i1
  %l213 = alloca i1
  %l216 = alloca ptr
  %l218 = alloca i32
  %l219 = alloca i64
  %l228 = alloca ptr
  %l229 = alloca i1
  %l235 = alloca ptr
  %l240 = alloca %"compiler/effects:Facts"
  %l250 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l257 = alloca i32
  %l258 = alloca i1
  %l259 = alloca i1
  %l262 = alloca ptr
  %l264 = alloca i32
  %l265 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca i1
  %l287 = alloca i64
  %l290 = alloca i64
  %l309 = alloca { i64, ptr }
  %l314 = alloca i1
  %l315 = alloca ptr
  %l316 = alloca i1
  %l319 = alloca i1
  %l329 = alloca i1
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t7 = load ptr, ptr %l43, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l43, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l44, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l44, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 26
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l51
  br label %bb6
bb6:
  %t26 = load i64, ptr %l51, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t27, i32 0, i32 26
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t29, i64 %t32)
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 68
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Call", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t44 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t43, i64 %t44)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldPends(ptr %v0, ptr %v1, ptr %t48, i64 %t51, i64 %t52, ptr %t53)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb15
bb12:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l76, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb14
bb14:
  %t91 = load i64, ptr %l76, !tbaa !24
  store i64 %t91, ptr %l73, !tbaa !24
  br label %bb15
bb15:
  %t92 = load i64, ptr %l73, !tbaa !24
  store i64 %t92, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb17, label %bb18
bb17:
  br label %bb33
bb18:
  br label %bb19
bb19:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l10, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Call", ptr %t116, i32 0, i32 1
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l99, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t120
  %t125 = load ptr, ptr %t124, !tbaa !39
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargLink(ptr %v0, ptr %v1, ptr %t111, i64 %t114, i64 %t115, ptr %t125)
  br label %bb20
bb20:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l3, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t136 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2etakesFn(ptr %v0, ptr %t130, i64 %t133)
  store i1 %t136, ptr %l105
  br label %bb21
bb21:
  %t137 = load i1, ptr %l105, !tbaa !21
  br i1 %t137, label %bb22, label %bb23
bb22:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l107, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l109, !tbaa !27
  %t143 = load i64, ptr %l10, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  %t150 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t148)
  store i32 %t150, ptr %l112
  br label %bb24
bb23:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb26
bb24:
  %t151 = load ptr, ptr %l107, !tbaa !29
  %t152 = load i32, ptr %l112, !tbaa !23
  %t153 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t153, ptr %l113
  br label %bb25
bb25:
  %t154 = load i1, ptr %l113, !tbaa !21
  store i1 %t154, ptr %l106, !tbaa !21
  br label %bb26
bb26:
  %t155 = load i1, ptr %l106, !tbaa !21
  br i1 %t155, label %bb27, label %bb28
bb27:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Effects", ptr %t156, i32 0, i32 37
  store ptr %t158, ptr %l115, !tbaa !29
  %t159 = load i64, ptr %l4, !tbaa !24
  %t160 = load i64, ptr %l10, !tbaa !24
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Call", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l119, !tbaa !27
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr ptr, ptr %t168, i64 %t165
  %t170 = load ptr, ptr %t169, !tbaa !39
  %t174 = call %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v1, ptr %v0, i64 %t159, i64 %t160, ptr %t170)
  store %"compiler/effects:pend" %t174, ptr %l122
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t175 = load ptr, ptr %l115, !tbaa !29
  %t176 = load %"compiler/effects:pend", ptr %l122
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t175, %"compiler/effects:pend" %t176)
  br label %bb30
bb30:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/effects:Effects", ptr %t177, i32 0, i32 44
  store i1 true, ptr %t179, !tbaa !21
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb16
bb33:
  br label %bb128
bb34:
  %t185 = load ptr, ptr %l2, !tbaa !29
  store ptr %t185, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t186 = load ptr, ptr %l127, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb35, label %bb36
bb35:
  %t189 = load ptr, ptr %l127, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 5}
  %t192 = icmp eq i64 %t190, 1
  store i1 %t192, ptr %l128, !tbaa !21
  br label %bb36
bb36:
  %t193 = load i1, ptr %l128, !tbaa !21
  br i1 %t193, label %bb37, label %bb38
bb37:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { i64 }, ptr %t196, i32 0, i32 0
  %t198 = load i64, ptr %t197
  store i64 %t198, ptr %l11, !tbaa !24
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %t200, i64 %t201)
  br label %bb40
bb40:
  br label %bb128
bb41:
  %t204 = load ptr, ptr %l2, !tbaa !29
  store ptr %t204, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t205 = load ptr, ptr %l135, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb42, label %bb43
bb42:
  %t208 = load ptr, ptr %l135, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 5}
  %t211 = icmp eq i64 %t209, 2
  store i1 %t211, ptr %l136, !tbaa !21
  br label %bb43
bb43:
  %t212 = load i1, ptr %l136, !tbaa !21
  br i1 %t212, label %bb44, label %bb45
bb44:
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { ptr }, ptr %t215, i32 0, i32 0
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l12, !tbaa !29
  br label %bb46
bb45:
  br label %bb70
bb46:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/effects:Effects", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  store ptr %t224, ptr %l143, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t225)
  store i32 %t227, ptr %l145
  br label %bb47
bb47:
  %t228 = load ptr, ptr %l143, !tbaa !29
  %t229 = load i32, ptr %l145, !tbaa !23
  %t230 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %t228, i32 %t229)
  store i1 %t230, ptr %l146
  br label %bb48
bb48:
  %t231 = load i1, ptr %l146, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t232, ptr %t233)
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t237 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecPointer(ptr %v0, ptr %t237)
  br label %bb52
bb52:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Call", ptr %t239, i32 0, i32 1
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  %t248 = load i64, ptr %l14, !tbaa !24
  %t249 = load i64, ptr %l15, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb54, label %bb55
bb54:
  br label %bb69
bb55:
  br label %bb56
bb56:
  %t256 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t256, ptr %l159, !tbaa !27
  %t257 = load i64, ptr %l14, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  store ptr %t262, ptr %l16, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/effects:Effects", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  store ptr %t269, ptr %l164, !tbaa !29
  %t270 = load ptr, ptr %l16, !tbaa !29
  %t272 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t270)
  store i32 %t272, ptr %l166
  br label %bb57
bb57:
  %t273 = load ptr, ptr %l164, !tbaa !29
  %t274 = load i32, ptr %l166, !tbaa !23
  %t275 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t273, i32 %t274)
  store i1 %t275, ptr %l167
  br label %bb58
bb58:
  %t276 = load i1, ptr %l167, !tbaa !21
  br i1 %t276, label %bb59, label %bb60
bb59:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/effects:Effects", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 2
  store ptr %t282, ptr %l171, !tbaa !29
  %t283 = load ptr, ptr %l16, !tbaa !29
  %t285 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t283)
  store i32 %t285, ptr %l173
  br label %bb61
bb60:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb63
bb61:
  %t286 = load ptr, ptr %l171, !tbaa !29
  %t287 = load i32, ptr %l173, !tbaa !23
  %t288 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t286, i32 %t287)
  store i64 %t288, ptr %l174
  br label %bb62
bb62:
  %t289 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t290 = load i64, ptr %l174, !tbaa !24
  %t292 = and i64 %t290, %t289
  %t294 = icmp ne i64 %t292, 0
  store i1 %t294, ptr %l168, !tbaa !21
  br label %bb63
bb63:
  %t296 = load i1, ptr %l168, !tbaa !21
  br i1 %t296, label %bb64, label %bb65
bb64:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t297, ptr %t298)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t301 = load i64, ptr %l14, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l14, !tbaa !24
  br label %bb53
bb69:
  br label %bb128
bb70:
  %t306 = load ptr, ptr %l2, !tbaa !29
  store ptr %t306, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t307 = load ptr, ptr %l183, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb71, label %bb72
bb71:
  %t310 = load ptr, ptr %l183, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 5}
  %t313 = icmp eq i64 %t311, 2
  store i1 %t313, ptr %l184, !tbaa !21
  br label %bb72
bb72:
  %t314 = load i1, ptr %l184, !tbaa !21
  br i1 %t314, label %bb73, label %bb74
bb73:
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { ptr }, ptr %t317, i32 0, i32 0
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l17, !tbaa !29
  br label %bb75
bb74:
  br label %bb96
bb75:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/effects:Effects", ptr %t321, i32 0, i32 37
  store ptr %t323, ptr %l190, !tbaa !29
  %t324 = load ptr, ptr %l17, !tbaa !29
  %t326 = call %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v1, ptr %v0, i64 -1, i64 0, ptr %t324)
  store %"compiler/effects:pend" %t326, ptr %l192
  br label %bb76
bb76:
  %t327 = load ptr, ptr %l190, !tbaa !29
  %t328 = load %"compiler/effects:pend", ptr %l192
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t327, %"compiler/effects:pend" %t328)
  br label %bb77
bb77:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t330)
  br label %bb78
bb78:
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Call", ptr %t334, i32 0, i32 1
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  store i64 %t341, ptr %l20, !tbaa !24
  br label %bb79
bb79:
  %t343 = load i64, ptr %l19, !tbaa !24
  %t344 = load i64, ptr %l20, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb80, label %bb81
bb80:
  br label %bb95
bb81:
  br label %bb82
bb82:
  %t351 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t351, ptr %l204, !tbaa !27
  %t352 = load i64, ptr %l19, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr ptr, ptr %t355, i64 %t352
  %t357 = load ptr, ptr %t356, !tbaa !39
  store ptr %t357, ptr %l21, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/effects:Effects", ptr %t359, i32 0, i32 0
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t364 = getelementptr %"compiler/generic:Program", ptr %t362, i32 0, i32 2
  store ptr %t364, ptr %l209, !tbaa !29
  %t365 = load ptr, ptr %l21, !tbaa !29
  %t367 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t365)
  store i32 %t367, ptr %l211
  br label %bb83
bb83:
  %t368 = load ptr, ptr %l209, !tbaa !29
  %t369 = load i32, ptr %l211, !tbaa !23
  %t370 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t368, i32 %t369)
  store i1 %t370, ptr %l212
  br label %bb84
bb84:
  %t371 = load i1, ptr %l212, !tbaa !21
  br i1 %t371, label %bb85, label %bb86
bb85:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/effects:Effects", ptr %t372, i32 0, i32 0
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  store ptr %t377, ptr %l216, !tbaa !29
  %t378 = load ptr, ptr %l21, !tbaa !29
  %t380 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t378)
  store i32 %t380, ptr %l218
  br label %bb87
bb86:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb89
bb87:
  %t381 = load ptr, ptr %l216, !tbaa !29
  %t382 = load i32, ptr %l218, !tbaa !23
  %t383 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t381, i32 %t382)
  store i64 %t383, ptr %l219
  br label %bb88
bb88:
  %t384 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t385 = load i64, ptr %l219, !tbaa !24
  %t387 = and i64 %t385, %t384
  %t389 = icmp ne i64 %t387, 0
  store i1 %t389, ptr %l213, !tbaa !21
  br label %bb89
bb89:
  %t391 = load i1, ptr %l213, !tbaa !21
  br i1 %t391, label %bb90, label %bb91
bb90:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t392, ptr %t393)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t396 = load i64, ptr %l19, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l19, !tbaa !24
  br label %bb79
bb95:
  br label %bb128
bb96:
  %t401 = load ptr, ptr %l2, !tbaa !29
  store ptr %t401, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t402 = load ptr, ptr %l228, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb97, label %bb98
bb97:
  %t405 = load ptr, ptr %l228, !tbaa !29
  %t406 = load i64, ptr %t405, !range !{i64 0, i64 5}
  %t408 = icmp eq i64 %t406, 3
  store i1 %t408, ptr %l229, !tbaa !21
  br label %bb98
bb98:
  %t409 = load i1, ptr %l229, !tbaa !21
  br i1 %t409, label %bb99, label %bb100
bb99:
  %t410 = load ptr, ptr %l2, !tbaa !29
  %t412 = getelementptr { i64, [3 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { i32, i64, i32 }, ptr %t412, i32 0, i32 2
  %t414 = load i32, ptr %t413
  store i32 %t414, ptr %l22, !tbaa !23
  br label %bb101
bb100:
  br label %bb121
bb101:
  store %olang.scope zeroinitializer, ptr %s17
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/effects:Effects", ptr %t416, i32 0, i32 25
  store ptr %t418, ptr %l235, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/effects:Effects", ptr %t419, i32 0, i32 0
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = getelementptr %"compiler/generic:Program", ptr %t422, i32 0, i32 2
  %t425 = load i32, ptr %l22, !tbaa !23
  %t428 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t424, i32 %t425)
  store %"compiler/effects:Facts" %t428, ptr %l240
  br label %bb102
bb102:
  %t429 = load ptr, ptr %l235, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s17, ptr %t429, ptr %l240)
  br label %bb103
bb103:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Call", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l25, !tbaa !24
  br label %bb104
bb104:
  %t440 = load i64, ptr %l24, !tbaa !24
  %t441 = load i64, ptr %l25, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb105, label %bb106
bb105:
  br label %bb120
bb106:
  br label %bb107
bb107:
  %t448 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t448, ptr %l250, !tbaa !27
  %t449 = load i64, ptr %l24, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr ptr, ptr %t452, i64 %t449
  %t454 = load ptr, ptr %t453, !tbaa !39
  store ptr %t454, ptr %l26, !tbaa !29
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/effects:Effects", ptr %t456, i32 0, i32 0
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t459, i32 0, i32 2
  store ptr %t461, ptr %l255, !tbaa !29
  %t462 = load ptr, ptr %l26, !tbaa !29
  %t464 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t462)
  store i32 %t464, ptr %l257
  br label %bb108
bb108:
  %t465 = load ptr, ptr %l255, !tbaa !29
  %t466 = load i32, ptr %l257, !tbaa !23
  %t467 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t465, i32 %t466)
  store i1 %t467, ptr %l258
  br label %bb109
bb109:
  %t468 = load i1, ptr %l258, !tbaa !21
  br i1 %t468, label %bb110, label %bb111
bb110:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/effects:Effects", ptr %t469, i32 0, i32 0
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t474 = getelementptr %"compiler/generic:Program", ptr %t472, i32 0, i32 2
  store ptr %t474, ptr %l262, !tbaa !29
  %t475 = load ptr, ptr %l26, !tbaa !29
  %t477 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t475)
  store i32 %t477, ptr %l264
  br label %bb112
bb111:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb114
bb112:
  %t478 = load ptr, ptr %l262, !tbaa !29
  %t479 = load i32, ptr %l264, !tbaa !23
  %t480 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t478, i32 %t479)
  store i64 %t480, ptr %l265
  br label %bb113
bb113:
  %t481 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t482 = load i64, ptr %l265, !tbaa !24
  %t484 = and i64 %t482, %t481
  %t486 = icmp ne i64 %t484, 0
  store i1 %t486, ptr %l259, !tbaa !21
  br label %bb114
bb114:
  %t488 = load i1, ptr %l259, !tbaa !21
  br i1 %t488, label %bb115, label %bb116
bb115:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t489, ptr %t490)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t493 = load i64, ptr %l24, !tbaa !24
  %t496 = add i64 %t493, 1
  store i64 %t496, ptr %l24, !tbaa !24
  br label %bb104
bb120:
  call void @__olang_scope_close(ptr %s17)
  br label %bb128
bb121:
  %t498 = load ptr, ptr %l2, !tbaa !29
  store ptr %t498, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t499 = load ptr, ptr %l274, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb122, label %bb123
bb122:
  %t502 = load ptr, ptr %l274, !tbaa !29
  %t503 = load i64, ptr %t502, !range !{i64 0, i64 5}
  %t505 = icmp eq i64 %t503, 4
  store i1 %t505, ptr %l275, !tbaa !21
  br label %bb123
bb123:
  %t506 = load i1, ptr %l275, !tbaa !21
  br i1 %t506, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_1bc29689bbb58e32_9924d9acc7f0abd6)
  unreachable
bb128:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/effects:Effects", ptr %t507, i32 0, i32 70
  %t510 = load i1, ptr %t509, !tbaa !21
  store i1 %t510, ptr %l27, !tbaa !21
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/effects:Effects", ptr %t512, i32 0, i32 70
  store i1 false, ptr %t514, !tbaa !21
  store i64 0, ptr %l28, !tbaa !24
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr %"compiler/typed:Call", ptr %t515, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t518, 0
  store i64 %t520, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t522 = load i64, ptr %l29, !tbaa !24
  %t523 = load i64, ptr %l28, !tbaa !24
  %t526 = icmp sgt i64 %t522, %t523
  br i1 %t526, label %bb129, label %bb130
bb129:
  %t528 = load i64, ptr %l30, !tbaa !24
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb134
bb131:
  %t532 = load i64, ptr %l29, !tbaa !24
  %t533 = load i64, ptr %l28, !tbaa !24
  %t536 = sub i64 %t532, %t533
  %t537 = load i64, ptr %l30, !tbaa !24
  %t540 = add i64 %t536, %t537
  %t542 = sub i64 %t540, 1
  %t543 = load i64, ptr %l30, !tbaa !24
  %t546 = sdiv i64 %t542, %t543
  store i64 %t546, ptr %l290, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb133
bb133:
  %t548 = load i64, ptr %l290, !tbaa !24
  store i64 %t548, ptr %l287, !tbaa !24
  br label %bb134
bb134:
  %t549 = load i64, ptr %l287, !tbaa !24
  store i64 %t549, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb135
bb135:
  %t550 = load i64, ptr %l32, !tbaa !24
  %t551 = load i64, ptr %l31, !tbaa !24
  %t554 = icmp slt i64 %t550, %t551
  %t556 = xor i1 %t554, true
  br i1 %t556, label %bb136, label %bb137
bb136:
  br label %bb154
bb137:
  br label %bb138
bb138:
  %t558 = load i64, ptr %l28, !tbaa !24
  %t559 = load i64, ptr %l32, !tbaa !24
  %t560 = load i64, ptr %l30, !tbaa !24
  %t563 = mul i64 %t559, %t560
  %t566 = add i64 %t558, %t563
  store i64 %t566, ptr %l33, !tbaa !24
  %t568 = load ptr, ptr %l1, !tbaa !29
  %t570 = getelementptr %"compiler/typed:Call", ptr %t568, i32 0, i32 1
  %t571 = load { i64, ptr }, ptr %t570, !tbaa !27
  store { i64, ptr } %t571, ptr %l309, !tbaa !27
  %t572 = load i64, ptr %l33, !tbaa !24
  %t574 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr ptr, ptr %t575, i64 %t572
  %t577 = load ptr, ptr %t576, !tbaa !39
  store ptr %t577, ptr %l34, !tbaa !29
  %t579 = load i1, ptr %l27, !tbaa !21
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb139, label %bb140
bb139:
  %t583 = load ptr, ptr %l34, !tbaa !29
  store ptr %t583, ptr %l315, !tbaa !29
  store i1 false, ptr %l316, !tbaa !21
  %t584 = load ptr, ptr %l315, !tbaa !29
  %t585 = icmp ne ptr %t584, null
  br i1 %t585, label %bb141, label %bb142
bb140:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb143
bb141:
  %t587 = load ptr, ptr %l315, !tbaa !29
  %t588 = load i64, ptr %t587, !range !{i64 0, i64 18}
  %t590 = icmp eq i64 %t588, 5
  store i1 %t590, ptr %l316, !tbaa !21
  br label %bb142
bb142:
  %t591 = load i1, ptr %l316, !tbaa !21
  store i1 %t591, ptr %l314, !tbaa !21
  br label %bb143
bb143:
  %t592 = load i1, ptr %l314, !tbaa !21
  br i1 %t592, label %bb144, label %bb145
bb144:
  %t593 = load ptr, ptr %l34, !tbaa !29
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t595, i32 0, i32 0
  %t597 = load %"compiler/source:Span", ptr %t596
  store %"compiler/source:Span" %t597, ptr %l35
  %t599 = load ptr, ptr %l34, !tbaa !29
  %t601 = getelementptr { i64, [5 x i64] }, ptr %t599, i32 0, i32 1
  %t602 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t601, i32 0, i32 1
  %t603 = load i32, ptr %t602
  store i32 %t603, ptr %l36, !tbaa !23
  %t605 = load ptr, ptr %l34, !tbaa !29
  %t607 = getelementptr { i64, [5 x i64] }, ptr %t605, i32 0, i32 1
  %t608 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t607, i32 0, i32 2
  %t609 = load ptr, ptr %t608
  store ptr %t609, ptr %l37, !tbaa !29
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t613 = load i64, ptr %l33, !tbaa !24
  %t617 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eonStack(ptr %v0, ptr %v1, ptr %t611, ptr %t612, i64 %t613)
  store i1 %t617, ptr %l329
  br label %bb146
bb145:
  store i1 false, ptr %l319, !tbaa !21
  br label %bb147
bb146:
  %t618 = load i1, ptr %l329, !tbaa !21
  store i1 %t618, ptr %l319, !tbaa !21
  br label %bb147
bb147:
  %t619 = load i1, ptr %l319, !tbaa !21
  br i1 %t619, label %bb148, label %bb149
bb148:
  %t620 = load ptr, ptr %l34, !tbaa !29
  %t622 = getelementptr { i64, [5 x i64] }, ptr %t620, i32 0, i32 1
  %t623 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t622, i32 0, i32 0
  %t624 = load %"compiler/source:Span", ptr %t623
  store %"compiler/source:Span" %t624, ptr %l38
  %t626 = load ptr, ptr %l34, !tbaa !29
  %t628 = getelementptr { i64, [5 x i64] }, ptr %t626, i32 0, i32 1
  %t629 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t628, i32 0, i32 1
  %t630 = load i32, ptr %t629
  store i32 %t630, ptr %l39, !tbaa !23
  %t632 = load ptr, ptr %l34, !tbaa !29
  %t634 = getelementptr { i64, [5 x i64] }, ptr %t632, i32 0, i32 1
  %t635 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t634, i32 0, i32 2
  %t636 = load ptr, ptr %t635
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/typed:Promote", ptr %t636, i32 0, i32 0
  %t643 = load ptr, ptr %t642, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t638, ptr %t643)
  br label %bb150
bb149:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t647, ptr %t648)
  br label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb152
bb152:
  br label %bb153
bb153:
  %t652 = load i64, ptr %l32, !tbaa !24
  %t655 = add i64 %t652, 1
  store i64 %t655, ptr %l32, !tbaa !24
  br label %bb135
bb154:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i32
  %l44 = alloca %"compiler/effects:part"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l74 = alloca i32
  %l75 = alloca i1
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i32
  %l87 = alloca %"compiler/effects:part"
  %l88 = alloca ptr
  %l89 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i32
  %l102 = alloca %"compiler/effects:part"
  %l103 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca i1
  %l132 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca i1
  %l176 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l202 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i64
  %l214 = alloca i32
  %l215 = alloca %"compiler/effects:part"
  %l216 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca i1
  %l232 = alloca ptr
  %l236 = alloca %"compiler/effects:part"
  %l237 = alloca ptr
  %l238 = alloca i1
  %l241 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l257 = alloca ptr
  %l258 = alloca i1
  %l265 = alloca ptr
  %l266 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca ptr
  %l279 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l283 = alloca ptr
  %l286 = alloca %"compiler/effects:part"
  %l287 = alloca ptr
  %l288 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i64
  %l295 = alloca i32
  %l296 = alloca %"compiler/effects:part"
  %l297 = alloca ptr
  %l298 = alloca i1
  %l307 = alloca ptr
  %l308 = alloca i1
  %l314 = alloca ptr
  %l319 = alloca %"compiler/effects:part"
  %l321 = alloca ptr
  %l324 = alloca %"compiler/effects:part"
  %l326 = alloca ptr
  %l327 = alloca i64
  %l329 = alloca i32
  %l330 = alloca %"compiler/effects:part"
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 16
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 38
  store ptr %t11, ptr %l40, !tbaa !29
  %t12 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t12, ptr %l41, !tbaa !24
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t13)
  store i32 %t15, ptr %l43
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i64, ptr %l41, !tbaa !24
  %t17 = load i32, ptr %l43, !tbaa !23
  %t18 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t16, i64 0, i32 %t17, ptr null)
  store %"compiler/effects:part" %t18, ptr %l44
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l40, !tbaa !29
  %t20 = load %"compiler/effects:part", ptr %l44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t19, %"compiler/effects:part" %t20)
  br label %bb8
bb8:
  br label %ret
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t22 = load ptr, ptr %l45, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l45, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 17
  store i1 %t28, ptr %l46, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l46, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = add i64 %t39, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 %t41)
  br label %bb15
bb15:
  br label %bb183
bb16:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t46 = load ptr, ptr %l56, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l56, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 9
  store i1 %t52, ptr %l57, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l57, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 54}
  store i32 %t58, ptr %l4
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t62, i32 0, i32 4
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l5, !tbaa !27
  br label %bb21
bb20:
  br label %bb37
bb21:
  %t66 = load i32, ptr %l4, !range !{i32 0, i32 54}
  %t68 = trunc i64 20 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t75 = icmp eq i64 %t73, 1
  store i1 %t75, ptr %l66, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l66, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l71, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t79, ptr %l72, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 0
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t83)
  store i32 %t85, ptr %l74
  br label %bb27
bb26:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb29
bb27:
  %t86 = load ptr, ptr %l71, !tbaa !29
  %t87 = load i32, ptr %l74, !tbaa !23
  %t88 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l75
  br label %bb28
bb28:
  %t89 = load i1, ptr %l75, !tbaa !21
  store i1 %t89, ptr %l70, !tbaa !21
  br label %bb29
bb29:
  %t90 = load i1, ptr %l70, !tbaa !21
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t92, ptr %l77, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 0
  %t96 = load ptr, ptr %t95, !tbaa !39
  %t98 = load i64, ptr %l2, !tbaa !24
  %t100 = add i64 %t98, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t91, ptr %t96, i64 %t100)
  br label %bb32
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 38
  store ptr %t106, ptr %l83, !tbaa !29
  %t107 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t107, ptr %l84, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t108)
  store i32 %t110, ptr %l86
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t111 = load i64, ptr %l84, !tbaa !24
  %t112 = load i32, ptr %l86, !tbaa !23
  %t113 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t111, i64 0, i32 %t112, ptr null)
  store %"compiler/effects:part" %t113, ptr %l87
  br label %bb34
bb34:
  %t114 = load ptr, ptr %l83, !tbaa !29
  %t115 = load %"compiler/effects:part", ptr %l87
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t114, %"compiler/effects:part" %t115)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb183
bb37:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t117 = load ptr, ptr %l88, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb38, label %bb39
bb38:
  %t120 = load ptr, ptr %l88, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 18}
  %t123 = icmp eq i64 %t121, 11
  store i1 %t123, ptr %l89, !tbaa !21
  br label %bb39
bb39:
  %t124 = load i1, ptr %l89, !tbaa !21
  br i1 %t124, label %bb40, label %bb41
bb40:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l6, !tbaa !29
  br label %bb42
bb41:
  br label %bb54
bb42:
  %t131 = load ptr, ptr %l6, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Cond", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb43, label %bb44
bb43:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/effects:Effects", ptr %t138, i32 0, i32 38
  store ptr %t140, ptr %l98, !tbaa !29
  %t141 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t141, ptr %l99, !tbaa !24
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t142)
  store i32 %t144, ptr %l101
  br label %bb45
bb44:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l103, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Cond", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb48, label %bb49
bb45:
  %t153 = load i64, ptr %l99, !tbaa !24
  %t154 = load i32, ptr %l101, !tbaa !23
  %t155 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t153, i64 0, i32 %t154, ptr null)
  store %"compiler/effects:part" %t155, ptr %l102
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l98, !tbaa !29
  %t157 = load %"compiler/effects:part", ptr %l102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t156, %"compiler/effects:part" %t157)
  br label %bb47
bb47:
  br label %bb52
bb48:
  call void @__olang_check_failed(ptr @olang_loc_b51fd4885ec92e5_d8c1bbe4cc347d79)
  unreachable
bb49:
  br label %bb50
bb50:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Cond", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = load i64, ptr %l2, !tbaa !24
  %t165 = add i64 %t163, 1
  %t166 = load ptr, ptr %l103, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t166, ptr %t161, i64 %t165)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l6, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Cond", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = load i64, ptr %l2, !tbaa !24
  %t177 = add i64 %t175, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t169, ptr %t173, i64 %t177)
  br label %bb53
bb53:
  br label %bb183
bb54:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t182 = load ptr, ptr %l118, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb55, label %bb56
bb55:
  %t185 = load ptr, ptr %l118, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 18}
  %t188 = icmp eq i64 %t186, 13
  store i1 %t188, ptr %l119, !tbaa !21
  br label %bb56
bb56:
  %t189 = load i1, ptr %l119, !tbaa !21
  br i1 %t189, label %bb57, label %bb58
bb57:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb74
bb59:
  %t196 = load ptr, ptr %l7, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Match", ptr %t196, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  %t205 = load i64, ptr %l9, !tbaa !24
  %t206 = load i64, ptr %l10, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t213 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t213, ptr %l132, !tbaa !27
  %t214 = load i64, ptr %l9, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Arm", ptr %t219, i32 0, i32 4
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load i64, ptr %l2, !tbaa !24
  %t228 = add i64 %t226, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t221, ptr %t225, i64 %t228)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l9, !tbaa !24
  br label %bb60
bb66:
  %t237 = load ptr, ptr %l7, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Match", ptr %t237, i32 0, i32 2
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = icmp eq ptr %t240, null
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb67, label %bb68
bb67:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l147, !tbaa !29
  %t247 = load ptr, ptr %l7, !tbaa !29
  %t249 = getelementptr %"compiler/typed:Match", ptr %t247, i32 0, i32 2
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb69, label %bb70
bb68:
  br label %bb73
bb69:
  call void @__olang_check_failed(ptr @olang_loc_488be308cffaf13e_20c0e7cb8e30f352)
  unreachable
bb70:
  br label %bb71
bb71:
  %t254 = load ptr, ptr %l7, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Match", ptr %t254, i32 0, i32 2
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t260 = getelementptr %"compiler/typed:Arm", ptr %t257, i32 0, i32 4
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t262 = load i64, ptr %l2, !tbaa !24
  %t264 = add i64 %t262, 1
  %t265 = load ptr, ptr %l147, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t265, ptr %t261, i64 %t264)
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb183
bb74:
  %t268 = load ptr, ptr %l1, !tbaa !29
  store ptr %t268, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t269 = load ptr, ptr %l157, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb75, label %bb76
bb75:
  %t272 = load ptr, ptr %l157, !tbaa !29
  %t273 = load i64, ptr %t272, !range !{i64 0, i64 18}
  %t275 = icmp eq i64 %t273, 14
  store i1 %t275, ptr %l158, !tbaa !21
  br label %bb76
bb76:
  %t276 = load i1, ptr %l158, !tbaa !21
  br i1 %t276, label %bb77, label %bb78
bb77:
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t279, i32 0, i32 2
  %t281 = load ptr, ptr %t280
  store ptr %t281, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb94
bb79:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Try", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t288 = load i64, ptr %l2, !tbaa !24
  %t290 = add i64 %t288, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t283, ptr %t287, i64 %t290)
  br label %bb80
bb80:
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Try", ptr %t294, i32 0, i32 1
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  store { i64, ptr } %t297, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l15, !tbaa !24
  br label %bb81
bb81:
  %t303 = load i64, ptr %l14, !tbaa !24
  %t304 = load i64, ptr %l15, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb82, label %bb83
bb82:
  br label %bb93
bb83:
  br label %bb84
bb84:
  %t311 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t311, ptr %l176, !tbaa !27
  %t312 = load i64, ptr %l14, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 %t312
  %t317 = load ptr, ptr %t316, !tbaa !39
  %t321 = getelementptr %"compiler/typed:Clause", ptr %t317, i32 0, i32 4
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t324 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  store i64 %t326, ptr %l19, !tbaa !24
  br label %bb85
bb85:
  %t328 = load i64, ptr %l18, !tbaa !24
  %t329 = load i64, ptr %l19, !tbaa !24
  %t332 = icmp slt i64 %t328, %t329
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb86, label %bb87
bb86:
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t336 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t336, ptr %l187, !tbaa !27
  %t337 = load i64, ptr %l18, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr ptr, ptr %t340, i64 %t337
  %t342 = load ptr, ptr %t341, !tbaa !39
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i64, ptr %l2, !tbaa !24
  %t349 = add i64 %t347, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t344, ptr %t342, i64 %t349)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t353 = load i64, ptr %l18, !tbaa !24
  %t356 = add i64 %t353, 1
  store i64 %t356, ptr %l18, !tbaa !24
  br label %bb85
bb91:
  br label %bb92
bb92:
  %t358 = load i64, ptr %l14, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l14, !tbaa !24
  br label %bb81
bb93:
  br label %bb183
bb94:
  %t363 = load ptr, ptr %l1, !tbaa !29
  store ptr %t363, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t364 = load ptr, ptr %l201, !tbaa !29
  %t365 = icmp ne ptr %t364, null
  br i1 %t365, label %bb95, label %bb96
bb95:
  %t367 = load ptr, ptr %l201, !tbaa !29
  %t368 = load i64, ptr %t367, !range !{i64 0, i64 18}
  %t370 = icmp eq i64 %t368, 12
  store i1 %t370, ptr %l202, !tbaa !21
  br label %bb96
bb96:
  %t371 = load i1, ptr %l202, !tbaa !21
  br i1 %t371, label %bb97, label %bb98
bb97:
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [5 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l21, !tbaa !29
  br label %bb99
bb98:
  br label %bb110
bb99:
  %t378 = load ptr, ptr %l21, !tbaa !29
  %t380 = getelementptr %"compiler/typed:Seq", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  br i1 %t383, label %bb100, label %bb101
bb100:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/effects:Effects", ptr %t385, i32 0, i32 38
  store ptr %t387, ptr %l211, !tbaa !29
  %t388 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t388, ptr %l212, !tbaa !24
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t389)
  store i32 %t391, ptr %l214
  br label %bb102
bb101:
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l216, !tbaa !29
  %t393 = load ptr, ptr %l21, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Seq", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb105, label %bb106
bb102:
  %t400 = load i64, ptr %l212, !tbaa !24
  %t401 = load i32, ptr %l214, !tbaa !23
  %t402 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t400, i64 0, i32 %t401, ptr null)
  store %"compiler/effects:part" %t402, ptr %l215
  br label %bb103
bb103:
  %t403 = load ptr, ptr %l211, !tbaa !29
  %t404 = load %"compiler/effects:part", ptr %l215
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t403, %"compiler/effects:part" %t404)
  br label %bb104
bb104:
  br label %bb109
bb105:
  call void @__olang_check_failed(ptr @olang_loc_59fe423ba48f95ef_125e5ca5a1678c93)
  unreachable
bb106:
  br label %bb107
bb107:
  %t405 = load ptr, ptr %l21, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Seq", ptr %t405, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = load i64, ptr %l2, !tbaa !24
  %t412 = add i64 %t410, 1
  %t413 = load ptr, ptr %l216, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t413, ptr %t408, i64 %t412)
  br label %bb108
bb108:
  br label %bb109
bb109:
  br label %bb183
bb110:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t417 = load ptr, ptr %l225, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb111, label %bb112
bb111:
  %t420 = load ptr, ptr %l225, !tbaa !29
  %t421 = load i64, ptr %t420, !range !{i64 0, i64 18}
  %t423 = icmp eq i64 %t421, 15
  store i1 %t423, ptr %l226, !tbaa !21
  br label %bb112
bb112:
  %t424 = load i1, ptr %l226, !tbaa !21
  br i1 %t424, label %bb113, label %bb114
bb113:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t427, i32 0, i32 2
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l22, !tbaa !29
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/effects:Effects", ptr %t431, i32 0, i32 38
  store ptr %t433, ptr %l232, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l22, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t440 = call %"compiler/effects:part" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnPart(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t434, ptr %t435, ptr %t436)
  store %"compiler/effects:part" %t440, ptr %l236
  br label %bb116
bb116:
  %t441 = load ptr, ptr %l232, !tbaa !29
  %t442 = load %"compiler/effects:part", ptr %l236
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %t441, %"compiler/effects:part" %t442)
  br label %bb117
bb117:
  br label %bb183
bb118:
  %t443 = load ptr, ptr %l1, !tbaa !29
  store ptr %t443, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t444 = load ptr, ptr %l237, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb119, label %bb120
bb119:
  %t447 = load ptr, ptr %l237, !tbaa !29
  %t448 = load i64, ptr %t447, !range !{i64 0, i64 18}
  %t450 = icmp eq i64 %t448, 2
  store i1 %t450, ptr %l238, !tbaa !21
  br label %bb120
bb120:
  %t451 = load i1, ptr %l238, !tbaa !21
  br i1 %t451, label %bb121, label %bb122
bb121:
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr { i64, [5 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t454, i32 0, i32 2
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t457 = load ptr, ptr %l243, !tbaa !29
  %t458 = icmp ne ptr %t457, null
  br i1 %t458, label %bb123, label %bb124
bb122:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb125
bb123:
  %t460 = load ptr, ptr %l243, !tbaa !29
  %t461 = load i64, ptr %t460, !range !{i64 0, i64 8}
  %t463 = icmp eq i64 %t461, 0
  store i1 %t463, ptr %l244, !tbaa !21
  br label %bb124
bb124:
  %t464 = load i1, ptr %l244, !tbaa !21
  store i1 %t464, ptr %l241, !tbaa !21
  br label %bb125
bb125:
  %t465 = load i1, ptr %l241, !tbaa !21
  br i1 %t465, label %bb126, label %bb127
bb126:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t468, i32 0, i32 1
  %t470 = load i32, ptr %t469
  store i32 %t470, ptr %l23, !tbaa !23
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [5 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t474, i32 0, i32 2
  %t476 = load ptr, ptr %t475
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t478, i32 0, i32 2
  %t480 = load i32, ptr %t479
  store i32 %t480, ptr %l24, !tbaa !23
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l24, !tbaa !23
  %t485 = sext i32 %t483 to i64
  %t486 = load i32, ptr %l23, !tbaa !23
  %t487 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyLocal(ptr %v0, ptr %t482, i64 %t485, i32 %t486, i64 %t487)
  br label %bb129
bb129:
  br label %bb183
bb130:
  %t492 = load ptr, ptr %l1, !tbaa !29
  store ptr %t492, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t493 = load ptr, ptr %l257, !tbaa !29
  %t494 = icmp ne ptr %t493, null
  br i1 %t494, label %bb131, label %bb132
bb131:
  %t496 = load ptr, ptr %l257, !tbaa !29
  %t497 = load i64, ptr %t496, !range !{i64 0, i64 18}
  %t499 = icmp eq i64 %t497, 2
  store i1 %t499, ptr %l258, !tbaa !21
  br label %bb132
bb132:
  %t500 = load i1, ptr %l258, !tbaa !21
  br i1 %t500, label %bb133, label %bb134
bb133:
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [5 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t503, i32 0, i32 1
  %t505 = load i32, ptr %t504
  store i32 %t505, ptr %l25, !tbaa !23
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t509, i32 0, i32 2
  %t511 = load ptr, ptr %t510
  store ptr %t511, ptr %l26, !tbaa !29
  br label %bb135
bb134:
  br label %bb145
bb135:
  %t513 = load ptr, ptr %l26, !tbaa !29
  store ptr %t513, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t514 = load ptr, ptr %l265, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb136, label %bb137
bb136:
  %t517 = load ptr, ptr %l265, !tbaa !29
  %t518 = load i64, ptr %t517, !range !{i64 0, i64 8}
  %t520 = icmp eq i64 %t518, 3
  store i1 %t520, ptr %l266, !tbaa !21
  br label %bb137
bb137:
  %t521 = load i1, ptr %l266, !tbaa !21
  br i1 %t521, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s28
  %t522 = load ptr, ptr %l26, !tbaa !29
  %t524 = getelementptr { i64, [4 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t524, i32 0, i32 0
  %t526 = load %"compiler/source:Span", ptr %t525
  store %"compiler/source:Span" %t526, ptr %l27
  %t528 = load ptr, ptr %l26, !tbaa !29
  %t530 = getelementptr { i64, [4 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t530, i32 0, i32 1
  %t532 = load i32, ptr %t531
  store i32 %t532, ptr %l28, !tbaa !23
  %t534 = load ptr, ptr %l26, !tbaa !29
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t536, i32 0, i32 2
  %t538 = load ptr, ptr %t537
  store ptr %t538, ptr %l29, !tbaa !29
  %t540 = load ptr, ptr %l26, !tbaa !29
  %t542 = getelementptr { i64, [4 x i64] }, ptr %t540, i32 0, i32 1
  %t543 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t542, i32 0, i32 3
  %t544 = load i64, ptr %t543
  store i64 %t544, ptr %l30, !tbaa !24
  %t546 = load ptr, ptr %l0, !tbaa !29
  store ptr %t546, ptr %l277, !tbaa !29
  %t547 = load ptr, ptr %l26, !tbaa !29
  store ptr %t547, ptr %l278, !tbaa !29
  %t548 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s28, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t548, ptr %l279
  br label %bb140
bb139:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/effects:Effects", ptr %t549, i32 0, i32 38
  store ptr %t551, ptr %l283, !tbaa !29
  %t552 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t553 = load i32, ptr %l25, !tbaa !23
  %t556 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t552, i64 0, i32 %t553, ptr null)
  store %"compiler/effects:part" %t556, ptr %l286
  br label %bb142
bb140:
  %t557 = load i32, ptr %l25, !tbaa !23
  %t558 = load i64, ptr %l2, !tbaa !24
  %t559 = load ptr, ptr %l277, !tbaa !29
  %t560 = load ptr, ptr %l278, !tbaa !29
  %t561 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l279
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyField(ptr %v0, ptr %v1, ptr %s28, ptr %t559, ptr %t560, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t561, i32 %t557, i64 %t558)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s28)
  br label %bb144
bb142:
  %t564 = load ptr, ptr %l283, !tbaa !29
  %t565 = load %"compiler/effects:part", ptr %l286
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t564, %"compiler/effects:part" %t565)
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb183
bb145:
  %t566 = load ptr, ptr %l1, !tbaa !29
  store ptr %t566, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t567 = load ptr, ptr %l287, !tbaa !29
  %t568 = icmp ne ptr %t567, null
  br i1 %t568, label %bb146, label %bb147
bb146:
  %t570 = load ptr, ptr %l287, !tbaa !29
  %t571 = load i64, ptr %t570, !range !{i64 0, i64 18}
  %t573 = icmp eq i64 %t571, 0
  store i1 %t573, ptr %l288, !tbaa !21
  br label %bb147
bb147:
  %t574 = load i1, ptr %l288, !tbaa !21
  br i1 %t574, label %bb148, label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb154
bb150:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = getelementptr %"compiler/effects:Effects", ptr %t575, i32 0, i32 38
  store ptr %t577, ptr %l292, !tbaa !29
  %t578 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  store i64 %t578, ptr %l293, !tbaa !24
  %t579 = load ptr, ptr %l1, !tbaa !29
  %t581 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t579)
  store i32 %t581, ptr %l295
  br label %bb151
bb151:
  %t582 = load i64, ptr %l293, !tbaa !24
  %t583 = load i32, ptr %l295, !tbaa !23
  %t584 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t582, i64 0, i32 %t583, ptr null)
  store %"compiler/effects:part" %t584, ptr %l296
  br label %bb152
bb152:
  %t585 = load ptr, ptr %l292, !tbaa !29
  %t586 = load %"compiler/effects:part", ptr %l296
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t585, %"compiler/effects:part" %t586)
  br label %bb153
bb153:
  br label %bb183
bb154:
  %t587 = load ptr, ptr %l1, !tbaa !29
  store ptr %t587, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t588 = load ptr, ptr %l297, !tbaa !29
  %t589 = icmp ne ptr %t588, null
  br i1 %t589, label %bb155, label %bb156
bb155:
  %t591 = load ptr, ptr %l297, !tbaa !29
  %t592 = load i64, ptr %t591, !range !{i64 0, i64 18}
  %t594 = icmp eq i64 %t592, 6
  store i1 %t594, ptr %l298, !tbaa !21
  br label %bb156
bb156:
  %t595 = load i1, ptr %l298, !tbaa !21
  br i1 %t595, label %bb157, label %bb158
bb157:
  %t596 = load ptr, ptr %l1, !tbaa !29
  %t598 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 1
  %t599 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t598, i32 0, i32 1
  %t600 = load i32, ptr %t599
  store i32 %t600, ptr %l31, !tbaa !23
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t604, i32 0, i32 2
  %t606 = load ptr, ptr %t605
  store ptr %t606, ptr %l32, !tbaa !29
  br label %bb159
bb158:
  br label %bb175
bb159:
  %t608 = load ptr, ptr %l32, !tbaa !29
  %t610 = getelementptr %"compiler/typed:Call", ptr %t608, i32 0, i32 0
  %t611 = load ptr, ptr %t610, !tbaa !29
  store ptr %t611, ptr %l33, !tbaa !29
  %t613 = load ptr, ptr %l33, !tbaa !29
  store ptr %t613, ptr %l307, !tbaa !29
  store i1 false, ptr %l308, !tbaa !21
  %t614 = load ptr, ptr %l307, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb160, label %bb161
bb160:
  %t617 = load ptr, ptr %l307, !tbaa !29
  %t618 = load i64, ptr %t617, !range !{i64 0, i64 5}
  %t620 = icmp eq i64 %t618, 0
  store i1 %t620, ptr %l308, !tbaa !21
  br label %bb161
bb161:
  %t621 = load i1, ptr %l308, !tbaa !21
  br i1 %t621, label %bb162, label %bb163
bb162:
  %t622 = load ptr, ptr %l33, !tbaa !29
  %t624 = getelementptr { i64, [3 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { i32 }, ptr %t624, i32 0, i32 0
  %t626 = load i32, ptr %t625
  store i32 %t626, ptr %l34, !tbaa !23
  br label %bb164
bb163:
  br label %bb167
bb164:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/effects:Effects", ptr %t628, i32 0, i32 38
  store ptr %t630, ptr %l314, !tbaa !29
  %t631 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t632 = load i32, ptr %l34, !tbaa !23
  %t634 = sext i32 %t632 to i64
  %t635 = load i32, ptr %l31, !tbaa !23
  %t639 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t631, i64 %t634, i32 %t635, ptr null)
  store %"compiler/effects:part" %t639, ptr %l319
  br label %bb165
bb165:
  %t640 = load ptr, ptr %l314, !tbaa !29
  %t641 = load %"compiler/effects:part", ptr %l319
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t640, %"compiler/effects:part" %t641)
  br label %bb166
bb166:
  br label %bb174
bb167:
  br i1 true, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb173
bb170:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = getelementptr %"compiler/effects:Effects", ptr %t642, i32 0, i32 38
  store ptr %t644, ptr %l321, !tbaa !29
  %t645 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t646 = load i32, ptr %l31, !tbaa !23
  %t649 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t645, i64 0, i32 %t646, ptr null)
  store %"compiler/effects:part" %t649, ptr %l324
  br label %bb171
bb171:
  %t650 = load ptr, ptr %l321, !tbaa !29
  %t651 = load %"compiler/effects:part", ptr %l324
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t650, %"compiler/effects:part" %t651)
  br label %bb172
bb172:
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_8e13f40ea2f1e4d7_76f885d7d8afa3eb)
  unreachable
bb174:
  br label %bb183
bb175:
  br i1 true, label %bb176, label %bb177
bb176:
  br label %bb178
bb177:
  br label %bb182
bb178:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/effects:Effects", ptr %t652, i32 0, i32 38
  store ptr %t654, ptr %l326, !tbaa !29
  %t655 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t655, ptr %l327, !tbaa !24
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t656)
  store i32 %t658, ptr %l329
  br label %bb179
bb179:
  %t659 = load i64, ptr %l327, !tbaa !24
  %t660 = load i32, ptr %l329, !tbaa !23
  %t661 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t659, i64 0, i32 %t660, ptr null)
  store %"compiler/effects:part" %t661, ptr %l330
  br label %bb180
bb180:
  %t662 = load ptr, ptr %l326, !tbaa !29
  %t663 = load %"compiler/effects:part", ptr %l330
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t662, %"compiler/effects:part" %t663)
  br label %bb181
bb181:
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_2b1992bc034d4ac0_3aae813f6df6734c)
  unreachable
bb183:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyCallInst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca %"compiler/effects:part"
  %l38 = alloca ptr
  %l46 = alloca %"compiler/effects:part"
  %l47 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca %"compiler/effects:part"
  %l94 = alloca i64
  %l98 = alloca { i64, ptr }
  %l104 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l131 = alloca ptr
  %l134 = alloca i64
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l6, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l6, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l19, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l19, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_46f184d5298e32c_10b291f73bcbacf0)
  unreachable
bb11:
  %t25 = load i64, ptr %l19, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp slt i64 %t26, 0
  br i1 %t28, label %bb12, label %bb13
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Effects", ptr %t30, i32 0, i32 38
  store ptr %t32, ptr %l31, !tbaa !29
  %t33 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t33, i64 0, i32 %t34, ptr null)
  store %"compiler/effects:part" %t37, ptr %l34
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t38 = load ptr, ptr %l31, !tbaa !29
  %t39 = load %"compiler/effects:part", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t38, %"compiler/effects:part" %t39)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/effects:Effects", ptr %t40, i32 0, i32 1
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store ptr %t46, ptr %l38
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l38, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 1
  %t50 = load { i64, [2 x i64] }, ptr %t49
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 1
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i32, ptr %l3, !tbaa !23
  %t63 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t57, i64 %t58, i32 %t59, ptr null)
  store %"compiler/effects:part" %t63, ptr %l46
  br label %bb20
bb19:
  br label %bb40
bb20:
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t64, ptr %lp8
  %t65 = load %"compiler/effects:part", ptr %l46
  %t66 = load ptr, ptr %lp8
  store %"compiler/effects:part" %t65, ptr %t66
  %t67 = call ptr @__olang_scope_hold(ptr %v0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l47, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = call ptr @__olang_region_make(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l47, !tbaa !24
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l51
  %t77 = load i64, ptr %l47
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l52, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t83 = load i64, ptr %l47
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = call ptr @__olang_region_make_part(ptr %t84)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l52, !tbaa !24
  br label %bb24
bb24:
  %t87 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l54, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l55, !tbaa !24
  %t91 = load i64, ptr %l55, !tbaa !24
  %t92 = mul i64 %t91, 8
  %t93 = load i64, ptr %l52
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call ptr @__olang_held_alloc(ptr %t94, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l55, !tbaa !24
  %t103 = mul i64 %t102, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t105 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  store { i64, ptr } %t104, ptr %t105, !tbaa !27
  %t106 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t108 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb27, label %bb28
bb26:
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t114, label %bb29, label %bb30
bb27:
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t116, !tbaa !27
  br label %bb28
bb28:
  %t117 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t118 = load i64, ptr %l52
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load { i64, ptr }, ptr %t117
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_settle_in(ptr %t119, ptr %t124)
  br label %bb26
bb29:
  %t125 = load i64, ptr %l47
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = call ptr @__olang_region_home(ptr %t130)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr null
  call void @__olang_region_settle_in(ptr %t126, ptr %t133)
  br label %bb30
bb30:
  %t134 = load ptr, ptr %lp8
  %t135 = getelementptr %"compiler/effects:part", ptr %t134, i32 0, i32 4
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l61
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t138 = load ptr, ptr %lp8
  %t139 = getelementptr %"compiler/effects:part", ptr %t138, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %t139
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t140, label %bb31, label %bb32
bb31:
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = call ptr @__olang_region_or(ptr %t144, ptr null)
  %t146 = call ptr @__olang_region_home(ptr %t145)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr null
  call void @__olang_region_drop(ptr %t148)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l61
  br label %bb32
bb32:
  %t149 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t149, label %bb33, label %bb34
bb33:
  %t151 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t152 = load { i64, ptr }, ptr %t151
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  call void @__olang_region_release_part(ptr %t154, i64 %t153)
  store { i64, ptr } zeroinitializer, ptr %t151
  br label %bb34
bb34:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/effects:Effects", ptr %t155, i32 0, i32 68
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %t160, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t166 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t157, i64 %t163)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l71
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb36, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l70
  br label %bb35
bb35:
  %t171 = load i64, ptr %l70, !tbaa !24
  store i64 %t171, ptr %l64, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  store i64 -1, ptr %l64, !tbaa !24
  br label %bb38
bb38:
  %t172 = load i64, ptr %l64, !tbaa !24
  %t173 = load ptr, ptr %lp8
  %t174 = getelementptr %"compiler/effects:part", ptr %t173, i32 0, i32 5
  store i64 %t172, ptr %t174, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/effects:Effects", ptr %t175, i32 0, i32 38
  %t178 = load ptr, ptr %lp8
  %t179 = load %"compiler/effects:part", ptr %t178
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t177, %"compiler/effects:part" %t179)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l75, !tbaa !29
  %t183 = load i64, ptr %l7, !tbaa !24
  store i64 %t183, ptr %l76, !tbaa !24
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t184, i64 0)
  store i64 %t186, ptr %l78
  br label %bb41
bb41:
  %t187 = load ptr, ptr %l75, !tbaa !29
  %t188 = load i64, ptr %l76, !tbaa !24
  %t189 = load i64, ptr %l78, !tbaa !24
  %t190 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorArg(ptr %v0, ptr %t187, i64 %t188, i64 %t189)
  store i64 %t190, ptr %l79
  br label %bb42
bb42:
  %t191 = load i64, ptr %l79, !tbaa !24
  store i64 %t191, ptr %l9, !tbaa !24
  %t192 = load i64, ptr %l9, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb45
bb44:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Call", ptr %t197, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t205 = icmp sge i64 %t196, %t202
  store i1 %t205, ptr %l82, !tbaa !21
  br label %bb45
bb45:
  %t207 = load i1, ptr %l82, !tbaa !21
  br i1 %t207, label %bb46, label %bb47
bb46:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/effects:Effects", ptr %t208, i32 0, i32 38
  store ptr %t210, ptr %l89, !tbaa !29
  %t211 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t212 = load i32, ptr %l3, !tbaa !23
  %t215 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t211, i64 0, i32 %t212, ptr null)
  store %"compiler/effects:part" %t215, ptr %l92
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t216 = load ptr, ptr %l89, !tbaa !29
  %t217 = load %"compiler/effects:part", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t216, %"compiler/effects:part" %t217)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t218)
  store i64 %t220, ptr %l94
  br label %bb51
bb51:
  %t221 = load i64, ptr %l94, !tbaa !24
  %t222 = icmp eq i64 %t221, 1
  br i1 %t222, label %bb52, label %bb53
bb52:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Call", ptr %t225, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l98, !tbaa !27
  %t229 = load i64, ptr %l9, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 %t229
  %t234 = load ptr, ptr %t233, !tbaa !39
  %t236 = load i64, ptr %l4, !tbaa !24
  %t238 = add i64 %t236, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t224, ptr %t234, i64 %t238)
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb55:
  %t242 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t242, ptr %l104
  br label %bb56
bb56:
  %t243 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l10
  store i64 1, ptr %l11, !tbaa !24
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t244)
  store i64 %t246, ptr %l106
  br label %bb57
bb57:
  %t247 = load i64, ptr %l106, !tbaa !24
  store i64 %t247, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t248 = load i64, ptr %l12, !tbaa !24
  %t249 = load i64, ptr %l11, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb58, label %bb59
bb58:
  %t254 = load i64, ptr %l13, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb63
bb60:
  %t258 = load i64, ptr %l12, !tbaa !24
  %t259 = load i64, ptr %l11, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l13, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l13, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l113, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb62
bb62:
  %t274 = load i64, ptr %l113, !tbaa !24
  store i64 %t274, ptr %l110, !tbaa !24
  br label %bb63
bb63:
  %t275 = load i64, ptr %l110, !tbaa !24
  store i64 %t275, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb64
bb64:
  %t276 = load i64, ptr %l15, !tbaa !24
  %t277 = load i64, ptr %l14, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t284 = load i64, ptr %l11, !tbaa !24
  %t285 = load i64, ptr %l15, !tbaa !24
  %t286 = load i64, ptr %l13, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store ptr %l10, ptr %l131, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t294, i64 %t292)
  store i64 %t298, ptr %l134
  br label %bb68
bb68:
  %t299 = load ptr, ptr %l131, !tbaa !29
  %t300 = load i64, ptr %l134, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t299, i64 %t300)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t301 = load i64, ptr %l15, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l15, !tbaa !24
  br label %bb64
bb71:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Call", ptr %t307, i32 0, i32 1
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l140, !tbaa !27
  %t311 = load i64, ptr %l9, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr ptr, ptr %t314, i64 %t311
  %t316 = load ptr, ptr %t315, !tbaa !39
  %t317 = load i32, ptr %l3, !tbaa !23
  %t318 = load i64, ptr %l4, !tbaa !24
  %t320 = add i64 %t318, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %s0, ptr %t306, ptr %t316, ptr %l10, i32 %t317, i64 %t320)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i1
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca %"compiler/effects:part"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca %"compiler/effects:part"
  %l46 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca %"compiler/effects:part"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb2:
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %l2)
  store i64 %t6, ptr %l17
  br label %bb3
bb3:
  %t7 = load i64, ptr @G_2ecompiler_2feffects_2eFieldDepth, !tbaa !24
  %t8 = load i64, ptr %l17, !tbaa !24
  %t10 = icmp sgt i64 %t8, %t7
  store i1 %t10, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t12 = load i1, ptr %l15, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 38
  store ptr %t15, ptr %l21, !tbaa !29
  %t16 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t16, i64 0, i32 %t17, ptr null)
  store %"compiler/effects:part" %t20, ptr %l24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t21 = load ptr, ptr %l21, !tbaa !29
  %t22 = load %"compiler/effects:part", ptr %l24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t21, %"compiler/effects:part" %t22)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l25, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 8}
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l26, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 3
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb37
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l33, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t46)
  store i32 %t48, ptr %l36
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = load i32, ptr %l36, !tbaa !23
  %t51 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l37
  br label %bb16
bb16:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t54 = load i32, ptr %l37, !tbaa !23
  %t56 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efixed(ptr %v0, ptr %t53, i32 %t54, i64 %t52)
  store i1 %t56, ptr %l39
  br label %bb17
bb17:
  %t57 = load i1, ptr %l39, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/effects:Effects", ptr %t60, i32 0, i32 38
  store ptr %t62, ptr %l42, !tbaa !29
  %t63 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t63, i64 0, i32 %t64, ptr null)
  store %"compiler/effects:part" %t67, ptr %l45
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t68 = load ptr, ptr %l42, !tbaa !29
  %t69 = load %"compiler/effects:part", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t68, %"compiler/effects:part" %t69)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t70 = call ptr @__olang_scope_hold(ptr %s2)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2estd_2fprelude_2farray_3aArrayIter_3cI64_3e_2e0
  br i1 %t72, label %bb23, label %bb24
bb23:
  %t74 = call ptr @__olang_region_make(ptr %s2)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l46, !tbaa !24
  br label %bb24
bb24:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = mul i64 1, 8
  %t78 = load i64, ptr %l46
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %t79, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 1, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l49, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 0
  store i64 %t76, ptr %t86, !tbaa !34
  %t87 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t88 = call %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %s2, ptr %s2, { i64, ptr } %t87)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t88, ptr %l50
  br label %bb25
bb25:
  %t89 = load %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381", ptr %l50
  %t90 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 24, i64 8)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t89, ptr %t90
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %s2, ptr %s2, ptr %t90)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l52
  br label %bb26
bb26:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l7
  store ptr %l2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  %t95 = load i64, ptr %l9, !tbaa !24
  store i64 %t95, ptr %l54, !tbaa !24
  %t96 = load ptr, ptr %l8, !tbaa !29
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t96)
  store i64 %t98, ptr %l56
  br label %bb28
bb28:
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = load i64, ptr %l56, !tbaa !24
  %t101 = icmp slt i64 %t99, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t105 = load ptr, ptr %l8, !tbaa !29
  %t106 = load i64, ptr %l9, !tbaa !24
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l61
  br label %bb32
bb32:
  %t110 = load i64, ptr %l61, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l7, i64 %t110)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb27
bb35:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t122 = load i32, ptr %l3, !tbaa !23
  %t123 = load i64, ptr %l4, !tbaa !24
  %t125 = add i64 %t123, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyField(ptr %v0, ptr %v1, ptr %s2, ptr %t119, ptr %t120, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, i32 %t122, i64 %t125)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb37:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t132 = load ptr, ptr %l73, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb38, label %bb39
bb38:
  %t135 = load ptr, ptr %l73, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 0
  store i1 %t138, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t139 = load i1, ptr %l74, !tbaa !21
  br i1 %t139, label %bb40, label %bb41
bb40:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l11, !tbaa !23
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l11, !tbaa !23
  %t149 = sext i32 %t147 to i64
  %t150 = load i32, ptr %l3, !tbaa !23
  %t151 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInstLocal(ptr %v0, ptr %v2, ptr %t146, i64 %t149, ptr %l2, i32 %t150, i64 %t151)
  br label %bb43
bb43:
  br label %bb58
bb44:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t158 = load ptr, ptr %l85, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l85, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 8}
  %t164 = icmp eq i64 %t162, 2
  store i1 %t164, ptr %l86, !tbaa !21
  br label %bb46
bb46:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb47, label %bb48
bb47:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t168, i32 0, i32 2
  %t170 = load ptr, ptr %t169
  store ptr %t170, ptr %l12, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l12, !tbaa !29
  %t174 = load i32, ptr %l3, !tbaa !23
  %t175 = load i64, ptr %l4, !tbaa !24
  %t177 = add i64 %t175, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %t172, ptr %t173, ptr %l2, i32 %t174, i64 %t177)
  br label %bb50
bb50:
  br label %bb58
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/effects:Effects", ptr %t183, i32 0, i32 38
  store ptr %t185, ptr %l98, !tbaa !29
  %t186 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t187 = load i32, ptr %l3, !tbaa !23
  %t190 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t186, i64 0, i32 %t187, ptr null)
  store %"compiler/effects:part" %t190, ptr %l101
  br label %bb55
bb55:
  %t191 = load ptr, ptr %l98, !tbaa !29
  %t192 = load %"compiler/effects:part", ptr %l101
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t191, %"compiler/effects:part" %t192)
  br label %bb56
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_3535a9392f714f10_e154cce5335d35ec)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca %"compiler/effects:part"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca %"compiler/effects:part"
  %l90 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i1
  %l119 = alloca ptr
  %l122 = alloca %"compiler/effects:part"
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 38
  store ptr %t7, ptr %l13, !tbaa !29
  %t8 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t9 = load i32, ptr %l3, !tbaa !23
  %t12 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t8, i64 0, i32 %t9, ptr null)
  store %"compiler/effects:part" %t12, ptr %l16
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = load %"compiler/effects:part", ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t13, %"compiler/effects:part" %t14)
  br label %bb4
bb4:
  br label %ret
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 17
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l5, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t32, i32 %t33, i64 %t36)
  br label %bb11
bb11:
  br label %bb70
bb12:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t43 = load ptr, ptr %l29, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 5
  store i1 %t49, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l30, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Promote", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t64, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %t57, ptr %t61, ptr %t62, i32 %t63, i64 %t66)
  br label %bb18
bb18:
  br label %bb70
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t73 = load ptr, ptr %l42, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l42, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 2
  store i1 %t79, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l7, !tbaa !29
  br label %bb32
bb23:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l7, !tbaa !29
  br label %bb32
bb27:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t103 = load ptr, ptr %l54, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb28, label %bb29
bb28:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 4
  store i1 %t109, ptr %l55, !tbaa !21
  br label %bb29
bb29:
  %t110 = load i1, ptr %l55, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb32
bb31:
  br label %bb40
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l60, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  store ptr %t118, ptr %l61, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l64
  %t123 = call ptr @__olang_scope_hold(ptr %s4)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l65, !tbaa !24
  %t125 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = call ptr @__olang_region_make_part(ptr %s4)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l65, !tbaa !24
  br label %bb34
bb34:
  %t129 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l67, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l68, !tbaa !24
  %t133 = load i64, ptr %l68, !tbaa !24
  %t134 = mul i64 %t133, 8
  %t135 = load i64, ptr %l65
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = call ptr @__olang_held_alloc(ptr %t136, i64 %t134)
  %t138 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l69, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l68, !tbaa !24
  %t145 = mul i64 %t144, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  %t146 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t147 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  store { i64, ptr } %t146, ptr %t147, !tbaa !27
  %t148 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t150 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t154 = icmp eq i64 %t152, 0
  br i1 %t154, label %bb37, label %bb38
bb36:
  %t156 = load i32, ptr %l3, !tbaa !23
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = add i64 %t157, 1
  %t160 = load ptr, ptr %l60, !tbaa !29
  %t161 = load ptr, ptr %l61, !tbaa !29
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyField(ptr %v0, ptr %v1, ptr %s4, ptr %t160, ptr %t161, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, i32 %t156, i64 %t159)
  br label %bb39
bb37:
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t165, !tbaa !27
  br label %bb38
bb38:
  %t166 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t167 = load i64, ptr %l65
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = load { i64, ptr }, ptr %t166
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  call void @__olang_region_settle_in(ptr %t168, ptr %t173)
  br label %bb36
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb40:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t175 = load ptr, ptr %l76, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb41, label %bb42
bb41:
  %t178 = load ptr, ptr %l76, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 18}
  %t181 = icmp eq i64 %t179, 11
  store i1 %t181, ptr %l77, !tbaa !21
  br label %bb42
bb42:
  %t182 = load i1, ptr %l77, !tbaa !21
  br i1 %t182, label %bb43, label %bb44
bb43:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l8, !tbaa !29
  br label %bb45
bb44:
  br label %bb56
bb45:
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Cond", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb46, label %bb47
bb46:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/effects:Effects", ptr %t196, i32 0, i32 38
  store ptr %t198, ptr %l86, !tbaa !29
  %t199 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t200 = load i32, ptr %l3, !tbaa !23
  %t203 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t199, i64 0, i32 %t200, ptr null)
  store %"compiler/effects:part" %t203, ptr %l89
  br label %bb48
bb47:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l90, !tbaa !29
  %t205 = load ptr, ptr %l8, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Cond", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb50, label %bb51
bb48:
  %t212 = load ptr, ptr %l86, !tbaa !29
  %t213 = load %"compiler/effects:part", ptr %l89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t212, %"compiler/effects:part" %t213)
  br label %bb49
bb49:
  br label %bb54
bb50:
  call void @__olang_check_failed(ptr @olang_loc_7a6d7e31a8c94555_e5f55f7e2b9f5a99)
  unreachable
bb51:
  br label %bb52
bb52:
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Cond", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t219 = load i32, ptr %l3, !tbaa !23
  %t220 = load i64, ptr %l4, !tbaa !24
  %t222 = add i64 %t220, 1
  %t223 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %t223, ptr %t217, ptr %t218, i32 %t219, i64 %t222)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l8, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Cond", ptr %t229, i32 0, i32 2
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t235 = load i64, ptr %l4, !tbaa !24
  %t237 = add i64 %t235, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %t228, ptr %t232, ptr %t233, i32 %t234, i64 %t237)
  br label %bb55
bb55:
  br label %bb70
bb56:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t244 = load ptr, ptr %l107, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb57, label %bb58
bb57:
  %t247 = load ptr, ptr %l107, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 18}
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l108, !tbaa !21
  br label %bb58
bb58:
  %t251 = load i1, ptr %l108, !tbaa !21
  br i1 %t251, label %bb59, label %bb60
bb59:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l9, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i32, ptr %l3, !tbaa !23
  %t262 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyCallInst(ptr %v0, ptr %v1, ptr %v2, ptr %t258, ptr %t259, ptr %t260, i32 %t261, i64 %t262)
  br label %bb62
bb62:
  br label %bb70
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/effects:Effects", ptr %t268, i32 0, i32 38
  store ptr %t270, ptr %l119, !tbaa !29
  %t271 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t272 = load i32, ptr %l3, !tbaa !23
  %t275 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t271, i64 0, i32 %t272, ptr null)
  store %"compiler/effects:part" %t275, ptr %l122
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l119, !tbaa !29
  %t277 = load %"compiler/effects:part", ptr %l122
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t276, %"compiler/effects:part" %t277)
  br label %bb68
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ac8d93ad38a597bd_9a80442872e097e1)
  unreachable
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInstLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca %"compiler/effects:part"
  %l44 = alloca %"compiler/effects:part"
  %l47 = alloca %"compiler/effects:part"
  %l51 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca %"compiler/effects:part"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i32
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 31
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l16
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l11, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/effects:Effects", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 35
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t25)
  store ptr %t28, ptr %l24
  br label %bb7
bb6:
  br label %bb19
bb7:
  %t29 = load ptr, ptr %l24, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 5
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l27
  br label %bb8
bb8:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = icmp slt i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 35
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlotOf(ptr %v0, ptr %v1, ptr %t38, i64 %t42, i64 %t43, ptr %t44)
  store i64 %t49, ptr %l35
  br label %bb11
bb10:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb12
bb11:
  %t50 = load i64, ptr %l35, !tbaa !24
  store i64 %t50, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l29, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 38
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i32, ptr %l3, !tbaa !23
  %t65 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t59, i64 %t60, i32 %t61, ptr null)
  store %"compiler/effects:part" %t65, ptr %l44
  br label %bb15
bb14:
  %t66 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  %t70 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t66, i64 0, i32 %t67, ptr null)
  store %"compiler/effects:part" %t70, ptr %l47
  br label %bb16
bb15:
  %t71 = load %"compiler/effects:part", ptr %l44
  store %"compiler/effects:part" %t71, ptr %l40
  br label %bb17
bb16:
  %t72 = load %"compiler/effects:part", ptr %l47
  store %"compiler/effects:part" %t72, ptr %l40
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load %"compiler/effects:part", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t73, %"compiler/effects:part" %t74)
  br label %bb18
bb18:
  br label %ret
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 67
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77, i64 %t78)
  store i1 %t81, ptr %l51
  br label %bb20
bb20:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb24
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/effects:Effects", ptr %t83, i32 0, i32 66
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l56
  br label %bb23
bb23:
  %t90 = load i1, ptr %l56, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/effects:Effects", ptr %t94, i32 0, i32 38
  store ptr %t96, ptr %l59, !tbaa !29
  %t97 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t97, i64 0, i32 %t98, ptr null)
  store %"compiler/effects:part" %t101, ptr %l62
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t102 = load ptr, ptr %l59, !tbaa !29
  %t103 = load %"compiler/effects:part", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t102, %"compiler/effects:part" %t103)
  br label %bb28
bb28:
  br label %ret
bb29:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 66
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v0, ptr %t106, i64 %t107)
  %t111 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t110, 1
  %t112 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t110, 0
  store i32 %t112, ptr %l68
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb31, label %ok.114, !prof !99
ok.114:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l67
  br label %bb30
bb30:
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %l67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l70
  br label %bb33
bb31:
  br label %bb32
bb32:
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l71
  br label %bb34
bb33:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l63
  br label %bb35
bb34:
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  %t122 = load i64, ptr %l9, !tbaa !24
  store i64 %t122, ptr %l73, !tbaa !24
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l75
  br label %bb37
bb37:
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = load i64, ptr %l75, !tbaa !24
  %t128 = icmp slt i64 %t126, %t127
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb38, label %bb39
bb38:
  br label %bb44
bb39:
  br label %bb40
bb40:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store ptr %t136, ptr %l80
  br label %bb41
bb41:
  %t137 = load ptr, ptr %l80, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  %t144 = add i64 %a4, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v0, ptr %v1, ptr %t138, ptr %t137, ptr %t140, i32 %t141, i64 %t144)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t153 = add i64 %t150, 1
  store i64 %t153, ptr %l9, !tbaa !24
  br label %bb36
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyLocal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca %"compiler/effects:part"
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca %"compiler/effects:part"
  %l44 = alloca i1
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i32
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 31
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l14
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t12 = load i64, ptr %l13, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l9, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Effects", ptr %t18, i32 0, i32 38
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i32, ptr %l2, !tbaa !23
  %t27 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t21, i64 %t22, i32 %t23, ptr null)
  store %"compiler/effects:part" %t27, ptr %l22
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load %"compiler/effects:part", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t28, %"compiler/effects:part" %t29)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Effects", ptr %t30, i32 0, i32 40
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t32, i64 %t33)
  store i1 %t36, ptr %l26
  br label %bb10
bb10:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb12:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t38, 0
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 39
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t49 = load i1, ptr %l34, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 38
  store ptr %t56, ptr %l37, !tbaa !29
  %t57 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t57, i64 0, i32 %t58, ptr null)
  store %"compiler/effects:part" %t61, ptr %l40
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load %"compiler/effects:part", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t62, %"compiler/effects:part" %t63)
  br label %bb21
bb21:
  br label %ret
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Effects", ptr %t64, i32 0, i32 39
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l44
  br label %bb23
bb23:
  %t71 = load i1, ptr %l44, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t74, i32 0, i32 39
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  %t81 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t80, 1
  %t82 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t80, 0
  store i32 %t82, ptr %l51
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb28, label %ok.84, !prof !99
ok.84:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l50
  br label %bb27
bb27:
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l53
  br label %bb30
bb28:
  br label %bb29
bb29:
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l54
  br label %bb31
bb30:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l46
  br label %bb32
bb31:
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l46
  br label %bb32
bb32:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l5
  store ptr %l5, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb33
bb33:
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %l56, !tbaa !24
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l58
  br label %bb34
bb34:
  %t96 = load i64, ptr %l56, !tbaa !24
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l63
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l63, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t113 = add i64 %a3, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v0, ptr %t108, ptr %t107, i64 %t113)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb33
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:coldMark"
  %l6 = alloca %"compiler/effects:coldMark"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/effects:coldMark" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldOpen(ptr %v0, ptr %t5)
  store %"compiler/effects:coldMark" %t7, ptr %l6
  br label %bb4
bb4:
  %t8 = load %"compiler/effects:coldMark", ptr %l6
  store %"compiler/effects:coldMark" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t9, ptr %t10)
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/effects:coldMark", ptr %l2
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldClose(ptr %v0, ptr %t14, %"compiler/effects:coldMark" %t15)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecopyBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evalueArray(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewidened(ptr %v0, ptr %v1, ptr %t15, ptr %t16, i32 %t17)
  store i1 %t21, ptr %l14
  br label %bb8
bb8:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t28 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t28, ptr %l19
  br label %bb11
bb11:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i1
  %l30 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/effects:Effects", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 10
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load i64, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb5
bb4:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 11
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  store i1 %t24, ptr %l22, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 10
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t30, i64 %t31)
  store i32 %t34, ptr %l30
  br label %bb9
bb9:
  %t35 = load i32, ptr %l30, !tbaa !23
  store i32 %t35, ptr %l4, !tbaa !23
  store i64 -1, ptr %l5, !tbaa !24
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 11
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3b1aba267d3808f9_9a4444fd59d95fdd)
  unreachable
bb11:
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 11
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Block", ptr %t46, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  br label %bb47
bb15:
  br label %bb16
bb16:
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t64, ptr %l44, !tbaa !27
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr ptr, ptr %t68, i64 %t65
  %t70 = load ptr, ptr %t69, !tbaa !39
  store ptr %t70, ptr %l9, !tbaa !29
  %t72 = load ptr, ptr %l9, !tbaa !29
  store ptr %t72, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t73 = load ptr, ptr %l47, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load ptr, ptr %l47, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 17}
  %t79 = icmp eq i64 %t77, 0
  store i1 %t79, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l48, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l10, !tbaa !23
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l11, !tbaa !29
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t93 = load i32, ptr %l10, !tbaa !23
  %t94 = load i32, ptr %l4, !tbaa !23
  %t97 = icmp eq i32 %t93, %t94
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t100 = load ptr, ptr %l11, !tbaa !29
  %t103 = call i64 @compiler_2feffects_2eparamOf(ptr %v0, ptr %v0, ptr %t99, ptr %t100)
  store i64 %t103, ptr %l60
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t104 = load i64, ptr %l60, !tbaa !24
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb25
bb25:
  br label %bb45
bb26:
  %t105 = load ptr, ptr %l9, !tbaa !29
  store ptr %t105, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t106 = load ptr, ptr %l61, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb27, label %bb28
bb27:
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 17}
  %t112 = icmp eq i64 %t110, 1
  store i1 %t112, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t113 = load i1, ptr %l62, !tbaa !21
  br i1 %t113, label %bb29, label %bb30
bb29:
  %t114 = load ptr, ptr %l9, !tbaa !29
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t119 = load ptr, ptr %l67, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb33
bb31:
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 0
  store i1 %t125, ptr %l68, !tbaa !21
  br label %bb32
bb32:
  %t126 = load i1, ptr %l68, !tbaa !21
  store i1 %t126, ptr %l65, !tbaa !21
  br label %bb33
bb33:
  %t127 = load i1, ptr %l65, !tbaa !21
  br i1 %t127, label %bb34, label %bb35
bb34:
  %t128 = load ptr, ptr %l9, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t134, i32 0, i32 2
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l12, !tbaa !23
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t138 = load i32, ptr %l12, !tbaa !23
  %t139 = load i32, ptr %l4, !tbaa !23
  %t142 = icmp eq i32 %t138, %t139
  br i1 %t142, label %bb37, label %bb38
bb37:
  store i64 -1, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_76dfd6b01352a9c1_3e5307bd9b690f5)
  unreachable
bb45:
  br label %bb46
bb46:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l7, !tbaa !24
  br label %bb13
bb47:
  %t150 = load i64, ptr %l5, !tbaa !24
  store i64 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpand(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/effects:given"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l13 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i32
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/effects:given"
  %l42 = alloca i1
  %l46 = alloca i1
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i64
  %l65 = alloca i64
  %l67 = alloca i1
  %l71 = alloca i64
  %l73 = alloca i1
  %l77 = alloca i64
  %l79 = alloca i1
  %l96 = alloca i1
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l103 = alloca i64
  %l105 = alloca i64
  %l110 = alloca i64
  %l122 = alloca ptr
  %l127 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load i1, ptr %l13, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 9
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb5dd413d586c55d7ccefa7dbc5ad43c5(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l19
  br label %bb4
bb4:
  %t18 = load i1, ptr %l19, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 9
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t28, 1
  %t30 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t28, 0
  store i32 %t30, ptr %l26
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l25
  br label %bb9
bb9:
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l28
  br label %bb12
bb10:
  br label %bb11
bb11:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l29
  br label %bb13
bb12:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l21
  br label %bb14
bb13:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l21
  br label %bb14
bb14:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l2
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l4, !tbaa !24
  store i64 %t40, ptr %l31, !tbaa !24
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t41)
  store i64 %t43, ptr %l33
  br label %bb16
bb16:
  %t44 = load i64, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = icmp slt i64 %t44, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb81
bb18:
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t50, i64 %t51)
  store %"compiler/effects:given" %t54, ptr %l38
  br label %bb20
bb20:
  %t55 = load %"compiler/effects:given", ptr %l38
  store %"compiler/effects:given" %t55, ptr %l5
  %t56 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t63 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 2
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t68 = icmp ne i64 %t64, %t65
  store i1 %t68, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t71 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t76 = icmp ne i64 %t72, %t73
  store i1 %t76, ptr %l46, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t78 = load i1, ptr %l46, !tbaa !21
  br i1 %t78, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb28:
  br label %bb29
bb29:
  %t79 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 0
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = icmp sge i64 %t80, 0
  br i1 %t82, label %bb30, label %bb31
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/effects:Effects", ptr %t84, i32 0, i32 6
  %t87 = load i64, ptr %l1, !tbaa !24
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l55
  br label %bb32
bb31:
  br label %bb50
bb32:
  %t91 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 0
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l55, i64 %t92)
  store i64 %t95, ptr %l58
  br label %bb33
bb33:
  %t96 = load i64, ptr %l58, !tbaa !24
  store i64 %t96, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = icmp slt i64 %t97, 0
  br i1 %t99, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb37
bb35:
  %t101 = load i64, ptr %l6, !tbaa !24
  store i64 %t101, ptr %l62, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Effects", ptr %t102, i32 0, i32 1
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l65
  br label %bb36
bb36:
  %t107 = load i64, ptr %l62, !tbaa !24
  %t108 = load i64, ptr %l65, !tbaa !24
  %t109 = icmp sge i64 %t107, %t108
  store i1 %t109, ptr %l61, !tbaa !21
  br label %bb37
bb37:
  %t111 = load i1, ptr %l61, !tbaa !21
  br i1 %t111, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb46
bb39:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/effects:Effects", ptr %t112, i32 0, i32 17
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l71
  br label %bb40
bb40:
  %t119 = load i64, ptr %l71, !tbaa !24
  %t120 = icmp eq i64 %t119, 2
  br i1 %t120, label %bb41, label %bb42
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/effects:Effects", ptr %t122, i32 0, i32 12
  %t125 = load i64, ptr %l6, !tbaa !24
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l77
  br label %bb43
bb42:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb45
bb43:
  %t129 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l77, !tbaa !24
  %t133 = call i1 @compiler_2feffects_2ehasBit(i64 %t131, i64 %t130)
  store i1 %t133, ptr %l79
  br label %bb44
bb44:
  %t134 = load i1, ptr %l79, !tbaa !21
  %t135 = xor i1 %t134, true
  store i1 %t135, ptr %l73, !tbaa !21
  br label %bb45
bb45:
  %t137 = load i1, ptr %l73, !tbaa !21
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb46
bb46:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t139 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 2
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t144 = icmp eq i64 %t140, %t141
  br i1 %t144, label %bb51, label %bb52
bb51:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i64, ptr %l1, !tbaa !24
  %t148 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 3
  %t149 = load i64, ptr %t148, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallEdge(ptr %v0, ptr %t146, i64 %t147, i64 %t149)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb54:
  %t153 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 2
  %t154 = load i64, ptr %t153, !tbaa !24
  %t155 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t158 = icmp eq i64 %t154, %t155
  br i1 %t158, label %bb55, label %bb56
bb55:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpandField(ptr %v0, ptr %s3, ptr %t160, i64 %t161, ptr %l5)
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb58:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/effects:Effects", ptr %t165, i32 0, i32 10
  %t168 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 3
  %t169 = load i64, ptr %t168, !tbaa !24
  %t172 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t167, i64 %t169)
  store i1 %t172, ptr %l96
  br label %bb59
bb59:
  %t173 = load i1, ptr %l96, !tbaa !21
  br i1 %t173, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 3
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s10, ptr %t174, i64 %t176)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l99
  br label %bb62
bb61:
  %t180 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 0
  %t181 = load i64, ptr %t180, !tbaa !24
  %t183 = icmp slt i64 %t181, 0
  br i1 %t183, label %bb73, label %bb74
bb62:
  %t186 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s10, ptr %l99)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %l101
  br label %bb63
bb63:
  %t187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  %t188 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %t188
  store ptr %t188, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb64
bb64:
  %t190 = load i64, ptr %l8, !tbaa !24
  store i64 %t190, ptr %l103, !tbaa !24
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %t191)
  store i64 %t193, ptr %l105
  br label %bb65
bb65:
  %t194 = load i64, ptr %l103, !tbaa !24
  %t195 = load i64, ptr %l105, !tbaa !24
  %t196 = icmp slt i64 %t194, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb66, label %bb67
bb66:
  br label %bb72
bb67:
  br label %bb68
bb68:
  %t200 = load ptr, ptr %l7, !tbaa !29
  %t201 = load i64, ptr %l8, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l110
  br label %bb69
bb69:
  %t205 = load i64, ptr %l110, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallEdge(ptr %v0, ptr %t206, i64 %t207, i64 %t205)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l8, !tbaa !24
  br label %bb64
bb72:
  call void @__olang_scope_close(ptr %s10)
  br label %bb79
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/effects:Effects", ptr %t217, i32 0, i32 3
  %t220 = load i64, ptr %l1, !tbaa !24
  %t223 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t219, i64 %t220)
  store ptr %t223, ptr %l122
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/effects:Effects", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = getelementptr %"compiler/effects:given", ptr %l5, i32 0, i32 4
  %t231 = load i32, ptr %t230, !tbaa !23
  %t234 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t229, i32 %t231)
  store %"compiler/effects:Facts" %t234, ptr %l127
  br label %bb76
bb76:
  %t235 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s14, ptr %t235, ptr %l127)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb80:
  %t237 = load i64, ptr %l4, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l4, !tbaa !24
  br label %bb15
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpandField(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca %"compiler/effects:part"
  %l23 = alloca %"compiler/effects:part"
  %l36 = alloca ptr
  %l41 = alloca %"compiler/effects:Facts"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %v1, ptr %s0, ptr %t3, i64 %t4, ptr %a2, ptr %l3, i64 0)
  br label %bb2
bb2:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %s0, ptr %t12)
  store i64 %t14, ptr %l16
  br label %bb4
bb4:
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l16, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %s0, ptr %s0, ptr %t21, i64 %t22)
  store %"compiler/effects:part" %t25, ptr %l21
  br label %bb8
bb8:
  %t27 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %s0, ptr %l21)
  store %"compiler/effects:part" %t27, ptr %l23
  br label %bb9
bb9:
  %t28 = load %"compiler/effects:part", ptr %l23
  store %"compiler/effects:part" %t28, ptr %l6
  %t29 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallEdge(ptr %v0, ptr %t36, i64 %t37, i64 %t39)
  br label %bb12
bb11:
  %t43 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  br i1 %t48, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/effects:Effects", ptr %t50, i32 0, i32 3
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store ptr %t56, ptr %l36
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/effects:Effects", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  %t67 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t62, i32 %t64)
  store %"compiler/effects:Facts" %t67, ptr %l41
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s5, ptr %t68, ptr %l41)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t70 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t75 = icmp ne i64 %t71, %t72
  br i1 %t75, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Effects", ptr %t77, i32 0, i32 3
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l49
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l49, !tbaa !29
  store ptr %t84, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  store ptr %t85, ptr %l50, !tbaa !29
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Facts", ptr %t86, i32 0, i32 24
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = call i64 @compiler_2feffects_2eparamBit(i64 %t91)
  store i64 %t93, ptr %l54
  br label %bb24
bb24:
  %t94 = load i64, ptr %l52, !tbaa !24
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = or i64 %t94, %t95
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Facts", ptr %t98, i32 0, i32 24
  store i64 %t96, ptr %t99, !tbaa !24
  br label %bb25
bb25:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l5, !tbaa !24
  br label %bb3
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"compiler/effects:given"
  %lp4 = alloca ptr
  %l10 = alloca %"compiler/effects:given"
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/effects:part", ptr %t2, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/effects:part", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t13 = call %"compiler/effects:given" @compiler_2feffects_3agiven_2ector(ptr %s0, i64 -1, i64 0, i64 %t1, i64 %t5, i32 %t9)
  store %"compiler/effects:given" %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load %"compiler/effects:given", ptr %l10
  store %"compiler/effects:given" %t14, ptr %l3
  %t15 = call ptr @__olang_scope_hold(ptr %s0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = call ptr @__olang_region_make(ptr %s0)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/effects:part", ptr %t21, i32 0, i32 4
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l15
  %t26 = load i64, ptr %l11
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t32 = load i64, ptr %l11
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call ptr @__olang_region_make_part(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t36 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19, !tbaa !24
  %t40 = load i64, ptr %l19, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = load i64, ptr %l16
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call ptr @__olang_held_alloc(ptr %t43, i64 %t41)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l20, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l19, !tbaa !24
  %t52 = mul i64 %t51, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  store { i64, ptr } %t53, ptr %t54, !tbaa !27
  %t55 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t55, label %bb6, label %bb7
bb6:
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t61 = icmp eq i64 %t59, 0
  br i1 %t61, label %bb8, label %bb9
bb7:
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t63, label %bb10, label %bb11
bb8:
  %t65 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t65, !tbaa !27
  br label %bb9
bb9:
  %t66 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t67 = load i64, ptr %l16
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = load { i64, ptr }, ptr %t66
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = call ptr @__olang_region_or(ptr %t70, ptr null)
  %t72 = icmp ne ptr %t71, null
  %t73 = select i1 %t72, ptr %t71, ptr null
  call void @__olang_region_settle_in(ptr %t68, ptr %t73)
  br label %bb7
bb10:
  %t74 = load i64, ptr %l11
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t77 = load { i64, ptr }, ptr %t76
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = call ptr @__olang_region_or(ptr %t78, ptr null)
  %t80 = call ptr @__olang_region_home(ptr %t79)
  %t81 = icmp ne ptr %t80, null
  %t82 = select i1 %t81, ptr %t80, ptr null
  call void @__olang_region_settle_in(ptr %t75, ptr %t82)
  br label %bb11
bb11:
  %t83 = getelementptr %"compiler/effects:given", ptr %l3, i32 0, i32 5
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l25
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t86 = getelementptr %"compiler/effects:given", ptr %l3, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t87, label %bb12, label %bb13
bb12:
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = call ptr @__olang_region_or(ptr %t91, ptr null)
  %t93 = call ptr @__olang_region_home(ptr %t92)
  %t94 = icmp ne ptr %t93, null
  %t95 = select i1 %t94, ptr %t93, ptr null
  call void @__olang_region_drop(ptr %t95)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l25
  br label %bb13
bb13:
  %t96 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t96, label %bb14, label %bb15
bb14:
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  call void @__olang_region_release_part(ptr %t101, i64 %t100)
  store { i64, ptr } zeroinitializer, ptr %t98
  br label %bb15
bb15:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/effects:part", ptr %t102, i32 0, i32 5
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = getelementptr %"compiler/effects:given", ptr %l3, i32 0, i32 6
  store i64 %t105, ptr %t107, !tbaa !24
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l30
  br label %bb16
bb16:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t109, ptr %lp4
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  %t111 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  %t114 = load ptr, ptr %lp4
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %s0, ptr %v2, ptr %a0, i64 %a1, ptr %l3, ptr %t114, i64 0)
  br label %bb17
bb17:
  %t119 = load ptr, ptr %lp4
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t119
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldPends(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca %"compiler/effects:fslot"
  %l63 = alloca { i64, ptr }
  %l66 = alloca %"compiler/effects:pend"
  %l67 = alloca i64
  %l71 = alloca %"compiler/effects:fslot"
  %l73 = alloca %"compiler/effects:fslot"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l4)
  store i64 %t8, ptr %l18
  br label %bb2
bb2:
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l22
  br label %bb6
bb6:
  %t17 = load i64, ptr %l22, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l4)
  store i64 %t19, ptr %l24
  br label %bb7
bb7:
  %t20 = load i64, ptr %l24, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb13
bb10:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l31, !tbaa !24
  store i64 %t47, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s3, ptr %l4, i64 %t67)
  store %"compiler/effects:fslot" %t70, ptr %l51
  br label %bb18
bb18:
  %t71 = getelementptr %"compiler/effects:fslot", ptr %l51, i32 0, i32 0
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Call", ptr %t75, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = icmp sge i64 %t74, %t80
  br i1 %t83, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb20:
  br label %bb21
bb21:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Call", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l63, !tbaa !27
  %t95 = load i64, ptr %l12, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t104 = call %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v1, ptr %v0, i64 %a2, i64 %t90, ptr %t100)
  store %"compiler/effects:pend" %t104, ptr %l66
  br label %bb22
bb22:
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store ptr %t105, ptr %lp13
  %t106 = load %"compiler/effects:pend", ptr %l66
  %t107 = load ptr, ptr %lp13
  store %"compiler/effects:pend" %t106, ptr %t107
  %t108 = call ptr @__olang_scope_hold(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l67, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apend_2e3
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l67, !tbaa !24
  br label %bb24
bb24:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s0, ptr %l4, i64 %t114)
  store %"compiler/effects:fslot" %t117, ptr %l71
  br label %bb25
bb25:
  %t119 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %s3, ptr %l71)
  store %"compiler/effects:fslot" %t119, ptr %l73
  br label %bb26
bb26:
  %t120 = getelementptr %"compiler/effects:fslot", ptr %l73, i32 0, i32 1
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l75
  %t123 = load i64, ptr %l67
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = call ptr @__olang_scope_hold(ptr %t124)
  %t126 = ptrtoint ptr %t125 to i64
  store i64 %t126, ptr %l76, !tbaa !24
  %t127 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t127, label %bb27, label %bb28
bb27:
  %t129 = load i64, ptr %l67
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = call ptr @__olang_region_make_part(ptr %t130)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l76, !tbaa !24
  br label %bb28
bb28:
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l78, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l79, !tbaa !24
  %t137 = load i64, ptr %l79, !tbaa !24
  %t138 = mul i64 %t137, 8
  %t139 = load i64, ptr %l76
  %t140 = inttoptr i64 %t139 to ptr
  %t141 = call ptr @__olang_held_alloc(ptr %t140, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l80, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l79, !tbaa !24
  %t149 = mul i64 %t148, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t151 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  store { i64, ptr } %t150, ptr %t151, !tbaa !27
  %t152 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t152, label %bb29, label %bb30
bb29:
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp eq i64 %t156, 0
  br i1 %t158, label %bb31, label %bb32
bb30:
  %t160 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apend_2e3
  br i1 %t160, label %bb33, label %bb34
bb31:
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t162, !tbaa !27
  br label %bb32
bb32:
  %t163 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t164 = load i64, ptr %l76
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = load { i64, ptr }, ptr %t163
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr null
  call void @__olang_region_settle_in(ptr %t165, ptr %t170)
  br label %bb30
bb33:
  %t171 = load i64, ptr %l67
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr null)
  %t177 = call ptr @__olang_region_home(ptr %t176)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr null
  call void @__olang_region_settle_in(ptr %t172, ptr %t179)
  br label %bb34
bb34:
  %t180 = load ptr, ptr %lp13
  %t181 = getelementptr %"compiler/effects:pend", ptr %t180, i32 0, i32 3
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t181
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l85
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  %t184 = load ptr, ptr %lp13
  %t185 = getelementptr %"compiler/effects:pend", ptr %t184, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %t185
  %t186 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apend_2e3
  br i1 %t186, label %bb35, label %bb36
bb35:
  %t188 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t189 = load { i64, ptr }, ptr %t188
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = call ptr @__olang_region_or(ptr %t190, ptr null)
  %t192 = call ptr @__olang_region_home(ptr %t191)
  %t193 = icmp ne ptr %t192, null
  %t194 = select i1 %t193, ptr %t192, ptr null
  call void @__olang_region_drop(ptr %t194)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l85
  br label %bb36
bb36:
  %t195 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t195, label %bb37, label %bb38
bb37:
  %t197 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  call void @__olang_region_release_part(ptr %t200, i64 %t199)
  store { i64, ptr } zeroinitializer, ptr %t197
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/effects:Effects", ptr %t201, i32 0, i32 37
  %t204 = load ptr, ptr %lp13
  %t205 = load %"compiler/effects:pend", ptr %t204
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t203, %"compiler/effects:pend" %t205)
  br label %bb39
bb39:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/effects:Effects", ptr %t208, i32 0, i32 44
  store i1 true, ptr %t210, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l10, !tbaa !24
  br label %bb14
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlotOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca %"compiler/effects:fslot"
  %l46 = alloca i1
  %l49 = alloca %"compiler/effects:fslot"
  %l52 = alloca i1
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l4)
  store i64 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l7, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l19, !tbaa !24
  store i64 %t37, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l10, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s2, ptr %l4, i64 %t56)
  store %"compiler/effects:fslot" %t59, ptr %l42
  br label %bb13
bb13:
  %t60 = getelementptr %"compiler/effects:fslot", ptr %l42, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t65 = icmp eq i64 %t61, %a2
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s0, ptr %l4, i64 %t67)
  store %"compiler/effects:fslot" %t70, ptr %l49
  br label %bb16
bb15:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb18
bb16:
  %t71 = getelementptr %"compiler/effects:fslot", ptr %l49, i32 0, i32 1
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %s0, ptr %v1, ptr %t71, ptr %a3)
  store i1 %t75, ptr %l52
  br label %bb17
bb17:
  %t76 = load i1, ptr %l52, !tbaa !21
  store i1 %t76, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l46, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l55
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l55, !tbaa !24
  %t86 = add i64 %t84, %t83
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t86, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb9
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/effects:part" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/effects:part"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/effects:part"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l32 = alloca %"compiler/effects:part"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i32
  %l44 = alloca %"compiler/effects:part"
  %rv = alloca %"compiler/effects:part"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  store i64 %t16, ptr %l13, !tbaa !24
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l15, !tbaa !24
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t20)
  store i32 %t22, ptr %l17
  br label %bb6
bb6:
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t23, i64 %t24, i32 %t25, ptr null)
  store %"compiler/effects:part" %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load %"compiler/effects:part", ptr %l18
  store %"compiler/effects:part" %t27, ptr %l6
  br label %bb25
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 3}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t43 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store i64 %t46, ptr %l27, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t47)
  store i32 %t49, ptr %l29
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = load i32, ptr %l29, !tbaa !23
  %t56 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v2, ptr %v3, i64 %t52, i64 %t53, i32 %t54, ptr %t50)
  store %"compiler/effects:part" %t56, ptr %l32
  br label %bb15
bb15:
  %t57 = load %"compiler/effects:part", ptr %l32
  store %"compiler/effects:part" %t57, ptr %l6
  br label %bb25
bb16:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 3}
  %t65 = icmp eq i64 %t63, 2
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { i32, ptr, i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t73 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  store i64 %t73, ptr %l39, !tbaa !24
  %t74 = load i32, ptr %l5, !tbaa !23
  %t76 = sext i32 %t74 to i64
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t77)
  store i32 %t79, ptr %l43
  br label %bb22
bb22:
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i32, ptr %l43, !tbaa !23
  %t83 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t80, i64 %t81, i32 %t82, ptr null)
  store %"compiler/effects:part" %t83, ptr %l44
  br label %bb23
bb23:
  %t84 = load %"compiler/effects:part", ptr %l44
  store %"compiler/effects:part" %t84, ptr %l6
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e33fbd58e0454875_653468874e31cf21)
  unreachable
bb25:
  %t85 = load %"compiler/effects:part", ptr %l6
  store %"compiler/effects:part" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l38 = alloca i64
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l6, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l20, !tbaa !24
  store i64 %t30, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  store i64 %t50, ptr %l38, !tbaa !24
  %t51 = load i64, ptr %l38, !tbaa !24
  %t52 = load i64, ptr %l38, !tbaa !24
  %t53 = shl i64 1, %t52
  store i64 %t53, ptr %l10, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = and i64 %a2, %t56
  %t61 = icmp eq i64 %t59, 0
  br i1 %t61, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %v1, ptr %v2, ptr %a1, i64 %t64)
  store { i64, ptr } %t67, ptr %l46
  br label %bb14
bb14:
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t68, ptr %lp11
  %t69 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t70 = load ptr, ptr %lp11
  store { i64, ptr } %t69, ptr %t70, !tbaa !27
  %t71 = load ptr, ptr %lp11
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t74, ptr %l48
  br label %bb15
bb15:
  %t75 = load i1, ptr %l48, !tbaa !21
  br i1 %t75, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb17:
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l49, !tbaa !29
  %t77 = call ptr @__olang_scope_hold(ptr %v2)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l50, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = call ptr @__olang_region_make_part(ptr %v2)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t83
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  store { i64, ptr } %t86, ptr %l54, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l55, !tbaa !24
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = load i64, ptr %l50
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = call ptr @__olang_held_alloc(ptr %t93, i64 %t91)
  %t95 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l55, !tbaa !24
  %t102 = mul i64 %t101, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t98, ptr %t100, i64 %t102, i1 false)
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t105 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t108 = icmp eq i64 %t106, 0
  br i1 %t108, label %bb23, label %bb24
bb22:
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Verdict", ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l60, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = load ptr, ptr %l49, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Verdict", ptr %t114, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t115, !tbaa !27
  %t116 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t116, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l56, !tbaa !27
  br label %bb24
bb24:
  %t118 = load i64, ptr %l50
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load { i64, ptr }, ptr %l56
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_settle_in(ptr %t119, ptr %t124)
  br label %bb22
bb25:
  %t125 = load { i64, ptr }, ptr %l60
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release_part(ptr %t127, i64 %t126)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %bb26
bb26:
  %t128 = load ptr, ptr %l3, !tbaa !29
  store ptr %t128, ptr %l62, !tbaa !29
  %t129 = call ptr @__olang_scope_hold(ptr %v2)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l63, !tbaa !24
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t131, label %bb27, label %bb28
bb27:
  %t133 = call ptr @__olang_region_make_part(ptr %v2)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l63, !tbaa !24
  br label %bb28
bb28:
  %t135 = load ptr, ptr %lp11
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l65, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l66, !tbaa !24
  %t139 = load i64, ptr %l66, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = load i64, ptr %l63
  %t142 = inttoptr i64 %t141 to ptr
  %t143 = call ptr @__olang_held_alloc(ptr %t142, i64 %t140)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l67, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l66, !tbaa !24
  %t151 = mul i64 %t150, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %t149, i64 %t151, i1 false)
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t152, label %bb29, label %bb30
bb29:
  %t154 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t157 = icmp eq i64 %t155, 0
  br i1 %t157, label %bb31, label %bb32
bb30:
  %t159 = load ptr, ptr %l62, !tbaa !29
  %t160 = getelementptr %"compiler/effects:Verdict", ptr %t159, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l71, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t163 = load ptr, ptr %l62, !tbaa !29
  %t164 = getelementptr %"compiler/effects:Verdict", ptr %t163, i32 0, i32 1
  store { i64, ptr } %t162, ptr %t164, !tbaa !27
  %t165 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e1
  br i1 %t165, label %bb33, label %bb34
bb31:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb32
bb32:
  %t167 = load i64, ptr %l63
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = load { i64, ptr }, ptr %l67
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  call void @__olang_region_settle_in(ptr %t168, ptr %t173)
  br label %bb30
bb33:
  %t174 = load { i64, ptr }, ptr %l71
  %t175 = extractvalue { i64, ptr } %t174, 0
  %t176 = extractvalue { i64, ptr } %t174, 1
  call void @__olang_region_release_part(ptr %t176, i64 %t175)
  store { i64, ptr } zeroinitializer, ptr %l71
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb35:
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l8, !tbaa !24
  br label %bb7
bb36:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/effects:Facts"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca ptr
  %l25 = alloca i64
  %lp26 = alloca ptr
  %l29 = alloca %"compiler/effects:Facts"
  %l33 = alloca %"compiler/effects:Facts"
  %l40 = alloca ptr
  %l43 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca %"compiler/effects:Facts"
  %l86 = alloca i64
  %l88 = alloca i64
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l121 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca %"compiler/effects:Facts"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l139 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l155 = alloca { i64, ptr }
  %l158 = alloca i64
  %l164 = alloca i64
  %l165 = alloca i1
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l180 = alloca i64
  %l182 = alloca i64
  %l187 = alloca %"compiler/effects:part"
  %l189 = alloca %"compiler/effects:part"
  %l190 = alloca ptr
  %l194 = alloca %"compiler/effects:Facts"
  %l202 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca i32
  %l208 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t1, i64 %t2)
  store %"compiler/effects:Facts" %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 11
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/effects:Facts" %t12, ptr %l33
  br label %bb2
bb2:
  %t13 = load %"compiler/effects:Facts", ptr %l33
  store %"compiler/effects:Facts" %t13, ptr %l4
  %t14 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 24
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load %"compiler/effects:Facts", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t19, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l40
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l40, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 5
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l43
  br label %bb7
bb7:
  %t33 = load i64, ptr %l43, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l50, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l50, !tbaa !24
  store i64 %t60, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l47, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 24
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = call i1 @compiler_2feffects_2ehasBit(i64 %t81, i64 %t82)
  store i1 %t85, ptr %l70
  br label %bb18
bb18:
  %t86 = load i1, ptr %l70, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l71, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/effects:Effects", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l74, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l2, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t99 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t93, i64 %t94, i64 %t95)
  store i32 %t99, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t100 = load ptr, ptr %l74, !tbaa !29
  %t101 = load i32, ptr %l78, !tbaa !23
  %t102 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t100, i32 %t101)
  store %"compiler/effects:Facts" %t102, ptr %l79
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s4, ptr %t103, ptr %l79)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb14
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l86
  br label %bb27
bb27:
  %t115 = load i64, ptr %l86, !tbaa !24
  store i64 %t115, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  store i64 %t118, ptr %l88, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i64, ptr %l2, !tbaa !24
  %t123 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %v0, ptr %t119, i64 %t120)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %l91
  br label %bb28
bb28:
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %l91)
  store i64 %t125, ptr %l93
  br label %bb29
bb29:
  %t126 = load i64, ptr %l88, !tbaa !24
  %t127 = load i64, ptr %l93, !tbaa !24
  %t128 = add i64 %t126, %t127
  store i64 %t128, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load i64, ptr %l14, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb35
bb32:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l101, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb34
bb34:
  %t156 = load i64, ptr %l101, !tbaa !24
  store i64 %t156, ptr %l98, !tbaa !24
  br label %bb35
bb35:
  %t157 = load i64, ptr %l98, !tbaa !24
  store i64 %t157, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb37, label %bb38
bb37:
  br label %bb48
bb38:
  br label %bb39
bb39:
  %t166 = load i64, ptr %l12, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l17, !tbaa !24
  %t176 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 24
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr %l17, !tbaa !24
  %t181 = call i1 @compiler_2feffects_2ehasBit(i64 %t177, i64 %t178)
  store i1 %t181, ptr %l121
  br label %bb40
bb40:
  %t182 = load i1, ptr %l121, !tbaa !21
  br i1 %t182, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l4, ptr %l122, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/effects:Effects", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  store ptr %t188, ptr %l125, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l2, !tbaa !24
  %t191 = load i64, ptr %l17, !tbaa !24
  %t195 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t189, i64 %t190, i64 %t191)
  store i32 %t195, ptr %l129
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t196 = load ptr, ptr %l125, !tbaa !29
  %t197 = load i32, ptr %l129, !tbaa !23
  %t198 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t196, i32 %t197)
  store %"compiler/effects:Facts" %t198, ptr %l130
  br label %bb44
bb44:
  %t199 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s8, ptr %t199, ptr %l130)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l16, !tbaa !24
  br label %bb36
bb48:
  %t206 = load ptr, ptr %l3, !tbaa !29
  store ptr %t206, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t207 = load ptr, ptr %l135, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb49, label %bb50
bb49:
  %t210 = load ptr, ptr %l135, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 18}
  %t213 = icmp eq i64 %t211, 15
  store i1 %t213, ptr %l136, !tbaa !21
  br label %bb50
bb50:
  %t214 = load i1, ptr %l136, !tbaa !21
  br i1 %t214, label %bb51, label %bb52
bb51:
  %t215 = load ptr, ptr %l3, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t217, i32 0, i32 2
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t220 = load ptr, ptr %l141, !tbaa !29
  %t221 = icmp ne ptr %t220, null
  br i1 %t221, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb55
bb53:
  %t223 = load ptr, ptr %l141, !tbaa !29
  %t224 = load i64, ptr %t223, !range !{i64 0, i64 3}
  %t226 = icmp eq i64 %t224, 1
  store i1 %t226, ptr %l142, !tbaa !21
  br label %bb54
bb54:
  %t227 = load i1, ptr %l142, !tbaa !21
  store i1 %t227, ptr %l139, !tbaa !21
  br label %bb55
bb55:
  %t228 = load i1, ptr %l139, !tbaa !21
  br i1 %t228, label %bb56, label %bb57
bb56:
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t235, i32 0, i32 1
  %t237 = load { i64, ptr }, ptr %t236
  store { i64, ptr } %t237, ptr %l18, !tbaa !27
  br label %bb58
bb57:
  br label %bb85
bb58:
  %t239 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t239, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l21, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t245 = load i64, ptr %l20, !tbaa !24
  %t246 = load i64, ptr %l21, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb61:
  br label %bb62
bb62:
  %t253 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t253, ptr %l155, !tbaa !27
  %t254 = load i64, ptr %l20, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr ptr, ptr %t257, i64 %t254
  %t259 = load ptr, ptr %t258, !tbaa !39
  store ptr %t259, ptr %l22, !tbaa !29
  %t261 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 24
  %t262 = load i64, ptr %t261, !tbaa !24
  store i64 %t262, ptr %l158, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l2, !tbaa !24
  %t265 = load ptr, ptr %l22, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Capture", ptr %t265, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t270 = sext i32 %t268 to i64
  %t274 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %t263, i64 %t264, i64 %t270)
  store i64 %t274, ptr %l164
  br label %bb63
bb63:
  %t275 = load i64, ptr %l158, !tbaa !24
  %t276 = load i64, ptr %l164, !tbaa !24
  %t277 = call i1 @compiler_2feffects_2ehasBit(i64 %t275, i64 %t276)
  store i1 %t277, ptr %l165
  br label %bb64
bb64:
  %t278 = load i1, ptr %l165, !tbaa !21
  %t279 = xor i1 %t278, true
  br i1 %t279, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb66:
  br label %bb67
bb67:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t281, i64 %t282)
  br label %bb68
bb68:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/effects:Effects", ptr %t285, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t287)
  br label %bb69
bb69:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l22, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Capture", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t289, ptr %t293, i64 0)
  br label %bb70
bb70:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/effects:Effects", ptr %t297, i32 0, i32 38
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t299
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %l176
  %t302 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %s12, ptr %l176)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l178
  br label %bb71
bb71:
  %t303 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s15
  %t305 = load i64, ptr %l25, !tbaa !24
  store i64 %t305, ptr %l180, !tbaa !24
  %t306 = load ptr, ptr %l24, !tbaa !29
  %t308 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t306)
  store i64 %t308, ptr %l182
  br label %bb73
bb73:
  %t309 = load i64, ptr %l180, !tbaa !24
  %t310 = load i64, ptr %l182, !tbaa !24
  %t311 = icmp slt i64 %t309, %t310
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s15)
  br label %bb82
bb75:
  br label %bb76
bb76:
  %t315 = load ptr, ptr %l24, !tbaa !29
  %t316 = load i64, ptr %l25, !tbaa !24
  %t319 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  store %"compiler/effects:part" %t319, ptr %l187
  br label %bb77
bb77:
  %t321 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l187)
  store %"compiler/effects:part" %t321, ptr %l189
  br label %bb78
bb78:
  %t322 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t322, ptr %lp26
  %t323 = load %"compiler/effects:part", ptr %l189
  %t324 = load ptr, ptr %lp26
  store %"compiler/effects:part" %t323, ptr %t324
  store ptr %l4, ptr %l190, !tbaa !29
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i64, ptr %l1, !tbaa !24
  %t327 = load ptr, ptr %lp26
  %t331 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epartFacts(ptr %v0, ptr %v0, ptr %t325, i64 %t326, ptr %t327)
  store %"compiler/effects:Facts" %t331, ptr %l194
  br label %bb79
bb79:
  %t332 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s15, ptr %t332, ptr %l194)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s15)
  br label %bb81
bb81:
  %t334 = load i64, ptr %l25, !tbaa !24
  %t337 = add i64 %t334, 1
  store i64 %t337, ptr %l25, !tbaa !24
  br label %bb72
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  %t339 = load i64, ptr %l20, !tbaa !24
  %t342 = add i64 %t339, 1
  store i64 %t342, ptr %l20, !tbaa !24
  br label %bb59
bb84:
  br label %bb93
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l4, ptr %l202, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/effects:Effects", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = getelementptr %"compiler/generic:Program", ptr %t347, i32 0, i32 2
  store ptr %t349, ptr %l205, !tbaa !29
  %t350 = load ptr, ptr %l3, !tbaa !29
  %t352 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t350)
  store i32 %t352, ptr %l207
  br label %bb89
bb89:
  %t353 = load ptr, ptr %l205, !tbaa !29
  %t354 = load i32, ptr %l207, !tbaa !23
  %t355 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t353, i32 %t354)
  store %"compiler/effects:Facts" %t355, ptr %l208
  br label %bb90
bb90:
  %t356 = load ptr, ptr %l202, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s18, ptr %t356, ptr %l208)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s18)
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_9b481a3036e75930_9f21b77026d49cd4)
  unreachable
bb93:
  %t358 = load %"compiler/effects:Facts", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t358, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eonStack(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i1
  %l28 = alloca i64
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i32
  %l92 = alloca i32
  %l97 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i32
  %l110 = alloca i1
  %l115 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l127 = alloca i1
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l12, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  store ptr %t12, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 5
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t20 = load i1, ptr %l16, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/source:Span", ptr %t27
  store %"compiler/source:Span" %t28, ptr %l4
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb6
bb6:
  %t45 = load i64, ptr %l28, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l8, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l8, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb11
bb11:
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l46
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp sge i64 %t83, %t86
  br i1 %t89, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb16
bb14:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l2, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t96, i32 %t103)
  store i1 %t106, ptr %l58
  br label %bb15
bb15:
  %t107 = load i1, ptr %l58, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t110 = load i1, ptr %l51, !tbaa !21
  br i1 %t110, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb18:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/effects:Effects", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t117, ptr %l64, !tbaa !27
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t116, i32 %t123)
  store i64 %t126, ptr %l67
  br label %bb19
bb19:
  %t127 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t128 = load i64, ptr %l67, !tbaa !24
  %t130 = and i64 %t128, %t127
  %t132 = icmp ne i64 %t130, 0
  store i1 %t132, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t134 = load i1, ptr %l60, !tbaa !21
  br i1 %t134, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/effects:Effects", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  store ptr %t141, ptr %l74, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Effects", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l8, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l79
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l74, !tbaa !29
  %t153 = load i32, ptr %l79, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t152, i32 %t153)
  store i1 %t154, ptr %l80
  br label %bb25
bb25:
  %t155 = load i1, ptr %l80, !tbaa !21
  br i1 %t155, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/effects:Effects", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l5, !tbaa !23
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l86
  br label %bb29
bb29:
  %t167 = load i1, ptr %l86, !tbaa !21
  br i1 %t167, label %bb30, label %bb31
bb30:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/effects:Effects", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l5, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l92
  br label %bb32
bb31:
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t178, ptr %l87, !tbaa !23
  br label %bb33
bb32:
  %t180 = load i32, ptr %l92, !tbaa !23
  store i32 %t180, ptr %l87, !tbaa !23
  br label %bb33
bb33:
  %t181 = load i32, ptr %l87, !tbaa !23
  store i32 %t181, ptr %l10, !tbaa !23
  %t182 = load i32, ptr %l10, !tbaa !23
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t186 = icmp eq i32 %t182, %t183
  br i1 %t186, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb38
bb35:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/effects:Effects", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  store ptr %t193, ptr %l100, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/effects:Effects", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %l10, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l105
  br label %bb36
bb36:
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t205 = load i32, ptr %l105, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l106
  br label %bb37
bb37:
  %t207 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t209 = trunc i64 18 to i32
  %t210 = icmp eq i32 %t207, %t209
  %t212 = xor i1 %t210, true
  store i1 %t212, ptr %l97, !tbaa !21
  br label %bb38
bb38:
  %t214 = load i1, ptr %l97, !tbaa !21
  br i1 %t214, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb42
bb40:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/effects:Effects", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l10, !tbaa !23
  %t224 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t220, i32 %t221)
  store i1 %t224, ptr %l115
  br label %bb41
bb41:
  %t225 = load i1, ptr %l115, !tbaa !21
  store i1 %t225, ptr %l110, !tbaa !21
  br label %bb42
bb42:
  %t226 = load i1, ptr %l110, !tbaa !21
  br i1 %t226, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/effects:Effects", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l10, !tbaa !23
  %t237 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l121
  br label %bb46
bb46:
  %t238 = load i1, ptr %l121, !tbaa !21
  br i1 %t238, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb50
bb48:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/effects:Effects", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l10, !tbaa !23
  %t248 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t244, i32 %t245)
  store i1 %t248, ptr %l127
  br label %bb49
bb49:
  %t249 = load i1, ptr %l127, !tbaa !21
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb50
bb50:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb51, label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/effects:Effects", ptr %t252, i32 0, i32 71
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/effects:Effects", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/effects:Effects", ptr %t261, i32 0, i32 1
  %t264 = load i64, ptr %l7, !tbaa !24
  %t265 = load i64, ptr %l2, !tbaa !24
  %t271 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v0, ptr %v0, ptr %t254, ptr %t260, ptr %t263, i64 %t264, i64 %t265)
  store i1 %t271, ptr %l138
  br label %bb54
bb54:
  %t272 = load i1, ptr %l138, !tbaa !21
  store i1 %t272, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca %"compiler/effects:root"
  %l11 = alloca i1
  %l12 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/effects:root" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  %t19 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  store i64 %t19, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 31
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb9
bb9:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Effects", ptr %t30, i32 0, i32 32
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t32, i64 %t33)
  store i1 %t36, ptr %l22
  br label %bb12
bb12:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/effects:Effects", ptr %t40, i32 0, i32 43
  store i1 true, ptr %t42, !tbaa !21
  %t43 = load i64, ptr @G_2ecompiler_2feffects_2eoutLocal, !tbaa !24
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t43, %t44
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutsJudged(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/effects:link"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i32
  %l62 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"compiler/effects:link"
  %l80 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i32
  %l88 = alloca ptr
  %l92 = alloca %"compiler/effects:link"
  %l96 = alloca ptr
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 41
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l15, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l17
  br label %bb3
bb3:
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l17, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l22
  br label %bb7
bb7:
  %t22 = load i64, ptr %l22, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  store ptr %l1, ptr %l23, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t23, 2
  store i64 %t25, ptr %l25, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = srem i64 %t26, 2
  %t30 = icmp eq i64 %t28, 1
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t32, 2
  %t37 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t34)
  %t38 = extractvalue { i32, i1 } %t37, 1
  %t39 = extractvalue { i32, i1 } %t37, 0
  store i32 %t39, ptr %l35
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41, !prof !99
ok.41:
  store i1 %t38, ptr %l34
  br label %bb10
bb9:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb10:
  %t42 = load i1, ptr %l34, !tbaa !21
  store i1 %t42, ptr %l30, !tbaa !21
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = load i1, ptr %l29, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t44, i64 %t45, i1 %t46)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 42
  store ptr %t54, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t56 = load i64, ptr %l6, !tbaa !24
  store i64 %t56, ptr %l41, !tbaa !24
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l43
  br label %bb19
bb19:
  %t60 = load i64, ptr %l41, !tbaa !24
  %t61 = load i64, ptr %l43, !tbaa !24
  %t62 = icmp slt i64 %t60, %t61
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb20, label %bb21
bb20:
  br label %bb32
bb21:
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l48
  br label %bb23
bb23:
  %t71 = load i64, ptr %l48, !tbaa !24
  %t75 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t71)
  %t76 = extractvalue { i32, i1 } %t75, 1
  %t77 = extractvalue { i32, i1 } %t75, 0
  store i32 %t77, ptr %l53
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb25, label %ok.79, !prof !99
ok.79:
  store i1 %t76, ptr %l52
  br label %bb24
bb24:
  %t80 = load i1, ptr %l52, !tbaa !21
  store i1 %t80, ptr %l49, !tbaa !21
  br label %bb27
bb25:
  br label %bb26
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t81 = load i1, ptr %l49, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/effects:Effects", ptr %t84, i32 0, i32 25
  %t87 = getelementptr %"compiler/effects:Facts", ptr %t86, i32 0, i32 19
  store i1 true, ptr %t87, !tbaa !21
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb18
bb32:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/effects:Effects", ptr %t93, i32 0, i32 43
  %t96 = load i1, ptr %t95, !tbaa !21
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t100 = call ptr @__olang_scope_hold(ptr %v0)
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l62, !tbaa !24
  %t102 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t104 = call ptr @__olang_region_make(ptr %v0)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l62, !tbaa !24
  br label %bb37
bb37:
  %t106 = load i64, ptr %l62
  %t107 = inttoptr i64 %t106 to ptr
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %t107, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l64
  br label %bb38
bb38:
  %t109 = load i64, ptr %l62
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_scope_alloc_a(ptr %t110, i64 32, i64 8)
  store ptr %t111, ptr %lp8
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t113 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %t113
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/effects:Effects", ptr %t114, i32 0, i32 29
  store ptr %t116, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  %t118 = load i64, ptr %l10, !tbaa !24
  store i64 %t118, ptr %l67, !tbaa !24
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l69
  br label %bb40
bb40:
  %t122 = load i64, ptr %l67, !tbaa !24
  %t123 = load i64, ptr %l69, !tbaa !24
  %t124 = icmp slt i64 %t122, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb41, label %bb42
bb41:
  br label %bb59
bb42:
  br label %bb43
bb43:
  %t128 = load ptr, ptr %l9, !tbaa !29
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = call %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t128, i64 %t129)
  store %"compiler/effects:link" %t132, ptr %l74
  br label %bb44
bb44:
  %t133 = load %"compiler/effects:link", ptr %l74
  store %"compiler/effects:link" %t133, ptr %l11
  %t134 = getelementptr %"compiler/effects:link", ptr %l11, i32 0, i32 2
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = load i64, ptr @G_2ecompiler_2feffects_2eoutLocal, !tbaa !24
  %t139 = icmp sgt i64 %t135, %t136
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = load ptr, ptr %lp8
  %t142 = load %"compiler/effects:link", ptr %l11
  %t143 = load i64, ptr %l62
  %t144 = inttoptr i64 %t143 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %t144, ptr %t141, %"compiler/effects:link" %t142)
  br label %bb47
bb46:
  %t147 = load i64, ptr @G_2ecompiler_2feffects_2eoutLocal, !tbaa !24
  %t148 = getelementptr %"compiler/effects:link", ptr %l11, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = sub i64 %t147, %t149
  %t155 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t152)
  %t156 = extractvalue { i32, i1 } %t155, 1
  %t157 = extractvalue { i32, i1 } %t155, 0
  store i32 %t157, ptr %l86
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb49, label %ok.159, !prof !99
ok.159:
  store i1 %t156, ptr %l85
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t160 = load i1, ptr %l85, !tbaa !21
  store i1 %t160, ptr %l80, !tbaa !21
  br label %bb51
bb49:
  br label %bb50
bb50:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb51
bb51:
  %t161 = load i1, ptr %l80, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t164 = load ptr, ptr %lp8
  store ptr %t164, ptr %l88, !tbaa !29
  %t165 = getelementptr %"compiler/effects:link", ptr %l11, i32 0, i32 0
  %t166 = load i64, ptr %t165, !tbaa !24
  %t167 = getelementptr %"compiler/effects:link", ptr %l11, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  %t173 = call %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %s13, i64 %t166, i64 %t168, i64 %t169)
  store %"compiler/effects:link" %t173, ptr %l92
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t174 = load i64, ptr %l62
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = load ptr, ptr %l88, !tbaa !29
  %t177 = load %"compiler/effects:link", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %t175, ptr %t176, %"compiler/effects:link" %t177)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l10, !tbaa !24
  br label %bb39
bb59:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %lp8
  %t185 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t184
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t187 = getelementptr %"compiler/effects:Effects", ptr %t186, i32 0, i32 29
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t187
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l98
  %t190 = load ptr, ptr %l96, !tbaa !29
  %t191 = getelementptr %"compiler/effects:Effects", ptr %t190, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %t191
  %t192 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t192, label %bb60, label %bb61
bb60:
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  call void @__olang_region_drop(ptr %t200)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l98
  br label %bb61
bb61:
  %t201 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2e0
  br i1 %t201, label %bb62, label %bb63
bb62:
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  call void @__olang_region_release_part(ptr %t206, i64 %t205)
  store { i64, ptr } zeroinitializer, ptr %t203
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eownSlot(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l31 = alloca %"compiler/typed:LocalUses"
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t53 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 72
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 72
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i1 } %t15, 1
  %t17 = extractvalue { i32, i1 } %t15, 0
  store i32 %t17, ptr %l13
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store i1 %t16, ptr %l12
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l8, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/effects:Effects", ptr %t25, i32 0, i32 35
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t24, i64 %t28)
  store ptr %t31, ptr %l18
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l18, !tbaa !29
  store ptr %t32, ptr %l2, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t33, i32 0, i32 71
  store ptr %t35, ptr %l20, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 1
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/effects:Effects", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t53, ptr %v0, ptr %v0, ptr %v0, ptr %t51, ptr %t52)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t53, i64 1640, i1 false)
  br label %bb10
bb10:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 1640, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %l31, i64 1640, i1 false)
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load ptr, ptr %l20, !tbaa !29
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = load ptr, ptr %l25, !tbaa !29
  %t61 = load ptr, ptr %l26, !tbaa !29
  %t64 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eOwnSlot(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t58, ptr %t59, ptr %t60, ptr %t61, ptr %t56, i64 %t57)
  store i1 %t64, ptr %l34
  br label %bb11
bb11:
  %t65 = load i1, ptr %l34, !tbaa !21
  store i1 %t65, ptr %l3, !tbaa !21
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/effects:Effects", ptr %t66, i32 0, i32 72
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load i1, ptr %l3, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t68, i64 %t69, i1 %t70)
  br label %bb12
bb12:
  %t74 = load i1, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epartFacts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/effects:Facts"
  %l4 = alloca ptr
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/effects:Facts"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l18 = alloca %"compiler/effects:Facts"
  %l25 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca %"compiler/effects:Facts"
  %l39 = alloca %"compiler/effects:Facts"
  %l44 = alloca ptr
  %l45 = alloca i64
  %l47 = alloca i64
  %l53 = alloca %"compiler/effects:Facts"
  %l58 = alloca %"compiler/effects:Facts"
  %l63 = alloca %"compiler/effects:Facts"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca %"compiler/effects:part"
  %l78 = alloca %"compiler/effects:part"
  %l79 = alloca ptr
  %l83 = alloca %"compiler/effects:Facts"
  %l93 = alloca i1
  %l98 = alloca i1
  %l99 = alloca %"compiler/effects:Facts"
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca i64
  %l109 = alloca i64
  %l114 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca %"compiler/effects:Facts"
  %l129 = alloca %"compiler/effects:Facts"
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/effects:part", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/effects:part", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t10, i64 %t14)
  store %"compiler/effects:Facts" %t17, ptr %l18
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load %"compiler/effects:Facts", ptr %l18
  store %"compiler/effects:Facts" %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/effects:part", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l25, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/effects:part", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t43 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t34, i64 %t35, i64 %t39)
  store i32 %t43, ptr %l30
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i32, ptr %l30, !tbaa !23
  %t46 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t44, i32 %t45)
  store %"compiler/effects:Facts" %t46, ptr %l31
  br label %bb8
bb8:
  %t47 = load %"compiler/effects:Facts", ptr %l31
  store %"compiler/effects:Facts" %t47, ptr %rv
  br label %ret
bb9:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/effects:part", ptr %t48, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  %t55 = icmp eq i64 %t51, %t52
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/effects:part", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t57, i64 %t61)
  store %"compiler/effects:Facts" %t64, ptr %l39
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t65 = load %"compiler/effects:Facts", ptr %l39
  store %"compiler/effects:Facts" %t65, ptr %rv
  br label %ret
bb13:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/effects:part", ptr %t66, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l44, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  store i64 %t76, ptr %l45, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/effects:part", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/effects:part", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_89d258cb45db8a97_6792eaa695d1effb)
  unreachable
bb17:
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/effects:part", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t92 = load ptr, ptr %l44, !tbaa !29
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = load i64, ptr %l47, !tbaa !24
  %t96 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v1, ptr %t92, i64 %t93, i64 %t94, ptr %t91)
  store %"compiler/effects:Facts" %t96, ptr %l53
  br label %bb19
bb19:
  %t97 = load %"compiler/effects:Facts", ptr %l53
  store %"compiler/effects:Facts" %t97, ptr %rv
  br label %ret
bb20:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/effects:part", ptr %t98, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s5)
  store %"compiler/effects:Facts" %t107, ptr %l58
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  %t108 = load %"compiler/effects:Facts", ptr %l58
  store %"compiler/effects:Facts" %t108, ptr %rv
  br label %ret
bb24:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/effects:part", ptr %t109, i32 0, i32 0
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t118 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s6)
  store %"compiler/effects:Facts" %t118, ptr %l63
  br label %bb27
bb26:
  br label %bb40
bb27:
  %t119 = load %"compiler/effects:Facts", ptr %l63
  store %"compiler/effects:Facts" %t119, ptr %l3
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i64, ptr %l1, !tbaa !24
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t126 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %v1, ptr %v0, ptr %t120, i64 %t121, ptr %t122)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %l67
  br label %bb28
bb28:
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t128
  store ptr %t128, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load i64, ptr %l5, !tbaa !24
  store i64 %t130, ptr %l69, !tbaa !24
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l71
  br label %bb30
bb30:
  %t134 = load i64, ptr %l69, !tbaa !24
  %t135 = load i64, ptr %l71, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l4, !tbaa !29
  %t141 = load i64, ptr %l5, !tbaa !24
  %t144 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store %"compiler/effects:part" %t144, ptr %l76
  br label %bb34
bb34:
  %t146 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l76)
  store %"compiler/effects:part" %t146, ptr %l78
  br label %bb35
bb35:
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t147, ptr %lp6
  %t148 = load %"compiler/effects:part", ptr %l78
  %t149 = load ptr, ptr %lp6
  store %"compiler/effects:part" %t148, ptr %t149
  store ptr %l3, ptr %l79, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load ptr, ptr %lp6
  %t156 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epartFacts(ptr %v0, ptr %v0, ptr %t150, i64 %t151, ptr %t152)
  store %"compiler/effects:Facts" %t156, ptr %l83
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s6, ptr %s8, ptr %t157, ptr %l83)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l5, !tbaa !24
  br label %bb29
bb39:
  %t164 = load %"compiler/effects:Facts", ptr %l3
  call void @__olang_scope_close(ptr %s6)
  store %"compiler/effects:Facts" %t164, ptr %rv
  br label %ret
bb40:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/effects:part", ptr %t166, i32 0, i32 0
  %t169 = load i64, ptr %t168, !tbaa !24
  %t170 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t173 = icmp eq i64 %t169, %t170
  br i1 %t173, label %bb41, label %bb42
bb41:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/effects:Effects", ptr %t175, i32 0, i32 10
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/effects:part", ptr %t178, i32 0, i32 1
  %t181 = load i64, ptr %t180, !tbaa !24
  %t184 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t177, i64 %t181)
  store i1 %t184, ptr %l98
  br label %bb43
bb42:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb44
bb43:
  %t185 = load i1, ptr %l98, !tbaa !21
  store i1 %t185, ptr %l93, !tbaa !21
  br label %bb44
bb44:
  %t186 = load i1, ptr %l93, !tbaa !21
  br i1 %t186, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  %t187 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s10)
  store %"compiler/effects:Facts" %t187, ptr %l99
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t188 = load %"compiler/effects:Facts", ptr %l99
  store %"compiler/effects:Facts" %t188, ptr %l7
  store %olang.scope zeroinitializer, ptr %s11
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = getelementptr %"compiler/effects:part", ptr %t190, i32 0, i32 1
  %t193 = load i64, ptr %t192, !tbaa !24
  %t196 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s11, ptr %t189, i64 %t193)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l103
  br label %bb48
bb48:
  %t198 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s11, ptr %l103)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l105
  br label %bb49
bb49:
  %t199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  %t200 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %t200
  store ptr %t200, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t202 = load i64, ptr %l9, !tbaa !24
  store i64 %t202, ptr %l107, !tbaa !24
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s11, ptr %t203)
  store i64 %t205, ptr %l109
  br label %bb51
bb51:
  %t206 = load i64, ptr %l107, !tbaa !24
  %t207 = load i64, ptr %l109, !tbaa !24
  %t208 = icmp slt i64 %t206, %t207
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb53:
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l8, !tbaa !29
  %t213 = load i64, ptr %l9, !tbaa !24
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s11, ptr %t212, i64 %t213)
  store i64 %t216, ptr %l114
  br label %bb55
bb55:
  %t217 = load i64, ptr %l114, !tbaa !24
  store ptr %l7, ptr %l115, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t222 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t218, i64 %t217)
  store %"compiler/effects:Facts" %t222, ptr %l118
  br label %bb56
bb56:
  %t223 = load ptr, ptr %l115, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s10, ptr %s12, ptr %t223, ptr %l118)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s12)
  br label %bb58
bb58:
  %t225 = load i64, ptr %l9, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l9, !tbaa !24
  br label %bb50
bb59:
  call void @__olang_scope_close(ptr %s11)
  %t230 = load %"compiler/effects:Facts", ptr %l7
  call void @__olang_scope_close(ptr %s10)
  store %"compiler/effects:Facts" %t230, ptr %rv
  br label %ret
bb60:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/effects:Effects", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = getelementptr %"compiler/effects:part", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %t240, !tbaa !23
  %t244 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t237, i32 %t241)
  store %"compiler/effects:Facts" %t244, ptr %l129
  br label %bb61
bb61:
  %t245 = load %"compiler/effects:Facts", ptr %l129
  store %"compiler/effects:Facts" %t245, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/effects:fpath"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i1
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca i64
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca { i64, ptr }
  %l98 = alloca %"compiler/effects:fpath"
  %l102 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l111 = alloca i32
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca %"compiler/effects:fpath"
  %l122 = alloca %"compiler/effects:fpath"
  %l123 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l132 = alloca i64
  %l135 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381"
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca i64
  %l145 = alloca i64
  %l150 = alloca i64
  %l156 = alloca ptr
  %l159 = alloca %"compiler/effects:fpath"
  %l161 = alloca %"compiler/effects:fpath"
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l20
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 63
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hf6a5697b694481c39cb93e062458012f(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l24
  br label %bb5
bb5:
  %t16 = load i1, ptr %l24, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 63
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H7002a026c084e9a7d52910b10cae7157(ptr %v0, ptr %v1, ptr %t19, i32 %t20)
  %t24 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t23, 1
  %t25 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t23, 0
  store i32 %t25, ptr %l30
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb9, label %ok.27, !prof !99
ok.27:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l29
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %v1, ptr %l29)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l32
  br label %bb11
bb9:
  br label %bb10
bb10:
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l33
  br label %bb12
bb11:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l25
  br label %bb13
bb12:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %rv
  br label %ret
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Effects", ptr %t34, i32 0, i32 63
  store ptr %t36, ptr %l35, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  store i32 %t37, ptr %l36, !tbaa !23
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l37
  br label %bb15
bb15:
  %t39 = load ptr, ptr %l35, !tbaa !29
  %t40 = load i32, ptr %l36, !tbaa !23
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H23909c0b6cdd8c6a8e8461d347ccf8af(ptr %v0, ptr %s0, ptr %t39, i32 %t40, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41)
  br label %bb16
bb16:
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l38
  br label %bb17
bb17:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/effects:Effects", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l41, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/effects:Effects", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l46
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l41, !tbaa !29
  %t61 = load i32, ptr %l46, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l47
  br label %bb19
bb19:
  %t63 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t63, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp sgt i64 %t68, %t69
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp sgt i64 %t74, 0
  br i1 %t76, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb25
bb22:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = sub i64 %t78, %t79
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t82, %t83
  %t88 = sub i64 %t86, 1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = sdiv i64 %t88, %t89
  store i64 %t92, ptr %l56, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t94 = load i64, ptr %l56, !tbaa !24
  store i64 %t94, ptr %l53, !tbaa !24
  br label %bb25
bb25:
  %t95 = load i64, ptr %l53, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l8, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb89
bb28:
  br label %bb29
bb29:
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = mul i64 %t105, %t106
  %t112 = add i64 %t104, %t109
  store i64 %t112, ptr %l9, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t116 = load i64, ptr %l9, !tbaa !24
  %t120 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efixed(ptr %v0, ptr %t114, i32 %t115, i64 %t116)
  store i1 %t120, ptr %l77
  br label %bb30
bb30:
  %t121 = load i1, ptr %l77, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb31, label %bb32
bb31:
  br label %bb88
bb32:
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t125, ptr %l80, !tbaa !27
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  %t134 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t124, i32 %t131)
  store i1 %t134, ptr %l83
  br label %bb34
bb34:
  %t135 = load i1, ptr %l83, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l2, ptr %l84, !tbaa !29
  %t136 = call ptr @__olang_scope_hold(ptr %s6)
  %t137 = ptrtoint ptr %t136 to i64
  store i64 %t137, ptr %l85, !tbaa !24
  %t138 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3afpath_2e0
  br i1 %t138, label %bb37, label %bb38
bb36:
  br label %bb47
bb37:
  %t140 = call ptr @__olang_region_make(ptr %s6)
  %t141 = ptrtoint ptr %t140 to i64
  store i64 %t141, ptr %l85, !tbaa !24
  br label %bb38
bb38:
  %t142 = load i64, ptr %l85
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l87, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2estd_2fprelude_2farray_3aArrayIter_3cI64_3e_2e0
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load i64, ptr %l85
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = call ptr @__olang_region_make(ptr %t149)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l87, !tbaa !24
  br label %bb40
bb40:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = mul i64 1, 8
  %t154 = load i64, ptr %l87
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = call ptr @__olang_scope_alloc_zeroed(ptr %t155, i64 %t153)
  %t157 = insertvalue { i64, ptr } undef, i64 1, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l90, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i64, ptr %t161, i64 0
  store i64 %t152, ptr %t162, !tbaa !34
  %t163 = load i64, ptr %l85
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = load i64, ptr %l85
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t168 = call %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %t164, ptr %t166, { i64, ptr } %t167)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t168, ptr %l91
  br label %bb41
bb41:
  %t169 = load %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381", ptr %l91
  %t170 = load i64, ptr %l85
  %t171 = inttoptr i64 %t170 to ptr
  %t172 = call ptr @__olang_scope_alloc_a(ptr %t171, i64 24, i64 8)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t169, ptr %t172
  %t173 = load i64, ptr %l85
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = load i64, ptr %l85
  %t176 = inttoptr i64 %t175 to ptr
  %t178 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %t174, ptr %t176, ptr %t172)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %l93
  br label %bb42
bb42:
  %t179 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3afpath_2e0
  br i1 %t179, label %bb43, label %bb44
bb43:
  %t181 = load i64, ptr %l85
  %t182 = inttoptr i64 %t181 to ptr
  %t183 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93, i32 0, i32 0
  %t184 = load { i64, ptr }, ptr %t183
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = call ptr @__olang_region_or(ptr %t185, ptr null)
  %t187 = call ptr @__olang_region_home(ptr %t186)
  %t188 = icmp ne ptr %t187, null
  %t189 = select i1 %t188, ptr %t187, ptr null
  call void @__olang_region_settle_in(ptr %t182, ptr %t189)
  br label %bb44
bb44:
  %t190 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t190, ptr %l95, !tbaa !27
  %t191 = load i64, ptr %l9, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr i32, ptr %t194, i64 %t191
  %t196 = load i32, ptr %t195, !tbaa !33
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  %t199 = call %"compiler/effects:fpath" @compiler_2feffects_3afpath_2ector(ptr %s6, ptr %s6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, i32 %t196)
  store %"compiler/effects:fpath" %t199, ptr %l98
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l84, !tbaa !29
  %t201 = load %"compiler/effects:fpath", ptr %l98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ePush_3ccompiler_2feffects_3afpath_3e(ptr %v1, ptr %s6, ptr %t200, %"compiler/effects:fpath" %t201)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb88
bb47:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/effects:Effects", ptr %t202, i32 0, i32 0
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  %t208 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t208, ptr %l102, !tbaa !27
  %t209 = load i64, ptr %l9, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t207, i32 %t214)
  store i1 %t217, ptr %l105
  br label %bb48
bb48:
  %t218 = load i1, ptr %l105, !tbaa !21
  br i1 %t218, label %bb49, label %bb50
bb49:
  br label %bb88
bb50:
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l106, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t221, ptr %l108, !tbaa !27
  %t222 = load i64, ptr %l9, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i32, ptr %t225, i64 %t222
  %t227 = load i32, ptr %t226, !tbaa !33
  %t230 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %t220, i32 %t227)
  store i32 %t230, ptr %l111
  br label %bb52
bb52:
  %t231 = load ptr, ptr %l106, !tbaa !29
  %t232 = load i32, ptr %l111, !tbaa !23
  %t233 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %s8, ptr %t231, i32 %t232)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l112
  br label %bb53
bb53:
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  %t235 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %t235
  store ptr %t235, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t237 = load i64, ptr %l11, !tbaa !24
  store i64 %t237, ptr %l114, !tbaa !24
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %s8, ptr %t238)
  store i64 %t240, ptr %l116
  br label %bb55
bb55:
  %t241 = load i64, ptr %l114, !tbaa !24
  %t242 = load i64, ptr %l116, !tbaa !24
  %t243 = icmp slt i64 %t241, %t242
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb57:
  br label %bb58
bb58:
  %t247 = load ptr, ptr %l10, !tbaa !29
  %t248 = load i64, ptr %l11, !tbaa !24
  %t251 = call %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %s8, ptr %s8, ptr %t247, i64 %t248)
  store %"compiler/effects:fpath" %t251, ptr %l121
  br label %bb59
bb59:
  %t252 = load %"compiler/effects:fpath", ptr %l121
  store %"compiler/effects:fpath" %t252, ptr %l122
  %t253 = call ptr @__olang_scope_hold(ptr %s9)
  %t254 = ptrtoint ptr %t253 to i64
  store i64 %t254, ptr %l123, !tbaa !24
  %t255 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t255, label %bb60, label %bb61
bb60:
  %t257 = call ptr @__olang_region_make_part(ptr %s9)
  %t258 = ptrtoint ptr %t257 to i64
  store i64 %t258, ptr %l123, !tbaa !24
  br label %bb61
bb61:
  %t259 = getelementptr %"compiler/effects:fpath", ptr %l122, i32 0, i32 0
  %t260 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t259, i32 0, i32 0
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l125, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l126, !tbaa !24
  %t264 = load i64, ptr %l126, !tbaa !24
  %t265 = mul i64 %t264, 8
  %t266 = load i64, ptr %l123
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = call ptr @__olang_held_alloc(ptr %t267, i64 %t265)
  %t269 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  store { i64, ptr } %t270, ptr %l127, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = load i64, ptr %l126, !tbaa !24
  %t276 = mul i64 %t275, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %t274, i64 %t276, i1 false)
  %t277 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t278 = getelementptr %"compiler/effects:fpath", ptr %l122, i32 0, i32 0
  %t279 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t278, i32 0, i32 0
  store { i64, ptr } %t277, ptr %t279, !tbaa !27
  %t280 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t280, label %bb62, label %bb63
bb62:
  %t282 = getelementptr %"compiler/effects:fpath", ptr %l122, i32 0, i32 0
  %t283 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t282, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t287 = icmp eq i64 %t285, 0
  br i1 %t287, label %bb64, label %bb65
bb63:
  %t289 = load %"compiler/effects:fpath", ptr %l122
  store %"compiler/effects:fpath" %t289, ptr %l12
  %t290 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 0
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %t290)
  store i64 %t292, ptr %l132
  br label %bb66
bb64:
  %t293 = getelementptr %"compiler/effects:fpath", ptr %l122, i32 0, i32 0
  %t294 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t293, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t294, !tbaa !27
  br label %bb65
bb65:
  %t295 = getelementptr %"compiler/effects:fpath", ptr %l122, i32 0, i32 0
  %t296 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t295, i32 0, i32 0
  %t297 = load i64, ptr %l123
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = load { i64, ptr }, ptr %t296
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = call ptr @__olang_region_or(ptr %t300, ptr null)
  %t302 = icmp ne ptr %t301, null
  %t303 = select i1 %t302, ptr %t301, ptr null
  call void @__olang_region_settle_in(ptr %t298, ptr %t303)
  br label %bb63
bb66:
  %t304 = load i64, ptr @G_2ecompiler_2feffects_2eFieldDepth, !tbaa !24
  %t305 = load i64, ptr %l132, !tbaa !24
  %t307 = icmp sge i64 %t305, %t304
  br i1 %t307, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s9)
  br label %bb86
bb68:
  br label %bb69
bb69:
  %t309 = call ptr @__olang_scope_hold(ptr %s9)
  %t310 = ptrtoint ptr %t309 to i64
  store i64 %t310, ptr %l135, !tbaa !24
  %t311 = load i1, ptr @olang_2esole_2estd_2fprelude_2farray_3aArrayIter_3cI64_3e_2e0
  br i1 %t311, label %bb70, label %bb71
bb70:
  %t313 = call ptr @__olang_region_make(ptr %s9)
  %t314 = ptrtoint ptr %t313 to i64
  store i64 %t314, ptr %l135, !tbaa !24
  br label %bb71
bb71:
  %t315 = load i64, ptr %l9, !tbaa !24
  %t316 = mul i64 1, 8
  %t317 = load i64, ptr %l135
  %t318 = inttoptr i64 %t317 to ptr
  %t319 = call ptr @__olang_scope_alloc_zeroed(ptr %t318, i64 %t316)
  %t320 = insertvalue { i64, ptr } undef, i64 1, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l138, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i64, ptr %t324, i64 0
  store i64 %t315, ptr %t325, !tbaa !34
  %t326 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t327 = call %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %s9, ptr %s9, { i64, ptr } %t326)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t327, ptr %l139
  br label %bb72
bb72:
  %t328 = load %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381", ptr %l139
  %t329 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 24, i64 8)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t328, ptr %t329
  %t331 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %s9, ptr %s9, ptr %t329)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t331, ptr %l141
  br label %bb73
bb73:
  %t332 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t332, ptr %l13
  %t333 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 0
  store ptr %t333, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb74
bb74:
  %t335 = load i64, ptr %l15, !tbaa !24
  store i64 %t335, ptr %l143, !tbaa !24
  %t336 = load ptr, ptr %l14, !tbaa !29
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %t336)
  store i64 %t338, ptr %l145
  br label %bb75
bb75:
  %t339 = load i64, ptr %l143, !tbaa !24
  %t340 = load i64, ptr %l145, !tbaa !24
  %t341 = icmp slt i64 %t339, %t340
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb76, label %bb77
bb76:
  br label %bb82
bb77:
  br label %bb78
bb78:
  %t345 = load ptr, ptr %l14, !tbaa !29
  %t346 = load i64, ptr %l15, !tbaa !24
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t345, i64 %t346)
  store i64 %t349, ptr %l150
  br label %bb79
bb79:
  %t350 = load i64, ptr %l150, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s9, ptr %l13, i64 %t350)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t354 = load i64, ptr %l15, !tbaa !24
  %t357 = add i64 %t354, 1
  store i64 %t357, ptr %l15, !tbaa !24
  br label %bb74
bb82:
  store ptr %l2, ptr %l156, !tbaa !29
  %t359 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t360 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 1
  %t361 = load i32, ptr %t360, !tbaa !23
  %t364 = call %"compiler/effects:fpath" @compiler_2feffects_3afpath_2ector(ptr %s9, ptr %s9, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t359, i32 %t361)
  store %"compiler/effects:fpath" %t364, ptr %l159
  br label %bb83
bb83:
  %t366 = call %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %s9, ptr %l159)
  store %"compiler/effects:fpath" %t366, ptr %l161
  br label %bb84
bb84:
  %t367 = load ptr, ptr %l156, !tbaa !29
  %t368 = load %"compiler/effects:fpath", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ePush_3ccompiler_2feffects_3afpath_3e(ptr %v1, ptr %s9, ptr %t367, %"compiler/effects:fpath" %t368)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s9)
  br label %bb86
bb86:
  %t369 = load i64, ptr %l11, !tbaa !24
  %t372 = add i64 %t369, 1
  store i64 %t372, ptr %l11, !tbaa !24
  br label %bb54
bb87:
  call void @__olang_scope_close(ptr %s8)
  br label %bb88
bb88:
  %t374 = load i64, ptr %l8, !tbaa !24
  %t377 = add i64 %t374, 1
  store i64 %t377, ptr %l8, !tbaa !24
  br label %bb26
bb89:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/effects:Effects", ptr %t379, i32 0, i32 63
  store ptr %t381, ptr %l169, !tbaa !29
  %t382 = load i32, ptr %l1, !tbaa !23
  store i32 %t382, ptr %l170, !tbaa !23
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %l171
  %t385 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %s0, ptr %l171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %l173
  br label %bb90
bb90:
  %t386 = load ptr, ptr %l169, !tbaa !29
  %t387 = load i32, ptr %l170, !tbaa !23
  %t388 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H23909c0b6cdd8c6a8e8461d347ccf8af(ptr %v0, ptr %s0, ptr %t386, i32 %t387, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t388)
  br label %bb91
bb91:
  %t389 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t389, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/effects:part"
  %l6 = alloca i64
  %l7 = alloca %"compiler/effects:given"
  %l8 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l25 = alloca i64
  %l28 = alloca i32
  %l36 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca %"compiler/effects:part"
  %l50 = alloca %"compiler/effects:part"
  %l55 = alloca i1
  %l63 = alloca i1
  %l70 = alloca i1
  %l81 = alloca %"compiler/effects:given"
  %l82 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca ptr
  %l107 = alloca i64
  %l109 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca %"compiler/effects:Facts"
  %l130 = alloca ptr
  %l135 = alloca %"compiler/effects:Facts"
  %l140 = alloca i1
  %l145 = alloca ptr
  %l149 = alloca %"compiler/effects:given"
  %l154 = alloca i1
  %l156 = alloca i1
  %l159 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i1
  %l166 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/effects:pend", ptr %t5, i32 0, i32 3
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l15, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/effects:pend", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l17, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/effects:pend", ptr %t18, i32 0, i32 3
  store ptr %t20, ptr %l19, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 26
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/effects:pend", ptr %t25, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t28)
  store i64 %t31, ptr %l25
  br label %bb5
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/effects:pend", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t32, ptr %t36, i64 0)
  br label %bb8
bb5:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/effects:pend", ptr %t40, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t47 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t44, i64 %t45, i64 %t43)
  store i32 %t47, ptr %l28
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l15, !tbaa !29
  %t49 = load ptr, ptr %l17, !tbaa !29
  %t50 = load ptr, ptr %l19, !tbaa !29
  %t51 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v1, ptr %t48, ptr %t49, ptr %t50, i32 %t51, i64 0)
  br label %bb7
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 49
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp ne i64 %t55, 0
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyNow(ptr %v0, ptr %t59)
  store i1 %t61, ptr %l38
  br label %bb12
bb11:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t62 = load i1, ptr %l38, !tbaa !21
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l36, !tbaa !21
  store i1 %t63, ptr %l2, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Effects", ptr %t64, i32 0, i32 38
  store ptr %t66, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l4, !tbaa !24
  store i64 %t68, ptr %l41, !tbaa !24
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l43
  br label %bb15
bb15:
  %t72 = load i64, ptr %l41, !tbaa !24
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb16, label %bb17
bb16:
  br label %bb79
bb17:
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/effects:part" %t82, ptr %l48
  br label %bb19
bb19:
  %t84 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l48)
  store %"compiler/effects:part" %t84, ptr %l50
  br label %bb20
bb20:
  %t85 = load %"compiler/effects:part", ptr %l50
  store %"compiler/effects:part" %t85, ptr %l5
  %t86 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t90 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb23
bb22:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb23
bb23:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t102 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t110 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t113 = icmp sge i64 %t111, 63
  store i1 %t113, ptr %l63, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb29
bb29:
  %t115 = load i1, ptr %l63, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  store i64 %t116, ptr %l6, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/effects:pend", ptr %t118, i32 0, i32 0
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = icmp sge i64 %t121, 0
  br i1 %t123, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb35
bb34:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t126 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  store i1 %t129, ptr %l70, !tbaa !21
  br label %bb35
bb35:
  %t131 = load i1, ptr %l70, !tbaa !21
  br i1 %t131, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/effects:pend", ptr %t132, i32 0, i32 0
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/effects:pend", ptr %t136, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr %l6, !tbaa !24
  %t141 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 1
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 2
  %t144 = load i32, ptr %t143, !tbaa !23
  %t150 = call %"compiler/effects:given" @compiler_2feffects_3agiven_2ector(ptr %s7, i64 %t135, i64 %t139, i64 %t140, i64 %t142, i32 %t144)
  store %"compiler/effects:given" %t150, ptr %l81
  br label %bb38
bb37:
  br label %bb54
bb38:
  %t151 = load %"compiler/effects:given", ptr %l81
  store %"compiler/effects:given" %t151, ptr %l7
  %t152 = call ptr @__olang_scope_hold(ptr %s7)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l82, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t156 = call ptr @__olang_region_make(ptr %s7)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l82, !tbaa !24
  br label %bb40
bb40:
  %t158 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 4
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l85
  %t161 = load i64, ptr %l82
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = call ptr @__olang_scope_hold(ptr %t162)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l86, !tbaa !24
  %t165 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load i64, ptr %l82
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_region_make_part(ptr %t168)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l86, !tbaa !24
  br label %bb42
bb42:
  %t171 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l88, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l89, !tbaa !24
  %t175 = load i64, ptr %l89, !tbaa !24
  %t176 = mul i64 %t175, 8
  %t177 = load i64, ptr %l86
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = call ptr @__olang_held_alloc(ptr %t178, i64 %t176)
  %t180 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l90, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = load i64, ptr %l89, !tbaa !24
  %t187 = mul i64 %t186, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t183, ptr %t185, i64 %t187, i1 false)
  %t188 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t189 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  store { i64, ptr } %t188, ptr %t189, !tbaa !27
  %t190 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t196 = icmp eq i64 %t194, 0
  br i1 %t196, label %bb45, label %bb46
bb44:
  %t198 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t198, label %bb47, label %bb48
bb45:
  %t200 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t200, !tbaa !27
  br label %bb46
bb46:
  %t201 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t202 = load i64, ptr %l86
  %t203 = inttoptr i64 %t202 to ptr
  %t204 = load { i64, ptr }, ptr %t201
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = call ptr @__olang_region_or(ptr %t205, ptr null)
  %t207 = icmp ne ptr %t206, null
  %t208 = select i1 %t207, ptr %t206, ptr null
  call void @__olang_region_settle_in(ptr %t203, ptr %t208)
  br label %bb44
bb47:
  %t209 = load i64, ptr %l82
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = call ptr @__olang_region_or(ptr %t213, ptr null)
  %t215 = call ptr @__olang_region_home(ptr %t214)
  %t216 = icmp ne ptr %t215, null
  %t217 = select i1 %t216, ptr %t215, ptr null
  call void @__olang_region_settle_in(ptr %t210, ptr %t217)
  br label %bb48
bb48:
  %t218 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 5
  %t219 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t218
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l95
  %t220 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  %t221 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, ptr %t221
  %t222 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t222, label %bb49, label %bb50
bb49:
  %t224 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = call ptr @__olang_region_or(ptr %t226, ptr null)
  %t228 = call ptr @__olang_region_home(ptr %t227)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_drop(ptr %t230)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l95
  br label %bb50
bb50:
  %t231 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t231, label %bb51, label %bb52
bb51:
  %t233 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t234 = load { i64, ptr }, ptr %t233
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  call void @__olang_region_release_part(ptr %t236, i64 %t235)
  store { i64, ptr } zeroinitializer, ptr %t233
  br label %bb52
bb52:
  %t237 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 5
  %t238 = load i64, ptr %t237, !tbaa !24
  %t240 = getelementptr %"compiler/effects:given", ptr %l7, i32 0, i32 6
  store i64 %t238, ptr %t240, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/effects:Effects", ptr %t241, i32 0, i32 30
  %t244 = load %"compiler/effects:given", ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ePush_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %s7, ptr %t243, %"compiler/effects:given" %t244)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb54:
  %t247 = load i64, ptr %l6, !tbaa !24
  %t248 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t251 = icmp eq i64 %t247, %t248
  br i1 %t251, label %bb55, label %bb56
bb55:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l105, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/effects:Effects", ptr %t254, i32 0, i32 25
  %t257 = getelementptr %"compiler/effects:Facts", ptr %t256, i32 0, i32 24
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l107, !tbaa !24
  %t259 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 1
  %t260 = load i64, ptr %t259, !tbaa !24
  %t262 = call i64 @compiler_2feffects_2eparamBit(i64 %t260)
  store i64 %t262, ptr %l109
  br label %bb57
bb56:
  %t263 = load i64, ptr %l6, !tbaa !24
  %t264 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t267 = icmp eq i64 %t263, %t264
  br i1 %t267, label %bb64, label %bb65
bb57:
  %t269 = load i64, ptr %l107, !tbaa !24
  %t270 = load i64, ptr %l109, !tbaa !24
  %t271 = or i64 %t269, %t270
  %t273 = load ptr, ptr %l105, !tbaa !29
  %t274 = getelementptr %"compiler/effects:Effects", ptr %t273, i32 0, i32 25
  %t275 = getelementptr %"compiler/effects:Facts", ptr %t274, i32 0, i32 24
  store i64 %t271, ptr %t275, !tbaa !24
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/effects:Effects", ptr %t276, i32 0, i32 49
  %t279 = load i64, ptr %t278, !tbaa !24
  %t281 = icmp ne i64 %t279, 0
  br i1 %t281, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s9
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/effects:Effects", ptr %t283, i32 0, i32 25
  store ptr %t285, ptr %l115, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/effects:Effects", ptr %t286, i32 0, i32 0
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/generic:Program", ptr %t289, i32 0, i32 2
  store ptr %t291, ptr %l118, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/effects:Effects", ptr %t293, i32 0, i32 35
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 1
  %t298 = load i64, ptr %t297, !tbaa !24
  %t302 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t292, i64 %t296, i64 %t298)
  store i32 %t302, ptr %l123
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t303 = load ptr, ptr %l118, !tbaa !29
  %t304 = load i32, ptr %l123, !tbaa !23
  %t305 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t303, i32 %t304)
  store %"compiler/effects:Facts" %t305, ptr %l124
  br label %bb61
bb61:
  %t306 = load ptr, ptr %l115, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s9, ptr %t306, ptr %l124)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  br label %bb77
bb64:
  store %olang.scope zeroinitializer, ptr %s11
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/effects:Effects", ptr %t308, i32 0, i32 25
  store ptr %t310, ptr %l130, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/effects:Effects", ptr %t311, i32 0, i32 0
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  %t317 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 2
  %t318 = load i32, ptr %t317, !tbaa !23
  %t321 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t316, i32 %t318)
  store %"compiler/effects:Facts" %t321, ptr %l135
  br label %bb66
bb65:
  %t322 = load i64, ptr %l6, !tbaa !24
  %t323 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t326 = icmp eq i64 %t322, %t323
  br i1 %t326, label %bb68, label %bb69
bb66:
  %t328 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s11, ptr %t328, ptr %l135)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb68:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb70
bb69:
  %t330 = load i64, ptr %l6, !tbaa !24
  %t331 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t334 = icmp eq i64 %t330, %t331
  store i1 %t334, ptr %l140, !tbaa !21
  br label %bb70
bb70:
  %t336 = load i1, ptr %l140, !tbaa !21
  br i1 %t336, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/effects:Effects", ptr %t337, i32 0, i32 30
  store ptr %t339, ptr %l145, !tbaa !29
  %t340 = load i64, ptr %l6, !tbaa !24
  %t341 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 1
  %t342 = load i64, ptr %t341, !tbaa !24
  %t343 = getelementptr %"compiler/effects:part", ptr %l5, i32 0, i32 2
  %t344 = load i32, ptr %t343, !tbaa !23
  %t348 = call %"compiler/effects:given" @compiler_2feffects_3agiven_2ector(ptr %s13, i64 -1, i64 0, i64 %t340, i64 %t342, i32 %t344)
  store %"compiler/effects:given" %t348, ptr %l149
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t349 = load ptr, ptr %l145, !tbaa !29
  %t350 = load %"compiler/effects:given", ptr %l149
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ePush_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %s13, ptr %t349, %"compiler/effects:given" %t350)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t351 = load i64, ptr %l4, !tbaa !24
  %t354 = add i64 %t351, 1
  store i64 %t354, ptr %l4, !tbaa !24
  br label %bb14
bb79:
  %t356 = load i1, ptr %l2, !tbaa !21
  br i1 %t356, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb83
bb81:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyNow(ptr %v0, ptr %t358)
  store i1 %t360, ptr %l156
  br label %bb82
bb82:
  %t361 = load i1, ptr %l156, !tbaa !21
  %t362 = xor i1 %t361, true
  store i1 %t362, ptr %l154, !tbaa !21
  br label %bb83
bb83:
  %t364 = load i1, ptr %l154, !tbaa !21
  br i1 %t364, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb85:
  br label %bb86
bb86:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyDoes(ptr %v0, ptr %s0, ptr %t365)
  store { i64, ptr } %t367, ptr %l159
  br label %bb87
bb87:
  %t368 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t368, ptr %l8, !tbaa !27
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l160, !tbaa !29
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr %"compiler/effects:pend", ptr %t370, i32 0, i32 2
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t373)
  store %"compiler/source:Span" %t375, ptr %l163
  br label %bb88
bb88:
  %t376 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t378 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t376, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t378, ptr %l165
  br label %bb89
bb89:
  %t379 = load i1, ptr %l165, !tbaa !21
  br i1 %t379, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l166, !tbaa !27
  br label %bb92
bb91:
  %t380 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t381 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t384 = extractvalue { i64, ptr } %t380, 1
  %t385 = extractvalue { i64, ptr } %t380, 0
  %t386 = add i64 %t382, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t381, i64 %t382)
  %t388 = getelementptr i8, ptr %t387, i64 %t382
  call void @olang_textcopy(ptr %t388, ptr %t384, i64 %t385)
  %t389 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t387, 1
  store { i64, ptr } %t390, ptr %l166, !tbaa !27
  br label %bb92
bb92:
  %t393 = load ptr, ptr %l160, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l163
  %t395 = load { i64, ptr }, ptr %l166, !tbaa !27
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebecause(ptr %v0, ptr %s0, ptr %t393, %"compiler/source:Span" %t394, { i64, ptr } %t395)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l52 = alloca i1
  %l63 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/effects:Effects", ptr %t10, i32 0, i32 35
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %t13)
  store ptr %t16, ptr %l14
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t21, i32 %t20)
  store i32 %t23, ptr %l17
  br label %bb2
bb2:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evalueArray(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb3
bb3:
  %t30 = load i1, ptr %l20, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t40 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewidened(ptr %v0, ptr %v1, ptr %t34, ptr %t35, i32 %t36)
  store i1 %t40, ptr %l26
  br label %bb7
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t48, ptr %l31
  br label %bb11
bb11:
  %t49 = load i1, ptr %l31, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb15
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 35
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %t52, i64 %t56)
  store i64 %t59, ptr %l37
  br label %bb14
bb14:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l41, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 18}
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t73 = load i1, ptr %l42, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t80 = load ptr, ptr %l3, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 8}
  %t87 = icmp eq i64 %t85, 0
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l48, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb30
bb27:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t93, i32 0, i32 0
  %t95 = load %"compiler/source:Span", ptr %t94
  store %"compiler/source:Span" %t95, ptr %l4
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l5, !tbaa !23
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t105, i32 0, i32 2
  %t107 = load i32, ptr %t106
  store i32 %t107, ptr %l6, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Effects", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/effects:Effects", ptr %t112, i32 0, i32 35
  %t115 = load i64, ptr %t114, !tbaa !24
  %t118 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t111, i64 %t115)
  store ptr %t118, ptr %l63
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 7
  %t122 = load i32, ptr %l6, !tbaa !23
  %t124 = sext i32 %t122 to i64
  %t127 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t121, i64 %t124)
  store %"compiler/typed:Local" %t127, ptr %l68
  br label %bb29
bb29:
  %t128 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 4
  %t129 = load i32, ptr %t128, !range !{i32 0, i32 7}
  %t131 = trunc i64 0 to i32
  %t132 = icmp eq i32 %t129, %t131
  store i1 %t132, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t134 = load i1, ptr %l52, !tbaa !21
  store i1 %t134, ptr %l40, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8f0e2357f3b9767c_69d91ea023337680)
  unreachable
bb36:
  %t135 = load i1, ptr %l40, !tbaa !21
  store i1 %t135, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretFields(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/effects:fpath"
  %l6 = alloca ptr
  %l7 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/effects:part"
  %l13 = alloca i64
  %lp14 = alloca ptr
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/effects:fpath"
  %l39 = alloca %"compiler/effects:fpath"
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca i64
  %l59 = alloca ptr
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca i64
  %l72 = alloca i64
  %l77 = alloca %"compiler/effects:part"
  %l79 = alloca %"compiler/effects:part"
  %l84 = alloca i1
  %l92 = alloca %"compiler/effects:part"
  %l93 = alloca i64
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca ptr
  %l118 = alloca %"compiler/effects:fret"
  %l120 = alloca %"compiler/effects:fret"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l20, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l24
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t24, i32 %t23)
  store i32 %t26, ptr %l27
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = load i32, ptr %l27, !tbaa !23
  %t29 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t29, ptr %l28
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i32, ptr %l28, !tbaa !23
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %s1, ptr %t30, i32 %t31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l29
  br label %bb5
bb5:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t34 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %t34
  store ptr %t34, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l4, !tbaa !24
  store i64 %t36, ptr %l31, !tbaa !24
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %s1, ptr %t37)
  store i64 %t39, ptr %l33
  br label %bb7
bb7:
  %t40 = load i64, ptr %l31, !tbaa !24
  %t41 = load i64, ptr %l33, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %s1, ptr %s1, ptr %t46, i64 %t47)
  store %"compiler/effects:fpath" %t50, ptr %l38
  br label %bb11
bb11:
  %t51 = load %"compiler/effects:fpath", ptr %l38
  store %"compiler/effects:fpath" %t51, ptr %l39
  %t52 = call ptr @__olang_scope_hold(ptr %s2)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l40, !tbaa !24
  %t54 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = call ptr @__olang_region_make_part(ptr %s2)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t58 = getelementptr %"compiler/effects:fpath", ptr %l39, i32 0, i32 0
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t58, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l42, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l43, !tbaa !24
  %t63 = load i64, ptr %l43, !tbaa !24
  %t64 = mul i64 %t63, 8
  %t65 = load i64, ptr %l40
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = mul i64 %t74, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t77 = getelementptr %"compiler/effects:fpath", ptr %l39, i32 0, i32 0
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = getelementptr %"compiler/effects:fpath", ptr %l39, i32 0, i32 0
  %t82 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t81, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  %t86 = icmp eq i64 %t84, 0
  br i1 %t86, label %bb16, label %bb17
bb15:
  %t88 = load %"compiler/effects:fpath", ptr %l39
  store %"compiler/effects:fpath" %t88, ptr %l5
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Effects", ptr %t89, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t91)
  br label %bb18
bb16:
  %t93 = getelementptr %"compiler/effects:fpath", ptr %l39, i32 0, i32 0
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t94, !tbaa !27
  br label %bb17
bb17:
  %t95 = getelementptr %"compiler/effects:fpath", ptr %l39, i32 0, i32 0
  %t96 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %l40
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = load { i64, ptr }, ptr %t96
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr null
  call void @__olang_region_settle_in(ptr %t98, ptr %t103)
  br label %bb15
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 46
  store ptr %t106, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  %t108 = load i64, ptr %l7, !tbaa !24
  store i64 %t108, ptr %l52, !tbaa !24
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l54
  br label %bb20
bb20:
  %t112 = load i64, ptr %l52, !tbaa !24
  %t113 = load i64, ptr %l54, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store ptr %t122, ptr %l59
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l59, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/effects:fpath", ptr %l5, i32 0, i32 0
  %t127 = getelementptr %"compiler/effects:fpath", ptr %l5, i32 0, i32 1
  %t128 = load i32, ptr %t127, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v0, ptr %s2, ptr %t124, ptr %t123, ptr %t126, i32 %t128, i64 0)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb19
bb27:
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l67
  br label %bb28
bb28:
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t139, ptr %lp9
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t141 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Effects", ptr %t142, i32 0, i32 38
  store ptr %t144, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t146 = load i64, ptr %l11, !tbaa !24
  store i64 %t146, ptr %l70, !tbaa !24
  %t147 = load ptr, ptr %l10, !tbaa !29
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t147)
  store i64 %t149, ptr %l72
  br label %bb30
bb30:
  %t150 = load i64, ptr %l70, !tbaa !24
  %t151 = load i64, ptr %l72, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb31, label %bb32
bb31:
  br label %bb59
bb32:
  br label %bb33
bb33:
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t156, i64 %t157)
  store %"compiler/effects:part" %t160, ptr %l77
  br label %bb34
bb34:
  %t162 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l77)
  store %"compiler/effects:part" %t162, ptr %l79
  br label %bb35
bb35:
  %t163 = load %"compiler/effects:part", ptr %l79
  store %"compiler/effects:part" %t163, ptr %l12
  %t164 = getelementptr %"compiler/effects:part", ptr %l12, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t168 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  %t171 = icmp eq i64 %t167, %t168
  br i1 %t171, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb38
bb37:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  %t177 = icmp eq i64 %t173, %t174
  store i1 %t177, ptr %l84, !tbaa !21
  br label %bb38
bb38:
  %t179 = load i1, ptr %l84, !tbaa !21
  br i1 %t179, label %bb39, label %bb40
bb39:
  %t180 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  store i64 %t180, ptr %l13, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t182 = load i64, ptr %l13, !tbaa !24
  %t183 = getelementptr %"compiler/effects:part", ptr %l12, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  %t185 = getelementptr %"compiler/effects:part", ptr %l12, i32 0, i32 2
  %t186 = load i32, ptr %t185, !tbaa !23
  %t190 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t182, i64 %t184, i32 %t186, ptr null)
  store %"compiler/effects:part" %t190, ptr %l92
  br label %bb42
bb42:
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t191, ptr %lp14
  %t192 = load %"compiler/effects:part", ptr %l92
  %t193 = load ptr, ptr %lp14
  store %"compiler/effects:part" %t192, ptr %t193
  %t194 = call ptr @__olang_scope_hold(ptr %v0)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l93, !tbaa !24
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t196, label %bb43, label %bb44
bb43:
  %t198 = call ptr @__olang_region_make(ptr %v0)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l93, !tbaa !24
  br label %bb44
bb44:
  %t200 = getelementptr %"compiler/effects:part", ptr %l12, i32 0, i32 4
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t200
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l96
  %t203 = load i64, ptr %l93
  %t204 = inttoptr i64 %t203 to ptr
  %t205 = call ptr @__olang_scope_hold(ptr %t204)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l97, !tbaa !24
  %t207 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t207, label %bb45, label %bb46
bb45:
  %t209 = load i64, ptr %l93
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = call ptr @__olang_region_make_part(ptr %t210)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l97, !tbaa !24
  br label %bb46
bb46:
  %t213 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l99, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l100, !tbaa !24
  %t217 = load i64, ptr %l100, !tbaa !24
  %t218 = mul i64 %t217, 8
  %t219 = load i64, ptr %l97
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = call ptr @__olang_held_alloc(ptr %t220, i64 %t218)
  %t222 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l101, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l100, !tbaa !24
  %t229 = mul i64 %t228, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t225, ptr %t227, i64 %t229, i1 false)
  %t230 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t231 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  store { i64, ptr } %t230, ptr %t231, !tbaa !27
  %t232 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t232, label %bb47, label %bb48
bb47:
  %t234 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t238 = icmp eq i64 %t236, 0
  br i1 %t238, label %bb49, label %bb50
bb48:
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t240, label %bb51, label %bb52
bb49:
  %t242 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t242, !tbaa !27
  br label %bb50
bb50:
  %t243 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  %t244 = load i64, ptr %l97
  %t245 = inttoptr i64 %t244 to ptr
  %t246 = load { i64, ptr }, ptr %t243
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = call ptr @__olang_region_or(ptr %t247, ptr null)
  %t249 = icmp ne ptr %t248, null
  %t250 = select i1 %t249, ptr %t248, ptr null
  call void @__olang_region_settle_in(ptr %t245, ptr %t250)
  br label %bb48
bb51:
  %t251 = load i64, ptr %l93
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = call ptr @__olang_region_home(ptr %t256)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr null
  call void @__olang_region_settle_in(ptr %t252, ptr %t259)
  br label %bb52
bb52:
  %t260 = load ptr, ptr %lp14
  %t261 = getelementptr %"compiler/effects:part", ptr %t260, i32 0, i32 4
  %t262 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t261
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t262, ptr %l106
  %t263 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  %t264 = load ptr, ptr %lp14
  %t265 = getelementptr %"compiler/effects:part", ptr %t264, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %t265
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t266, label %bb53, label %bb54
bb53:
  %t268 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106, i32 0, i32 0
  %t269 = load { i64, ptr }, ptr %t268
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = call ptr @__olang_region_or(ptr %t270, ptr null)
  %t272 = call ptr @__olang_region_home(ptr %t271)
  %t273 = icmp ne ptr %t272, null
  %t274 = select i1 %t273, ptr %t272, ptr null
  call void @__olang_region_drop(ptr %t274)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l106
  br label %bb54
bb54:
  %t275 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t275, label %bb55, label %bb56
bb55:
  %t277 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  call void @__olang_region_release_part(ptr %t280, i64 %t279)
  store { i64, ptr } zeroinitializer, ptr %t277
  br label %bb56
bb56:
  %t281 = getelementptr %"compiler/effects:part", ptr %l12, i32 0, i32 5
  %t282 = load i64, ptr %t281, !tbaa !24
  %t284 = load ptr, ptr %lp14
  %t285 = getelementptr %"compiler/effects:part", ptr %t284, i32 0, i32 5
  store i64 %t282, ptr %t285, !tbaa !24
  %t286 = load ptr, ptr %lp9
  %t287 = load ptr, ptr %lp14
  %t288 = load %"compiler/effects:part", ptr %t287
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t286, %"compiler/effects:part" %t288)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t291 = load i64, ptr %l11, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l11, !tbaa !24
  br label %bb29
bb59:
  %t296 = load ptr, ptr %lp2
  store ptr %t296, ptr %l115, !tbaa !29
  %t297 = getelementptr %"compiler/effects:fpath", ptr %l5, i32 0, i32 0
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t297
  %t299 = load ptr, ptr %lp9
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t299
  %t303 = call %"compiler/effects:fret" @compiler_2feffects_3afret_2ector(ptr %v0, ptr %v0, ptr %v0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300)
  store %"compiler/effects:fret" %t303, ptr %l118
  br label %bb60
bb60:
  %t305 = call %"compiler/effects:fret" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afret(ptr %s2, ptr %l118)
  store %"compiler/effects:fret" %t305, ptr %l120
  br label %bb61
bb61:
  %t306 = load ptr, ptr %l115, !tbaa !29
  %t307 = load %"compiler/effects:fret", ptr %l120
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_2ePush_3ccompiler_2feffects_3afret_3e(ptr %v0, ptr %v0, ptr %t306, %"compiler/effects:fret" %t307)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb63:
  %t308 = load i64, ptr %l4, !tbaa !24
  %t311 = add i64 %t308, 1
  store i64 %t311, ptr %l4, !tbaa !24
  br label %bb6
bb64:
  call void @__olang_scope_close(ptr %s1)
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/effects:Effects", ptr %t313, i32 0, i32 65
  %t316 = load i64, ptr %l1, !tbaa !24
  %t317 = load ptr, ptr %lp2
  %t318 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t317
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc7f0d5e54ac63fdc8f930fd93d6364c9(ptr %v0, ptr %v0, ptr %t315, i64 %t316, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t318)
  br label %bb65
bb65:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t57, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Arm", ptr %t78, i32 0, i32 2
  %t81 = load ptr, ptr %t80, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t77, ptr %t81)
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Arm", ptr %t85, i32 0, i32 3
  %t88 = load ptr, ptr %t87, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t84, ptr %t88)
  br label %bb16
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t92, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i1
  %l75 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l100 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l164 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l215 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l225 = alloca i1
  %l241 = alloca ptr
  %l242 = alloca i1
  %l258 = alloca { i64, ptr }
  %l267 = alloca ptr
  %l268 = alloca i1
  %l280 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l290 = alloca i1
  %l299 = alloca ptr
  %l300 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i1
  %l330 = alloca { i64, ptr }
  %l333 = alloca ptr
  %l334 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca i1
  %l351 = alloca ptr
  %l352 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca i1
  %l365 = alloca ptr
  %l366 = alloca i1
  %l369 = alloca i1
  %l371 = alloca ptr
  %l372 = alloca i1
  %l385 = alloca { i64, ptr }
  %l395 = alloca ptr
  %l396 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t6 = load ptr, ptr %l61, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l61, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 12
  store i1 %t12, ptr %l62, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l62, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Seq", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l75, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanStmt(ptr %v0, ptr %v1, ptr %t45, ptr %t43)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb9
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Seq", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  br label %bb16
bb16:
  br label %bb213
bb17:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t62 = load ptr, ptr %l86, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l86, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 13
  store i1 %t68, ptr %l87, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l87, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb44
bb22:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Match", ptr %t76, i32 0, i32 0
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t85 = load i64, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t93 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t93, ptr %l100, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanStmt(ptr %v0, ptr %v1, ptr %t101, ptr %t99)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb23
bb29:
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Match", ptr %t110, i32 0, i32 1
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t127 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t127, ptr %l116, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t128
  %t133 = load ptr, ptr %t132, !tbaa !39
  %t135 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanArm(ptr %v0, ptr %v1, ptr %t135, ptr %t133)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l13, !tbaa !24
  br label %bb30
bb36:
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Match", ptr %t144, i32 0, i32 2
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb37, label %bb38
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l128, !tbaa !29
  %t154 = load ptr, ptr %l7, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Match", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb39, label %bb40
bb38:
  br label %bb43
bb39:
  call void @__olang_check_failed(ptr @olang_loc_b872ac5dc3b5cbc5_c1669fe863d2e49)
  unreachable
bb40:
  br label %bb41
bb41:
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Match", ptr %t161, i32 0, i32 2
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load ptr, ptr %l128, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanArm(ptr %v0, ptr %v1, ptr %t165, ptr %t164)
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb213
bb44:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t168 = load ptr, ptr %l134, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb45, label %bb46
bb45:
  %t171 = load ptr, ptr %l134, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 8
  store i1 %t174, ptr %l135, !tbaa !21
  br label %bb46
bb46:
  %t175 = load i1, ptr %l135, !tbaa !21
  br i1 %t175, label %bb47, label %bb48
bb47:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l16, !tbaa !29
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l16, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Collect", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t182, ptr %t186)
  br label %bb50
bb50:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Collect", ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t189, ptr %t193)
  br label %bb51
bb51:
  br label %bb213
bb52:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t198 = load ptr, ptr %l147, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb53, label %bb54
bb53:
  %t201 = load ptr, ptr %l147, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 18}
  %t204 = icmp eq i64 %t202, 14
  store i1 %t204, ptr %l148, !tbaa !21
  br label %bb54
bb54:
  %t205 = load i1, ptr %l148, !tbaa !21
  br i1 %t205, label %bb55, label %bb56
bb55:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [5 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l17, !tbaa !29
  br label %bb57
bb56:
  br label %bb73
bb57:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l17, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Try", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t212, ptr %t216)
  br label %bb58
bb58:
  %t219 = load ptr, ptr %l17, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Try", ptr %t219, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l20, !tbaa !24
  br label %bb59
bb59:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb60, label %bb61
bb60:
  br label %bb72
bb61:
  br label %bb62
bb62:
  %t236 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t236, ptr %l164, !tbaa !27
  %t237 = load i64, ptr %l19, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr ptr, ptr %t240, i64 %t237
  %t242 = load ptr, ptr %t241, !tbaa !39
  store ptr %t242, ptr %l21, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l21, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Clause", ptr %t245, i32 0, i32 3
  %t248 = load ptr, ptr %t247, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t244, ptr %t248)
  br label %bb63
bb63:
  %t251 = load ptr, ptr %l21, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Clause", ptr %t251, i32 0, i32 4
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  store i64 %t258, ptr %l24, !tbaa !24
  br label %bb64
bb64:
  %t260 = load i64, ptr %l23, !tbaa !24
  %t261 = load i64, ptr %l24, !tbaa !24
  %t264 = icmp slt i64 %t260, %t261
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t268 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t268, ptr %l178, !tbaa !27
  %t269 = load i64, ptr %l23, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  %t276 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t276, ptr %t274)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t281 = load i64, ptr %l23, !tbaa !24
  %t284 = add i64 %t281, 1
  store i64 %t284, ptr %l23, !tbaa !24
  br label %bb64
bb70:
  br label %bb71
bb71:
  %t286 = load i64, ptr %l19, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l19, !tbaa !24
  br label %bb59
bb72:
  br label %bb213
bb73:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t292 = load ptr, ptr %l190, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb74, label %bb75
bb74:
  %t295 = load ptr, ptr %l190, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 18}
  %t298 = icmp eq i64 %t296, 6
  store i1 %t298, ptr %l191, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l191, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t302, i32 0, i32 2
  %t304 = load ptr, ptr %t303
  store ptr %t304, ptr %l26, !tbaa !29
  br label %bb78
bb77:
  br label %bb98
bb78:
  %t306 = load ptr, ptr %l26, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Call", ptr %t306, i32 0, i32 0
  %t309 = load ptr, ptr %t308, !tbaa !29
  store ptr %t309, ptr %l27, !tbaa !29
  %t311 = load ptr, ptr %l27, !tbaa !29
  store ptr %t311, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t312 = load ptr, ptr %l198, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb79, label %bb80
bb79:
  %t315 = load ptr, ptr %l198, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 5}
  %t318 = icmp eq i64 %t316, 2
  store i1 %t318, ptr %l199, !tbaa !21
  br label %bb80
bb80:
  %t319 = load i1, ptr %l199, !tbaa !21
  br i1 %t319, label %bb81, label %bb82
bb81:
  %t320 = load ptr, ptr %l27, !tbaa !29
  %t322 = getelementptr { i64, [3 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { ptr }, ptr %t322, i32 0, i32 0
  %t324 = load ptr, ptr %t323
  store ptr %t324, ptr %l28, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t326, ptr %t327)
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_7fc479e7b96e92ad_adfc96c825376791)
  unreachable
bb90:
  %t331 = load ptr, ptr %l26, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Call", ptr %t331, i32 0, i32 1
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t336 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t336, 0
  store i64 %t338, ptr %l31, !tbaa !24
  br label %bb91
bb91:
  %t340 = load i64, ptr %l30, !tbaa !24
  %t341 = load i64, ptr %l31, !tbaa !24
  %t344 = icmp slt i64 %t340, %t341
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb92, label %bb93
bb92:
  br label %bb97
bb93:
  br label %bb94
bb94:
  %t348 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t348, ptr %l215, !tbaa !27
  %t349 = load i64, ptr %l30, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr ptr, ptr %t352, i64 %t349
  %t354 = load ptr, ptr %t353, !tbaa !39
  %t356 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t356, ptr %t354)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t361 = load i64, ptr %l30, !tbaa !24
  %t364 = add i64 %t361, 1
  store i64 %t364, ptr %l30, !tbaa !24
  br label %bb91
bb97:
  br label %bb213
bb98:
  %t366 = load ptr, ptr %l1, !tbaa !29
  store ptr %t366, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t367 = load ptr, ptr %l224, !tbaa !29
  %t368 = icmp ne ptr %t367, null
  br i1 %t368, label %bb99, label %bb100
bb99:
  %t370 = load ptr, ptr %l224, !tbaa !29
  %t371 = load i64, ptr %t370, !range !{i64 0, i64 18}
  %t373 = icmp eq i64 %t371, 11
  store i1 %t373, ptr %l225, !tbaa !21
  br label %bb100
bb100:
  %t374 = load i1, ptr %l225, !tbaa !21
  br i1 %t374, label %bb101, label %bb102
bb101:
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr { i64, [5 x i64] }, ptr %t375, i32 0, i32 1
  %t378 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t377, i32 0, i32 2
  %t379 = load ptr, ptr %t378
  store ptr %t379, ptr %l33, !tbaa !29
  br label %bb103
bb102:
  br label %bb107
bb103:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l33, !tbaa !29
  %t384 = getelementptr %"compiler/typed:Cond", ptr %t382, i32 0, i32 0
  %t385 = load ptr, ptr %t384, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t381, ptr %t385)
  br label %bb104
bb104:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l33, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Cond", ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t389, ptr %t393)
  br label %bb105
bb105:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l33, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Cond", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t396, ptr %t400)
  br label %bb106
bb106:
  br label %bb213
bb107:
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t405 = load ptr, ptr %l241, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb108, label %bb109
bb108:
  %t408 = load ptr, ptr %l241, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 18}
  %t411 = icmp eq i64 %t409, 7
  store i1 %t411, ptr %l242, !tbaa !21
  br label %bb109
bb109:
  %t412 = load i1, ptr %l242, !tbaa !21
  br i1 %t412, label %bb110, label %bb111
bb110:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t415, i32 0, i32 2
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l34, !tbaa !29
  br label %bb112
bb111:
  br label %bb121
bb112:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l34, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Make", ptr %t420, i32 0, i32 3
  %t423 = load ptr, ptr %t422, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t419, ptr %t423)
  br label %bb113
bb113:
  %t426 = load ptr, ptr %l34, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Make", ptr %t426, i32 0, i32 2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l37, !tbaa !24
  br label %bb114
bb114:
  %t435 = load i64, ptr %l36, !tbaa !24
  %t436 = load i64, ptr %l37, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb115, label %bb116
bb115:
  br label %bb120
bb116:
  br label %bb117
bb117:
  %t443 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t443, ptr %l258, !tbaa !27
  %t444 = load i64, ptr %l36, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t451, ptr %t449)
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t456 = load i64, ptr %l36, !tbaa !24
  %t459 = add i64 %t456, 1
  store i64 %t459, ptr %l36, !tbaa !24
  br label %bb114
bb120:
  br label %bb213
bb121:
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t462 = load ptr, ptr %l267, !tbaa !29
  %t463 = icmp ne ptr %t462, null
  br i1 %t463, label %bb122, label %bb123
bb122:
  %t465 = load ptr, ptr %l267, !tbaa !29
  %t466 = load i64, ptr %t465, !range !{i64 0, i64 18}
  %t468 = icmp eq i64 %t466, 9
  store i1 %t468, ptr %l268, !tbaa !21
  br label %bb123
bb123:
  %t469 = load i1, ptr %l268, !tbaa !21
  br i1 %t469, label %bb124, label %bb125
bb124:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t472, i32 0, i32 4
  %t474 = load { i64, ptr }, ptr %t473
  store { i64, ptr } %t474, ptr %l39, !tbaa !27
  br label %bb126
bb125:
  br label %bb134
bb126:
  %t476 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t476, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t478, 0
  store i64 %t480, ptr %l42, !tbaa !24
  br label %bb127
bb127:
  %t482 = load i64, ptr %l41, !tbaa !24
  %t483 = load i64, ptr %l42, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb128, label %bb129
bb128:
  br label %bb133
bb129:
  br label %bb130
bb130:
  %t490 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t490, ptr %l280, !tbaa !27
  %t491 = load i64, ptr %l41, !tbaa !24
  %t493 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  %t498 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t498, ptr %t496)
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t503 = load i64, ptr %l41, !tbaa !24
  %t506 = add i64 %t503, 1
  store i64 %t506, ptr %l41, !tbaa !24
  br label %bb127
bb133:
  br label %bb213
bb134:
  %t508 = load ptr, ptr %l1, !tbaa !29
  store ptr %t508, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t509 = load ptr, ptr %l289, !tbaa !29
  %t510 = icmp ne ptr %t509, null
  br i1 %t510, label %bb135, label %bb136
bb135:
  %t512 = load ptr, ptr %l289, !tbaa !29
  %t513 = load i64, ptr %t512, !range !{i64 0, i64 18}
  %t515 = icmp eq i64 %t513, 5
  store i1 %t515, ptr %l290, !tbaa !21
  br label %bb136
bb136:
  %t516 = load i1, ptr %l290, !tbaa !21
  br i1 %t516, label %bb137, label %bb138
bb137:
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t519 = getelementptr { i64, [5 x i64] }, ptr %t517, i32 0, i32 1
  %t520 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t519, i32 0, i32 2
  %t521 = load ptr, ptr %t520
  store ptr %t521, ptr %l44, !tbaa !29
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load ptr, ptr %l44, !tbaa !29
  %t526 = getelementptr %"compiler/typed:Promote", ptr %t524, i32 0, i32 0
  %t527 = load ptr, ptr %t526, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t523, ptr %t527)
  br label %bb140
bb140:
  br label %bb213
bb141:
  %t531 = load ptr, ptr %l1, !tbaa !29
  store ptr %t531, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t532 = load ptr, ptr %l299, !tbaa !29
  %t533 = icmp ne ptr %t532, null
  br i1 %t533, label %bb142, label %bb143
bb142:
  %t535 = load ptr, ptr %l299, !tbaa !29
  %t536 = load i64, ptr %t535, !range !{i64 0, i64 18}
  %t538 = icmp eq i64 %t536, 10
  store i1 %t538, ptr %l300, !tbaa !21
  br label %bb143
bb143:
  %t539 = load i1, ptr %l300, !tbaa !21
  br i1 %t539, label %bb144, label %bb145
bb144:
  %t540 = load ptr, ptr %l1, !tbaa !29
  %t542 = getelementptr { i64, [5 x i64] }, ptr %t540, i32 0, i32 1
  %t543 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t542, i32 0, i32 2
  %t544 = load ptr, ptr %t543
  store ptr %t544, ptr %l45, !tbaa !29
  br label %bb146
bb145:
  br label %bb150
bb146:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load ptr, ptr %l45, !tbaa !29
  %t549 = getelementptr %"compiler/typed:Slice", ptr %t547, i32 0, i32 0
  %t550 = load ptr, ptr %t549, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %t546, ptr %t550)
  br label %bb147
bb147:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load ptr, ptr %l45, !tbaa !29
  %t556 = getelementptr %"compiler/typed:Slice", ptr %t554, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t553, ptr %t557)
  br label %bb148
bb148:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load ptr, ptr %l45, !tbaa !29
  %t564 = getelementptr %"compiler/typed:Slice", ptr %t562, i32 0, i32 2
  %t565 = load ptr, ptr %t564, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t561, ptr %t565)
  br label %bb149
bb149:
  br label %bb213
bb150:
  %t569 = load ptr, ptr %l1, !tbaa !29
  store ptr %t569, ptr %l316, !tbaa !29
  store i1 false, ptr %l317, !tbaa !21
  %t570 = load ptr, ptr %l316, !tbaa !29
  %t571 = icmp ne ptr %t570, null
  br i1 %t571, label %bb151, label %bb152
bb151:
  %t573 = load ptr, ptr %l316, !tbaa !29
  %t574 = load i64, ptr %t573, !range !{i64 0, i64 18}
  %t576 = icmp eq i64 %t574, 16
  store i1 %t576, ptr %l317, !tbaa !21
  br label %bb152
bb152:
  %t577 = load i1, ptr %l317, !tbaa !21
  br i1 %t577, label %bb153, label %bb154
bb153:
  %t578 = load ptr, ptr %l1, !tbaa !29
  %t580 = getelementptr { i64, [5 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t580, i32 0, i32 2
  %t582 = load ptr, ptr %t581
  store ptr %t582, ptr %l46, !tbaa !29
  br label %bb155
bb154:
  br label %bb168
bb155:
  %t584 = load ptr, ptr %l46, !tbaa !29
  %t586 = getelementptr %"compiler/typed:Text", ptr %t584, i32 0, i32 0
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  store { i64, ptr } %t587, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t589 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t591 = extractvalue { i64, ptr } %t589, 0
  store i64 %t591, ptr %l49, !tbaa !24
  br label %bb156
bb156:
  %t593 = load i64, ptr %l48, !tbaa !24
  %t594 = load i64, ptr %l49, !tbaa !24
  %t597 = icmp slt i64 %t593, %t594
  %t599 = xor i1 %t597, true
  br i1 %t599, label %bb157, label %bb158
bb157:
  br label %bb167
bb158:
  br label %bb159
bb159:
  %t601 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t601, ptr %l330, !tbaa !27
  %t602 = load i64, ptr %l48, !tbaa !24
  %t604 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !27
  %t606 = getelementptr ptr, ptr %t605, i64 %t602
  %t607 = load ptr, ptr %t606, !tbaa !39
  store ptr %t607, ptr %l50, !tbaa !29
  %t609 = load ptr, ptr %l50, !tbaa !29
  store ptr %t609, ptr %l333, !tbaa !29
  store i1 false, ptr %l334, !tbaa !21
  %t610 = load ptr, ptr %l333, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb160, label %bb161
bb160:
  %t613 = load ptr, ptr %l333, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 2}
  %t616 = icmp eq i64 %t614, 1
  store i1 %t616, ptr %l334, !tbaa !21
  br label %bb161
bb161:
  %t617 = load i1, ptr %l334, !tbaa !21
  br i1 %t617, label %bb162, label %bb163
bb162:
  %t618 = load ptr, ptr %l50, !tbaa !29
  %t620 = getelementptr { i64, [2 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { ptr }, ptr %t620, i32 0, i32 0
  %t622 = load ptr, ptr %t621
  %t624 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t624, ptr %t622)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  br label %bb166
bb166:
  %t629 = load i64, ptr %l48, !tbaa !24
  %t632 = add i64 %t629, 1
  store i64 %t632, ptr %l48, !tbaa !24
  br label %bb156
bb167:
  br label %bb213
bb168:
  %t634 = load ptr, ptr %l1, !tbaa !29
  store ptr %t634, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t635 = load ptr, ptr %l345, !tbaa !29
  %t636 = icmp ne ptr %t635, null
  br i1 %t636, label %bb169, label %bb170
bb169:
  %t638 = load ptr, ptr %l345, !tbaa !29
  %t639 = load i64, ptr %t638, !range !{i64 0, i64 18}
  %t641 = icmp eq i64 %t639, 2
  store i1 %t641, ptr %l346, !tbaa !21
  br label %bb170
bb170:
  %t642 = load i1, ptr %l346, !tbaa !21
  br i1 %t642, label %bb171, label %bb172
bb171:
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [5 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t645, i32 0, i32 2
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l52, !tbaa !29
  br label %bb181
bb172:
  %t649 = load ptr, ptr %l1, !tbaa !29
  store ptr %t649, ptr %l351, !tbaa !29
  store i1 false, ptr %l352, !tbaa !21
  %t650 = load ptr, ptr %l351, !tbaa !29
  %t651 = icmp ne ptr %t650, null
  br i1 %t651, label %bb173, label %bb174
bb173:
  %t653 = load ptr, ptr %l351, !tbaa !29
  %t654 = load i64, ptr %t653, !range !{i64 0, i64 18}
  %t656 = icmp eq i64 %t654, 3
  store i1 %t656, ptr %l352, !tbaa !21
  br label %bb174
bb174:
  %t657 = load i1, ptr %l352, !tbaa !21
  br i1 %t657, label %bb175, label %bb176
bb175:
  %t658 = load ptr, ptr %l1, !tbaa !29
  %t660 = getelementptr { i64, [5 x i64] }, ptr %t658, i32 0, i32 1
  %t661 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t660, i32 0, i32 2
  %t662 = load ptr, ptr %t661
  store ptr %t662, ptr %l52, !tbaa !29
  br label %bb181
bb176:
  %t664 = load ptr, ptr %l1, !tbaa !29
  store ptr %t664, ptr %l357, !tbaa !29
  store i1 false, ptr %l358, !tbaa !21
  %t665 = load ptr, ptr %l357, !tbaa !29
  %t666 = icmp ne ptr %t665, null
  br i1 %t666, label %bb177, label %bb178
bb177:
  %t668 = load ptr, ptr %l357, !tbaa !29
  %t669 = load i64, ptr %t668, !range !{i64 0, i64 18}
  %t671 = icmp eq i64 %t669, 4
  store i1 %t671, ptr %l358, !tbaa !21
  br label %bb178
bb178:
  %t672 = load i1, ptr %l358, !tbaa !21
  br i1 %t672, label %bb179, label %bb180
bb179:
  %t673 = load ptr, ptr %l1, !tbaa !29
  %t675 = getelementptr { i64, [5 x i64] }, ptr %t673, i32 0, i32 1
  %t676 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t675, i32 0, i32 2
  %t677 = load ptr, ptr %t676
  store ptr %t677, ptr %l52, !tbaa !29
  br label %bb181
bb180:
  br label %bb183
bb181:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %t679, ptr %t680)
  br label %bb182
bb182:
  br label %bb213
bb183:
  %t683 = load ptr, ptr %l1, !tbaa !29
  store ptr %t683, ptr %l365, !tbaa !29
  store i1 false, ptr %l366, !tbaa !21
  %t684 = load ptr, ptr %l365, !tbaa !29
  %t685 = icmp ne ptr %t684, null
  br i1 %t685, label %bb184, label %bb185
bb184:
  %t687 = load ptr, ptr %l365, !tbaa !29
  %t688 = load i64, ptr %t687, !range !{i64 0, i64 18}
  %t690 = icmp eq i64 %t688, 15
  store i1 %t690, ptr %l366, !tbaa !21
  br label %bb185
bb185:
  %t691 = load i1, ptr %l366, !tbaa !21
  br i1 %t691, label %bb186, label %bb187
bb186:
  %t692 = load ptr, ptr %l1, !tbaa !29
  %t694 = getelementptr { i64, [5 x i64] }, ptr %t692, i32 0, i32 1
  %t695 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t694, i32 0, i32 2
  %t696 = load ptr, ptr %t695
  store ptr %t696, ptr %l371, !tbaa !29
  store i1 false, ptr %l372, !tbaa !21
  %t697 = load ptr, ptr %l371, !tbaa !29
  %t698 = icmp ne ptr %t697, null
  br i1 %t698, label %bb188, label %bb189
bb187:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb190
bb188:
  %t700 = load ptr, ptr %l371, !tbaa !29
  %t701 = load i64, ptr %t700, !range !{i64 0, i64 3}
  %t703 = icmp eq i64 %t701, 1
  store i1 %t703, ptr %l372, !tbaa !21
  br label %bb189
bb189:
  %t704 = load i1, ptr %l372, !tbaa !21
  store i1 %t704, ptr %l369, !tbaa !21
  br label %bb190
bb190:
  %t705 = load i1, ptr %l369, !tbaa !21
  br i1 %t705, label %bb191, label %bb192
bb191:
  %t706 = load ptr, ptr %l1, !tbaa !29
  %t708 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 1
  %t709 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t708, i32 0, i32 2
  %t710 = load ptr, ptr %t709
  %t712 = getelementptr { i64, [4 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t712, i32 0, i32 1
  %t714 = load { i64, ptr }, ptr %t713
  store { i64, ptr } %t714, ptr %l53, !tbaa !27
  br label %bb193
bb192:
  br label %bb201
bb193:
  %t716 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t716, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t718 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t718, 0
  store i64 %t720, ptr %l56, !tbaa !24
  br label %bb194
bb194:
  %t722 = load i64, ptr %l55, !tbaa !24
  %t723 = load i64, ptr %l56, !tbaa !24
  %t726 = icmp slt i64 %t722, %t723
  %t728 = xor i1 %t726, true
  br i1 %t728, label %bb195, label %bb196
bb195:
  br label %bb200
bb196:
  br label %bb197
bb197:
  %t730 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t730, ptr %l385, !tbaa !27
  %t731 = load i64, ptr %l55, !tbaa !24
  %t733 = getelementptr { i64, ptr }, ptr %l385, i32 0, i32 1
  %t734 = load ptr, ptr %t733, !tbaa !27
  %t735 = getelementptr ptr, ptr %t734, i64 %t731
  %t736 = load ptr, ptr %t735, !tbaa !39
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t741 = getelementptr %"compiler/typed:Capture", ptr %t736, i32 0, i32 1
  %t742 = load ptr, ptr %t741, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t738, ptr %t742)
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t746 = load i64, ptr %l55, !tbaa !24
  %t749 = add i64 %t746, 1
  store i64 %t749, ptr %l55, !tbaa !24
  br label %bb194
bb200:
  br label %bb213
bb201:
  %t751 = load ptr, ptr %l1, !tbaa !29
  store ptr %t751, ptr %l395, !tbaa !29
  store i1 false, ptr %l396, !tbaa !21
  %t752 = load ptr, ptr %l395, !tbaa !29
  %t753 = icmp ne ptr %t752, null
  br i1 %t753, label %bb202, label %bb203
bb202:
  %t755 = load ptr, ptr %l395, !tbaa !29
  %t756 = load i64, ptr %t755, !range !{i64 0, i64 18}
  %t758 = icmp eq i64 %t756, 17
  store i1 %t758, ptr %l396, !tbaa !21
  br label %bb203
bb203:
  %t759 = load i1, ptr %l396, !tbaa !21
  br i1 %t759, label %bb204, label %bb205
bb204:
  %t760 = load ptr, ptr %l1, !tbaa !29
  %t762 = getelementptr { i64, [5 x i64] }, ptr %t760, i32 0, i32 1
  %t763 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t762, i32 0, i32 2
  %t764 = load ptr, ptr %t763
  store ptr %t764, ptr %l58, !tbaa !29
  br label %bb206
bb205:
  br label %bb208
bb206:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t766, ptr %t767)
  br label %bb207
bb207:
  br label %bb213
bb208:
  br i1 true, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_edb5a1ac978d0996_7c7124734c9b85fa)
  unreachable
bb213:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb41
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb13
bb13:
  br label %bb41
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t41 = load ptr, ptr %l24, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 4
  store i1 %t47, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Elem", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %t55, ptr %t59)
  br label %bb20
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t62, ptr %t66)
  br label %bb21
bb21:
  br label %bb41
bb22:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 5
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Payload", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanPlace(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  br label %bb28
bb28:
  br label %bb41
bb29:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb30, label %bb31
bb30:
  %t96 = load ptr, ptr %l46, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t100 = load i1, ptr %l47, !tbaa !21
  br i1 %t100, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_83ffd618ff536982_5c02ec347c68c506)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2espawnedInto(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 40
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4, i1 true)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 67
  %t10 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t9, i64 %t10, i1 true)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 2
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Effects", ptr %t18, i32 0, i32 41
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = mul i64 2, %t21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t20, i64 %t23)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l73 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i1
  %l83 = alloca i1
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l92 = alloca ptr
  %l97 = alloca %"compiler/typed:Local"
  %l99 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l141 = alloca i1
  %l157 = alloca i1
  %l178 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca i32
  %l183 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l189 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l205 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l246 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l265 = alloca i1
  %l268 = alloca i1
  %l272 = alloca i1
  %l275 = alloca i1
  %l282 = alloca ptr
  %l283 = alloca i1
  %l290 = alloca ptr
  %l291 = alloca i1
  %l299 = alloca ptr
  %l300 = alloca i1
  %l303 = alloca ptr
  %l304 = alloca i1
  %l307 = alloca ptr
  %l308 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i1
  %l326 = alloca ptr
  %l328 = alloca i64
  %l331 = alloca i1
  %l335 = alloca i1
  %l339 = alloca ptr
  %l340 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca i1
  %l357 = alloca i1
  %l365 = alloca ptr
  %l366 = alloca i1
  %l384 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l393 = alloca i1
  %l409 = alloca { i64, ptr }
  %l416 = alloca ptr
  %l417 = alloca i1
  %l446 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t2 = load ptr, ptr %l57, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l57, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l58, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l58, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %t27, i64 %t30, ptr %t31)
  br label %bb7
bb7:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l73, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/effects:Effects", ptr %t38, i32 0, i32 73
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l76
  br label %bb8
bb8:
  %t43 = load i64, ptr %l73, !tbaa !24
  %t44 = load i64, ptr %l76, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 73
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t55 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t49, i64 %t52)
  store i1 %t55, ptr %l83
  br label %bb11
bb10:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb12
bb11:
  %t56 = load i1, ptr %l83, !tbaa !21
  store i1 %t56, ptr %l78, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l78, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 25
  %t61 = getelementptr %"compiler/effects:Facts", ptr %t60, i32 0, i32 0
  store i1 true, ptr %t61, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l85, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  store ptr %t63, ptr %l87, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/effects:Effects", ptr %t68, i32 0, i32 35
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l92
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l92, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t75, i32 0, i32 7
  %t78 = load i32, ptr %l2, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t83 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t77, i64 %t80)
  store %"compiler/typed:Local" %t83, ptr %l97
  br label %bb17
bb17:
  %t84 = getelementptr %"compiler/typed:Local", ptr %l97, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l85, !tbaa !29
  %t87 = load ptr, ptr %l87, !tbaa !29
  %t89 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecopyBuilds(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i32 %t85)
  store i1 %t89, ptr %l99
  br label %bb18
bb18:
  %t90 = load i1, ptr %l99, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 25
  %t94 = getelementptr %"compiler/effects:Facts", ptr %t93, i32 0, i32 0
  store i1 true, ptr %t94, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb235
bb22:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t96 = load ptr, ptr %l101, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb23, label %bb24
bb23:
  %t99 = load ptr, ptr %l101, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l102, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l102, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb31
bb26:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t111 = load ptr, ptr %l107, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t114 = load ptr, ptr %l107, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 17}
  %t117 = icmp eq i64 %t115, 15
  store i1 %t117, ptr %l108, !tbaa !21
  br label %bb28
bb28:
  %t118 = load i1, ptr %l108, !tbaa !21
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  br label %bb32
bb32:
  br label %bb235
bb33:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t131 = load ptr, ptr %l116, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l116, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 17}
  %t137 = icmp eq i64 %t135, 1
  store i1 %t137, ptr %l117, !tbaa !21
  br label %bb35
bb35:
  %t138 = load i1, ptr %l117, !tbaa !21
  br i1 %t138, label %bb36, label %bb37
bb36:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l5, !tbaa !29
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t147, i32 0, i32 2
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb78
bb38:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i1 true)
  br label %bb39
bb39:
  %t155 = load ptr, ptr %l5, !tbaa !29
  store ptr %t155, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t156 = load ptr, ptr %l126, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l126, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 8}
  %t162 = icmp eq i64 %t160, 0
  store i1 %t162, ptr %l127, !tbaa !21
  br label %bb41
bb41:
  %t163 = load i1, ptr %l127, !tbaa !21
  br i1 %t163, label %bb42, label %bb43
bb42:
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l7
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t172, i32 0, i32 1
  %t174 = load i32, ptr %t173
  store i32 %t174, ptr %l8, !tbaa !23
  %t176 = load ptr, ptr %l5, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t178, i32 0, i32 2
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l9, !tbaa !23
  %t182 = load ptr, ptr %l6, !tbaa !29
  store ptr %t182, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t183 = load ptr, ptr %l137, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb46
bb44:
  %t186 = load ptr, ptr %l137, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 18}
  %t189 = icmp eq i64 %t187, 5
  store i1 %t189, ptr %l138, !tbaa !21
  br label %bb45
bb45:
  %t190 = load i1, ptr %l138, !tbaa !21
  store i1 %t190, ptr %l130, !tbaa !21
  br label %bb46
bb46:
  %t191 = load i1, ptr %l130, !tbaa !21
  br i1 %t191, label %bb47, label %bb48
bb47:
  %t192 = load ptr, ptr %l5, !tbaa !29
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t194, i32 0, i32 0
  %t196 = load %"compiler/source:Span", ptr %t195
  store %"compiler/source:Span" %t196, ptr %l10
  %t198 = load ptr, ptr %l5, !tbaa !29
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t200, i32 0, i32 1
  %t202 = load i32, ptr %t201
  store i32 %t202, ptr %l11, !tbaa !23
  %t204 = load ptr, ptr %l5, !tbaa !29
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t206, i32 0, i32 2
  %t208 = load i32, ptr %t207
  %t210 = load ptr, ptr %l6, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t212, i32 0, i32 0
  %t214 = load %"compiler/source:Span", ptr %t213
  store %"compiler/source:Span" %t214, ptr %l13
  %t216 = load ptr, ptr %l6, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t218, i32 0, i32 1
  %t220 = load i32, ptr %t219
  store i32 %t220, ptr %l14, !tbaa !23
  %t222 = load ptr, ptr %l6, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l15, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t231 = sext i32 %t208 to i64
  %t234 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eownSlot(ptr %v0, ptr %t228, i64 %t231)
  store i1 %t234, ptr %l157
  br label %bb49
bb48:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb50
bb49:
  %t235 = load i1, ptr %l157, !tbaa !21
  store i1 %t235, ptr %l141, !tbaa !21
  br label %bb50
bb50:
  %t236 = load i1, ptr %l141, !tbaa !21
  br i1 %t236, label %bb51, label %bb52
bb51:
  %t237 = load ptr, ptr %l5, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t239, i32 0, i32 0
  %t241 = load %"compiler/source:Span", ptr %t240
  store %"compiler/source:Span" %t241, ptr %l16
  %t243 = load ptr, ptr %l5, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t245, i32 0, i32 1
  %t247 = load i32, ptr %t246
  store i32 %t247, ptr %l17, !tbaa !23
  %t249 = load ptr, ptr %l5, !tbaa !29
  %t251 = getelementptr { i64, [4 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t251, i32 0, i32 2
  %t253 = load i32, ptr %t252
  store i32 %t253, ptr %l18, !tbaa !23
  %t255 = load ptr, ptr %l6, !tbaa !29
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t257, i32 0, i32 0
  %t259 = load %"compiler/source:Span", ptr %t258
  store %"compiler/source:Span" %t259, ptr %l19
  %t261 = load ptr, ptr %l6, !tbaa !29
  %t263 = getelementptr { i64, [5 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t263, i32 0, i32 1
  %t265 = load i32, ptr %t264
  store i32 %t265, ptr %l20, !tbaa !23
  %t267 = load ptr, ptr %l6, !tbaa !29
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load ptr, ptr %t270
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Promote", ptr %t271, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t278)
  br label %bb53
bb52:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t282, ptr %t283)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l178, !tbaa !29
  %t288 = load ptr, ptr %l6, !tbaa !29
  store ptr %t288, ptr %l180, !tbaa !29
  %t290 = load ptr, ptr %l5, !tbaa !29
  %t292 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t290)
  store i32 %t292, ptr %l182
  br label %bb56
bb56:
  %t293 = load ptr, ptr %l178, !tbaa !29
  %t294 = load ptr, ptr %l180, !tbaa !29
  %t295 = load i32, ptr %l182, !tbaa !23
  %t296 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecopyBuilds(ptr %v0, ptr %v1, ptr %t293, ptr %t294, i32 %t295)
  store i1 %t296, ptr %l183
  br label %bb57
bb57:
  %t297 = load i1, ptr %l183, !tbaa !21
  br i1 %t297, label %bb58, label %bb59
bb58:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/effects:Effects", ptr %t298, i32 0, i32 25
  %t301 = getelementptr %"compiler/effects:Facts", ptr %t300, i32 0, i32 0
  store i1 true, ptr %t301, !tbaa !21
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t302 = load ptr, ptr %l5, !tbaa !29
  store ptr %t302, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t303 = load ptr, ptr %l185, !tbaa !29
  %t304 = icmp ne ptr %t303, null
  br i1 %t304, label %bb61, label %bb62
bb61:
  %t306 = load ptr, ptr %l185, !tbaa !29
  %t307 = load i64, ptr %t306, !range !{i64 0, i64 8}
  %t309 = icmp eq i64 %t307, 0
  store i1 %t309, ptr %l186, !tbaa !21
  br label %bb62
bb62:
  %t310 = load i1, ptr %l186, !tbaa !21
  br i1 %t310, label %bb63, label %bb64
bb63:
  %t311 = load ptr, ptr %l5, !tbaa !29
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t313, i32 0, i32 0
  %t315 = load %"compiler/source:Span", ptr %t314
  store %"compiler/source:Span" %t315, ptr %l22
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t319, i32 0, i32 1
  %t321 = load i32, ptr %t320
  store i32 %t321, ptr %l23, !tbaa !23
  %t323 = load ptr, ptr %l5, !tbaa !29
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t325, i32 0, i32 2
  %t327 = load i32, ptr %t326
  store i32 %t327, ptr %l24, !tbaa !23
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/effects:Effects", ptr %t329, i32 0, i32 2
  %t332 = load i1, ptr %t331, !tbaa !21
  br i1 %t332, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb73
bb65:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb68
bb66:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l23, !tbaa !23
  %t338 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t334, i32 %t335)
  store i1 %t338, ptr %l201
  br label %bb67
bb67:
  %t339 = load i1, ptr %l201, !tbaa !21
  store i1 %t339, ptr %l198, !tbaa !21
  br label %bb68
bb68:
  %t340 = load i1, ptr %l198, !tbaa !21
  br i1 %t340, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb72
bb70:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i32, ptr %l23, !tbaa !23
  %t345 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %t341, i32 %t342)
  store i1 %t345, ptr %l205
  br label %bb71
bb71:
  %t346 = load i1, ptr %l205, !tbaa !21
  store i1 %t346, ptr %l202, !tbaa !21
  br label %bb72
bb72:
  %t347 = load i1, ptr %l202, !tbaa !21
  store i1 %t347, ptr %l189, !tbaa !21
  br label %bb73
bb73:
  %t348 = load i1, ptr %l189, !tbaa !21
  br i1 %t348, label %bb74, label %bb75
bb74:
  %t349 = load ptr, ptr %l5, !tbaa !29
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t351, i32 0, i32 0
  %t353 = load %"compiler/source:Span", ptr %t352
  store %"compiler/source:Span" %t353, ptr %l25
  %t355 = load ptr, ptr %l5, !tbaa !29
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t357, i32 0, i32 1
  %t359 = load i32, ptr %t358
  store i32 %t359, ptr %l26, !tbaa !23
  %t361 = load ptr, ptr %l5, !tbaa !29
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t363, i32 0, i32 2
  %t365 = load i32, ptr %t364
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t370 = sext i32 %t365 to i64
  %t371 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %t367, i64 %t370, ptr %t371)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb235
bb78:
  %t375 = load ptr, ptr %l1, !tbaa !29
  store ptr %t375, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t376 = load ptr, ptr %l216, !tbaa !29
  %t377 = icmp ne ptr %t376, null
  br i1 %t377, label %bb79, label %bb80
bb79:
  %t379 = load ptr, ptr %l216, !tbaa !29
  %t380 = load i64, ptr %t379, !range !{i64 0, i64 17}
  %t382 = icmp eq i64 %t380, 3
  store i1 %t382, ptr %l217, !tbaa !21
  br label %bb80
bb80:
  %t383 = load i1, ptr %l217, !tbaa !21
  br i1 %t383, label %bb81, label %bb82
bb81:
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", ptr }, ptr %t386, i32 0, i32 1
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l28, !tbaa !29
  br label %bb83
bb82:
  br label %bb87
bb83:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l28, !tbaa !29
  %t393 = getelementptr %"compiler/typed:If", ptr %t391, i32 0, i32 0
  %t394 = load ptr, ptr %t393, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t390, ptr %t394)
  br label %bb84
bb84:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l28, !tbaa !29
  %t401 = getelementptr %"compiler/typed:If", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t398, ptr %t402)
  br label %bb85
bb85:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l28, !tbaa !29
  %t409 = getelementptr %"compiler/typed:If", ptr %t407, i32 0, i32 2
  %t410 = load ptr, ptr %t409, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t406, ptr %t410)
  br label %bb86
bb86:
  br label %bb235
bb87:
  %t413 = load ptr, ptr %l1, !tbaa !29
  store ptr %t413, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t414 = load ptr, ptr %l233, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb88, label %bb89
bb88:
  %t417 = load ptr, ptr %l233, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 17}
  %t420 = icmp eq i64 %t418, 4
  store i1 %t420, ptr %l234, !tbaa !21
  br label %bb89
bb89:
  %t421 = load i1, ptr %l234, !tbaa !21
  br i1 %t421, label %bb90, label %bb91
bb90:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t424, i32 0, i32 1
  %t426 = load ptr, ptr %t425
  store ptr %t426, ptr %l29, !tbaa !29
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t430 = getelementptr { i64, [3 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t430, i32 0, i32 2
  %t432 = load ptr, ptr %t431
  store ptr %t432, ptr %l30, !tbaa !29
  br label %bb92
bb91:
  br label %bb99
bb92:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/effects:Effects", ptr %t434, i32 0, i32 33
  %t437 = load ptr, ptr %l29, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Block", ptr %t437, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t442 = sext i32 %t440 to i64
  %t445 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t436, i64 %t442)
  store i1 %t445, ptr %l246
  br label %bb93
bb93:
  %t446 = load i1, ptr %l246, !tbaa !21
  %t447 = xor i1 %t446, true
  br i1 %t447, label %bb94, label %bb95
bb94:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/effects:Effects", ptr %t449, i32 0, i32 25
  %t452 = getelementptr %"compiler/effects:Facts", ptr %t451, i32 0, i32 11
  store i1 true, ptr %t452, !tbaa !21
  br label %bb96
bb95:
  br label %bb96
bb96:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t453, ptr %t454)
  br label %bb97
bb97:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t458, ptr %t459)
  br label %bb98
bb98:
  br label %bb235
bb99:
  %t462 = load ptr, ptr %l1, !tbaa !29
  store ptr %t462, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t463 = load ptr, ptr %l254, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb100, label %bb101
bb100:
  %t466 = load ptr, ptr %l254, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 17}
  %t469 = icmp eq i64 %t467, 6
  store i1 %t469, ptr %l255, !tbaa !21
  br label %bb101
bb101:
  %t470 = load i1, ptr %l255, !tbaa !21
  br i1 %t470, label %bb102, label %bb103
bb102:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = getelementptr { i64, [3 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", ptr }, ptr %t473, i32 0, i32 1
  %t475 = load ptr, ptr %t474
  store ptr %t475, ptr %l31, !tbaa !29
  br label %bb104
bb103:
  br label %bb123
bb104:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t477, ptr %t478)
  br label %bb105
bb105:
  %t481 = load ptr, ptr %l31, !tbaa !29
  %t483 = icmp eq ptr %t481, null
  %t485 = xor i1 %t483, true
  br i1 %t485, label %bb106, label %bb107
bb106:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l31, !tbaa !29
  %t491 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretBuilds(ptr %v0, ptr %v1, ptr %t487, ptr %t488)
  store i1 %t491, ptr %l268
  br label %bb108
bb107:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb109
bb108:
  %t492 = load i1, ptr %l268, !tbaa !21
  store i1 %t492, ptr %l265, !tbaa !21
  br label %bb109
bb109:
  %t493 = load i1, ptr %l265, !tbaa !21
  br i1 %t493, label %bb110, label %bb111
bb110:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/effects:Effects", ptr %t494, i32 0, i32 25
  %t497 = getelementptr %"compiler/effects:Facts", ptr %t496, i32 0, i32 0
  store i1 true, ptr %t497, !tbaa !21
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/effects:Effects", ptr %t498, i32 0, i32 45
  %t501 = load i1, ptr %t500, !tbaa !21
  br i1 %t501, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l272, !tbaa !21
  br label %bb115
bb114:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/effects:Effects", ptr %t503, i32 0, i32 69
  %t506 = load i1, ptr %t505, !tbaa !21
  store i1 %t506, ptr %l272, !tbaa !21
  br label %bb115
bb115:
  %t508 = load i1, ptr %l272, !tbaa !21
  br i1 %t508, label %bb116, label %bb117
bb116:
  %t509 = load ptr, ptr %l31, !tbaa !29
  %t511 = icmp eq ptr %t509, null
  %t513 = xor i1 %t511, true
  store i1 %t513, ptr %l275, !tbaa !21
  br label %bb118
bb117:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb118
bb118:
  %t515 = load i1, ptr %l275, !tbaa !21
  br i1 %t515, label %bb119, label %bb120
bb119:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/effects:Effects", ptr %t516, i32 0, i32 46
  %t519 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t518, ptr %t519)
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb122
bb122:
  br label %bb235
bb123:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l282, !tbaa !29
  store i1 false, ptr %l283, !tbaa !21
  %t523 = load ptr, ptr %l282, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb124, label %bb125
bb124:
  %t526 = load ptr, ptr %l282, !tbaa !29
  %t527 = load i64, ptr %t526, !range !{i64 0, i64 17}
  %t529 = icmp eq i64 %t527, 16
  store i1 %t529, ptr %l283, !tbaa !21
  br label %bb125
bb125:
  %t530 = load i1, ptr %l283, !tbaa !21
  br i1 %t530, label %bb126, label %bb127
bb126:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [3 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", ptr }, ptr %t533, i32 0, i32 1
  %t535 = load ptr, ptr %t534
  store ptr %t535, ptr %l32, !tbaa !29
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t537, ptr %t538)
  br label %bb129
bb129:
  br label %bb235
bb130:
  %t541 = load ptr, ptr %l1, !tbaa !29
  store ptr %t541, ptr %l290, !tbaa !29
  store i1 false, ptr %l291, !tbaa !21
  %t542 = load ptr, ptr %l290, !tbaa !29
  %t543 = icmp ne ptr %t542, null
  br i1 %t543, label %bb131, label %bb132
bb131:
  %t545 = load ptr, ptr %l290, !tbaa !29
  %t546 = load i64, ptr %t545, !range !{i64 0, i64 17}
  %t548 = icmp eq i64 %t546, 8
  store i1 %t548, ptr %l291, !tbaa !21
  br label %bb132
bb132:
  %t549 = load i1, ptr %l291, !tbaa !21
  br i1 %t549, label %bb133, label %bb134
bb133:
  %t550 = load ptr, ptr %l1, !tbaa !29
  %t552 = getelementptr { i64, [3 x i64] }, ptr %t550, i32 0, i32 1
  %t553 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t552, i32 0, i32 1
  %t554 = load ptr, ptr %t553
  store ptr %t554, ptr %l33, !tbaa !29
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t556, ptr %t557)
  br label %bb136
bb136:
  br label %bb235
bb137:
  %t561 = load ptr, ptr %l1, !tbaa !29
  store ptr %t561, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t562 = load ptr, ptr %l299, !tbaa !29
  %t563 = icmp ne ptr %t562, null
  br i1 %t563, label %bb138, label %bb139
bb138:
  %t565 = load ptr, ptr %l299, !tbaa !29
  %t566 = load i64, ptr %t565, !range !{i64 0, i64 17}
  %t568 = icmp eq i64 %t566, 5
  store i1 %t568, ptr %l300, !tbaa !21
  br label %bb139
bb139:
  %t569 = load i1, ptr %l300, !tbaa !21
  br i1 %t569, label %bb140, label %bb141
bb140:
  br label %bb146
bb141:
  %t570 = load ptr, ptr %l1, !tbaa !29
  store ptr %t570, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t571 = load ptr, ptr %l303, !tbaa !29
  %t572 = icmp ne ptr %t571, null
  br i1 %t572, label %bb142, label %bb143
bb142:
  %t574 = load ptr, ptr %l303, !tbaa !29
  %t575 = load i64, ptr %t574, !range !{i64 0, i64 17}
  %t577 = icmp eq i64 %t575, 7
  store i1 %t577, ptr %l304, !tbaa !21
  br label %bb143
bb143:
  %t578 = load i1, ptr %l304, !tbaa !21
  br i1 %t578, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb235
bb147:
  %t579 = load ptr, ptr %l1, !tbaa !29
  store ptr %t579, ptr %l307, !tbaa !29
  store i1 false, ptr %l308, !tbaa !21
  %t580 = load ptr, ptr %l307, !tbaa !29
  %t581 = icmp ne ptr %t580, null
  br i1 %t581, label %bb148, label %bb149
bb148:
  %t583 = load ptr, ptr %l307, !tbaa !29
  %t584 = load i64, ptr %t583, !range !{i64 0, i64 17}
  %t586 = icmp eq i64 %t584, 11
  store i1 %t586, ptr %l308, !tbaa !21
  br label %bb149
bb149:
  %t587 = load i1, ptr %l308, !tbaa !21
  br i1 %t587, label %bb150, label %bb151
bb150:
  %t588 = load ptr, ptr %l1, !tbaa !29
  %t590 = getelementptr { i64, [3 x i64] }, ptr %t588, i32 0, i32 1
  %t591 = getelementptr { %"compiler/source:Span", ptr }, ptr %t590, i32 0, i32 1
  %t592 = load ptr, ptr %t591
  store ptr %t592, ptr %l34, !tbaa !29
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t594, ptr %t595)
  br label %bb153
bb153:
  br label %bb235
bb154:
  %t599 = load ptr, ptr %l1, !tbaa !29
  store ptr %t599, ptr %l316, !tbaa !29
  store i1 false, ptr %l317, !tbaa !21
  %t600 = load ptr, ptr %l316, !tbaa !29
  %t601 = icmp ne ptr %t600, null
  br i1 %t601, label %bb155, label %bb156
bb155:
  %t603 = load ptr, ptr %l316, !tbaa !29
  %t604 = load i64, ptr %t603, !range !{i64 0, i64 17}
  %t606 = icmp eq i64 %t604, 12
  store i1 %t606, ptr %l317, !tbaa !21
  br label %bb156
bb156:
  %t607 = load i1, ptr %l317, !tbaa !21
  br i1 %t607, label %bb157, label %bb158
bb157:
  %t608 = load ptr, ptr %l1, !tbaa !29
  %t610 = getelementptr { i64, [3 x i64] }, ptr %t608, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", ptr }, ptr %t610, i32 0, i32 1
  %t612 = load ptr, ptr %t611
  store ptr %t612, ptr %l35, !tbaa !29
  br label %bb159
bb158:
  br label %bb170
bb159:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/effects:Effects", ptr %t614, i32 0, i32 1
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t619 = getelementptr %"compiler/effects:Effects", ptr %t617, i32 0, i32 35
  %t620 = load i64, ptr %t619, !tbaa !24
  %t623 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t616, i64 %t620)
  store ptr %t623, ptr %l326
  br label %bb160
bb160:
  %t624 = load ptr, ptr %l35, !tbaa !29
  %t625 = load ptr, ptr %l326, !tbaa !29
  %t627 = call i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %t625, ptr %t624)
  store i64 %t627, ptr %l328
  br label %bb161
bb161:
  %t628 = load i64, ptr %l328, !tbaa !24
  store i64 %t628, ptr %l36, !tbaa !24
  %t629 = load i64, ptr %l36, !tbaa !24
  %t631 = icmp slt i64 %t629, 0
  br i1 %t631, label %bb162, label %bb163
bb162:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb165
bb163:
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = getelementptr %"compiler/effects:Effects", ptr %t633, i32 0, i32 34
  %t636 = load i64, ptr %l36, !tbaa !24
  %t639 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t635, i64 %t636)
  store i1 %t639, ptr %l335
  br label %bb164
bb164:
  %t640 = load i1, ptr %l335, !tbaa !21
  store i1 %t640, ptr %l331, !tbaa !21
  br label %bb165
bb165:
  %t641 = load i1, ptr %l331, !tbaa !21
  br i1 %t641, label %bb166, label %bb167
bb166:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t642, ptr %t643)
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb169
bb169:
  br label %bb235
bb170:
  %t647 = load ptr, ptr %l1, !tbaa !29
  store ptr %t647, ptr %l339, !tbaa !29
  store i1 false, ptr %l340, !tbaa !21
  %t648 = load ptr, ptr %l339, !tbaa !29
  %t649 = icmp ne ptr %t648, null
  br i1 %t649, label %bb171, label %bb172
bb171:
  %t651 = load ptr, ptr %l339, !tbaa !29
  %t652 = load i64, ptr %t651, !range !{i64 0, i64 17}
  %t654 = icmp eq i64 %t652, 9
  store i1 %t654, ptr %l340, !tbaa !21
  br label %bb172
bb172:
  %t655 = load i1, ptr %l340, !tbaa !21
  br i1 %t655, label %bb173, label %bb174
bb173:
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = getelementptr { i64, [3 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t658, i32 0, i32 2
  %t660 = load ptr, ptr %t659
  store ptr %t660, ptr %l37, !tbaa !29
  br label %bb175
bb174:
  br label %bb177
bb175:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/effects:Effects", ptr %t662, i32 0, i32 25
  %t665 = getelementptr %"compiler/effects:Facts", ptr %t664, i32 0, i32 18
  store i1 true, ptr %t665, !tbaa !21
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldExpr(ptr %v0, ptr %v1, ptr %t666, ptr %t667)
  br label %bb176
bb176:
  br label %bb235
bb177:
  %t670 = load ptr, ptr %l1, !tbaa !29
  store ptr %t670, ptr %l348, !tbaa !29
  store i1 false, ptr %l349, !tbaa !21
  %t671 = load ptr, ptr %l348, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb178, label %bb179
bb178:
  %t674 = load ptr, ptr %l348, !tbaa !29
  %t675 = load i64, ptr %t674, !range !{i64 0, i64 17}
  %t677 = icmp eq i64 %t675, 10
  store i1 %t677, ptr %l349, !tbaa !21
  br label %bb179
bb179:
  %t678 = load i1, ptr %l349, !tbaa !21
  br i1 %t678, label %bb180, label %bb181
bb180:
  %t679 = load ptr, ptr %l1, !tbaa !29
  %t681 = getelementptr { i64, [3 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t681, i32 0, i32 1
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l38, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  %t687 = getelementptr { i64, [3 x i64] }, ptr %t685, i32 0, i32 1
  %t688 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t687, i32 0, i32 2
  %t689 = load ptr, ptr %t688
  store ptr %t689, ptr %l39, !tbaa !29
  br label %bb182
bb181:
  br label %bb189
bb182:
  %t691 = load ptr, ptr %l38, !tbaa !29
  %t693 = call i1 @compiler_2feffects_2elitTrue(ptr %v1, ptr %t691)
  store i1 %t693, ptr %l357
  br label %bb183
bb183:
  %t694 = load i1, ptr %l357, !tbaa !21
  %t695 = xor i1 %t694, true
  br i1 %t695, label %bb184, label %bb185
bb184:
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = getelementptr %"compiler/effects:Effects", ptr %t697, i32 0, i32 25
  %t700 = getelementptr %"compiler/effects:Facts", ptr %t699, i32 0, i32 18
  store i1 true, ptr %t700, !tbaa !21
  br label %bb186
bb185:
  br label %bb186
bb186:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t701, ptr %t702)
  br label %bb187
bb187:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t707 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldExpr(ptr %v0, ptr %v1, ptr %t706, ptr %t707)
  br label %bb188
bb188:
  br label %bb235
bb189:
  %t710 = load ptr, ptr %l1, !tbaa !29
  store ptr %t710, ptr %l365, !tbaa !29
  store i1 false, ptr %l366, !tbaa !21
  %t711 = load ptr, ptr %l365, !tbaa !29
  %t712 = icmp ne ptr %t711, null
  br i1 %t712, label %bb190, label %bb191
bb190:
  %t714 = load ptr, ptr %l365, !tbaa !29
  %t715 = load i64, ptr %t714, !range !{i64 0, i64 17}
  %t717 = icmp eq i64 %t715, 13
  store i1 %t717, ptr %l366, !tbaa !21
  br label %bb191
bb191:
  %t718 = load i1, ptr %l366, !tbaa !21
  br i1 %t718, label %bb192, label %bb193
bb192:
  %t719 = load ptr, ptr %l1, !tbaa !29
  %t721 = getelementptr { i64, [3 x i64] }, ptr %t719, i32 0, i32 1
  %t722 = getelementptr { %"compiler/source:Span", ptr }, ptr %t721, i32 0, i32 1
  %t723 = load ptr, ptr %t722
  store ptr %t723, ptr %l40, !tbaa !29
  br label %bb194
bb193:
  br label %bb203
bb194:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t727 = getelementptr %"compiler/effects:Effects", ptr %t725, i32 0, i32 25
  %t728 = getelementptr %"compiler/effects:Facts", ptr %t727, i32 0, i32 2
  store i1 true, ptr %t728, !tbaa !21
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load ptr, ptr %l40, !tbaa !29
  %t732 = getelementptr %"compiler/typed:Join", ptr %t730, i32 0, i32 0
  %t733 = load ptr, ptr %t732, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t729, ptr %t733)
  br label %bb195
bb195:
  %t737 = load ptr, ptr %l40, !tbaa !29
  %t739 = getelementptr %"compiler/typed:Join", ptr %t737, i32 0, i32 2
  %t740 = load { i64, ptr }, ptr %t739, !tbaa !27
  store { i64, ptr } %t740, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t742 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t742, 0
  store i64 %t744, ptr %l43, !tbaa !24
  br label %bb196
bb196:
  %t746 = load i64, ptr %l42, !tbaa !24
  %t747 = load i64, ptr %l43, !tbaa !24
  %t750 = icmp slt i64 %t746, %t747
  %t752 = xor i1 %t750, true
  br i1 %t752, label %bb197, label %bb198
bb197:
  br label %bb202
bb198:
  br label %bb199
bb199:
  %t754 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t754, ptr %l384, !tbaa !27
  %t755 = load i64, ptr %l42, !tbaa !24
  %t757 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !27
  %t759 = getelementptr ptr, ptr %t758, i64 %t755
  %t760 = load ptr, ptr %t759, !tbaa !39
  %t762 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %t762, ptr %t760)
  br label %bb200
bb200:
  br label %bb201
bb201:
  %t766 = load i64, ptr %l42, !tbaa !24
  %t769 = add i64 %t766, 1
  store i64 %t769, ptr %l42, !tbaa !24
  br label %bb196
bb202:
  br label %bb235
bb203:
  %t771 = load ptr, ptr %l1, !tbaa !29
  store ptr %t771, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t772 = load ptr, ptr %l392, !tbaa !29
  %t773 = icmp ne ptr %t772, null
  br i1 %t773, label %bb204, label %bb205
bb204:
  %t775 = load ptr, ptr %l392, !tbaa !29
  %t776 = load i64, ptr %t775, !range !{i64 0, i64 17}
  %t778 = icmp eq i64 %t776, 14
  store i1 %t778, ptr %l393, !tbaa !21
  br label %bb205
bb205:
  %t779 = load i1, ptr %l393, !tbaa !21
  br i1 %t779, label %bb206, label %bb207
bb206:
  %t780 = load ptr, ptr %l1, !tbaa !29
  %t782 = getelementptr { i64, [3 x i64] }, ptr %t780, i32 0, i32 1
  %t783 = getelementptr { %"compiler/source:Span", ptr }, ptr %t782, i32 0, i32 1
  %t784 = load ptr, ptr %t783
  store ptr %t784, ptr %l45, !tbaa !29
  br label %bb208
bb207:
  br label %bb234
bb208:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t788 = getelementptr %"compiler/effects:Effects", ptr %t786, i32 0, i32 25
  %t789 = getelementptr %"compiler/effects:Facts", ptr %t788, i32 0, i32 9
  store i1 true, ptr %t789, !tbaa !21
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %t790, i64 %t791)
  br label %bb209
bb209:
  %t794 = load ptr, ptr %l45, !tbaa !29
  %t796 = getelementptr %"compiler/typed:Spawn", ptr %t794, i32 0, i32 0
  %t797 = load { i64, ptr }, ptr %t796, !tbaa !27
  store { i64, ptr } %t797, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t799 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t801 = extractvalue { i64, ptr } %t799, 0
  store i64 %t801, ptr %l48, !tbaa !24
  br label %bb210
bb210:
  %t803 = load i64, ptr %l47, !tbaa !24
  %t804 = load i64, ptr %l48, !tbaa !24
  %t807 = icmp slt i64 %t803, %t804
  %t809 = xor i1 %t807, true
  br i1 %t809, label %bb211, label %bb212
bb211:
  br label %bb225
bb212:
  br label %bb213
bb213:
  %t811 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t811, ptr %l409, !tbaa !27
  %t812 = load i64, ptr %l47, !tbaa !24
  %t814 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t815 = load ptr, ptr %t814, !tbaa !27
  %t816 = getelementptr ptr, ptr %t815, i64 %t812
  %t817 = load ptr, ptr %t816, !tbaa !39
  store ptr %t817, ptr %l49, !tbaa !29
  %t819 = load ptr, ptr %l49, !tbaa !29
  %t821 = icmp eq ptr %t819, null
  br i1 %t821, label %bb214, label %bb215
bb214:
  br label %bb224
bb215:
  br label %bb216
bb216:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t823, ptr %t824, i1 true)
  br label %bb217
bb217:
  %t827 = load ptr, ptr %l49, !tbaa !29
  store ptr %t827, ptr %l416, !tbaa !29
  store i1 false, ptr %l417, !tbaa !21
  %t828 = load ptr, ptr %l416, !tbaa !29
  %t829 = icmp ne ptr %t828, null
  br i1 %t829, label %bb218, label %bb219
bb218:
  %t831 = load ptr, ptr %l416, !tbaa !29
  %t832 = load i64, ptr %t831, !range !{i64 0, i64 8}
  %t834 = icmp eq i64 %t832, 0
  store i1 %t834, ptr %l417, !tbaa !21
  br label %bb219
bb219:
  %t835 = load i1, ptr %l417, !tbaa !21
  br i1 %t835, label %bb220, label %bb221
bb220:
  %t836 = load ptr, ptr %l49, !tbaa !29
  %t838 = getelementptr { i64, [4 x i64] }, ptr %t836, i32 0, i32 1
  %t839 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t838, i32 0, i32 0
  %t840 = load %"compiler/source:Span", ptr %t839
  store %"compiler/source:Span" %t840, ptr %l50
  %t842 = load ptr, ptr %l49, !tbaa !29
  %t844 = getelementptr { i64, [4 x i64] }, ptr %t842, i32 0, i32 1
  %t845 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t844, i32 0, i32 1
  %t846 = load i32, ptr %t845
  store i32 %t846, ptr %l51, !tbaa !23
  %t848 = load ptr, ptr %l49, !tbaa !29
  %t850 = getelementptr { i64, [4 x i64] }, ptr %t848, i32 0, i32 1
  %t851 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t850, i32 0, i32 2
  %t852 = load i32, ptr %t851
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t857 = sext i32 %t852 to i64
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2espawnedInto(ptr %v0, ptr %t854, i64 %t857)
  br label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb223
bb223:
  br label %bb224
bb224:
  %t860 = load i64, ptr %l47, !tbaa !24
  %t863 = add i64 %t860, 1
  store i64 %t863, ptr %l47, !tbaa !24
  br label %bb210
bb225:
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t867 = getelementptr %"compiler/effects:Effects", ptr %t865, i32 0, i32 70
  store i1 true, ptr %t867, !tbaa !21
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load ptr, ptr %l45, !tbaa !29
  %t871 = getelementptr %"compiler/typed:Spawn", ptr %t869, i32 0, i32 1
  %t872 = load ptr, ptr %t871, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t868, ptr %t872)
  br label %bb226
bb226:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t878 = getelementptr %"compiler/effects:Effects", ptr %t876, i32 0, i32 70
  store i1 false, ptr %t878, !tbaa !21
  %t879 = load ptr, ptr %l45, !tbaa !29
  %t881 = getelementptr %"compiler/typed:Spawn", ptr %t879, i32 0, i32 2
  %t882 = load { i64, ptr }, ptr %t881, !tbaa !27
  store { i64, ptr } %t882, ptr %l53, !tbaa !27
  store i64 0, ptr %l54, !tbaa !24
  %t884 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t884, 0
  store i64 %t886, ptr %l55, !tbaa !24
  br label %bb227
bb227:
  %t888 = load i64, ptr %l54, !tbaa !24
  %t889 = load i64, ptr %l55, !tbaa !24
  %t892 = icmp slt i64 %t888, %t889
  %t894 = xor i1 %t892, true
  br i1 %t894, label %bb228, label %bb229
bb228:
  br label %bb233
bb229:
  br label %bb230
bb230:
  %t896 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t896, ptr %l446, !tbaa !27
  %t897 = load i64, ptr %l54, !tbaa !24
  %t899 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = getelementptr ptr, ptr %t900, i64 %t897
  %t902 = load ptr, ptr %t901, !tbaa !39
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t907 = getelementptr %"compiler/typed:TaskClause", ptr %t902, i32 0, i32 3
  %t908 = load ptr, ptr %t907, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t904, ptr %t908)
  br label %bb231
bb231:
  br label %bb232
bb232:
  %t911 = load i64, ptr %l54, !tbaa !24
  %t914 = add i64 %t911, 1
  store i64 %t914, ptr %l54, !tbaa !24
  br label %bb227
bb233:
  br label %bb235
bb234:
  call void @__olang_check_failed(ptr @olang_loc_cdd9fd819eb1314_592489ef7c054390)
  unreachable
bb235:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2etakesFn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l44 = alloca i1
  %l54 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 13
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l18
  br label %bb8
bb8:
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = icmp slt i64 %t24, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t27, i32 0, i32 13
  %t30 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30, i64 0)
  br label %bb11
bb10:
  br label %bb27
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l26
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l26, !tbaa !29
  store ptr %t40, ptr %l2, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 5
  store ptr %t43, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l29, !tbaa !24
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l31
  br label %bb14
bb14:
  %t49 = load i64, ptr %l29, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t55, i64 %t56)
  store i32 %t59, ptr %l36
  br label %bb18
bb18:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l37, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 7
  %t67 = sext i32 %t60 to i64
  %t70 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64, i64 %t67)
  store %"compiler/typed:Local" %t70, ptr %l42
  br label %bb19
bb19:
  %t71 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t75 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t73, i32 %t72)
  store i1 %t75, ptr %l44
  br label %bb20
bb20:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Effects", ptr %t77, i32 0, i32 13
  %t80 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t79, i64 %t80, i64 1)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l4, !tbaa !24
  br label %bb13
bb26:
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/effects:Effects", ptr %t88, i32 0, i32 13
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l54
  br label %bb28
bb28:
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = icmp eq i64 %t95, 1
  store i1 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i64
  %l59 = alloca i64
  %l61 = alloca i1
  %l65 = alloca i64
  %l69 = alloca %"compiler/effects:Facts"
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l97 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyNow(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i1, ptr %l13, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 26
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/effects:Effects", ptr %t15, i32 0, i32 51
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 26
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l24
  br label %bb7
bb7:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb13
bb10:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb16:
  br label %bb17
bb17:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t74, i32 0, i32 26
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t76, i64 %t72)
  store i64 %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = load i64, ptr %l52, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  br i1 %t84, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb22
bb20:
  %t86 = load i64, ptr %l10, !tbaa !24
  store i64 %t86, ptr %l56, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/effects:Effects", ptr %t87, i32 0, i32 1
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l59
  br label %bb21
bb21:
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = icmp sge i64 %t92, %t93
  store i1 %t94, ptr %l55, !tbaa !21
  br label %bb22
bb22:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb26
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Effects", ptr %t97, i32 0, i32 17
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l65
  br label %bb25
bb25:
  %t104 = load i64, ptr %l65, !tbaa !24
  %t105 = icmp slt i64 %t104, 2
  store i1 %t105, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t107 = load i1, ptr %l61, !tbaa !21
  br i1 %t107, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb28:
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2enamed(ptr %v0, ptr %t108, i64 %t109)
  store %"compiler/effects:Facts" %t112, ptr %l69
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Effects", ptr %t113, i32 0, i32 49
  %t116 = load i64, ptr %t115, !tbaa !24
  %t119 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %s3, ptr %s3, ptr %l69, i64 %t116)
  store { i64, ptr } %t119, ptr %l73
  br label %bb31
bb31:
  %t120 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t120, ptr %l11, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t121, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t123, ptr %l75
  br label %bb32
bb32:
  %t124 = load i1, ptr %l75, !tbaa !21
  br i1 %t124, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l76, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = call %"compiler/source:Span" @compiler_2feffects_2estmtSpan(ptr %v1, ptr %t126)
  store %"compiler/source:Span" %t128, ptr %l78
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %s3, ptr %t129, i64 %t130)
  store { i64, ptr } %t133, ptr %l81
  br label %bb37
bb37:
  %t134 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t135 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t137 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t145 = extractvalue { i64, ptr } %t134, 1
  %t146 = extractvalue { i64, ptr } %t134, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t135, i64 %t136)
  %t149 = getelementptr i8, ptr %t148, i64 %t136
  call void @olang_textcopy(ptr %t149, ptr %t138, i64 %t139)
  %t150 = getelementptr i8, ptr %t149, i64 %t139
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t145, i64 %t146)
  %t152 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t148, 1
  %t155 = load ptr, ptr %l76, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l78
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebecause(ptr %v0, ptr %s3, ptr %t155, %"compiler/source:Span" %t156, { i64, ptr } %t153)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb39:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l8, !tbaa !24
  br label %bb14
bb40:
  %t163 = load i1, ptr %l2, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyNow(ptr %v0, ptr %t167)
  store i1 %t169, ptr %l92
  br label %bb43
bb42:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb44
bb43:
  %t170 = load i1, ptr %l92, !tbaa !21
  store i1 %t170, ptr %l90, !tbaa !21
  br label %bb44
bb44:
  %t171 = load i1, ptr %l90, !tbaa !21
  br i1 %t171, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l93, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2feffects_2estmtSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyDoes(ptr %v0, ptr %s8, ptr %t176)
  store { i64, ptr } %t178, ptr %l97
  br label %bb48
bb48:
  %t179 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t181 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t188 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t187)
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  call void @olang_textcopy(ptr %t189, ptr %t182, i64 %t183)
  %t190 = getelementptr i8, ptr %t189, i64 %t183
  call void @olang_textcopy(ptr %t190, ptr %t185, i64 %t186)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t188, 1
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l95
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebecause(ptr %v0, ptr %s8, ptr %t194, %"compiler/source:Span" %t195, { i64, ptr } %t192)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eEvaluable(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 3
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 12
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 16
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 15
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 1
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 2
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 3
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 7
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 9
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Facts", ptr %t36, i32 0, i32 12
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t42, i32 0, i32 14
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Facts", ptr %t48, i32 0, i32 16
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 15
  %t58 = load i1, ptr %t57, !tbaa !21
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb28, label %bb29
bb28:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/effects:Facts", ptr %t62, i32 0, i32 21
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp eq i64 %t65, 0
  store i1 %t67, ptr %l31, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb30
bb30:
  %t69 = load i1, ptr %l31, !tbaa !21
  br i1 %t69, label %bb31, label %bb32
bb31:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Facts", ptr %t70, i32 0, i32 23
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l35, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb33
bb33:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb34, label %bb35
bb34:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Facts", ptr %t78, i32 0, i32 24
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb36
bb36:
  %t85 = load i1, ptr %l39, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t22)
  store i1 %t24, ptr %l8
  br label %bb4
bb4:
  %t25 = load i1, ptr %l8, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feffects_2eexclusiveShape(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t9, i32 %t10)
  store i64 %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load i64, ptr %l11, !tbaa !24
  %t17 = and i64 %t15, %t14
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l8, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i32, ptr %l19, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t31, ptr %l20
  br label %bb10
bb10:
  %t32 = load i32, ptr %l20, !tbaa !23
  store i32 %t32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l23, !range !{i32 0, i32 33}
  store i32 %t38, ptr %l3
  %t39 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t41 = trunc i64 19 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l29
  br label %bb15
bb15:
  %t49 = load i32, ptr %l29, !tbaa !23
  %t50 = icmp ne i32 %t49, 0
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb60
bb16:
  %t52 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l36, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t65, ptr %l37
  br label %bb21
bb21:
  %t66 = load i32, ptr %l37, !range !{i32 0, i32 6}
  %t68 = trunc i64 0 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb26
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i32, ptr %l44, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t79, ptr %l45
  br label %bb25
bb25:
  %t80 = load i32, ptr %l45, !range !{i32 0, i32 6}
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l40, !tbaa !21
  br label %bb26
bb26:
  %t85 = load i1, ptr %l40, !tbaa !21
  store i1 %t85, ptr %l24, !tbaa !21
  br label %bb60
bb27:
  %t86 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t88 = trunc i64 2 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb28, label %bb29
bb28:
  br label %bb54
bb29:
  %t91 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t93 = trunc i64 3 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb30, label %bb31
bb30:
  br label %bb54
bb31:
  %t96 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t98 = trunc i64 4 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb32, label %bb33
bb32:
  br label %bb54
bb33:
  %t101 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t103 = trunc i64 5 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb34, label %bb35
bb34:
  br label %bb54
bb35:
  %t106 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t108 = trunc i64 6 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb36, label %bb37
bb36:
  br label %bb54
bb37:
  %t111 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t113 = trunc i64 7 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb38, label %bb39
bb38:
  br label %bb54
bb39:
  %t116 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t118 = trunc i64 8 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb40, label %bb41
bb40:
  br label %bb54
bb41:
  %t121 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t123 = trunc i64 9 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb42, label %bb43
bb42:
  br label %bb54
bb43:
  %t126 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t128 = trunc i64 10 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb44, label %bb45
bb44:
  br label %bb54
bb45:
  %t131 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t133 = trunc i64 11 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb46, label %bb47
bb46:
  br label %bb54
bb47:
  %t136 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t138 = trunc i64 12 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  %t141 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t143 = trunc i64 13 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb50, label %bb51
bb50:
  br label %bb54
bb51:
  %t146 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t148 = trunc i64 14 to i32
  %t149 = icmp eq i32 %t146, %t148
  br i1 %t149, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_83cd05edfd6dbdc2_ee5ceab4d3ae0c56)
  unreachable
bb60:
  %t151 = load i1, ptr %l24, !tbaa !21
  store i1 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2elitTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d8bf60be8d53266c_65df02eeff1797b0)
  unreachable
bb14:
  %t33 = load i1, ptr %l3, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2enotReturning(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 17
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 12
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 13
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l10, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Facts", ptr %t34, i32 0, i32 10
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l17, !tbaa !24
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l17, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t53, ptr %l16, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 11
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l23, !tbaa !24
  %t63 = load i64, ptr %l23, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l24, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l23, !tbaa !24
  %t73 = mul i64 %t72, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t74, ptr %l22, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/effects:Facts", ptr %t76, i32 0, i32 2
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/effects:Facts", ptr %t81, i32 0, i32 8
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l27, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t87, ptr %l31, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l32, !tbaa !24
  %t90 = load i64, ptr %l32, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l33, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l32, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t101, ptr %l31, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/effects:Facts", ptr %t103, i32 0, i32 15
  %t106 = load i1, ptr %t105, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb24
bb23:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/effects:Facts", ptr %t108, i32 0, i32 18
  %t111 = load i1, ptr %t110, !tbaa !21
  store i1 %t111, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t113 = load i1, ptr %l36, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t114, ptr %l40, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l41, !tbaa !24
  %t117 = load i64, ptr %l41, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l42, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l41, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t128, ptr %l40, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l43, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t130, ptr %l44, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l45, !tbaa !24
  %t133 = load i64, ptr %l45, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l46, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l45, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t144, ptr %l44, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2feffects_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2feffects_2eparamOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l18
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t23 = load ptr, ptr %l19, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t36 = load ptr, ptr %l25, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l3, !tbaa !23
  br label %bb26
bb16:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t84, i32 0, i32 2
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l3, !tbaa !23
  br label %bb26
bb25:
  br label %bb44
bb26:
  store i64 0, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 5
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l47
  br label %bb27
bb27:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb33
bb30:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb33
bb33:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l7, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t130 = load i64, ptr %l4, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l9, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 5
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t142, i64 %t143)
  store i32 %t146, ptr %l75
  br label %bb38
bb38:
  %t147 = load i32, ptr %l3, !tbaa !23
  %t148 = load i32, ptr %l75, !tbaa !23
  %t150 = icmp eq i32 %t148, %t147
  br i1 %t150, label %bb39, label %bb40
bb39:
  %t152 = load i64, ptr %l9, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_bef23b7223d78d87_3941411f391512b)
  unreachable
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2feffects_2estmtSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 15
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 1
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb79
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 17}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 17}
  %t85 = icmp eq i64 %t83, 4
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 17}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 16
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb79
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 17}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 17}
  %t147 = icmp eq i64 %t145, 5
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 17}
  %t162 = icmp eq i64 %t160, 7
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 17}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb79
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 17}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb71
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 9
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb71
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 10
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb71
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 13
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t247 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t247, ptr %l6
  br label %bb79
bb72:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t250 = load ptr, ptr %l107, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l107, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 17}
  %t256 = icmp eq i64 %t254, 14
  store i1 %t256, ptr %l108, !tbaa !21
  br label %bb74
bb74:
  %t257 = load i1, ptr %l108, !tbaa !21
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 0
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l5
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t264 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t264, ptr %l6
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_f9d1419be2a6bd97_a466df32bbf19e6b)
  unreachable
bb79:
  %t266 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t266, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l27 = alloca %"compiler/effects:Facts"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca i1
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l59 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l60 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l63 = alloca i1
  %l64 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l66 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l67 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l69 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l70 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca %"compiler/typed:RefsKept"
  %l74 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca i64
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca i64
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i64
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca i64
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca i64
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l103 = alloca i64
  %l105 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l107 = alloca i64
  %l109 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l111 = alloca i64
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca i64
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca i64
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca i64
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l127 = alloca i64
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca i64
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca i64
  %l137 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l139 = alloca i64
  %l141 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l143 = alloca i64
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca i64
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca i64
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca i64
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca %"compiler/effects:Facts"
  %l160 = alloca i64
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca i64
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca i64
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca i64
  %l174 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca i64
  %l178 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l180 = alloca i64
  %l182 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l184 = alloca i64
  %l186 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l188 = alloca i64
  %l190 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l192 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l194 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l195 = alloca i64
  %l197 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l199 = alloca i64
  %l201 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l203 = alloca i64
  %l205 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l207 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca i64
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l215 = alloca { i64, ptr }
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca { i64, ptr }
  %l221 = alloca i64
  %l223 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l225 = alloca i64
  %l227 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l229 = alloca i64
  %l231 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l233 = alloca i64
  %l235 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l237 = alloca i64
  %l239 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l241 = alloca i64
  %l243 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l245 = alloca i64
  %l247 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l249 = alloca i64
  %l251 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l253 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l254 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l255 = alloca i64
  %l257 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l259 = alloca i64
  %l261 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l263 = alloca i64
  %l265 = alloca %"compiler/typed:RefsKept"
  %l267 = alloca i64
  %l269 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l271 = alloca i64
  %l273 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l275 = alloca i64
  %l277 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l279 = alloca %"compiler/effects:Effects"
  %t1191 = alloca %"compiler/typed:RefsKept", align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call ptr @__olang_scope_hold(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l79, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e3
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l79, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l79
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l81
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e3
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l79
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l5
  %t26 = call ptr @__olang_scope_hold(ptr %v2)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l83, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e4
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = call ptr @__olang_region_make(ptr %v2)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l83, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l83
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l85
  br label %bb8
bb8:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e4
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l83
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l6
  %t47 = call ptr @__olang_scope_hold(ptr %v2)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l87, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e5
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = call ptr @__olang_region_make(ptr %v2)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l87, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l87
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2ector(ptr %t54, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l89
  br label %bb13
bb13:
  %t56 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e5
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load i64, ptr %l87
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t66)
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l7
  %t68 = call ptr @__olang_scope_hold(ptr %v2)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l91, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e6
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = call ptr @__olang_region_make(ptr %v2)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l91, !tbaa !24
  br label %bb17
bb17:
  %t74 = load i64, ptr %l91
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t75, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l93
  br label %bb18
bb18:
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e6
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = load i64, ptr %l91
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr null)
  %t85 = call ptr @__olang_region_home(ptr %t84)
  %t86 = icmp ne ptr %t85, null
  %t87 = select i1 %t86, ptr %t85, ptr null
  call void @__olang_region_settle_in(ptr %t80, ptr %t87)
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l8
  %t89 = call ptr @__olang_scope_hold(ptr %v2)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l95, !tbaa !24
  %t91 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e7
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t93 = call ptr @__olang_region_make(ptr %v2)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l95, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l95
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t96, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l97
  br label %bb23
bb23:
  %t98 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e7
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t100 = load i64, ptr %l95
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr null)
  %t106 = call ptr @__olang_region_home(ptr %t105)
  %t107 = icmp ne ptr %t106, null
  %t108 = select i1 %t107, ptr %t106, ptr null
  call void @__olang_region_settle_in(ptr %t101, ptr %t108)
  br label %bb25
bb25:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l9
  %t110 = call ptr @__olang_scope_hold(ptr %v2)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l99, !tbaa !24
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e8
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t114 = call ptr @__olang_region_make(ptr %v2)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l99, !tbaa !24
  br label %bb27
bb27:
  %t116 = load i64, ptr %l99
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e_2ector(ptr %t117, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l101
  br label %bb28
bb28:
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e8
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l99
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = call ptr @__olang_region_or(ptr %t125, ptr null)
  %t127 = call ptr @__olang_region_home(ptr %t126)
  %t128 = icmp ne ptr %t127, null
  %t129 = select i1 %t128, ptr %t127, ptr null
  call void @__olang_region_settle_in(ptr %t122, ptr %t129)
  br label %bb30
bb30:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l10
  %t131 = call ptr @__olang_scope_hold(ptr %v2)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l103, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e9
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t135 = call ptr @__olang_region_make(ptr %v2)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l103, !tbaa !24
  br label %bb32
bb32:
  %t137 = load i64, ptr %l103
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_Hbea44694f2ac293c111b1f169c7495eb(ptr %t138)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t139, ptr %l105
  br label %bb33
bb33:
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e9
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load i64, ptr %l103
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = call ptr @__olang_region_home(ptr %t147)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  %t151 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 1
  %t152 = load { i64, ptr }, ptr %t151
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = call ptr @__olang_region_or(ptr %t153, ptr null)
  %t155 = call ptr @__olang_region_home(ptr %t154)
  %t156 = icmp ne ptr %t155, null
  %t157 = select i1 %t156, ptr %t155, ptr %t150
  %t158 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = call ptr @__olang_region_or(ptr %t160, ptr null)
  %t162 = call ptr @__olang_region_home(ptr %t161)
  %t163 = icmp ne ptr %t162, null
  %t164 = select i1 %t163, ptr %t162, ptr %t157
  call void @__olang_region_settle_in(ptr %t143, ptr %t164)
  br label %bb35
bb35:
  %t165 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l105
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t165, ptr %l11
  %t166 = call ptr @__olang_scope_hold(ptr %v2)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l107, !tbaa !24
  %t168 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e10
  br i1 %t168, label %bb36, label %bb37
bb36:
  %t170 = call ptr @__olang_region_make(ptr %v2)
  %t171 = ptrtoint ptr %t170 to i64
  store i64 %t171, ptr %l107, !tbaa !24
  br label %bb37
bb37:
  %t172 = load i64, ptr %l107
  %t173 = inttoptr i64 %t172 to ptr
  %t174 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %t173)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t174, ptr %l109
  br label %bb38
bb38:
  %t175 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e10
  br i1 %t175, label %bb39, label %bb40
bb39:
  %t177 = load i64, ptr %l107
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l109, i32 0, i32 2
  %t180 = load { i64, ptr }, ptr %t179
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = call ptr @__olang_region_or(ptr %t181, ptr null)
  %t183 = call ptr @__olang_region_home(ptr %t182)
  %t184 = icmp ne ptr %t183, null
  %t185 = select i1 %t184, ptr %t183, ptr null
  %t186 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l109, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = call ptr @__olang_region_or(ptr %t188, ptr null)
  %t190 = call ptr @__olang_region_home(ptr %t189)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr %t185
  %t193 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l109, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = call ptr @__olang_region_or(ptr %t195, ptr null)
  %t197 = call ptr @__olang_region_home(ptr %t196)
  %t198 = icmp ne ptr %t197, null
  %t199 = select i1 %t198, ptr %t197, ptr %t192
  call void @__olang_region_settle_in(ptr %t178, ptr %t199)
  br label %bb40
bb40:
  %t200 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l109
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t200, ptr %l12
  %t201 = call ptr @__olang_scope_hold(ptr %v2)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l111, !tbaa !24
  %t203 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e11
  br i1 %t203, label %bb41, label %bb42
bb41:
  %t205 = call ptr @__olang_region_make(ptr %v2)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l111, !tbaa !24
  br label %bb42
bb42:
  %t207 = load i64, ptr %l111
  %t208 = inttoptr i64 %t207 to ptr
  %t209 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %t208, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l113
  br label %bb43
bb43:
  %t210 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e11
  br i1 %t210, label %bb44, label %bb45
bb44:
  %t212 = load i64, ptr %l111
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = call ptr @__olang_region_or(ptr %t216, ptr null)
  %t218 = call ptr @__olang_region_home(ptr %t217)
  %t219 = icmp ne ptr %t218, null
  %t220 = select i1 %t219, ptr %t218, ptr null
  call void @__olang_region_settle_in(ptr %t213, ptr %t220)
  br label %bb45
bb45:
  %t221 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l13
  %t222 = call ptr @__olang_scope_hold(ptr %v2)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l115, !tbaa !24
  %t224 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e12
  br i1 %t224, label %bb46, label %bb47
bb46:
  %t226 = call ptr @__olang_region_make(ptr %v2)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l115, !tbaa !24
  br label %bb47
bb47:
  %t228 = load i64, ptr %l115
  %t229 = inttoptr i64 %t228 to ptr
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t229, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l117
  br label %bb48
bb48:
  %t231 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e12
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t233 = load i64, ptr %l115
  %t234 = inttoptr i64 %t233 to ptr
  %t235 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = call ptr @__olang_region_or(ptr %t237, ptr null)
  %t239 = call ptr @__olang_region_home(ptr %t238)
  %t240 = icmp ne ptr %t239, null
  %t241 = select i1 %t240, ptr %t239, ptr null
  call void @__olang_region_settle_in(ptr %t234, ptr %t241)
  br label %bb50
bb50:
  %t242 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t242, ptr %l14
  %t243 = call ptr @__olang_scope_hold(ptr %v2)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l119, !tbaa !24
  %t245 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e13
  br i1 %t245, label %bb51, label %bb52
bb51:
  %t247 = call ptr @__olang_region_make(ptr %v2)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l119, !tbaa !24
  br label %bb52
bb52:
  %t249 = load i64, ptr %l119
  %t250 = inttoptr i64 %t249 to ptr
  %t251 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t250, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l121
  br label %bb53
bb53:
  %t252 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e13
  br i1 %t252, label %bb54, label %bb55
bb54:
  %t254 = load i64, ptr %l119
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = call ptr @__olang_region_or(ptr %t258, ptr null)
  %t260 = call ptr @__olang_region_home(ptr %t259)
  %t261 = icmp ne ptr %t260, null
  %t262 = select i1 %t261, ptr %t260, ptr null
  call void @__olang_region_settle_in(ptr %t255, ptr %t262)
  br label %bb55
bb55:
  %t263 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l15
  %t264 = call ptr @__olang_scope_hold(ptr %v2)
  %t265 = ptrtoint ptr %t264 to i64
  store i64 %t265, ptr %l123, !tbaa !24
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e14
  br i1 %t266, label %bb56, label %bb57
bb56:
  %t268 = call ptr @__olang_region_make(ptr %v2)
  %t269 = ptrtoint ptr %t268 to i64
  store i64 %t269, ptr %l123, !tbaa !24
  br label %bb57
bb57:
  %t270 = load i64, ptr %l123
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t271, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %l125
  br label %bb58
bb58:
  %t273 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e14
  br i1 %t273, label %bb59, label %bb60
bb59:
  %t275 = load i64, ptr %l123
  %t276 = inttoptr i64 %t275 to ptr
  %t277 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = call ptr @__olang_region_or(ptr %t279, ptr null)
  %t281 = call ptr @__olang_region_home(ptr %t280)
  %t282 = icmp ne ptr %t281, null
  %t283 = select i1 %t282, ptr %t281, ptr null
  call void @__olang_region_settle_in(ptr %t276, ptr %t283)
  br label %bb60
bb60:
  %t284 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t284, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t285 = call ptr @__olang_scope_hold(ptr %v2)
  %t286 = ptrtoint ptr %t285 to i64
  store i64 %t286, ptr %l127, !tbaa !24
  %t287 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e16
  br i1 %t287, label %bb61, label %bb62
bb61:
  %t289 = call ptr @__olang_region_make(ptr %v2)
  %t290 = ptrtoint ptr %t289 to i64
  store i64 %t290, ptr %l127, !tbaa !24
  br label %bb62
bb62:
  %t291 = load i64, ptr %l127
  %t292 = inttoptr i64 %t291 to ptr
  %t293 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t292, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %l129
  br label %bb63
bb63:
  %t294 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e16
  br i1 %t294, label %bb64, label %bb65
bb64:
  %t296 = load i64, ptr %l127
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 0
  %t299 = load { i64, ptr }, ptr %t298
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = call ptr @__olang_region_or(ptr %t300, ptr null)
  %t302 = call ptr @__olang_region_home(ptr %t301)
  %t303 = icmp ne ptr %t302, null
  %t304 = select i1 %t303, ptr %t302, ptr null
  call void @__olang_region_settle_in(ptr %t297, ptr %t304)
  br label %bb65
bb65:
  %t305 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t305, ptr %l18
  %t306 = call ptr @__olang_scope_hold(ptr %v2)
  %t307 = ptrtoint ptr %t306 to i64
  store i64 %t307, ptr %l131, !tbaa !24
  %t308 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e17
  br i1 %t308, label %bb66, label %bb67
bb66:
  %t310 = call ptr @__olang_region_make(ptr %v2)
  %t311 = ptrtoint ptr %t310 to i64
  store i64 %t311, ptr %l131, !tbaa !24
  br label %bb67
bb67:
  %t312 = load i64, ptr %l131
  %t313 = inttoptr i64 %t312 to ptr
  %t314 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t313, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %l133
  br label %bb68
bb68:
  %t315 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e17
  br i1 %t315, label %bb69, label %bb70
bb69:
  %t317 = load i64, ptr %l131
  %t318 = inttoptr i64 %t317 to ptr
  %t319 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133, i32 0, i32 0
  %t320 = load { i64, ptr }, ptr %t319
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = call ptr @__olang_region_or(ptr %t321, ptr null)
  %t323 = call ptr @__olang_region_home(ptr %t322)
  %t324 = icmp ne ptr %t323, null
  %t325 = select i1 %t324, ptr %t323, ptr null
  call void @__olang_region_settle_in(ptr %t318, ptr %t325)
  br label %bb70
bb70:
  %t326 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %l19
  %t327 = call ptr @__olang_scope_hold(ptr %v2)
  %t328 = ptrtoint ptr %t327 to i64
  store i64 %t328, ptr %l135, !tbaa !24
  %t329 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e18
  br i1 %t329, label %bb71, label %bb72
bb71:
  %t331 = call ptr @__olang_region_make(ptr %v2)
  %t332 = ptrtoint ptr %t331 to i64
  store i64 %t332, ptr %l135, !tbaa !24
  br label %bb72
bb72:
  %t333 = load i64, ptr %l135
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t334)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t335, ptr %l137
  br label %bb73
bb73:
  %t336 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e18
  br i1 %t336, label %bb74, label %bb75
bb74:
  %t338 = load i64, ptr %l135
  %t339 = inttoptr i64 %t338 to ptr
  %t340 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l137, i32 0, i32 2
  %t341 = load { i64, ptr }, ptr %t340
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = call ptr @__olang_region_or(ptr %t342, ptr null)
  %t344 = call ptr @__olang_region_home(ptr %t343)
  %t345 = icmp ne ptr %t344, null
  %t346 = select i1 %t345, ptr %t344, ptr null
  %t347 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l137, i32 0, i32 1
  %t348 = load { i64, ptr }, ptr %t347
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = call ptr @__olang_region_or(ptr %t349, ptr null)
  %t351 = call ptr @__olang_region_home(ptr %t350)
  %t352 = icmp ne ptr %t351, null
  %t353 = select i1 %t352, ptr %t351, ptr %t346
  %t354 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l137, i32 0, i32 0
  %t355 = load { i64, ptr }, ptr %t354
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = call ptr @__olang_region_or(ptr %t356, ptr null)
  %t358 = call ptr @__olang_region_home(ptr %t357)
  %t359 = icmp ne ptr %t358, null
  %t360 = select i1 %t359, ptr %t358, ptr %t353
  call void @__olang_region_settle_in(ptr %t339, ptr %t360)
  br label %bb75
bb75:
  %t361 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l137
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t361, ptr %l20
  %t362 = call ptr @__olang_scope_hold(ptr %v2)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l139, !tbaa !24
  %t364 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e19
  br i1 %t364, label %bb76, label %bb77
bb76:
  %t366 = call ptr @__olang_region_make(ptr %v2)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l139, !tbaa !24
  br label %bb77
bb77:
  %t368 = load i64, ptr %l139
  %t369 = inttoptr i64 %t368 to ptr
  %t370 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %t369)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t370, ptr %l141
  br label %bb78
bb78:
  %t371 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e19
  br i1 %t371, label %bb79, label %bb80
bb79:
  %t373 = load i64, ptr %l139
  %t374 = inttoptr i64 %t373 to ptr
  %t375 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141, i32 0, i32 2
  %t376 = load { i64, ptr }, ptr %t375
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = call ptr @__olang_region_or(ptr %t377, ptr null)
  %t379 = call ptr @__olang_region_home(ptr %t378)
  %t380 = icmp ne ptr %t379, null
  %t381 = select i1 %t380, ptr %t379, ptr null
  %t382 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141, i32 0, i32 1
  %t383 = load { i64, ptr }, ptr %t382
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = call ptr @__olang_region_or(ptr %t384, ptr null)
  %t386 = call ptr @__olang_region_home(ptr %t385)
  %t387 = icmp ne ptr %t386, null
  %t388 = select i1 %t387, ptr %t386, ptr %t381
  %t389 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = call ptr @__olang_region_or(ptr %t391, ptr null)
  %t393 = call ptr @__olang_region_home(ptr %t392)
  %t394 = icmp ne ptr %t393, null
  %t395 = select i1 %t394, ptr %t393, ptr %t388
  call void @__olang_region_settle_in(ptr %t374, ptr %t395)
  br label %bb80
bb80:
  %t396 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t396, ptr %l21
  %t397 = call ptr @__olang_scope_hold(ptr %v2)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l143, !tbaa !24
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e20
  br i1 %t399, label %bb81, label %bb82
bb81:
  %t401 = call ptr @__olang_region_make(ptr %v2)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l143, !tbaa !24
  br label %bb82
bb82:
  %t403 = load i64, ptr %l143
  %t404 = inttoptr i64 %t403 to ptr
  %t405 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t404, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t405, ptr %l145
  br label %bb83
bb83:
  %t406 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e20
  br i1 %t406, label %bb84, label %bb85
bb84:
  %t408 = load i64, ptr %l143
  %t409 = inttoptr i64 %t408 to ptr
  %t410 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145, i32 0, i32 0
  %t411 = load { i64, ptr }, ptr %t410
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = call ptr @__olang_region_or(ptr %t412, ptr null)
  %t414 = call ptr @__olang_region_home(ptr %t413)
  %t415 = icmp ne ptr %t414, null
  %t416 = select i1 %t415, ptr %t414, ptr null
  call void @__olang_region_settle_in(ptr %t409, ptr %t416)
  br label %bb85
bb85:
  %t417 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %l22
  %t418 = call ptr @__olang_scope_hold(ptr %v2)
  %t419 = ptrtoint ptr %t418 to i64
  store i64 %t419, ptr %l147, !tbaa !24
  %t420 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e21
  br i1 %t420, label %bb86, label %bb87
bb86:
  %t422 = call ptr @__olang_region_make(ptr %v2)
  %t423 = ptrtoint ptr %t422 to i64
  store i64 %t423, ptr %l147, !tbaa !24
  br label %bb87
bb87:
  %t424 = load i64, ptr %l147
  %t425 = inttoptr i64 %t424 to ptr
  %t426 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t425, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t426, ptr %l149
  br label %bb88
bb88:
  %t427 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e21
  br i1 %t427, label %bb89, label %bb90
bb89:
  %t429 = load i64, ptr %l147
  %t430 = inttoptr i64 %t429 to ptr
  %t431 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149, i32 0, i32 0
  %t432 = load { i64, ptr }, ptr %t431
  %t433 = extractvalue { i64, ptr } %t432, 1
  %t434 = call ptr @__olang_region_or(ptr %t433, ptr null)
  %t435 = call ptr @__olang_region_home(ptr %t434)
  %t436 = icmp ne ptr %t435, null
  %t437 = select i1 %t436, ptr %t435, ptr null
  call void @__olang_region_settle_in(ptr %t430, ptr %t437)
  br label %bb90
bb90:
  %t438 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t438, ptr %l23
  %t439 = call ptr @__olang_scope_hold(ptr %v2)
  %t440 = ptrtoint ptr %t439 to i64
  store i64 %t440, ptr %l151, !tbaa !24
  %t441 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e22
  br i1 %t441, label %bb91, label %bb92
bb91:
  %t443 = call ptr @__olang_region_make(ptr %v2)
  %t444 = ptrtoint ptr %t443 to i64
  store i64 %t444, ptr %l151, !tbaa !24
  br label %bb92
bb92:
  %t445 = load i64, ptr %l151
  %t446 = inttoptr i64 %t445 to ptr
  %t447 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t446, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t447, ptr %l153
  br label %bb93
bb93:
  %t448 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e22
  br i1 %t448, label %bb94, label %bb95
bb94:
  %t450 = load i64, ptr %l151
  %t451 = inttoptr i64 %t450 to ptr
  %t452 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153, i32 0, i32 0
  %t453 = load { i64, ptr }, ptr %t452
  %t454 = extractvalue { i64, ptr } %t453, 1
  %t455 = call ptr @__olang_region_or(ptr %t454, ptr null)
  %t456 = call ptr @__olang_region_home(ptr %t455)
  %t457 = icmp ne ptr %t456, null
  %t458 = select i1 %t457, ptr %t456, ptr null
  call void @__olang_region_settle_in(ptr %t451, ptr %t458)
  br label %bb95
bb95:
  %t459 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t459, ptr %l24
  %t460 = call ptr @__olang_scope_hold(ptr %v2)
  %t461 = ptrtoint ptr %t460 to i64
  store i64 %t461, ptr %l155, !tbaa !24
  %t462 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e23
  br i1 %t462, label %bb96, label %bb97
bb96:
  %t464 = call ptr @__olang_region_make(ptr %v2)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l155, !tbaa !24
  br label %bb97
bb97:
  %t466 = load i64, ptr %l155
  %t467 = inttoptr i64 %t466 to ptr
  %t468 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t467, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t468, ptr %l157
  br label %bb98
bb98:
  %t469 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e23
  br i1 %t469, label %bb99, label %bb100
bb99:
  %t471 = load i64, ptr %l155
  %t472 = inttoptr i64 %t471 to ptr
  %t473 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157, i32 0, i32 0
  %t474 = load { i64, ptr }, ptr %t473
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = call ptr @__olang_region_or(ptr %t475, ptr null)
  %t477 = call ptr @__olang_region_home(ptr %t476)
  %t478 = icmp ne ptr %t477, null
  %t479 = select i1 %t478, ptr %t477, ptr null
  call void @__olang_region_settle_in(ptr %t472, ptr %t479)
  br label %bb100
bb100:
  %t480 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t480, ptr %l25
  store i64 0, ptr %l26, !tbaa !24
  %t481 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v2)
  store %"compiler/effects:Facts" %t481, ptr %l159
  br label %bb101
bb101:
  %t482 = load %"compiler/effects:Facts", ptr %l159
  store %"compiler/effects:Facts" %t482, ptr %l27
  %t483 = call ptr @__olang_scope_hold(ptr %v2)
  %t484 = ptrtoint ptr %t483 to i64
  store i64 %t484, ptr %l160, !tbaa !24
  %t485 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e26
  br i1 %t485, label %bb102, label %bb103
bb102:
  %t487 = call ptr @__olang_region_make(ptr %v2)
  %t488 = ptrtoint ptr %t487 to i64
  store i64 %t488, ptr %l160, !tbaa !24
  br label %bb103
bb103:
  %t489 = load i64, ptr %l160
  %t490 = inttoptr i64 %t489 to ptr
  %t491 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t490, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t491, ptr %l162
  br label %bb104
bb104:
  %t492 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e26
  br i1 %t492, label %bb105, label %bb106
bb105:
  %t494 = load i64, ptr %l160
  %t495 = inttoptr i64 %t494 to ptr
  %t496 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162, i32 0, i32 0
  %t497 = load { i64, ptr }, ptr %t496
  %t498 = extractvalue { i64, ptr } %t497, 1
  %t499 = call ptr @__olang_region_or(ptr %t498, ptr null)
  %t500 = call ptr @__olang_region_home(ptr %t499)
  %t501 = icmp ne ptr %t500, null
  %t502 = select i1 %t501, ptr %t500, ptr null
  call void @__olang_region_settle_in(ptr %t495, ptr %t502)
  br label %bb106
bb106:
  %t503 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t503, ptr %l28
  %t504 = call ptr @__olang_scope_hold(ptr %v2)
  %t505 = ptrtoint ptr %t504 to i64
  store i64 %t505, ptr %l164, !tbaa !24
  %t506 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t506, label %bb107, label %bb108
bb107:
  %t508 = call ptr @__olang_region_make(ptr %v2)
  %t509 = ptrtoint ptr %t508 to i64
  store i64 %t509, ptr %l164, !tbaa !24
  br label %bb108
bb108:
  %t510 = load i64, ptr %l164
  %t511 = inttoptr i64 %t510 to ptr
  %t512 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t511, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t512, ptr %l166
  br label %bb109
bb109:
  %t513 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t513, label %bb110, label %bb111
bb110:
  %t515 = load i64, ptr %l164
  %t516 = inttoptr i64 %t515 to ptr
  %t517 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l166, i32 0, i32 0
  %t518 = load { i64, ptr }, ptr %t517
  %t519 = extractvalue { i64, ptr } %t518, 1
  %t520 = call ptr @__olang_region_or(ptr %t519, ptr null)
  %t521 = call ptr @__olang_region_home(ptr %t520)
  %t522 = icmp ne ptr %t521, null
  %t523 = select i1 %t522, ptr %t521, ptr null
  call void @__olang_region_settle_in(ptr %t516, ptr %t523)
  br label %bb111
bb111:
  %t524 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l166
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t524, ptr %l29
  store i64 0, ptr %l30, !tbaa !24
  %t525 = call ptr @__olang_scope_hold(ptr %v2)
  %t526 = ptrtoint ptr %t525 to i64
  store i64 %t526, ptr %l168, !tbaa !24
  %t527 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t527, label %bb112, label %bb113
bb112:
  %t529 = call ptr @__olang_region_make(ptr %v2)
  %t530 = ptrtoint ptr %t529 to i64
  store i64 %t530, ptr %l168, !tbaa !24
  br label %bb113
bb113:
  %t531 = load i64, ptr %l168
  %t532 = inttoptr i64 %t531 to ptr
  %t533 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %t532, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t533, ptr %l170
  br label %bb114
bb114:
  %t534 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t534, label %bb115, label %bb116
bb115:
  %t536 = load i64, ptr %l168
  %t537 = inttoptr i64 %t536 to ptr
  %t538 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170, i32 0, i32 0
  %t539 = load { i64, ptr }, ptr %t538
  %t540 = extractvalue { i64, ptr } %t539, 1
  %t541 = call ptr @__olang_region_or(ptr %t540, ptr null)
  %t542 = call ptr @__olang_region_home(ptr %t541)
  %t543 = icmp ne ptr %t542, null
  %t544 = select i1 %t543, ptr %t542, ptr null
  call void @__olang_region_settle_in(ptr %t537, ptr %t544)
  br label %bb116
bb116:
  %t545 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t545, ptr %l31
  %t546 = call ptr @__olang_scope_hold(ptr %v2)
  %t547 = ptrtoint ptr %t546 to i64
  store i64 %t547, ptr %l172, !tbaa !24
  %t548 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e30
  br i1 %t548, label %bb117, label %bb118
bb117:
  %t550 = call ptr @__olang_region_make(ptr %v2)
  %t551 = ptrtoint ptr %t550 to i64
  store i64 %t551, ptr %l172, !tbaa !24
  br label %bb118
bb118:
  %t552 = load i64, ptr %l172
  %t553 = inttoptr i64 %t552 to ptr
  %t554 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %t553, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t554, ptr %l174
  br label %bb119
bb119:
  %t555 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e30
  br i1 %t555, label %bb120, label %bb121
bb120:
  %t557 = load i64, ptr %l172
  %t558 = inttoptr i64 %t557 to ptr
  %t559 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l174, i32 0, i32 0
  %t560 = load { i64, ptr }, ptr %t559
  %t561 = extractvalue { i64, ptr } %t560, 1
  %t562 = call ptr @__olang_region_or(ptr %t561, ptr null)
  %t563 = call ptr @__olang_region_home(ptr %t562)
  %t564 = icmp ne ptr %t563, null
  %t565 = select i1 %t564, ptr %t563, ptr null
  call void @__olang_region_settle_in(ptr %t558, ptr %t565)
  br label %bb121
bb121:
  %t566 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l174
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %l32
  %t567 = call ptr @__olang_scope_hold(ptr %v2)
  %t568 = ptrtoint ptr %t567 to i64
  store i64 %t568, ptr %l176, !tbaa !24
  %t569 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t569, label %bb122, label %bb123
bb122:
  %t571 = call ptr @__olang_region_make(ptr %v2)
  %t572 = ptrtoint ptr %t571 to i64
  store i64 %t572, ptr %l176, !tbaa !24
  br label %bb123
bb123:
  %t573 = load i64, ptr %l176
  %t574 = inttoptr i64 %t573 to ptr
  %t575 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t574)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t575, ptr %l178
  br label %bb124
bb124:
  %t576 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t576, label %bb125, label %bb126
bb125:
  %t578 = load i64, ptr %l176
  %t579 = inttoptr i64 %t578 to ptr
  %t580 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l178, i32 0, i32 2
  %t581 = load { i64, ptr }, ptr %t580
  %t582 = extractvalue { i64, ptr } %t581, 1
  %t583 = call ptr @__olang_region_or(ptr %t582, ptr null)
  %t584 = call ptr @__olang_region_home(ptr %t583)
  %t585 = icmp ne ptr %t584, null
  %t586 = select i1 %t585, ptr %t584, ptr null
  %t587 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l178, i32 0, i32 1
  %t588 = load { i64, ptr }, ptr %t587
  %t589 = extractvalue { i64, ptr } %t588, 1
  %t590 = call ptr @__olang_region_or(ptr %t589, ptr null)
  %t591 = call ptr @__olang_region_home(ptr %t590)
  %t592 = icmp ne ptr %t591, null
  %t593 = select i1 %t592, ptr %t591, ptr %t586
  %t594 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l178, i32 0, i32 0
  %t595 = load { i64, ptr }, ptr %t594
  %t596 = extractvalue { i64, ptr } %t595, 1
  %t597 = call ptr @__olang_region_or(ptr %t596, ptr null)
  %t598 = call ptr @__olang_region_home(ptr %t597)
  %t599 = icmp ne ptr %t598, null
  %t600 = select i1 %t599, ptr %t598, ptr %t593
  call void @__olang_region_settle_in(ptr %t579, ptr %t600)
  br label %bb126
bb126:
  %t601 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l178
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t601, ptr %l33
  %t602 = call ptr @__olang_scope_hold(ptr %v2)
  %t603 = ptrtoint ptr %t602 to i64
  store i64 %t603, ptr %l180, !tbaa !24
  %t604 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t604, label %bb127, label %bb128
bb127:
  %t606 = call ptr @__olang_region_make(ptr %v2)
  %t607 = ptrtoint ptr %t606 to i64
  store i64 %t607, ptr %l180, !tbaa !24
  br label %bb128
bb128:
  %t608 = load i64, ptr %l180
  %t609 = inttoptr i64 %t608 to ptr
  %t610 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t609)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t610, ptr %l182
  br label %bb129
bb129:
  %t611 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t611, label %bb130, label %bb131
bb130:
  %t613 = load i64, ptr %l180
  %t614 = inttoptr i64 %t613 to ptr
  %t615 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l182, i32 0, i32 2
  %t616 = load { i64, ptr }, ptr %t615
  %t617 = extractvalue { i64, ptr } %t616, 1
  %t618 = call ptr @__olang_region_or(ptr %t617, ptr null)
  %t619 = call ptr @__olang_region_home(ptr %t618)
  %t620 = icmp ne ptr %t619, null
  %t621 = select i1 %t620, ptr %t619, ptr null
  %t622 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l182, i32 0, i32 1
  %t623 = load { i64, ptr }, ptr %t622
  %t624 = extractvalue { i64, ptr } %t623, 1
  %t625 = call ptr @__olang_region_or(ptr %t624, ptr null)
  %t626 = call ptr @__olang_region_home(ptr %t625)
  %t627 = icmp ne ptr %t626, null
  %t628 = select i1 %t627, ptr %t626, ptr %t621
  %t629 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l182, i32 0, i32 0
  %t630 = load { i64, ptr }, ptr %t629
  %t631 = extractvalue { i64, ptr } %t630, 1
  %t632 = call ptr @__olang_region_or(ptr %t631, ptr null)
  %t633 = call ptr @__olang_region_home(ptr %t632)
  %t634 = icmp ne ptr %t633, null
  %t635 = select i1 %t634, ptr %t633, ptr %t628
  call void @__olang_region_settle_in(ptr %t614, ptr %t635)
  br label %bb131
bb131:
  %t636 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l182
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t636, ptr %l34
  %t637 = call ptr @__olang_scope_hold(ptr %v2)
  %t638 = ptrtoint ptr %t637 to i64
  store i64 %t638, ptr %l184, !tbaa !24
  %t639 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e33
  br i1 %t639, label %bb132, label %bb133
bb132:
  %t641 = call ptr @__olang_region_make(ptr %v2)
  %t642 = ptrtoint ptr %t641 to i64
  store i64 %t642, ptr %l184, !tbaa !24
  br label %bb133
bb133:
  %t643 = load i64, ptr %l184
  %t644 = inttoptr i64 %t643 to ptr
  %t645 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t644)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t645, ptr %l186
  br label %bb134
bb134:
  %t646 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e33
  br i1 %t646, label %bb135, label %bb136
bb135:
  %t648 = load i64, ptr %l184
  %t649 = inttoptr i64 %t648 to ptr
  %t650 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 2
  %t651 = load { i64, ptr }, ptr %t650
  %t652 = extractvalue { i64, ptr } %t651, 1
  %t653 = call ptr @__olang_region_or(ptr %t652, ptr null)
  %t654 = call ptr @__olang_region_home(ptr %t653)
  %t655 = icmp ne ptr %t654, null
  %t656 = select i1 %t655, ptr %t654, ptr null
  %t657 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 1
  %t658 = load { i64, ptr }, ptr %t657
  %t659 = extractvalue { i64, ptr } %t658, 1
  %t660 = call ptr @__olang_region_or(ptr %t659, ptr null)
  %t661 = call ptr @__olang_region_home(ptr %t660)
  %t662 = icmp ne ptr %t661, null
  %t663 = select i1 %t662, ptr %t661, ptr %t656
  %t664 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186, i32 0, i32 0
  %t665 = load { i64, ptr }, ptr %t664
  %t666 = extractvalue { i64, ptr } %t665, 1
  %t667 = call ptr @__olang_region_or(ptr %t666, ptr null)
  %t668 = call ptr @__olang_region_home(ptr %t667)
  %t669 = icmp ne ptr %t668, null
  %t670 = select i1 %t669, ptr %t668, ptr %t663
  call void @__olang_region_settle_in(ptr %t649, ptr %t670)
  br label %bb136
bb136:
  %t671 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l186
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t671, ptr %l35
  %t672 = call ptr @__olang_scope_hold(ptr %v2)
  %t673 = ptrtoint ptr %t672 to i64
  store i64 %t673, ptr %l188, !tbaa !24
  %t674 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e34
  br i1 %t674, label %bb137, label %bb138
bb137:
  %t676 = call ptr @__olang_region_make(ptr %v2)
  %t677 = ptrtoint ptr %t676 to i64
  store i64 %t677, ptr %l188, !tbaa !24
  br label %bb138
bb138:
  %t678 = load i64, ptr %l188
  %t679 = inttoptr i64 %t678 to ptr
  %t680 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t679)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t680, ptr %l190
  br label %bb139
bb139:
  %t681 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e34
  br i1 %t681, label %bb140, label %bb141
bb140:
  %t683 = load i64, ptr %l188
  %t684 = inttoptr i64 %t683 to ptr
  %t685 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 2
  %t686 = load { i64, ptr }, ptr %t685
  %t687 = extractvalue { i64, ptr } %t686, 1
  %t688 = call ptr @__olang_region_or(ptr %t687, ptr null)
  %t689 = call ptr @__olang_region_home(ptr %t688)
  %t690 = icmp ne ptr %t689, null
  %t691 = select i1 %t690, ptr %t689, ptr null
  %t692 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 1
  %t693 = load { i64, ptr }, ptr %t692
  %t694 = extractvalue { i64, ptr } %t693, 1
  %t695 = call ptr @__olang_region_or(ptr %t694, ptr null)
  %t696 = call ptr @__olang_region_home(ptr %t695)
  %t697 = icmp ne ptr %t696, null
  %t698 = select i1 %t697, ptr %t696, ptr %t691
  %t699 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 0
  %t700 = load { i64, ptr }, ptr %t699
  %t701 = extractvalue { i64, ptr } %t700, 1
  %t702 = call ptr @__olang_region_or(ptr %t701, ptr null)
  %t703 = call ptr @__olang_region_home(ptr %t702)
  %t704 = icmp ne ptr %t703, null
  %t705 = select i1 %t704, ptr %t703, ptr %t698
  call void @__olang_region_settle_in(ptr %t684, ptr %t705)
  br label %bb141
bb141:
  %t706 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t706, ptr %l36
  store i64 -1, ptr %l37, !tbaa !24
  store i64 -1, ptr %l38, !tbaa !24
  %t707 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t707, ptr %l192
  br label %bb142
bb142:
  %t708 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l192
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t708, ptr %l39
  %t709 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t709, ptr %l193
  br label %bb143
bb143:
  %t710 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l193
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t710, ptr %l40
  %t711 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H3227b03907400d34f4865c02b6d98850(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t711, ptr %l194
  br label %bb144
bb144:
  %t712 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l194
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t712, ptr %l41
  %t713 = call ptr @__olang_scope_hold(ptr %v2)
  %t714 = ptrtoint ptr %t713 to i64
  store i64 %t714, ptr %l195, !tbaa !24
  %t715 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e40
  br i1 %t715, label %bb145, label %bb146
bb145:
  %t717 = call ptr @__olang_region_make(ptr %v2)
  %t718 = ptrtoint ptr %t717 to i64
  store i64 %t718, ptr %l195, !tbaa !24
  br label %bb146
bb146:
  %t719 = load i64, ptr %l195
  %t720 = inttoptr i64 %t719 to ptr
  %t721 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t720)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t721, ptr %l197
  br label %bb147
bb147:
  %t722 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e40
  br i1 %t722, label %bb148, label %bb149
bb148:
  %t724 = load i64, ptr %l195
  %t725 = inttoptr i64 %t724 to ptr
  %t726 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l197, i32 0, i32 2
  %t727 = load { i64, ptr }, ptr %t726
  %t728 = extractvalue { i64, ptr } %t727, 1
  %t729 = call ptr @__olang_region_or(ptr %t728, ptr null)
  %t730 = call ptr @__olang_region_home(ptr %t729)
  %t731 = icmp ne ptr %t730, null
  %t732 = select i1 %t731, ptr %t730, ptr null
  %t733 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l197, i32 0, i32 1
  %t734 = load { i64, ptr }, ptr %t733
  %t735 = extractvalue { i64, ptr } %t734, 1
  %t736 = call ptr @__olang_region_or(ptr %t735, ptr null)
  %t737 = call ptr @__olang_region_home(ptr %t736)
  %t738 = icmp ne ptr %t737, null
  %t739 = select i1 %t738, ptr %t737, ptr %t732
  %t740 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l197, i32 0, i32 0
  %t741 = load { i64, ptr }, ptr %t740
  %t742 = extractvalue { i64, ptr } %t741, 1
  %t743 = call ptr @__olang_region_or(ptr %t742, ptr null)
  %t744 = call ptr @__olang_region_home(ptr %t743)
  %t745 = icmp ne ptr %t744, null
  %t746 = select i1 %t745, ptr %t744, ptr %t739
  call void @__olang_region_settle_in(ptr %t725, ptr %t746)
  br label %bb149
bb149:
  %t747 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l197
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t747, ptr %l42
  %t748 = call ptr @__olang_scope_hold(ptr %v2)
  %t749 = ptrtoint ptr %t748 to i64
  store i64 %t749, ptr %l199, !tbaa !24
  %t750 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e41
  br i1 %t750, label %bb150, label %bb151
bb150:
  %t752 = call ptr @__olang_region_make(ptr %v2)
  %t753 = ptrtoint ptr %t752 to i64
  store i64 %t753, ptr %l199, !tbaa !24
  br label %bb151
bb151:
  %t754 = load i64, ptr %l199
  %t755 = inttoptr i64 %t754 to ptr
  %t756 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t755, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t756, ptr %l201
  br label %bb152
bb152:
  %t757 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e41
  br i1 %t757, label %bb153, label %bb154
bb153:
  %t759 = load i64, ptr %l199
  %t760 = inttoptr i64 %t759 to ptr
  %t761 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l201, i32 0, i32 0
  %t762 = load { i64, ptr }, ptr %t761
  %t763 = extractvalue { i64, ptr } %t762, 1
  %t764 = call ptr @__olang_region_or(ptr %t763, ptr null)
  %t765 = call ptr @__olang_region_home(ptr %t764)
  %t766 = icmp ne ptr %t765, null
  %t767 = select i1 %t766, ptr %t765, ptr null
  call void @__olang_region_settle_in(ptr %t760, ptr %t767)
  br label %bb154
bb154:
  %t768 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l201
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t768, ptr %l43
  %t769 = call ptr @__olang_scope_hold(ptr %v2)
  %t770 = ptrtoint ptr %t769 to i64
  store i64 %t770, ptr %l203, !tbaa !24
  %t771 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e42
  br i1 %t771, label %bb155, label %bb156
bb155:
  %t773 = call ptr @__olang_region_make(ptr %v2)
  %t774 = ptrtoint ptr %t773 to i64
  store i64 %t774, ptr %l203, !tbaa !24
  br label %bb156
bb156:
  %t775 = load i64, ptr %l203
  %t776 = inttoptr i64 %t775 to ptr
  %t777 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t776, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t777, ptr %l205
  br label %bb157
bb157:
  %t778 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e42
  br i1 %t778, label %bb158, label %bb159
bb158:
  %t780 = load i64, ptr %l203
  %t781 = inttoptr i64 %t780 to ptr
  %t782 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l205, i32 0, i32 0
  %t783 = load { i64, ptr }, ptr %t782
  %t784 = extractvalue { i64, ptr } %t783, 1
  %t785 = call ptr @__olang_region_or(ptr %t784, ptr null)
  %t786 = call ptr @__olang_region_home(ptr %t785)
  %t787 = icmp ne ptr %t786, null
  %t788 = select i1 %t787, ptr %t786, ptr null
  call void @__olang_region_settle_in(ptr %t781, ptr %t788)
  br label %bb159
bb159:
  %t789 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l205
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t789, ptr %l44
  store i1 false, ptr %l45, !tbaa !21
  store i1 false, ptr %l46, !tbaa !21
  store i1 false, ptr %l47, !tbaa !21
  %t790 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t790, ptr %l207
  br label %bb160
bb160:
  %t791 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l207
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t791, ptr %l48
  %t792 = call ptr @__olang_scope_hold(ptr %v2)
  %t793 = ptrtoint ptr %t792 to i64
  store i64 %t793, ptr %l208, !tbaa !24
  %t794 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e47
  br i1 %t794, label %bb161, label %bb162
bb161:
  %t796 = call ptr @__olang_region_make(ptr %v2)
  %t797 = ptrtoint ptr %t796 to i64
  store i64 %t797, ptr %l208, !tbaa !24
  br label %bb162
bb162:
  %t798 = load i64, ptr %l208
  %t799 = inttoptr i64 %t798 to ptr
  %t800 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t799, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t800, ptr %l210
  br label %bb163
bb163:
  %t801 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e47
  br i1 %t801, label %bb164, label %bb165
bb164:
  %t803 = load i64, ptr %l208
  %t804 = inttoptr i64 %t803 to ptr
  %t805 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l210, i32 0, i32 0
  %t806 = load { i64, ptr }, ptr %t805
  %t807 = extractvalue { i64, ptr } %t806, 1
  %t808 = call ptr @__olang_region_or(ptr %t807, ptr null)
  %t809 = call ptr @__olang_region_home(ptr %t808)
  %t810 = icmp ne ptr %t809, null
  %t811 = select i1 %t810, ptr %t809, ptr null
  call void @__olang_region_settle_in(ptr %t804, ptr %t811)
  br label %bb165
bb165:
  %t812 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l210
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t812, ptr %l49
  store i1 false, ptr %l50, !tbaa !21
  store i64 0, ptr %l51, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l212, !tbaa !27
  %t813 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t813, ptr %l213, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 0
  store i64 %t815, ptr %l214, !tbaa !24
  %t816 = load i64, ptr %l214, !tbaa !24
  %t817 = mul i64 %t816, 1
  %t818 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t817)
  %t819 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t818, 1
  store { i64, ptr } %t820, ptr %l215, !tbaa !27
  %t821 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !27
  %t823 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = load i64, ptr %l214, !tbaa !24
  %t826 = mul i64 %t825, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t822, ptr %t824, i64 %t826, i1 false)
  %t827 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t827, ptr %l52, !tbaa !27
  store i1 false, ptr %l53, !tbaa !21
  %t828 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t828, ptr %l216
  br label %bb166
bb166:
  %t829 = load %"compiler/source:Span", ptr %l216
  store %"compiler/source:Span" %t829, ptr %l54
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l217, !tbaa !27
  %t830 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t830, ptr %l218, !tbaa !27
  %t831 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t832 = extractvalue { i64, ptr } %t831, 0
  store i64 %t832, ptr %l219, !tbaa !24
  %t833 = load i64, ptr %l219, !tbaa !24
  %t834 = mul i64 %t833, 1
  %t835 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t834)
  %t836 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  store { i64, ptr } %t837, ptr %l220, !tbaa !27
  %t838 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t839 = load ptr, ptr %t838, !tbaa !27
  %t840 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t841 = load ptr, ptr %t840, !tbaa !27
  %t842 = load i64, ptr %l219, !tbaa !24
  %t843 = mul i64 %t842, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t839, ptr %t841, i64 %t843, i1 false)
  %t844 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t844, ptr %l55, !tbaa !27
  store i1 false, ptr %l56, !tbaa !21
  store i64 -1, ptr %l57, !tbaa !24
  %t845 = call ptr @__olang_scope_hold(ptr %v2)
  %t846 = ptrtoint ptr %t845 to i64
  store i64 %t846, ptr %l221, !tbaa !24
  %t847 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e56
  br i1 %t847, label %bb167, label %bb168
bb167:
  %t849 = call ptr @__olang_region_make(ptr %v2)
  %t850 = ptrtoint ptr %t849 to i64
  store i64 %t850, ptr %l221, !tbaa !24
  br label %bb168
bb168:
  %t851 = load i64, ptr %l221
  %t852 = inttoptr i64 %t851 to ptr
  %t853 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t852)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t853, ptr %l223
  br label %bb169
bb169:
  %t854 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e56
  br i1 %t854, label %bb170, label %bb171
bb170:
  %t856 = load i64, ptr %l221
  %t857 = inttoptr i64 %t856 to ptr
  %t858 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l223, i32 0, i32 2
  %t859 = load { i64, ptr }, ptr %t858
  %t860 = extractvalue { i64, ptr } %t859, 1
  %t861 = call ptr @__olang_region_or(ptr %t860, ptr null)
  %t862 = call ptr @__olang_region_home(ptr %t861)
  %t863 = icmp ne ptr %t862, null
  %t864 = select i1 %t863, ptr %t862, ptr null
  %t865 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l223, i32 0, i32 1
  %t866 = load { i64, ptr }, ptr %t865
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = call ptr @__olang_region_or(ptr %t867, ptr null)
  %t869 = call ptr @__olang_region_home(ptr %t868)
  %t870 = icmp ne ptr %t869, null
  %t871 = select i1 %t870, ptr %t869, ptr %t864
  %t872 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l223, i32 0, i32 0
  %t873 = load { i64, ptr }, ptr %t872
  %t874 = extractvalue { i64, ptr } %t873, 1
  %t875 = call ptr @__olang_region_or(ptr %t874, ptr null)
  %t876 = call ptr @__olang_region_home(ptr %t875)
  %t877 = icmp ne ptr %t876, null
  %t878 = select i1 %t877, ptr %t876, ptr %t871
  call void @__olang_region_settle_in(ptr %t857, ptr %t878)
  br label %bb171
bb171:
  %t879 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l223
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t879, ptr %l58
  %t880 = call ptr @__olang_scope_hold(ptr %v2)
  %t881 = ptrtoint ptr %t880 to i64
  store i64 %t881, ptr %l225, !tbaa !24
  %t882 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e57
  br i1 %t882, label %bb172, label %bb173
bb172:
  %t884 = call ptr @__olang_region_make(ptr %v2)
  %t885 = ptrtoint ptr %t884 to i64
  store i64 %t885, ptr %l225, !tbaa !24
  br label %bb173
bb173:
  %t886 = load i64, ptr %l225
  %t887 = inttoptr i64 %t886 to ptr
  %t888 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t887)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t888, ptr %l227
  br label %bb174
bb174:
  %t889 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e57
  br i1 %t889, label %bb175, label %bb176
bb175:
  %t891 = load i64, ptr %l225
  %t892 = inttoptr i64 %t891 to ptr
  %t893 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l227, i32 0, i32 2
  %t894 = load { i64, ptr }, ptr %t893
  %t895 = extractvalue { i64, ptr } %t894, 1
  %t896 = call ptr @__olang_region_or(ptr %t895, ptr null)
  %t897 = call ptr @__olang_region_home(ptr %t896)
  %t898 = icmp ne ptr %t897, null
  %t899 = select i1 %t898, ptr %t897, ptr null
  %t900 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l227, i32 0, i32 1
  %t901 = load { i64, ptr }, ptr %t900
  %t902 = extractvalue { i64, ptr } %t901, 1
  %t903 = call ptr @__olang_region_or(ptr %t902, ptr null)
  %t904 = call ptr @__olang_region_home(ptr %t903)
  %t905 = icmp ne ptr %t904, null
  %t906 = select i1 %t905, ptr %t904, ptr %t899
  %t907 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l227, i32 0, i32 0
  %t908 = load { i64, ptr }, ptr %t907
  %t909 = extractvalue { i64, ptr } %t908, 1
  %t910 = call ptr @__olang_region_or(ptr %t909, ptr null)
  %t911 = call ptr @__olang_region_home(ptr %t910)
  %t912 = icmp ne ptr %t911, null
  %t913 = select i1 %t912, ptr %t911, ptr %t906
  call void @__olang_region_settle_in(ptr %t892, ptr %t913)
  br label %bb176
bb176:
  %t914 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l227
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t914, ptr %l59
  %t915 = call ptr @__olang_scope_hold(ptr %v2)
  %t916 = ptrtoint ptr %t915 to i64
  store i64 %t916, ptr %l229, !tbaa !24
  %t917 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e58
  br i1 %t917, label %bb177, label %bb178
bb177:
  %t919 = call ptr @__olang_region_make(ptr %v2)
  %t920 = ptrtoint ptr %t919 to i64
  store i64 %t920, ptr %l229, !tbaa !24
  br label %bb178
bb178:
  %t921 = load i64, ptr %l229
  %t922 = inttoptr i64 %t921 to ptr
  %t923 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t922)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t923, ptr %l231
  br label %bb179
bb179:
  %t924 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e58
  br i1 %t924, label %bb180, label %bb181
bb180:
  %t926 = load i64, ptr %l229
  %t927 = inttoptr i64 %t926 to ptr
  %t928 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l231, i32 0, i32 2
  %t929 = load { i64, ptr }, ptr %t928
  %t930 = extractvalue { i64, ptr } %t929, 1
  %t931 = call ptr @__olang_region_or(ptr %t930, ptr null)
  %t932 = call ptr @__olang_region_home(ptr %t931)
  %t933 = icmp ne ptr %t932, null
  %t934 = select i1 %t933, ptr %t932, ptr null
  %t935 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l231, i32 0, i32 1
  %t936 = load { i64, ptr }, ptr %t935
  %t937 = extractvalue { i64, ptr } %t936, 1
  %t938 = call ptr @__olang_region_or(ptr %t937, ptr null)
  %t939 = call ptr @__olang_region_home(ptr %t938)
  %t940 = icmp ne ptr %t939, null
  %t941 = select i1 %t940, ptr %t939, ptr %t934
  %t942 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l231, i32 0, i32 0
  %t943 = load { i64, ptr }, ptr %t942
  %t944 = extractvalue { i64, ptr } %t943, 1
  %t945 = call ptr @__olang_region_or(ptr %t944, ptr null)
  %t946 = call ptr @__olang_region_home(ptr %t945)
  %t947 = icmp ne ptr %t946, null
  %t948 = select i1 %t947, ptr %t946, ptr %t941
  call void @__olang_region_settle_in(ptr %t927, ptr %t948)
  br label %bb181
bb181:
  %t949 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l231
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t949, ptr %l60
  %t950 = call ptr @__olang_scope_hold(ptr %v2)
  %t951 = ptrtoint ptr %t950 to i64
  store i64 %t951, ptr %l233, !tbaa !24
  %t952 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e59
  br i1 %t952, label %bb182, label %bb183
bb182:
  %t954 = call ptr @__olang_region_make(ptr %v2)
  %t955 = ptrtoint ptr %t954 to i64
  store i64 %t955, ptr %l233, !tbaa !24
  br label %bb183
bb183:
  %t956 = load i64, ptr %l233
  %t957 = inttoptr i64 %t956 to ptr
  %t958 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t957, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t958, ptr %l235
  br label %bb184
bb184:
  %t959 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e59
  br i1 %t959, label %bb185, label %bb186
bb185:
  %t961 = load i64, ptr %l233
  %t962 = inttoptr i64 %t961 to ptr
  %t963 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l235, i32 0, i32 0
  %t964 = load { i64, ptr }, ptr %t963
  %t965 = extractvalue { i64, ptr } %t964, 1
  %t966 = call ptr @__olang_region_or(ptr %t965, ptr null)
  %t967 = call ptr @__olang_region_home(ptr %t966)
  %t968 = icmp ne ptr %t967, null
  %t969 = select i1 %t968, ptr %t967, ptr null
  call void @__olang_region_settle_in(ptr %t962, ptr %t969)
  br label %bb186
bb186:
  %t970 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l235
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t970, ptr %l61
  %t971 = call ptr @__olang_scope_hold(ptr %v2)
  %t972 = ptrtoint ptr %t971 to i64
  store i64 %t972, ptr %l237, !tbaa !24
  %t973 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e60
  br i1 %t973, label %bb187, label %bb188
bb187:
  %t975 = call ptr @__olang_region_make(ptr %v2)
  %t976 = ptrtoint ptr %t975 to i64
  store i64 %t976, ptr %l237, !tbaa !24
  br label %bb188
bb188:
  %t977 = load i64, ptr %l237
  %t978 = inttoptr i64 %t977 to ptr
  %t979 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t978)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t979, ptr %l239
  br label %bb189
bb189:
  %t980 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e60
  br i1 %t980, label %bb190, label %bb191
bb190:
  %t982 = load i64, ptr %l237
  %t983 = inttoptr i64 %t982 to ptr
  %t984 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l239, i32 0, i32 2
  %t985 = load { i64, ptr }, ptr %t984
  %t986 = extractvalue { i64, ptr } %t985, 1
  %t987 = call ptr @__olang_region_or(ptr %t986, ptr null)
  %t988 = call ptr @__olang_region_home(ptr %t987)
  %t989 = icmp ne ptr %t988, null
  %t990 = select i1 %t989, ptr %t988, ptr null
  %t991 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l239, i32 0, i32 1
  %t992 = load { i64, ptr }, ptr %t991
  %t993 = extractvalue { i64, ptr } %t992, 1
  %t994 = call ptr @__olang_region_or(ptr %t993, ptr null)
  %t995 = call ptr @__olang_region_home(ptr %t994)
  %t996 = icmp ne ptr %t995, null
  %t997 = select i1 %t996, ptr %t995, ptr %t990
  %t998 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l239, i32 0, i32 0
  %t999 = load { i64, ptr }, ptr %t998
  %t1000 = extractvalue { i64, ptr } %t999, 1
  %t1001 = call ptr @__olang_region_or(ptr %t1000, ptr null)
  %t1002 = call ptr @__olang_region_home(ptr %t1001)
  %t1003 = icmp ne ptr %t1002, null
  %t1004 = select i1 %t1003, ptr %t1002, ptr %t997
  call void @__olang_region_settle_in(ptr %t983, ptr %t1004)
  br label %bb191
bb191:
  %t1005 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l239
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1005, ptr %l62
  store i1 false, ptr %l63, !tbaa !21
  %t1006 = call ptr @__olang_scope_hold(ptr %v2)
  %t1007 = ptrtoint ptr %t1006 to i64
  store i64 %t1007, ptr %l241, !tbaa !24
  %t1008 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e62
  br i1 %t1008, label %bb192, label %bb193
bb192:
  %t1010 = call ptr @__olang_region_make(ptr %v2)
  %t1011 = ptrtoint ptr %t1010 to i64
  store i64 %t1011, ptr %l241, !tbaa !24
  br label %bb193
bb193:
  %t1012 = load i64, ptr %l241
  %t1013 = inttoptr i64 %t1012 to ptr
  %t1014 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %t1013)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1014, ptr %l243
  br label %bb194
bb194:
  %t1015 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e62
  br i1 %t1015, label %bb195, label %bb196
bb195:
  %t1017 = load i64, ptr %l241
  %t1018 = inttoptr i64 %t1017 to ptr
  %t1019 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l243, i32 0, i32 2
  %t1020 = load { i64, ptr }, ptr %t1019
  %t1021 = extractvalue { i64, ptr } %t1020, 1
  %t1022 = call ptr @__olang_region_or(ptr %t1021, ptr null)
  %t1023 = call ptr @__olang_region_home(ptr %t1022)
  %t1024 = icmp ne ptr %t1023, null
  %t1025 = select i1 %t1024, ptr %t1023, ptr null
  %t1026 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l243, i32 0, i32 1
  %t1027 = load { i64, ptr }, ptr %t1026
  %t1028 = extractvalue { i64, ptr } %t1027, 1
  %t1029 = call ptr @__olang_region_or(ptr %t1028, ptr null)
  %t1030 = call ptr @__olang_region_home(ptr %t1029)
  %t1031 = icmp ne ptr %t1030, null
  %t1032 = select i1 %t1031, ptr %t1030, ptr %t1025
  %t1033 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l243, i32 0, i32 0
  %t1034 = load { i64, ptr }, ptr %t1033
  %t1035 = extractvalue { i64, ptr } %t1034, 1
  %t1036 = call ptr @__olang_region_or(ptr %t1035, ptr null)
  %t1037 = call ptr @__olang_region_home(ptr %t1036)
  %t1038 = icmp ne ptr %t1037, null
  %t1039 = select i1 %t1038, ptr %t1037, ptr %t1032
  call void @__olang_region_settle_in(ptr %t1018, ptr %t1039)
  br label %bb196
bb196:
  %t1040 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l243
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1040, ptr %l64
  %t1041 = call ptr @__olang_scope_hold(ptr %v2)
  %t1042 = ptrtoint ptr %t1041 to i64
  store i64 %t1042, ptr %l245, !tbaa !24
  %t1043 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e63
  br i1 %t1043, label %bb197, label %bb198
bb197:
  %t1045 = call ptr @__olang_region_make(ptr %v2)
  %t1046 = ptrtoint ptr %t1045 to i64
  store i64 %t1046, ptr %l245, !tbaa !24
  br label %bb198
bb198:
  %t1047 = load i64, ptr %l245
  %t1048 = inttoptr i64 %t1047 to ptr
  %t1049 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hfe0b8a6431726c879f98e5933eafeded(ptr %t1048)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1049, ptr %l247
  br label %bb199
bb199:
  %t1050 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e63
  br i1 %t1050, label %bb200, label %bb201
bb200:
  %t1052 = load i64, ptr %l245
  %t1053 = inttoptr i64 %t1052 to ptr
  %t1054 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l247, i32 0, i32 2
  %t1055 = load { i64, ptr }, ptr %t1054
  %t1056 = extractvalue { i64, ptr } %t1055, 1
  %t1057 = call ptr @__olang_region_or(ptr %t1056, ptr null)
  %t1058 = call ptr @__olang_region_home(ptr %t1057)
  %t1059 = icmp ne ptr %t1058, null
  %t1060 = select i1 %t1059, ptr %t1058, ptr null
  %t1061 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l247, i32 0, i32 1
  %t1062 = load { i64, ptr }, ptr %t1061
  %t1063 = extractvalue { i64, ptr } %t1062, 1
  %t1064 = call ptr @__olang_region_or(ptr %t1063, ptr null)
  %t1065 = call ptr @__olang_region_home(ptr %t1064)
  %t1066 = icmp ne ptr %t1065, null
  %t1067 = select i1 %t1066, ptr %t1065, ptr %t1060
  %t1068 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l247, i32 0, i32 0
  %t1069 = load { i64, ptr }, ptr %t1068
  %t1070 = extractvalue { i64, ptr } %t1069, 1
  %t1071 = call ptr @__olang_region_or(ptr %t1070, ptr null)
  %t1072 = call ptr @__olang_region_home(ptr %t1071)
  %t1073 = icmp ne ptr %t1072, null
  %t1074 = select i1 %t1073, ptr %t1072, ptr %t1067
  call void @__olang_region_settle_in(ptr %t1053, ptr %t1074)
  br label %bb201
bb201:
  %t1075 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l247
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1075, ptr %l65
  %t1076 = call ptr @__olang_scope_hold(ptr %v2)
  %t1077 = ptrtoint ptr %t1076 to i64
  store i64 %t1077, ptr %l249, !tbaa !24
  %t1078 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e64
  br i1 %t1078, label %bb202, label %bb203
bb202:
  %t1080 = call ptr @__olang_region_make(ptr %v2)
  %t1081 = ptrtoint ptr %t1080 to i64
  store i64 %t1081, ptr %l249, !tbaa !24
  br label %bb203
bb203:
  %t1082 = load i64, ptr %l249
  %t1083 = inttoptr i64 %t1082 to ptr
  %t1084 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_Hdcf598faa391f42f17ca4d3159c68b14(ptr %t1083)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1084, ptr %l251
  br label %bb204
bb204:
  %t1085 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e64
  br i1 %t1085, label %bb205, label %bb206
bb205:
  %t1087 = load i64, ptr %l249
  %t1088 = inttoptr i64 %t1087 to ptr
  %t1089 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l251, i32 0, i32 2
  %t1090 = load { i64, ptr }, ptr %t1089
  %t1091 = extractvalue { i64, ptr } %t1090, 1
  %t1092 = call ptr @__olang_region_or(ptr %t1091, ptr null)
  %t1093 = call ptr @__olang_region_home(ptr %t1092)
  %t1094 = icmp ne ptr %t1093, null
  %t1095 = select i1 %t1094, ptr %t1093, ptr null
  %t1096 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l251, i32 0, i32 1
  %t1097 = load { i64, ptr }, ptr %t1096
  %t1098 = extractvalue { i64, ptr } %t1097, 1
  %t1099 = call ptr @__olang_region_or(ptr %t1098, ptr null)
  %t1100 = call ptr @__olang_region_home(ptr %t1099)
  %t1101 = icmp ne ptr %t1100, null
  %t1102 = select i1 %t1101, ptr %t1100, ptr %t1095
  %t1103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l251, i32 0, i32 0
  %t1104 = load { i64, ptr }, ptr %t1103
  %t1105 = extractvalue { i64, ptr } %t1104, 1
  %t1106 = call ptr @__olang_region_or(ptr %t1105, ptr null)
  %t1107 = call ptr @__olang_region_home(ptr %t1106)
  %t1108 = icmp ne ptr %t1107, null
  %t1109 = select i1 %t1108, ptr %t1107, ptr %t1102
  call void @__olang_region_settle_in(ptr %t1088, ptr %t1109)
  br label %bb206
bb206:
  %t1110 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l251
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1110, ptr %l66
  %t1111 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H2f96a66e37bdd4e6ba26b25615641feb(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1111, ptr %l253
  br label %bb207
bb207:
  %t1112 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l253
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1112, ptr %l67
  %t1113 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H3227b03907400d34f4865c02b6d98850(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1113, ptr %l254
  br label %bb208
bb208:
  %t1114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l254
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1114, ptr %l68
  %t1115 = call ptr @__olang_scope_hold(ptr %v2)
  %t1116 = ptrtoint ptr %t1115 to i64
  store i64 %t1116, ptr %l255, !tbaa !24
  %t1117 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e67
  br i1 %t1117, label %bb209, label %bb210
bb209:
  %t1119 = call ptr @__olang_region_make(ptr %v2)
  %t1120 = ptrtoint ptr %t1119 to i64
  store i64 %t1120, ptr %l255, !tbaa !24
  br label %bb210
bb210:
  %t1121 = load i64, ptr %l255
  %t1122 = inttoptr i64 %t1121 to ptr
  %t1123 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1122)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1123, ptr %l257
  br label %bb211
bb211:
  %t1124 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e67
  br i1 %t1124, label %bb212, label %bb213
bb212:
  %t1126 = load i64, ptr %l255
  %t1127 = inttoptr i64 %t1126 to ptr
  %t1128 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l257, i32 0, i32 2
  %t1129 = load { i64, ptr }, ptr %t1128
  %t1130 = extractvalue { i64, ptr } %t1129, 1
  %t1131 = call ptr @__olang_region_or(ptr %t1130, ptr null)
  %t1132 = call ptr @__olang_region_home(ptr %t1131)
  %t1133 = icmp ne ptr %t1132, null
  %t1134 = select i1 %t1133, ptr %t1132, ptr null
  %t1135 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l257, i32 0, i32 1
  %t1136 = load { i64, ptr }, ptr %t1135
  %t1137 = extractvalue { i64, ptr } %t1136, 1
  %t1138 = call ptr @__olang_region_or(ptr %t1137, ptr null)
  %t1139 = call ptr @__olang_region_home(ptr %t1138)
  %t1140 = icmp ne ptr %t1139, null
  %t1141 = select i1 %t1140, ptr %t1139, ptr %t1134
  %t1142 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l257, i32 0, i32 0
  %t1143 = load { i64, ptr }, ptr %t1142
  %t1144 = extractvalue { i64, ptr } %t1143, 1
  %t1145 = call ptr @__olang_region_or(ptr %t1144, ptr null)
  %t1146 = call ptr @__olang_region_home(ptr %t1145)
  %t1147 = icmp ne ptr %t1146, null
  %t1148 = select i1 %t1147, ptr %t1146, ptr %t1141
  call void @__olang_region_settle_in(ptr %t1127, ptr %t1148)
  br label %bb213
bb213:
  %t1149 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l257
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1149, ptr %l69
  %t1150 = call ptr @__olang_scope_hold(ptr %v2)
  %t1151 = ptrtoint ptr %t1150 to i64
  store i64 %t1151, ptr %l259, !tbaa !24
  %t1152 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e68
  br i1 %t1152, label %bb214, label %bb215
bb214:
  %t1154 = call ptr @__olang_region_make(ptr %v2)
  %t1155 = ptrtoint ptr %t1154 to i64
  store i64 %t1155, ptr %l259, !tbaa !24
  br label %bb215
bb215:
  %t1156 = load i64, ptr %l259
  %t1157 = inttoptr i64 %t1156 to ptr
  %t1158 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t1157)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1158, ptr %l261
  br label %bb216
bb216:
  %t1159 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e68
  br i1 %t1159, label %bb217, label %bb218
bb217:
  %t1161 = load i64, ptr %l259
  %t1162 = inttoptr i64 %t1161 to ptr
  %t1163 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l261, i32 0, i32 2
  %t1164 = load { i64, ptr }, ptr %t1163
  %t1165 = extractvalue { i64, ptr } %t1164, 1
  %t1166 = call ptr @__olang_region_or(ptr %t1165, ptr null)
  %t1167 = call ptr @__olang_region_home(ptr %t1166)
  %t1168 = icmp ne ptr %t1167, null
  %t1169 = select i1 %t1168, ptr %t1167, ptr null
  %t1170 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l261, i32 0, i32 1
  %t1171 = load { i64, ptr }, ptr %t1170
  %t1172 = extractvalue { i64, ptr } %t1171, 1
  %t1173 = call ptr @__olang_region_or(ptr %t1172, ptr null)
  %t1174 = call ptr @__olang_region_home(ptr %t1173)
  %t1175 = icmp ne ptr %t1174, null
  %t1176 = select i1 %t1175, ptr %t1174, ptr %t1169
  %t1177 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l261, i32 0, i32 0
  %t1178 = load { i64, ptr }, ptr %t1177
  %t1179 = extractvalue { i64, ptr } %t1178, 1
  %t1180 = call ptr @__olang_region_or(ptr %t1179, ptr null)
  %t1181 = call ptr @__olang_region_home(ptr %t1180)
  %t1182 = icmp ne ptr %t1181, null
  %t1183 = select i1 %t1182, ptr %t1181, ptr %t1176
  call void @__olang_region_settle_in(ptr %t1162, ptr %t1183)
  br label %bb218
bb218:
  %t1184 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l261
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1184, ptr %l70
  store i1 false, ptr %l71, !tbaa !21
  store i1 false, ptr %l72, !tbaa !21
  %t1185 = call ptr @__olang_scope_hold(ptr %v2)
  %t1186 = ptrtoint ptr %t1185 to i64
  store i64 %t1186, ptr %l263, !tbaa !24
  %t1187 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e71
  br i1 %t1187, label %bb219, label %bb220
bb219:
  %t1189 = call ptr @__olang_region_make(ptr %v2)
  %t1190 = ptrtoint ptr %t1189 to i64
  store i64 %t1190, ptr %l263, !tbaa !24
  br label %bb220
bb220:
  %t1192 = load i64, ptr %l263
  %t1193 = inttoptr i64 %t1192 to ptr
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2ftyped_3aRefsKept(ptr %t1191, ptr %t1193)
  call void @llvm.memmove.p0.p0.i64(ptr %l265, ptr %t1191, i64 296, i1 false)
  br label %bb221
bb221:
  %t1194 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e71
  br i1 %t1194, label %bb222, label %bb223
bb222:
  %t1196 = load i64, ptr %l263
  %t1197 = inttoptr i64 %t1196 to ptr
  %t1198 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 4
  %t1199 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1198, i32 0, i32 2
  %t1200 = load { i64, ptr }, ptr %t1199
  %t1201 = extractvalue { i64, ptr } %t1200, 1
  %t1202 = call ptr @__olang_region_or(ptr %t1201, ptr null)
  %t1203 = call ptr @__olang_region_home(ptr %t1202)
  %t1204 = icmp ne ptr %t1203, null
  %t1205 = select i1 %t1204, ptr %t1203, ptr null
  %t1206 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 4
  %t1207 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1206, i32 0, i32 1
  %t1208 = load { i64, ptr }, ptr %t1207
  %t1209 = extractvalue { i64, ptr } %t1208, 1
  %t1210 = call ptr @__olang_region_or(ptr %t1209, ptr null)
  %t1211 = call ptr @__olang_region_home(ptr %t1210)
  %t1212 = icmp ne ptr %t1211, null
  %t1213 = select i1 %t1212, ptr %t1211, ptr %t1205
  %t1214 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 4
  %t1215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1214, i32 0, i32 0
  %t1216 = load { i64, ptr }, ptr %t1215
  %t1217 = extractvalue { i64, ptr } %t1216, 1
  %t1218 = call ptr @__olang_region_or(ptr %t1217, ptr null)
  %t1219 = call ptr @__olang_region_home(ptr %t1218)
  %t1220 = icmp ne ptr %t1219, null
  %t1221 = select i1 %t1220, ptr %t1219, ptr %t1213
  %t1222 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 2
  %t1223 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1222, i32 0, i32 2
  %t1224 = load { i64, ptr }, ptr %t1223
  %t1225 = extractvalue { i64, ptr } %t1224, 1
  %t1226 = call ptr @__olang_region_or(ptr %t1225, ptr null)
  %t1227 = call ptr @__olang_region_home(ptr %t1226)
  %t1228 = icmp ne ptr %t1227, null
  %t1229 = select i1 %t1228, ptr %t1227, ptr %t1221
  %t1230 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 2
  %t1231 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1230, i32 0, i32 1
  %t1232 = load { i64, ptr }, ptr %t1231
  %t1233 = extractvalue { i64, ptr } %t1232, 1
  %t1234 = call ptr @__olang_region_or(ptr %t1233, ptr null)
  %t1235 = call ptr @__olang_region_home(ptr %t1234)
  %t1236 = icmp ne ptr %t1235, null
  %t1237 = select i1 %t1236, ptr %t1235, ptr %t1229
  %t1238 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 2
  %t1239 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1238, i32 0, i32 0
  %t1240 = load { i64, ptr }, ptr %t1239
  %t1241 = extractvalue { i64, ptr } %t1240, 1
  %t1242 = call ptr @__olang_region_or(ptr %t1241, ptr null)
  %t1243 = call ptr @__olang_region_home(ptr %t1242)
  %t1244 = icmp ne ptr %t1243, null
  %t1245 = select i1 %t1244, ptr %t1243, ptr %t1237
  %t1246 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 1
  %t1247 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1246, i32 0, i32 2
  %t1248 = load { i64, ptr }, ptr %t1247
  %t1249 = extractvalue { i64, ptr } %t1248, 1
  %t1250 = call ptr @__olang_region_or(ptr %t1249, ptr null)
  %t1251 = call ptr @__olang_region_home(ptr %t1250)
  %t1252 = icmp ne ptr %t1251, null
  %t1253 = select i1 %t1252, ptr %t1251, ptr %t1245
  %t1254 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 1
  %t1255 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1254, i32 0, i32 1
  %t1256 = load { i64, ptr }, ptr %t1255
  %t1257 = extractvalue { i64, ptr } %t1256, 1
  %t1258 = call ptr @__olang_region_or(ptr %t1257, ptr null)
  %t1259 = call ptr @__olang_region_home(ptr %t1258)
  %t1260 = icmp ne ptr %t1259, null
  %t1261 = select i1 %t1260, ptr %t1259, ptr %t1253
  %t1262 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 1
  %t1263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1262, i32 0, i32 0
  %t1264 = load { i64, ptr }, ptr %t1263
  %t1265 = extractvalue { i64, ptr } %t1264, 1
  %t1266 = call ptr @__olang_region_or(ptr %t1265, ptr null)
  %t1267 = call ptr @__olang_region_home(ptr %t1266)
  %t1268 = icmp ne ptr %t1267, null
  %t1269 = select i1 %t1268, ptr %t1267, ptr %t1261
  %t1270 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 0
  %t1271 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1270, i32 0, i32 2
  %t1272 = load { i64, ptr }, ptr %t1271
  %t1273 = extractvalue { i64, ptr } %t1272, 1
  %t1274 = call ptr @__olang_region_or(ptr %t1273, ptr null)
  %t1275 = call ptr @__olang_region_home(ptr %t1274)
  %t1276 = icmp ne ptr %t1275, null
  %t1277 = select i1 %t1276, ptr %t1275, ptr %t1269
  %t1278 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 0
  %t1279 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1278, i32 0, i32 1
  %t1280 = load { i64, ptr }, ptr %t1279
  %t1281 = extractvalue { i64, ptr } %t1280, 1
  %t1282 = call ptr @__olang_region_or(ptr %t1281, ptr null)
  %t1283 = call ptr @__olang_region_home(ptr %t1282)
  %t1284 = icmp ne ptr %t1283, null
  %t1285 = select i1 %t1284, ptr %t1283, ptr %t1277
  %t1286 = getelementptr %"compiler/typed:RefsKept", ptr %l265, i32 0, i32 0
  %t1287 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1286, i32 0, i32 0
  %t1288 = load { i64, ptr }, ptr %t1287
  %t1289 = extractvalue { i64, ptr } %t1288, 1
  %t1290 = call ptr @__olang_region_or(ptr %t1289, ptr null)
  %t1291 = call ptr @__olang_region_home(ptr %t1290)
  %t1292 = icmp ne ptr %t1291, null
  %t1293 = select i1 %t1292, ptr %t1291, ptr %t1285
  call void @__olang_region_settle_in(ptr %t1197, ptr %t1293)
  br label %bb223
bb223:
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %l265, i64 296, i1 false)
  %t1294 = call ptr @__olang_scope_hold(ptr %v2)
  %t1295 = ptrtoint ptr %t1294 to i64
  store i64 %t1295, ptr %l267, !tbaa !24
  %t1296 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e72
  br i1 %t1296, label %bb224, label %bb225
bb224:
  %t1298 = call ptr @__olang_region_make(ptr %v2)
  %t1299 = ptrtoint ptr %t1298 to i64
  store i64 %t1299, ptr %l267, !tbaa !24
  br label %bb225
bb225:
  %t1300 = load i64, ptr %l267
  %t1301 = inttoptr i64 %t1300 to ptr
  %t1302 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1301)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1302, ptr %l269
  br label %bb226
bb226:
  %t1303 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e72
  br i1 %t1303, label %bb227, label %bb228
bb227:
  %t1305 = load i64, ptr %l267
  %t1306 = inttoptr i64 %t1305 to ptr
  %t1307 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l269, i32 0, i32 2
  %t1308 = load { i64, ptr }, ptr %t1307
  %t1309 = extractvalue { i64, ptr } %t1308, 1
  %t1310 = call ptr @__olang_region_or(ptr %t1309, ptr null)
  %t1311 = call ptr @__olang_region_home(ptr %t1310)
  %t1312 = icmp ne ptr %t1311, null
  %t1313 = select i1 %t1312, ptr %t1311, ptr null
  %t1314 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l269, i32 0, i32 1
  %t1315 = load { i64, ptr }, ptr %t1314
  %t1316 = extractvalue { i64, ptr } %t1315, 1
  %t1317 = call ptr @__olang_region_or(ptr %t1316, ptr null)
  %t1318 = call ptr @__olang_region_home(ptr %t1317)
  %t1319 = icmp ne ptr %t1318, null
  %t1320 = select i1 %t1319, ptr %t1318, ptr %t1313
  %t1321 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l269, i32 0, i32 0
  %t1322 = load { i64, ptr }, ptr %t1321
  %t1323 = extractvalue { i64, ptr } %t1322, 1
  %t1324 = call ptr @__olang_region_or(ptr %t1323, ptr null)
  %t1325 = call ptr @__olang_region_home(ptr %t1324)
  %t1326 = icmp ne ptr %t1325, null
  %t1327 = select i1 %t1326, ptr %t1325, ptr %t1320
  call void @__olang_region_settle_in(ptr %t1306, ptr %t1327)
  br label %bb228
bb228:
  %t1328 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l269
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1328, ptr %l74
  %t1329 = call ptr @__olang_scope_hold(ptr %v2)
  %t1330 = ptrtoint ptr %t1329 to i64
  store i64 %t1330, ptr %l271, !tbaa !24
  %t1331 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e73
  br i1 %t1331, label %bb229, label %bb230
bb229:
  %t1333 = call ptr @__olang_region_make(ptr %v2)
  %t1334 = ptrtoint ptr %t1333 to i64
  store i64 %t1334, ptr %l271, !tbaa !24
  br label %bb230
bb230:
  %t1335 = load i64, ptr %l271
  %t1336 = inttoptr i64 %t1335 to ptr
  %t1337 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t1336, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1337, ptr %l273
  br label %bb231
bb231:
  %t1338 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e73
  br i1 %t1338, label %bb232, label %bb233
bb232:
  %t1340 = load i64, ptr %l271
  %t1341 = inttoptr i64 %t1340 to ptr
  %t1342 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l273, i32 0, i32 0
  %t1343 = load { i64, ptr }, ptr %t1342
  %t1344 = extractvalue { i64, ptr } %t1343, 1
  %t1345 = call ptr @__olang_region_or(ptr %t1344, ptr null)
  %t1346 = call ptr @__olang_region_home(ptr %t1345)
  %t1347 = icmp ne ptr %t1346, null
  %t1348 = select i1 %t1347, ptr %t1346, ptr null
  call void @__olang_region_settle_in(ptr %t1341, ptr %t1348)
  br label %bb233
bb233:
  %t1349 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l273
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1349, ptr %l75
  %t1350 = call ptr @__olang_scope_hold(ptr %v2)
  %t1351 = ptrtoint ptr %t1350 to i64
  store i64 %t1351, ptr %l275, !tbaa !24
  %t1352 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e74
  br i1 %t1352, label %bb234, label %bb235
bb234:
  %t1354 = call ptr @__olang_region_make(ptr %v2)
  %t1355 = ptrtoint ptr %t1354 to i64
  store i64 %t1355, ptr %l275, !tbaa !24
  br label %bb235
bb235:
  %t1356 = load i64, ptr %l275
  %t1357 = inttoptr i64 %t1356 to ptr
  %t1358 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1357)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1358, ptr %l277
  br label %bb236
bb236:
  %t1359 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e74
  br i1 %t1359, label %bb237, label %bb238
bb237:
  %t1361 = load i64, ptr %l275
  %t1362 = inttoptr i64 %t1361 to ptr
  %t1363 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l277, i32 0, i32 2
  %t1364 = load { i64, ptr }, ptr %t1363
  %t1365 = extractvalue { i64, ptr } %t1364, 1
  %t1366 = call ptr @__olang_region_or(ptr %t1365, ptr null)
  %t1367 = call ptr @__olang_region_home(ptr %t1366)
  %t1368 = icmp ne ptr %t1367, null
  %t1369 = select i1 %t1368, ptr %t1367, ptr null
  %t1370 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l277, i32 0, i32 1
  %t1371 = load { i64, ptr }, ptr %t1370
  %t1372 = extractvalue { i64, ptr } %t1371, 1
  %t1373 = call ptr @__olang_region_or(ptr %t1372, ptr null)
  %t1374 = call ptr @__olang_region_home(ptr %t1373)
  %t1375 = icmp ne ptr %t1374, null
  %t1376 = select i1 %t1375, ptr %t1374, ptr %t1369
  %t1377 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l277, i32 0, i32 0
  %t1378 = load { i64, ptr }, ptr %t1377
  %t1379 = extractvalue { i64, ptr } %t1378, 1
  %t1380 = call ptr @__olang_region_or(ptr %t1379, ptr null)
  %t1381 = call ptr @__olang_region_home(ptr %t1380)
  %t1382 = icmp ne ptr %t1381, null
  %t1383 = select i1 %t1382, ptr %t1381, ptr %t1376
  call void @__olang_region_settle_in(ptr %t1362, ptr %t1383)
  br label %bb238
bb238:
  %t1384 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l277
  %t1385 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 0
  %t1386 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1386, ptr %t1385, !tbaa !29
  %t1387 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 1
  %t1388 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1388, ptr %t1387
  %t1389 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 2
  %t1390 = load i1, ptr %l4, !tbaa !21
  store i1 %t1390, ptr %t1389, !tbaa !21
  %t1391 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 3
  %t1392 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1392, ptr %t1391
  %t1393 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 4
  %t1394 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1394, ptr %t1393
  %t1395 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 5
  %t1396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1396, ptr %t1395
  %t1397 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 6
  %t1398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1398, ptr %t1397
  %t1399 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 7
  %t1400 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1400, ptr %t1399
  %t1401 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 8
  %t1402 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1402, ptr %t1401
  %t1403 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 9
  %t1404 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1404, ptr %t1403
  %t1405 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 10
  %t1406 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1406, ptr %t1405
  %t1407 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 11
  %t1408 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1408, ptr %t1407
  %t1409 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 12
  %t1410 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1410, ptr %t1409
  %t1411 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 13
  %t1412 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1412, ptr %t1411
  %t1413 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 14
  %t1414 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1414, ptr %t1413
  %t1415 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 15
  %t1416 = load i64, ptr %l17, !tbaa !24
  store i64 %t1416, ptr %t1415, !tbaa !24
  %t1417 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 16
  %t1418 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1418, ptr %t1417
  %t1419 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 17
  %t1420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1420, ptr %t1419
  %t1421 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 18
  %t1422 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1422, ptr %t1421
  %t1423 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 19
  %t1424 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1424, ptr %t1423
  %t1425 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 20
  %t1426 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1426, ptr %t1425
  %t1427 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 21
  %t1428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1428, ptr %t1427
  %t1429 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 22
  %t1430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1430, ptr %t1429
  %t1431 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 23
  %t1432 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1432, ptr %t1431
  %t1433 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 24
  %t1434 = load i64, ptr %l26, !tbaa !24
  store i64 %t1434, ptr %t1433, !tbaa !24
  %t1435 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 25
  %t1436 = load %"compiler/effects:Facts", ptr %l27
  store %"compiler/effects:Facts" %t1436, ptr %t1435
  %t1437 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 26
  %t1438 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1438, ptr %t1437
  %t1439 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 27
  %t1440 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1440, ptr %t1439
  %t1441 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 28
  %t1442 = load i64, ptr %l30, !tbaa !24
  store i64 %t1442, ptr %t1441, !tbaa !24
  %t1443 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 29
  %t1444 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1444, ptr %t1443
  %t1445 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 30
  %t1446 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1446, ptr %t1445
  %t1447 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 31
  %t1448 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1448, ptr %t1447
  %t1449 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 32
  %t1450 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1450, ptr %t1449
  %t1451 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 33
  %t1452 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1452, ptr %t1451
  %t1453 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 34
  %t1454 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1454, ptr %t1453
  %t1455 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 35
  %t1456 = load i64, ptr %l37, !tbaa !24
  store i64 %t1456, ptr %t1455, !tbaa !24
  %t1457 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 36
  %t1458 = load i64, ptr %l38, !tbaa !24
  store i64 %t1458, ptr %t1457, !tbaa !24
  %t1459 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 37
  %t1460 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1460, ptr %t1459
  %t1461 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 38
  %t1462 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1462, ptr %t1461
  %t1463 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 39
  %t1464 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1464, ptr %t1463
  %t1465 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 40
  %t1466 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1466, ptr %t1465
  %t1467 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 41
  %t1468 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1468, ptr %t1467
  %t1469 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 42
  %t1470 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1470, ptr %t1469
  %t1471 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 43
  %t1472 = load i1, ptr %l45, !tbaa !21
  store i1 %t1472, ptr %t1471, !tbaa !21
  %t1473 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 44
  %t1474 = load i1, ptr %l46, !tbaa !21
  store i1 %t1474, ptr %t1473, !tbaa !21
  %t1475 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 45
  %t1476 = load i1, ptr %l47, !tbaa !21
  store i1 %t1476, ptr %t1475, !tbaa !21
  %t1477 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 46
  %t1478 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1478, ptr %t1477
  %t1479 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 47
  %t1480 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1480, ptr %t1479
  %t1481 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 48
  %t1482 = load i1, ptr %l50, !tbaa !21
  store i1 %t1482, ptr %t1481, !tbaa !21
  %t1483 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 49
  %t1484 = load i64, ptr %l51, !tbaa !24
  store i64 %t1484, ptr %t1483, !tbaa !24
  %t1485 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 50
  %t1486 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1486, ptr %t1485, !tbaa !27
  %t1487 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 51
  %t1488 = load i1, ptr %l53, !tbaa !21
  store i1 %t1488, ptr %t1487, !tbaa !21
  %t1489 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 52
  %t1490 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t1490, ptr %t1489
  %t1491 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 53
  %t1492 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t1492, ptr %t1491, !tbaa !27
  %t1493 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 54
  %t1494 = load i1, ptr %l56, !tbaa !21
  store i1 %t1494, ptr %t1493, !tbaa !21
  %t1495 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 55
  %t1496 = load i64, ptr %l57, !tbaa !24
  store i64 %t1496, ptr %t1495, !tbaa !24
  %t1497 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 56
  %t1498 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1498, ptr %t1497
  %t1499 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 57
  %t1500 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l59
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1500, ptr %t1499
  %t1501 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 58
  %t1502 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1502, ptr %t1501
  %t1503 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 59
  %t1504 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1504, ptr %t1503
  %t1505 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 60
  %t1506 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1506, ptr %t1505
  %t1507 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 61
  %t1508 = load i1, ptr %l63, !tbaa !21
  store i1 %t1508, ptr %t1507, !tbaa !21
  %t1509 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 62
  %t1510 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l64
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1510, ptr %t1509
  %t1511 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 63
  %t1512 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1512, ptr %t1511
  %t1513 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 64
  %t1514 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1514, ptr %t1513
  %t1515 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 65
  %t1516 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l67
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1516, ptr %t1515
  %t1517 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 66
  %t1518 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1518, ptr %t1517
  %t1519 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 67
  %t1520 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l69
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1520, ptr %t1519
  %t1521 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 68
  %t1522 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l70
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1522, ptr %t1521
  %t1523 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 69
  %t1524 = load i1, ptr %l71, !tbaa !21
  store i1 %t1524, ptr %t1523, !tbaa !21
  %t1525 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 70
  %t1526 = load i1, ptr %l72, !tbaa !21
  store i1 %t1526, ptr %t1525, !tbaa !21
  %t1527 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 71
  call void @llvm.memmove.p0.p0.i64(ptr %t1527, ptr %l73, i64 296, i1 false)
  %t1528 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 72
  %t1529 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l74
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1529, ptr %t1528
  %t1530 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 73
  %t1531 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1531, ptr %t1530
  %t1532 = getelementptr %"compiler/effects:Effects", ptr %l279, i32 0, i32 74
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1384, ptr %t1532
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l279, i64 3136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:fpath" @compiler_2feffects_3afpath_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:fpath"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:fpath" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t8 = insertvalue %"compiler/effects:fpath" %t6, i32 %a1, 1
  store %"compiler/effects:fpath" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fpath", ptr %rv
  ret %"compiler/effects:fpath" %rr
}

define dso_local %"compiler/effects:fret" @compiler_2feffects_3afret_2ector(ptr %v0, ptr %v1, ptr %v2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:fret"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:fret" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t8 = insertvalue %"compiler/effects:fret" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  store %"compiler/effects:fret" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fret", ptr %rv
  ret %"compiler/effects:fret" %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d3 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"not known - it reaches code that did not check" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"anything - it calls C, which may call the program's export fns" }>, align 8
@.d5 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"anything - it calls through a function value or an 'any'" }>, align 8
@.d6 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"none - it may be computed while compiling where its arguments are known" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d11 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"writes through " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d15 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"calls through " }>, align 8
@.d16 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"writes a global" }>, align 8
@.d17 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"allocates" }>, align 8
@.d18 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"allocates only where it fails" }>, align 8
@.d19 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"allocates nothing" }>, align 8
@.d20 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"may grow a Vec" }>, align 8
@.d21 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"starts tasks" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"calls C" }>, align 8
@.d24 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"may end the program" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"may block" }>, align 8
@.d26 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"never blocks" }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"recursive" }>, align 8
@.d28 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"always ends" }>, align 8
@.d29 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"may be computed while compiling" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2ecompiler_2feffects_3apart_2e4 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2farray_3aArrayIter_3cI64_3e_2e0 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:part"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:part"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:part", ptr %a0
  store %"compiler/effects:part" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:part", ptr %l1
  store %"compiler/effects:part" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

@olang_2esole_2ecompiler_2feffects_3agiven_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3apend_2e3 = weak hidden constant i1 false
define linkonce_odr %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fslot"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fslot"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fslot", ptr %a0
  store %"compiler/effects:fslot" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fslot", ptr %l1
  store %"compiler/effects:fslot" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fslot", ptr %rv
  ret %"compiler/effects:fslot" %rr
}

@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e29 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler_2feffects_3afpath_2e0 = weak hidden constant i1 false
define linkonce_odr %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fpath"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fpath"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fpath", ptr %a0
  store %"compiler/effects:fpath" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fpath", ptr %l1
  store %"compiler/effects:fpath" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fpath", ptr %rv
  ret %"compiler/effects:fpath" %rr
}

@.d33 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"call through" }>, align 8
@.d34 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"it calls through a function value here, and what that calls is not followed" }>, align 8
@.d35 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"its call through this function value may " }>, align 8
define linkonce_odr %"compiler/effects:fret" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afret(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fret"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fret"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fret", ptr %a0
  store %"compiler/effects:fret" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fret", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fret", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/effects:fret", ptr %l1, i32 0, i32 1
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/effects:fret", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = load %"compiler/effects:fret", ptr %l1
  store %"compiler/effects:fret" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fret", ptr %rv
  ret %"compiler/effects:fret" %rr
}

@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its call of " }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" may " }>, align 8
@.d39 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"it may " }>, align 8
@.d40 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" here" }>, align 8
@.d41 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"; recursive" }>, align 8
@.d42 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"; always ends" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"call through a function value it does not follow, which may not come back" }>, align 8
@.d45 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call itself" }>, align 8
@.d46 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"loop with no count known before the loop starts" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"block" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"end the program" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aEffects_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e9 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_Hbea44694f2ac293c111b1f169c7495eb(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e10 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e18 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e19 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e26 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e31 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e32 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e34 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H3227b03907400d34f4865c02b6d98850(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e40 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e41 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e42 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e47 = weak hidden constant i1 false
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aEffects_2e56 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e57 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e58 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e59 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e60 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e62 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e63 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hfe0b8a6431726c879f98e5933eafeded(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cc_Had198c5ef8f3129624d068a2c584611b(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e64 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_Hdcf598faa391f42f17ca4d3159c68b14(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H2f96a66e37bdd4e6ba26b25615641feb(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e67 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e68 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e71 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2ftyped_3aRefsKept(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/typed:RefsKept"
  %t1 = alloca %"compiler/typed:RefsKept", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftyped_3aRefsKept_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 296, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e72 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e73 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e74 = weak hidden constant i1 false
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:given"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 80
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:given", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %t15)
  store %"compiler/effects:given" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:given", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:given", ptr %t22, i64 %t20
  store %"compiler/effects:given" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 72
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:part", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %t15)
  store %"compiler/effects:part" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:part", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:part", ptr %t22, i64 %t20
  store %"compiler/effects:part" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fpath"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fpath", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %t15)
  store %"compiler/effects:fpath" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fpath", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fpath", ptr %t22, i64 %t20
  store %"compiler/effects:fpath" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:given"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:given"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:given", ptr %a0
  store %"compiler/effects:given" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:given", ptr %l1
  store %"compiler/effects:given" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:given", ptr %rv
  ret %"compiler/effects:given" %rr
}

declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2feffects_2eCapCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2feffects_2eCapName(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2feffects_2ehasBit(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %a0)
declare %"compiler/effects:link" @compiler_2feffects_3alink_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ePush_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, %"compiler/effects:link" %a1)
@G_2ecompiler_2feffects_2eglobalParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ectorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2feffects_2eoutParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_650dda860f99b242_5ce1da2dd4f47486 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4055e0fe87b920f9_59f1ceb8b6607d = external constant [0 x i8]
@G_2ecompiler_2feffects_2eCapC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecap(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:pend" %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1bc29689bbb58e32_9924d9acc7f0abd6 = external constant [0 x i8]
@G_2ecompiler_2feffects_2eGivBound = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i32 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:part" %a1)
@olang_loc_b51fd4885ec92e5_d8c1bbe4cc347d79 = external constant [0 x i8]
@olang_loc_488be308cffaf13e_20c0e7cb8e30f352 = external constant [0 x i8]
@olang_loc_59fe423ba48f95ef_125e5ca5a1678c93 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2feffects_2eGivMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eGivResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_8e13f40ea2f1e4d7_76f885d7d8afa3eb = external constant [0 x i8]
@olang_loc_2b1992bc034d4ac0_3aae813f6df6734c = external constant [0 x i8]
@olang_loc_46f184d5298e32c_10b291f73bcbacf0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivResField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eFieldDepth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efixed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3535a9392f714f10_e154cce5335d35ec = external constant [0 x i8]
@olang_loc_7a6d7e31a8c94555_e5f55f7e2b9f5a99 = external constant [0 x i8]
@olang_loc_ac8d93ad38a597bd_9a80442872e097e1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feffects_2eGivSlot = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:coldMark" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldOpen(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldClose(ptr %v0, ptr %a0, %"compiler/effects:coldMark" %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evalueArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewidened(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3b1aba267d3808f9_9a4444fd59d95fdd = external constant [0 x i8]
@olang_loc_76dfd6b01352a9c1_3e5307bd9b690f5 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hb5dd413d586c55d7ccefa7dbc5ad43c5(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivNamed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallEdge(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2feffects_2eparamBit(i64 %a0)
declare %"compiler/effects:given" @compiler_2feffects_3agiven_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i32 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2feffects_2ePartLambda = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2ePartAdapter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_e33fbd58e0454875_653468874e31cf21 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @compiler_2feffects_2eBreaks(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
@olang_loc_9b481a3036e75930_9f21b77026d49cd4 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eoutLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\FC\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eOwnSlot(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
@olang_loc_89d258cb45db8a97_6792eaa695d1effb = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hf6a5697b694481c39cb93e062458012f(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H7002a026c084e9a7d52910b10cae7157(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H23909c0b6cdd8c6a8e8461d347ccf8af(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2ePush_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:fpath" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyNow(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ePush_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:given" %a1)
declare { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyDoes(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebecause(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8f0e2357f3b9767c_69d91ea023337680 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_2ePush_3ccompiler_2feffects_3afret_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:fret" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc7f0d5e54ac63fdc8f930fd93d6364c9(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b872ac5dc3b5cbc5_c1669fe863d2e49 = external constant [0 x i8]
@olang_loc_7fc479e7b96e92ad_adfc96c825376791 = external constant [0 x i8]
@olang_loc_edb5a1ac978d0996_7c7124734c9b85fa = external constant [0 x i8]
@olang_loc_83ffd618ff536982_5c02ec347c68c506 = external constant [0 x i8]
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2feffects_2eCapThreads = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cdd9fd819eb1314_592489ef7c054390 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2enamed(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_83cd05edfd6dbdc2_ee5ceab4d3ae0c56 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_d8bf60be8d53266c_65df02eeff1797b0 = external constant [0 x i8]
@olang_loc_bef23b7223d78d87_3941411f391512b = external constant [0 x i8]
@olang_loc_f9d1419be2a6bd97_a466df32bbf19e6b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cc_Had198c5ef8f3129624d068a2c584611b(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afret_3e_3e_2ector(ptr %v0)
declare void @compiler_2ftyped_3aRefsKept_2ector(ptr %out, ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
