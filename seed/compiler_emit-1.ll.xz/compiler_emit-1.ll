; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr } }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
define dso_local void @compiler_2femit_2ePartSizeDev_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 524288, ptr @G_2ecompiler_2femit_2ePartSizeDev, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t5 = sext i32 %a0 to i64
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t5)
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t5)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %s1, ptr %t5)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l11, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t12)
  store i64 %t14, ptr %l13
  br label %bb4
bb4:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb24
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l18
  br label %bb8
bb8:
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 1
  %t36 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t32, i64 %t26)
  store ptr %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Body", ptr %t37, i32 0, i32 1
  %t40 = load { i64, [2 x i64] }, ptr %t39
  store { i64, [2 x i64] } %t40, ptr %l5
  %t42 = load { i64, [2 x i64] }, ptr %l5
  %t44 = extractvalue { i64, [2 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  store i64 %t49, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t51 = load ptr, ptr %lp1
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/emit:Emitter", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/emit:Emitter", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l36
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t65, i64 %t66)
  store ptr %t67, ptr %l37
  br label %bb14
bb14:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load ptr, ptr %l30, !tbaa !29
  %t74 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t72, i32 %t71)
  store { i64, ptr } %t74, ptr %l40
  br label %bb15
bb15:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t76, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } %t80, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t88 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t88, { i64, ptr } %t87)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b7cf39b9bc6342b8_b5524b9e4a088564)
  unreachable
bb22:
  br label %bb23
bb23:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l3, !tbaa !24
  br label %bb3
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t94 = load ptr, ptr %lp1
  %t95 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t94
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/emit:Reused"
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/emit:Reused"
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %lp32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/emit:Object"
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca i64
  %l86 = alloca i64
  %l91 = alloca i64
  %l98 = alloca i32
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %l134 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l144 = alloca i64
  %l148 = alloca { i64, ptr }
  %l155 = alloca i64
  %l157 = alloca i64
  %l162 = alloca %"compiler/emit:Reused"
  %l166 = alloca i1
  %l174 = alloca i1
  %l181 = alloca i64
  %l183 = alloca i64
  %l188 = alloca %"compiler/emit:Reused"
  %l192 = alloca i1
  %l193 = alloca i1
  %l202 = alloca i1
  %l205 = alloca i1
  %l213 = alloca i64
  %l217 = alloca i64
  %l220 = alloca i64
  %l241 = alloca i64
  %l245 = alloca i64
  %l246 = alloca i32
  %l251 = alloca ptr
  %l257 = alloca %"compiler/emit:Object"
  %l263 = alloca i1
  %l265 = alloca %"compiler/emit:Reused"
  %l269 = alloca ptr
  %l271 = alloca i64
  %l274 = alloca i64
  %l278 = alloca i64
  %l281 = alloca i64
  %l302 = alloca i64
  %l305 = alloca ptr
  %l306 = alloca i64
  %l310 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l316 = alloca ptr
  %l319 = alloca ptr
  %l332 = alloca i64
  %l336 = alloca i64
  %l339 = alloca i64
  %l358 = alloca ptr
  %l361 = alloca %"compiler/emit:Object"
  %l366 = alloca ptr
  %l369 = alloca %"compiler/emit:Object"
  %l383 = alloca i64
  %l385 = alloca i64
  %l390 = alloca i64
  %l393 = alloca ptr
  %l395 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %l402 = alloca ptr
  %l417 = alloca ptr
  %l418 = alloca ptr
  %l421 = alloca ptr
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l51
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  %t6 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 5
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l2
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 7
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:Emitter", ptr %t29, i32 0, i32 38
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 5
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb4:
  br label %bb13
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %lp1
  store ptr %t43, ptr %l66, !tbaa !29
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t44)
  store ptr %t47, ptr %l69
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l69, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 2
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l73, !tbaa !27
  store i32 0, ptr %l74
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l3, !tbaa !24
  %t69 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t65, i64 %t66, i1 true, i64 0, i64 1, ptr null, i64 -1, ptr null, i64 -1)
  store { i64, ptr } %t69, ptr %l77
  br label %bb10
bb10:
  %t70 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t78 = load i32, ptr %l74
  %t80 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t77, i32 %t78, { i64, ptr } %t76)
  store %"compiler/emit:Object" %t80, ptr %l79
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l66, !tbaa !29
  %t82 = load %"compiler/emit:Object", ptr %l79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t81, %"compiler/emit:Object" %t82)
  br label %bb12
bb12:
  %t83 = load ptr, ptr %lp1
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t83
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %rv
  br label %ret
bb13:
  %t86 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l81
  br label %bb14
bb14:
  %t87 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l4
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/emit:Emitter", ptr %t88, i32 0, i32 17
  store ptr %t90, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t92 = load i64, ptr %l6, !tbaa !24
  store i64 %t92, ptr %l84, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l86
  br label %bb16
bb16:
  %t96 = load i64, ptr %l84, !tbaa !24
  %t97 = load i64, ptr %l86, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l91
  br label %bb20
bb20:
  %t107 = load i64, ptr %l91, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t107, i1 true)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb15
bb23:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %t115, i32 0, i32 4
  %t118 = load i1, ptr %t117, !tbaa !21
  br i1 %t118, label %bb24, label %bb25
bb24:
  store i32 2, ptr %l98
  br label %bb26
bb25:
  store i32 1, ptr %l98
  br label %bb26
bb26:
  %t122 = load i32, ptr %l98
  store i32 %t122, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/emit:Emitter", ptr %t123, i32 0, i32 15
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t125)
  store i64 %t127, ptr %l103
  br label %bb27
bb27:
  %t128 = load i64, ptr %l103, !tbaa !24
  store i64 %t128, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb28, label %bb29
bb28:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb33
bb30:
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l12, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l110, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb32
bb32:
  %t155 = load i64, ptr %l110, !tbaa !24
  store i64 %t155, ptr %l107, !tbaa !24
  br label %bb33
bb33:
  %t156 = load i64, ptr %l107, !tbaa !24
  store i64 %t156, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  store i64 %t173, ptr %l15, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %t175, i32 0, i32 17
  %t178 = load i64, ptr %l15, !tbaa !24
  %t181 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t177, i64 %t178)
  store i64 %t181, ptr %l131
  br label %bb38
bb38:
  %t182 = load i64, ptr %l131, !tbaa !24
  store i64 %t182, ptr %l16, !tbaa !24
  %t183 = load i64, ptr %l16, !tbaa !24
  %t185 = icmp sge i64 %t183, 0
  br i1 %t185, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb41
bb40:
  %t187 = load i64, ptr %l16, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  store i1 %t191, ptr %l134, !tbaa !21
  br label %bb41
bb41:
  %t193 = load i1, ptr %l134, !tbaa !21
  br i1 %t193, label %bb42, label %bb43
bb42:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/emit:Emitter", ptr %t194, i32 0, i32 61
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t196, i64 %t197)
  store i1 %t200, ptr %l142
  br label %bb44
bb43:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb45
bb44:
  %t201 = load i1, ptr %l142, !tbaa !21
  %t202 = xor i1 %t201, true
  store i1 %t202, ptr %l138, !tbaa !21
  br label %bb45
bb45:
  %t204 = load i1, ptr %l138, !tbaa !21
  br i1 %t204, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t205 = load i64, ptr %l9, !tbaa !24
  store i64 %t205, ptr %l144, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/emit:Emitter", ptr %t206, i32 0, i32 16
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s9, ptr %t208, i64 %t209)
  store { i64, ptr } %t212, ptr %l148
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t213 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  %t215 = load i64, ptr %l144, !tbaa !24
  %t217 = add i64 %t215, %t214
  store i64 %t217, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l14, !tbaa !24
  br label %bb34
bb51:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/emit:Emitter", ptr %t223, i32 0, i32 60
  store ptr %t225, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb52
bb52:
  %t227 = load i64, ptr %l18, !tbaa !24
  store i64 %t227, ptr %l155, !tbaa !24
  %t228 = load ptr, ptr %l17, !tbaa !29
  %t230 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t228)
  store i64 %t230, ptr %l157
  br label %bb53
bb53:
  %t231 = load i64, ptr %l155, !tbaa !24
  %t232 = load i64, ptr %l157, !tbaa !24
  %t233 = icmp slt i64 %t231, %t232
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb54, label %bb55
bb54:
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t237 = load ptr, ptr %l17, !tbaa !29
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = call %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t237, i64 %t238)
  store %"compiler/emit:Reused" %t241, ptr %l162
  br label %bb57
bb57:
  %t242 = load %"compiler/emit:Reused", ptr %l162
  store %"compiler/emit:Reused" %t242, ptr %l19
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/emit:Emitter", ptr %t243, i32 0, i32 61
  %t246 = getelementptr %"compiler/emit:Reused", ptr %l19, i32 0, i32 0
  %t247 = load i64, ptr %t246, !tbaa !24
  %t250 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t245, i64 %t247)
  store i1 %t250, ptr %l166
  br label %bb58
bb58:
  %t251 = load i1, ptr %l166, !tbaa !21
  br i1 %t251, label %bb59, label %bb60
bb59:
  %t252 = load i64, ptr %l9, !tbaa !24
  %t253 = getelementptr %"compiler/emit:Reused", ptr %l19, i32 0, i32 4
  %t254 = load i64, ptr %t253, !tbaa !24
  %t257 = add i64 %t252, %t254
  store i64 %t257, ptr %l9, !tbaa !24
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t259 = load i64, ptr %l18, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l18, !tbaa !24
  br label %bb52
bb63:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:Emitter", ptr %t263, i32 0, i32 5
  %t266 = load i1, ptr %t265, !tbaa !21
  br i1 %t266, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb66
bb65:
  %t268 = load i64, ptr %l9, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/emit:Emitter", ptr %t269, i32 0, i32 39
  %t272 = load i64, ptr %t271, !tbaa !24
  %t275 = icmp sge i64 %t268, %t272
  store i1 %t275, ptr %l174, !tbaa !21
  br label %bb66
bb66:
  %t277 = load i1, ptr %l174, !tbaa !21
  store i1 %t277, ptr %l20, !tbaa !21
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/emit:Emitter", ptr %t278, i32 0, i32 60
  store ptr %t280, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb67
bb67:
  %t282 = load i64, ptr %l22, !tbaa !24
  store i64 %t282, ptr %l181, !tbaa !24
  %t283 = load ptr, ptr %l21, !tbaa !29
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t283)
  store i64 %t285, ptr %l183
  br label %bb68
bb68:
  %t286 = load i64, ptr %l181, !tbaa !24
  %t287 = load i64, ptr %l183, !tbaa !24
  %t288 = icmp slt i64 %t286, %t287
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb69, label %bb70
bb69:
  br label %bb81
bb70:
  br label %bb71
bb71:
  %t292 = load ptr, ptr %l21, !tbaa !29
  %t293 = load i64, ptr %l22, !tbaa !24
  %t296 = call %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t292, i64 %t293)
  store %"compiler/emit:Reused" %t296, ptr %l188
  br label %bb72
bb72:
  %t297 = load %"compiler/emit:Reused", ptr %l188
  store %"compiler/emit:Reused" %t297, ptr %l23
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/emit:Emitter", ptr %t298, i32 0, i32 61
  %t301 = getelementptr %"compiler/emit:Reused", ptr %l23, i32 0, i32 0
  %t302 = load i64, ptr %t301, !tbaa !24
  %t305 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t300, i64 %t302)
  store i1 %t305, ptr %l192
  br label %bb73
bb73:
  %t306 = load i1, ptr %l192, !tbaa !21
  br i1 %t306, label %bb74, label %bb75
bb74:
  %t307 = getelementptr %"compiler/emit:Reused", ptr %l23, i32 0, i32 5
  %t308 = load i1, ptr %t307, !tbaa !21
  %t309 = load i1, ptr %l20, !tbaa !21
  %t312 = icmp ne i1 %t308, %t309
  store i1 %t312, ptr %l193, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb76
bb76:
  %t314 = load i1, ptr %l193, !tbaa !21
  br i1 %t314, label %bb77, label %bb78
bb77:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/emit:Emitter", ptr %t315, i32 0, i32 63
  store i1 true, ptr %t317, !tbaa !21
  %t318 = load ptr, ptr %lp1
  %t319 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t318
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t319, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t321 = load i64, ptr %l22, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb67
bb81:
  %t325 = load i1, ptr %l20, !tbaa !21
  br i1 %t325, label %bb82, label %bb83
bb82:
  %t327 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t330 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t327)
  store i1 %t330, ptr %l205
  br label %bb84
bb83:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb85
bb84:
  %t331 = load i1, ptr %l205, !tbaa !21
  store i1 %t331, ptr %l202, !tbaa !21
  br label %bb85
bb85:
  %t332 = load i1, ptr %l202, !tbaa !21
  store i1 %t332, ptr %l24, !tbaa !21
  %t333 = load i1, ptr %l24, !tbaa !21
  br i1 %t333, label %bb86, label %bb87
bb86:
  %t335 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroups(ptr %v0, ptr %t335)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/emit:Emitter", ptr %t337, i32 0, i32 5
  %t340 = load i1, ptr %t339, !tbaa !21
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb90, label %bb91
bb90:
  %t344 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %t344)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  store i64 0, ptr %l25, !tbaa !24
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %l2)
  store i64 %t347, ptr %l213
  br label %bb94
bb94:
  %t348 = load i64, ptr %l213, !tbaa !24
  store i64 %t348, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t349 = load i64, ptr %l26, !tbaa !24
  %t350 = load i64, ptr %l25, !tbaa !24
  %t353 = icmp sgt i64 %t349, %t350
  br i1 %t353, label %bb95, label %bb96
bb95:
  %t355 = load i64, ptr %l27, !tbaa !24
  %t357 = icmp sgt i64 %t355, 0
  br i1 %t357, label %bb97, label %bb98
bb96:
  store i64 0, ptr %l217, !tbaa !24
  br label %bb100
bb97:
  %t359 = load i64, ptr %l26, !tbaa !24
  %t360 = load i64, ptr %l25, !tbaa !24
  %t363 = sub i64 %t359, %t360
  %t364 = load i64, ptr %l27, !tbaa !24
  %t367 = add i64 %t363, %t364
  %t369 = sub i64 %t367, 1
  %t370 = load i64, ptr %l27, !tbaa !24
  %t373 = sdiv i64 %t369, %t370
  store i64 %t373, ptr %l220, !tbaa !24
  br label %bb99
bb98:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb99
bb99:
  %t375 = load i64, ptr %l220, !tbaa !24
  store i64 %t375, ptr %l217, !tbaa !24
  br label %bb100
bb100:
  %t376 = load i64, ptr %l217, !tbaa !24
  store i64 %t376, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb101
bb101:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t378 = load i64, ptr %l28, !tbaa !24
  %t381 = icmp slt i64 %t377, %t378
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb102, label %bb103
bb102:
  br label %bb163
bb103:
  br label %bb104
bb104:
  %t385 = load i64, ptr %l25, !tbaa !24
  %t386 = load i64, ptr %l29, !tbaa !24
  %t387 = load i64, ptr %l27, !tbaa !24
  %t390 = mul i64 %t386, %t387
  %t393 = add i64 %t385, %t390
  store i64 %t393, ptr %l30, !tbaa !24
  %t395 = load i64, ptr %l30, !tbaa !24
  %t396 = load i64, ptr %l3, !tbaa !24
  %t399 = icmp eq i64 %t395, %t396
  br i1 %t399, label %bb105, label %bb106
bb105:
  br label %bb162
bb106:
  br label %bb107
bb107:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/emit:Emitter", ptr %t401, i32 0, i32 61
  %t404 = load i64, ptr %l30, !tbaa !24
  %t407 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t403, i64 %t404)
  %t408 = extractvalue { i32, i64 } %t407, 1
  %t409 = extractvalue { i32, i64 } %t407, 0
  store i32 %t409, ptr %l246
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb109, label %ok.411
ok.411:
  store i64 %t408, ptr %l245
  br label %bb108
bb108:
  %t412 = load i64, ptr %l245, !tbaa !24
  store i64 %t412, ptr %l241, !tbaa !24
  br label %bb111
bb109:
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l241, !tbaa !24
  br label %bb111
bb111:
  %t413 = load i64, ptr %l241, !tbaa !24
  store i64 %t413, ptr %l31, !tbaa !24
  %t414 = load i64, ptr %l31, !tbaa !24
  %t416 = icmp sge i64 %t414, 0
  br i1 %t416, label %bb112, label %bb113
bb112:
  %t418 = load i64, ptr %l30, !tbaa !24
  %t421 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t418)
  store ptr %t421, ptr %l251
  br label %bb114
bb113:
  %t422 = load i64, ptr %l30, !tbaa !24
  %t425 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t422)
  store i1 %t425, ptr %l263
  br label %bb117
bb114:
  %t426 = load ptr, ptr %l251, !tbaa !29
  %t428 = getelementptr %"compiler/load:Module", ptr %t426, i32 0, i32 2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t429, 1
  %t432 = extractvalue { i64, ptr } %t429, 0
  %t433 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t432)
  call void @olang_textcopy(ptr %t433, ptr %t431, i64 %t432)
  %t434 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t433, 1
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } %t435, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  %t445 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t442, i32 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store %"compiler/emit:Object" %t445, ptr %l257
  br label %bb115
bb115:
  %t446 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t446, ptr %lp32
  %t447 = load %"compiler/emit:Object", ptr %l257
  %t448 = load ptr, ptr %lp32
  store %"compiler/emit:Object" %t447, ptr %t448
  %t449 = load i64, ptr %l31, !tbaa !24
  %t451 = load ptr, ptr %lp32
  %t452 = getelementptr %"compiler/emit:Object", ptr %t451, i32 0, i32 3
  store i64 %t449, ptr %t452, !tbaa !24
  %t453 = load ptr, ptr %lp1
  %t454 = load ptr, ptr %lp32
  %t455 = load %"compiler/emit:Object", ptr %t454
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t453, %"compiler/emit:Object" %t455)
  br label %bb116
bb116:
  br label %bb161
bb117:
  %t458 = load i1, ptr %l263, !tbaa !21
  br i1 %t458, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s27
  %t459 = load i64, ptr %l30, !tbaa !24
  %t461 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %t459)
  store %"compiler/emit:Reused" %t461, ptr %l265
  br label %bb120
bb119:
  br label %bb160
bb120:
  %t462 = load %"compiler/emit:Reused", ptr %l265
  %t463 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/emit:Reused" %t462, ptr %t463
  store ptr %t463, ptr %l33, !tbaa !29
  %t465 = load ptr, ptr %l33, !tbaa !29
  %t466 = load i1, ptr %l20, !tbaa !21
  %t469 = getelementptr %"compiler/emit:Reused", ptr %t465, i32 0, i32 5
  store i1 %t466, ptr %t469, !tbaa !21
  %t470 = load ptr, ptr %l33, !tbaa !29
  store ptr %t470, ptr %l269, !tbaa !29
  %t471 = load ptr, ptr %lp1
  %t473 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %t471)
  store i64 %t473, ptr %l271
  br label %bb121
bb121:
  %t474 = load i64, ptr %l271, !tbaa !24
  %t475 = load ptr, ptr %l269, !tbaa !29
  %t476 = getelementptr %"compiler/emit:Reused", ptr %t475, i32 0, i32 7
  store i64 %t474, ptr %t476, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/emit:Emitter", ptr %t477, i32 0, i32 15
  %t481 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t479)
  store i64 %t481, ptr %l274
  br label %bb122
bb122:
  %t482 = load i64, ptr %l274, !tbaa !24
  store i64 %t482, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t483 = load i64, ptr %l35, !tbaa !24
  %t484 = load i64, ptr %l34, !tbaa !24
  %t487 = icmp sgt i64 %t483, %t484
  br i1 %t487, label %bb123, label %bb124
bb123:
  %t489 = load i64, ptr %l36, !tbaa !24
  %t491 = icmp sgt i64 %t489, 0
  br i1 %t491, label %bb125, label %bb126
bb124:
  store i64 0, ptr %l278, !tbaa !24
  br label %bb128
bb125:
  %t493 = load i64, ptr %l35, !tbaa !24
  %t494 = load i64, ptr %l34, !tbaa !24
  %t497 = sub i64 %t493, %t494
  %t498 = load i64, ptr %l36, !tbaa !24
  %t501 = add i64 %t497, %t498
  %t503 = sub i64 %t501, 1
  %t504 = load i64, ptr %l36, !tbaa !24
  %t507 = sdiv i64 %t503, %t504
  store i64 %t507, ptr %l281, !tbaa !24
  br label %bb127
bb126:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb127
bb127:
  %t509 = load i64, ptr %l281, !tbaa !24
  store i64 %t509, ptr %l278, !tbaa !24
  br label %bb128
bb128:
  %t510 = load i64, ptr %l278, !tbaa !24
  store i64 %t510, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb129
bb129:
  %t511 = load i64, ptr %l38, !tbaa !24
  %t512 = load i64, ptr %l37, !tbaa !24
  %t515 = icmp slt i64 %t511, %t512
  %t517 = xor i1 %t515, true
  br i1 %t517, label %bb130, label %bb131
bb130:
  br label %bb139
bb131:
  br label %bb132
bb132:
  %t519 = load i64, ptr %l34, !tbaa !24
  %t520 = load i64, ptr %l38, !tbaa !24
  %t521 = load i64, ptr %l36, !tbaa !24
  %t524 = mul i64 %t520, %t521
  %t527 = add i64 %t519, %t524
  store i64 %t527, ptr %l39, !tbaa !24
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/emit:Emitter", ptr %t529, i32 0, i32 17
  %t532 = load i64, ptr %l39, !tbaa !24
  %t535 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t531, i64 %t532)
  store i64 %t535, ptr %l302
  br label %bb133
bb133:
  %t536 = load i64, ptr %l30, !tbaa !24
  %t537 = load i64, ptr %l302, !tbaa !24
  %t539 = icmp eq i64 %t537, %t536
  br i1 %t539, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s30
  %t541 = load ptr, ptr %l33, !tbaa !29
  store ptr %t541, ptr %l305, !tbaa !29
  %t542 = load ptr, ptr %l305, !tbaa !29
  %t543 = getelementptr %"compiler/emit:Reused", ptr %t542, i32 0, i32 4
  %t544 = load i64, ptr %t543, !tbaa !24
  store i64 %t544, ptr %l306, !tbaa !24
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:Emitter", ptr %t545, i32 0, i32 16
  %t548 = load i64, ptr %l39, !tbaa !24
  %t551 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s30, ptr %t547, i64 %t548)
  store { i64, ptr } %t551, ptr %l310
  br label %bb136
bb135:
  br label %bb137
bb136:
  %t552 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t552, 0
  %t554 = load i64, ptr %l306, !tbaa !24
  %t556 = add i64 %t554, %t553
  %t558 = load ptr, ptr %l305, !tbaa !29
  %t559 = getelementptr %"compiler/emit:Reused", ptr %t558, i32 0, i32 4
  store i64 %t556, ptr %t559, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb137
bb137:
  br label %bb138
bb138:
  %t560 = load i64, ptr %l38, !tbaa !24
  %t562 = add i64 %t560, 1
  store i64 %t562, ptr %l38, !tbaa !24
  br label %bb129
bb139:
  %t564 = load ptr, ptr %l0, !tbaa !29
  store ptr %t564, ptr %l315, !tbaa !29
  %t565 = load ptr, ptr %lp1
  store ptr %t565, ptr %l316, !tbaa !29
  %t566 = load i64, ptr %l30, !tbaa !24
  %t569 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t566)
  store ptr %t569, ptr %l319
  br label %bb140
bb140:
  %t570 = load ptr, ptr %l319, !tbaa !29
  %t572 = getelementptr %"compiler/load:Module", ptr %t570, i32 0, i32 2
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t573, 1
  %t576 = extractvalue { i64, ptr } %t573, 0
  %t577 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t576)
  call void @olang_textcopy(ptr %t577, ptr %t575, i64 %t576)
  %t578 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  %t581 = extractvalue { i64, ptr } %t579, 0
  %t582 = extractvalue { i64, ptr } %t579, 1
  %t583 = mul i64 %t581, 1
  %t584 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t583)
  call void @llvm.memcpy.p0.p0.i64(ptr %t584, ptr %t582, i64 %t583, i1 false)
  %t585 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t584, 1
  %t587 = load i64, ptr %l30, !tbaa !24
  %t588 = load i1, ptr %l20, !tbaa !21
  %t589 = load ptr, ptr %l33, !tbaa !29
  %t591 = getelementptr %"compiler/emit:Reused", ptr %t589, i32 0, i32 6
  %t592 = load ptr, ptr %l315, !tbaa !29
  %t593 = load ptr, ptr %l316, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s27, ptr %v0, ptr %t592, ptr %t593, { i64, ptr } %t586, i32 0, i64 %t587, i1 false, i1 %t588, ptr %t591, i64 -1)
  br label %bb141
bb141:
  %t599 = load ptr, ptr %l33, !tbaa !29
  %t601 = getelementptr %"compiler/emit:Reused", ptr %t599, i32 0, i32 7
  %t602 = load i64, ptr %t601, !tbaa !24
  store i64 %t602, ptr %l40, !tbaa !24
  %t604 = load ptr, ptr %lp1
  %t606 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %t604)
  store i64 %t606, ptr %l332
  br label %bb142
bb142:
  %t607 = load i64, ptr %l332, !tbaa !24
  store i64 %t607, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t608 = load i64, ptr %l41, !tbaa !24
  %t609 = load i64, ptr %l40, !tbaa !24
  %t612 = icmp sgt i64 %t608, %t609
  br i1 %t612, label %bb143, label %bb144
bb143:
  %t614 = load i64, ptr %l42, !tbaa !24
  %t616 = icmp sgt i64 %t614, 0
  br i1 %t616, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l336, !tbaa !24
  br label %bb148
bb145:
  %t618 = load i64, ptr %l41, !tbaa !24
  %t619 = load i64, ptr %l40, !tbaa !24
  %t622 = sub i64 %t618, %t619
  %t623 = load i64, ptr %l42, !tbaa !24
  %t626 = add i64 %t622, %t623
  %t628 = sub i64 %t626, 1
  %t629 = load i64, ptr %l42, !tbaa !24
  %t632 = sdiv i64 %t628, %t629
  store i64 %t632, ptr %l339, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l339, !tbaa !24
  br label %bb147
bb147:
  %t634 = load i64, ptr %l339, !tbaa !24
  store i64 %t634, ptr %l336, !tbaa !24
  br label %bb148
bb148:
  %t635 = load i64, ptr %l336, !tbaa !24
  store i64 %t635, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s34
  %t636 = load i64, ptr %l44, !tbaa !24
  %t637 = load i64, ptr %l43, !tbaa !24
  %t640 = icmp slt i64 %t636, %t637
  %t642 = xor i1 %t640, true
  br i1 %t642, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s34)
  br label %bb158
bb151:
  br label %bb152
bb152:
  %t644 = load i64, ptr %l40, !tbaa !24
  %t645 = load i64, ptr %l44, !tbaa !24
  %t646 = load i64, ptr %l42, !tbaa !24
  %t649 = mul i64 %t645, %t646
  %t652 = add i64 %t644, %t649
  store i64 %t652, ptr %l45, !tbaa !24
  %t654 = load ptr, ptr %l33, !tbaa !29
  %t656 = getelementptr %"compiler/emit:Reused", ptr %t654, i32 0, i32 1
  store ptr %t656, ptr %l358, !tbaa !29
  %t657 = load ptr, ptr %lp1
  %t658 = load i64, ptr %l45, !tbaa !24
  %t661 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t657, i64 %t658)
  store %"compiler/emit:Object" %t661, ptr %l361
  br label %bb153
bb153:
  %t662 = getelementptr %"compiler/emit:Object", ptr %l361, i32 0, i32 0
  %t663 = load { i64, ptr }, ptr %t662, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t663, 1
  %t666 = extractvalue { i64, ptr } %t663, 0
  %t667 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t666)
  call void @olang_textcopy(ptr %t667, ptr %t665, i64 %t666)
  %t668 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t667, 1
  %t671 = extractvalue { i64, ptr } %t669, 0
  %t672 = extractvalue { i64, ptr } %t669, 1
  %t673 = mul i64 %t671, 1
  %t674 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t673)
  call void @llvm.memcpy.p0.p0.i64(ptr %t674, ptr %t672, i64 %t673, i1 false)
  %t675 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t676 = insertvalue { i64, ptr } %t675, ptr %t674, 1
  %t677 = load ptr, ptr %l358, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t677, { i64, ptr } %t676)
  br label %bb154
bb154:
  %t679 = load ptr, ptr %l33, !tbaa !29
  %t681 = getelementptr %"compiler/emit:Reused", ptr %t679, i32 0, i32 2
  store ptr %t681, ptr %l366, !tbaa !29
  %t682 = load ptr, ptr %lp1
  %t683 = load i64, ptr %l45, !tbaa !24
  %t686 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %s34, ptr %t682, i64 %t683)
  store %"compiler/emit:Object" %t686, ptr %l369
  br label %bb155
bb155:
  %t687 = getelementptr %"compiler/emit:Object", ptr %l369, i32 0, i32 1
  %t688 = load i32, ptr %t687
  %t690 = trunc i64 4 to i32
  %t691 = icmp eq i32 %t688, %t690
  %t692 = load ptr, ptr %l366, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t692, i1 %t691)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s34)
  br label %bb157
bb157:
  %t694 = load i64, ptr %l44, !tbaa !24
  %t696 = add i64 %t694, 1
  store i64 %t696, ptr %l44, !tbaa !24
  br label %bb149
bb158:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = getelementptr %"compiler/emit:Emitter", ptr %t698, i32 0, i32 62
  %t701 = load ptr, ptr %l33, !tbaa !29
  %t703 = load %"compiler/emit:Reused", ptr %t701
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t700, %"compiler/emit:Reused" %t703)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s27)
  br label %bb160
bb160:
  br label %bb161
bb161:
  br label %bb162
bb162:
  %t706 = load i64, ptr %l29, !tbaa !24
  %t708 = add i64 %t706, 1
  store i64 %t708, ptr %l29, !tbaa !24
  br label %bb101
bb163:
  %t710 = load i1, ptr %l24, !tbaa !21
  br i1 %t710, label %bb164, label %bb165
bb164:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/emit:Emitter", ptr %t712, i32 0, i32 67
  store ptr %t714, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  br label %bb166
bb165:
  br label %bb180
bb166:
  store %olang.scope zeroinitializer, ptr %s40
  %t716 = load i64, ptr %l47, !tbaa !24
  store i64 %t716, ptr %l383, !tbaa !24
  %t717 = load ptr, ptr %l46, !tbaa !29
  %t719 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t717)
  store i64 %t719, ptr %l385
  br label %bb167
bb167:
  %t720 = load i64, ptr %l383, !tbaa !24
  %t721 = load i64, ptr %l385, !tbaa !24
  %t722 = icmp slt i64 %t720, %t721
  %t724 = xor i1 %t722, true
  br i1 %t724, label %bb168, label %bb169
bb168:
  call void @__olang_scope_close(ptr %s40)
  br label %bb179
bb169:
  br label %bb170
bb170:
  %t726 = load ptr, ptr %l46, !tbaa !29
  %t727 = load i64, ptr %l47, !tbaa !24
  %t730 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t726, i64 %t727)
  store i64 %t730, ptr %l390
  br label %bb171
bb171:
  %t731 = load i64, ptr %l390, !tbaa !24
  store i64 %t731, ptr %l48, !tbaa !24
  %t732 = load i64, ptr %l3, !tbaa !24
  %t735 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t732)
  store ptr %t735, ptr %l393
  br label %bb172
bb172:
  %t736 = load ptr, ptr %l393, !tbaa !29
  %t738 = getelementptr %"compiler/load:Module", ptr %t736, i32 0, i32 2
  %t739 = load { i64, ptr }, ptr %t738, !tbaa !27
  store { i64, ptr } %t739, ptr %l395, !tbaa !27
  %t740 = load i64, ptr %l48, !tbaa !24
  %t741 = load i64, ptr %l3, !tbaa !24
  %t744 = icmp eq i64 %t740, %t741
  br i1 %t744, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l399, !tbaa !27
  br label %bb176
bb174:
  %t746 = load i64, ptr %l48, !tbaa !24
  %t749 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t746)
  store ptr %t749, ptr %l402
  br label %bb175
bb175:
  %t750 = load ptr, ptr %l402, !tbaa !29
  %t752 = getelementptr %"compiler/load:Module", ptr %t750, i32 0, i32 2
  %t753 = load { i64, ptr }, ptr %t752, !tbaa !27
  %t754 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t755 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t757 = extractvalue { i64, ptr } %t753, 1
  %t758 = extractvalue { i64, ptr } %t753, 0
  %t759 = add i64 %t755, %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t754, i64 %t755)
  %t761 = getelementptr i8, ptr %t760, i64 %t755
  call void @olang_textcopy(ptr %t761, ptr %t757, i64 %t758)
  %t762 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t760, 1
  %t765 = extractvalue { i64, ptr } %t763, 0
  %t766 = extractvalue { i64, ptr } %t763, 1
  %t767 = mul i64 %t765, 1
  %t768 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t767)
  call void @llvm.memcpy.p0.p0.i64(ptr %t768, ptr %t766, i64 %t767, i1 false)
  %t769 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t770 = insertvalue { i64, ptr } %t769, ptr %t768, 1
  store { i64, ptr } %t770, ptr %l399, !tbaa !27
  br label %bb176
bb176:
  %t772 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = extractvalue { i64, ptr } %t772, 0
  %t775 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t776 = extractvalue { i64, ptr } %t775, 1
  %t777 = extractvalue { i64, ptr } %t775, 0
  %t778 = add i64 %t774, %t777
  %t779 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t778)
  call void @olang_textcopy(ptr %t779, ptr %t773, i64 %t774)
  %t780 = getelementptr i8, ptr %t779, i64 %t774
  call void @olang_textcopy(ptr %t780, ptr %t776, i64 %t777)
  %t781 = insertvalue { i64, ptr } undef, i64 %t778, 0
  %t782 = insertvalue { i64, ptr } %t781, ptr %t779, 1
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t785 = load ptr, ptr %lp1
  %t787 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t788 = load i1, ptr %l20, !tbaa !21
  %t789 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s40, ptr %s40, ptr %t784, ptr %t785, { i64, ptr } %t782, i32 3, i64 %t787, i1 false, i1 %t788, ptr null, i64 %t789)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s40)
  br label %bb178
bb178:
  %t797 = load i64, ptr %l47, !tbaa !24
  %t799 = add i64 %t797, 1
  store i64 %t799, ptr %l47, !tbaa !24
  br label %bb166
bb179:
  br label %bb180
bb180:
  %t801 = load ptr, ptr %l0, !tbaa !29
  store ptr %t801, ptr %l417, !tbaa !29
  %t802 = load ptr, ptr %lp1
  store ptr %t802, ptr %l418, !tbaa !29
  %t803 = load i64, ptr %l3, !tbaa !24
  %t806 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l2, i64 %t803)
  store ptr %t806, ptr %l421
  br label %bb181
bb181:
  %t807 = load ptr, ptr %l421, !tbaa !29
  %t809 = getelementptr %"compiler/load:Module", ptr %t807, i32 0, i32 2
  %t810 = load { i64, ptr }, ptr %t809, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t810, 1
  %t813 = extractvalue { i64, ptr } %t810, 0
  %t814 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t813)
  call void @olang_textcopy(ptr %t814, ptr %t812, i64 %t813)
  %t815 = insertvalue { i64, ptr } undef, i64 %t813, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t814, 1
  %t818 = extractvalue { i64, ptr } %t816, 0
  %t819 = extractvalue { i64, ptr } %t816, 1
  %t820 = mul i64 %t818, 1
  %t821 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t820)
  call void @llvm.memcpy.p0.p0.i64(ptr %t821, ptr %t819, i64 %t820, i1 false)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  %t824 = load i32, ptr %l8
  %t825 = load i64, ptr %l3, !tbaa !24
  %t826 = load i1, ptr %l24, !tbaa !21
  %t828 = xor i1 %t826, true
  %t829 = load i1, ptr %l20, !tbaa !21
  %t830 = load ptr, ptr %l417, !tbaa !29
  %t831 = load ptr, ptr %l418, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t830, ptr %t831, { i64, ptr } %t823, i32 %t824, i64 %t825, i1 %t828, i1 %t829, ptr null, i64 -1)
  br label %bb182
bb182:
  %t837 = load ptr, ptr %lp1
  %t838 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t837
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t838, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i32, ptr %l14, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb12
bb12:
  %t63 = load i32, ptr %l41
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i32, ptr %l3, !tbaa !23
  store i32 %t68, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i32, ptr %l3, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l47
  br label %bb16
bb16:
  %t75 = load i32, ptr %l47
  %t77 = trunc i64 18 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l54
  br label %bb19
bb18:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb21
bb19:
  %t86 = load ptr, ptr %l51, !tbaa !29
  %t87 = load i32, ptr %l54, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t88, ptr %l55
  br label %bb20
bb20:
  %t89 = load i32, ptr %l55
  %t91 = trunc i64 4 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l50, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load i32, ptr %l3, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l61
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i32, ptr %l61, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l62
  br label %bb25
bb25:
  %t104 = load i32, ptr %l62, !tbaa !23
  store i32 %t104, ptr %l3, !tbaa !23
  br label %bb27
bb26:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
bb27:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb8
bb28:
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecEntryDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i64
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l96 = alloca i32
  %l99 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i32
  %l107 = alloca i64
  %l113 = alloca i32
  %l116 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca { i64, ptr }
  %l130 = alloca i32
  %l138 = alloca i32
  %l141 = alloca i1
  %l142 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i32
  %l149 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l179 = alloca i32
  %l183 = alloca i1
  %l187 = alloca ptr
  %l190 = alloca i32
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l199 = alloca i1
  %l202 = alloca i1
  %l203 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca i32
  %l208 = alloca ptr
  %l212 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l225 = alloca i64
  %l229 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l241 = alloca i64
  %l242 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca i64
  %l251 = alloca %"std/prelude/text:StringBuilder"
  %l252 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l264 = alloca i64
  %l268 = alloca i64
  %l270 = alloca i64
  %l276 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l288 = alloca i64
  %l289 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l35
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l35, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Func", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t15, i32 %t19)
  store { i64, ptr } %t22, ptr %l39
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t24, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l41
  br label %bb3
bb3:
  %t31 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l7
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l42, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l45
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l42, !tbaa !29
  %t39 = load i32, ptr %l45, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t40, ptr %l46
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb6, label %bb7
bb6:
  %t52 = load i64, ptr %l11, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb11
bb8:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l55, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb10
bb10:
  %t72 = load i64, ptr %l55, !tbaa !24
  store i64 %t72, ptr %l52, !tbaa !24
  br label %bb11
bb11:
  %t73 = load i64, ptr %l52, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load i64, ptr %l13, !tbaa !24
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb14:
  br label %bb15
bb15:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l14, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Sig", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t104 = icmp slt i64 %t92, %t101
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Func", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Sig", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l83, !tbaa !27
  %t114 = load i64, ptr %l14, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t121 = getelementptr %"compiler/ast:Param", ptr %t119, i32 0, i32 1
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t106, i32 %t122)
  store { i64, ptr } %t125, ptr %l87
  br label %bb18
bb17:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t130 = call i64 @__olang_fmt_i64(ptr null, i64 %t126)
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t127, i64 %t128)
  %t133 = getelementptr i8, ptr %t132, i64 %t128
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t126)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l79, !tbaa !27
  br label %bb19
bb18:
  %t138 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l79, !tbaa !27
  br label %bb19
bb19:
  %t145 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t145, ptr %l15, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %l91, !tbaa !27
  %t147 = load i64, ptr %l14, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  store i32 %t152, ptr %l16, !tbaa !23
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t155 = load i32, ptr %l16, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l96
  br label %bb20
bb20:
  %t159 = load i32, ptr %l96, !tbaa !23
  store i32 %t159, ptr %l17, !tbaa !23
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t161 = load i32, ptr %l17, !tbaa !23
  %t164 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l99
  br label %bb21
bb21:
  %t165 = load i1, ptr %l99, !tbaa !21
  br i1 %t165, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t166 = load ptr, ptr %l4, !tbaa !29
  store ptr %t166, ptr %l100, !tbaa !29
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t168 = load i32, ptr %l17, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l103
  br label %bb24
bb23:
  br label %bb58
bb24:
  %t172 = load ptr, ptr %l100, !tbaa !29
  %t173 = load i32, ptr %l103, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t174, ptr %l104
  br label %bb25
bb25:
  %t175 = load i32, ptr %l104, !tbaa !23
  store i32 %t175, ptr %l18, !tbaa !23
  %t176 = load ptr, ptr %l4, !tbaa !29
  %t177 = load i32, ptr %l17, !tbaa !23
  %t180 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t176, i32 %t177)
  store i64 %t180, ptr %l107
  br label %bb26
bb26:
  %t181 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t182 = load i64, ptr %l107, !tbaa !24
  %t184 = and i64 %t182, %t181
  %t186 = icmp eq i64 %t184, 0
  store i1 %t186, ptr %l19, !tbaa !21
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t189 = load i32, ptr %l18, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l113
  br label %bb27
bb27:
  %t193 = load i32, ptr %l113
  %t195 = trunc i64 19 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l7, ptr %l116, !tbaa !29
  %t198 = load i1, ptr %l19, !tbaa !21
  br i1 %t198, label %bb30, label %bb31
bb29:
  br label %bb41
bb30:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l118, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l118, !tbaa !27
  br label %bb32
bb32:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l119, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t202 = load i32, ptr %l18, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l122
  br label %bb33
bb33:
  %t206 = load ptr, ptr %l3, !tbaa !29
  %t207 = load ptr, ptr %l119, !tbaa !29
  %t208 = load i32, ptr %l122, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s7, ptr %t207, i32 %t208, ptr %t206)
  store { i64, ptr } %t210, ptr %l124
  br label %bb34
bb34:
  %t211 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t223 = extractvalue { i64, ptr } %t211, 1
  %t224 = extractvalue { i64, ptr } %t211, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t213, i64 %t214)
  %t227 = getelementptr i8, ptr %t226, i64 %t214
  call void @olang_textcopy(ptr %t227, ptr %t216, i64 %t217)
  %t228 = getelementptr i8, ptr %t227, i64 %t217
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t223, i64 %t224)
  %t230 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t226, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l116, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb35
bb35:
  %t241 = load ptr, ptr %l4, !tbaa !29
  %t242 = load i32, ptr %l18, !tbaa !23
  %t245 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t241, i32 %t242)
  store i32 %t245, ptr %l130
  br label %bb36
bb36:
  %t246 = load i32, ptr %l130, !tbaa !23
  %t247 = icmp eq i32 %t246, 0
  br i1 %t247, label %bb37, label %bb38
bb37:
  %t249 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t250 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t253 = extractvalue { i64, ptr } %t249, 1
  %t254 = extractvalue { i64, ptr } %t249, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t250, i64 %t251)
  %t260 = getelementptr i8, ptr %t259, i64 %t251
  call void @olang_textcopy(ptr %t260, ptr %t253, i64 %t254)
  %t261 = getelementptr i8, ptr %t260, i64 %t254
  call void @olang_textcopy(ptr %t261, ptr %t256, i64 %t257)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t259, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t270)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb41:
  %t273 = load ptr, ptr %l4, !tbaa !29
  %t274 = load i32, ptr %l18, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l138
  br label %bb42
bb42:
  %t278 = load i32, ptr %l138
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb43, label %bb44
bb43:
  %t283 = load ptr, ptr %l4, !tbaa !29
  store ptr %t283, ptr %l142, !tbaa !29
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t285 = load i32, ptr %l18, !tbaa !23
  %t288 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t284, i32 %t285)
  store i32 %t288, ptr %l145
  br label %bb45
bb44:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb47
bb45:
  %t289 = load ptr, ptr %l142, !tbaa !29
  %t290 = load i32, ptr %l145, !tbaa !23
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t289, i32 %t290)
  store i32 %t291, ptr %l146
  br label %bb46
bb46:
  %t292 = load i32, ptr %l146
  %t294 = trunc i64 5 to i32
  %t295 = icmp eq i32 %t292, %t294
  store i1 %t295, ptr %l141, !tbaa !21
  br label %bb47
bb47:
  %t297 = load i1, ptr %l141, !tbaa !21
  br i1 %t297, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l7, ptr %l149, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l16, !tbaa !23
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t304 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s11, ptr %t298, i32 %t299, ptr %t300)
  store { i64, ptr } %t304, ptr %l153
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t305 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t313 = extractvalue { i64, ptr } %t305, 1
  %t314 = extractvalue { i64, ptr } %t305, 0
  %t315 = add i64 %t311, %t314
  %t316 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t315)
  call void @olang_textcopy(ptr %t316, ptr %t307, i64 %t308)
  %t317 = getelementptr i8, ptr %t316, i64 %t308
  call void @olang_textcopy(ptr %t317, ptr %t309, i64 %t310)
  %t318 = getelementptr i8, ptr %t317, i64 %t310
  call void @olang_textcopy(ptr %t318, ptr %t313, i64 %t314)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t316, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = load ptr, ptr %l149, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t328, { i64, ptr } %t327)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb52:
  store ptr %l7, ptr %l157, !tbaa !29
  %t330 = load i1, ptr %l19, !tbaa !21
  br i1 %t330, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l159, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l159, !tbaa !27
  br label %bb55
bb55:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i32, ptr %l18, !tbaa !23
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t338 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s6, ptr %t332, i32 %t333, ptr %t334)
  store { i64, ptr } %t338, ptr %l163
  br label %bb56
bb56:
  %t339 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t339, 1
  %t352 = extractvalue { i64, ptr } %t339, 0
  %t353 = add i64 %t349, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t341, i64 %t342)
  %t355 = getelementptr i8, ptr %t354, i64 %t342
  call void @olang_textcopy(ptr %t355, ptr %t344, i64 %t345)
  %t356 = getelementptr i8, ptr %t355, i64 %t345
  call void @olang_textcopy(ptr %t356, ptr %t347, i64 %t348)
  %t357 = getelementptr i8, ptr %t356, i64 %t348
  call void @olang_textcopy(ptr %t357, ptr %t351, i64 %t352)
  %t358 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t354, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } %t359, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t367 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t367, { i64, ptr } %t366)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb58:
  store ptr %l7, ptr %l167, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr %l16, !tbaa !23
  %t371 = load ptr, ptr %l3, !tbaa !29
  %t375 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s3, ptr %t369, i32 %t370, ptr %t371)
  store { i64, ptr } %t375, ptr %l171
  br label %bb59
bb59:
  %t376 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t384 = extractvalue { i64, ptr } %t376, 1
  %t385 = extractvalue { i64, ptr } %t376, 0
  %t386 = add i64 %t382, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t378, i64 %t379)
  %t388 = getelementptr i8, ptr %t387, i64 %t379
  call void @olang_textcopy(ptr %t388, ptr %t380, i64 %t381)
  %t389 = getelementptr i8, ptr %t388, i64 %t381
  call void @olang_textcopy(ptr %t389, ptr %t384, i64 %t385)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t387, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } %t391, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t399 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t399, { i64, ptr } %t398)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb61:
  %t401 = load i64, ptr %l13, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l13, !tbaa !24
  br label %bb12
bb62:
  %t405 = load ptr, ptr %l4, !tbaa !29
  %t406 = load i32, ptr %l2, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l179
  br label %bb63
bb63:
  %t410 = load i32, ptr %l179, !tbaa !23
  store i32 %t410, ptr %l20, !tbaa !23
  %t411 = load i32, ptr %l20, !tbaa !23
  %t412 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t415 = icmp ne i32 %t411, %t412
  br i1 %t415, label %bb64, label %bb65
bb64:
  %t417 = load i32, ptr %l20, !tbaa !23
  %t418 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t421 = icmp ne i32 %t417, %t418
  store i1 %t421, ptr %l183, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb66
bb66:
  %t423 = load i1, ptr %l183, !tbaa !21
  store i1 %t423, ptr %l21, !tbaa !21
  %t424 = load ptr, ptr %l4, !tbaa !29
  store ptr %t424, ptr %l187, !tbaa !29
  %t425 = load ptr, ptr %l4, !tbaa !29
  %t426 = load i32, ptr %l2, !tbaa !23
  %t429 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t425, i32 %t426)
  store i32 %t429, ptr %l190
  br label %bb67
bb67:
  %t430 = load ptr, ptr %l187, !tbaa !29
  %t431 = load i32, ptr %l190, !tbaa !23
  %t432 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t430, i32 %t431)
  store { i64, ptr } %t432, ptr %l191
  br label %bb68
bb68:
  %t433 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 0
  %t436 = icmp sgt i64 %t434, 0
  store i1 %t436, ptr %l22, !tbaa !21
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l194, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t438, ptr %l195, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  store i64 %t440, ptr %l196, !tbaa !24
  %t441 = load i64, ptr %l196, !tbaa !24
  %t442 = mul i64 %t441, 1
  %t443 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t442)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t443, 1
  store { i64, ptr } %t445, ptr %l197, !tbaa !27
  %t446 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = load i64, ptr %l196, !tbaa !24
  %t451 = mul i64 %t450, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t447, ptr %t449, i64 %t451, i1 false)
  %t452 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t452, ptr %l23, !tbaa !27
  %t453 = load i1, ptr %l21, !tbaa !21
  br i1 %t453, label %bb69, label %bb70
bb69:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i32, ptr %l20, !tbaa !23
  %t459 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %t455, i32 %t456)
  store i1 %t459, ptr %l202
  br label %bb71
bb70:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb72
bb71:
  %t460 = load i1, ptr %l202, !tbaa !21
  store i1 %t460, ptr %l199, !tbaa !21
  br label %bb72
bb72:
  %t461 = load i1, ptr %l199, !tbaa !21
  br i1 %t461, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s16
  %t462 = load ptr, ptr %l4, !tbaa !29
  store ptr %t462, ptr %l203, !tbaa !29
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i32, ptr %l20, !tbaa !23
  %t467 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t463, i32 %t464)
  store i32 %t467, ptr %l206
  br label %bb75
bb74:
  %t468 = load i1, ptr %l22, !tbaa !21
  br i1 %t468, label %bb90, label %bb91
bb75:
  %t470 = load ptr, ptr %l203, !tbaa !29
  %t471 = load i32, ptr %l206, !tbaa !23
  %t472 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t470, i32 %t471)
  store i32 %t472, ptr %l207
  br label %bb76
bb76:
  %t473 = load i32, ptr %l207, !tbaa !23
  store ptr %l7, ptr %l208, !tbaa !29
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l3, !tbaa !29
  %t480 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s16, ptr %t474, i32 %t473, ptr %t476)
  store { i64, ptr } %t480, ptr %l212
  br label %bb77
bb77:
  %t481 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t482, i64 %t483)
  %t488 = getelementptr i8, ptr %t487, i64 %t483
  call void @olang_textcopy(ptr %t488, ptr %t484, i64 %t485)
  %t489 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t487, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } %t490, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t498 = load ptr, ptr %l208, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t498, { i64, ptr } %t497)
  br label %bb78
bb78:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb79
bb79:
  %t501 = load i1, ptr %l22, !tbaa !21
  br i1 %t501, label %bb80, label %bb81
bb80:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t504 = load i1, ptr %l22, !tbaa !21
  br i1 %t504, label %bb84, label %bb85
bb84:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l220, !tbaa !27
  %t506 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t506, ptr %l219, !tbaa !27
  br label %bb86
bb85:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l222, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t508, ptr %l219, !tbaa !27
  br label %bb86
bb86:
  %t510 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l225, !tbaa !24
  %t515 = load i64, ptr %l225, !tbaa !24
  %t516 = icmp eq i64 %t511, %t515
  br i1 %t516, label %bb87, label %bb88
bb87:
  %t518 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = load i64, ptr %l225, !tbaa !24
  %t523 = mul i64 %t522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t519, ptr %t521, i64 %t523, i1 false)
  br label %bb89
bb88:
  %t524 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t524, ptr %l23, !tbaa !27
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s16)
  br label %bb108
bb90:
  %t525 = load i1, ptr %l21, !tbaa !21
  br i1 %t525, label %bb92, label %bb93
bb91:
  %t527 = load i1, ptr %l21, !tbaa !21
  br i1 %t527, label %bb100, label %bb101
bb92:
  store %olang.scope zeroinitializer, ptr %s21
  store ptr %l7, ptr %l229, !tbaa !29
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l20, !tbaa !23
  %t531 = load ptr, ptr %l3, !tbaa !29
  %t535 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s21, ptr %t529, i32 %t530, ptr %t531)
  store { i64, ptr } %t535, ptr %l233
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t536 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 1
  %t538 = extractvalue { i64, ptr } %t536, 0
  %t539 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t542 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t537, i64 %t538)
  %t543 = getelementptr i8, ptr %t542, i64 %t538
  call void @olang_textcopy(ptr %t543, ptr %t539, i64 %t540)
  %t544 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t542, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = extractvalue { i64, ptr } %t545, 1
  %t549 = mul i64 %t547, 1
  %t550 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t549)
  call void @llvm.memcpy.p0.p0.i64(ptr %t550, ptr %t548, i64 %t549, i1 false)
  %t551 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  %t553 = load ptr, ptr %l229, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t553, { i64, ptr } %t552)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l236, !tbaa !27
  %t555 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t555, ptr %l237, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t556, 0
  %t558 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 0
  store i64 %t559, ptr %l239, !tbaa !24
  %t561 = load i64, ptr %l239, !tbaa !24
  %t562 = icmp eq i64 %t557, %t561
  br i1 %t562, label %bb97, label %bb98
bb97:
  %t564 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = load i64, ptr %l239, !tbaa !24
  %t569 = mul i64 %t568, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t565, ptr %t567, i64 %t569, i1 false)
  br label %bb99
bb98:
  %t570 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t570, 0
  store i64 %t571, ptr %l241, !tbaa !24
  %t572 = load i64, ptr %l241, !tbaa !24
  %t573 = mul i64 %t572, 1
  %t574 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t573)
  %t575 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  store { i64, ptr } %t576, ptr %l242, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = load i64, ptr %l241, !tbaa !24
  %t582 = mul i64 %t581, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t578, ptr %t580, i64 %t582, i1 false)
  %t583 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t583, ptr %l23, !tbaa !27
  br label %bb99
bb99:
  br label %bb107
bb100:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i32, ptr %l20, !tbaa !23
  %t586 = load ptr, ptr %l3, !tbaa !29
  %t590 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s0, ptr %t584, i32 %t585, ptr %t586)
  store { i64, ptr } %t590, ptr %l247
  br label %bb102
bb101:
  br label %bb106
bb102:
  %t591 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 0
  %t593 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t593, 0
  store i64 %t594, ptr %l249, !tbaa !24
  %t596 = load i64, ptr %l249, !tbaa !24
  %t597 = icmp eq i64 %t592, %t596
  br i1 %t597, label %bb103, label %bb104
bb103:
  %t599 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = load i64, ptr %l249, !tbaa !24
  %t604 = mul i64 %t603, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t600, ptr %t602, i64 %t604, i1 false)
  br label %bb105
bb104:
  %t605 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t605, ptr %l23, !tbaa !27
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t606 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t606, ptr %l251
  br label %bb109
bb109:
  %t607 = load %"std/prelude/text:StringBuilder", ptr %l251
  store %"std/prelude/text:StringBuilder" %t607, ptr %l25
  store ptr %l25, ptr %l252, !tbaa !29
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i64, ptr %l1, !tbaa !24
  %t612 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignatureText(ptr %v0, ptr %s0, ptr %t608, i64 %t609)
  store { i64, ptr } %t612, ptr %l255
  br label %bb110
bb110:
  %t613 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t615 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t613, i64 %t614)
  %t623 = getelementptr i8, ptr %t622, i64 %t614
  call void @olang_textcopy(ptr %t623, ptr %t616, i64 %t617)
  %t624 = getelementptr i8, ptr %t623, i64 %t617
  call void @olang_textcopy(ptr %t624, ptr %t619, i64 %t620)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t634 = load ptr, ptr %l252, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t634, { i64, ptr } %t633)
  br label %bb111
bb111:
  %t636 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t636, 1
  %t640 = extractvalue { i64, ptr } %t636, 0
  %t641 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t642 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t643 = add i64 %t640, %t642
  %t645 = extractvalue { i64, ptr } %t637, 1
  %t646 = extractvalue { i64, ptr } %t637, 0
  %t647 = add i64 %t643, %t646
  %t648 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t649 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t650 = add i64 %t647, %t649
  %t651 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t650)
  call void @olang_textcopy(ptr %t651, ptr %t639, i64 %t640)
  %t652 = getelementptr i8, ptr %t651, i64 %t640
  call void @olang_textcopy(ptr %t652, ptr %t641, i64 %t642)
  %t653 = getelementptr i8, ptr %t652, i64 %t642
  call void @olang_textcopy(ptr %t653, ptr %t645, i64 %t646)
  %t654 = getelementptr i8, ptr %t653, i64 %t646
  call void @olang_textcopy(ptr %t654, ptr %t648, i64 %t649)
  %t655 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t651, 1
  %t658 = extractvalue { i64, ptr } %t656, 0
  %t659 = extractvalue { i64, ptr } %t656, 1
  %t660 = mul i64 %t658, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t661, ptr %t659, i64 %t660, i1 false)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } %t663)
  br label %bb112
bb112:
  %t667 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t667, ptr %l264
  br label %bb113
bb113:
  %t668 = load i64, ptr %l264, !tbaa !24
  %t669 = icmp eq i64 %t668, 0
  br i1 %t669, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s27)
  br label %bb117
bb117:
  store ptr %l7, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb118
bb118:
  %t673 = load i64, ptr %l27, !tbaa !24
  store i64 %t673, ptr %l268, !tbaa !24
  %t674 = load ptr, ptr %l26, !tbaa !29
  %t676 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t674)
  store i64 %t676, ptr %l270
  br label %bb119
bb119:
  %t677 = load i64, ptr %l268, !tbaa !24
  %t678 = load i64, ptr %l270, !tbaa !24
  %t679 = icmp slt i64 %t677, %t678
  %t681 = xor i1 %t679, true
  br i1 %t681, label %bb120, label %bb121
bb120:
  br label %bb130
bb121:
  br label %bb122
bb122:
  %t683 = load i64, ptr %l27, !tbaa !24
  store i64 %t683, ptr %l28, !tbaa !24
  %t685 = load ptr, ptr %l26, !tbaa !29
  %t686 = load i64, ptr %l27, !tbaa !24
  %t689 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t685, i64 %t686)
  store { i64, ptr } %t689, ptr %l276
  br label %bb123
bb123:
  %t690 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t690, ptr %l29, !tbaa !27
  %t691 = load i64, ptr %l28, !tbaa !24
  %t693 = icmp sgt i64 %t691, 0
  br i1 %t693, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s30
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %l25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb126
bb125:
  br label %bb127
bb126:
  call void @__olang_scope_close(ptr %s30)
  br label %bb127
bb127:
  %t696 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } %t696)
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t699 = load i64, ptr %l27, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l27, !tbaa !24
  br label %bb118
bb130:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb131
bb131:
  %t705 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l25)
  store { i64, ptr } %t705, ptr %l286
  br label %bb132
bb132:
  %t706 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t706, ptr %l287, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 0
  store i64 %t708, ptr %l288, !tbaa !24
  %t709 = load i64, ptr %l288, !tbaa !24
  %t710 = mul i64 %t709, 1
  %t711 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t710)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  store { i64, ptr } %t713, ptr %l289, !tbaa !27
  %t714 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !27
  %t716 = getelementptr { i64, ptr }, ptr %l287, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = load i64, ptr %l288, !tbaa !24
  %t719 = mul i64 %t718, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t715, ptr %t717, i64 %t719, i1 false)
  %t720 = load { i64, ptr }, ptr %l289, !tbaa !27
  store { i64, ptr } %t720, ptr %l287, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t721 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t721, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/cabi:Way"
  %l8 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l76 = alloca %"compiler/cabi:Way"
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l5, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load i32, ptr %l16
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 %a3, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l19, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load ptr, ptr %l21, !tbaa !29
  %t27 = getelementptr %"compiler/cabi:Regs", ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = sub i64 %t28, 2
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = getelementptr %"compiler/cabi:Regs", ptr %t32, i32 0, i32 0
  store i64 %t30, ptr %t33, !tbaa !24
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l27, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l30
  br label %bb9
bb9:
  %t55 = load i32, ptr %l30
  %t57 = trunc i64 21 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t62 = getelementptr %"compiler/cabi:Regs", ptr %t61, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = sub i64 %t63, 1
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Regs", ptr %t67, i32 0, i32 0
  store i64 %t65, ptr %t68, !tbaa !24
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t69, ptr %l37, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l38, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l39, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l42
  br label %bb13
bb13:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb14, label %bb15
bb14:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l46
  br label %bb16
bb15:
  %t96 = load i32, ptr %l5, !tbaa !23
  store i32 %t96, ptr %l43, !tbaa !23
  br label %bb17
bb16:
  %t98 = load i32, ptr %l46, !tbaa !23
  store i32 %t98, ptr %l43, !tbaa !23
  br label %bb17
bb17:
  %t99 = load i32, ptr %l43, !tbaa !23
  store i32 %t99, ptr %l6, !tbaa !23
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t101 = load i32, ptr %l5, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l50
  br label %bb18
bb18:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb20:
  %t106 = load ptr, ptr %l4, !tbaa !29
  store ptr %t106, ptr %l52, !tbaa !29
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  %t115 = load i32, ptr %l56
  %t117 = trunc i64 19 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l51, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l59, !tbaa !29
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = getelementptr %"compiler/cabi:Regs", ptr %t122, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = sub i64 %t124, 1
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = getelementptr %"compiler/cabi:Regs", ptr %t128, i32 0, i32 0
  store i64 %t126, ptr %t129, !tbaa !24
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t130, ptr %l63, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l64, !tbaa !24
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l65, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l64, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l69
  br label %bb27
bb27:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/emit:Emitter", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/emit:Emitter", ptr %t158, i32 0, i32 45
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t162 = load i32, ptr %l1, !tbaa !23
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t168 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t157, { i64, ptr } %t161, i32 %t162, ptr %t163)
  store %"compiler/cabi:Way" %t168, ptr %l76
  br label %bb28
bb28:
  %t169 = load %"compiler/cabi:Way", ptr %l76
  store %"compiler/cabi:Way" %t169, ptr %l7
  %t170 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 0
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l8
  %t173 = load i32, ptr %l8
  %t175 = trunc i64 0 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s4, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l83
  br label %bb32
bb32:
  %t183 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t184, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t186, ptr %l85
  br label %bb33
bb33:
  %t187 = load i1, ptr %l85, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb34, label %bb35
bb34:
  %t190 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t195 = extractvalue { i64, ptr } %t191, 1
  %t196 = extractvalue { i64, ptr } %t191, 0
  %t197 = add i64 %t193, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = getelementptr i8, ptr %t198, i64 %t193
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l87, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb36
bb36:
  %t210 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = add i64 %t212, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t211, i64 %t212)
  %t218 = getelementptr i8, ptr %t217, i64 %t212
  call void @olang_textcopy(ptr %t218, ptr %t214, i64 %t215)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t217, 1
  store { i64, ptr } %t220, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb37:
  %t222 = load i32, ptr %l8
  %t224 = trunc i64 1 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t228 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t228, ptr %l95
  br label %bb41
bb41:
  %t229 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t229, ptr %l78, !tbaa !27
  br label %bb54
bb42:
  %t230 = load i32, ptr %l8
  %t232 = trunc i64 2 to i32
  %t233 = icmp eq i32 %t230, %t232
  br i1 %t233, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb49
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l1, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s8, ptr %t235, i32 %t236)
  store { i64, ptr } %t239, ptr %l100
  br label %bb46
bb46:
  %t240 = load ptr, ptr %l4, !tbaa !29
  %t241 = load i32, ptr %l1, !tbaa !23
  %t244 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t240, i32 %t241)
  store i64 %t244, ptr %l103
  br label %bb47
bb47:
  %t245 = load i64, ptr %l103, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t245, i64 8)
  store i64 %t246, ptr %l104
  br label %bb48
bb48:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = load i64, ptr %l104, !tbaa !24
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t256)
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t247, i64 %t248)
  %t260 = getelementptr i8, ptr %t259, i64 %t248
  call void @olang_textcopy(ptr %t260, ptr %t250, i64 %t251)
  %t261 = getelementptr i8, ptr %t260, i64 %t251
  call void @olang_textcopy(ptr %t261, ptr %t253, i64 %t254)
  %t262 = getelementptr i8, ptr %t261, i64 %t254
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t256)
  %t264 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t259, 1
  store { i64, ptr } %t265, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l106, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t267, ptr %l78, !tbaa !27
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2854570d7fadf599_61afc1034d008305)
  unreachable
bb54:
  %t269 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l108, !tbaa !24
  %t271 = load i64, ptr %l108, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l109, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l108, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t282, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, [1 x i64] }
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l59 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb22
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l17
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 6
  store ptr %t24, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l22
  br label %bb6
bb6:
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %bb21
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t36, i64 %t37)
  store { i64, [1 x i64] } %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load { i64, [1 x i64] }, ptr %l27
  %t44 = extractvalue { i64, [1 x i64] } %t41, 0
  %t45 = icmp eq i64 %t44, 4
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l2, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9506350913203bfc_41d6488afcc367c0)
  unreachable
bb19:
  br label %bb20
bb20:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb5
bb21:
  br label %bb41
bb22:
  %t55 = load { i64, [2 x i64] }, ptr %l1
  %t57 = extractvalue { i64, [2 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 1
  br i1 %t58, label %bb23, label %bb24
bb23:
  %t60 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t61 = getelementptr { i32 }, ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/emit:Emitter", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/emit:Emitter", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l40, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:Emitter", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/lower:Lowerer", ptr %t75, i32 0, i32 1
  %t78 = load i32, ptr %l7, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t77, i64 %t80)
  store ptr %t83, ptr %l46
  br label %bb26
bb26:
  %t84 = load ptr, ptr %l46, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t88, i32 %t87)
  store i32 %t90, ptr %l49
  br label %bb27
bb27:
  %t91 = load ptr, ptr %l38, !tbaa !29
  %t92 = load i32, ptr %l49, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t91, i32 %t92)
  store { i64, ptr } %t93, ptr %l50
  br label %bb28
bb28:
  %t94 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t94, ptr %l8, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb29, label %bb30
bb29:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/emit:Emitter", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t105, ptr %l57, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 0
  %t109 = load i32, ptr %t108, !tbaa !33
  %t112 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t104, i32 %t109)
  store i1 %t112, ptr %l59
  br label %bb31
bb30:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb32
bb31:
  %t113 = load i1, ptr %l59, !tbaa !21
  store i1 %t113, ptr %l54, !tbaa !21
  br label %bb32
bb32:
  %t114 = load i1, ptr %l54, !tbaa !21
  br i1 %t114, label %bb33, label %bb34
bb33:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_2a2725b2da5e1bad_47abef39162bd051)
  unreachable
bb41:
  %t115 = load i64, ptr %l2, !tbaa !24
  store i64 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:Emitter", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t10, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 51
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:Emitter", ptr %t8, i32 0, i32 51
  %t11 = load i64, ptr %t10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 51
  store i64 %t17, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:Emitter", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t29, i64 %t39)
  store ptr %t42, ptr %l19
  br label %bb5
bb5:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t45 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load ptr, ptr %l10, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t47, i64 %t46)
  store i64 %t49, ptr %l22
  br label %bb6
bb6:
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 51
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t60 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t61 = add i64 %t58, %t60
  %t62 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t57, i64 %t58)
  %t69 = getelementptr i8, ptr %t68, i64 %t58
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t50)
  %t71 = getelementptr i8, ptr %t69, i64 %t60
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = getelementptr i8, ptr %t71, i64 %t63
  call void @olang_textcopy(ptr %t72, ptr %t65, i64 %t66)
  %t73 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t68, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } %t74, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t51, i64 %t55, { i64, ptr } %t81)
  br label %bb7
bb7:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/emit:Emitter", ptr %t85, i32 0, i32 51
  %t88 = load i64, ptr %t87, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i64, ptr %l14, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 56
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t11 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t10, i64 %t11)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l21
  br label %bb3
bb3:
  %t18 = load i64, ptr %l21, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp ne i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l27
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l29
  br label %bb8
bb8:
  %t34 = load i64, ptr %l29, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l35
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t46 = load i64, ptr %l35, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l37
  br label %bb12
bb12:
  %t50 = load i64, ptr %l37, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = getelementptr i8, ptr %t63, i64 %t59
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb15
bb15:
  %t76 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t78 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = getelementptr i8, ptr %t86, i64 %t80
  call void @olang_textcopy(ptr %t87, ptr %t82, i64 %t83)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t85, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s2, ptr %t97, i64 %t98, { i64, ptr } %t96)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l49
  br label %bb18
bb18:
  %t103 = load i64, ptr %l49, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l51
  br label %bb19
bb19:
  %t107 = load i64, ptr %l51, !tbaa !24
  store i64 %t107, ptr %l11, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t108)
  store i64 %t110, ptr %l53
  br label %bb20
bb20:
  %t111 = load i64, ptr %l53, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t119 = extractvalue { i64, ptr } %a2, 1
  %t120 = extractvalue { i64, ptr } %a2, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t116, i64 %t117)
  %t132 = getelementptr i8, ptr %t131, i64 %t117
  call void @olang_textcopy(ptr %t132, ptr %t119, i64 %t120)
  %t133 = getelementptr i8, ptr %t132, i64 %t120
  call void @olang_textcopy(ptr %t133, ptr %t122, i64 %t123)
  %t134 = getelementptr i8, ptr %t133, i64 %t123
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t115)
  %t136 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t136, ptr %t128, i64 %t129)
  %t137 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t131, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t112, i64 %t113, { i64, ptr } %t145)
  br label %bb21
bb21:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t156 = extractvalue { i64, ptr } %a4, 1
  %t157 = extractvalue { i64, ptr } %a4, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t152)
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t153, i64 %t154)
  %t169 = getelementptr i8, ptr %t168, i64 %t154
  call void @olang_textcopy(ptr %t169, ptr %t156, i64 %t157)
  %t170 = getelementptr i8, ptr %t169, i64 %t157
  call void @olang_textcopy(ptr %t170, ptr %t159, i64 %t160)
  %t171 = getelementptr i8, ptr %t170, i64 %t160
  %t172 = call i64 @__olang_fmt_i64(ptr %t171, i64 %t152)
  %t173 = getelementptr i8, ptr %t171, i64 %t163
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t168, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t149, i64 %t150, { i64, ptr } %t182)
  br label %bb22
bb22:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l10, !tbaa !24
  %t189 = load i64, ptr %l11, !tbaa !24
  %t190 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t193 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t194 = add i64 %t191, %t193
  %t195 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t199 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t200 = add i64 %t197, %t199
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t190, i64 %t191)
  %t205 = getelementptr i8, ptr %t204, i64 %t191
  %t206 = call i64 @__olang_fmt_i64(ptr %t205, i64 %t188)
  %t207 = getelementptr i8, ptr %t205, i64 %t193
  call void @olang_textcopy(ptr %t207, ptr %t195, i64 %t196)
  %t208 = getelementptr i8, ptr %t207, i64 %t196
  %t209 = call i64 @__olang_fmt_i64(ptr %t208, i64 %t189)
  %t210 = getelementptr i8, ptr %t208, i64 %t199
  call void @olang_textcopy(ptr %t210, ptr %t201, i64 %t202)
  %t211 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t204, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t186, i64 %t187, { i64, ptr } %t219)
  br label %bb23
bb23:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l72, !tbaa !29
  %t224 = load i64, ptr %l6, !tbaa !24
  store i64 %t224, ptr %l73, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l1, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s0, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l76
  br label %bb24
bb24:
  %t230 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t238 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t236)
  store { i64, ptr } %t238, ptr %l78
  br label %bb25
bb25:
  %t239 = load i64, ptr %l12, !tbaa !24
  %t240 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t242 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t248 = add i64 %t245, %t247
  %t250 = call i64 @__olang_fmt_i64(ptr null, i64 %t239)
  %t251 = add i64 %t248, %t250
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t254 = add i64 %t251, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t240, i64 %t241)
  %t256 = getelementptr i8, ptr %t255, i64 %t241
  call void @olang_textcopy(ptr %t256, ptr %t243, i64 %t244)
  %t257 = getelementptr i8, ptr %t256, i64 %t244
  call void @olang_textcopy(ptr %t257, ptr %t246, i64 %t247)
  %t258 = getelementptr i8, ptr %t257, i64 %t247
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t239)
  %t260 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t260, ptr %t252, i64 %t253)
  %t261 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t255, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l72, !tbaa !29
  %t271 = load i64, ptr %l73, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t270, i64 %t271, { i64, ptr } %t269)
  br label %bb26
bb26:
  %t273 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t273, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 52
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 52
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 52
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 52
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) })
  %t13 = extractvalue { i32, i64 } %t12, 1
  %t14 = extractvalue { i32, i64 } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store i64 %t13, ptr %l10
  br label %bb2
bb2:
  %t17 = load i64, ptr %l10, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t18 = load i64, ptr %l8, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t25, ptr %l16
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb11:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l18, !tbaa !27
  br label %bb18
bb12:
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb14:
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb16:
  %t57 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = load i64, ptr %l22, !tbaa !24
  %t61 = getelementptr i8, ptr %t58, i64 %t59
  %t62 = sub i64 %t60, %t59
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l18, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t6 = extractvalue { i64, ptr } %a2, 1
  %t7 = extractvalue { i64, ptr } %a2, 0
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = extractvalue { i64, ptr } %t14, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %a1, i64 %t3, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edtorThunk(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l33 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t10 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t6, { i64, [2 x i64] } %t7)
  store { i64, ptr } %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l1
  %t16 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  store i32 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i32, ptr %l20, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t18, ptr %l21
  br label %bb3
bb3:
  %t19 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t19, ptr %l5
  store ptr %l5, ptr %l22, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l26
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t26, 1
  %t45 = extractvalue { i64, ptr } %t26, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t27, i64 %t28)
  %t51 = getelementptr i8, ptr %t50, i64 %t28
  call void @olang_textcopy(ptr %t51, ptr %t30, i64 %t31)
  %t52 = getelementptr i8, ptr %t51, i64 %t31
  call void @olang_textcopy(ptr %t52, ptr %t33, i64 %t34)
  %t53 = getelementptr i8, ptr %t52, i64 %t34
  call void @olang_textcopy(ptr %t53, ptr %t37, i64 %t38)
  %t54 = getelementptr i8, ptr %t53, i64 %t38
  call void @olang_textcopy(ptr %t54, ptr %t40, i64 %t41)
  %t55 = getelementptr i8, ptr %t54, i64 %t41
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t50, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t66, { i64, ptr } %t65)
  br label %bb5
bb5:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, [2 x i64] }, ptr %l1
  %t70 = load i32, ptr %l4, !tbaa !23
  %t74 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t68, { i64, [2 x i64] } %t69, i32 %t70)
  store i64 %t74, ptr %l33
  br label %bb6
bb6:
  %t75 = load i64, ptr %l33, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb7, label %bb8
bb7:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb12
bb9:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l41, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb11
bb11:
  %t104 = load i64, ptr %l41, !tbaa !24
  store i64 %t104, ptr %l38, !tbaa !24
  br label %bb12
bb12:
  %t105 = load i64, ptr %l38, !tbaa !24
  store i64 %t105, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  %t126 = icmp sgt i64 %t122, 0
  br i1 %t126, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb13
bb23:
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb28
bb28:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l69, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = getelementptr i8, ptr %t148, i64 %t144
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t159, ptr %l73, !tbaa !24
  %t161 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t161, ptr %l75
  br label %bb29
bb29:
  %t162 = load ptr, ptr %l69, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t164 = load i64, ptr %l73, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t162, { i64, ptr } %t163, i64 %t164, { i64, ptr } %t165, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t10, i64 %a1)
  store ptr %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t19, i32 %t18)
  store { i64, ptr } %t21, ptr %l16
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t28, ptr %lp4
  %t30 = load ptr, ptr %lp4
  store { i64, ptr } %t27, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %lp4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v1, ptr %t31, { i64, ptr } %t33, i32 %t34)
  store { i64, ptr } %t38, ptr %l21
  br label %bb3
bb3:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t39, ptr %lp5
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t41 = load ptr, ptr %lp5
  store { i64, ptr } %t40, ptr %t41, !tbaa !27
  %t42 = load ptr, ptr %lp5
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t45, ptr %l23
  br label %bb4
bb4:
  %t46 = load i1, ptr %l23, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp5
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t54 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t51)
  store i1 %t54, ptr %l27
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t55 = load i1, ptr %l27, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %lp5
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l30, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s3, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l33
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t66 = load ptr, ptr %lp5
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l34, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb11
bb11:
  %t73 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t74, i64 %t75)
  %t94 = getelementptr i8, ptr %t93, i64 %t75
  call void @olang_textcopy(ptr %t94, ptr %t76, i64 %t77)
  %t95 = getelementptr i8, ptr %t94, i64 %t77
  call void @olang_textcopy(ptr %t95, ptr %t80, i64 %t81)
  %t96 = getelementptr i8, ptr %t95, i64 %t81
  call void @olang_textcopy(ptr %t96, ptr %t83, i64 %t84)
  %t97 = getelementptr i8, ptr %t96, i64 %t84
  call void @olang_textcopy(ptr %t97, ptr %t87, i64 %t88)
  %t98 = getelementptr i8, ptr %t97, i64 %t88
  call void @olang_textcopy(ptr %t98, ptr %t90, i64 %t91)
  %t99 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t93, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l29, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s3, ptr %t108, { i64, ptr } %t109, { i64, ptr } %t107)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t111 = load ptr, ptr %lp5
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t112, ptr %rv
  br label %ret
bb14:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %lp4
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t119 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t114, { i64, ptr } %t116)
  store i1 %t119, ptr %l43
  br label %bb15
bb15:
  %t120 = load i1, ptr %l43, !tbaa !21
  br i1 %t120, label %bb16, label %bb17
bb16:
  %t121 = load ptr, ptr %lp4
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l45
  br label %bb19
bb19:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t125, ptr %l6
  store ptr %l6, ptr %l46, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l2, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %s0, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l49
  br label %bb20
bb20:
  %t131 = load ptr, ptr %lp4
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t140 = extractvalue { i64, ptr } %t132, 1
  %t141 = extractvalue { i64, ptr } %t132, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t134, i64 %t135)
  %t147 = getelementptr i8, ptr %t146, i64 %t135
  call void @olang_textcopy(ptr %t147, ptr %t136, i64 %t137)
  %t148 = getelementptr i8, ptr %t147, i64 %t137
  call void @olang_textcopy(ptr %t148, ptr %t140, i64 %t141)
  %t149 = getelementptr i8, ptr %t148, i64 %t141
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t159, { i64, ptr } %t158)
  br label %bb21
bb21:
  store ptr %l6, ptr %l53, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l54, !tbaa !29
  %t162 = load i32, ptr %l2, !tbaa !23
  store i32 %t162, ptr %l55, !tbaa !23
  %t163 = load ptr, ptr %lp4
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t166, ptr %l57
  br label %bb22
bb22:
  %t167 = load ptr, ptr %l54, !tbaa !29
  %t168 = load i32, ptr %l55, !tbaa !23
  %t169 = load i1, ptr %l57, !tbaa !21
  %t170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %s0, ptr %t167, i32 %t168, i1 %t169)
  store { i64, ptr } %t170, ptr %l58
  br label %bb23
bb23:
  %t171 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t178 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t178, { i64, ptr } %t177)
  br label %bb24
bb24:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb25
bb25:
  %t181 = load ptr, ptr %lp4
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load ptr, ptr @__olang_prog_scope
  %t186 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %t183, ptr %v1, ptr @G_2ecompiler_2femit_2emathInexact, { i64, ptr } %t182)
  store i1 %t186, ptr %l63
  br label %bb26
bb26:
  %t187 = load i1, ptr %l63, !tbaa !21
  br i1 %t187, label %bb27, label %bb28
bb27:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s0, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l67
  br label %bb29
bb28:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb31
bb29:
  %t193 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t199, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t201, ptr %l69
  br label %bb30
bb30:
  %t202 = load i1, ptr %l69, !tbaa !21
  %t203 = xor i1 %t202, true
  store i1 %t203, ptr %l64, !tbaa !21
  br label %bb31
bb31:
  %t205 = load i1, ptr %l64, !tbaa !21
  br i1 %t205, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l6, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l72, !tbaa !29
  %t208 = load ptr, ptr %lp4
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l73, !tbaa !27
  %t211 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t211, ptr %l75
  br label %bb36
bb36:
  %t212 = load ptr, ptr %l72, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s0, ptr %t212, { i64, ptr } %t213, { i64, ptr } %t214)
  br label %bb37
bb37:
  %t215 = load ptr, ptr %lp4
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 19
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [2 x i64] }, ptr %l1
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t15, { i64, [2 x i64] } %t16, i32 %a2, { i64, ptr } %t18, i64 %a4, i1 %a5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store { i64, ptr } %t27, ptr %l22
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t28, ptr %l8, !tbaa !27
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:Emitter", ptr %t29, i32 0, i32 58
  store ptr %t31, ptr %l24, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 15
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l27
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2femit_2efnTypeOf(ptr %s0, ptr %v0, { i64, ptr } %t37)
  store { i64, ptr } %t39, ptr %l29
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t47, i64 %t48, { i64, ptr } %t46)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t50, { i64, ptr } %t51, i64 %t52, { i64, ptr } %a6, { i64, ptr } %t54)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 9
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t1)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 9
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a1, 1
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t24)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb3
bb3:
  %t29 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %a2, 1
  %t33 = extractvalue { i64, ptr } %a2, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t29, i64 %t30)
  %t39 = getelementptr i8, ptr %t38, i64 %t30
  call void @olang_textcopy(ptr %t39, ptr %t32, i64 %t33)
  %t40 = getelementptr i8, ptr %t39, i64 %t33
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t49)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb6
bb6:
  %t55 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t55, ptr %l17
  br label %bb7
bb7:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %l18, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l19, !tbaa !24
  %t59 = load i64, ptr %l19, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l20, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l19, !tbaa !24
  %t69 = mul i64 %t68, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t70, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t71 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 21
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %t4, 1
  %t9 = extractvalue { i64, ptr } %t4, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t5, i64 %t6)
  %t15 = getelementptr i8, ptr %t14, i64 %t6
  call void @olang_textcopy(ptr %t15, ptr %t8, i64 %t9)
  %t16 = getelementptr i8, ptr %t15, i64 %t9
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t14, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 66
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroups(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l98 = alloca i64
  %l104 = alloca i64
  %l110 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l137 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i1
  %l148 = alloca i64
  %l150 = alloca i64
  %l160 = alloca i64
  %l162 = alloca i64
  %l167 = alloca i64
  %l168 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i32
  %l180 = alloca %"compiler/emit:Reused"
  %l182 = alloca i64
  %l184 = alloca i64
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i32
  %l198 = alloca i1
  %l202 = alloca i64
  %l205 = alloca i1
  %l209 = alloca i1
  %l228 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l229 = alloca i64
  %l231 = alloca i64
  %l236 = alloca i64
  %l242 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l251 = alloca i64
  %l254 = alloca i64
  %l272 = alloca { i64, ptr }
  %l276 = alloca i64
  %l278 = alloca ptr
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l283 = alloca i64
  %l284 = alloca { i64, ptr }
  %l287 = alloca i64
  %l288 = alloca i64
  %l293 = alloca i64
  %l294 = alloca i32
  %l300 = alloca i64
  %l307 = alloca i1
  %l317 = alloca i1
  %l321 = alloca i1
  %l324 = alloca i1
  %l334 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l337 = alloca i64
  %l341 = alloca i64
  %l344 = alloca i64
  %l365 = alloca i64
  %l371 = alloca i1
  %l377 = alloca ptr
  %l378 = alloca i64
  %l382 = alloca i64
  %l383 = alloca i32
  %l388 = alloca i64
  %l390 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i1
  %l400 = alloca ptr
  %l401 = alloca i64
  %l404 = alloca i64
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %t101 = alloca i64
  %t126 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 7
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l61
  br label %bb1
bb1:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %l1)
  store i64 %t26, ptr %l63
  br label %bb2
bb2:
  %t27 = load i64, ptr %l63, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l70, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l70, !tbaa !24
  store i64 %t54, ptr %l67, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l67, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l2, !tbaa !24
  %t78 = icmp ne i64 %t74, %t75
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t80)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  %t87 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t87)
  br label %bb19
bb19:
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %l1)
  store i64 %t91, ptr %l98
  br label %bb20
bb20:
  %t92 = load i64, ptr %l98, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb21, label %bb22
bb21:
  %t95 = load i64, ptr %l98, !tbaa !24
  %t96 = icmp sle i64 %t95, 1152921504606846975
  br i1 %t96, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb23:
  %t98 = load i64, ptr %l98, !tbaa !24
  %t99 = mul i64 %t98, 8
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  store i64 0, ptr %t101
  br label %fill.102
fill.102:
  %t105 = load i64, ptr %t101
  %t106 = icmp slt i64 %t105, %t98
  br i1 %t106, label %fillb.103, label %filld.104
fillb.103:
  %t107 = getelementptr i64, ptr %t100, i64 %t105
  store i64 -1, ptr %t107
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %t101
  br label %fill.102
filld.104:
  %t109 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t100, 1
  store { i64, ptr } %t110, ptr %l10, !tbaa !27
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/emit:Emitter", ptr %t112, i32 0, i32 15
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l104
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb25:
  %t117 = load i64, ptr %l104, !tbaa !24
  %t118 = icmp sge i64 %t117, 0
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t120 = load i64, ptr %l104, !tbaa !24
  %t121 = icmp sle i64 %t120, 1152921504606846975
  br i1 %t121, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb28:
  %t123 = load i64, ptr %l104, !tbaa !24
  %t124 = mul i64 %t123, 8
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  store i64 0, ptr %t126
  br label %fill.127
fill.127:
  %t130 = load i64, ptr %t126
  %t131 = icmp slt i64 %t130, %t123
  br i1 %t131, label %fillb.128, label %filld.129
fillb.128:
  %t132 = getelementptr i64, ptr %t125, i64 %t130
  store i64 -1, ptr %t132
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %t126
  br label %fill.127
filld.129:
  %t134 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t125, 1
  store { i64, ptr } %t135, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/emit:Emitter", ptr %t137, i32 0, i32 15
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l110
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb30:
  %t142 = load i64, ptr %l110, !tbaa !24
  store i64 %t142, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t144 = load i64, ptr %l12, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb31, label %bb32
bb31:
  %t149 = load i64, ptr %l14, !tbaa !24
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb36
bb33:
  %t153 = load i64, ptr %l13, !tbaa !24
  %t154 = load i64, ptr %l12, !tbaa !24
  %t157 = sub i64 %t153, %t154
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t163 = sub i64 %t161, 1
  %t164 = load i64, ptr %l14, !tbaa !24
  %t167 = sdiv i64 %t163, %t164
  store i64 %t167, ptr %l117, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb35
bb35:
  %t169 = load i64, ptr %l117, !tbaa !24
  store i64 %t169, ptr %l114, !tbaa !24
  br label %bb36
bb36:
  %t170 = load i64, ptr %l114, !tbaa !24
  store i64 %t170, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l16, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = mul i64 %t180, %t181
  %t187 = add i64 %t179, %t184
  store i64 %t187, ptr %l17, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:Emitter", ptr %t189, i32 0, i32 15
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t191)
  store i64 %t193, ptr %l137
  br label %bb41
bb41:
  %t194 = load i64, ptr %l137, !tbaa !24
  %t195 = sub i64 %t194, 1
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = sub i64 %t195, %t196
  store i64 %t199, ptr %l18, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %t201, i32 0, i32 17
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t203, i64 %t204)
  store i64 %t207, ptr %l144
  br label %bb42
bb42:
  %t208 = load i64, ptr %l144, !tbaa !24
  store i64 %t208, ptr %l19, !tbaa !24
  %t209 = load i64, ptr %l19, !tbaa !24
  %t211 = icmp sge i64 %t209, 0
  br i1 %t211, label %bb43, label %bb44
bb43:
  %t213 = load i64, ptr %l19, !tbaa !24
  store i64 %t213, ptr %l148, !tbaa !24
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %l1)
  store i64 %t215, ptr %l150
  br label %bb45
bb44:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb46
bb45:
  %t216 = load i64, ptr %l148, !tbaa !24
  %t217 = load i64, ptr %l150, !tbaa !24
  %t218 = icmp slt i64 %t216, %t217
  store i1 %t218, ptr %l147, !tbaa !21
  br label %bb46
bb46:
  %t220 = load i1, ptr %l147, !tbaa !21
  br i1 %t220, label %bb47, label %bb48
bb47:
  %t221 = load i64, ptr %l18, !tbaa !24
  %t222 = load i64, ptr %l19, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t222
  %t227 = load i64, ptr %t226, !tbaa !34
  %t230 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i64, ptr %t231, i64 %t221
  store i64 %t227, ptr %t232, !tbaa !34
  %t233 = load i64, ptr %l19, !tbaa !24
  %t234 = load i64, ptr %l18, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i64, ptr %t238, i64 %t233
  store i64 %t234, ptr %t239, !tbaa !34
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t240 = load i64, ptr %l16, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l16, !tbaa !24
  br label %bb37
bb51:
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i64, ptr %l21, !tbaa !24
  store i64 %t245, ptr %l160, !tbaa !24
  %t246 = load ptr, ptr %l20, !tbaa !29
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t246)
  store i64 %t248, ptr %l162
  br label %bb53
bb53:
  %t249 = load i64, ptr %l160, !tbaa !24
  %t250 = load i64, ptr %l162, !tbaa !24
  %t251 = icmp slt i64 %t249, %t250
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb161
bb55:
  br label %bb56
bb56:
  %t255 = load ptr, ptr %l20, !tbaa !29
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t255, i64 %t256)
  store i64 %t259, ptr %l167
  br label %bb57
bb57:
  %t260 = load i64, ptr %l167, !tbaa !24
  store i64 %t260, ptr %l22, !tbaa !24
  %t261 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t261, ptr %l168
  br label %bb58
bb58:
  %t262 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t262, ptr %l23
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:Emitter", ptr %t263, i32 0, i32 61
  %t266 = load i64, ptr %l22, !tbaa !24
  %t269 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t265, i64 %t266)
  %t270 = extractvalue { i32, i64 } %t269, 1
  %t271 = extractvalue { i32, i64 } %t269, 0
  store i32 %t271, ptr %l174
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb60, label %ok.273
ok.273:
  store i64 %t270, ptr %l173
  br label %bb59
bb59:
  %t274 = load i64, ptr %l173, !tbaa !24
  store i64 %t274, ptr %l169, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l169, !tbaa !24
  br label %bb62
bb62:
  %t275 = load i64, ptr %l169, !tbaa !24
  store i64 %t275, ptr %l24, !tbaa !24
  %t276 = load i64, ptr %l24, !tbaa !24
  %t278 = icmp sge i64 %t276, 0
  br i1 %t278, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/emit:Emitter", ptr %t280, i32 0, i32 60
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = call %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t282, i64 %t283)
  store %"compiler/emit:Reused" %t286, ptr %l180
  br label %bb65
bb64:
  %t287 = load i64, ptr %l22, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i64, ptr %t290, i64 %t287
  %t292 = load i64, ptr %t291, !tbaa !34
  store i64 %t292, ptr %l29, !tbaa !24
  br label %bb91
bb65:
  %t294 = getelementptr %"compiler/emit:Reused", ptr %l180, i32 0, i32 6
  store ptr %t294, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb66
bb66:
  %t296 = load i64, ptr %l26, !tbaa !24
  store i64 %t296, ptr %l182, !tbaa !24
  %t297 = load ptr, ptr %l25, !tbaa !29
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s12, ptr %t297)
  store i64 %t299, ptr %l184
  br label %bb67
bb67:
  %t300 = load i64, ptr %l182, !tbaa !24
  %t301 = load i64, ptr %l184, !tbaa !24
  %t302 = icmp slt i64 %t300, %t301
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb68, label %bb69
bb68:
  br label %bb90
bb69:
  br label %bb70
bb70:
  %t306 = load ptr, ptr %l25, !tbaa !29
  %t307 = load i64, ptr %l26, !tbaa !24
  %t310 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s12, ptr %s12, ptr %t306, i64 %t307)
  store { i64, ptr } %t310, ptr %l189
  br label %bb71
bb71:
  %t311 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/emit:Emitter", ptr %t312, i32 0, i32 19
  %t318 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s12, ptr %t314, { i64, ptr } %t311)
  %t319 = extractvalue { i32, i64 } %t318, 1
  %t320 = extractvalue { i32, i64 } %t318, 0
  store i32 %t320, ptr %l195
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb73, label %ok.322
ok.322:
  store i64 %t319, ptr %l194
  br label %bb72
bb72:
  %t323 = load i64, ptr %l194, !tbaa !24
  store i64 %t323, ptr %l190, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l190, !tbaa !24
  br label %bb75
bb75:
  %t324 = load i64, ptr %l190, !tbaa !24
  store i64 %t324, ptr %l28, !tbaa !24
  %t325 = load i64, ptr %l28, !tbaa !24
  %t327 = icmp sge i64 %t325, 0
  br i1 %t327, label %bb76, label %bb77
bb76:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/emit:Emitter", ptr %t329, i32 0, i32 17
  %t332 = load i64, ptr %l28, !tbaa !24
  %t335 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  store i64 %t335, ptr %l202
  br label %bb78
bb77:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb79
bb78:
  %t336 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t337 = load i64, ptr %l202, !tbaa !24
  %t339 = icmp eq i64 %t337, %t336
  store i1 %t339, ptr %l198, !tbaa !21
  br label %bb79
bb79:
  %t341 = load i1, ptr %l198, !tbaa !21
  br i1 %t341, label %bb80, label %bb81
bb80:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/emit:Emitter", ptr %t342, i32 0, i32 66
  %t345 = load i64, ptr %l28, !tbaa !24
  %t348 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t344, i64 %t345)
  store i1 %t348, ptr %l209
  br label %bb82
bb81:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb83
bb82:
  %t349 = load i1, ptr %l209, !tbaa !21
  %t350 = xor i1 %t349, true
  store i1 %t350, ptr %l205, !tbaa !21
  br label %bb83
bb83:
  %t352 = load i1, ptr %l205, !tbaa !21
  br i1 %t352, label %bb84, label %bb85
bb84:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/emit:Emitter", ptr %t353, i32 0, i32 66
  %t356 = load i64, ptr %l28, !tbaa !24
  %t357 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t355, i64 %t356, i64 %t357)
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t361 = load i64, ptr %l28, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t361)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t364 = load i64, ptr %l26, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l26, !tbaa !24
  br label %bb66
bb90:
  call void @__olang_scope_close(ptr %s12)
  br label %bb98
bb91:
  %t368 = load i64, ptr %l29, !tbaa !24
  %t370 = icmp sge i64 %t368, 0
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb92, label %bb93
bb92:
  br label %bb97
bb93:
  br label %bb94
bb94:
  %t374 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t374)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t379 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr i64, ptr %t380, i64 %t377
  %t382 = load i64, ptr %t381, !tbaa !34
  store i64 %t382, ptr %l29, !tbaa !24
  br label %bb91
bb97:
  br label %bb98
bb98:
  %t384 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s10)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t384, ptr %l228
  br label %bb99
bb99:
  %t385 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l228
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  br label %bb100
bb100:
  %t386 = load i64, ptr %l31, !tbaa !24
  store i64 %t386, ptr %l229, !tbaa !24
  %t388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %l23)
  store i64 %t388, ptr %l231
  br label %bb101
bb101:
  %t389 = load i64, ptr %l229, !tbaa !24
  %t390 = load i64, ptr %l231, !tbaa !24
  %t391 = icmp slt i64 %t389, %t390
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb102, label %bb103
bb102:
  br label %bb159
bb103:
  br label %bb104
bb104:
  %t395 = load i64, ptr %l31, !tbaa !24
  %t398 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %l23, i64 %t395)
  store i64 %t398, ptr %l236
  br label %bb105
bb105:
  %t399 = load i64, ptr %l236, !tbaa !24
  store i64 %t399, ptr %l32, !tbaa !24
  %t400 = load i64, ptr %l31, !tbaa !24
  %t402 = add i64 %t400, 1
  store i64 %t402, ptr %l31, !tbaa !24
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/emit:Emitter", ptr %t404, i32 0, i32 16
  %t407 = load i64, ptr %l32, !tbaa !24
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t406, i64 %t407)
  store { i64, ptr } %t410, ptr %l242
  br label %bb106
bb106:
  %t411 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t411, ptr %l33, !tbaa !27
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i64, ptr %l32, !tbaa !24
  %t416 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %t412, i64 %t413)
  store { i64, ptr } %t416, ptr %l245
  br label %bb107
bb107:
  %t417 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t417, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t418 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t418, 0
  store i64 %t420, ptr %l36, !tbaa !24
  store i64 3, ptr %l37, !tbaa !24
  %t422 = load i64, ptr %l36, !tbaa !24
  %t423 = load i64, ptr %l35, !tbaa !24
  %t426 = icmp sgt i64 %t422, %t423
  br i1 %t426, label %bb108, label %bb109
bb108:
  %t428 = load i64, ptr %l37, !tbaa !24
  %t430 = icmp sgt i64 %t428, 0
  br i1 %t430, label %bb110, label %bb111
bb109:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb113
bb110:
  %t432 = load i64, ptr %l36, !tbaa !24
  %t433 = load i64, ptr %l35, !tbaa !24
  %t436 = sub i64 %t432, %t433
  %t437 = load i64, ptr %l37, !tbaa !24
  %t440 = add i64 %t436, %t437
  %t442 = sub i64 %t440, 1
  %t443 = load i64, ptr %l37, !tbaa !24
  %t446 = sdiv i64 %t442, %t443
  store i64 %t446, ptr %l254, !tbaa !24
  br label %bb112
bb111:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb112
bb112:
  %t448 = load i64, ptr %l254, !tbaa !24
  store i64 %t448, ptr %l251, !tbaa !24
  br label %bb113
bb113:
  %t449 = load i64, ptr %l251, !tbaa !24
  store i64 %t449, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb114
bb114:
  %t450 = load i64, ptr %l39, !tbaa !24
  %t451 = load i64, ptr %l38, !tbaa !24
  %t454 = icmp slt i64 %t450, %t451
  %t456 = xor i1 %t454, true
  br i1 %t456, label %bb115, label %bb116
bb115:
  br label %bb157
bb116:
  br label %bb117
bb117:
  %t458 = load i64, ptr %l35, !tbaa !24
  %t459 = load i64, ptr %l39, !tbaa !24
  %t460 = load i64, ptr %l37, !tbaa !24
  %t463 = mul i64 %t459, %t460
  %t466 = add i64 %t458, %t463
  store i64 %t466, ptr %l40, !tbaa !24
  %t468 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t468, ptr %l272, !tbaa !27
  %t469 = load i64, ptr %l40, !tbaa !24
  %t471 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr i64, ptr %t472, i64 %t469
  %t474 = load i64, ptr %t473, !tbaa !34
  %t476 = icmp ne i64 %t474, 0
  br i1 %t476, label %bb118, label %bb119
bb118:
  br label %bb156
bb119:
  br label %bb120
bb120:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/emit:Emitter", ptr %t478, i32 0, i32 19
  store ptr %t480, ptr %l278, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t481, ptr %l279, !tbaa !27
  %t482 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t482, ptr %l280, !tbaa !27
  %t483 = load i64, ptr %l40, !tbaa !24
  %t485 = add i64 %t483, 1
  %t487 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr i64, ptr %t488, i64 %t485
  %t490 = load i64, ptr %t489, !tbaa !34
  store i64 %t490, ptr %l283, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t491, ptr %l284, !tbaa !27
  %t492 = load i64, ptr %l40, !tbaa !24
  %t494 = add i64 %t492, 2
  %t496 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !27
  %t498 = getelementptr i64, ptr %t497, i64 %t494
  %t499 = load i64, ptr %t498, !tbaa !34
  store i64 %t499, ptr %l287, !tbaa !24
  %t500 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t500, 0
  store i64 %t501, ptr %l288, !tbaa !24
  %t502 = load i64, ptr %l283, !tbaa !24
  %t503 = icmp sge i64 %t502, 0
  br i1 %t503, label %bb121, label %bb122
bb121:
  %t505 = load i64, ptr %l283, !tbaa !24
  %t506 = load i64, ptr %l287, !tbaa !24
  %t507 = icmp sle i64 %t505, %t506
  br i1 %t507, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_ccff4b50b9448573_2ea1a60810f956ef)
  unreachable
bb123:
  %t509 = load i64, ptr %l287, !tbaa !24
  %t510 = load i64, ptr %l288, !tbaa !24
  %t511 = icmp sle i64 %t509, %t510
  br i1 %t511, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_ccff4b50b9448573_2ea1a60810f956ef)
  unreachable
bb125:
  %t513 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = load i64, ptr %l283, !tbaa !24
  %t516 = load i64, ptr %l287, !tbaa !24
  %t517 = getelementptr i8, ptr %t514, i64 %t515
  %t518 = sub i64 %t516, %t515
  %t519 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t517, 1
  %t521 = load ptr, ptr %l278, !tbaa !29
  %t523 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t521, { i64, ptr } %t520)
  %t524 = extractvalue { i32, i64 } %t523, 1
  %t525 = extractvalue { i32, i64 } %t523, 0
  store i32 %t525, ptr %l294
  %t526 = icmp ne i32 %t525, 0
  br i1 %t526, label %bb128, label %ok.527
ok.527:
  store i64 %t524, ptr %l293
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_ccff4b50b9448573_2ea1a60810f956ef)
  unreachable
bb127:
  %t528 = load i64, ptr %l293, !tbaa !24
  store i64 %t528, ptr %l276, !tbaa !24
  br label %bb130
bb128:
  br label %bb129
bb129:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l276, !tbaa !24
  br label %bb130
bb130:
  %t529 = load i64, ptr %l276, !tbaa !24
  store i64 %t529, ptr %l41, !tbaa !24
  %t530 = load i64, ptr %l41, !tbaa !24
  %t532 = icmp slt i64 %t530, 0
  br i1 %t532, label %bb131, label %bb132
bb131:
  br label %bb156
bb132:
  br label %bb133
bb133:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/emit:Emitter", ptr %t534, i32 0, i32 17
  %t537 = load i64, ptr %l41, !tbaa !24
  %t540 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t536, i64 %t537)
  store i64 %t540, ptr %l300
  br label %bb134
bb134:
  %t541 = load i64, ptr %l300, !tbaa !24
  store i64 %t541, ptr %l42, !tbaa !24
  %t542 = load i64, ptr %l42, !tbaa !24
  %t543 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t546 = icmp eq i64 %t542, %t543
  br i1 %t546, label %bb135, label %bb136
bb135:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = getelementptr %"compiler/emit:Emitter", ptr %t548, i32 0, i32 66
  %t551 = load i64, ptr %l41, !tbaa !24
  %t554 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t550, i64 %t551)
  store i1 %t554, ptr %l307
  br label %bb137
bb136:
  %t555 = load i64, ptr %l42, !tbaa !24
  %t556 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t559 = icmp eq i64 %t555, %t556
  br i1 %t559, label %bb143, label %bb144
bb137:
  %t561 = load i1, ptr %l307, !tbaa !21
  br i1 %t561, label %bb138, label %bb139
bb138:
  br label %bb156
bb139:
  br label %bb140
bb140:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/emit:Emitter", ptr %t562, i32 0, i32 66
  %t565 = load i64, ptr %l41, !tbaa !24
  %t566 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t564, i64 %t565, i64 %t566)
  br label %bb141
bb141:
  %t570 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t570)
  br label %bb142
bb142:
  br label %bb155
bb143:
  store i1 true, ptr %l317, !tbaa !21
  br label %bb145
bb144:
  %t573 = load i64, ptr %l42, !tbaa !24
  %t574 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t577 = icmp eq i64 %t573, %t574
  store i1 %t577, ptr %l317, !tbaa !21
  br label %bb145
bb145:
  %t579 = load i1, ptr %l317, !tbaa !21
  br i1 %t579, label %bb146, label %bb147
bb146:
  %t580 = load i64, ptr %l41, !tbaa !24
  %t583 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s10, ptr %l30, i64 %t580)
  store i1 %t583, ptr %l324
  br label %bb148
bb147:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb149
bb148:
  %t584 = load i1, ptr %l324, !tbaa !21
  %t585 = xor i1 %t584, true
  store i1 %t585, ptr %l321, !tbaa !21
  br label %bb149
bb149:
  %t587 = load i1, ptr %l321, !tbaa !21
  br i1 %t587, label %bb150, label %bb151
bb150:
  %t588 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s10, ptr %l30, i64 %t588, i1 true)
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t591 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s10, ptr %l23, i64 %t591)
  br label %bb153
bb153:
  br label %bb154
bb154:
  br label %bb155
bb155:
  br label %bb156
bb156:
  %t594 = load i64, ptr %l39, !tbaa !24
  %t596 = add i64 %t594, 1
  store i64 %t596, ptr %l39, !tbaa !24
  br label %bb114
bb157:
  br label %bb158
bb158:
  br label %bb100
bb159:
  call void @__olang_scope_close(ptr %s10)
  br label %bb160
bb160:
  %t598 = load i64, ptr %l21, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l21, !tbaa !24
  br label %bb52
bb161:
  %t602 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t602, ptr %l334
  br label %bb162
bb162:
  %t603 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l334
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t603, ptr %l43
  store i64 0, ptr %l44, !tbaa !24
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/emit:Emitter", ptr %t604, i32 0, i32 15
  %t608 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t606)
  store i64 %t608, ptr %l337
  br label %bb163
bb163:
  %t609 = load i64, ptr %l337, !tbaa !24
  store i64 %t609, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t610 = load i64, ptr %l45, !tbaa !24
  %t611 = load i64, ptr %l44, !tbaa !24
  %t614 = icmp sgt i64 %t610, %t611
  br i1 %t614, label %bb164, label %bb165
bb164:
  %t616 = load i64, ptr %l46, !tbaa !24
  %t618 = icmp sgt i64 %t616, 0
  br i1 %t618, label %bb166, label %bb167
bb165:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb169
bb166:
  %t620 = load i64, ptr %l45, !tbaa !24
  %t621 = load i64, ptr %l44, !tbaa !24
  %t624 = sub i64 %t620, %t621
  %t625 = load i64, ptr %l46, !tbaa !24
  %t628 = add i64 %t624, %t625
  %t630 = sub i64 %t628, 1
  %t631 = load i64, ptr %l46, !tbaa !24
  %t634 = sdiv i64 %t630, %t631
  store i64 %t634, ptr %l344, !tbaa !24
  br label %bb168
bb167:
  store i64 0, ptr %l344, !tbaa !24
  br label %bb168
bb168:
  %t636 = load i64, ptr %l344, !tbaa !24
  store i64 %t636, ptr %l341, !tbaa !24
  br label %bb169
bb169:
  %t637 = load i64, ptr %l341, !tbaa !24
  store i64 %t637, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb170
bb170:
  %t638 = load i64, ptr %l48, !tbaa !24
  %t639 = load i64, ptr %l47, !tbaa !24
  %t642 = icmp slt i64 %t638, %t639
  %t644 = xor i1 %t642, true
  br i1 %t644, label %bb171, label %bb172
bb171:
  br label %bb189
bb172:
  br label %bb173
bb173:
  %t646 = load i64, ptr %l44, !tbaa !24
  %t647 = load i64, ptr %l48, !tbaa !24
  %t648 = load i64, ptr %l46, !tbaa !24
  %t651 = mul i64 %t647, %t648
  %t654 = add i64 %t646, %t651
  store i64 %t654, ptr %l49, !tbaa !24
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = getelementptr %"compiler/emit:Emitter", ptr %t656, i32 0, i32 17
  %t659 = load i64, ptr %l49, !tbaa !24
  %t662 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t658, i64 %t659)
  store i64 %t662, ptr %l365
  br label %bb174
bb174:
  %t663 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t664 = load i64, ptr %l365, !tbaa !24
  %t666 = icmp ne i64 %t664, %t663
  br i1 %t666, label %bb175, label %bb176
bb175:
  br label %bb188
bb176:
  br label %bb177
bb177:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = getelementptr %"compiler/emit:Emitter", ptr %t668, i32 0, i32 66
  %t671 = load i64, ptr %l49, !tbaa !24
  %t674 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t670, i64 %t671)
  store i1 %t674, ptr %l371
  br label %bb178
bb178:
  %t675 = load i1, ptr %l371, !tbaa !21
  %t676 = xor i1 %t675, true
  br i1 %t676, label %bb179, label %bb180
bb179:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/emit:Emitter", ptr %t678, i32 0, i32 66
  %t681 = load i64, ptr %l49, !tbaa !24
  %t682 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t680, i64 %t681, i64 %t682)
  br label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb182
bb182:
  store ptr %l43, ptr %l377, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/emit:Emitter", ptr %t686, i32 0, i32 66
  %t689 = load i64, ptr %l49, !tbaa !24
  %t692 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t688, i64 %t689)
  %t693 = extractvalue { i32, i64 } %t692, 1
  %t694 = extractvalue { i32, i64 } %t692, 0
  store i32 %t694, ptr %l383
  %t695 = icmp ne i32 %t694, 0
  br i1 %t695, label %bb184, label %ok.696
ok.696:
  store i64 %t693, ptr %l382
  br label %bb183
bb183:
  %t697 = load i64, ptr %l382, !tbaa !24
  store i64 %t697, ptr %l378, !tbaa !24
  br label %bb186
bb184:
  br label %bb185
bb185:
  call void @__olang_ert_req_clear()
  %t698 = load i64, ptr %l2, !tbaa !24
  store i64 %t698, ptr %l378, !tbaa !24
  br label %bb186
bb186:
  %t700 = load ptr, ptr %l377, !tbaa !29
  %t701 = load i64, ptr %l378, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t700, i64 %t701, i1 true)
  br label %bb187
bb187:
  br label %bb188
bb188:
  %t702 = load i64, ptr %l48, !tbaa !24
  %t704 = add i64 %t702, 1
  store i64 %t704, ptr %l48, !tbaa !24
  br label %bb170
bb189:
  store ptr %l3, ptr %l50, !tbaa !29
  store i64 0, ptr %l51, !tbaa !24
  br label %bb190
bb190:
  %t707 = load i64, ptr %l51, !tbaa !24
  store i64 %t707, ptr %l388, !tbaa !24
  %t708 = load ptr, ptr %l50, !tbaa !29
  %t710 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t708)
  store i64 %t710, ptr %l390
  br label %bb191
bb191:
  %t711 = load i64, ptr %l388, !tbaa !24
  %t712 = load i64, ptr %l390, !tbaa !24
  %t713 = icmp slt i64 %t711, %t712
  %t715 = xor i1 %t713, true
  br i1 %t715, label %bb192, label %bb193
bb192:
  br label %bb204
bb193:
  br label %bb194
bb194:
  %t717 = load ptr, ptr %l50, !tbaa !29
  %t718 = load i64, ptr %l51, !tbaa !24
  %t721 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t717, i64 %t718)
  store i64 %t721, ptr %l395
  br label %bb195
bb195:
  %t722 = load i64, ptr %l395, !tbaa !24
  store i64 %t722, ptr %l52, !tbaa !24
  %t723 = load i64, ptr %l52, !tbaa !24
  %t726 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l43, i64 %t723)
  store i1 %t726, ptr %l398
  br label %bb196
bb196:
  %t727 = load i1, ptr %l398, !tbaa !21
  br i1 %t727, label %bb197, label %bb198
bb197:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/emit:Emitter", ptr %t728, i32 0, i32 68
  store ptr %t730, ptr %l400, !tbaa !29
  %t731 = load i64, ptr %l52, !tbaa !24
  store i64 %t731, ptr %l401, !tbaa !24
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t734 = getelementptr %"compiler/emit:Emitter", ptr %t732, i32 0, i32 67
  %t736 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t734)
  store i64 %t736, ptr %l404
  br label %bb199
bb198:
  br label %bb202
bb199:
  %t737 = load ptr, ptr %l400, !tbaa !29
  %t738 = load i64, ptr %l401, !tbaa !24
  %t739 = load i64, ptr %l404, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t737, i64 %t738, i64 %t739)
  br label %bb200
bb200:
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t742 = getelementptr %"compiler/emit:Emitter", ptr %t740, i32 0, i32 67
  %t743 = load i64, ptr %l52, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t742, i64 %t743)
  br label %bb201
bb201:
  br label %bb202
bb202:
  br label %bb203
bb203:
  %t746 = load i64, ptr %l51, !tbaa !24
  %t748 = add i64 %t746, 1
  store i64 %t748, ptr %l51, !tbaa !24
  br label %bb190
bb204:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i64 %a4, i1 %a5, i1 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca i64
  %l57 = alloca i64
  %l76 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l124 = alloca i64
  %l127 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i64
  %l136 = alloca i64
  %l140 = alloca { i64, ptr }
  %l147 = alloca i64
  %l154 = alloca i64
  %l165 = alloca i1
  %l172 = alloca i64
  %l175 = alloca i64
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca i32
  %l221 = alloca { i64, ptr }
  %l223 = alloca %"compiler/emit:Object"
  %l229 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l241 = alloca { i64, ptr }
  %l243 = alloca %"compiler/emit:Object"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l6, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 4
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l37, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l37, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t9, %t19
  store i1 %t22, ptr %l40, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l40, !tbaa !21
  store i1 %t24, ptr %l9, !tbaa !21
  %t25 = load i1, ptr %l9, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i64 2, ptr %l48, !tbaa !24
  br label %bb9
bb8:
  store i64 1, ptr %l48, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l48, !tbaa !24
  store i64 %t27, ptr %l10, !tbaa !24
  %t28 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l49
  br label %bb10
bb10:
  %t29 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l10, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = load i64, ptr %l12, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l14, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb13:
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = load i64, ptr %l12, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l14, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l14, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l57, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l57, !tbaa !24
  store i64 %t58, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t59 = load i64, ptr %l54, !tbaa !24
  store i64 %t59, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  %t60 = load i64, ptr %l16, !tbaa !24
  %t61 = load i64, ptr %l15, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb99
bb19:
  br label %bb20
bb20:
  %t68 = load i64, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l16, !tbaa !24
  %t70 = load i64, ptr %l14, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l17, !tbaa !24
  %t78 = load i1, ptr %l9, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = load i64, ptr %l17, !tbaa !24
  store i64 %t80, ptr %l76, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l76, !tbaa !24
  br label %bb23
bb23:
  %t82 = load i64, ptr %l76, !tbaa !24
  store i64 %t82, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t83, i32 0, i32 15
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l80
  br label %bb24
bb24:
  %t88 = load i64, ptr %l80, !tbaa !24
  store i64 %t88, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t89 = load i64, ptr %l21, !tbaa !24
  %t90 = load i64, ptr %l20, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load i64, ptr %l22, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb30
bb27:
  %t99 = load i64, ptr %l21, !tbaa !24
  %t100 = load i64, ptr %l20, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l22, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l22, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l87, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb29
bb29:
  %t115 = load i64, ptr %l87, !tbaa !24
  store i64 %t115, ptr %l84, !tbaa !24
  br label %bb30
bb30:
  %t116 = load i64, ptr %l84, !tbaa !24
  store i64 %t116, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb31
bb31:
  %t117 = load i64, ptr %l24, !tbaa !24
  %t118 = load i64, ptr %l23, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb32, label %bb33
bb32:
  br label %bb61
bb33:
  br label %bb34
bb34:
  %t125 = load i64, ptr %l20, !tbaa !24
  %t126 = load i64, ptr %l24, !tbaa !24
  %t127 = load i64, ptr %l22, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l25, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/emit:Emitter", ptr %t135, i32 0, i32 17
  %t138 = load i64, ptr %l25, !tbaa !24
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l108
  br label %bb35
bb35:
  %t142 = load i64, ptr %l108, !tbaa !24
  store i64 %t142, ptr %l26, !tbaa !24
  %t143 = load i64, ptr %l26, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  %t147 = icmp eq i64 %t143, %t144
  br i1 %t147, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb41
bb37:
  %t149 = load i1, ptr %l5, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  %t151 = load i64, ptr %l26, !tbaa !24
  %t152 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t155 = icmp eq i64 %t151, %t152
  store i1 %t155, ptr %l114, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb40
bb40:
  %t157 = load i1, ptr %l114, !tbaa !21
  store i1 %t157, ptr %l112, !tbaa !21
  br label %bb41
bb41:
  %t158 = load i1, ptr %l112, !tbaa !21
  br i1 %t158, label %bb42, label %bb43
bb42:
  %t159 = load i64, ptr %l18, !tbaa !24
  %t161 = icmp slt i64 %t159, 0
  br i1 %t161, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb48
bb44:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb47
bb45:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr %l25, !tbaa !24
  %t167 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l124
  br label %bb46
bb46:
  %t168 = load i64, ptr %l18, !tbaa !24
  %t169 = load i64, ptr %l124, !tbaa !24
  %t171 = icmp eq i64 %t169, %t168
  store i1 %t171, ptr %l121, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l121, !tbaa !21
  store i1 %t173, ptr %l118, !tbaa !21
  br label %bb48
bb48:
  %t174 = load i1, ptr %l118, !tbaa !21
  br i1 %t174, label %bb49, label %bb50
bb49:
  %t175 = load i64, ptr %l8, !tbaa !24
  %t177 = icmp slt i64 %t175, 0
  br i1 %t177, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb54
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l25, !tbaa !24
  %t183 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t179, i64 %t180)
  store i64 %t183, ptr %l133
  br label %bb53
bb53:
  %t184 = load i64, ptr %l8, !tbaa !24
  %t185 = load i64, ptr %l133, !tbaa !24
  %t187 = icmp eq i64 %t185, %t184
  store i1 %t187, ptr %l130, !tbaa !21
  br label %bb54
bb54:
  %t189 = load i1, ptr %l130, !tbaa !21
  store i1 %t189, ptr %l127, !tbaa !21
  br label %bb55
bb55:
  %t190 = load i1, ptr %l127, !tbaa !21
  br i1 %t190, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t191 = load i64, ptr %l19, !tbaa !24
  store i64 %t191, ptr %l136, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/emit:Emitter", ptr %t192, i32 0, i32 16
  %t195 = load i64, ptr %l25, !tbaa !24
  %t198 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s5, ptr %t194, i64 %t195)
  store { i64, ptr } %t198, ptr %l140
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t199 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = load i64, ptr %l136, !tbaa !24
  %t203 = add i64 %t201, %t200
  store i64 %t203, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t205 = load i64, ptr %l24, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l24, !tbaa !24
  br label %bb31
bb61:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t211 = icmp eq i64 %t209, 1
  br i1 %t211, label %bb62, label %bb63
bb62:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/emit:Emitter", ptr %t213, i32 0, i32 40
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = sdiv i64 %t216, 4
  store i64 %t218, ptr %l147, !tbaa !24
  br label %bb64
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/emit:Emitter", ptr %t220, i32 0, i32 40
  %t223 = load i64, ptr %t222, !tbaa !24
  store i64 %t223, ptr %l147, !tbaa !24
  br label %bb64
bb64:
  %t225 = load i64, ptr %l147, !tbaa !24
  store i64 %t225, ptr %l27, !tbaa !24
  %t226 = load i1, ptr %l6, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t229 = load i64, ptr %l27, !tbaa !24
  %t232 = add i64 %t228, %t229
  %t234 = sub i64 %t232, 1
  %t235 = load i64, ptr %l27, !tbaa !24
  %t238 = sdiv i64 %t234, %t235
  store i64 %t238, ptr %l154, !tbaa !24
  br label %bb67
bb66:
  store i64 1, ptr %l154, !tbaa !24
  br label %bb67
bb67:
  %t240 = load i64, ptr %l154, !tbaa !24
  store i64 %t240, ptr %l28, !tbaa !24
  %t241 = load i64, ptr %l28, !tbaa !24
  %t243 = icmp slt i64 %t241, 1
  br i1 %t243, label %bb68, label %bb69
bb68:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t245 = load i64, ptr %l18, !tbaa !24
  %t247 = icmp eq i64 %t245, 1
  br i1 %t247, label %bb71, label %bb72
bb71:
  %t249 = load i64, ptr %l19, !tbaa !24
  %t251 = icmp eq i64 %t249, 0
  store i1 %t251, ptr %l165, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb73
bb73:
  %t253 = load i1, ptr %l165, !tbaa !21
  br i1 %t253, label %bb74, label %bb75
bb74:
  br label %bb98
bb75:
  br label %bb76
bb76:
  store i64 0, ptr %l29, !tbaa !24
  %t254 = load i64, ptr %l28, !tbaa !24
  store i64 %t254, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t256 = load i64, ptr %l30, !tbaa !24
  %t257 = load i64, ptr %l29, !tbaa !24
  %t260 = icmp sgt i64 %t256, %t257
  br i1 %t260, label %bb77, label %bb78
bb77:
  %t262 = load i64, ptr %l31, !tbaa !24
  %t264 = icmp sgt i64 %t262, 0
  br i1 %t264, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb82
bb79:
  %t266 = load i64, ptr %l30, !tbaa !24
  %t267 = load i64, ptr %l29, !tbaa !24
  %t270 = sub i64 %t266, %t267
  %t271 = load i64, ptr %l31, !tbaa !24
  %t274 = add i64 %t270, %t271
  %t276 = sub i64 %t274, 1
  %t277 = load i64, ptr %l31, !tbaa !24
  %t280 = sdiv i64 %t276, %t277
  store i64 %t280, ptr %l175, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb81
bb81:
  %t282 = load i64, ptr %l175, !tbaa !24
  store i64 %t282, ptr %l172, !tbaa !24
  br label %bb82
bb82:
  %t283 = load i64, ptr %l172, !tbaa !24
  store i64 %t283, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t284 = load i64, ptr %l33, !tbaa !24
  %t285 = load i64, ptr %l32, !tbaa !24
  %t288 = icmp slt i64 %t284, %t285
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb97
bb85:
  br label %bb86
bb86:
  %t292 = load i64, ptr %l29, !tbaa !24
  %t293 = load i64, ptr %l33, !tbaa !24
  %t294 = load i64, ptr %l31, !tbaa !24
  %t297 = mul i64 %t293, %t294
  %t300 = add i64 %t292, %t297
  store i64 %t300, ptr %l34, !tbaa !24
  %t302 = load i64, ptr %l18, !tbaa !24
  %t304 = icmp ne i64 %t302, 1
  br i1 %t304, label %bb87, label %bb88
bb87:
  %t306 = load i64, ptr %l34, !tbaa !24
  %t308 = icmp eq i64 %t306, 0
  br i1 %t308, label %bb89, label %bb90
bb88:
  %t310 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = load i64, ptr %l34, !tbaa !24
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = extractvalue { i64, ptr } %t310, 0
  %t315 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = call i64 @__olang_fmt_i64(ptr null, i64 %t311)
  %t320 = add i64 %t317, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t313, i64 %t314)
  %t322 = getelementptr i8, ptr %t321, i64 %t314
  call void @olang_textcopy(ptr %t322, ptr %t315, i64 %t316)
  %t323 = getelementptr i8, ptr %t322, i64 %t316
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t311)
  %t325 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t321, 1
  store { i64, ptr } %t326, ptr %l195, !tbaa !27
  br label %bb92
bb89:
  %t328 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = extractvalue { i64, ptr } %t328, 0
  %t332 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t331)
  call void @olang_textcopy(ptr %t332, ptr %t330, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l198, !tbaa !27
  br label %bb91
bb90:
  %t336 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t337 = load i64, ptr %l34, !tbaa !24
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = extractvalue { i64, ptr } %t336, 0
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t345 = call i64 @__olang_fmt_i64(ptr null, i64 %t337)
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t339, i64 %t340)
  %t348 = getelementptr i8, ptr %t347, i64 %t340
  call void @olang_textcopy(ptr %t348, ptr %t341, i64 %t342)
  %t349 = getelementptr i8, ptr %t348, i64 %t342
  %t350 = call i64 @__olang_fmt_i64(ptr %t349, i64 %t337)
  %t351 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t347, 1
  store { i64, ptr } %t352, ptr %l198, !tbaa !27
  br label %bb91
bb91:
  %t354 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t354, ptr %l195, !tbaa !27
  br label %bb92
bb92:
  %t355 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l207, !tbaa !29
  %t359 = extractvalue { i64, ptr } %t355, 1
  %t360 = extractvalue { i64, ptr } %t355, 0
  %t361 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t360)
  call void @olang_textcopy(ptr %t361, ptr %t359, i64 %t360)
  %t362 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = extractvalue { i64, ptr } %t363, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l210, !tbaa !27
  %t371 = load i32, ptr %l3
  store i32 %t371, ptr %l211
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i64, ptr %l4, !tbaa !24
  %t374 = load i1, ptr %l5, !tbaa !21
  %t375 = load i64, ptr %l34, !tbaa !24
  %t376 = load i64, ptr %l28, !tbaa !24
  %t378 = load i64, ptr %l18, !tbaa !24
  %t379 = load i64, ptr %l8, !tbaa !24
  %t389 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v3, ptr %s0, ptr %v1, ptr %t372, i64 %t373, i1 %t374, i64 %t375, i64 %t376, ptr %a7, i64 %t378, ptr %l11, i64 %t379)
  store { i64, ptr } %t389, ptr %l221
  br label %bb93
bb93:
  %t390 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t398 = load i32, ptr %l211
  %t400 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t397, i32 %t398, { i64, ptr } %t396)
  store %"compiler/emit:Object" %t400, ptr %l223
  br label %bb94
bb94:
  %t401 = load ptr, ptr %l207, !tbaa !29
  %t402 = load %"compiler/emit:Object", ptr %l223
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t401, %"compiler/emit:Object" %t402)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t403 = load i64, ptr %l33, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l33, !tbaa !24
  br label %bb83
bb97:
  br label %bb98
bb98:
  %t407 = load i64, ptr %l16, !tbaa !24
  %t409 = add i64 %t407, 1
  store i64 %t409, ptr %l16, !tbaa !24
  br label %bb17
bb99:
  %t412 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %s0, ptr %l11)
  store i64 %t412, ptr %l229
  br label %bb100
bb100:
  %t413 = load i64, ptr %l229, !tbaa !24
  %t414 = icmp sgt i64 %t413, 0
  br i1 %t414, label %bb101, label %bb102
bb101:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t417, ptr %l232, !tbaa !27
  %t418 = load i32, ptr %l3
  %t420 = trunc i64 3 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb103, label %bb104
bb102:
  br label %bb109
bb103:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb105
bb104:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb105
bb105:
  %t423 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 1
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t429 = add i64 %t425, %t428
  %t430 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t429)
  call void @olang_textcopy(ptr %t430, ptr %t424, i64 %t425)
  %t431 = getelementptr i8, ptr %t430, i64 %t425
  call void @olang_textcopy(ptr %t431, ptr %t427, i64 %t428)
  %t432 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t430, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = extractvalue { i64, ptr } %t433, 1
  %t437 = mul i64 %t435, 1
  %t438 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t437)
  call void @llvm.memcpy.p0.p0.i64(ptr %t438, ptr %t436, i64 %t437, i1 false)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  store { i64, ptr } %t440, ptr %l237, !tbaa !27
  store i32 4, ptr %l238
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t444 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %s0, ptr %v1, ptr %t441, ptr %l11)
  store { i64, ptr } %t444, ptr %l241
  br label %bb106
bb106:
  %t445 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 0
  %t447 = extractvalue { i64, ptr } %t445, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t452 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t453 = load i32, ptr %l238
  %t455 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t452, i32 %t453, { i64, ptr } %t451)
  store %"compiler/emit:Object" %t455, ptr %l243
  br label %bb107
bb107:
  %t456 = load ptr, ptr %l231, !tbaa !29
  %t457 = load %"compiler/emit:Object", ptr %l243
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t456, %"compiler/emit:Object" %t457)
  br label %bb108
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t29, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l24
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l24, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t43, ptr %l25
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t13 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t4, i64 %a1, i64 %t9)
  store { i64, ptr } %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) })
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l14
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb3, label %ok.21
ok.21:
  store i64 %t18, ptr %l13
  br label %bb2
bb2:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l11, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb8, label %bb9
bb7:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l17, !tbaa !27
  br label %bb14
bb8:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = icmp sle i64 0, %t41
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb10:
  %t44 = load i64, ptr %l18, !tbaa !24
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb12:
  %t48 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l18, !tbaa !24
  %t51 = getelementptr i8, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = extractvalue { i64, ptr } %t54, 0
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t56, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l41 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i32
  %l109 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t289 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l20
  br label %bb1
bb1:
  %t14 = load i32, ptr %l20, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l23
  br label %bb2
bb2:
  %t20 = load i32, ptr %l23
  store i32 %t20, ptr %l6
  %t21 = load i32, ptr %l6
  %t23 = trunc i64 24 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb4:
  %t26 = load i32, ptr %l6
  %t28 = trunc i64 18 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l33
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb7:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l34
  br label %bb8
bb8:
  %t40 = load i32, ptr %l34
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l29, !tbaa !21
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l41
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t57 = load i1, ptr %l41, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t60)
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l47
  br label %bb17
bb17:
  %t73 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s1, ptr %s1, ptr %t74, { i64, ptr } %t75, i64 8)
  store { i64, ptr } %t78, ptr %l50
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t80, { i64, ptr } %t81, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } %t82, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t90 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t89)
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %t87)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t107 = extractvalue { i64, ptr } %t102, 1
  %t108 = extractvalue { i64, ptr } %t102, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t114 = extractvalue { i64, ptr } %t103, 1
  %t115 = extractvalue { i64, ptr } %t103, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t110, i64 %t111)
  %t123 = getelementptr i8, ptr %t122, i64 %t111
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t120, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t136 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t101, { i64, ptr } %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb20
bb20:
  %t137 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l54, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t144, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } %t145, { i64, ptr } %t143, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l4, !tbaa !29
  store ptr %t147, ptr %l65, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l5, !tbaa !23
  %t152 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l68
  br label %bb22
bb22:
  %t153 = load ptr, ptr %l65, !tbaa !29
  %t154 = load i32, ptr %l68, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l69
  br label %bb23
bb23:
  %t156 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l10, !tbaa !23
  %t164 = load i32, ptr %l10, !tbaa !23
  %t166 = icmp ne i32 %t164, 0
  br i1 %t166, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l75, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l76, !tbaa !23
  %t170 = load ptr, ptr %l4, !tbaa !29
  store ptr %t170, ptr %l77, !tbaa !29
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t172 = load i32, ptr %l10, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l80
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t176 = load ptr, ptr %l77, !tbaa !29
  %t177 = load i32, ptr %l80, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l81
  br label %bb27
bb27:
  %t179 = load %"compiler/mir:Range", ptr %l3
  %t180 = load ptr, ptr %l75, !tbaa !29
  %t181 = load i32, ptr %l76, !tbaa !23
  %t182 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %s6, ptr %t180, i32 %t181, { i64, ptr } %t182, %"compiler/mir:Range" %t179)
  store { i64, ptr } %t184, ptr %l83
  br label %bb28
bb28:
  %t185 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l10, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l87
  br label %bb29
bb29:
  %t192 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l88, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t199, ptr %l89, !tbaa !27
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t206 = extractvalue { i64, ptr } %t201, 1
  %t207 = extractvalue { i64, ptr } %t201, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t213 = extractvalue { i64, ptr } %t202, 1
  %t214 = extractvalue { i64, ptr } %t202, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t203, i64 %t204)
  %t220 = getelementptr i8, ptr %t219, i64 %t204
  call void @olang_textcopy(ptr %t220, ptr %t206, i64 %t207)
  %t221 = getelementptr i8, ptr %t220, i64 %t207
  call void @olang_textcopy(ptr %t221, ptr %t209, i64 %t210)
  %t222 = getelementptr i8, ptr %t221, i64 %t210
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t219, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t235 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s6, ptr %s6, ptr %t200, { i64, ptr } %t232)
  store { i64, ptr } %t235, ptr %l95
  br label %bb30
bb30:
  %t236 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t243 = load ptr, ptr %l84, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %t243, { i64, ptr } %t244, { i64, ptr } %t245, { i64, ptr } %t242, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t253 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %v1, ptr %v1, ptr %t247, { i64, ptr } %t248, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store { i64, ptr } %t253, ptr %l100
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s1)
  %t254 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t254, ptr %rv
  br label %ret
bb34:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l5, !tbaa !23
  %t259 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t259, ptr %l103
  br label %bb35
bb35:
  %t260 = load i32, ptr %l103, !tbaa !23
  store i32 %t260, ptr %l12, !tbaa !23
  %t261 = load i32, ptr %l12, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  br i1 %t265, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l12, !tbaa !23
  %t271 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t267, i32 %t268)
  store i64 %t271, ptr %l109
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t272 = load i64, ptr %l109, !tbaa !24
  store i64 %t272, ptr %l110, !tbaa !24
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t275 = load i32, ptr %l12, !tbaa !23
  %t278 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l113
  br label %bb39
bb39:
  %t279 = load i64, ptr %l110, !tbaa !24
  %t280 = icmp sge i64 %t279, 0
  br i1 %t280, label %bb40, label %bb41
bb40:
  %t282 = load i64, ptr %l110, !tbaa !24
  %t283 = icmp sle i64 %t282, 2305843009213693951
  br i1 %t283, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb42:
  %t285 = load i64, ptr %l110, !tbaa !24
  %t286 = mul i64 %t285, 4
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  %t288 = load i32, ptr %l113, !tbaa !23
  store i64 0, ptr %t289
  br label %fill.290
fill.290:
  %t293 = load i64, ptr %t289
  %t294 = icmp slt i64 %t293, %t285
  br i1 %t294, label %fillb.291, label %filld.292
fillb.291:
  %t295 = getelementptr i32, ptr %t287, i64 %t293
  store i32 %t288, ptr %t295
  %t296 = add i64 %t293, 1
  store i64 %t296, ptr %t289
  br label %fill.290
filld.292:
  %t297 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t287, 1
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l12, !tbaa !23
  %t303 = load %"compiler/mir:Range", ptr %l3
  %t308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %s8, ptr %v1, ptr %t300, i32 %t301, { i64, ptr } %t298, %"compiler/mir:Range" %t303)
  store { i64, ptr } %t308, ptr %l121
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb44:
  call void @__olang_scope_close(ptr %s8)
  %t309 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
bb45:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l122, !tbaa !29
  %t311 = load i32, ptr %l5, !tbaa !23
  store i32 %t311, ptr %l123, !tbaa !23
  %t312 = load ptr, ptr %l4, !tbaa !29
  store ptr %t312, ptr %l124, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l5, !tbaa !23
  %t317 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t313, i32 %t314)
  store i32 %t317, ptr %l127
  br label %bb46
bb46:
  %t318 = load ptr, ptr %l124, !tbaa !29
  %t319 = load i32, ptr %l127, !tbaa !23
  %t320 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t318, i32 %t319)
  store { i64, ptr } %t320, ptr %l128
  br label %bb47
bb47:
  %t321 = load %"compiler/mir:Range", ptr %l3
  %t322 = load ptr, ptr %l122, !tbaa !29
  %t323 = load i32, ptr %l123, !tbaa !23
  %t324 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %v1, ptr %t322, i32 %t323, { i64, ptr } %t324, %"compiler/mir:Range" %t321)
  store { i64, ptr } %t326, ptr %l130
  br label %bb48
bb48:
  %t327 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t327, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l6 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l3
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t13, %a2
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1)
  unreachable
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, [7 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l110 = alloca i64
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l134 = alloca { i64, ptr }
  %l136 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l156 = alloca i64
  %l162 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca i64
  %l180 = alloca i1
  %l182 = alloca i1
  %l193 = alloca i32
  %l194 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca { i64, ptr }
  %l204 = alloca i1
  %l208 = alloca i1
  %l211 = alloca i1
  %l212 = alloca %"std/prelude/text:StringBuilder"
  %l214 = alloca i1
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca i64
  %l223 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l242 = alloca i32
  %l245 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l276 = alloca { i64, [1 x i64] }
  %l277 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l285 = alloca i32
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l295 = alloca i64
  %l298 = alloca i64
  %l322 = alloca { i64, [4 x i64] }
  %l325 = alloca i1
  %l327 = alloca i1
  %l335 = alloca i1
  %l340 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l356 = alloca { i64, ptr }
  %l359 = alloca { i64, ptr }
  %l361 = alloca ptr
  %l364 = alloca { i64, ptr }
  %l367 = alloca { i64, ptr }
  %l373 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l383 = alloca { i64, ptr }
  %l386 = alloca ptr
  %l388 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l402 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca { i64, ptr }
  %l407 = alloca { i64, ptr }
  %l408 = alloca i64
  %l409 = alloca { i64, ptr }
  %l411 = alloca i1
  %l412 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l415 = alloca { i64, ptr }
  %l418 = alloca ptr
  %l419 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l422 = alloca { i64, ptr }
  %l425 = alloca { i64, ptr }
  %l427 = alloca i64
  %l433 = alloca { i64, ptr }
  %l434 = alloca { i64, ptr }
  %l435 = alloca i64
  %l436 = alloca { i64, ptr }
  %l438 = alloca { i64, ptr }
  %l440 = alloca i64
  %l442 = alloca i64
  %l443 = alloca { i64, ptr }
  %l448 = alloca { i64, ptr }
  %l454 = alloca { i64, ptr }
  %l457 = alloca i64
  %l461 = alloca i1
  %l465 = alloca { i64, ptr }
  %l472 = alloca { i64, ptr }
  %l476 = alloca ptr
  %l477 = alloca { i64, ptr }
  %l480 = alloca { i64, ptr }
  %l486 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l489 = alloca ptr
  %l490 = alloca { i64, ptr }
  %l492 = alloca { i64, ptr }
  %l499 = alloca i1
  %l501 = alloca i1
  %l505 = alloca { { i64, ptr }, i32 }
  %l506 = alloca { i64, ptr }
  %l507 = alloca i64
  %l508 = alloca { i64, ptr }
  %l511 = alloca ptr
  %l512 = alloca { i64, ptr }
  %l513 = alloca { i64, ptr }
  %l516 = alloca i64
  %l517 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l524 = alloca ptr
  %l526 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t11, ptr %l59, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l60, !tbaa !24
  %t14 = load i64, ptr %l60, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l61, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l60, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t26, ptr %l63, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l64, !tbaa !24
  %t29 = load i64, ptr %l64, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l65, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l64, !tbaa !24
  %t39 = mul i64 %t38, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t41, ptr %l67, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l68, !tbaa !24
  %t44 = load i64, ptr %l68, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l69, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l68, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  store i1 false, ptr %l7, !tbaa !21
  %t56 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t57 = load { i64, [7 x i64] }, ptr %t56
  store { i64, [7 x i64] } %t57, ptr %l8
  %t59 = load { i64, [7 x i64] }, ptr %l8
  %t61 = extractvalue { i64, [7 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb1, label %bb2
bb1:
  %t64 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, [2 x i64] }, ptr %t65
  store { i64, [2 x i64] } %t66, ptr %l9
  %t68 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t69 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l10, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:fnEm", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t75, { i64, [2 x i64] } %t76)
  br label %bb4
bb4:
  %t79 = load i32, ptr %l10, !tbaa !23
  store i32 %t79, ptr %l3, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load { i64, [2 x i64] }, ptr %l9
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s1, ptr %t84, { i64, [2 x i64] } %t85)
  store { i64, ptr } %t88, ptr %l82
  br label %bb5
bb5:
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t91 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l83, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l85, !tbaa !24
  %t104 = load i64, ptr %l85, !tbaa !24
  %t105 = icmp eq i64 %t100, %t104
  br i1 %t105, label %bb6, label %bb7
bb6:
  %t107 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l85, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  br label %bb8
bb7:
  %t113 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t113, ptr %l4, !tbaa !27
  br label %bb8
bb8:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:fnEm", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load { i64, [2 x i64] }, ptr %l9
  %t121 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t117, { i64, [2 x i64] } %t118)
  store i1 %t121, ptr %l90
  br label %bb9
bb9:
  %t122 = load i1, ptr %l90, !tbaa !21
  br i1 %t122, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t123, ptr %l92, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l94, !tbaa !24
  %t129 = load i64, ptr %l94, !tbaa !24
  %t130 = icmp eq i64 %t125, %t129
  br i1 %t130, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t132 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l94, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  br label %bb14
bb13:
  %t138 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l96, !tbaa !24
  %t140 = load i64, ptr %l96, !tbaa !24
  %t141 = mul i64 %t140, 1
  %t142 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l97, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l96, !tbaa !24
  %t150 = mul i64 %t149, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t146, ptr %t148, i64 %t150, i1 false)
  %t151 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t151, ptr %l5, !tbaa !27
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb16:
  %t152 = load { i64, [7 x i64] }, ptr %l8
  %t154 = extractvalue { i64, [7 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 1
  br i1 %t155, label %bb17, label %bb18
bb17:
  %t157 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t158 = getelementptr { i64, i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i64, ptr %t158
  store i64 %t159, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t162 = getelementptr { i64, i32 }, ptr %t161, i32 0, i32 1
  %t163 = load i32, ptr %t162
  store i32 %t163, ptr %l12, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t165 = load i32, ptr %l12, !tbaa !23
  store i32 %t165, ptr %l3, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/emit:fnEm", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l11, !tbaa !24
  %t172 = load i32, ptr %l12, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %s4, ptr %t170, i64 %t171, i32 %t172)
  store { i64, ptr } %t176, ptr %l107
  br label %bb20
bb20:
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t179 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t177, i64 %t178)
  %t184 = getelementptr i8, ptr %t183, i64 %t178
  call void @olang_textcopy(ptr %t184, ptr %t180, i64 %t181)
  %t185 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t183, 1
  store { i64, ptr } %t186, ptr %l108, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l110, !tbaa !24
  %t192 = load i64, ptr %l110, !tbaa !24
  %t193 = icmp eq i64 %t188, %t192
  br i1 %t193, label %bb21, label %bb22
bb21:
  %t195 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l110, !tbaa !24
  %t200 = mul i64 %t199, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %t198, i64 %t200, i1 false)
  br label %bb23
bb22:
  %t201 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t201, ptr %l4, !tbaa !27
  br label %bb23
bb23:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb24:
  %t202 = load { i64, [7 x i64] }, ptr %l8
  %t204 = extractvalue { i64, [7 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 2
  br i1 %t205, label %bb25, label %bb26
bb25:
  %t207 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t208 = getelementptr { { i64, [4 x i64] } }, ptr %t207, i32 0, i32 0
  %t209 = load { i64, [4 x i64] }, ptr %t208
  store { i64, [4 x i64] } %t209, ptr %l13
  br label %bb27
bb26:
  br label %bb38
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load { i64, [4 x i64] }, ptr %l13
  %t215 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t211, { i64, [4 x i64] } %t212)
  store i32 %t215, ptr %l117
  br label %bb28
bb28:
  %t216 = load i32, ptr %l117, !tbaa !23
  store i32 %t216, ptr %l3, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, [4 x i64] }, ptr %l13
  %t219 = load i32, ptr %l3, !tbaa !23
  %t223 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s6, ptr %t217, { i64, [4 x i64] } %t218, i32 %t219)
  store { i64, ptr } %t223, ptr %l121
  br label %bb29
bb29:
  %t224 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t224, ptr %l14, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t227 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t230 = extractvalue { i64, ptr } %t226, 1
  %t231 = extractvalue { i64, ptr } %t226, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t227, i64 %t228)
  %t237 = getelementptr i8, ptr %t236, i64 %t228
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  call void @olang_textcopy(ptr %t238, ptr %t233, i64 %t234)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t236, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t250 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t225, { i64, ptr } %t247)
  store { i64, ptr } %t250, ptr %l126
  br label %bb30
bb30:
  %t251 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l128, !tbaa !24
  %t256 = load i64, ptr %l128, !tbaa !24
  %t257 = icmp eq i64 %t252, %t256
  br i1 %t257, label %bb31, label %bb32
bb31:
  %t259 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l128, !tbaa !24
  %t264 = mul i64 %t263, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t260, ptr %t262, i64 %t264, i1 false)
  br label %bb33
bb32:
  %t265 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t265, ptr %l4, !tbaa !27
  br label %bb33
bb33:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t268 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t271 = extractvalue { i64, ptr } %t267, 1
  %t272 = extractvalue { i64, ptr } %t267, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t268, i64 %t269)
  %t278 = getelementptr i8, ptr %t277, i64 %t269
  call void @olang_textcopy(ptr %t278, ptr %t271, i64 %t272)
  %t279 = getelementptr i8, ptr %t278, i64 %t272
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t277, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t291 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t266, { i64, ptr } %t288)
  store { i64, ptr } %t291, ptr %l134
  br label %bb34
bb34:
  %t292 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  %t294 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  store i64 %t295, ptr %l136, !tbaa !24
  %t297 = load i64, ptr %l136, !tbaa !24
  %t298 = icmp eq i64 %t293, %t297
  br i1 %t298, label %bb35, label %bb36
bb35:
  %t300 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l136, !tbaa !24
  %t305 = mul i64 %t304, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t301, ptr %t303, i64 %t305, i1 false)
  br label %bb37
bb36:
  %t306 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t306, ptr %l5, !tbaa !27
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb38:
  %t307 = load { i64, [7 x i64] }, ptr %l8
  %t309 = extractvalue { i64, [7 x i64] } %t307, 0
  %t310 = icmp eq i64 %t309, 3
  br i1 %t310, label %bb39, label %bb40
bb39:
  %t312 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t313 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t312, i32 0, i32 0
  %t314 = load { i64, [4 x i64] }, ptr %t313
  store { i64, [4 x i64] } %t314, ptr %l15
  %t316 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t317 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t316, i32 0, i32 1
  %t318 = load i64, ptr %t317
  store i64 %t318, ptr %l16, !tbaa !24
  %t320 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t321 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t320, i32 0, i32 2
  %t322 = load i32, ptr %t321
  store i32 %t322, ptr %l17, !tbaa !23
  br label %bb41
bb40:
  br label %bb54
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t324 = load i32, ptr %l17, !tbaa !23
  store i32 %t324, ptr %l3, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l144, !tbaa !29
  %t327 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t327, ptr %l145
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load { i64, [4 x i64] }, ptr %l15
  %t332 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t328, { i64, [4 x i64] } %t329)
  store i32 %t332, ptr %l148
  br label %bb42
bb42:
  %t333 = load ptr, ptr %l144, !tbaa !29
  %t334 = load { i64, [4 x i64] }, ptr %l145
  %t335 = load i32, ptr %l148, !tbaa !23
  %t336 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s9, ptr %t333, { i64, [4 x i64] } %t334, i32 %t335)
  store { i64, ptr } %t336, ptr %l149
  br label %bb43
bb43:
  %t337 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t337, ptr %l18, !tbaa !27
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t340 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t343 = extractvalue { i64, ptr } %t339, 1
  %t344 = extractvalue { i64, ptr } %t339, 0
  %t345 = add i64 %t341, %t344
  %t346 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t348 = add i64 %t345, %t347
  %t349 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t340, i64 %t341)
  %t350 = getelementptr i8, ptr %t349, i64 %t341
  call void @olang_textcopy(ptr %t350, ptr %t343, i64 %t344)
  %t351 = getelementptr i8, ptr %t350, i64 %t344
  call void @olang_textcopy(ptr %t351, ptr %t346, i64 %t347)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t349, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t338, { i64, ptr } %t360)
  store { i64, ptr } %t363, ptr %l154
  br label %bb44
bb44:
  %t364 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  store i64 %t367, ptr %l156, !tbaa !24
  %t369 = load i64, ptr %l156, !tbaa !24
  %t370 = icmp eq i64 %t365, %t369
  br i1 %t370, label %bb45, label %bb46
bb45:
  %t372 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = load i64, ptr %l156, !tbaa !24
  %t377 = mul i64 %t376, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t373, ptr %t375, i64 %t377, i1 false)
  br label %bb47
bb46:
  %t378 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t378, ptr %l6, !tbaa !27
  br label %bb47
bb47:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t381 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t384 = extractvalue { i64, ptr } %t380, 1
  %t385 = extractvalue { i64, ptr } %t380, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t384, i64 %t385)
  %t392 = getelementptr i8, ptr %t391, i64 %t385
  call void @olang_textcopy(ptr %t392, ptr %t387, i64 %t388)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t404 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t379, { i64, ptr } %t401)
  store { i64, ptr } %t404, ptr %l162
  br label %bb48
bb48:
  %t405 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t409 = load i64, ptr %l16, !tbaa !24
  %t412 = add i64 %t408, %t409
  %t413 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t416 = extractvalue { i64, ptr } %t405, 1
  %t417 = extractvalue { i64, ptr } %t405, 0
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t423 = call i64 @__olang_fmt_i64(ptr null, i64 %t412)
  %t424 = add i64 %t421, %t423
  %t425 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t413, i64 %t414)
  %t426 = getelementptr i8, ptr %t425, i64 %t414
  call void @olang_textcopy(ptr %t426, ptr %t416, i64 %t417)
  %t427 = getelementptr i8, ptr %t426, i64 %t417
  call void @olang_textcopy(ptr %t427, ptr %t419, i64 %t420)
  %t428 = getelementptr i8, ptr %t427, i64 %t420
  %t429 = call i64 @__olang_fmt_i64(ptr %t428, i64 %t412)
  %t430 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t425, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t441 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t406, { i64, ptr } %t438)
  store { i64, ptr } %t441, ptr %l170
  br label %bb49
bb49:
  %t442 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t448 = extractvalue { i64, ptr } %t442, 1
  %t449 = extractvalue { i64, ptr } %t442, 0
  %t450 = add i64 %t446, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t445, i64 %t446)
  %t452 = getelementptr i8, ptr %t451, i64 %t446
  call void @olang_textcopy(ptr %t452, ptr %t448, i64 %t449)
  %t453 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t451, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = extractvalue { i64, ptr } %t454, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  %t464 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t443, { i64, ptr } %t461)
  store { i64, ptr } %t464, ptr %l175
  br label %bb50
bb50:
  %t465 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l177, !tbaa !24
  %t470 = load i64, ptr %l177, !tbaa !24
  %t471 = icmp eq i64 %t466, %t470
  br i1 %t471, label %bb51, label %bb52
bb51:
  %t473 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = load i64, ptr %l177, !tbaa !24
  %t478 = mul i64 %t477, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t474, ptr %t476, i64 %t478, i1 false)
  br label %bb53
bb52:
  %t479 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t479, ptr %l4, !tbaa !27
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_d166383632e6ec4e_5cd1ec2f29a4b0f2)
  unreachable
bb55:
  %t480 = load i1, ptr %l7, !tbaa !21
  br i1 %t480, label %bb56, label %bb57
bb56:
  %t482 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t484 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t482, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t484, ptr %l182
  br label %bb58
bb57:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb59
bb58:
  %t485 = load i1, ptr %l182, !tbaa !21
  %t486 = xor i1 %t485, true
  store i1 %t486, ptr %l180, !tbaa !21
  br label %bb59
bb59:
  %t488 = load i1, ptr %l180, !tbaa !21
  br i1 %t488, label %bb60, label %bb61
bb60:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load %"compiler/mir:Call", ptr %l1
  %t491 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t492 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %s0, ptr %t489, %"compiler/mir:Call" %t490, { i64, ptr } %t491, i32 %t492)
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb63:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/emit:fnEm", ptr %t497, i32 0, i32 0
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t501 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t500, i32 %t501)
  br label %bb64
bb64:
  %t504 = load ptr, ptr %l2, !tbaa !29
  %t505 = load i32, ptr %l3, !tbaa !23
  %t508 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t504, i32 %t505)
  store i32 %t508, ptr %l193
  br label %bb65
bb65:
  %t509 = load i32, ptr %l193, !tbaa !23
  store i32 %t509, ptr %l21, !tbaa !23
  %t510 = load ptr, ptr %l2, !tbaa !29
  store ptr %t510, ptr %l194, !tbaa !29
  %t511 = load ptr, ptr %l2, !tbaa !29
  %t512 = load i32, ptr %l3, !tbaa !23
  %t515 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t511, i32 %t512)
  store i32 %t515, ptr %l197
  br label %bb66
bb66:
  %t516 = load ptr, ptr %l194, !tbaa !29
  %t517 = load i32, ptr %l197, !tbaa !23
  %t518 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t516, i32 %t517)
  store { i64, ptr } %t518, ptr %l198
  br label %bb67
bb67:
  %t519 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t522 = icmp sgt i64 %t520, 0
  store i1 %t522, ptr %l22, !tbaa !21
  %t524 = load i32, ptr %l21, !tbaa !23
  %t525 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t528 = icmp ne i32 %t524, %t525
  br i1 %t528, label %bb68, label %bb69
bb68:
  %t530 = load i32, ptr %l21, !tbaa !23
  %t531 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t534 = icmp ne i32 %t530, %t531
  store i1 %t534, ptr %l204, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb70
bb70:
  %t536 = load i1, ptr %l204, !tbaa !21
  br i1 %t536, label %bb71, label %bb72
bb71:
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load i32, ptr %l21, !tbaa !23
  %t541 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t537, i32 %t538)
  store i1 %t541, ptr %l211
  br label %bb73
bb72:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb74
bb73:
  %t542 = load i1, ptr %l211, !tbaa !21
  store i1 %t542, ptr %l208, !tbaa !21
  br label %bb74
bb74:
  %t543 = load i1, ptr %l208, !tbaa !21
  store i1 %t543, ptr %l23, !tbaa !21
  %t544 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t544, ptr %l212
  br label %bb75
bb75:
  %t545 = load %"std/prelude/text:StringBuilder", ptr %l212
  store %"std/prelude/text:StringBuilder" %t545, ptr %l24
  store i1 true, ptr %l25, !tbaa !21
  %t546 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t548 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t546, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t548, ptr %l214
  br label %bb76
bb76:
  %t549 = load i1, ptr %l214, !tbaa !21
  %t550 = xor i1 %t549, true
  br i1 %t550, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  %t552 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t553 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t556 = extractvalue { i64, ptr } %t552, 1
  %t557 = extractvalue { i64, ptr } %t552, 0
  %t558 = add i64 %t554, %t557
  %t559 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t558)
  call void @olang_textcopy(ptr %t559, ptr %t553, i64 %t554)
  %t560 = getelementptr i8, ptr %t559, i64 %t554
  call void @olang_textcopy(ptr %t560, ptr %t556, i64 %t557)
  %t561 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t559, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l24, { i64, ptr } %t569)
  br label %bb79
bb78:
  br label %bb80
bb79:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb80
bb80:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l220, !tbaa !27
  %t572 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t572, ptr %l221, !tbaa !27
  %t573 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  store i64 %t574, ptr %l222, !tbaa !24
  %t575 = load i64, ptr %l222, !tbaa !24
  %t576 = mul i64 %t575, 1
  %t577 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t576)
  %t578 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  store { i64, ptr } %t579, ptr %l223, !tbaa !27
  %t580 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = load i64, ptr %l222, !tbaa !24
  %t585 = mul i64 %t584, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t581, ptr %t583, i64 %t585, i1 false)
  %t586 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t586, ptr %l26, !tbaa !27
  %t587 = load i1, ptr %l23, !tbaa !21
  br i1 %t587, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i32, ptr %l21, !tbaa !23
  %t593 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s0, ptr %t589, i32 %t590)
  store { i64, ptr } %t593, ptr %l227
  br label %bb83
bb82:
  br label %bb92
bb83:
  %t594 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t595 = extractvalue { i64, ptr } %t594, 0
  %t596 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  store i64 %t597, ptr %l229, !tbaa !24
  %t599 = load i64, ptr %l229, !tbaa !24
  %t600 = icmp eq i64 %t595, %t599
  br i1 %t600, label %bb84, label %bb85
bb84:
  %t602 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !27
  %t606 = load i64, ptr %l229, !tbaa !24
  %t607 = mul i64 %t606, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t603, ptr %t605, i64 %t607, i1 false)
  br label %bb86
bb85:
  %t608 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t608, ptr %l26, !tbaa !27
  br label %bb86
bb86:
  %t609 = load i1, ptr %l25, !tbaa !21
  %t611 = xor i1 %t609, true
  br i1 %t611, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t614 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t615 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t618 = extractvalue { i64, ptr } %t614, 1
  %t619 = extractvalue { i64, ptr } %t614, 0
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  call void @olang_textcopy(ptr %t622, ptr %t618, i64 %t619)
  %t623 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t621, 1
  %t626 = extractvalue { i64, ptr } %t624, 0
  %t627 = extractvalue { i64, ptr } %t624, 1
  %t628 = mul i64 %t626, 1
  %t629 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t629, ptr %t627, i64 %t628, i1 false)
  %t630 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l24, { i64, ptr } %t631)
  br label %bb91
bb91:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb92
bb92:
  store i32 0, ptr %l27, !tbaa !23
  %t634 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t635 = getelementptr %"compiler/mir:Range", ptr %t634, i32 0, i32 1
  %t636 = load i32, ptr %t635, !tbaa !23
  store i32 %t636, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t638 = load i32, ptr %l28, !tbaa !23
  %t639 = load i32, ptr %l27, !tbaa !23
  %t642 = icmp sgt i32 %t638, %t639
  br i1 %t642, label %bb93, label %bb94
bb93:
  %t644 = load i32, ptr %l29, !tbaa !23
  %t646 = icmp sgt i32 %t644, 0
  br i1 %t646, label %bb95, label %bb96
bb94:
  store i32 0, ptr %l242, !tbaa !23
  br label %bb98
bb95:
  %t648 = load i32, ptr %l28, !tbaa !23
  %t649 = load i32, ptr %l27, !tbaa !23
  %t652 = sub i32 %t648, %t649
  %t653 = load i32, ptr %l29, !tbaa !23
  %t656 = add i32 %t652, %t653
  %t658 = sub i32 %t656, 1
  %t659 = load i32, ptr %l29, !tbaa !23
  %t662 = sdiv i32 %t658, %t659
  store i32 %t662, ptr %l245, !tbaa !23
  br label %bb97
bb96:
  store i32 0, ptr %l245, !tbaa !23
  br label %bb97
bb97:
  %t664 = load i32, ptr %l245, !tbaa !23
  store i32 %t664, ptr %l242, !tbaa !23
  br label %bb98
bb98:
  %t665 = load i32, ptr %l242, !tbaa !23
  store i32 %t665, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s21
  %t666 = load i32, ptr %l31, !tbaa !23
  %t667 = load i32, ptr %l30, !tbaa !23
  %t670 = icmp slt i32 %t666, %t667
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s21)
  br label %bb111
bb101:
  br label %bb102
bb102:
  %t674 = load i32, ptr %l27, !tbaa !23
  %t675 = load i32, ptr %l31, !tbaa !23
  %t676 = load i32, ptr %l29, !tbaa !23
  %t679 = mul i32 %t675, %t676
  %t682 = add i32 %t674, %t679
  store i32 %t682, ptr %l32, !tbaa !23
  %t684 = load i1, ptr %l25, !tbaa !21
  %t686 = xor i1 %t684, true
  br i1 %t686, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb106:
  store i1 false, ptr %l25, !tbaa !21
  store ptr %l24, ptr %l266, !tbaa !29
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l267, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/emit:fnEm", ptr %t690, i32 0, i32 1
  %t693 = load ptr, ptr %t692, !tbaa !29
  %t695 = getelementptr %"compiler/mir:Fn", ptr %t693, i32 0, i32 12
  %t696 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t697 = getelementptr %"compiler/mir:Range", ptr %t696, i32 0, i32 0
  %t698 = load i32, ptr %t697, !tbaa !23
  %t700 = sext i32 %t698 to i64
  %t701 = load i32, ptr %l32, !tbaa !23
  %t703 = sext i32 %t701 to i64
  %t706 = add i64 %t700, %t703
  %t709 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t695, i64 %t706)
  store { i64, [1 x i64] } %t709, ptr %l276
  br label %bb107
bb107:
  %t710 = load ptr, ptr %l267, !tbaa !29
  %t711 = load { i64, [1 x i64] }, ptr %l276
  %t712 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s21, ptr %t710, { i64, [1 x i64] } %t711)
  store { i64, ptr } %t712, ptr %l277
  br label %bb108
bb108:
  %t713 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t715 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 1
  %t717 = extractvalue { i64, ptr } %t715, 0
  %t718 = add i64 %t714, %t717
  %t719 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t718)
  call void @olang_textcopy(ptr %t719, ptr %t713, i64 %t714)
  %t720 = getelementptr i8, ptr %t719, i64 %t714
  call void @olang_textcopy(ptr %t720, ptr %t716, i64 %t717)
  %t721 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t722 = insertvalue { i64, ptr } %t721, ptr %t719, 1
  %t724 = extractvalue { i64, ptr } %t722, 0
  %t725 = extractvalue { i64, ptr } %t722, 1
  %t726 = mul i64 %t724, 1
  %t727 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t726)
  call void @llvm.memcpy.p0.p0.i64(ptr %t727, ptr %t725, i64 %t726, i1 false)
  %t728 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t727, 1
  %t730 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t730, { i64, ptr } %t729)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s21)
  br label %bb110
bb110:
  %t732 = load i32, ptr %l31, !tbaa !23
  %t734 = add i32 %t732, 1
  store i32 %t734, ptr %l31, !tbaa !23
  br label %bb99
bb111:
  %t736 = load ptr, ptr %l2, !tbaa !29
  store ptr %t736, ptr %l282, !tbaa !29
  %t737 = load ptr, ptr %l2, !tbaa !29
  %t738 = load i32, ptr %l3, !tbaa !23
  %t741 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t737, i32 %t738)
  store i32 %t741, ptr %l285
  br label %bb112
bb112:
  %t742 = load ptr, ptr %l282, !tbaa !29
  %t743 = load i32, ptr %l285, !tbaa !23
  %t744 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t742, i32 %t743)
  store { i64, ptr } %t744, ptr %l286
  br label %bb113
bb113:
  %t745 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t745, ptr %l33, !tbaa !27
  %t746 = load ptr, ptr %l2, !tbaa !29
  %t747 = load i32, ptr %l3, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t746, i32 %t747)
  store { i64, ptr } %t750, ptr %l289
  br label %bb114
bb114:
  %t751 = load { i64, ptr }, ptr %l289, !tbaa !27
  store { i64, ptr } %t751, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t752 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t752, 0
  store i64 %t754, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t756 = load i64, ptr %l36, !tbaa !24
  %t757 = load i64, ptr %l35, !tbaa !24
  %t760 = icmp sgt i64 %t756, %t757
  br i1 %t760, label %bb115, label %bb116
bb115:
  %t762 = load i64, ptr %l37, !tbaa !24
  %t764 = icmp sgt i64 %t762, 0
  br i1 %t764, label %bb117, label %bb118
bb116:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb120
bb117:
  %t766 = load i64, ptr %l36, !tbaa !24
  %t767 = load i64, ptr %l35, !tbaa !24
  %t770 = sub i64 %t766, %t767
  %t771 = load i64, ptr %l37, !tbaa !24
  %t774 = add i64 %t770, %t771
  %t776 = sub i64 %t774, 1
  %t777 = load i64, ptr %l37, !tbaa !24
  %t780 = sdiv i64 %t776, %t777
  store i64 %t780, ptr %l298, !tbaa !24
  br label %bb119
bb118:
  store i64 0, ptr %l298, !tbaa !24
  br label %bb119
bb119:
  %t782 = load i64, ptr %l298, !tbaa !24
  store i64 %t782, ptr %l295, !tbaa !24
  br label %bb120
bb120:
  %t783 = load i64, ptr %l295, !tbaa !24
  store i64 %t783, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s26
  %t784 = load i64, ptr %l39, !tbaa !24
  %t785 = load i64, ptr %l38, !tbaa !24
  %t788 = icmp slt i64 %t784, %t785
  %t790 = xor i1 %t788, true
  br i1 %t790, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s26)
  br label %bb168
bb123:
  br label %bb124
bb124:
  %t792 = load i64, ptr %l35, !tbaa !24
  %t793 = load i64, ptr %l39, !tbaa !24
  %t794 = load i64, ptr %l37, !tbaa !24
  %t797 = mul i64 %t793, %t794
  %t800 = add i64 %t792, %t797
  store i64 %t800, ptr %l40, !tbaa !24
  %t802 = load i1, ptr %l25, !tbaa !21
  %t804 = xor i1 %t802, true
  br i1 %t804, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_scope_close(ptr %s27)
  br label %bb128
bb128:
  store i1 false, ptr %l25, !tbaa !21
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t809 = load %"compiler/mir:Range", ptr %t808
  %t810 = load i64, ptr %l40, !tbaa !24
  %t814 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t807, %"compiler/mir:Range" %t809, i64 %t810)
  store { i64, [4 x i64] } %t814, ptr %l322
  br label %bb129
bb129:
  %t815 = load { i64, [4 x i64] }, ptr %l322
  store { i64, [4 x i64] } %t815, ptr %l41
  %t816 = load i64, ptr %l40, !tbaa !24
  %t818 = icmp eq i64 %t816, 0
  br i1 %t818, label %bb130, label %bb131
bb130:
  %t820 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t822 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s26, { i64, ptr } %t820, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) })
  store i1 %t822, ptr %l327
  br label %bb132
bb131:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb133
bb132:
  %t823 = load i1, ptr %l327, !tbaa !21
  %t824 = xor i1 %t823, true
  store i1 %t824, ptr %l325, !tbaa !21
  br label %bb133
bb133:
  %t826 = load i1, ptr %l325, !tbaa !21
  br i1 %t826, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s28
  %t827 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t828 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t829 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t831 = extractvalue { i64, ptr } %t827, 1
  %t832 = extractvalue { i64, ptr } %t827, 0
  %t833 = add i64 %t829, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t828, i64 %t829)
  %t835 = getelementptr i8, ptr %t834, i64 %t829
  call void @olang_textcopy(ptr %t835, ptr %t831, i64 %t832)
  %t836 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t834, 1
  %t839 = extractvalue { i64, ptr } %t837, 0
  %t840 = extractvalue { i64, ptr } %t837, 1
  %t841 = mul i64 %t839, 1
  %t842 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t841)
  call void @llvm.memcpy.p0.p0.i64(ptr %t842, ptr %t840, i64 %t841, i1 false)
  %t843 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t844 = insertvalue { i64, ptr } %t843, ptr %t842, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l24, { i64, ptr } %t844)
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb137:
  %t847 = load i1, ptr %l7, !tbaa !21
  %t849 = xor i1 %t847, true
  br i1 %t849, label %bb138, label %bb139
bb138:
  %t851 = load i64, ptr %l40, !tbaa !24
  %t853 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !27
  %t855 = getelementptr i8, ptr %t854, i64 %t851
  %t856 = load i8, ptr %t855, !tbaa !32
  %t858 = icmp eq i8 %t856, 109
  store i1 %t858, ptr %l335, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb140
bb140:
  %t860 = load i1, ptr %l335, !tbaa !21
  br i1 %t860, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s30
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t862, ptr %l340, !tbaa !27
  %t863 = load i64, ptr %l40, !tbaa !24
  %t865 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = getelementptr i32, ptr %t866, i64 %t863
  %t868 = load i32, ptr %t867, !tbaa !33
  %t871 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s30, ptr %t861, i32 %t868)
  store { i64, ptr } %t871, ptr %l343
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t872 = load { i64, ptr }, ptr %l343, !tbaa !27
  store { i64, ptr } %t872, ptr %l42, !tbaa !27
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t874 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t875 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t875, ptr %l346, !tbaa !27
  %t876 = load i64, ptr %l40, !tbaa !24
  %t878 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !27
  %t880 = getelementptr i32, ptr %t879, i64 %t876
  %t881 = load i32, ptr %t880, !tbaa !33
  %t882 = load { i64, [4 x i64] }, ptr %l41
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s30, ptr %s30, ptr %t873, { i64, ptr } %t874, i32 %t881, { i64, [4 x i64] } %t882, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb144
bb144:
  %t887 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t888 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t889 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t891 = extractvalue { i64, ptr } %t887, 1
  %t892 = extractvalue { i64, ptr } %t887, 0
  %t893 = add i64 %t889, %t892
  %t894 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t893)
  call void @olang_textcopy(ptr %t894, ptr %t888, i64 %t889)
  %t895 = getelementptr i8, ptr %t894, i64 %t889
  call void @olang_textcopy(ptr %t895, ptr %t891, i64 %t892)
  %t896 = insertvalue { i64, ptr } undef, i64 %t893, 0
  %t897 = insertvalue { i64, ptr } %t896, ptr %t894, 1
  %t899 = extractvalue { i64, ptr } %t897, 0
  %t900 = extractvalue { i64, ptr } %t897, 1
  %t901 = mul i64 %t899, 1
  %t902 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t901)
  call void @llvm.memcpy.p0.p0.i64(ptr %t902, ptr %t900, i64 %t901, i1 false)
  %t903 = insertvalue { i64, ptr } undef, i64 %t899, 0
  %t904 = insertvalue { i64, ptr } %t903, ptr %t902, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %l24, { i64, ptr } %t904)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb146:
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t908 = load { i64, [4 x i64] }, ptr %l41
  %t909 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t909, ptr %l356, !tbaa !27
  %t910 = load i64, ptr %l40, !tbaa !24
  %t912 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = getelementptr i32, ptr %t913, i64 %t910
  %t915 = load i32, ptr %t914, !tbaa !33
  %t919 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s26, ptr %t907, { i64, [4 x i64] } %t908, i32 %t915)
  store { i64, ptr } %t919, ptr %l359
  br label %bb147
bb147:
  %t920 = load { i64, ptr }, ptr %l359, !tbaa !27
  store { i64, ptr } %t920, ptr %l43, !tbaa !27
  %t921 = load i1, ptr %l7, !tbaa !21
  br i1 %t921, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s32
  store ptr %l24, ptr %l361, !tbaa !29
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t925 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t925, ptr %l364, !tbaa !27
  %t926 = load i64, ptr %l40, !tbaa !24
  %t928 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t929 = load ptr, ptr %t928, !tbaa !27
  %t930 = getelementptr i32, ptr %t929, i64 %t926
  %t931 = load i32, ptr %t930, !tbaa !33
  %t935 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s26, ptr %s32, ptr %t923, { i64, ptr } %t924, i32 %t931)
  store { i64, ptr } %t935, ptr %l367
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t936 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 0
  %t938 = extractvalue { i64, ptr } %t936, 1
  %t939 = mul i64 %t937, 1
  %t940 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t939)
  call void @llvm.memcpy.p0.p0.i64(ptr %t940, ptr %t938, i64 %t939, i1 false)
  %t941 = insertvalue { i64, ptr } undef, i64 %t937, 0
  %t942 = insertvalue { i64, ptr } %t941, ptr %t940, 1
  %t943 = load ptr, ptr %l361, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s32, ptr %t943, { i64, ptr } %t942)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb152:
  %t945 = load i64, ptr %l40, !tbaa !24
  %t947 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t948 = load ptr, ptr %t947, !tbaa !27
  %t949 = getelementptr i8, ptr %t948, i64 %t945
  %t950 = load i8, ptr %t949, !tbaa !32
  %t954 = icmp eq i8 %t950, 115
  br i1 %t954, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb159
bb155:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l24, ptr %l373, !tbaa !29
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t957 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t958 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t959 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t961 = extractvalue { i64, ptr } %t957, 1
  %t962 = extractvalue { i64, ptr } %t957, 0
  %t963 = add i64 %t959, %t962
  %t964 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t965 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t966 = add i64 %t963, %t965
  %t967 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t966)
  call void @olang_textcopy(ptr %t967, ptr %t958, i64 %t959)
  %t968 = getelementptr i8, ptr %t967, i64 %t959
  call void @olang_textcopy(ptr %t968, ptr %t961, i64 %t962)
  %t969 = getelementptr i8, ptr %t968, i64 %t962
  call void @olang_textcopy(ptr %t969, ptr %t964, i64 %t965)
  %t970 = insertvalue { i64, ptr } undef, i64 %t966, 0
  %t971 = insertvalue { i64, ptr } %t970, ptr %t967, 1
  %t973 = extractvalue { i64, ptr } %t971, 0
  %t974 = extractvalue { i64, ptr } %t971, 1
  %t975 = mul i64 %t973, 1
  %t976 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t975)
  call void @llvm.memcpy.p0.p0.i64(ptr %t976, ptr %t974, i64 %t975, i1 false)
  %t977 = insertvalue { i64, ptr } undef, i64 %t973, 0
  %t978 = insertvalue { i64, ptr } %t977, ptr %t976, 1
  %t981 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s33, ptr %s33, ptr %t956, { i64, ptr } %t978)
  store { i64, ptr } %t981, ptr %l378
  br label %bb156
bb156:
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t983 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t984 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t985 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t987 = extractvalue { i64, ptr } %t983, 1
  %t988 = extractvalue { i64, ptr } %t983, 0
  %t989 = add i64 %t985, %t988
  %t990 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t991 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t992 = add i64 %t989, %t991
  %t993 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t992)
  call void @olang_textcopy(ptr %t993, ptr %t984, i64 %t985)
  %t994 = getelementptr i8, ptr %t993, i64 %t985
  call void @olang_textcopy(ptr %t994, ptr %t987, i64 %t988)
  %t995 = getelementptr i8, ptr %t994, i64 %t988
  call void @olang_textcopy(ptr %t995, ptr %t990, i64 %t991)
  %t996 = insertvalue { i64, ptr } undef, i64 %t992, 0
  %t997 = insertvalue { i64, ptr } %t996, ptr %t993, 1
  %t999 = extractvalue { i64, ptr } %t997, 0
  %t1000 = extractvalue { i64, ptr } %t997, 1
  %t1001 = mul i64 %t999, 1
  %t1002 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1001)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1002, ptr %t1000, i64 %t1001, i1 false)
  %t1003 = insertvalue { i64, ptr } undef, i64 %t999, 0
  %t1004 = insertvalue { i64, ptr } %t1003, ptr %t1002, 1
  %t1007 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s33, ptr %s33, ptr %t982, { i64, ptr } %t1004)
  store { i64, ptr } %t1007, ptr %l383
  br label %bb157
bb157:
  %t1008 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t1009 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t1010 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t1011 = extractvalue { i64, ptr } %t1010, 1
  %t1012 = extractvalue { i64, ptr } %t1010, 0
  %t1013 = add i64 %t1009, %t1012
  %t1014 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t1015 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t1016 = add i64 %t1013, %t1015
  %t1017 = load { i64, ptr }, ptr %l383, !tbaa !27
  %t1018 = extractvalue { i64, ptr } %t1017, 1
  %t1019 = extractvalue { i64, ptr } %t1017, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1020)
  call void @olang_textcopy(ptr %t1021, ptr %t1008, i64 %t1009)
  %t1022 = getelementptr i8, ptr %t1021, i64 %t1009
  call void @olang_textcopy(ptr %t1022, ptr %t1011, i64 %t1012)
  %t1023 = getelementptr i8, ptr %t1022, i64 %t1012
  call void @olang_textcopy(ptr %t1023, ptr %t1014, i64 %t1015)
  %t1024 = getelementptr i8, ptr %t1023, i64 %t1015
  call void @olang_textcopy(ptr %t1024, ptr %t1018, i64 %t1019)
  %t1025 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1026 = insertvalue { i64, ptr } %t1025, ptr %t1021, 1
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  %t1029 = extractvalue { i64, ptr } %t1026, 1
  %t1030 = mul i64 %t1028, 1
  %t1031 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1030)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1031, ptr %t1029, i64 %t1030, i1 false)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1028, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1031, 1
  %t1034 = load ptr, ptr %l373, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %t1034, { i64, ptr } %t1033)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s33)
  br label %bb166
bb159:
  br i1 true, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb165
bb162:
  store %olang.scope zeroinitializer, ptr %s37
  store ptr %l24, ptr %l386, !tbaa !29
  %t1036 = load ptr, ptr %l0, !tbaa !29
  %t1037 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t1037, ptr %l388, !tbaa !27
  %t1038 = load i64, ptr %l40, !tbaa !24
  %t1040 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t1041 = load ptr, ptr %t1040, !tbaa !27
  %t1042 = getelementptr i32, ptr %t1041, i64 %t1038
  %t1043 = load i32, ptr %t1042, !tbaa !33
  %t1046 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s37, ptr %t1036, i32 %t1043)
  store { i64, ptr } %t1046, ptr %l391
  br label %bb163
bb163:
  %t1047 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1048 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t1049 = extractvalue { i64, ptr } %t1048, 1
  %t1050 = extractvalue { i64, ptr } %t1048, 0
  %t1051 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t1052 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t1053 = add i64 %t1050, %t1052
  %t1055 = extractvalue { i64, ptr } %t1047, 1
  %t1056 = extractvalue { i64, ptr } %t1047, 0
  %t1057 = add i64 %t1053, %t1056
  %t1058 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1057)
  call void @olang_textcopy(ptr %t1058, ptr %t1049, i64 %t1050)
  %t1059 = getelementptr i8, ptr %t1058, i64 %t1050
  call void @olang_textcopy(ptr %t1059, ptr %t1051, i64 %t1052)
  %t1060 = getelementptr i8, ptr %t1059, i64 %t1052
  call void @olang_textcopy(ptr %t1060, ptr %t1055, i64 %t1056)
  %t1061 = insertvalue { i64, ptr } undef, i64 %t1057, 0
  %t1062 = insertvalue { i64, ptr } %t1061, ptr %t1058, 1
  %t1064 = extractvalue { i64, ptr } %t1062, 0
  %t1065 = extractvalue { i64, ptr } %t1062, 1
  %t1066 = mul i64 %t1064, 1
  %t1067 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1066)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1067, ptr %t1065, i64 %t1066, i1 false)
  %t1068 = insertvalue { i64, ptr } undef, i64 %t1064, 0
  %t1069 = insertvalue { i64, ptr } %t1068, ptr %t1067, 1
  %t1070 = load ptr, ptr %l386, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %t1070, { i64, ptr } %t1069)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s37)
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_9199a3ab2b5d08f_bd3a4c654376a573)
  unreachable
bb166:
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb167:
  %t1072 = load i64, ptr %l39, !tbaa !24
  %t1074 = add i64 %t1072, 1
  store i64 %t1074, ptr %l39, !tbaa !24
  br label %bb121
bb168:
  %t1076 = load i1, ptr %l7, !tbaa !21
  br i1 %t1076, label %bb169, label %bb170
bb169:
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1080 = getelementptr %"compiler/emit:fnEm", ptr %t1078, i32 0, i32 0
  %t1081 = load ptr, ptr %t1080, !tbaa !29
  %t1082 = load i32, ptr %l3, !tbaa !23
  %t1085 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s0, ptr %t1081, i32 %t1082)
  store { i64, ptr } %t1085, ptr %l402
  br label %bb171
bb170:
  %t1086 = load ptr, ptr %l2, !tbaa !29
  %t1087 = load i32, ptr %l3, !tbaa !23
  %t1090 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t1086, i32 %t1087)
  store { i64, ptr } %t1090, ptr %l405
  br label %bb172
bb171:
  %t1091 = load { i64, ptr }, ptr %l402, !tbaa !27
  store { i64, ptr } %t1091, ptr %l398, !tbaa !27
  br label %bb173
bb172:
  %t1092 = load { i64, ptr }, ptr %l405, !tbaa !27
  store { i64, ptr } %t1092, ptr %l398, !tbaa !27
  br label %bb173
bb173:
  %t1093 = load { i64, ptr }, ptr %l398, !tbaa !27
  store { i64, ptr } %t1093, ptr %l45, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d145, i32 0, i32 1) }, ptr %l406, !tbaa !27
  %t1094 = load { i64, ptr }, ptr %l406, !tbaa !27
  store { i64, ptr } %t1094, ptr %l407, !tbaa !27
  %t1095 = load { i64, ptr }, ptr %l407, !tbaa !27
  %t1096 = extractvalue { i64, ptr } %t1095, 0
  store i64 %t1096, ptr %l408, !tbaa !24
  %t1097 = load i64, ptr %l408, !tbaa !24
  %t1098 = mul i64 %t1097, 1
  %t1099 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1098)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1097, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1099, 1
  store { i64, ptr } %t1101, ptr %l409, !tbaa !27
  %t1102 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t1103 = load ptr, ptr %t1102, !tbaa !27
  %t1104 = getelementptr { i64, ptr }, ptr %l407, i32 0, i32 1
  %t1105 = load ptr, ptr %t1104, !tbaa !27
  %t1106 = load i64, ptr %l408, !tbaa !24
  %t1107 = mul i64 %t1106, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1103, ptr %t1105, i64 %t1107, i1 false)
  %t1108 = load { i64, ptr }, ptr %l409, !tbaa !27
  store { i64, ptr } %t1108, ptr %l46, !tbaa !27
  %t1109 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1109, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store i1 %t1111, ptr %l411
  br label %bb174
bb174:
  %t1112 = load i1, ptr %l411, !tbaa !21
  br i1 %t1112, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s40
  %t1113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1113, ptr %l412, !tbaa !29
  %t1114 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1114, ptr %l413, !tbaa !27
  %t1116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s40, ptr %l24)
  store { i64, ptr } %t1116, ptr %l415
  br label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s42
  %t1117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1117, ptr %l418, !tbaa !29
  %t1118 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1118, ptr %l419, !tbaa !27
  %t1119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1119, ptr %l420, !tbaa !27
  %t1121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s42, ptr %l24)
  store { i64, ptr } %t1121, ptr %l422
  br label %bb179
bb177:
  %t1122 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t1123 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t1124 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t1125 = extractvalue { i64, ptr } %t1124, 1
  %t1126 = extractvalue { i64, ptr } %t1124, 0
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t1129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = load { i64, ptr }, ptr %l415, !tbaa !27
  %t1132 = extractvalue { i64, ptr } %t1131, 1
  %t1133 = extractvalue { i64, ptr } %t1131, 0
  %t1134 = add i64 %t1130, %t1133
  %t1135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t1136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t1137 = add i64 %t1134, %t1136
  %t1138 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1137)
  call void @olang_textcopy(ptr %t1138, ptr %t1122, i64 %t1123)
  %t1139 = getelementptr i8, ptr %t1138, i64 %t1123
  call void @olang_textcopy(ptr %t1139, ptr %t1125, i64 %t1126)
  %t1140 = getelementptr i8, ptr %t1139, i64 %t1126
  call void @olang_textcopy(ptr %t1140, ptr %t1128, i64 %t1129)
  %t1141 = getelementptr i8, ptr %t1140, i64 %t1129
  call void @olang_textcopy(ptr %t1141, ptr %t1132, i64 %t1133)
  %t1142 = getelementptr i8, ptr %t1141, i64 %t1133
  call void @olang_textcopy(ptr %t1142, ptr %t1135, i64 %t1136)
  %t1143 = insertvalue { i64, ptr } undef, i64 %t1137, 0
  %t1144 = insertvalue { i64, ptr } %t1143, ptr %t1138, 1
  %t1146 = extractvalue { i64, ptr } %t1144, 0
  %t1147 = extractvalue { i64, ptr } %t1144, 1
  %t1148 = mul i64 %t1146, 1
  %t1149 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1149, ptr %t1147, i64 %t1148, i1 false)
  %t1150 = insertvalue { i64, ptr } undef, i64 %t1146, 0
  %t1151 = insertvalue { i64, ptr } %t1150, ptr %t1149, 1
  %t1152 = load ptr, ptr %l412, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s40, ptr %t1152, { i64, ptr } %t1151)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s40)
  br label %bb184
bb179:
  %t1154 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t1155 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t1156 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1156, 1
  %t1158 = extractvalue { i64, ptr } %t1156, 0
  %t1159 = add i64 %t1155, %t1158
  %t1160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t1162 = add i64 %t1159, %t1161
  %t1163 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t1164 = extractvalue { i64, ptr } %t1163, 1
  %t1165 = extractvalue { i64, ptr } %t1163, 0
  %t1166 = add i64 %t1162, %t1165
  %t1167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t1168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t1169 = add i64 %t1166, %t1168
  %t1170 = load { i64, ptr }, ptr %l422, !tbaa !27
  %t1171 = extractvalue { i64, ptr } %t1170, 1
  %t1172 = extractvalue { i64, ptr } %t1170, 0
  %t1173 = add i64 %t1169, %t1172
  %t1174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t1175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t1176 = add i64 %t1173, %t1175
  %t1177 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1176)
  call void @olang_textcopy(ptr %t1177, ptr %t1154, i64 %t1155)
  %t1178 = getelementptr i8, ptr %t1177, i64 %t1155
  call void @olang_textcopy(ptr %t1178, ptr %t1157, i64 %t1158)
  %t1179 = getelementptr i8, ptr %t1178, i64 %t1158
  call void @olang_textcopy(ptr %t1179, ptr %t1160, i64 %t1161)
  %t1180 = getelementptr i8, ptr %t1179, i64 %t1161
  call void @olang_textcopy(ptr %t1180, ptr %t1164, i64 %t1165)
  %t1181 = getelementptr i8, ptr %t1180, i64 %t1165
  call void @olang_textcopy(ptr %t1181, ptr %t1167, i64 %t1168)
  %t1182 = getelementptr i8, ptr %t1181, i64 %t1168
  call void @olang_textcopy(ptr %t1182, ptr %t1171, i64 %t1172)
  %t1183 = getelementptr i8, ptr %t1182, i64 %t1172
  call void @olang_textcopy(ptr %t1183, ptr %t1174, i64 %t1175)
  %t1184 = insertvalue { i64, ptr } undef, i64 %t1176, 0
  %t1185 = insertvalue { i64, ptr } %t1184, ptr %t1177, 1
  %t1187 = extractvalue { i64, ptr } %t1185, 0
  %t1188 = extractvalue { i64, ptr } %t1185, 1
  %t1189 = mul i64 %t1187, 1
  %t1190 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1190, ptr %t1188, i64 %t1189, i1 false)
  %t1191 = insertvalue { i64, ptr } undef, i64 %t1187, 0
  %t1192 = insertvalue { i64, ptr } %t1191, ptr %t1190, 1
  %t1193 = load ptr, ptr %l418, !tbaa !29
  %t1195 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1193, { i64, ptr } %t1192)
  store { i64, ptr } %t1195, ptr %l425
  br label %bb180
bb180:
  %t1196 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1197 = extractvalue { i64, ptr } %t1196, 0
  %t1198 = load { i64, ptr }, ptr %l425, !tbaa !27
  %t1199 = extractvalue { i64, ptr } %t1198, 0
  store i64 %t1199, ptr %l427, !tbaa !24
  %t1201 = load i64, ptr %l427, !tbaa !24
  %t1202 = icmp eq i64 %t1197, %t1201
  br i1 %t1202, label %bb181, label %bb182
bb181:
  %t1204 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1205 = load ptr, ptr %t1204, !tbaa !27
  %t1206 = getelementptr { i64, ptr }, ptr %l425, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206, !tbaa !27
  %t1208 = load i64, ptr %l427, !tbaa !24
  %t1209 = mul i64 %t1208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1205, ptr %t1207, i64 %t1209, i1 false)
  br label %bb183
bb182:
  %t1210 = load { i64, ptr }, ptr %l425, !tbaa !27
  store { i64, ptr } %t1210, ptr %l46, !tbaa !27
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s42)
  br label %bb184
bb184:
  %t1211 = load i32, ptr %l21, !tbaa !23
  %t1212 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1215 = icmp eq i32 %t1211, %t1212
  br i1 %t1215, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s44
  %t1217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s44, ptr %t1217, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb187
bb186:
  br label %bb188
bb187:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb188:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) }, ptr %l433, !tbaa !27
  %t1219 = load { i64, ptr }, ptr %l433, !tbaa !27
  store { i64, ptr } %t1219, ptr %l434, !tbaa !27
  %t1220 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t1221 = extractvalue { i64, ptr } %t1220, 0
  store i64 %t1221, ptr %l435, !tbaa !24
  %t1222 = load i64, ptr %l435, !tbaa !24
  %t1223 = mul i64 %t1222, 1
  %t1224 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1223)
  %t1225 = insertvalue { i64, ptr } undef, i64 %t1222, 0
  %t1226 = insertvalue { i64, ptr } %t1225, ptr %t1224, 1
  store { i64, ptr } %t1226, ptr %l436, !tbaa !27
  %t1227 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t1228 = load ptr, ptr %t1227, !tbaa !27
  %t1229 = getelementptr { i64, ptr }, ptr %l434, i32 0, i32 1
  %t1230 = load ptr, ptr %t1229, !tbaa !27
  %t1231 = load i64, ptr %l435, !tbaa !24
  %t1232 = mul i64 %t1231, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1228, ptr %t1230, i64 %t1232, i1 false)
  %t1233 = load { i64, ptr }, ptr %l436, !tbaa !27
  store { i64, ptr } %t1233, ptr %l47, !tbaa !27
  %t1234 = load i1, ptr %l23, !tbaa !21
  br i1 %t1234, label %bb189, label %bb190
bb189:
  %t1236 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1236, ptr %l438, !tbaa !27
  %t1237 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1238 = extractvalue { i64, ptr } %t1237, 0
  %t1239 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1239, 0
  store i64 %t1240, ptr %l440, !tbaa !24
  %t1242 = load i64, ptr %l440, !tbaa !24
  %t1243 = icmp eq i64 %t1238, %t1242
  br i1 %t1243, label %bb191, label %bb192
bb190:
  %t1245 = load i32, ptr %l21, !tbaa !23
  %t1246 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1249 = icmp ne i32 %t1245, %t1246
  br i1 %t1249, label %bb194, label %bb195
bb191:
  %t1251 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1252 = load ptr, ptr %t1251, !tbaa !27
  %t1253 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t1254 = load ptr, ptr %t1253, !tbaa !27
  %t1255 = load i64, ptr %l440, !tbaa !24
  %t1256 = mul i64 %t1255, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1252, ptr %t1254, i64 %t1256, i1 false)
  br label %bb193
bb192:
  %t1257 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1258 = extractvalue { i64, ptr } %t1257, 0
  store i64 %t1258, ptr %l442, !tbaa !24
  %t1259 = load i64, ptr %l442, !tbaa !24
  %t1260 = mul i64 %t1259, 1
  %t1261 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1260)
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1261, 1
  store { i64, ptr } %t1263, ptr %l443, !tbaa !27
  %t1264 = getelementptr { i64, ptr }, ptr %l443, i32 0, i32 1
  %t1265 = load ptr, ptr %t1264, !tbaa !27
  %t1266 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t1267 = load ptr, ptr %t1266, !tbaa !27
  %t1268 = load i64, ptr %l442, !tbaa !24
  %t1269 = mul i64 %t1268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1265, ptr %t1267, i64 %t1269, i1 false)
  %t1270 = load { i64, ptr }, ptr %l443, !tbaa !27
  store { i64, ptr } %t1270, ptr %l47, !tbaa !27
  br label %bb193
bb193:
  br label %bb204
bb194:
  %t1271 = load i1, ptr %l22, !tbaa !21
  br i1 %t1271, label %bb196, label %bb197
bb195:
  br label %bb203
bb196:
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1274 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1275 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1276 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t1277 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t1279 = extractvalue { i64, ptr } %t1274, 1
  %t1280 = extractvalue { i64, ptr } %t1274, 0
  %t1281 = add i64 %t1277, %t1280
  %t1282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t1283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t1284 = add i64 %t1281, %t1283
  %t1286 = extractvalue { i64, ptr } %t1275, 1
  %t1287 = extractvalue { i64, ptr } %t1275, 0
  %t1288 = add i64 %t1284, %t1287
  %t1289 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t1290 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t1291 = add i64 %t1288, %t1290
  %t1292 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1291)
  call void @olang_textcopy(ptr %t1292, ptr %t1276, i64 %t1277)
  %t1293 = getelementptr i8, ptr %t1292, i64 %t1277
  call void @olang_textcopy(ptr %t1293, ptr %t1279, i64 %t1280)
  %t1294 = getelementptr i8, ptr %t1293, i64 %t1280
  call void @olang_textcopy(ptr %t1294, ptr %t1282, i64 %t1283)
  %t1295 = getelementptr i8, ptr %t1294, i64 %t1283
  call void @olang_textcopy(ptr %t1295, ptr %t1286, i64 %t1287)
  %t1296 = getelementptr i8, ptr %t1295, i64 %t1287
  call void @olang_textcopy(ptr %t1296, ptr %t1289, i64 %t1290)
  %t1297 = insertvalue { i64, ptr } undef, i64 %t1291, 0
  %t1298 = insertvalue { i64, ptr } %t1297, ptr %t1292, 1
  %t1300 = extractvalue { i64, ptr } %t1298, 0
  %t1301 = extractvalue { i64, ptr } %t1298, 1
  %t1302 = mul i64 %t1300, 1
  %t1303 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1303, ptr %t1301, i64 %t1302, i1 false)
  %t1304 = insertvalue { i64, ptr } undef, i64 %t1300, 0
  %t1305 = insertvalue { i64, ptr } %t1304, ptr %t1303, 1
  %t1308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1273, { i64, ptr } %t1305)
  store { i64, ptr } %t1308, ptr %l454
  br label %bb198
bb197:
  %t1309 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1309, ptr %l448, !tbaa !27
  br label %bb199
bb198:
  %t1311 = load { i64, ptr }, ptr %l454, !tbaa !27
  store { i64, ptr } %t1311, ptr %l448, !tbaa !27
  br label %bb199
bb199:
  %t1312 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1313 = extractvalue { i64, ptr } %t1312, 0
  %t1314 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t1315 = extractvalue { i64, ptr } %t1314, 0
  store i64 %t1315, ptr %l457, !tbaa !24
  %t1317 = load i64, ptr %l457, !tbaa !24
  %t1318 = icmp eq i64 %t1313, %t1317
  br i1 %t1318, label %bb200, label %bb201
bb200:
  %t1320 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1321 = load ptr, ptr %t1320, !tbaa !27
  %t1322 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t1323 = load ptr, ptr %t1322, !tbaa !27
  %t1324 = load i64, ptr %l457, !tbaa !24
  %t1325 = mul i64 %t1324, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1321, ptr %t1323, i64 %t1325, i1 false)
  br label %bb202
bb201:
  %t1326 = load { i64, ptr }, ptr %l448, !tbaa !27
  store { i64, ptr } %t1326, ptr %l47, !tbaa !27
  br label %bb202
bb202:
  br label %bb203
bb203:
  br label %bb204
bb204:
  %t1327 = load i1, ptr %l22, !tbaa !21
  br i1 %t1327, label %bb205, label %bb206
bb205:
  store %olang.scope zeroinitializer, ptr %s49
  %t1329 = load i1, ptr %l23, !tbaa !21
  br i1 %t1329, label %bb207, label %bb208
bb206:
  br label %bb224
bb207:
  store i1 true, ptr %l461, !tbaa !21
  br label %bb209
bb208:
  %t1331 = load i32, ptr %l21, !tbaa !23
  %t1332 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1335 = icmp eq i32 %t1331, %t1332
  store i1 %t1335, ptr %l461, !tbaa !21
  br label %bb209
bb209:
  %t1337 = load i1, ptr %l461, !tbaa !21
  br i1 %t1337, label %bb210, label %bb211
bb210:
  %t1338 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1338, ptr %l465, !tbaa !27
  br label %bb213
bb211:
  %t1340 = load ptr, ptr %l0, !tbaa !29
  %t1341 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1342 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1343 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t1344 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t1346 = extractvalue { i64, ptr } %t1341, 1
  %t1347 = extractvalue { i64, ptr } %t1341, 0
  %t1348 = add i64 %t1344, %t1347
  %t1349 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t1350 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t1351 = add i64 %t1348, %t1350
  %t1353 = extractvalue { i64, ptr } %t1342, 1
  %t1354 = extractvalue { i64, ptr } %t1342, 0
  %t1355 = add i64 %t1351, %t1354
  %t1356 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t1357 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t1358 = add i64 %t1355, %t1357
  %t1359 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1358)
  call void @olang_textcopy(ptr %t1359, ptr %t1343, i64 %t1344)
  %t1360 = getelementptr i8, ptr %t1359, i64 %t1344
  call void @olang_textcopy(ptr %t1360, ptr %t1346, i64 %t1347)
  %t1361 = getelementptr i8, ptr %t1360, i64 %t1347
  call void @olang_textcopy(ptr %t1361, ptr %t1349, i64 %t1350)
  %t1362 = getelementptr i8, ptr %t1361, i64 %t1350
  call void @olang_textcopy(ptr %t1362, ptr %t1353, i64 %t1354)
  %t1363 = getelementptr i8, ptr %t1362, i64 %t1354
  call void @olang_textcopy(ptr %t1363, ptr %t1356, i64 %t1357)
  %t1364 = insertvalue { i64, ptr } undef, i64 %t1358, 0
  %t1365 = insertvalue { i64, ptr } %t1364, ptr %t1359, 1
  %t1367 = extractvalue { i64, ptr } %t1365, 0
  %t1368 = extractvalue { i64, ptr } %t1365, 1
  %t1369 = mul i64 %t1367, 1
  %t1370 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1370, ptr %t1368, i64 %t1369, i1 false)
  %t1371 = insertvalue { i64, ptr } undef, i64 %t1367, 0
  %t1372 = insertvalue { i64, ptr } %t1371, ptr %t1370, 1
  %t1375 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1340, { i64, ptr } %t1372)
  store { i64, ptr } %t1375, ptr %l472
  br label %bb212
bb212:
  %t1376 = load { i64, ptr }, ptr %l472, !tbaa !27
  store { i64, ptr } %t1376, ptr %l465, !tbaa !27
  br label %bb213
bb213:
  %t1377 = load { i64, ptr }, ptr %l465, !tbaa !27
  store { i64, ptr } %t1377, ptr %l48, !tbaa !27
  %t1378 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t1379 = load i32, ptr %t1378, !tbaa !23
  %t1380 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t1383 = icmp ne i32 %t1379, %t1380
  br i1 %t1383, label %bb214, label %bb215
bb214:
  store %olang.scope zeroinitializer, ptr %s51
  %t1385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1385, ptr %l476, !tbaa !29
  %t1386 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t1386, ptr %l477, !tbaa !27
  %t1387 = load ptr, ptr %l0, !tbaa !29
  %t1388 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t1389 = load i32, ptr %t1388, !tbaa !23
  %t1392 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s51, ptr %t1387, i32 %t1389)
  store { i64, ptr } %t1392, ptr %l480
  br label %bb216
bb215:
  br label %bb218
bb216:
  %t1393 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t1394 = extractvalue { i64, ptr } %t1393, 0
  %t1395 = extractvalue { i64, ptr } %t1393, 1
  %t1396 = mul i64 %t1394, 1
  %t1397 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1397, ptr %t1395, i64 %t1396, i1 false)
  %t1398 = insertvalue { i64, ptr } undef, i64 %t1394, 0
  %t1399 = insertvalue { i64, ptr } %t1398, ptr %t1397, 1
  %t1400 = load ptr, ptr %l476, !tbaa !29
  %t1401 = load { i64, ptr }, ptr %l477, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s51, ptr %s49, ptr %s51, ptr %s51, ptr %t1400, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d162, i32 0, i32 1) }, { i64, ptr } %t1401, { i64, ptr } %t1399, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s51)
  br label %bb218
bb218:
  %t1403 = load ptr, ptr %l0, !tbaa !29
  %t1404 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1405 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t1406 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t1408 = extractvalue { i64, ptr } %t1404, 1
  %t1409 = extractvalue { i64, ptr } %t1404, 0
  %t1410 = add i64 %t1406, %t1409
  %t1411 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t1412 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t1413 = add i64 %t1410, %t1412
  %t1414 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1413)
  call void @olang_textcopy(ptr %t1414, ptr %t1405, i64 %t1406)
  %t1415 = getelementptr i8, ptr %t1414, i64 %t1406
  call void @olang_textcopy(ptr %t1415, ptr %t1408, i64 %t1409)
  %t1416 = getelementptr i8, ptr %t1415, i64 %t1409
  call void @olang_textcopy(ptr %t1416, ptr %t1411, i64 %t1412)
  %t1417 = insertvalue { i64, ptr } undef, i64 %t1413, 0
  %t1418 = insertvalue { i64, ptr } %t1417, ptr %t1414, 1
  %t1420 = extractvalue { i64, ptr } %t1418, 0
  %t1421 = extractvalue { i64, ptr } %t1418, 1
  %t1422 = mul i64 %t1420, 1
  %t1423 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1422)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1423, ptr %t1421, i64 %t1422, i1 false)
  %t1424 = insertvalue { i64, ptr } undef, i64 %t1420, 0
  %t1425 = insertvalue { i64, ptr } %t1424, ptr %t1423, 1
  %t1428 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1403, { i64, ptr } %t1425)
  store { i64, ptr } %t1428, ptr %l486
  br label %bb219
bb219:
  %t1429 = load { i64, ptr }, ptr %l486, !tbaa !27
  store { i64, ptr } %t1429, ptr %l49, !tbaa !27
  %t1430 = load ptr, ptr %l0, !tbaa !29
  %t1432 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s49, ptr %s49, ptr %t1430, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store { i64, ptr } %t1432, ptr %l488
  br label %bb220
bb220:
  %t1433 = load { i64, ptr }, ptr %l488, !tbaa !27
  store { i64, ptr } %t1433, ptr %l50, !tbaa !27
  %t1434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1434, ptr %l489, !tbaa !29
  %t1435 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t1435, ptr %l490, !tbaa !27
  %t1436 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t1437 = load i32, ptr %t1436, !tbaa !23
  %t1439 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s49, i32 %t1437)
  store { i64, ptr } %t1439, ptr %l492
  br label %bb221
bb221:
  %t1440 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1441 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t1442 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t1443 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t1444 = extractvalue { i64, ptr } %t1443, 1
  %t1445 = extractvalue { i64, ptr } %t1443, 0
  %t1446 = add i64 %t1442, %t1445
  %t1447 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t1448 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t1449 = add i64 %t1446, %t1448
  %t1450 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t1451 = extractvalue { i64, ptr } %t1450, 1
  %t1452 = extractvalue { i64, ptr } %t1450, 0
  %t1453 = add i64 %t1449, %t1452
  %t1454 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t1455 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t1456 = add i64 %t1453, %t1455
  %t1458 = extractvalue { i64, ptr } %t1440, 1
  %t1459 = extractvalue { i64, ptr } %t1440, 0
  %t1460 = add i64 %t1456, %t1459
  %t1461 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1460)
  call void @olang_textcopy(ptr %t1461, ptr %t1441, i64 %t1442)
  %t1462 = getelementptr i8, ptr %t1461, i64 %t1442
  call void @olang_textcopy(ptr %t1462, ptr %t1444, i64 %t1445)
  %t1463 = getelementptr i8, ptr %t1462, i64 %t1445
  call void @olang_textcopy(ptr %t1463, ptr %t1447, i64 %t1448)
  %t1464 = getelementptr i8, ptr %t1463, i64 %t1448
  call void @olang_textcopy(ptr %t1464, ptr %t1451, i64 %t1452)
  %t1465 = getelementptr i8, ptr %t1464, i64 %t1452
  call void @olang_textcopy(ptr %t1465, ptr %t1454, i64 %t1455)
  %t1466 = getelementptr i8, ptr %t1465, i64 %t1455
  call void @olang_textcopy(ptr %t1466, ptr %t1458, i64 %t1459)
  %t1467 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1468 = insertvalue { i64, ptr } %t1467, ptr %t1461, 1
  %t1470 = extractvalue { i64, ptr } %t1468, 0
  %t1471 = extractvalue { i64, ptr } %t1468, 1
  %t1472 = mul i64 %t1470, 1
  %t1473 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1472)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1473, ptr %t1471, i64 %t1472, i1 false)
  %t1474 = insertvalue { i64, ptr } undef, i64 %t1470, 0
  %t1475 = insertvalue { i64, ptr } %t1474, ptr %t1473, 1
  %t1476 = load ptr, ptr %l489, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s49, ptr %t1476, { i64, ptr } %t1475)
  br label %bb222
bb222:
  %t1478 = load ptr, ptr %l0, !tbaa !29
  %t1479 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s49, ptr %t1478, { i64, ptr } %t1479)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s49)
  br label %bb224
bb224:
  %t1482 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t1483 = load i1, ptr %t1482, !tbaa !21
  br i1 %t1483, label %bb225, label %bb226
bb225:
  %t1485 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1487 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1485, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i1 %t1487, ptr %l501
  br label %bb227
bb226:
  store i1 false, ptr %l499, !tbaa !21
  br label %bb228
bb227:
  %t1488 = load i1, ptr %l501, !tbaa !21
  %t1489 = xor i1 %t1488, true
  store i1 %t1489, ptr %l499, !tbaa !21
  br label %bb228
bb228:
  %t1491 = load i1, ptr %l499, !tbaa !21
  br i1 %t1491, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s54
  %t1492 = load ptr, ptr %l0, !tbaa !29
  %t1493 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t1494 = load %"compiler/mir:Place", ptr %t1493
  %t1497 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s54, ptr %t1492, %"compiler/mir:Place" %t1494)
  store { { i64, ptr }, i32 } %t1497, ptr %l505
  br label %bb231
bb230:
  br label %bb239
bb231:
  %t1498 = load { { i64, ptr }, i32 }, ptr %l505
  store { { i64, ptr }, i32 } %t1498, ptr %l51
  %t1499 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t1500 = load { i64, ptr }, ptr %t1499, !tbaa !27
  store { i64, ptr } %t1500, ptr %l506, !tbaa !27
  %t1501 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t1502 = extractvalue { i64, ptr } %t1501, 0
  store i64 %t1502, ptr %l507, !tbaa !24
  %t1503 = load i64, ptr %l507, !tbaa !24
  %t1504 = mul i64 %t1503, 1
  %t1505 = call ptr @__olang_scope_alloc_zeroed(ptr %s54, i64 %t1504)
  %t1506 = insertvalue { i64, ptr } undef, i64 %t1503, 0
  %t1507 = insertvalue { i64, ptr } %t1506, ptr %t1505, 1
  store { i64, ptr } %t1507, ptr %l508, !tbaa !27
  %t1508 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1509 = load ptr, ptr %t1508, !tbaa !27
  %t1510 = getelementptr { i64, ptr }, ptr %l506, i32 0, i32 1
  %t1511 = load ptr, ptr %t1510, !tbaa !27
  %t1512 = load i64, ptr %l507, !tbaa !24
  %t1513 = mul i64 %t1512, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1509, ptr %t1511, i64 %t1513, i1 false)
  %t1514 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1514, ptr %l52, !tbaa !27
  %t1515 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 1
  %t1516 = load i32, ptr %t1515, !tbaa !23
  store i32 %t1516, ptr %l53, !tbaa !23
  %t1518 = load i1, ptr %l23, !tbaa !21
  br i1 %t1518, label %bb232, label %bb233
bb232:
  %t1520 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1520, ptr %l511, !tbaa !29
  %t1521 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1521, ptr %l512, !tbaa !27
  %t1522 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1522, ptr %l513, !tbaa !27
  %t1523 = load ptr, ptr %l0, !tbaa !29
  %t1524 = load i32, ptr %l21, !tbaa !23
  %t1527 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1523, i32 %t1524)
  store i64 %t1527, ptr %l516
  br label %bb234
bb233:
  store %olang.scope zeroinitializer, ptr %s56
  %t1528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1528, ptr %l517, !tbaa !29
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1530 = load i32, ptr %l53, !tbaa !23
  %t1533 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s56, ptr %t1529, i32 %t1530)
  store { i64, ptr } %t1533, ptr %l520
  br label %bb236
bb234:
  %t1534 = load ptr, ptr %l511, !tbaa !29
  %t1535 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t1536 = load { i64, ptr }, ptr %l513, !tbaa !27
  %t1537 = load i64, ptr %l516, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s54, ptr %s0, ptr %t1534, { i64, ptr } %t1535, { i64, ptr } %t1536, i64 %t1537)
  br label %bb235
bb235:
  br label %bb238
bb236:
  %t1538 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1539 = extractvalue { i64, ptr } %t1538, 0
  %t1540 = extractvalue { i64, ptr } %t1538, 1
  %t1541 = mul i64 %t1539, 1
  %t1542 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1541)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1542, ptr %t1540, i64 %t1541, i1 false)
  %t1543 = insertvalue { i64, ptr } undef, i64 %t1539, 0
  %t1544 = insertvalue { i64, ptr } %t1543, ptr %t1542, 1
  %t1545 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1546 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1547 = load ptr, ptr %l517, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s56, ptr %s0, ptr %s54, ptr %s56, ptr %t1547, { i64, ptr } %t1544, { i64, ptr } %t1545, { i64, ptr } %t1546, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s56)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s54)
  br label %bb239
bb239:
  %t1551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1551, ptr %l524, !tbaa !29
  %t1552 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t1553 = load i32, ptr %t1552, !tbaa !23
  %t1555 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %t1553)
  store { i64, ptr } %t1555, ptr %l526
  br label %bb240
bb240:
  %t1556 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t1557 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t1558 = load { i64, ptr }, ptr %l526, !tbaa !27
  %t1559 = extractvalue { i64, ptr } %t1558, 1
  %t1560 = extractvalue { i64, ptr } %t1558, 0
  %t1561 = add i64 %t1557, %t1560
  %t1562 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1561)
  call void @olang_textcopy(ptr %t1562, ptr %t1556, i64 %t1557)
  %t1563 = getelementptr i8, ptr %t1562, i64 %t1557
  call void @olang_textcopy(ptr %t1563, ptr %t1559, i64 %t1560)
  %t1564 = insertvalue { i64, ptr } undef, i64 %t1561, 0
  %t1565 = insertvalue { i64, ptr } %t1564, ptr %t1562, 1
  %t1567 = extractvalue { i64, ptr } %t1565, 0
  %t1568 = extractvalue { i64, ptr } %t1565, 1
  %t1569 = mul i64 %t1567, 1
  %t1570 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1569)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1570, ptr %t1568, i64 %t1569, i1 false)
  %t1571 = insertvalue { i64, ptr } undef, i64 %t1567, 0
  %t1572 = insertvalue { i64, ptr } %t1571, ptr %t1570, 1
  %t1573 = load ptr, ptr %l524, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1573, { i64, ptr } %t1572)
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3, i32 %a4, i64 %a5, i64 %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:TaskClause"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"compiler/typed:Item"
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l54 = alloca i32
  %l60 = alloca i32
  %l63 = alloca i32
  %l89 = alloca %"compiler/mir:TaskClause"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l107 = alloca i32
  %l110 = alloca i32
  %l136 = alloca %"compiler/typed:Item"
  %l140 = alloca i64
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l188 = alloca i32
  %l203 = alloca %"std/prelude/text:StringBuilder"
  %l210 = alloca i32
  %l214 = alloca i1
  %l218 = alloca i1
  %l221 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i32
  %l227 = alloca { i64, ptr }
  %l238 = alloca i64
  %l242 = alloca i64
  %l245 = alloca i64
  %l278 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca { i64, ptr }
  %l284 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i32
  %l288 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca i32
  %l293 = alloca { i64, ptr }
  %l294 = alloca i32
  %l296 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l302 = alloca i64
  %l305 = alloca ptr
  %l306 = alloca i32
  %l309 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l316 = alloca i64
  %l319 = alloca i1
  %l321 = alloca i1
  %l326 = alloca ptr
  %l327 = alloca i32
  %l328 = alloca i64
  %l331 = alloca { i64, ptr }
  %l336 = alloca ptr
  %l337 = alloca ptr
  %l340 = alloca i32
  %l341 = alloca i32
  %l342 = alloca { i64, ptr }
  %l347 = alloca i32
  %l350 = alloca i32
  %l377 = alloca ptr
  %l378 = alloca i32
  %l379 = alloca i32
  %l382 = alloca { i64, ptr }
  %l387 = alloca ptr
  %l389 = alloca { i64, ptr }
  %l392 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %t725 = alloca { i64, [4 x i64] }, align 8
  %t728 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/mir:Task" %a3, ptr %l3
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t11, i32 %a4)
  store i32 %t15, ptr %l54
  br label %bb1
bb1:
  %t16 = load i32, ptr %l54, !tbaa !23
  store i32 %t16, ptr %l10, !tbaa !23
  store i64 %a5, ptr %l11, !tbaa !24
  store i32 0, ptr %l12, !tbaa !23
  %t19 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t20 = getelementptr %"compiler/mir:Range", ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t23 = load i32, ptr %l13, !tbaa !23
  %t24 = load i32, ptr %l12, !tbaa !23
  %t27 = icmp sgt i32 %t23, %t24
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t31 = icmp sgt i32 %t29, 0
  br i1 %t31, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l60, !tbaa !23
  br label %bb7
bb4:
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = load i32, ptr %l12, !tbaa !23
  %t37 = sub i32 %t33, %t34
  %t38 = load i32, ptr %l14, !tbaa !23
  %t41 = add i32 %t37, %t38
  %t43 = sub i32 %t41, 1
  %t44 = load i32, ptr %l14, !tbaa !23
  %t47 = sdiv i32 %t43, %t44
  store i32 %t47, ptr %l63, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l63, !tbaa !23
  br label %bb6
bb6:
  %t49 = load i32, ptr %l63, !tbaa !23
  store i32 %t49, ptr %l60, !tbaa !23
  br label %bb7
bb7:
  %t50 = load i32, ptr %l60, !tbaa !23
  store i32 %t50, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i32, ptr %l16, !tbaa !23
  %t52 = load i32, ptr %l15, !tbaa !23
  %t55 = icmp slt i32 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb10:
  br label %bb11
bb11:
  %t59 = load i32, ptr %l12, !tbaa !23
  %t60 = load i32, ptr %l16, !tbaa !23
  %t61 = load i32, ptr %l14, !tbaa !23
  %t64 = mul i32 %t60, %t61
  %t67 = add i32 %t59, %t64
  store i32 %t67, ptr %l17, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 17
  %t75 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i32, ptr %l17, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = add i64 %t79, %t82
  %t88 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t74, i64 %t85)
  store %"compiler/mir:TaskClause" %t88, ptr %l89
  br label %bb12
bb12:
  %t89 = load %"compiler/mir:TaskClause", ptr %l89
  store %"compiler/mir:TaskClause" %t89, ptr %l18
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t90, ptr %l91, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l92, !tbaa !24
  %t93 = load i64, ptr %l92, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l93, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l92, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t104, ptr %l19, !tbaa !27
  %t105 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 1
  %t106 = load i1, ptr %t105, !tbaa !21
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t110, ptr %l97, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l99, !tbaa !24
  %t116 = load i64, ptr %l99, !tbaa !24
  %t117 = icmp eq i64 %t112, %t116
  br i1 %t117, label %bb15, label %bb16
bb14:
  br label %bb41
bb15:
  %t119 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l99, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  br label %bb17
bb16:
  %t125 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l101, !tbaa !24
  %t127 = load i64, ptr %l101, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l102, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l101, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t138, ptr %l19, !tbaa !27
  br label %bb17
bb17:
  store i32 0, ptr %l20, !tbaa !23
  %t139 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t140 = getelementptr %"compiler/mir:Range", ptr %t139, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l21, !tbaa !23
  store i32 1, ptr %l22, !tbaa !23
  %t143 = load i32, ptr %l21, !tbaa !23
  %t144 = load i32, ptr %l20, !tbaa !23
  %t147 = icmp sgt i32 %t143, %t144
  br i1 %t147, label %bb18, label %bb19
bb18:
  %t149 = load i32, ptr %l22, !tbaa !23
  %t151 = icmp sgt i32 %t149, 0
  br i1 %t151, label %bb20, label %bb21
bb19:
  store i32 0, ptr %l107, !tbaa !23
  br label %bb23
bb20:
  %t153 = load i32, ptr %l21, !tbaa !23
  %t154 = load i32, ptr %l20, !tbaa !23
  %t157 = sub i32 %t153, %t154
  %t158 = load i32, ptr %l22, !tbaa !23
  %t161 = add i32 %t157, %t158
  %t163 = sub i32 %t161, 1
  %t164 = load i32, ptr %l22, !tbaa !23
  %t167 = sdiv i32 %t163, %t164
  store i32 %t167, ptr %l110, !tbaa !23
  br label %bb22
bb21:
  store i32 0, ptr %l110, !tbaa !23
  br label %bb22
bb22:
  %t169 = load i32, ptr %l110, !tbaa !23
  store i32 %t169, ptr %l107, !tbaa !23
  br label %bb23
bb23:
  %t170 = load i32, ptr %l107, !tbaa !23
  store i32 %t170, ptr %l23, !tbaa !23
  store i32 0, ptr %l24, !tbaa !23
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load i32, ptr %l24, !tbaa !23
  %t172 = load i32, ptr %l23, !tbaa !23
  %t175 = icmp slt i32 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t179 = load i32, ptr %l20, !tbaa !23
  %t180 = load i32, ptr %l24, !tbaa !23
  %t181 = load i32, ptr %l22, !tbaa !23
  %t184 = mul i32 %t180, %t181
  %t187 = add i32 %t179, %t184
  store i32 %t187, ptr %l25, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/mir:Fn", ptr %t192, i32 0, i32 18
  %t195 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t196 = getelementptr %"compiler/mir:Range", ptr %t195, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t200 = load i32, ptr %l25, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t205 = add i64 %t199, %t202
  %t208 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t194, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l136
  br label %bb28
bb28:
  %t209 = load %"compiler/typed:Item", ptr %l136
  store %"compiler/typed:Item" %t209, ptr %l26
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t211 = load i32, ptr %l10, !tbaa !23
  %t212 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 0
  %t213 = load i32, ptr %t212, !tbaa !23
  %t217 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t210, i32 %t211, i32 %t213)
  store i64 %t217, ptr %l140
  br label %bb29
bb29:
  %t218 = load i64, ptr %l140, !tbaa !24
  store i64 %t218, ptr %l27, !tbaa !24
  %t219 = load i32, ptr %l17, !tbaa !23
  %t220 = load i32, ptr %l25, !tbaa !23
  %t221 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t224 = sext i32 %t219 to i64
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t231 = sext i32 %t220 to i64
  %t232 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t233 = add i64 %t229, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t221, i64 %t222)
  %t235 = getelementptr i8, ptr %t234, i64 %t222
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t224)
  %t237 = getelementptr i8, ptr %t235, i64 %t225
  call void @olang_textcopy(ptr %t237, ptr %t227, i64 %t228)
  %t238 = getelementptr i8, ptr %t237, i64 %t228
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t231)
  %t240 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t234, 1
  store { i64, ptr } %t241, ptr %l28, !tbaa !27
  %t243 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = icmp slt i64 %t244, 0
  br i1 %t246, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t253 = load i64, ptr %l27, !tbaa !24
  %t254 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t257 = extractvalue { i64, ptr } %t249, 1
  %t258 = extractvalue { i64, ptr } %t249, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t250, 1
  %t265 = extractvalue { i64, ptr } %t250, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t251, 1
  %t272 = extractvalue { i64, ptr } %t251, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = extractvalue { i64, ptr } %t252, 1
  %t279 = extractvalue { i64, ptr } %t252, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t285 = call i64 @__olang_fmt_i64(ptr null, i64 %t253)
  %t286 = add i64 %t283, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t254, i64 %t255)
  %t291 = getelementptr i8, ptr %t290, i64 %t255
  call void @olang_textcopy(ptr %t291, ptr %t257, i64 %t258)
  %t292 = getelementptr i8, ptr %t291, i64 %t258
  call void @olang_textcopy(ptr %t292, ptr %t260, i64 %t261)
  %t293 = getelementptr i8, ptr %t292, i64 %t261
  call void @olang_textcopy(ptr %t293, ptr %t264, i64 %t265)
  %t294 = getelementptr i8, ptr %t293, i64 %t265
  call void @olang_textcopy(ptr %t294, ptr %t267, i64 %t268)
  %t295 = getelementptr i8, ptr %t294, i64 %t268
  call void @olang_textcopy(ptr %t295, ptr %t271, i64 %t272)
  %t296 = getelementptr i8, ptr %t295, i64 %t272
  call void @olang_textcopy(ptr %t296, ptr %t274, i64 %t275)
  %t297 = getelementptr i8, ptr %t296, i64 %t275
  call void @olang_textcopy(ptr %t297, ptr %t278, i64 %t279)
  %t298 = getelementptr i8, ptr %t297, i64 %t279
  call void @olang_textcopy(ptr %t298, ptr %t281, i64 %t282)
  %t299 = getelementptr i8, ptr %t298, i64 %t282
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t253)
  %t301 = getelementptr i8, ptr %t299, i64 %t285
  call void @olang_textcopy(ptr %t301, ptr %t287, i64 %t288)
  %t302 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t290, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } %t303, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t248, { i64, ptr } %t310)
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t316 = load i64, ptr %l27, !tbaa !24
  %t318 = shl i64 %t316, 16
  %t319 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = or i64 %t318, %t320
  %t324 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t327 = extractvalue { i64, ptr } %t314, 1
  %t328 = extractvalue { i64, ptr } %t314, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t334 = extractvalue { i64, ptr } %t315, 1
  %t335 = extractvalue { i64, ptr } %t315, 0
  %t336 = add i64 %t332, %t335
  %t337 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t339 = add i64 %t336, %t338
  %t341 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t342 = add i64 %t339, %t341
  %t343 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t345 = add i64 %t342, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t324, i64 %t325)
  %t347 = getelementptr i8, ptr %t346, i64 %t325
  call void @olang_textcopy(ptr %t347, ptr %t327, i64 %t328)
  %t348 = getelementptr i8, ptr %t347, i64 %t328
  call void @olang_textcopy(ptr %t348, ptr %t330, i64 %t331)
  %t349 = getelementptr i8, ptr %t348, i64 %t331
  call void @olang_textcopy(ptr %t349, ptr %t334, i64 %t335)
  %t350 = getelementptr i8, ptr %t349, i64 %t335
  call void @olang_textcopy(ptr %t350, ptr %t337, i64 %t338)
  %t351 = getelementptr i8, ptr %t350, i64 %t338
  %t352 = call i64 @__olang_fmt_i64(ptr %t351, i64 %t323)
  %t353 = getelementptr i8, ptr %t351, i64 %t341
  call void @olang_textcopy(ptr %t353, ptr %t343, i64 %t344)
  %t354 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t346, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t313, { i64, ptr } %t362)
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t369 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t372 = extractvalue { i64, ptr } %t366, 1
  %t373 = extractvalue { i64, ptr } %t366, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t367, 1
  %t380 = extractvalue { i64, ptr } %t367, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t386 = extractvalue { i64, ptr } %t368, 1
  %t387 = extractvalue { i64, ptr } %t368, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t369, i64 %t370)
  %t393 = getelementptr i8, ptr %t392, i64 %t370
  call void @olang_textcopy(ptr %t393, ptr %t372, i64 %t373)
  %t394 = getelementptr i8, ptr %t393, i64 %t373
  call void @olang_textcopy(ptr %t394, ptr %t375, i64 %t376)
  %t395 = getelementptr i8, ptr %t394, i64 %t376
  call void @olang_textcopy(ptr %t395, ptr %t379, i64 %t380)
  %t396 = getelementptr i8, ptr %t395, i64 %t380
  call void @olang_textcopy(ptr %t396, ptr %t382, i64 %t383)
  %t397 = getelementptr i8, ptr %t396, i64 %t383
  call void @olang_textcopy(ptr %t397, ptr %t386, i64 %t387)
  %t398 = getelementptr i8, ptr %t397, i64 %t387
  call void @olang_textcopy(ptr %t398, ptr %t389, i64 %t390)
  %t399 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t392, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t365, { i64, ptr } %t407)
  br label %bb35
bb35:
  %t410 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 1
  %t413 = extractvalue { i64, ptr } %t410, 0
  %t414 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t412, i64 %t413)
  %t418 = getelementptr i8, ptr %t417, i64 %t413
  call void @olang_textcopy(ptr %t418, ptr %t414, i64 %t415)
  %t419 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t417, 1
  store { i64, ptr } %t420, ptr %l170, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  %t423 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l172, !tbaa !24
  %t426 = load i64, ptr %l172, !tbaa !24
  %t427 = icmp eq i64 %t422, %t426
  br i1 %t427, label %bb36, label %bb37
bb36:
  %t429 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = load i64, ptr %l172, !tbaa !24
  %t434 = mul i64 %t433, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t430, ptr %t432, i64 %t434, i1 false)
  br label %bb38
bb37:
  %t435 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t435, ptr %l19, !tbaa !27
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t436 = load i32, ptr %l24, !tbaa !23
  %t438 = add i32 %t436, 1
  store i32 %t438, ptr %l24, !tbaa !23
  br label %bb24
bb40:
  br label %bb41
bb41:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t442 = load i32, ptr %l17, !tbaa !23
  %t443 = load i32, ptr %l17, !tbaa !23
  %t444 = load i32, ptr %l17, !tbaa !23
  %t445 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t448 = extractvalue { i64, ptr } %t441, 1
  %t449 = extractvalue { i64, ptr } %t441, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t455 = sext i32 %t442 to i64
  %t456 = call i64 @__olang_fmt_i64(ptr null, i64 %t455)
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t462 = sext i32 %t443 to i64
  %t463 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t469 = sext i32 %t444 to i64
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t469)
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t445, i64 %t446)
  %t476 = getelementptr i8, ptr %t475, i64 %t446
  call void @olang_textcopy(ptr %t476, ptr %t448, i64 %t449)
  %t477 = getelementptr i8, ptr %t476, i64 %t449
  call void @olang_textcopy(ptr %t477, ptr %t451, i64 %t452)
  %t478 = getelementptr i8, ptr %t477, i64 %t452
  %t479 = call i64 @__olang_fmt_i64(ptr %t478, i64 %t455)
  %t480 = getelementptr i8, ptr %t478, i64 %t456
  call void @olang_textcopy(ptr %t480, ptr %t458, i64 %t459)
  %t481 = getelementptr i8, ptr %t480, i64 %t459
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t462)
  %t483 = getelementptr i8, ptr %t481, i64 %t463
  call void @olang_textcopy(ptr %t483, ptr %t465, i64 %t466)
  %t484 = getelementptr i8, ptr %t483, i64 %t466
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t469)
  %t486 = getelementptr i8, ptr %t484, i64 %t470
  call void @olang_textcopy(ptr %t486, ptr %t472, i64 %t473)
  %t487 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t475, 1
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t440, { i64, ptr } %t495)
  br label %bb42
bb42:
  %t498 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t499 = load { i64, [4 x i64] }, ptr %t498
  %t501 = extractvalue { i64, [4 x i64] } %t499, 0
  %t502 = icmp eq i64 %t501, 0
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t508 = load { i64, [4 x i64] }, ptr %t507
  %t511 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t506, { i64, [4 x i64] } %t508)
  store i32 %t511, ptr %l188
  br label %bb45
bb44:
  br label %bb134
bb45:
  %t512 = load i32, ptr %l188, !tbaa !23
  store i32 %t512, ptr %l29, !tbaa !23
  %t513 = load ptr, ptr %l8, !tbaa !29
  %t514 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t513, i32 %t514)
  br label %bb46
bb46:
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t518 = load i32, ptr %l17, !tbaa !23
  %t519 = load i64, ptr %l11, !tbaa !24
  %t520 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t521 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t523 = sext i32 %t518 to i64
  %t524 = call i64 @__olang_fmt_i64(ptr null, i64 %t523)
  %t525 = add i64 %t521, %t524
  %t526 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t527 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t528 = add i64 %t525, %t527
  %t530 = call i64 @__olang_fmt_i64(ptr null, i64 %t519)
  %t531 = add i64 %t528, %t530
  %t532 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t534 = add i64 %t531, %t533
  %t535 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t520, i64 %t521)
  %t536 = getelementptr i8, ptr %t535, i64 %t521
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t523)
  %t538 = getelementptr i8, ptr %t536, i64 %t524
  call void @olang_textcopy(ptr %t538, ptr %t526, i64 %t527)
  %t539 = getelementptr i8, ptr %t538, i64 %t527
  %t540 = call i64 @__olang_fmt_i64(ptr %t539, i64 %t519)
  %t541 = getelementptr i8, ptr %t539, i64 %t530
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t535, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t546 = extractvalue { i64, ptr } %t543, 1
  %t547 = mul i64 %t545, 1
  %t548 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t517, { i64, ptr } %t550)
  br label %bb47
bb47:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t554 = load i32, ptr %l17, !tbaa !23
  %t555 = load i32, ptr %l17, !tbaa !23
  %t556 = load i32, ptr %l17, !tbaa !23
  %t557 = load i32, ptr %l17, !tbaa !23
  %t558 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t561 = sext i32 %t554 to i64
  %t562 = call i64 @__olang_fmt_i64(ptr null, i64 %t561)
  %t563 = add i64 %t559, %t562
  %t564 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t566 = add i64 %t563, %t565
  %t568 = sext i32 %t555 to i64
  %t569 = call i64 @__olang_fmt_i64(ptr null, i64 %t568)
  %t570 = add i64 %t566, %t569
  %t571 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t572 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t573 = add i64 %t570, %t572
  %t575 = sext i32 %t556 to i64
  %t576 = call i64 @__olang_fmt_i64(ptr null, i64 %t575)
  %t577 = add i64 %t573, %t576
  %t578 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t580 = add i64 %t577, %t579
  %t582 = sext i32 %t557 to i64
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t584 = add i64 %t580, %t583
  %t585 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t587 = add i64 %t584, %t586
  %t588 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t558, i64 %t559)
  %t589 = getelementptr i8, ptr %t588, i64 %t559
  %t590 = call i64 @__olang_fmt_i64(ptr %t589, i64 %t561)
  %t591 = getelementptr i8, ptr %t589, i64 %t562
  call void @olang_textcopy(ptr %t591, ptr %t564, i64 %t565)
  %t592 = getelementptr i8, ptr %t591, i64 %t565
  %t593 = call i64 @__olang_fmt_i64(ptr %t592, i64 %t568)
  %t594 = getelementptr i8, ptr %t592, i64 %t569
  call void @olang_textcopy(ptr %t594, ptr %t571, i64 %t572)
  %t595 = getelementptr i8, ptr %t594, i64 %t572
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t575)
  %t597 = getelementptr i8, ptr %t595, i64 %t576
  call void @olang_textcopy(ptr %t597, ptr %t578, i64 %t579)
  %t598 = getelementptr i8, ptr %t597, i64 %t579
  %t599 = call i64 @__olang_fmt_i64(ptr %t598, i64 %t582)
  %t600 = getelementptr i8, ptr %t598, i64 %t583
  call void @olang_textcopy(ptr %t600, ptr %t585, i64 %t586)
  %t601 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t588, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = extractvalue { i64, ptr } %t602, 1
  %t606 = mul i64 %t604, 1
  %t607 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t606)
  call void @llvm.memcpy.p0.p0.i64(ptr %t607, ptr %t605, i64 %t606, i1 false)
  %t608 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t553, { i64, ptr } %t609)
  br label %bb48
bb48:
  %t612 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s15)
  store %"std/prelude/text:StringBuilder" %t612, ptr %l203
  br label %bb49
bb49:
  %t613 = load %"std/prelude/text:StringBuilder", ptr %l203
  store %"std/prelude/text:StringBuilder" %t613, ptr %l30
  %t614 = load i32, ptr %l17, !tbaa !23
  %t615 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t618 = sext i32 %t614 to i64
  %t619 = call i64 @__olang_fmt_i64(ptr null, i64 %t618)
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  %t623 = call i64 @__olang_fmt_i64(ptr %t622, i64 %t618)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t621, 1
  %t627 = extractvalue { i64, ptr } %t625, 0
  %t628 = extractvalue { i64, ptr } %t625, 1
  %t629 = mul i64 %t627, 1
  %t630 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t630, ptr %t628, i64 %t629, i1 false)
  %t631 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t630, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s15, ptr %l30, { i64, ptr } %t632)
  br label %bb50
bb50:
  %t635 = load ptr, ptr %l9, !tbaa !29
  %t636 = load i32, ptr %l29, !tbaa !23
  %t639 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t635, i32 %t636)
  store i32 %t639, ptr %l210
  br label %bb51
bb51:
  %t640 = load i32, ptr %l210, !tbaa !23
  store i32 %t640, ptr %l31, !tbaa !23
  %t641 = load i32, ptr %l31, !tbaa !23
  %t642 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t645 = icmp ne i32 %t641, %t642
  br i1 %t645, label %bb52, label %bb53
bb52:
  %t647 = load i32, ptr %l31, !tbaa !23
  %t648 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t651 = icmp ne i32 %t647, %t648
  store i1 %t651, ptr %l214, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb54
bb54:
  %t653 = load i1, ptr %l214, !tbaa !21
  br i1 %t653, label %bb55, label %bb56
bb55:
  %t654 = load ptr, ptr %l9, !tbaa !29
  %t655 = load i32, ptr %l31, !tbaa !23
  %t658 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t654, i32 %t655)
  store i1 %t658, ptr %l221
  br label %bb57
bb56:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb58
bb57:
  %t659 = load i1, ptr %l221, !tbaa !21
  store i1 %t659, ptr %l218, !tbaa !21
  br label %bb58
bb58:
  %t660 = load i1, ptr %l218, !tbaa !21
  store i1 %t660, ptr %l32, !tbaa !21
  %t661 = load i1, ptr %l32, !tbaa !21
  br i1 %t661, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s19
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l223, !tbaa !29
  %t664 = load i32, ptr %l17, !tbaa !23
  store i32 %t664, ptr %l224, !tbaa !23
  %t665 = load ptr, ptr %l8, !tbaa !29
  %t666 = load i32, ptr %l31, !tbaa !23
  %t669 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s19, ptr %t665, i32 %t666)
  store { i64, ptr } %t669, ptr %l227
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t670 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t672 = load i32, ptr %l224, !tbaa !23
  %t673 = sext i32 %t672 to i64
  %t674 = call i64 @__olang_fmt_i64(ptr null, i64 %t673)
  %t675 = add i64 %t671, %t674
  %t676 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t677 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t678 = add i64 %t675, %t677
  %t679 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = add i64 %t678, %t681
  %t683 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t684 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t685 = add i64 %t682, %t684
  %t686 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t685)
  call void @olang_textcopy(ptr %t686, ptr %t670, i64 %t671)
  %t687 = getelementptr i8, ptr %t686, i64 %t671
  %t688 = call i64 @__olang_fmt_i64(ptr %t687, i64 %t673)
  %t689 = getelementptr i8, ptr %t687, i64 %t674
  call void @olang_textcopy(ptr %t689, ptr %t676, i64 %t677)
  %t690 = getelementptr i8, ptr %t689, i64 %t677
  call void @olang_textcopy(ptr %t690, ptr %t680, i64 %t681)
  %t691 = getelementptr i8, ptr %t690, i64 %t681
  call void @olang_textcopy(ptr %t691, ptr %t683, i64 %t684)
  %t692 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t686, 1
  %t695 = extractvalue { i64, ptr } %t693, 0
  %t696 = extractvalue { i64, ptr } %t693, 1
  %t697 = mul i64 %t695, 1
  %t698 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t697)
  call void @llvm.memcpy.p0.p0.i64(ptr %t698, ptr %t696, i64 %t697, i1 false)
  %t699 = insertvalue { i64, ptr } undef, i64 %t695, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t698, 1
  %t701 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t701, { i64, ptr } %t700)
  br label %bb62
bb62:
  %t703 = load i32, ptr %l17, !tbaa !23
  %t704 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t705 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t707 = sext i32 %t703 to i64
  %t708 = call i64 @__olang_fmt_i64(ptr null, i64 %t707)
  %t709 = add i64 %t705, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t704, i64 %t705)
  %t711 = getelementptr i8, ptr %t710, i64 %t705
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t707)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t710, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = extractvalue { i64, ptr } %t714, 1
  %t718 = mul i64 %t716, 1
  %t719 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t719, ptr %t717, i64 %t718, i1 false)
  %t720 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t719, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s19, ptr %l30, { i64, ptr } %t721)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s19)
  br label %bb64
bb64:
  store i64 0, ptr %l33, !tbaa !24
  %t724 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t725
  %t726 = getelementptr { i64, [4 x i64] }, ptr %t725, i32 0, i32 0
  store i64 0, ptr %t726
  %t727 = load { i64, [4 x i64] }, ptr %t725
  store { i64, [7 x i64] } zeroinitializer, ptr %t728
  %t729 = getelementptr { i64, [7 x i64] }, ptr %t728, i32 0, i32 0
  store i64 2, ptr %t729
  %t731 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t727, 0
  %t732 = getelementptr { i64, [7 x i64] }, ptr %t728, i32 0, i32 1
  store { { i64, [4 x i64] } } %t731, ptr %t732
  %t733 = load { i64, [7 x i64] }, ptr %t728
  %t734 = load i32, ptr %l29, !tbaa !23
  %t738 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t724, { i64, [7 x i64] } %t733, i32 %t734)
  store i64 %t738, ptr %l238
  br label %bb65
bb65:
  %t739 = load i64, ptr %l238, !tbaa !24
  store i64 %t739, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t740 = load i64, ptr %l34, !tbaa !24
  %t741 = load i64, ptr %l33, !tbaa !24
  %t744 = icmp sgt i64 %t740, %t741
  br i1 %t744, label %bb66, label %bb67
bb66:
  %t746 = load i64, ptr %l35, !tbaa !24
  %t748 = icmp sgt i64 %t746, 0
  br i1 %t748, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb71
bb68:
  %t750 = load i64, ptr %l34, !tbaa !24
  %t751 = load i64, ptr %l33, !tbaa !24
  %t754 = sub i64 %t750, %t751
  %t755 = load i64, ptr %l35, !tbaa !24
  %t758 = add i64 %t754, %t755
  %t760 = sub i64 %t758, 1
  %t761 = load i64, ptr %l35, !tbaa !24
  %t764 = sdiv i64 %t760, %t761
  store i64 %t764, ptr %l245, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb70
bb70:
  %t766 = load i64, ptr %l245, !tbaa !24
  store i64 %t766, ptr %l242, !tbaa !24
  br label %bb71
bb71:
  %t767 = load i64, ptr %l242, !tbaa !24
  store i64 %t767, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t768 = load i64, ptr %l37, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s23)
  br label %bb80
bb74:
  br label %bb75
bb75:
  %t776 = load i64, ptr %l33, !tbaa !24
  %t777 = load i64, ptr %l37, !tbaa !24
  %t778 = load i64, ptr %l35, !tbaa !24
  %t781 = mul i64 %t777, %t778
  %t784 = add i64 %t776, %t781
  store i64 %t784, ptr %l38, !tbaa !24
  %t786 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s23, ptr %s23, ptr %t786, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d206, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb76
bb76:
  %t788 = load ptr, ptr %l1, !tbaa !29
  %t789 = load i32, ptr %l17, !tbaa !23
  %t790 = load i64, ptr %l38, !tbaa !24
  %t791 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t792 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t794 = sext i32 %t789 to i64
  %t795 = call i64 @__olang_fmt_i64(ptr null, i64 %t794)
  %t796 = add i64 %t792, %t795
  %t797 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t798 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t799 = add i64 %t796, %t798
  %t801 = call i64 @__olang_fmt_i64(ptr null, i64 %t790)
  %t802 = add i64 %t799, %t801
  %t803 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t804 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t805 = add i64 %t802, %t804
  %t806 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t791, i64 %t792)
  %t807 = getelementptr i8, ptr %t806, i64 %t792
  %t808 = call i64 @__olang_fmt_i64(ptr %t807, i64 %t794)
  %t809 = getelementptr i8, ptr %t807, i64 %t795
  call void @olang_textcopy(ptr %t809, ptr %t797, i64 %t798)
  %t810 = getelementptr i8, ptr %t809, i64 %t798
  %t811 = call i64 @__olang_fmt_i64(ptr %t810, i64 %t790)
  %t812 = getelementptr i8, ptr %t810, i64 %t801
  call void @olang_textcopy(ptr %t812, ptr %t803, i64 %t804)
  %t813 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t806, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = extractvalue { i64, ptr } %t814, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t788, { i64, ptr } %t821)
  br label %bb77
bb77:
  %t824 = load i32, ptr %l17, !tbaa !23
  %t825 = load i64, ptr %l38, !tbaa !24
  %t826 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t829 = sext i32 %t824 to i64
  %t830 = call i64 @__olang_fmt_i64(ptr null, i64 %t829)
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t834 = add i64 %t831, %t833
  %t836 = call i64 @__olang_fmt_i64(ptr null, i64 %t825)
  %t837 = add i64 %t834, %t836
  %t838 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t837)
  call void @olang_textcopy(ptr %t838, ptr %t826, i64 %t827)
  %t839 = getelementptr i8, ptr %t838, i64 %t827
  %t840 = call i64 @__olang_fmt_i64(ptr %t839, i64 %t829)
  %t841 = getelementptr i8, ptr %t839, i64 %t830
  call void @olang_textcopy(ptr %t841, ptr %t832, i64 %t833)
  %t842 = getelementptr i8, ptr %t841, i64 %t833
  %t843 = call i64 @__olang_fmt_i64(ptr %t842, i64 %t825)
  %t844 = insertvalue { i64, ptr } undef, i64 %t837, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t838, 1
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t848 = extractvalue { i64, ptr } %t845, 1
  %t849 = mul i64 %t847, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t849)
  call void @llvm.memcpy.p0.p0.i64(ptr %t850, ptr %t848, i64 %t849, i1 false)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s23, ptr %l30, { i64, ptr } %t852)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s23)
  br label %bb79
bb79:
  %t855 = load i64, ptr %l37, !tbaa !24
  %t857 = add i64 %t855, 1
  store i64 %t857, ptr %l37, !tbaa !24
  br label %bb72
bb80:
  %t859 = load ptr, ptr %l9, !tbaa !29
  %t860 = load i32, ptr %l29, !tbaa !23
  %t863 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s15, ptr %t859, i32 %t860)
  store { i64, ptr } %t863, ptr %l278
  br label %bb81
bb81:
  %t864 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t864, ptr %l39, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d213, i32 0, i32 1) }, ptr %l279, !tbaa !27
  %t865 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t865, ptr %l280, !tbaa !27
  %t866 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l281, !tbaa !24
  %t868 = load i64, ptr %l281, !tbaa !24
  %t869 = mul i64 %t868, 1
  %t870 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t869)
  %t871 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  store { i64, ptr } %t872, ptr %l282, !tbaa !27
  %t873 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = load i64, ptr %l281, !tbaa !24
  %t878 = mul i64 %t877, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t874, ptr %t876, i64 %t878, i1 false)
  %t879 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t879, ptr %l40, !tbaa !27
  %t880 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t882 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t880, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d214, i32 0, i32 1) })
  store i1 %t882, ptr %l284
  br label %bb82
bb82:
  %t883 = load i1, ptr %l284, !tbaa !21
  br i1 %t883, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s27
  %t884 = load ptr, ptr %l1, !tbaa !29
  store ptr %t884, ptr %l285, !tbaa !29
  %t885 = load i32, ptr %l17, !tbaa !23
  store i32 %t885, ptr %l286, !tbaa !23
  %t887 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s27, ptr %l30)
  store { i64, ptr } %t887, ptr %l288
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s29
  %t888 = load ptr, ptr %l1, !tbaa !29
  store ptr %t888, ptr %l291, !tbaa !29
  %t889 = load i32, ptr %l17, !tbaa !23
  store i32 %t889, ptr %l292, !tbaa !23
  %t890 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t890, ptr %l293, !tbaa !27
  %t891 = load i32, ptr %l17, !tbaa !23
  store i32 %t891, ptr %l294, !tbaa !23
  %t893 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s29, ptr %l30)
  store { i64, ptr } %t893, ptr %l296
  br label %bb87
bb85:
  %t894 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t895 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t896 = load i32, ptr %l286, !tbaa !23
  %t897 = sext i32 %t896 to i64
  %t898 = call i64 @__olang_fmt_i64(ptr null, i64 %t897)
  %t899 = add i64 %t895, %t898
  %t900 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t901 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t902 = add i64 %t899, %t901
  %t903 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t909 = add i64 %t906, %t908
  %t910 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t909)
  call void @olang_textcopy(ptr %t910, ptr %t894, i64 %t895)
  %t911 = getelementptr i8, ptr %t910, i64 %t895
  %t912 = call i64 @__olang_fmt_i64(ptr %t911, i64 %t897)
  %t913 = getelementptr i8, ptr %t911, i64 %t898
  call void @olang_textcopy(ptr %t913, ptr %t900, i64 %t901)
  %t914 = getelementptr i8, ptr %t913, i64 %t901
  call void @olang_textcopy(ptr %t914, ptr %t904, i64 %t905)
  %t915 = getelementptr i8, ptr %t914, i64 %t905
  call void @olang_textcopy(ptr %t915, ptr %t907, i64 %t908)
  %t916 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t917 = insertvalue { i64, ptr } %t916, ptr %t910, 1
  %t919 = extractvalue { i64, ptr } %t917, 0
  %t920 = extractvalue { i64, ptr } %t917, 1
  %t921 = mul i64 %t919, 1
  %t922 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t921)
  call void @llvm.memcpy.p0.p0.i64(ptr %t922, ptr %t920, i64 %t921, i1 false)
  %t923 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t922, 1
  %t925 = load ptr, ptr %l285, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t925, { i64, ptr } %t924)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb92
bb87:
  %t927 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t928 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t929 = load i32, ptr %l292, !tbaa !23
  %t930 = sext i32 %t929 to i64
  %t931 = call i64 @__olang_fmt_i64(ptr null, i64 %t930)
  %t932 = add i64 %t928, %t931
  %t933 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t934 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t935 = add i64 %t932, %t934
  %t936 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 1
  %t938 = extractvalue { i64, ptr } %t936, 0
  %t939 = add i64 %t935, %t938
  %t940 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t941 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t942 = add i64 %t939, %t941
  %t943 = load i32, ptr %l294, !tbaa !23
  %t944 = sext i32 %t943 to i64
  %t945 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t946 = add i64 %t942, %t945
  %t947 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t949 = add i64 %t946, %t948
  %t950 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t951 = extractvalue { i64, ptr } %t950, 1
  %t952 = extractvalue { i64, ptr } %t950, 0
  %t953 = add i64 %t949, %t952
  %t954 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t955 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t956 = add i64 %t953, %t955
  %t957 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t956)
  call void @olang_textcopy(ptr %t957, ptr %t927, i64 %t928)
  %t958 = getelementptr i8, ptr %t957, i64 %t928
  %t959 = call i64 @__olang_fmt_i64(ptr %t958, i64 %t930)
  %t960 = getelementptr i8, ptr %t958, i64 %t931
  call void @olang_textcopy(ptr %t960, ptr %t933, i64 %t934)
  %t961 = getelementptr i8, ptr %t960, i64 %t934
  call void @olang_textcopy(ptr %t961, ptr %t937, i64 %t938)
  %t962 = getelementptr i8, ptr %t961, i64 %t938
  call void @olang_textcopy(ptr %t962, ptr %t940, i64 %t941)
  %t963 = getelementptr i8, ptr %t962, i64 %t941
  %t964 = call i64 @__olang_fmt_i64(ptr %t963, i64 %t944)
  %t965 = getelementptr i8, ptr %t963, i64 %t945
  call void @olang_textcopy(ptr %t965, ptr %t947, i64 %t948)
  %t966 = getelementptr i8, ptr %t965, i64 %t948
  call void @olang_textcopy(ptr %t966, ptr %t951, i64 %t952)
  %t967 = getelementptr i8, ptr %t966, i64 %t952
  call void @olang_textcopy(ptr %t967, ptr %t954, i64 %t955)
  %t968 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t957, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = extractvalue { i64, ptr } %t969, 1
  %t973 = mul i64 %t971, 1
  %t974 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t974, ptr %t972, i64 %t973, i1 false)
  %t975 = insertvalue { i64, ptr } undef, i64 %t971, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t974, 1
  %t977 = load ptr, ptr %l291, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s29, ptr %t977, { i64, ptr } %t976)
  br label %bb88
bb88:
  %t979 = load i32, ptr %l17, !tbaa !23
  %t980 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t981 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t983 = sext i32 %t979 to i64
  %t984 = call i64 @__olang_fmt_i64(ptr null, i64 %t983)
  %t985 = add i64 %t981, %t984
  %t986 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t985)
  call void @olang_textcopy(ptr %t986, ptr %t980, i64 %t981)
  %t987 = getelementptr i8, ptr %t986, i64 %t981
  %t988 = call i64 @__olang_fmt_i64(ptr %t987, i64 %t983)
  %t989 = insertvalue { i64, ptr } undef, i64 %t985, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t986, 1
  store { i64, ptr } %t990, ptr %l300, !tbaa !27
  %t991 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t992 = extractvalue { i64, ptr } %t991, 0
  %t993 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t993, 0
  store i64 %t994, ptr %l302, !tbaa !24
  %t996 = load i64, ptr %l302, !tbaa !24
  %t997 = icmp eq i64 %t992, %t996
  br i1 %t997, label %bb89, label %bb90
bb89:
  %t999 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t1000 = load ptr, ptr %t999, !tbaa !27
  %t1001 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = load i64, ptr %l302, !tbaa !24
  %t1004 = mul i64 %t1003, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1000, ptr %t1002, i64 %t1004, i1 false)
  br label %bb91
bb90:
  %t1005 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t1005, ptr %l40, !tbaa !27
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s29)
  br label %bb92
bb92:
  %t1006 = load i1, ptr %l32, !tbaa !21
  br i1 %t1006, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s32
  %t1008 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1008, ptr %l305, !tbaa !29
  %t1009 = load i32, ptr %l17, !tbaa !23
  store i32 %t1009, ptr %l306, !tbaa !23
  %t1010 = load ptr, ptr %l8, !tbaa !29
  %t1011 = load i32, ptr %l31, !tbaa !23
  %t1014 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t1010, i32 %t1011)
  store { i64, ptr } %t1014, ptr %l309
  br label %bb95
bb94:
  br label %bb100
bb95:
  %t1015 = load i32, ptr %l17, !tbaa !23
  %t1016 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t1017 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t1018 = load i32, ptr %l306, !tbaa !23
  %t1019 = sext i32 %t1018 to i64
  %t1020 = call i64 @__olang_fmt_i64(ptr null, i64 %t1019)
  %t1021 = add i64 %t1017, %t1020
  %t1022 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t1023 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t1024 = add i64 %t1021, %t1023
  %t1025 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t1026 = extractvalue { i64, ptr } %t1025, 1
  %t1027 = extractvalue { i64, ptr } %t1025, 0
  %t1028 = add i64 %t1024, %t1027
  %t1029 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t1030 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t1031 = add i64 %t1028, %t1030
  %t1033 = sext i32 %t1015 to i64
  %t1034 = call i64 @__olang_fmt_i64(ptr null, i64 %t1033)
  %t1035 = add i64 %t1031, %t1034
  %t1036 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t1037 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t1038 = add i64 %t1035, %t1037
  %t1039 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1038)
  call void @olang_textcopy(ptr %t1039, ptr %t1016, i64 %t1017)
  %t1040 = getelementptr i8, ptr %t1039, i64 %t1017
  %t1041 = call i64 @__olang_fmt_i64(ptr %t1040, i64 %t1019)
  %t1042 = getelementptr i8, ptr %t1040, i64 %t1020
  call void @olang_textcopy(ptr %t1042, ptr %t1022, i64 %t1023)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1023
  call void @olang_textcopy(ptr %t1043, ptr %t1026, i64 %t1027)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1027
  call void @olang_textcopy(ptr %t1044, ptr %t1029, i64 %t1030)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1030
  %t1046 = call i64 @__olang_fmt_i64(ptr %t1045, i64 %t1033)
  %t1047 = getelementptr i8, ptr %t1045, i64 %t1034
  call void @olang_textcopy(ptr %t1047, ptr %t1036, i64 %t1037)
  %t1048 = insertvalue { i64, ptr } undef, i64 %t1038, 0
  %t1049 = insertvalue { i64, ptr } %t1048, ptr %t1039, 1
  %t1051 = extractvalue { i64, ptr } %t1049, 0
  %t1052 = extractvalue { i64, ptr } %t1049, 1
  %t1053 = mul i64 %t1051, 1
  %t1054 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1053)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1054, ptr %t1052, i64 %t1053, i1 false)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1054, 1
  %t1057 = load ptr, ptr %l305, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t1057, { i64, ptr } %t1056)
  br label %bb96
bb96:
  %t1059 = load i32, ptr %l17, !tbaa !23
  %t1060 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t1061 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t1063 = sext i32 %t1059 to i64
  %t1064 = call i64 @__olang_fmt_i64(ptr null, i64 %t1063)
  %t1065 = add i64 %t1061, %t1064
  %t1066 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t1065)
  call void @olang_textcopy(ptr %t1066, ptr %t1060, i64 %t1061)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1061
  %t1068 = call i64 @__olang_fmt_i64(ptr %t1067, i64 %t1063)
  %t1069 = insertvalue { i64, ptr } undef, i64 %t1065, 0
  %t1070 = insertvalue { i64, ptr } %t1069, ptr %t1066, 1
  store { i64, ptr } %t1070, ptr %l314, !tbaa !27
  %t1071 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1072 = extractvalue { i64, ptr } %t1071, 0
  %t1073 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  store i64 %t1074, ptr %l316, !tbaa !24
  %t1076 = load i64, ptr %l316, !tbaa !24
  %t1077 = icmp eq i64 %t1072, %t1076
  br i1 %t1077, label %bb97, label %bb98
bb97:
  %t1079 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t1080 = load ptr, ptr %t1079, !tbaa !27
  %t1081 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t1082 = load ptr, ptr %t1081, !tbaa !27
  %t1083 = load i64, ptr %l316, !tbaa !24
  %t1084 = mul i64 %t1083, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1080, ptr %t1082, i64 %t1084, i1 false)
  br label %bb99
bb98:
  %t1085 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t1085, ptr %l40, !tbaa !27
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s32)
  br label %bb100
bb100:
  %t1086 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1088 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t1086, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store i1 %t1088, ptr %l319
  br label %bb101
bb101:
  %t1089 = load i1, ptr %l319, !tbaa !21
  %t1090 = xor i1 %t1089, true
  br i1 %t1090, label %bb102, label %bb103
bb102:
  %t1092 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1093 = getelementptr %"compiler/mir:Range", ptr %t1092, i32 0, i32 1
  %t1094 = load i32, ptr %t1093, !tbaa !23
  %t1096 = icmp sgt i32 %t1094, 0
  store i1 %t1096, ptr %l321, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb104
bb104:
  %t1098 = load i1, ptr %l321, !tbaa !21
  br i1 %t1098, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s35
  %t1099 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1100 = getelementptr %"compiler/mir:Range", ptr %t1099, i32 0, i32 1
  %t1101 = load i32, ptr %t1100, !tbaa !23
  %t1103 = icmp eq i32 %t1101, 1
  br i1 %t1103, label %bb107, label %bb108
bb106:
  br label %bb133
bb107:
  store %olang.scope zeroinitializer, ptr %s36
  %t1105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1105, ptr %l326, !tbaa !29
  %t1106 = load i32, ptr %l17, !tbaa !23
  store i32 %t1106, ptr %l327, !tbaa !23
  %t1107 = load i64, ptr %l6, !tbaa !24
  store i64 %t1107, ptr %l328, !tbaa !24
  %t1108 = load ptr, ptr %l8, !tbaa !29
  %t1109 = load i32, ptr %l31, !tbaa !23
  %t1112 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s36, ptr %t1108, i32 %t1109)
  store { i64, ptr } %t1112, ptr %l331
  br label %bb109
bb108:
  %t1113 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1113, ptr %l336, !tbaa !29
  %t1114 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1114, ptr %l337, !tbaa !29
  %t1115 = load ptr, ptr %l9, !tbaa !29
  %t1116 = load i32, ptr %l31, !tbaa !23
  %t1119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1115, i32 %t1116)
  store i32 %t1119, ptr %l340
  br label %bb111
bb109:
  %t1120 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1121 = load i32, ptr %l17, !tbaa !23
  %t1122 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t1123 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t1124 = load i32, ptr %l327, !tbaa !23
  %t1125 = sext i32 %t1124 to i64
  %t1126 = call i64 @__olang_fmt_i64(ptr null, i64 %t1125)
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t1129 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = load i64, ptr %l328, !tbaa !24
  %t1132 = call i64 @__olang_fmt_i64(ptr null, i64 %t1131)
  %t1133 = add i64 %t1130, %t1132
  %t1134 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t1135 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t1136 = add i64 %t1133, %t1135
  %t1137 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 1
  %t1139 = extractvalue { i64, ptr } %t1137, 0
  %t1140 = add i64 %t1136, %t1139
  %t1141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t1142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t1143 = add i64 %t1140, %t1142
  %t1145 = extractvalue { i64, ptr } %t1120, 1
  %t1146 = extractvalue { i64, ptr } %t1120, 0
  %t1147 = add i64 %t1143, %t1146
  %t1148 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t1149 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t1150 = add i64 %t1147, %t1149
  %t1152 = sext i32 %t1121 to i64
  %t1153 = call i64 @__olang_fmt_i64(ptr null, i64 %t1152)
  %t1154 = add i64 %t1150, %t1153
  %t1155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t1156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t1157 = add i64 %t1154, %t1156
  %t1158 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1157)
  call void @olang_textcopy(ptr %t1158, ptr %t1122, i64 %t1123)
  %t1159 = getelementptr i8, ptr %t1158, i64 %t1123
  %t1160 = call i64 @__olang_fmt_i64(ptr %t1159, i64 %t1125)
  %t1161 = getelementptr i8, ptr %t1159, i64 %t1126
  call void @olang_textcopy(ptr %t1161, ptr %t1128, i64 %t1129)
  %t1162 = getelementptr i8, ptr %t1161, i64 %t1129
  %t1163 = call i64 @__olang_fmt_i64(ptr %t1162, i64 %t1131)
  %t1164 = getelementptr i8, ptr %t1162, i64 %t1132
  call void @olang_textcopy(ptr %t1164, ptr %t1134, i64 %t1135)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1135
  call void @olang_textcopy(ptr %t1165, ptr %t1138, i64 %t1139)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1139
  call void @olang_textcopy(ptr %t1166, ptr %t1141, i64 %t1142)
  %t1167 = getelementptr i8, ptr %t1166, i64 %t1142
  call void @olang_textcopy(ptr %t1167, ptr %t1145, i64 %t1146)
  %t1168 = getelementptr i8, ptr %t1167, i64 %t1146
  call void @olang_textcopy(ptr %t1168, ptr %t1148, i64 %t1149)
  %t1169 = getelementptr i8, ptr %t1168, i64 %t1149
  %t1170 = call i64 @__olang_fmt_i64(ptr %t1169, i64 %t1152)
  %t1171 = getelementptr i8, ptr %t1169, i64 %t1153
  call void @olang_textcopy(ptr %t1171, ptr %t1155, i64 %t1156)
  %t1172 = insertvalue { i64, ptr } undef, i64 %t1157, 0
  %t1173 = insertvalue { i64, ptr } %t1172, ptr %t1158, 1
  %t1175 = extractvalue { i64, ptr } %t1173, 0
  %t1176 = extractvalue { i64, ptr } %t1173, 1
  %t1177 = mul i64 %t1175, 1
  %t1178 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1178, ptr %t1176, i64 %t1177, i1 false)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1175, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1178, 1
  %t1181 = load ptr, ptr %l326, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t1181, { i64, ptr } %t1180)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s36)
  br label %bb131
bb111:
  %t1183 = load ptr, ptr %l337, !tbaa !29
  %t1184 = load i32, ptr %l340, !tbaa !23
  %t1185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1183, i32 %t1184)
  store i32 %t1185, ptr %l341
  br label %bb112
bb112:
  %t1186 = load ptr, ptr %l336, !tbaa !29
  %t1187 = load i32, ptr %l341, !tbaa !23
  %t1188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1186, i32 %t1187)
  store { i64, ptr } %t1188, ptr %l342
  br label %bb113
bb113:
  %t1189 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t1189, ptr %l41, !tbaa !27
  store i32 0, ptr %l42, !tbaa !23
  %t1190 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1191 = getelementptr %"compiler/mir:Range", ptr %t1190, i32 0, i32 1
  %t1192 = load i32, ptr %t1191, !tbaa !23
  store i32 %t1192, ptr %l43, !tbaa !23
  store i32 1, ptr %l44, !tbaa !23
  %t1194 = load i32, ptr %l43, !tbaa !23
  %t1195 = load i32, ptr %l42, !tbaa !23
  %t1198 = icmp sgt i32 %t1194, %t1195
  br i1 %t1198, label %bb114, label %bb115
bb114:
  %t1200 = load i32, ptr %l44, !tbaa !23
  %t1202 = icmp sgt i32 %t1200, 0
  br i1 %t1202, label %bb116, label %bb117
bb115:
  store i32 0, ptr %l347, !tbaa !23
  br label %bb119
bb116:
  %t1204 = load i32, ptr %l43, !tbaa !23
  %t1205 = load i32, ptr %l42, !tbaa !23
  %t1208 = sub i32 %t1204, %t1205
  %t1209 = load i32, ptr %l44, !tbaa !23
  %t1212 = add i32 %t1208, %t1209
  %t1214 = sub i32 %t1212, 1
  %t1215 = load i32, ptr %l44, !tbaa !23
  %t1218 = sdiv i32 %t1214, %t1215
  store i32 %t1218, ptr %l350, !tbaa !23
  br label %bb118
bb117:
  store i32 0, ptr %l350, !tbaa !23
  br label %bb118
bb118:
  %t1220 = load i32, ptr %l350, !tbaa !23
  store i32 %t1220, ptr %l347, !tbaa !23
  br label %bb119
bb119:
  %t1221 = load i32, ptr %l347, !tbaa !23
  store i32 %t1221, ptr %l45, !tbaa !23
  store i32 0, ptr %l46, !tbaa !23
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s40
  %t1222 = load i32, ptr %l46, !tbaa !23
  %t1223 = load i32, ptr %l45, !tbaa !23
  %t1226 = icmp slt i32 %t1222, %t1223
  %t1228 = xor i1 %t1226, true
  br i1 %t1228, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s40)
  br label %bb130
bb122:
  br label %bb123
bb123:
  %t1230 = load i32, ptr %l42, !tbaa !23
  %t1231 = load i32, ptr %l46, !tbaa !23
  %t1232 = load i32, ptr %l44, !tbaa !23
  %t1235 = mul i32 %t1231, %t1232
  %t1238 = add i32 %t1230, %t1235
  store i32 %t1238, ptr %l47, !tbaa !23
  %t1240 = load ptr, ptr %l1, !tbaa !29
  %t1241 = load i32, ptr %l17, !tbaa !23
  %t1242 = load i32, ptr %l47, !tbaa !23
  %t1243 = load i64, ptr %l6, !tbaa !24
  %t1244 = load i32, ptr %l47, !tbaa !23
  %t1246 = sext i32 %t1244 to i64
  %t1249 = add i64 %t1243, %t1246
  %t1250 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t1251 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t1253 = sext i32 %t1241 to i64
  %t1254 = call i64 @__olang_fmt_i64(ptr null, i64 %t1253)
  %t1255 = add i64 %t1251, %t1254
  %t1256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t1257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t1258 = add i64 %t1255, %t1257
  %t1260 = sext i32 %t1242 to i64
  %t1261 = call i64 @__olang_fmt_i64(ptr null, i64 %t1260)
  %t1262 = add i64 %t1258, %t1261
  %t1263 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t1264 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t1265 = add i64 %t1262, %t1264
  %t1267 = call i64 @__olang_fmt_i64(ptr null, i64 %t1249)
  %t1268 = add i64 %t1265, %t1267
  %t1269 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t1270 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t1271 = add i64 %t1268, %t1270
  %t1272 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1271)
  call void @olang_textcopy(ptr %t1272, ptr %t1250, i64 %t1251)
  %t1273 = getelementptr i8, ptr %t1272, i64 %t1251
  %t1274 = call i64 @__olang_fmt_i64(ptr %t1273, i64 %t1253)
  %t1275 = getelementptr i8, ptr %t1273, i64 %t1254
  call void @olang_textcopy(ptr %t1275, ptr %t1256, i64 %t1257)
  %t1276 = getelementptr i8, ptr %t1275, i64 %t1257
  %t1277 = call i64 @__olang_fmt_i64(ptr %t1276, i64 %t1260)
  %t1278 = getelementptr i8, ptr %t1276, i64 %t1261
  call void @olang_textcopy(ptr %t1278, ptr %t1263, i64 %t1264)
  %t1279 = getelementptr i8, ptr %t1278, i64 %t1264
  %t1280 = call i64 @__olang_fmt_i64(ptr %t1279, i64 %t1249)
  %t1281 = getelementptr i8, ptr %t1279, i64 %t1267
  call void @olang_textcopy(ptr %t1281, ptr %t1269, i64 %t1270)
  %t1282 = insertvalue { i64, ptr } undef, i64 %t1271, 0
  %t1283 = insertvalue { i64, ptr } %t1282, ptr %t1272, 1
  %t1285 = extractvalue { i64, ptr } %t1283, 0
  %t1286 = extractvalue { i64, ptr } %t1283, 1
  %t1287 = mul i64 %t1285, 1
  %t1288 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1288, ptr %t1286, i64 %t1287, i1 false)
  %t1289 = insertvalue { i64, ptr } undef, i64 %t1285, 0
  %t1290 = insertvalue { i64, ptr } %t1289, ptr %t1288, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1240, { i64, ptr } %t1290)
  br label %bb124
bb124:
  %t1293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1293, ptr %l377, !tbaa !29
  %t1294 = load i32, ptr %l17, !tbaa !23
  store i32 %t1294, ptr %l378, !tbaa !23
  %t1295 = load i32, ptr %l47, !tbaa !23
  store i32 %t1295, ptr %l379, !tbaa !23
  %t1296 = load ptr, ptr %l8, !tbaa !29
  %t1297 = load i32, ptr %l31, !tbaa !23
  %t1300 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1296, i32 %t1297)
  store { i64, ptr } %t1300, ptr %l382
  br label %bb125
bb125:
  %t1301 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1302 = load i32, ptr %l47, !tbaa !23
  %t1303 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t1304 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t1305 = load i32, ptr %l378, !tbaa !23
  %t1306 = sext i32 %t1305 to i64
  %t1307 = call i64 @__olang_fmt_i64(ptr null, i64 %t1306)
  %t1308 = add i64 %t1304, %t1307
  %t1309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t1310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t1311 = add i64 %t1308, %t1310
  %t1312 = load i32, ptr %l379, !tbaa !23
  %t1313 = sext i32 %t1312 to i64
  %t1314 = call i64 @__olang_fmt_i64(ptr null, i64 %t1313)
  %t1315 = add i64 %t1311, %t1314
  %t1316 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t1317 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t1318 = add i64 %t1315, %t1317
  %t1319 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t1320 = extractvalue { i64, ptr } %t1319, 1
  %t1321 = extractvalue { i64, ptr } %t1319, 0
  %t1322 = add i64 %t1318, %t1321
  %t1323 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t1324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t1325 = add i64 %t1322, %t1324
  %t1327 = extractvalue { i64, ptr } %t1301, 1
  %t1328 = extractvalue { i64, ptr } %t1301, 0
  %t1329 = add i64 %t1325, %t1328
  %t1330 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t1331 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t1332 = add i64 %t1329, %t1331
  %t1334 = sext i32 %t1302 to i64
  %t1335 = call i64 @__olang_fmt_i64(ptr null, i64 %t1334)
  %t1336 = add i64 %t1332, %t1335
  %t1337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t1338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t1339 = add i64 %t1336, %t1338
  %t1340 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1339)
  call void @olang_textcopy(ptr %t1340, ptr %t1303, i64 %t1304)
  %t1341 = getelementptr i8, ptr %t1340, i64 %t1304
  %t1342 = call i64 @__olang_fmt_i64(ptr %t1341, i64 %t1306)
  %t1343 = getelementptr i8, ptr %t1341, i64 %t1307
  call void @olang_textcopy(ptr %t1343, ptr %t1309, i64 %t1310)
  %t1344 = getelementptr i8, ptr %t1343, i64 %t1310
  %t1345 = call i64 @__olang_fmt_i64(ptr %t1344, i64 %t1313)
  %t1346 = getelementptr i8, ptr %t1344, i64 %t1314
  call void @olang_textcopy(ptr %t1346, ptr %t1316, i64 %t1317)
  %t1347 = getelementptr i8, ptr %t1346, i64 %t1317
  call void @olang_textcopy(ptr %t1347, ptr %t1320, i64 %t1321)
  %t1348 = getelementptr i8, ptr %t1347, i64 %t1321
  call void @olang_textcopy(ptr %t1348, ptr %t1323, i64 %t1324)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1324
  call void @olang_textcopy(ptr %t1349, ptr %t1327, i64 %t1328)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1328
  call void @olang_textcopy(ptr %t1350, ptr %t1330, i64 %t1331)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1331
  %t1352 = call i64 @__olang_fmt_i64(ptr %t1351, i64 %t1334)
  %t1353 = getelementptr i8, ptr %t1351, i64 %t1335
  call void @olang_textcopy(ptr %t1353, ptr %t1337, i64 %t1338)
  %t1354 = insertvalue { i64, ptr } undef, i64 %t1339, 0
  %t1355 = insertvalue { i64, ptr } %t1354, ptr %t1340, 1
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  %t1358 = extractvalue { i64, ptr } %t1355, 1
  %t1359 = mul i64 %t1357, 1
  %t1360 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1360, ptr %t1358, i64 %t1359, i1 false)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1357, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1360, 1
  %t1363 = load ptr, ptr %l377, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1363, { i64, ptr } %t1362)
  br label %bb126
bb126:
  %t1365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1365, ptr %l387, !tbaa !29
  %t1366 = load ptr, ptr %l8, !tbaa !29
  %t1367 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1367, ptr %l389, !tbaa !27
  %t1368 = load i32, ptr %l47, !tbaa !23
  %t1370 = sext i32 %t1368 to i64
  %t1371 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t1372 = load ptr, ptr %t1371, !tbaa !27
  %t1373 = getelementptr i32, ptr %t1372, i64 %t1370
  %t1374 = load i32, ptr %t1373, !tbaa !33
  %t1377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1366, i32 %t1374)
  store { i64, ptr } %t1377, ptr %l392
  br label %bb127
bb127:
  %t1378 = load i32, ptr %l17, !tbaa !23
  %t1379 = load i32, ptr %l47, !tbaa !23
  %t1380 = load i32, ptr %l17, !tbaa !23
  %t1381 = load i32, ptr %l47, !tbaa !23
  %t1382 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t1383 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t1384 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t1385 = extractvalue { i64, ptr } %t1384, 1
  %t1386 = extractvalue { i64, ptr } %t1384, 0
  %t1387 = add i64 %t1383, %t1386
  %t1388 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t1389 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t1390 = add i64 %t1387, %t1389
  %t1392 = sext i32 %t1378 to i64
  %t1393 = call i64 @__olang_fmt_i64(ptr null, i64 %t1392)
  %t1394 = add i64 %t1390, %t1393
  %t1395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t1396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t1397 = add i64 %t1394, %t1396
  %t1399 = sext i32 %t1379 to i64
  %t1400 = call i64 @__olang_fmt_i64(ptr null, i64 %t1399)
  %t1401 = add i64 %t1397, %t1400
  %t1402 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t1403 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t1404 = add i64 %t1401, %t1403
  %t1406 = sext i32 %t1380 to i64
  %t1407 = call i64 @__olang_fmt_i64(ptr null, i64 %t1406)
  %t1408 = add i64 %t1404, %t1407
  %t1409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t1410 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t1411 = add i64 %t1408, %t1410
  %t1413 = sext i32 %t1381 to i64
  %t1414 = call i64 @__olang_fmt_i64(ptr null, i64 %t1413)
  %t1415 = add i64 %t1411, %t1414
  %t1416 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t1417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t1418 = add i64 %t1415, %t1417
  %t1419 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1418)
  call void @olang_textcopy(ptr %t1419, ptr %t1382, i64 %t1383)
  %t1420 = getelementptr i8, ptr %t1419, i64 %t1383
  call void @olang_textcopy(ptr %t1420, ptr %t1385, i64 %t1386)
  %t1421 = getelementptr i8, ptr %t1420, i64 %t1386
  call void @olang_textcopy(ptr %t1421, ptr %t1388, i64 %t1389)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1389
  %t1423 = call i64 @__olang_fmt_i64(ptr %t1422, i64 %t1392)
  %t1424 = getelementptr i8, ptr %t1422, i64 %t1393
  call void @olang_textcopy(ptr %t1424, ptr %t1395, i64 %t1396)
  %t1425 = getelementptr i8, ptr %t1424, i64 %t1396
  %t1426 = call i64 @__olang_fmt_i64(ptr %t1425, i64 %t1399)
  %t1427 = getelementptr i8, ptr %t1425, i64 %t1400
  call void @olang_textcopy(ptr %t1427, ptr %t1402, i64 %t1403)
  %t1428 = getelementptr i8, ptr %t1427, i64 %t1403
  %t1429 = call i64 @__olang_fmt_i64(ptr %t1428, i64 %t1406)
  %t1430 = getelementptr i8, ptr %t1428, i64 %t1407
  call void @olang_textcopy(ptr %t1430, ptr %t1409, i64 %t1410)
  %t1431 = getelementptr i8, ptr %t1430, i64 %t1410
  %t1432 = call i64 @__olang_fmt_i64(ptr %t1431, i64 %t1413)
  %t1433 = getelementptr i8, ptr %t1431, i64 %t1414
  call void @olang_textcopy(ptr %t1433, ptr %t1416, i64 %t1417)
  %t1434 = insertvalue { i64, ptr } undef, i64 %t1418, 0
  %t1435 = insertvalue { i64, ptr } %t1434, ptr %t1419, 1
  %t1437 = extractvalue { i64, ptr } %t1435, 0
  %t1438 = extractvalue { i64, ptr } %t1435, 1
  %t1439 = mul i64 %t1437, 1
  %t1440 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1440, ptr %t1438, i64 %t1439, i1 false)
  %t1441 = insertvalue { i64, ptr } undef, i64 %t1437, 0
  %t1442 = insertvalue { i64, ptr } %t1441, ptr %t1440, 1
  %t1443 = load ptr, ptr %l387, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1443, { i64, ptr } %t1442)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s40)
  br label %bb129
bb129:
  %t1445 = load i32, ptr %l46, !tbaa !23
  %t1447 = add i32 %t1445, 1
  store i32 %t1447, ptr %l46, !tbaa !23
  br label %bb120
bb130:
  br label %bb131
bb131:
  %t1449 = load ptr, ptr %l0, !tbaa !29
  %t1450 = load ptr, ptr %l1, !tbaa !29
  %t1451 = load %"compiler/mir:Task", ptr %l3
  %t1452 = load i64, ptr %l6, !tbaa !24
  %t1454 = load i32, ptr %l17, !tbaa !23
  %t1455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t1456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t1458 = sext i32 %t1454 to i64
  %t1459 = call i64 @__olang_fmt_i64(ptr null, i64 %t1458)
  %t1460 = add i64 %t1456, %t1459
  %t1461 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1460)
  call void @olang_textcopy(ptr %t1461, ptr %t1455, i64 %t1456)
  %t1462 = getelementptr i8, ptr %t1461, i64 %t1456
  %t1463 = call i64 @__olang_fmt_i64(ptr %t1462, i64 %t1458)
  %t1464 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1465 = insertvalue { i64, ptr } %t1464, ptr %t1461, 1
  %t1467 = extractvalue { i64, ptr } %t1465, 0
  %t1468 = extractvalue { i64, ptr } %t1465, 1
  %t1469 = mul i64 %t1467, 1
  %t1470 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1470, ptr %t1468, i64 %t1469, i1 false)
  %t1471 = insertvalue { i64, ptr } undef, i64 %t1467, 0
  %t1472 = insertvalue { i64, ptr } %t1471, ptr %t1470, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v3, ptr %s35, ptr %t1449, ptr %t1450, %"compiler/mir:Task" %t1451, i64 %t1452, { i64, ptr } %a7, { i64, ptr } %t1472)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s35)
  br label %bb133
bb133:
  %t1479 = load i64, ptr %l11, !tbaa !24
  %t1481 = add i64 %t1479, 1
  store i64 %t1481, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb134
bb134:
  %t1483 = load ptr, ptr %l1, !tbaa !29
  %t1484 = load i32, ptr %l17, !tbaa !23
  %t1485 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t1486 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t1488 = sext i32 %t1484 to i64
  %t1489 = call i64 @__olang_fmt_i64(ptr null, i64 %t1488)
  %t1490 = add i64 %t1486, %t1489
  %t1491 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t1492 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t1493 = add i64 %t1490, %t1492
  %t1494 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1493)
  call void @olang_textcopy(ptr %t1494, ptr %t1485, i64 %t1486)
  %t1495 = getelementptr i8, ptr %t1494, i64 %t1486
  %t1496 = call i64 @__olang_fmt_i64(ptr %t1495, i64 %t1488)
  %t1497 = getelementptr i8, ptr %t1495, i64 %t1489
  call void @olang_textcopy(ptr %t1497, ptr %t1491, i64 %t1492)
  %t1498 = insertvalue { i64, ptr } undef, i64 %t1493, 0
  %t1499 = insertvalue { i64, ptr } %t1498, ptr %t1494, 1
  %t1501 = extractvalue { i64, ptr } %t1499, 0
  %t1502 = extractvalue { i64, ptr } %t1499, 1
  %t1503 = mul i64 %t1501, 1
  %t1504 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1503)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1504, ptr %t1502, i64 %t1503, i1 false)
  %t1505 = insertvalue { i64, ptr } undef, i64 %t1501, 0
  %t1506 = insertvalue { i64, ptr } %t1505, ptr %t1504, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t1483, { i64, ptr } %t1506)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s2)
  br label %bb136
bb136:
  %t1509 = load i32, ptr %l16, !tbaa !23
  %t1511 = add i32 %t1509, 1
  store i32 %t1511, ptr %l16, !tbaa !23
  br label %bb8
bb137:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v2, ptr %t2, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = mul i64 %t8, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t9, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v2, ptr %v1, ptr %v2, ptr %t16, { i64, ptr } %t13, { i64, ptr } %a2, i32 %a3)
  store { i64, ptr } %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t10, i32 %a3)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i32, ptr %l17, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t24 = extractvalue { i64, ptr } %t20, 1
  %t25 = extractvalue { i64, ptr } %t20, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } %t41)
  store { i64, ptr } %t44, ptr %l22
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l27
  br label %bb4
bb4:
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l28, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l29, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l32
  br label %bb5
bb5:
  %t80 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t80, i64 %t81)
  %t93 = getelementptr i8, ptr %t92, i64 %t81
  call void @olang_textcopy(ptr %t93, ptr %t83, i64 %t84)
  %t94 = getelementptr i8, ptr %t93, i64 %t84
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t89)
  %t97 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t92, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l28, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  store { i64, ptr } %t108, ptr %l35
  br label %bb6
bb6:
  %t109 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d260, i32 0, i32 1) })
  br label %bb7
bb7:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t121 = extractvalue { i64, ptr } %a1, 1
  %t122 = extractvalue { i64, ptr } %a1, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t117, 1
  %t129 = extractvalue { i64, ptr } %t117, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t118, i64 %t119)
  %t135 = getelementptr i8, ptr %t134, i64 %t119
  call void @olang_textcopy(ptr %t135, ptr %t121, i64 %t122)
  %t136 = getelementptr i8, ptr %t135, i64 %t122
  call void @olang_textcopy(ptr %t136, ptr %t124, i64 %t125)
  %t137 = getelementptr i8, ptr %t136, i64 %t125
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t134, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t150 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t115, { i64, ptr } %t147)
  store { i64, ptr } %t150, ptr %l43
  br label %bb8
bb8:
  %t151 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/emit:fnEm", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t155, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d264, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d265, i32 0, i32 1) })
  br label %bb9
bb9:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t164 = extractvalue { i64, ptr } %t158, 1
  %t165 = extractvalue { i64, ptr } %t158, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t159, 1
  %t172 = extractvalue { i64, ptr } %t159, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t178 = extractvalue { i64, ptr } %t160, 1
  %t179 = extractvalue { i64, ptr } %t160, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t161, i64 %t162)
  %t185 = getelementptr i8, ptr %t184, i64 %t162
  call void @olang_textcopy(ptr %t185, ptr %t164, i64 %t165)
  %t186 = getelementptr i8, ptr %t185, i64 %t165
  call void @olang_textcopy(ptr %t186, ptr %t167, i64 %t168)
  %t187 = getelementptr i8, ptr %t186, i64 %t168
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t174, i64 %t175)
  %t189 = getelementptr i8, ptr %t188, i64 %t175
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t184, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t199)
  br label %bb10
bb10:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t202, { i64, ptr } %t203, { i64, ptr } %t204)
  store { i64, ptr } %t208, ptr %l55
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t209 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { { i64, ptr }, i32 }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %t1, %"compiler/mir:Place" %a1)
  store { { i64, ptr }, i32 } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { { i64, ptr }, i32 }, ptr %l8
  store { { i64, ptr }, i32 } %t6, ptr %l2
  %t7 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t23 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t26, i32 %t24)
  store i32 %t30, ptr %l15
  br label %bb2
bb2:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp ne i32 %t32, %t33
  br i1 %t36, label %bb3, label %bb4
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l22
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb6
bb5:
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l19, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l24, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = extractvalue { i64, ptr } %t63, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t87 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t62, { i64, ptr } %t84)
  store { i64, ptr } %t87, ptr %l31
  br label %bb10
bb10:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/emit:fnEm", ptr %t95, i32 0, i32 14
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t99 = load ptr, ptr %l26, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %t99, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d272, i32 0, i32 1) }, { i64, ptr } %t94, { i64, ptr } %t98)
  store { i64, ptr } %t102, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 23
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t12, i64 %t15)
  store i1 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4)
  unreachable
bb10:
  %t20 = load i1, ptr %l3, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportNamed(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:BasicBlock"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [21 x i64] }
  %l12 = alloca %"compiler/mir:Place"
  %l13 = alloca { i64, [15 x i64] }
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/mir:BasicBlock"
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, [21 x i64] }
  %l46 = alloca { i64, [21 x i64] }
  %l52 = alloca i1
  %l56 = alloca i1
  %l70 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 -1, ptr %l2, !tbaa !23
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb13
bb3:
  %t10 = getelementptr %"compiler/mir:Place", ptr %l3, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l4
  %t13 = load { i64, [2 x i64] }, ptr %l4
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l5, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757)
  unreachable
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_dde810cb192bdc32_ece13dbcfe1403b6)
  unreachable
bb18:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/mir:Fn", ptr %t27, i32 0, i32 9
  store ptr %t29, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  %t31 = load i64, ptr %l7, !tbaa !24
  store i64 %t31, ptr %l29, !tbaa !24
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l31
  br label %bb20
bb20:
  %t35 = load i64, ptr %l29, !tbaa !24
  %t36 = load i64, ptr %l31, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb21, label %bb22
bb21:
  br label %bb81
bb22:
  br label %bb23
bb23:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store %"compiler/mir:BasicBlock" %t45, ptr %l36
  br label %bb24
bb24:
  %t46 = load %"compiler/mir:BasicBlock", ptr %l36
  store %"compiler/mir:BasicBlock" %t46, ptr %l8
  %t47 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 0
  store ptr %t47, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t49 = load i64, ptr %l10, !tbaa !24
  store i64 %t49, ptr %l38, !tbaa !24
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l40
  br label %bb26
bb26:
  %t53 = load i64, ptr %l38, !tbaa !24
  %t54 = load i64, ptr %l40, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb27, label %bb28
bb27:
  br label %bb79
bb28:
  br label %bb29
bb29:
  %t59 = load ptr, ptr %l9, !tbaa !29
  %t60 = load i64, ptr %l10, !tbaa !24
  %t63 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t59, i64 %t60)
  store { i64, [21 x i64] } %t63, ptr %l45
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l45, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %l11, i64 176, i1 false)
  %t64 = load { i64, [21 x i64] }, ptr %l46
  %t65 = extractvalue { i64, [21 x i64] } %t64, 0
  %t66 = icmp eq i64 %t65, 0
  br i1 %t66, label %bb31, label %bb32
bb31:
  %t68 = getelementptr { i64, [21 x i64] }, ptr %l11, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t68, i32 0, i32 1
  %t70 = load %"compiler/mir:Place", ptr %t69
  store %"compiler/mir:Place" %t70, ptr %l12
  %t72 = getelementptr { i64, [21 x i64] }, ptr %l11, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t72, i32 0, i32 2
  %t74 = load { i64, [15 x i64] }, ptr %t73
  store { i64, [15 x i64] } %t74, ptr %l13
  br label %bb33
bb32:
  br label %bb72
bb33:
  %t76 = getelementptr %"compiler/mir:Place", ptr %l12, i32 0, i32 1
  %t77 = getelementptr %"compiler/mir:Range", ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = icmp ne i32 %t78, 0
  br i1 %t80, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb37
bb35:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/mir:Place", ptr %l12
  %t84 = load i32, ptr %l2, !tbaa !23
  %t88 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t82, %"compiler/mir:Place" %t83, i32 %t84)
  store i1 %t88, ptr %l56
  br label %bb36
bb36:
  %t89 = load i1, ptr %l56, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l52, !tbaa !21
  br label %bb37
bb37:
  %t92 = load i1, ptr %l52, !tbaa !21
  br i1 %t92, label %bb38, label %bb39
bb38:
  br label %bb78
bb39:
  br label %bb40
bb40:
  %t93 = load { i64, [15 x i64] }, ptr %l13
  %t95 = extractvalue { i64, [15 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 10
  br i1 %t96, label %bb41, label %bb42
bb41:
  %t98 = getelementptr { i64, [15 x i64] }, ptr %l13, i32 0, i32 1
  %t99 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t98, i32 0, i32 0
  %t100 = load { i64, [2 x i64] }, ptr %t99
  store { i64, [2 x i64] } %t100, ptr %l14
  br label %bb43
bb42:
  br label %bb66
bb43:
  %t102 = load { i64, [2 x i64] }, ptr %l14
  %t104 = extractvalue { i64, [2 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 0
  br i1 %t105, label %bb44, label %bb45
bb44:
  %t107 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t108 = getelementptr { i32 }, ptr %t107, i32 0, i32 0
  %t109 = load i32, ptr %t108
  store i32 %t109, ptr %l15, !tbaa !23
  br label %bb46
bb45:
  br label %bb60
bb46:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/emit:fnEm", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/emit:Emitter", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/lower:Lowerer", ptr %t117, i32 0, i32 1
  %t120 = load i32, ptr %l15, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t125 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t119, i64 %t122)
  store ptr %t125, ptr %l70
  br label %bb47
bb47:
  %t126 = load ptr, ptr %l70, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 1
  %t129 = load { i64, [2 x i64] }, ptr %t128
  store { i64, [2 x i64] } %t129, ptr %l16
  %t131 = load { i64, [2 x i64] }, ptr %l16
  %t133 = extractvalue { i64, [2 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 0
  br i1 %t134, label %bb48, label %bb49
bb48:
  %t136 = getelementptr { i64, [2 x i64] }, ptr %l16, i32 0, i32 1
  %t137 = getelementptr { i64 }, ptr %t136, i32 0, i32 0
  %t138 = load i64, ptr %t137
  store i64 %t138, ptr %l17, !tbaa !24
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/emit:fnEm", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l77, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/emit:fnEm", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/emit:Emitter", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  store ptr %t150, ptr %l80, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/emit:fnEm", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/emit:Emitter", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load i64, ptr %l17, !tbaa !24
  %t161 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t157, i64 %t158)
  store i64 %t161, ptr %l85
  br label %bb51
bb51:
  %t162 = load ptr, ptr %l80, !tbaa !29
  %t163 = load i64, ptr %l85, !tbaa !24
  %t164 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t162, i64 %t163)
  store ptr %t164, ptr %l86
  br label %bb52
bb52:
  %t165 = load ptr, ptr %l86, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Func", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %t167, !tbaa !23
  %t169 = load ptr, ptr %l77, !tbaa !29
  %t171 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t169, i32 %t168)
  store { i64, ptr } %t171, ptr %l89
  br label %bb53
bb53:
  %t172 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t173, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t177, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_c0167577194c5569_3f3b475069b70a4d)
  unreachable
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c)
  unreachable
bb65:
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d4e74db3ab2eecf_2f1d311192c757bb)
  unreachable
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a)
  unreachable
bb77:
  br label %bb78
bb78:
  %t179 = load i64, ptr %l10, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l10, !tbaa !24
  br label %bb25
bb79:
  br label %bb80
bb80:
  %t183 = load i64, ptr %l7, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l7, !tbaa !24
  br label %bb19
bb81:
  %t187 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s0, ptr %t187, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d273, i32 0, i32 1) })
  br label %bb82
bb82:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d274, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t189, ptr %l97, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l98, !tbaa !24
  %t192 = load i64, ptr %l98, !tbaa !24
  %t193 = mul i64 %t192, 1
  %t194 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l99, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l98, !tbaa !24
  %t202 = mul i64 %t201, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  %t203 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t203, ptr %l97, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t204 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t204, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %lp26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l33 = alloca { i64, [4 x i64] }
  %l36 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %l55 = alloca i64
  %l62 = alloca ptr
  %l65 = alloca { i64, [4 x i64] }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca { i64, [4 x i64] }
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l167 = alloca i1
  %l172 = alloca i64
  %l179 = alloca { i64, ptr }
  %l181 = alloca i64
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l196 = alloca i1
  %l201 = alloca { i64, ptr }
  %l203 = alloca i64
  %l205 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l215 = alloca i64
  %l219 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l243 = alloca i64
  %l250 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l255 = alloca i64
  %l257 = alloca ptr
  %l258 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l268 = alloca i64
  %l270 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca i1
  %l300 = alloca i1
  %l303 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l305 = alloca i64
  %l306 = alloca { i64, ptr }
  %l308 = alloca ptr
  %l311 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l317 = alloca i64
  %l324 = alloca { i64, ptr }
  %l326 = alloca i64
  %l333 = alloca { i64, ptr }
  %l334 = alloca ptr
  %l335 = alloca i32
  %l337 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l341 = alloca i64
  %l342 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.builder
  %s44room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l3
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t9, %"compiler/mir:Range" %t10, i64 0)
  store { i64, [4 x i64] } %t13, ptr %l33
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l33
  store { i64, [4 x i64] } %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l5
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t15, { i64, [4 x i64] } %t16)
  store i32 %t19, ptr %l36
  br label %bb2
bb2:
  %t20 = load i32, ptr %l36, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l39
  br label %bb3
bb3:
  %t26 = load i32, ptr %l39, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l42
  br label %bb4
bb4:
  %t32 = load i32, ptr %l42, !tbaa !23
  store i32 %t32, ptr %l8, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l45
  br label %bb5
bb5:
  %t38 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l5
  %t41 = load i32, ptr %l6, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t39, { i64, [4 x i64] } %t40, i32 %t41)
  store { i64, ptr } %t45, ptr %l49
  br label %bb6
bb6:
  %t46 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l52
  br label %bb7
bb7:
  %t52 = load i1, ptr %l52, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l55
  br label %bb8
bb8:
  %t58 = load i64, ptr %l55, !tbaa !24
  store i64 %t58, ptr %l12, !tbaa !24
  %t59 = load i32, ptr %l1
  %t61 = trunc i64 3 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t64 = load i32, ptr %l1
  %t66 = trunc i64 4 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t69 = load i32, ptr %l1
  %t71 = trunc i64 5 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb37
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l62, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/mir:Range", ptr %l3
  %t79 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %t76, i64 1)
  store { i64, [4 x i64] } %t79, ptr %l65
  br label %bb16
bb16:
  %t80 = load i32, ptr %l6, !tbaa !23
  %t81 = load ptr, ptr %l62, !tbaa !29
  %t82 = load { i64, [4 x i64] }, ptr %l65
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t81, { i64, [4 x i64] } %t82, i32 %t80)
  store { i64, ptr } %t84, ptr %l67
  br label %bb17
bb17:
  %t85 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t85, ptr %l13, !tbaa !27
  %t86 = load i32, ptr %l1
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d275, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb30
bb21:
  %t91 = load i32, ptr %l1
  %t93 = trunc i64 4 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d277, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_7d1301c542cf69c7_2a1b7d2f181cc69b)
  unreachable
bb30:
  %t96 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t96, ptr %l14, !tbaa !27
  %t97 = load i1, ptr %l11, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d278, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d279, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb33
bb33:
  %t99 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t103 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t108 = extractvalue { i64, ptr } %t99, 1
  %t109 = extractvalue { i64, ptr } %t99, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t115 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t116 = add i64 %t113, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t101, i64 %t102)
  %t118 = getelementptr i8, ptr %t117, i64 %t102
  call void @olang_textcopy(ptr %t118, ptr %t104, i64 %t105)
  %t119 = getelementptr i8, ptr %t118, i64 %t105
  call void @olang_textcopy(ptr %t119, ptr %t108, i64 %t109)
  %t120 = getelementptr i8, ptr %t119, i64 %t109
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t100)
  %t123 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t117, 1
  store { i64, ptr } %t124, ptr %l15, !tbaa !27
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/emit:fnEm", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t138 = extractvalue { i64, ptr } %t131, 1
  %t139 = extractvalue { i64, ptr } %t131, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t145 = extractvalue { i64, ptr } %t132, 1
  %t146 = extractvalue { i64, ptr } %t132, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t133, 1
  %t153 = extractvalue { i64, ptr } %t133, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t159 = extractvalue { i64, ptr } %t134, 1
  %t160 = extractvalue { i64, ptr } %t134, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t135, i64 %t136)
  %t166 = getelementptr i8, ptr %t165, i64 %t136
  call void @olang_textcopy(ptr %t166, ptr %t138, i64 %t139)
  %t167 = getelementptr i8, ptr %t166, i64 %t139
  call void @olang_textcopy(ptr %t167, ptr %t141, i64 %t142)
  %t168 = getelementptr i8, ptr %t167, i64 %t142
  call void @olang_textcopy(ptr %t168, ptr %t145, i64 %t146)
  %t169 = getelementptr i8, ptr %t168, i64 %t146
  call void @olang_textcopy(ptr %t169, ptr %t148, i64 %t149)
  %t170 = getelementptr i8, ptr %t169, i64 %t149
  call void @olang_textcopy(ptr %t170, ptr %t152, i64 %t153)
  %t171 = getelementptr i8, ptr %t170, i64 %t153
  call void @olang_textcopy(ptr %t171, ptr %t155, i64 %t156)
  %t172 = getelementptr i8, ptr %t171, i64 %t156
  call void @olang_textcopy(ptr %t172, ptr %t159, i64 %t160)
  %t173 = getelementptr i8, ptr %t172, i64 %t160
  call void @olang_textcopy(ptr %t173, ptr %t162, i64 %t163)
  %t174 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t165, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t129, { i64, ptr } %t130, { i64, ptr } %t182)
  br label %bb34
bb34:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t193 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t196 = extractvalue { i64, ptr } %t187, 1
  %t197 = extractvalue { i64, ptr } %t187, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t188, 1
  %t204 = extractvalue { i64, ptr } %t188, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t210 = extractvalue { i64, ptr } %t189, 1
  %t211 = extractvalue { i64, ptr } %t189, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t217 = extractvalue { i64, ptr } %t190, 1
  %t218 = extractvalue { i64, ptr } %t190, 0
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t191, 1
  %t225 = extractvalue { i64, ptr } %t191, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t192, 1
  %t232 = extractvalue { i64, ptr } %t192, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t193, i64 %t194)
  %t238 = getelementptr i8, ptr %t237, i64 %t194
  call void @olang_textcopy(ptr %t238, ptr %t196, i64 %t197)
  %t239 = getelementptr i8, ptr %t238, i64 %t197
  call void @olang_textcopy(ptr %t239, ptr %t199, i64 %t200)
  %t240 = getelementptr i8, ptr %t239, i64 %t200
  call void @olang_textcopy(ptr %t240, ptr %t203, i64 %t204)
  %t241 = getelementptr i8, ptr %t240, i64 %t204
  call void @olang_textcopy(ptr %t241, ptr %t206, i64 %t207)
  %t242 = getelementptr i8, ptr %t241, i64 %t207
  call void @olang_textcopy(ptr %t242, ptr %t210, i64 %t211)
  %t243 = getelementptr i8, ptr %t242, i64 %t211
  call void @olang_textcopy(ptr %t243, ptr %t213, i64 %t214)
  %t244 = getelementptr i8, ptr %t243, i64 %t214
  call void @olang_textcopy(ptr %t244, ptr %t217, i64 %t218)
  %t245 = getelementptr i8, ptr %t244, i64 %t218
  call void @olang_textcopy(ptr %t245, ptr %t220, i64 %t221)
  %t246 = getelementptr i8, ptr %t245, i64 %t221
  call void @olang_textcopy(ptr %t246, ptr %t224, i64 %t225)
  %t247 = getelementptr i8, ptr %t246, i64 %t225
  call void @olang_textcopy(ptr %t247, ptr %t227, i64 %t228)
  %t248 = getelementptr i8, ptr %t247, i64 %t228
  call void @olang_textcopy(ptr %t248, ptr %t231, i64 %t232)
  %t249 = getelementptr i8, ptr %t248, i64 %t232
  call void @olang_textcopy(ptr %t249, ptr %t234, i64 %t235)
  %t250 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t237, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t261 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t186, { i64, ptr } %t258)
  store { i64, ptr } %t261, ptr %l96
  br label %bb35
bb35:
  %t262 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t266 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t269 = extractvalue { i64, ptr } %t264, 1
  %t270 = extractvalue { i64, ptr } %t264, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t276 = extractvalue { i64, ptr } %t262, 1
  %t277 = extractvalue { i64, ptr } %t262, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t266, i64 %t267)
  %t283 = getelementptr i8, ptr %t282, i64 %t267
  call void @olang_textcopy(ptr %t283, ptr %t269, i64 %t270)
  %t284 = getelementptr i8, ptr %t283, i64 %t270
  call void @olang_textcopy(ptr %t284, ptr %t272, i64 %t273)
  %t285 = getelementptr i8, ptr %t284, i64 %t273
  call void @olang_textcopy(ptr %t285, ptr %t276, i64 %t277)
  %t286 = getelementptr i8, ptr %t285, i64 %t277
  call void @olang_textcopy(ptr %t286, ptr %t279, i64 %t280)
  %t287 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t282, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t298 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t263, { i64, ptr } %t295)
  store { i64, ptr } %t298, ptr %l102
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t299 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t299, ptr %rv
  br label %ret
bb37:
  %t300 = load i32, ptr %l1
  %t302 = trunc i64 6 to i32
  %t303 = icmp eq i32 %t300, %t302
  br i1 %t303, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb50
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t305 = load i1, ptr %l11, !tbaa !21
  br i1 %t305, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d296, i32 0, i32 1) }, ptr %l106, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t307, ptr %l107, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l108, !tbaa !24
  %t310 = load i64, ptr %l108, !tbaa !24
  %t311 = mul i64 %t310, 1
  %t312 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t311)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, ptr } %t314, ptr %l109, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = load i64, ptr %l108, !tbaa !24
  %t320 = mul i64 %t319, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t316, ptr %t318, i64 %t320, i1 false)
  %t321 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t321, ptr %l107, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t322 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t322, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l110, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load %"compiler/mir:Range", ptr %l3
  %t328 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t324, %"compiler/mir:Range" %t325, i64 1)
  store { i64, [4 x i64] } %t328, ptr %l113
  br label %bb44
bb44:
  %t329 = load i32, ptr %l6, !tbaa !23
  %t330 = load ptr, ptr %l110, !tbaa !29
  %t331 = load { i64, [4 x i64] }, ptr %l113
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s9, ptr %t330, { i64, [4 x i64] } %t331, i32 %t329)
  store { i64, ptr } %t333, ptr %l115
  br label %bb45
bb45:
  %t334 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t334, ptr %l17, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l116, !tbaa !29
  %t336 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t336, ptr %l117, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t337, ptr %l118, !tbaa !27
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t340 = load i64, ptr %l12, !tbaa !24
  %t342 = sub i64 %t340, 1
  %t343 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t344 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t346 = extractvalue { i64, ptr } %t339, 1
  %t347 = extractvalue { i64, ptr } %t339, 0
  %t348 = add i64 %t344, %t347
  %t349 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t350 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t351 = add i64 %t348, %t350
  %t353 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t354 = add i64 %t351, %t353
  %t355 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t354)
  call void @olang_textcopy(ptr %t355, ptr %t343, i64 %t344)
  %t356 = getelementptr i8, ptr %t355, i64 %t344
  call void @olang_textcopy(ptr %t356, ptr %t346, i64 %t347)
  %t357 = getelementptr i8, ptr %t356, i64 %t347
  call void @olang_textcopy(ptr %t357, ptr %t349, i64 %t350)
  %t358 = getelementptr i8, ptr %t357, i64 %t350
  %t359 = call i64 @__olang_fmt_i64(ptr %t358, i64 %t342)
  %t360 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t355, 1
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t364 = extractvalue { i64, ptr } %t361, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  %t371 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t338, { i64, ptr } %t368)
  store { i64, ptr } %t371, ptr %l125
  br label %bb46
bb46:
  %t372 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t374 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = add i64 %t387, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t372, i64 %t373)
  %t393 = getelementptr i8, ptr %t392, i64 %t373
  call void @olang_textcopy(ptr %t393, ptr %t375, i64 %t376)
  %t394 = getelementptr i8, ptr %t393, i64 %t376
  call void @olang_textcopy(ptr %t394, ptr %t378, i64 %t379)
  %t395 = getelementptr i8, ptr %t394, i64 %t379
  call void @olang_textcopy(ptr %t395, ptr %t382, i64 %t383)
  %t396 = getelementptr i8, ptr %t395, i64 %t383
  call void @olang_textcopy(ptr %t396, ptr %t385, i64 %t386)
  %t397 = getelementptr i8, ptr %t396, i64 %t386
  call void @olang_textcopy(ptr %t397, ptr %t389, i64 %t390)
  %t398 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t392, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  %t407 = load ptr, ptr %l116, !tbaa !29
  %t409 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t407, { i64, ptr } %t406)
  store { i64, ptr } %t409, ptr %l128
  br label %bb47
bb47:
  %t410 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t410, ptr %l18, !tbaa !27
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t414 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t417 = extractvalue { i64, ptr } %t412, 1
  %t418 = extractvalue { i64, ptr } %t412, 0
  %t419 = add i64 %t415, %t418
  %t420 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t421 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t422 = add i64 %t419, %t421
  %t424 = extractvalue { i64, ptr } %t413, 1
  %t425 = extractvalue { i64, ptr } %t413, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t429 = add i64 %t426, %t428
  %t430 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t429)
  call void @olang_textcopy(ptr %t430, ptr %t414, i64 %t415)
  %t431 = getelementptr i8, ptr %t430, i64 %t415
  call void @olang_textcopy(ptr %t431, ptr %t417, i64 %t418)
  %t432 = getelementptr i8, ptr %t431, i64 %t418
  call void @olang_textcopy(ptr %t432, ptr %t420, i64 %t421)
  %t433 = getelementptr i8, ptr %t432, i64 %t421
  call void @olang_textcopy(ptr %t433, ptr %t424, i64 %t425)
  %t434 = getelementptr i8, ptr %t433, i64 %t425
  call void @olang_textcopy(ptr %t434, ptr %t427, i64 %t428)
  %t435 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t430, 1
  %t438 = extractvalue { i64, ptr } %t436, 0
  %t439 = extractvalue { i64, ptr } %t436, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  %t446 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t411, { i64, ptr } %t443)
  store { i64, ptr } %t446, ptr %l134
  br label %bb48
bb48:
  %t447 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t451 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t454 = extractvalue { i64, ptr } %t449, 1
  %t455 = extractvalue { i64, ptr } %t449, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t459 = add i64 %t456, %t458
  %t461 = extractvalue { i64, ptr } %t447, 1
  %t462 = extractvalue { i64, ptr } %t447, 0
  %t463 = add i64 %t459, %t462
  %t464 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t451, i64 %t452)
  %t465 = getelementptr i8, ptr %t464, i64 %t452
  call void @olang_textcopy(ptr %t465, ptr %t454, i64 %t455)
  %t466 = getelementptr i8, ptr %t465, i64 %t455
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t461, i64 %t462)
  %t468 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t464, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = extractvalue { i64, ptr } %t469, 1
  %t473 = mul i64 %t471, 1
  %t474 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  %t479 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t448, { i64, ptr } %t476)
  store { i64, ptr } %t479, ptr %l140
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t480 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t480, ptr %rv
  br label %ret
bb50:
  %t481 = load i32, ptr %l1
  %t483 = trunc i64 0 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb60
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t486 = load i1, ptr %l11, !tbaa !21
  br i1 %t486, label %bb54, label %bb55
bb54:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t491 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t494 = extractvalue { i64, ptr } %t489, 1
  %t495 = extractvalue { i64, ptr } %t489, 0
  %t496 = add i64 %t492, %t495
  %t497 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t498 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t499 = add i64 %t496, %t498
  %t501 = extractvalue { i64, ptr } %t490, 1
  %t502 = extractvalue { i64, ptr } %t490, 0
  %t503 = add i64 %t499, %t502
  %t504 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t507 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t506)
  call void @olang_textcopy(ptr %t507, ptr %t491, i64 %t492)
  %t508 = getelementptr i8, ptr %t507, i64 %t492
  call void @olang_textcopy(ptr %t508, ptr %t494, i64 %t495)
  %t509 = getelementptr i8, ptr %t508, i64 %t495
  call void @olang_textcopy(ptr %t509, ptr %t497, i64 %t498)
  %t510 = getelementptr i8, ptr %t509, i64 %t498
  call void @olang_textcopy(ptr %t510, ptr %t501, i64 %t502)
  %t511 = getelementptr i8, ptr %t510, i64 %t502
  call void @olang_textcopy(ptr %t511, ptr %t504, i64 %t505)
  %t512 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t507, 1
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t516 = extractvalue { i64, ptr } %t513, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  %t523 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t488, { i64, ptr } %t520)
  store { i64, ptr } %t523, ptr %l149
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t524 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t524, ptr %rv
  br label %ret
bb57:
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l150, !tbaa !29
  %t526 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t526, ptr %l151, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t527, ptr %l152, !tbaa !27
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t530 = load i64, ptr %l12, !tbaa !24
  %t532 = sub i64 %t530, 1
  %t533 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t536 = extractvalue { i64, ptr } %t529, 1
  %t537 = extractvalue { i64, ptr } %t529, 0
  %t538 = add i64 %t534, %t537
  %t539 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t543 = call i64 @__olang_fmt_i64(ptr null, i64 %t532)
  %t544 = add i64 %t541, %t543
  %t545 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t544)
  call void @olang_textcopy(ptr %t545, ptr %t533, i64 %t534)
  %t546 = getelementptr i8, ptr %t545, i64 %t534
  call void @olang_textcopy(ptr %t546, ptr %t536, i64 %t537)
  %t547 = getelementptr i8, ptr %t546, i64 %t537
  call void @olang_textcopy(ptr %t547, ptr %t539, i64 %t540)
  %t548 = getelementptr i8, ptr %t547, i64 %t540
  %t549 = call i64 @__olang_fmt_i64(ptr %t548, i64 %t532)
  %t550 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t545, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = extractvalue { i64, ptr } %t551, 1
  %t555 = mul i64 %t553, 1
  %t556 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t555)
  call void @llvm.memcpy.p0.p0.i64(ptr %t556, ptr %t554, i64 %t555, i1 false)
  %t557 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t558 = insertvalue { i64, ptr } %t557, ptr %t556, 1
  %t561 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t528, { i64, ptr } %t558)
  store { i64, ptr } %t561, ptr %l159
  br label %bb58
bb58:
  %t562 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t563 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t564 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t564, 1
  %t566 = extractvalue { i64, ptr } %t564, 0
  %t567 = add i64 %t563, %t566
  %t568 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t569 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t570 = add i64 %t567, %t569
  %t571 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 1
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = add i64 %t570, %t573
  %t575 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t577 = add i64 %t574, %t576
  %t578 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t581 = add i64 %t577, %t580
  %t582 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t581)
  call void @olang_textcopy(ptr %t582, ptr %t562, i64 %t563)
  %t583 = getelementptr i8, ptr %t582, i64 %t563
  call void @olang_textcopy(ptr %t583, ptr %t565, i64 %t566)
  %t584 = getelementptr i8, ptr %t583, i64 %t566
  call void @olang_textcopy(ptr %t584, ptr %t568, i64 %t569)
  %t585 = getelementptr i8, ptr %t584, i64 %t569
  call void @olang_textcopy(ptr %t585, ptr %t572, i64 %t573)
  %t586 = getelementptr i8, ptr %t585, i64 %t573
  call void @olang_textcopy(ptr %t586, ptr %t575, i64 %t576)
  %t587 = getelementptr i8, ptr %t586, i64 %t576
  call void @olang_textcopy(ptr %t587, ptr %t579, i64 %t580)
  %t588 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t582, 1
  %t591 = extractvalue { i64, ptr } %t589, 0
  %t592 = extractvalue { i64, ptr } %t589, 1
  %t593 = mul i64 %t591, 1
  %t594 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t593)
  call void @llvm.memcpy.p0.p0.i64(ptr %t594, ptr %t592, i64 %t593, i1 false)
  %t595 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t594, 1
  %t597 = load ptr, ptr %l150, !tbaa !29
  %t599 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t597, { i64, ptr } %t596)
  store { i64, ptr } %t599, ptr %l162
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t600 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t600, ptr %rv
  br label %ret
bb60:
  %t601 = load i32, ptr %l1
  %t603 = trunc i64 20 to i32
  %t604 = icmp eq i32 %t601, %t603
  br i1 %t604, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb130
bb63:
  store %olang.scope zeroinitializer, ptr %s20
  %t606 = load ptr, ptr %l4, !tbaa !29
  %t607 = load i32, ptr %l7, !tbaa !23
  %t610 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t606, i32 %t607)
  store i1 %t610, ptr %l167
  br label %bb64
bb64:
  %t611 = load i1, ptr %l167, !tbaa !21
  br i1 %t611, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s21
  %t612 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t612, 1
  %t615 = extractvalue { i64, ptr } %t612, 0
  %t616 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t615)
  call void @olang_textcopy(ptr %t616, ptr %t614, i64 %t615)
  %t617 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  store { i64, ptr } %t618, ptr %l20, !tbaa !27
  %t620 = load ptr, ptr %l4, !tbaa !29
  %t621 = load i32, ptr %l7, !tbaa !23
  %t624 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t620, i32 %t621)
  store i64 %t624, ptr %l172
  br label %bb67
bb66:
  br label %bb109
bb67:
  %t625 = load i64, ptr %l172, !tbaa !24
  %t626 = icmp ne i64 %t625, 64
  br i1 %t626, label %bb68, label %bb69
bb68:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t630 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t631 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t632 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t634 = extractvalue { i64, ptr } %t629, 1
  %t635 = extractvalue { i64, ptr } %t629, 0
  %t636 = add i64 %t632, %t635
  %t637 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t638 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t639 = add i64 %t636, %t638
  %t641 = extractvalue { i64, ptr } %t630, 1
  %t642 = extractvalue { i64, ptr } %t630, 0
  %t643 = add i64 %t639, %t642
  %t644 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t645 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t646 = add i64 %t643, %t645
  %t647 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t631, i64 %t632)
  %t648 = getelementptr i8, ptr %t647, i64 %t632
  call void @olang_textcopy(ptr %t648, ptr %t634, i64 %t635)
  %t649 = getelementptr i8, ptr %t648, i64 %t635
  call void @olang_textcopy(ptr %t649, ptr %t637, i64 %t638)
  %t650 = getelementptr i8, ptr %t649, i64 %t638
  call void @olang_textcopy(ptr %t650, ptr %t641, i64 %t642)
  %t651 = getelementptr i8, ptr %t650, i64 %t642
  call void @olang_textcopy(ptr %t651, ptr %t644, i64 %t645)
  %t652 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t647, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t656 = extractvalue { i64, ptr } %t653, 1
  %t657 = mul i64 %t655, 1
  %t658 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t657)
  call void @llvm.memcpy.p0.p0.i64(ptr %t658, ptr %t656, i64 %t657, i1 false)
  %t659 = insertvalue { i64, ptr } undef, i64 %t655, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t658, 1
  %t663 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t628, { i64, ptr } %t660)
  store { i64, ptr } %t663, ptr %l179
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t664 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t664, 0
  %t666 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 0
  store i64 %t667, ptr %l181, !tbaa !24
  %t669 = load i64, ptr %l181, !tbaa !24
  %t670 = icmp eq i64 %t665, %t669
  br i1 %t670, label %bb71, label %bb72
bb71:
  %t672 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t673 = load ptr, ptr %t672, !tbaa !27
  %t674 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = load i64, ptr %l181, !tbaa !24
  %t677 = mul i64 %t676, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t673, ptr %t675, i64 %t677, i1 false)
  br label %bb73
bb72:
  %t678 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t678, ptr %l20, !tbaa !27
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t679 = load ptr, ptr %l4, !tbaa !29
  %t680 = load i32, ptr %l8, !tbaa !23
  %t683 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t679, i32 %t680)
  store i64 %t683, ptr %l185
  br label %bb75
bb75:
  %t684 = load i64, ptr %l185, !tbaa !24
  store i64 %t684, ptr %l21, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d318, i32 0, i32 1) }, ptr %l186, !tbaa !27
  %t685 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t685, ptr %l187, !tbaa !27
  %t686 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t687 = extractvalue { i64, ptr } %t686, 0
  store i64 %t687, ptr %l188, !tbaa !24
  %t688 = load i64, ptr %l188, !tbaa !24
  %t689 = mul i64 %t688, 1
  %t690 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t689)
  %t691 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  store { i64, ptr } %t692, ptr %l189, !tbaa !27
  %t693 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t694 = load ptr, ptr %t693, !tbaa !27
  %t695 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t696 = load ptr, ptr %t695, !tbaa !27
  %t697 = load i64, ptr %l188, !tbaa !24
  %t698 = mul i64 %t697, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t694, ptr %t696, i64 %t698, i1 false)
  %t699 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t699, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d319, i32 0, i32 1) }, ptr %l190, !tbaa !27
  %t700 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t700, ptr %l191, !tbaa !27
  %t701 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 0
  store i64 %t702, ptr %l192, !tbaa !24
  %t703 = load i64, ptr %l192, !tbaa !24
  %t704 = mul i64 %t703, 1
  %t705 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t704)
  %t706 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  store { i64, ptr } %t707, ptr %l193, !tbaa !27
  %t708 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !27
  %t710 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !27
  %t712 = load i64, ptr %l192, !tbaa !24
  %t713 = mul i64 %t712, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t709, ptr %t711, i64 %t713, i1 false)
  %t714 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t714, ptr %l23, !tbaa !27
  %t715 = load ptr, ptr %l4, !tbaa !29
  %t716 = load i32, ptr %l8, !tbaa !23
  %t719 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t715, i32 %t716)
  store i1 %t719, ptr %l196
  br label %bb76
bb76:
  %t720 = load i1, ptr %l196, !tbaa !21
  br i1 %t720, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s25
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t722 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t723 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t724 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t726 = extractvalue { i64, ptr } %t722, 1
  %t727 = extractvalue { i64, ptr } %t722, 0
  %t728 = add i64 %t724, %t727
  %t729 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t730 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t731 = add i64 %t728, %t730
  %t732 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t731)
  call void @olang_textcopy(ptr %t732, ptr %t723, i64 %t724)
  %t733 = getelementptr i8, ptr %t732, i64 %t724
  call void @olang_textcopy(ptr %t733, ptr %t726, i64 %t727)
  %t734 = getelementptr i8, ptr %t733, i64 %t727
  call void @olang_textcopy(ptr %t734, ptr %t729, i64 %t730)
  %t735 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t732, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = extractvalue { i64, ptr } %t736, 1
  %t740 = mul i64 %t738, 1
  %t741 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t740)
  call void @llvm.memcpy.p0.p0.i64(ptr %t741, ptr %t739, i64 %t740, i1 false)
  %t742 = insertvalue { i64, ptr } undef, i64 %t738, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t741, 1
  %t746 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t721, { i64, ptr } %t743)
  store { i64, ptr } %t746, ptr %l201
  br label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s28
  %t747 = load i64, ptr %l21, !tbaa !24
  %t749 = icmp sgt i64 %t747, 53
  br i1 %t749, label %bb88, label %bb89
bb79:
  %t751 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t751, 0
  %t753 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 0
  store i64 %t754, ptr %l203, !tbaa !24
  %t756 = load i64, ptr %l203, !tbaa !24
  %t757 = icmp eq i64 %t752, %t756
  br i1 %t757, label %bb80, label %bb81
bb80:
  %t759 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = load i64, ptr %l203, !tbaa !24
  %t764 = mul i64 %t763, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t760, ptr %t762, i64 %t764, i1 false)
  br label %bb82
bb81:
  %t765 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t765, ptr %l22, !tbaa !27
  br label %bb82
bb82:
  %t766 = load ptr, ptr %l0, !tbaa !29
  store ptr %t766, ptr %l205, !tbaa !29
  %t767 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t767, ptr %l206, !tbaa !27
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t770 = getelementptr %"compiler/emit:fnEm", ptr %t768, i32 0, i32 0
  %t771 = load ptr, ptr %t770, !tbaa !29
  %t772 = load i64, ptr %l21, !tbaa !24
  %t775 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s25, ptr %t771, i64 %t772)
  store { i64, ptr } %t775, ptr %l210
  br label %bb83
bb83:
  %t776 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t778 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t779 = extractvalue { i64, ptr } %t778, 1
  %t780 = extractvalue { i64, ptr } %t778, 0
  %t781 = add i64 %t777, %t780
  %t782 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t784 = add i64 %t781, %t783
  %t785 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t785, 1
  %t787 = extractvalue { i64, ptr } %t785, 0
  %t788 = add i64 %t784, %t787
  %t789 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t788)
  call void @olang_textcopy(ptr %t789, ptr %t776, i64 %t777)
  %t790 = getelementptr i8, ptr %t789, i64 %t777
  call void @olang_textcopy(ptr %t790, ptr %t779, i64 %t780)
  %t791 = getelementptr i8, ptr %t790, i64 %t780
  call void @olang_textcopy(ptr %t791, ptr %t782, i64 %t783)
  %t792 = getelementptr i8, ptr %t791, i64 %t783
  call void @olang_textcopy(ptr %t792, ptr %t786, i64 %t787)
  %t793 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t789, 1
  %t796 = extractvalue { i64, ptr } %t794, 0
  %t797 = extractvalue { i64, ptr } %t794, 1
  %t798 = mul i64 %t796, 1
  %t799 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t798)
  call void @llvm.memcpy.p0.p0.i64(ptr %t799, ptr %t797, i64 %t798, i1 false)
  %t800 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t799, 1
  %t802 = load ptr, ptr %l205, !tbaa !29
  %t804 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t802, { i64, ptr } %t801)
  store { i64, ptr } %t804, ptr %l213
  br label %bb84
bb84:
  %t805 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t805, 0
  %t807 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 0
  store i64 %t808, ptr %l215, !tbaa !24
  %t810 = load i64, ptr %l215, !tbaa !24
  %t811 = icmp eq i64 %t806, %t810
  br i1 %t811, label %bb85, label %bb86
bb85:
  %t813 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t814 = load ptr, ptr %t813, !tbaa !27
  %t815 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t816 = load ptr, ptr %t815, !tbaa !27
  %t817 = load i64, ptr %l215, !tbaa !24
  %t818 = mul i64 %t817, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t814, ptr %t816, i64 %t818, i1 false)
  br label %bb87
bb86:
  %t819 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t819, ptr %l23, !tbaa !27
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s25)
  br label %bb106
bb88:
  store %olang.scope zeroinitializer, ptr %s29
  %t820 = load ptr, ptr %l0, !tbaa !29
  store ptr %t820, ptr %l219, !tbaa !29
  %t821 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t821, ptr %l220, !tbaa !27
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t824 = getelementptr %"compiler/emit:fnEm", ptr %t822, i32 0, i32 0
  %t825 = load ptr, ptr %t824, !tbaa !29
  %t826 = bitcast double 0x3ff0000000000000 to i64
  %t828 = load i64, ptr %l21, !tbaa !24
  %t830 = sub i64 %t828, 1
  %t832 = shl i64 %t830, 52
  %t835 = add i64 %t826, %t832
  %t836 = shl i64 1, 63
  %t839 = or i64 %t835, %t836
  %t842 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s29, ptr %t825, i32 14, i64 %t839)
  store { i64, ptr } %t842, ptr %l231
  br label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s31
  %t843 = load ptr, ptr %l0, !tbaa !29
  store ptr %t843, ptr %l238, !tbaa !29
  %t844 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t844, ptr %l239, !tbaa !27
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = getelementptr %"compiler/emit:fnEm", ptr %t845, i32 0, i32 0
  %t848 = load ptr, ptr %t847, !tbaa !29
  %t849 = load i64, ptr %l21, !tbaa !24
  %t851 = sub i64 %t849, 1
  store i64 %t851, ptr %l243, !tbaa !24
  %t852 = load i64, ptr %l243, !tbaa !24
  %t853 = load i64, ptr %l243, !tbaa !24
  %t854 = shl i64 1, %t853
  %t856 = sitofp i64 %t854 to double
  %t858 = fsub double 0x0000000000000000, %t856
  %t860 = fsub double %t858, 0x3ff0000000000000
  %t862 = bitcast double %t860 to i64
  %t866 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s31, ptr %t848, i32 14, i64 %t862)
  store { i64, ptr } %t866, ptr %l250
  br label %bb95
bb90:
  %t867 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t868 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t869 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t874 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t875 = add i64 %t872, %t874
  %t876 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t877 = extractvalue { i64, ptr } %t876, 1
  %t878 = extractvalue { i64, ptr } %t876, 0
  %t879 = add i64 %t875, %t878
  %t880 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t879)
  call void @olang_textcopy(ptr %t880, ptr %t867, i64 %t868)
  %t881 = getelementptr i8, ptr %t880, i64 %t868
  call void @olang_textcopy(ptr %t881, ptr %t870, i64 %t871)
  %t882 = getelementptr i8, ptr %t881, i64 %t871
  call void @olang_textcopy(ptr %t882, ptr %t873, i64 %t874)
  %t883 = getelementptr i8, ptr %t882, i64 %t874
  call void @olang_textcopy(ptr %t883, ptr %t877, i64 %t878)
  %t884 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t885 = insertvalue { i64, ptr } %t884, ptr %t880, 1
  %t887 = extractvalue { i64, ptr } %t885, 0
  %t888 = extractvalue { i64, ptr } %t885, 1
  %t889 = mul i64 %t887, 1
  %t890 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t889)
  call void @llvm.memcpy.p0.p0.i64(ptr %t890, ptr %t888, i64 %t889, i1 false)
  %t891 = insertvalue { i64, ptr } undef, i64 %t887, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t890, 1
  %t893 = load ptr, ptr %l219, !tbaa !29
  %t895 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t893, { i64, ptr } %t892)
  store { i64, ptr } %t895, ptr %l234
  br label %bb91
bb91:
  %t896 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t897 = extractvalue { i64, ptr } %t896, 0
  %t898 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t899 = extractvalue { i64, ptr } %t898, 0
  store i64 %t899, ptr %l236, !tbaa !24
  %t901 = load i64, ptr %l236, !tbaa !24
  %t902 = icmp eq i64 %t897, %t901
  br i1 %t902, label %bb92, label %bb93
bb92:
  %t904 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t905 = load ptr, ptr %t904, !tbaa !27
  %t906 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t907 = load ptr, ptr %t906, !tbaa !27
  %t908 = load i64, ptr %l236, !tbaa !24
  %t909 = mul i64 %t908, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t905, ptr %t907, i64 %t909, i1 false)
  br label %bb94
bb93:
  %t910 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t910, ptr %l22, !tbaa !27
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s29)
  br label %bb100
bb95:
  %t911 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t912 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t913 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t914 = extractvalue { i64, ptr } %t913, 1
  %t915 = extractvalue { i64, ptr } %t913, 0
  %t916 = add i64 %t912, %t915
  %t917 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t919 = add i64 %t916, %t918
  %t920 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t921 = extractvalue { i64, ptr } %t920, 1
  %t922 = extractvalue { i64, ptr } %t920, 0
  %t923 = add i64 %t919, %t922
  %t924 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t923)
  call void @olang_textcopy(ptr %t924, ptr %t911, i64 %t912)
  %t925 = getelementptr i8, ptr %t924, i64 %t912
  call void @olang_textcopy(ptr %t925, ptr %t914, i64 %t915)
  %t926 = getelementptr i8, ptr %t925, i64 %t915
  call void @olang_textcopy(ptr %t926, ptr %t917, i64 %t918)
  %t927 = getelementptr i8, ptr %t926, i64 %t918
  call void @olang_textcopy(ptr %t927, ptr %t921, i64 %t922)
  %t928 = insertvalue { i64, ptr } undef, i64 %t923, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t924, 1
  %t931 = extractvalue { i64, ptr } %t929, 0
  %t932 = extractvalue { i64, ptr } %t929, 1
  %t933 = mul i64 %t931, 1
  %t934 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t933)
  call void @llvm.memcpy.p0.p0.i64(ptr %t934, ptr %t932, i64 %t933, i1 false)
  %t935 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t936 = insertvalue { i64, ptr } %t935, ptr %t934, 1
  %t937 = load ptr, ptr %l238, !tbaa !29
  %t939 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t937, { i64, ptr } %t936)
  store { i64, ptr } %t939, ptr %l253
  br label %bb96
bb96:
  %t940 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t941 = extractvalue { i64, ptr } %t940, 0
  %t942 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t943 = extractvalue { i64, ptr } %t942, 0
  store i64 %t943, ptr %l255, !tbaa !24
  %t945 = load i64, ptr %l255, !tbaa !24
  %t946 = icmp eq i64 %t941, %t945
  br i1 %t946, label %bb97, label %bb98
bb97:
  %t948 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !27
  %t950 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t951 = load ptr, ptr %t950, !tbaa !27
  %t952 = load i64, ptr %l255, !tbaa !24
  %t953 = mul i64 %t952, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t949, ptr %t951, i64 %t953, i1 false)
  br label %bb99
bb98:
  %t954 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t954, ptr %l22, !tbaa !27
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s31)
  br label %bb100
bb100:
  %t955 = load ptr, ptr %l0, !tbaa !29
  store ptr %t955, ptr %l257, !tbaa !29
  %t956 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t956, ptr %l258, !tbaa !27
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t959 = getelementptr %"compiler/emit:fnEm", ptr %t957, i32 0, i32 0
  %t960 = load ptr, ptr %t959, !tbaa !29
  %t961 = load i64, ptr %l21, !tbaa !24
  %t963 = sub i64 %t961, 1
  %t966 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s28, ptr %t960, i64 %t963)
  store { i64, ptr } %t966, ptr %l263
  br label %bb101
bb101:
  %t967 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t968 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t969 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t970 = extractvalue { i64, ptr } %t969, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = add i64 %t968, %t971
  %t973 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t974 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t975 = add i64 %t972, %t974
  %t976 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t977 = extractvalue { i64, ptr } %t976, 1
  %t978 = extractvalue { i64, ptr } %t976, 0
  %t979 = add i64 %t975, %t978
  %t980 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t979)
  call void @olang_textcopy(ptr %t980, ptr %t967, i64 %t968)
  %t981 = getelementptr i8, ptr %t980, i64 %t968
  call void @olang_textcopy(ptr %t981, ptr %t970, i64 %t971)
  %t982 = getelementptr i8, ptr %t981, i64 %t971
  call void @olang_textcopy(ptr %t982, ptr %t973, i64 %t974)
  %t983 = getelementptr i8, ptr %t982, i64 %t974
  call void @olang_textcopy(ptr %t983, ptr %t977, i64 %t978)
  %t984 = insertvalue { i64, ptr } undef, i64 %t979, 0
  %t985 = insertvalue { i64, ptr } %t984, ptr %t980, 1
  %t987 = extractvalue { i64, ptr } %t985, 0
  %t988 = extractvalue { i64, ptr } %t985, 1
  %t989 = mul i64 %t987, 1
  %t990 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t989)
  call void @llvm.memcpy.p0.p0.i64(ptr %t990, ptr %t988, i64 %t989, i1 false)
  %t991 = insertvalue { i64, ptr } undef, i64 %t987, 0
  %t992 = insertvalue { i64, ptr } %t991, ptr %t990, 1
  %t993 = load ptr, ptr %l257, !tbaa !29
  %t995 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t993, { i64, ptr } %t992)
  store { i64, ptr } %t995, ptr %l266
  br label %bb102
bb102:
  %t996 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t997 = extractvalue { i64, ptr } %t996, 0
  %t998 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t999 = extractvalue { i64, ptr } %t998, 0
  store i64 %t999, ptr %l268, !tbaa !24
  %t1001 = load i64, ptr %l268, !tbaa !24
  %t1002 = icmp eq i64 %t997, %t1001
  br i1 %t1002, label %bb103, label %bb104
bb103:
  %t1004 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t1005 = load ptr, ptr %t1004, !tbaa !27
  %t1006 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t1007 = load ptr, ptr %t1006, !tbaa !27
  %t1008 = load i64, ptr %l268, !tbaa !24
  %t1009 = mul i64 %t1008, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1005, ptr %t1007, i64 %t1009, i1 false)
  br label %bb105
bb104:
  %t1010 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t1010, ptr %l23, !tbaa !27
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s28)
  br label %bb106
bb106:
  %t1011 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1011, ptr %l270, !tbaa !29
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1013 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1014 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1015 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t1016 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t1018 = extractvalue { i64, ptr } %t1013, 1
  %t1019 = extractvalue { i64, ptr } %t1013, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t1022 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t1023 = add i64 %t1020, %t1022
  %t1025 = extractvalue { i64, ptr } %t1014, 1
  %t1026 = extractvalue { i64, ptr } %t1014, 0
  %t1027 = add i64 %t1023, %t1026
  %t1028 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t1027)
  call void @olang_textcopy(ptr %t1028, ptr %t1015, i64 %t1016)
  %t1029 = getelementptr i8, ptr %t1028, i64 %t1016
  call void @olang_textcopy(ptr %t1029, ptr %t1018, i64 %t1019)
  %t1030 = getelementptr i8, ptr %t1029, i64 %t1019
  call void @olang_textcopy(ptr %t1030, ptr %t1021, i64 %t1022)
  %t1031 = getelementptr i8, ptr %t1030, i64 %t1022
  call void @olang_textcopy(ptr %t1031, ptr %t1025, i64 %t1026)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1027, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1028, 1
  %t1035 = extractvalue { i64, ptr } %t1033, 0
  %t1036 = extractvalue { i64, ptr } %t1033, 1
  %t1037 = mul i64 %t1035, 1
  %t1038 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t1037)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1038, ptr %t1036, i64 %t1037, i1 false)
  %t1039 = insertvalue { i64, ptr } undef, i64 %t1035, 0
  %t1040 = insertvalue { i64, ptr } %t1039, ptr %t1038, 1
  %t1043 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t1012, { i64, ptr } %t1040)
  store { i64, ptr } %t1043, ptr %l276
  br label %bb107
bb107:
  %t1044 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t1045 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t1046 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t1047 = extractvalue { i64, ptr } %t1046, 1
  %t1048 = extractvalue { i64, ptr } %t1046, 0
  %t1049 = add i64 %t1045, %t1048
  %t1050 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t1051 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t1052 = add i64 %t1049, %t1051
  %t1053 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1052)
  call void @olang_textcopy(ptr %t1053, ptr %t1044, i64 %t1045)
  %t1054 = getelementptr i8, ptr %t1053, i64 %t1045
  call void @olang_textcopy(ptr %t1054, ptr %t1047, i64 %t1048)
  %t1055 = getelementptr i8, ptr %t1054, i64 %t1048
  call void @olang_textcopy(ptr %t1055, ptr %t1050, i64 %t1051)
  %t1056 = insertvalue { i64, ptr } undef, i64 %t1052, 0
  %t1057 = insertvalue { i64, ptr } %t1056, ptr %t1053, 1
  %t1059 = extractvalue { i64, ptr } %t1057, 0
  %t1060 = extractvalue { i64, ptr } %t1057, 1
  %t1061 = mul i64 %t1059, 1
  %t1062 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1061)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1062, ptr %t1060, i64 %t1061, i1 false)
  %t1063 = insertvalue { i64, ptr } undef, i64 %t1059, 0
  %t1064 = insertvalue { i64, ptr } %t1063, ptr %t1062, 1
  %t1065 = load ptr, ptr %l270, !tbaa !29
  %t1067 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1065, { i64, ptr } %t1064)
  store { i64, ptr } %t1067, ptr %l279
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t1068 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t1068, ptr %rv
  br label %ret
bb109:
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1071 = load i32, ptr %l6, !tbaa !23
  %t1072 = load i32, ptr %l2, !tbaa !23
  %t1077 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %s0, ptr %s20, ptr %t1069, { i64, ptr } %t1070, i32 %t1071, i32 %t1072)
  store { i64, ptr } %t1077, ptr %l284
  br label %bb110
bb110:
  %t1078 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t1078, ptr %l24, !tbaa !27
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1081 = load i32, ptr %l2, !tbaa !23
  %t1082 = load i32, ptr %l6, !tbaa !23
  %t1087 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %s20, ptr %s20, ptr %t1079, { i64, ptr } %t1080, i32 %t1081, i32 %t1082)
  store { i64, ptr } %t1087, ptr %l289
  br label %bb111
bb111:
  %t1088 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1090 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t1092 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1093 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t1094 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t1096 = extractvalue { i64, ptr } %t1090, 1
  %t1097 = extractvalue { i64, ptr } %t1090, 0
  %t1098 = add i64 %t1094, %t1097
  %t1099 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t1100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t1101 = add i64 %t1098, %t1100
  %t1103 = extractvalue { i64, ptr } %t1088, 1
  %t1104 = extractvalue { i64, ptr } %t1088, 0
  %t1105 = add i64 %t1101, %t1104
  %t1106 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t1107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t1108 = add i64 %t1105, %t1107
  %t1110 = extractvalue { i64, ptr } %t1092, 1
  %t1111 = extractvalue { i64, ptr } %t1092, 0
  %t1112 = add i64 %t1108, %t1111
  %t1113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1112)
  call void @olang_textcopy(ptr %t1113, ptr %t1093, i64 %t1094)
  %t1114 = getelementptr i8, ptr %t1113, i64 %t1094
  call void @olang_textcopy(ptr %t1114, ptr %t1096, i64 %t1097)
  %t1115 = getelementptr i8, ptr %t1114, i64 %t1097
  call void @olang_textcopy(ptr %t1115, ptr %t1099, i64 %t1100)
  %t1116 = getelementptr i8, ptr %t1115, i64 %t1100
  call void @olang_textcopy(ptr %t1116, ptr %t1103, i64 %t1104)
  %t1117 = getelementptr i8, ptr %t1116, i64 %t1104
  call void @olang_textcopy(ptr %t1117, ptr %t1106, i64 %t1107)
  %t1118 = getelementptr i8, ptr %t1117, i64 %t1107
  call void @olang_textcopy(ptr %t1118, ptr %t1110, i64 %t1111)
  %t1119 = insertvalue { i64, ptr } undef, i64 %t1112, 0
  %t1120 = insertvalue { i64, ptr } %t1119, ptr %t1113, 1
  %t1122 = extractvalue { i64, ptr } %t1120, 0
  %t1123 = extractvalue { i64, ptr } %t1120, 1
  %t1124 = mul i64 %t1122, 1
  %t1125 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1125, ptr %t1123, i64 %t1124, i1 false)
  %t1126 = insertvalue { i64, ptr } undef, i64 %t1122, 0
  %t1127 = insertvalue { i64, ptr } %t1126, ptr %t1125, 1
  %t1130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1089, { i64, ptr } %t1127)
  store { i64, ptr } %t1130, ptr %l296
  br label %bb112
bb112:
  %t1131 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t1131, ptr %lp26
  %t1132 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t1133 = load ptr, ptr %lp26
  store { i64, ptr } %t1132, ptr %t1133, !tbaa !27
  %t1134 = load i1, ptr %l11, !tbaa !21
  store i1 %t1134, ptr %l297, !tbaa !21
  %t1135 = load ptr, ptr %l4, !tbaa !29
  %t1136 = load i32, ptr %l8, !tbaa !23
  %t1139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t1135, i32 %t1136)
  store i1 %t1139, ptr %l300
  br label %bb113
bb113:
  %t1140 = load i1, ptr %l297, !tbaa !21
  %t1141 = load i1, ptr %l300, !tbaa !21
  %t1142 = icmp eq i1 %t1140, %t1141
  br i1 %t1142, label %bb114, label %bb115
bb114:
  %t1144 = load ptr, ptr %lp26
  %t1145 = load { i64, ptr }, ptr %t1144, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1145, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d337, i32 0, i32 1) }, ptr %l303, !tbaa !27
  %t1147 = load { i64, ptr }, ptr %l303, !tbaa !27
  store { i64, ptr } %t1147, ptr %l304, !tbaa !27
  %t1148 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t1149 = extractvalue { i64, ptr } %t1148, 0
  store i64 %t1149, ptr %l305, !tbaa !24
  %t1150 = load i64, ptr %l305, !tbaa !24
  %t1151 = mul i64 %t1150, 1
  %t1152 = call ptr @__olang_scope_alloc_zeroed(ptr %s20, i64 %t1151)
  %t1153 = insertvalue { i64, ptr } undef, i64 %t1150, 0
  %t1154 = insertvalue { i64, ptr } %t1153, ptr %t1152, 1
  store { i64, ptr } %t1154, ptr %l306, !tbaa !27
  %t1155 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !27
  %t1157 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t1158 = load ptr, ptr %t1157, !tbaa !27
  %t1159 = load i64, ptr %l305, !tbaa !24
  %t1160 = mul i64 %t1159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1156, ptr %t1158, i64 %t1160, i1 false)
  %t1161 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t1161, ptr %l27, !tbaa !27
  %t1162 = load i1, ptr %l11, !tbaa !21
  br i1 %t1162, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s38
  %t1164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1164, ptr %l308, !tbaa !29
  %t1165 = load ptr, ptr %l0, !tbaa !29
  %t1166 = load i32, ptr %l8, !tbaa !23
  %t1169 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s38, ptr %t1165, i32 %t1166)
  store { i64, ptr } %t1169, ptr %l311
  br label %bb119
bb118:
  %t1170 = load ptr, ptr %l0, !tbaa !29
  %t1171 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t1172 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1173 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t1174 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t1176 = extractvalue { i64, ptr } %t1171, 1
  %t1177 = extractvalue { i64, ptr } %t1171, 0
  %t1178 = add i64 %t1174, %t1177
  %t1179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t1180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t1181 = add i64 %t1178, %t1180
  %t1183 = extractvalue { i64, ptr } %t1172, 1
  %t1184 = extractvalue { i64, ptr } %t1172, 0
  %t1185 = add i64 %t1181, %t1184
  %t1186 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t1187 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t1188 = add i64 %t1185, %t1187
  %t1189 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1188)
  call void @olang_textcopy(ptr %t1189, ptr %t1173, i64 %t1174)
  %t1190 = getelementptr i8, ptr %t1189, i64 %t1174
  call void @olang_textcopy(ptr %t1190, ptr %t1176, i64 %t1177)
  %t1191 = getelementptr i8, ptr %t1190, i64 %t1177
  call void @olang_textcopy(ptr %t1191, ptr %t1179, i64 %t1180)
  %t1192 = getelementptr i8, ptr %t1191, i64 %t1180
  call void @olang_textcopy(ptr %t1192, ptr %t1183, i64 %t1184)
  %t1193 = getelementptr i8, ptr %t1192, i64 %t1184
  call void @olang_textcopy(ptr %t1193, ptr %t1186, i64 %t1187)
  %t1194 = insertvalue { i64, ptr } undef, i64 %t1188, 0
  %t1195 = insertvalue { i64, ptr } %t1194, ptr %t1189, 1
  %t1197 = extractvalue { i64, ptr } %t1195, 0
  %t1198 = extractvalue { i64, ptr } %t1195, 1
  %t1199 = mul i64 %t1197, 1
  %t1200 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1200, ptr %t1198, i64 %t1199, i1 false)
  %t1201 = insertvalue { i64, ptr } undef, i64 %t1197, 0
  %t1202 = insertvalue { i64, ptr } %t1201, ptr %t1200, 1
  %t1205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s20, ptr %s20, ptr %t1170, { i64, ptr } %t1202)
  store { i64, ptr } %t1205, ptr %l324
  br label %bb124
bb119:
  %t1206 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1207 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t1208 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t1209 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t1210 = extractvalue { i64, ptr } %t1209, 1
  %t1211 = extractvalue { i64, ptr } %t1209, 0
  %t1212 = add i64 %t1208, %t1211
  %t1213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t1214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t1215 = add i64 %t1212, %t1214
  %t1217 = extractvalue { i64, ptr } %t1206, 1
  %t1218 = extractvalue { i64, ptr } %t1206, 0
  %t1219 = add i64 %t1215, %t1218
  %t1220 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t1221 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t1222 = add i64 %t1219, %t1221
  %t1223 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1222)
  call void @olang_textcopy(ptr %t1223, ptr %t1207, i64 %t1208)
  %t1224 = getelementptr i8, ptr %t1223, i64 %t1208
  call void @olang_textcopy(ptr %t1224, ptr %t1210, i64 %t1211)
  %t1225 = getelementptr i8, ptr %t1224, i64 %t1211
  call void @olang_textcopy(ptr %t1225, ptr %t1213, i64 %t1214)
  %t1226 = getelementptr i8, ptr %t1225, i64 %t1214
  call void @olang_textcopy(ptr %t1226, ptr %t1217, i64 %t1218)
  %t1227 = getelementptr i8, ptr %t1226, i64 %t1218
  call void @olang_textcopy(ptr %t1227, ptr %t1220, i64 %t1221)
  %t1228 = insertvalue { i64, ptr } undef, i64 %t1222, 0
  %t1229 = insertvalue { i64, ptr } %t1228, ptr %t1223, 1
  %t1231 = extractvalue { i64, ptr } %t1229, 0
  %t1232 = extractvalue { i64, ptr } %t1229, 1
  %t1233 = mul i64 %t1231, 1
  %t1234 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1234, ptr %t1232, i64 %t1233, i1 false)
  %t1235 = insertvalue { i64, ptr } undef, i64 %t1231, 0
  %t1236 = insertvalue { i64, ptr } %t1235, ptr %t1234, 1
  %t1237 = load ptr, ptr %l308, !tbaa !29
  %t1239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s20, ptr %s20, ptr %t1237, { i64, ptr } %t1236)
  store { i64, ptr } %t1239, ptr %l315
  br label %bb120
bb120:
  %t1240 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t1241 = extractvalue { i64, ptr } %t1240, 0
  %t1242 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t1243 = extractvalue { i64, ptr } %t1242, 0
  store i64 %t1243, ptr %l317, !tbaa !24
  %t1245 = load i64, ptr %l317, !tbaa !24
  %t1246 = icmp eq i64 %t1241, %t1245
  br i1 %t1246, label %bb121, label %bb122
bb121:
  %t1248 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t1249 = load ptr, ptr %t1248, !tbaa !27
  %t1250 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t1251 = load ptr, ptr %t1250, !tbaa !27
  %t1252 = load i64, ptr %l317, !tbaa !24
  %t1253 = mul i64 %t1252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1249, ptr %t1251, i64 %t1253, i1 false)
  br label %bb123
bb122:
  %t1254 = load { i64, ptr }, ptr %l315, !tbaa !27
  store { i64, ptr } %t1254, ptr %l27, !tbaa !27
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s38)
  br label %bb128
bb124:
  %t1255 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t1256 = extractvalue { i64, ptr } %t1255, 0
  %t1257 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t1258 = extractvalue { i64, ptr } %t1257, 0
  store i64 %t1258, ptr %l326, !tbaa !24
  %t1260 = load i64, ptr %l326, !tbaa !24
  %t1261 = icmp eq i64 %t1256, %t1260
  br i1 %t1261, label %bb125, label %bb126
bb125:
  %t1263 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t1264 = load ptr, ptr %t1263, !tbaa !27
  %t1265 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t1266 = load ptr, ptr %t1265, !tbaa !27
  %t1267 = load i64, ptr %l326, !tbaa !24
  %t1268 = mul i64 %t1267, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1264, ptr %t1266, i64 %t1268, i1 false)
  br label %bb127
bb126:
  %t1269 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t1269, ptr %l27, !tbaa !27
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t1270 = load ptr, ptr %l0, !tbaa !29
  %t1271 = load ptr, ptr %lp26
  %t1272 = load { i64, ptr }, ptr %t1271, !tbaa !27
  %t1273 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t1274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t1275 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t1277 = extractvalue { i64, ptr } %t1272, 1
  %t1278 = extractvalue { i64, ptr } %t1272, 0
  %t1279 = add i64 %t1275, %t1278
  %t1280 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t1281 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t1282 = add i64 %t1279, %t1281
  %t1284 = extractvalue { i64, ptr } %t1273, 1
  %t1285 = extractvalue { i64, ptr } %t1273, 0
  %t1286 = add i64 %t1282, %t1285
  %t1287 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1286)
  call void @olang_textcopy(ptr %t1287, ptr %t1274, i64 %t1275)
  %t1288 = getelementptr i8, ptr %t1287, i64 %t1275
  call void @olang_textcopy(ptr %t1288, ptr %t1277, i64 %t1278)
  %t1289 = getelementptr i8, ptr %t1288, i64 %t1278
  call void @olang_textcopy(ptr %t1289, ptr %t1280, i64 %t1281)
  %t1290 = getelementptr i8, ptr %t1289, i64 %t1281
  call void @olang_textcopy(ptr %t1290, ptr %t1284, i64 %t1285)
  %t1291 = insertvalue { i64, ptr } undef, i64 %t1286, 0
  %t1292 = insertvalue { i64, ptr } %t1291, ptr %t1287, 1
  %t1294 = extractvalue { i64, ptr } %t1292, 0
  %t1295 = extractvalue { i64, ptr } %t1292, 1
  %t1296 = mul i64 %t1294, 1
  %t1297 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1297, ptr %t1295, i64 %t1296, i1 false)
  %t1298 = insertvalue { i64, ptr } undef, i64 %t1294, 0
  %t1299 = insertvalue { i64, ptr } %t1298, ptr %t1297, 1
  %t1302 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1270, { i64, ptr } %t1299)
  store { i64, ptr } %t1302, ptr %l333
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t1303 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t1303, ptr %rv
  br label %ret
bb130:
  br i1 true, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb136
bb133:
  store %olang.scope zeroinitializer, ptr %s43
  %t1304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1304, ptr %l334, !tbaa !29
  %t1305 = load i32, ptr %l1
  store i32 %t1305, ptr %l335
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s44
  store ptr %s44room, ptr %s44
  %t1306 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t1307 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1306, i64 %t1307)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s44, ptr %l335, i64 0)
  br label %bb134
bb134:
  %t1309 = load ptr, ptr %s44
  %t1310 = getelementptr %olang.builder, ptr %s44, i32 0, i32 1
  %t1311 = load i64, ptr %t1310
  %t1312 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1311)
  call void @olang_textcopy(ptr %t1312, ptr %t1309, i64 %t1311)
  %t1313 = insertvalue { i64, ptr } undef, i64 %t1311, 0
  %t1314 = insertvalue { i64, ptr } %t1313, ptr %t1312, 1
  store { i64, ptr } %t1314, ptr %l337, !tbaa !27
  %t1315 = getelementptr %olang.builder, ptr %s44, i32 0, i32 3
  %t1316 = load ptr, ptr %t1315
  %t1317 = icmp ne ptr %t1316, null
  br i1 %t1317, label %sbgrew.1318, label %sbdone.1319
sbgrew.1318:
  call void @__olang_sb_done(ptr %s44)
  br label %sbdone.1319
sbdone.1319:
  %t1320 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t1321 = extractvalue { i64, ptr } %t1320, 0
  %t1322 = extractvalue { i64, ptr } %t1320, 1
  %t1323 = mul i64 %t1321, 1
  %t1324 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1324, ptr %t1322, i64 %t1323, i1 false)
  %t1325 = insertvalue { i64, ptr } undef, i64 %t1321, 0
  %t1326 = insertvalue { i64, ptr } %t1325, ptr %t1324, 1
  %t1327 = load ptr, ptr %l334, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s43, ptr %t1327, { i64, ptr } %t1326)
  br label %bb135
bb135:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d347, i32 0, i32 1) }, ptr %l339, !tbaa !27
  %t1329 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t1329, ptr %l340, !tbaa !27
  %t1330 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t1331 = extractvalue { i64, ptr } %t1330, 0
  store i64 %t1331, ptr %l341, !tbaa !24
  %t1332 = load i64, ptr %l341, !tbaa !24
  %t1333 = mul i64 %t1332, 1
  %t1334 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1333)
  %t1335 = insertvalue { i64, ptr } undef, i64 %t1332, 0
  %t1336 = insertvalue { i64, ptr } %t1335, ptr %t1334, 1
  store { i64, ptr } %t1336, ptr %l342, !tbaa !27
  %t1337 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t1338 = load ptr, ptr %t1337, !tbaa !27
  %t1339 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t1340 = load ptr, ptr %t1339, !tbaa !27
  %t1341 = load i64, ptr %l341, !tbaa !24
  %t1342 = mul i64 %t1341, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1338, ptr %t1340, i64 %t1342, i1 false)
  %t1343 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t1343, ptr %l340, !tbaa !27
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s0)
  %t1344 = load { i64, ptr }, ptr %l340, !tbaa !27
  store { i64, ptr } %t1344, ptr %rv
  br label %ret
bb136:
  call void @__olang_check_failed(ptr @olang_loc_9185a77390ef7566_ed985a49c11fac9a)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = sext i32 %t10 to i64
  %t16 = icmp eq i64 %t12, %a2
  store i1 %t16, ptr %l4, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b58edc65c6718b49_26c0578031dccca5)
  unreachable
bb9:
  %t18 = load i1, ptr %l4, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Place", ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t9, %"compiler/mir:Place" %t10)
  store i32 %t13, ptr %l19
  br label %bb1
bb1:
  %t14 = load i32, ptr %l19, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t15, i32 %t14)
  store i32 %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t21, i32 %t20)
  store i32 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i32, ptr %l25, !tbaa !23
  store i32 %t26, ptr %l8, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Place", ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Place" %t28)
  store { i64, ptr } %t31, ptr %l28
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l9, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [4 x i64] }, ptr %l2
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t34, { i64, [4 x i64] } %t35, i32 %t36)
  store { i64, ptr } %t40, ptr %l33
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, [4 x i64] }, ptr %l2
  %t52 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t48, { i64, [4 x i64] } %t49)
  store i32 %t52, ptr %l37
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t55 = load i32, ptr %l37, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t53, { i64, ptr } %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l38
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l3
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t59, { i64, [4 x i64] } %t60, i32 %t61)
  store { i64, ptr } %t65, ptr %l43
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, [4 x i64] }, ptr %l3
  %t77 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t73, { i64, [4 x i64] } %t74)
  store i32 %t77, ptr %l47
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = load i32, ptr %l47, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t78, { i64, ptr } %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l48
  br label %bb10
bb10:
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t82, ptr %l11, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l52
  br label %bb11
bb11:
  %t89 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t93 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t101 = extractvalue { i64, ptr } %t89, 1
  %t102 = extractvalue { i64, ptr } %t89, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t108 = extractvalue { i64, ptr } %t90, 1
  %t109 = extractvalue { i64, ptr } %t90, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t91, i64 %t92)
  %t112 = getelementptr i8, ptr %t111, i64 %t92
  call void @olang_textcopy(ptr %t112, ptr %t94, i64 %t95)
  %t113 = getelementptr i8, ptr %t112, i64 %t95
  call void @olang_textcopy(ptr %t113, ptr %t97, i64 %t98)
  %t114 = getelementptr i8, ptr %t113, i64 %t98
  call void @olang_textcopy(ptr %t114, ptr %t101, i64 %t102)
  %t115 = getelementptr i8, ptr %t114, i64 %t102
  call void @olang_textcopy(ptr %t115, ptr %t104, i64 %t105)
  %t116 = getelementptr i8, ptr %t115, i64 %t105
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t111, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l49, !tbaa !29
  %t128 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t126, { i64, ptr } %t125)
  store { i64, ptr } %t128, ptr %l57
  br label %bb12
bb12:
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t129, ptr %lp12
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = load ptr, ptr %lp12
  store { i64, ptr } %t130, ptr %t131, !tbaa !27
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l58, !tbaa !29
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t133, i32 %a4)
  store i32 %t137, ptr %l61
  br label %bb13
bb13:
  %t138 = load ptr, ptr %l58, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb14
bb14:
  %t141 = load i32, ptr %l62, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t142, i32 %t141)
  store i1 %t146, ptr %l65
  br label %bb15
bb15:
  %t147 = load i1, ptr %l65, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb16, label %bb17
bb16:
  %t150 = load ptr, ptr %lp12
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l68, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t156, 1
  %t168 = extractvalue { i64, ptr } %t156, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t157, i64 %t158)
  %t171 = getelementptr i8, ptr %t170, i64 %t158
  call void @olang_textcopy(ptr %t171, ptr %t160, i64 %t161)
  %t172 = getelementptr i8, ptr %t171, i64 %t161
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t167, i64 %t168)
  %t174 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t170, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t154, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l74
  br label %bb19
bb19:
  %t186 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %lp12
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t195 = load ptr, ptr %l68, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t195, { i64, ptr } %t192, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l77
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sle i64 %t6, 65536
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t10, i32 %t11)
  store { i64, ptr } %t14, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l8, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v1, ptr %t27, { i64, ptr } %t28, i64 %t29)
  store { i64, ptr } %t30, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %t32)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l20
  br label %bb9
bb9:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t40, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d353, i32 0, i32 1) })
  store { i64, ptr } %t42, ptr %l22
  br label %bb10
bb10:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t53, ptr %lp3
  %t55 = load ptr, ptr %lp3
  store { i64, ptr } %t52, ptr %t55, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/emit:fnEm", ptr %t56, i32 0, i32 4
  store ptr %t58, ptr %l25, !tbaa !29
  %t59 = load ptr, ptr %lp3
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l26, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l29
  br label %bb11
bb11:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = icmp sgt i64 %t66, 8
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l32, !tbaa !24
  br label %bb14
bb13:
  store i64 8, ptr %l32, !tbaa !24
  br label %bb14
bb14:
  %t72 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t74 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l29, !tbaa !24
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t83 = add i64 %t80, %t82
  %t84 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load i64, ptr %l32, !tbaa !24
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t72, i64 %t73)
  %t94 = getelementptr i8, ptr %t93, i64 %t73
  call void @olang_textcopy(ptr %t94, ptr %t75, i64 %t76)
  %t95 = getelementptr i8, ptr %t94, i64 %t76
  call void @olang_textcopy(ptr %t95, ptr %t78, i64 %t79)
  %t96 = getelementptr i8, ptr %t95, i64 %t79
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t81)
  %t98 = getelementptr i8, ptr %t96, i64 %t82
  call void @olang_textcopy(ptr %t98, ptr %t84, i64 %t85)
  %t99 = getelementptr i8, ptr %t98, i64 %t85
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t87)
  %t101 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t101, ptr %t90, i64 %t91)
  %t102 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t93, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t111, { i64, ptr } %t110)
  br label %bb15
bb15:
  %t113 = load ptr, ptr %lp3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Task" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/mir:Task"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, [7 x i64] }
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca { { i64, ptr }, i32 }
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca { i64, [1 x i64] }
  %l58 = alloca { i64, ptr }
  %l59 = alloca %"std/prelude/text:StringBuilder"
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l127 = alloca i64
  %l135 = alloca i32
  %l139 = alloca { i64, ptr }
  %l141 = alloca i64
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l154 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca i64
  %l167 = alloca i64
  %l185 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l205 = alloca { i64, [4 x i64] }
  %l206 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l213 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l218 = alloca i32
  %l221 = alloca i32
  %l247 = alloca { i64, [1 x i64] }
  %l253 = alloca ptr
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l274 = alloca i32
  %l277 = alloca i32
  %l296 = alloca ptr
  %l305 = alloca %"compiler/mir:Place"
  %l306 = alloca { { i64, ptr }, i32 }
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca { i64, ptr }
  %l320 = alloca i32
  %l323 = alloca i32
  %l349 = alloca %"compiler/mir:TaskClause"
  %l355 = alloca ptr
  %l356 = alloca ptr
  %l357 = alloca { i64, [4 x i64] }
  %l360 = alloca i32
  %l361 = alloca { i64, ptr }
  %l366 = alloca i64
  %l374 = alloca i32
  %l377 = alloca i32
  %l403 = alloca { i64, [1 x i64] }
  %l408 = alloca i32
  %l410 = alloca i64
  %l414 = alloca ptr
  %l417 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l425 = alloca i32
  %l427 = alloca i64
  %l435 = alloca %"std/prelude/text:StringBuilder"
  %l438 = alloca i64
  %l442 = alloca i64
  %l445 = alloca i64
  %l466 = alloca ptr
  %l469 = alloca { i64, ptr }
  %l473 = alloca i64
  %l478 = alloca { i64, ptr }
  %l480 = alloca ptr
  %l485 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  %l496 = alloca i64
  %l498 = alloca i64
  %l502 = alloca i64
  %l505 = alloca i64
  %l529 = alloca { i64, ptr }
  %l532 = alloca { i64, ptr }
  %l533 = alloca i1
  %l534 = alloca ptr
  %l535 = alloca { i64, ptr }
  %l536 = alloca { i64, ptr }
  %l540 = alloca i32
  %l546 = alloca { i64, [4 x i64] }
  %l547 = alloca ptr
  %l550 = alloca { i64, ptr }
  %l553 = alloca { i64, ptr }
  %l561 = alloca { i64, ptr }
  %l562 = alloca { i64, ptr }
  %l563 = alloca { i64, ptr }
  %l564 = alloca i64
  %l565 = alloca { i64, ptr }
  %l567 = alloca i64
  %l569 = alloca i64
  %l574 = alloca { i64, ptr }
  %l579 = alloca { i64, ptr }
  %l583 = alloca ptr
  %l584 = alloca { i64, ptr }
  %l589 = alloca { i64, ptr }
  %l591 = alloca { i64, ptr }
  %l593 = alloca i64
  %l595 = alloca i64
  %l596 = alloca { i64, ptr }
  %l599 = alloca ptr
  %l600 = alloca { i64, ptr }
  %l605 = alloca { i64, ptr }
  %l607 = alloca ptr
  %l612 = alloca { i64, ptr }
  %l614 = alloca ptr
  %l619 = alloca { i64, ptr }
  %l621 = alloca ptr
  %l622 = alloca { i64, ptr }
  %l623 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l624 = alloca i1
  %l625 = alloca { i64, ptr }
  %l626 = alloca i32
  %l628 = alloca i64
  %l629 = alloca %"compiler/mir:Task"
  %l635 = alloca %"compiler/mir:ScopeInfo"
  %l638 = alloca { i64, ptr }
  %l642 = alloca { i64, ptr }
  %l650 = alloca ptr
  %l655 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %t728 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/mir:Task" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t18 = sext i32 %t14 to i64
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = getelementptr i8, ptr %t21, i64 %t16
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t18)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d360, i32 0, i32 1) }, ptr %l93, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t29, ptr %l94, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l95, !tbaa !24
  %t32 = load i64, ptr %l95, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l96, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l95, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i1 false, ptr %l8, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d361, i32 0, i32 1) }, ptr %l97, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t44, ptr %l98, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l99, !tbaa !24
  %t47 = load i64, ptr %l99, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l100, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l99, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t58, ptr %l9, !tbaa !27
  %t59 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 0
  %t60 = load { i64, [7 x i64] }, ptr %t59
  store { i64, [7 x i64] } %t60, ptr %l10
  %t62 = load { i64, [7 x i64] }, ptr %l10
  %t64 = extractvalue { i64, [7 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb1, label %bb2
bb1:
  %t67 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t68 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t67, i32 0, i32 0
  %t69 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t69, ptr %l11
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t72 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l12, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t76 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t75, { i64, [2 x i64] } %t76)
  br label %bb4
bb4:
  %t79 = load i32, ptr %l12, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t82 = load { i64, [2 x i64] }, ptr %l11
  %t85 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s2, ptr %t81, { i64, [2 x i64] } %t82)
  store { i64, ptr } %t85, ptr %l111
  br label %bb5
bb5:
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t88 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t86, i64 %t87)
  %t93 = getelementptr i8, ptr %t92, i64 %t87
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l112, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l114, !tbaa !24
  %t101 = load i64, ptr %l114, !tbaa !24
  %t102 = icmp eq i64 %t97, %t101
  br i1 %t102, label %bb6, label %bb7
bb6:
  %t104 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l114, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  br label %bb8
bb7:
  %t110 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t110, ptr %l7, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  %t111 = load { i64, [7 x i64] }, ptr %l10
  %t113 = extractvalue { i64, [7 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 1
  br i1 %t114, label %bb10, label %bb11
bb10:
  %t116 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t117 = getelementptr { i64, i32 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l13, !tbaa !24
  %t120 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t121 = getelementptr { i64, i32 }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l14, !tbaa !23
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load i32, ptr %l14, !tbaa !23
  store i32 %t124, ptr %l6, !tbaa !23
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i32, ptr %l14, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %s4, ptr %t126, i64 %t127, i32 %t128)
  store { i64, ptr } %t132, ptr %l124
  br label %bb13
bb13:
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t135 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  store { i64, ptr } %t142, ptr %l125, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  %t145 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l127, !tbaa !24
  %t148 = load i64, ptr %l127, !tbaa !24
  %t149 = icmp eq i64 %t144, %t148
  br i1 %t149, label %bb14, label %bb15
bb14:
  %t151 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l127, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  br label %bb16
bb15:
  %t157 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  br label %bb16
bb16:
  %t158 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %t158, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d364, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb18:
  %t160 = load { i64, [7 x i64] }, ptr %l10
  %t162 = extractvalue { i64, [7 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 2
  br i1 %t163, label %bb19, label %bb20
bb19:
  %t165 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t166 = getelementptr { { i64, [4 x i64] } }, ptr %t165, i32 0, i32 0
  %t167 = load { i64, [4 x i64] }, ptr %t166
  store { i64, [4 x i64] } %t167, ptr %l15
  br label %bb21
bb20:
  br label %bb27
bb21:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, [4 x i64] }, ptr %l15
  %t173 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t169, { i64, [4 x i64] } %t170)
  store i32 %t173, ptr %l135
  br label %bb22
bb22:
  %t174 = load i32, ptr %l135, !tbaa !23
  store i32 %t174, ptr %l6, !tbaa !23
  store i1 true, ptr %l8, !tbaa !21
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, [4 x i64] }, ptr %l15
  %t177 = load i32, ptr %l6, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t175, { i64, [4 x i64] } %t176, i32 %t177)
  store { i64, ptr } %t181, ptr %l139
  br label %bb23
bb23:
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l141, !tbaa !24
  %t187 = load i64, ptr %l141, !tbaa !24
  %t188 = icmp eq i64 %t183, %t187
  br i1 %t188, label %bb24, label %bb25
bb24:
  %t190 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l141, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  br label %bb26
bb25:
  %t196 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t196, ptr %l9, !tbaa !27
  br label %bb26
bb26:
  br label %bb33
bb27:
  %t197 = load { i64, [7 x i64] }, ptr %l10
  %t199 = extractvalue { i64, [7 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 3
  br i1 %t200, label %bb28, label %bb29
bb28:
  %t202 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t203 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t202, i32 0, i32 2
  %t204 = load i32, ptr %t203
  store i32 %t204, ptr %l16, !tbaa !23
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load i32, ptr %l16, !tbaa !23
  store i32 %t206, ptr %l6, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s7, ptr %t208, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d365, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b)
  unreachable
bb33:
  %t210 = load ptr, ptr %l3, !tbaa !29
  store ptr %t210, ptr %l148, !tbaa !29
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t212 = load i32, ptr %l6, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l151
  br label %bb34
bb34:
  %t216 = load ptr, ptr %l148, !tbaa !29
  %t217 = load i32, ptr %l151, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t216, i32 %t217)
  store { i64, ptr } %t218, ptr %l152
  br label %bb35
bb35:
  %t219 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t219, ptr %l17, !tbaa !27
  %t220 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %l153
  br label %bb36
bb36:
  %t221 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l153
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t221, ptr %l18
  %t222 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l154
  br label %bb37
bb37:
  %t223 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l19
  %t224 = load i1, ptr %l8, !tbaa !21
  br i1 %t224, label %bb38, label %bb39
bb38:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d366, i32 0, i32 1) })
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t227 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t227)
  br label %bb41
bb41:
  br label %bb42
bb42:
  store i64 0, ptr %l20, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t234 = load i64, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t238 = icmp sgt i64 %t234, %t235
  br i1 %t238, label %bb43, label %bb44
bb43:
  %t240 = load i64, ptr %l22, !tbaa !24
  %t242 = icmp sgt i64 %t240, 0
  br i1 %t242, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb48
bb45:
  %t244 = load i64, ptr %l21, !tbaa !24
  %t245 = load i64, ptr %l20, !tbaa !24
  %t248 = sub i64 %t244, %t245
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = add i64 %t248, %t249
  %t254 = sub i64 %t252, 1
  %t255 = load i64, ptr %l22, !tbaa !24
  %t258 = sdiv i64 %t254, %t255
  store i64 %t258, ptr %l167, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb47
bb47:
  %t260 = load i64, ptr %l167, !tbaa !24
  store i64 %t260, ptr %l164, !tbaa !24
  br label %bb48
bb48:
  %t261 = load i64, ptr %l164, !tbaa !24
  store i64 %t261, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb49
bb49:
  %t262 = load i64, ptr %l24, !tbaa !24
  %t263 = load i64, ptr %l23, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb50, label %bb51
bb50:
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l24, !tbaa !24
  %t272 = load i64, ptr %l22, !tbaa !24
  %t275 = mul i64 %t271, %t272
  %t278 = add i64 %t270, %t275
  store i64 %t278, ptr %l25, !tbaa !24
  store ptr %l18, ptr %l185, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t281, ptr %l187, !tbaa !27
  %t282 = load i64, ptr %l25, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  %t290 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t280, i32 %t287)
  store { i64, ptr } %t290, ptr %l190
  br label %bb53
bb53:
  %t291 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  %t293 = extractvalue { i64, ptr } %t291, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t298 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t298, { i64, ptr } %t297)
  br label %bb54
bb54:
  store ptr %l19, ptr %l192, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t301, ptr %l194, !tbaa !27
  %t302 = load i64, ptr %l25, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t302
  %t307 = load i32, ptr %t306, !tbaa !33
  %t310 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t300, i32 %t307)
  store i1 %t310, ptr %l197
  br label %bb55
bb55:
  %t311 = load i1, ptr %l197, !tbaa !21
  br i1 %t311, label %bb56, label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d367, i32 0, i32 1) }, ptr %l199, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t312, ptr %l198, !tbaa !27
  br label %bb60
bb57:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l201, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t317 = load %"compiler/mir:Range", ptr %t316
  %t318 = load i64, ptr %l25, !tbaa !24
  %t322 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t315, %"compiler/mir:Range" %t317, i64 %t318)
  store { i64, [4 x i64] } %t322, ptr %l205
  br label %bb58
bb58:
  %t323 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t323, ptr %l206, !tbaa !27
  %t324 = load i64, ptr %l25, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  %t330 = load ptr, ptr %l201, !tbaa !29
  %t331 = load { i64, [4 x i64] }, ptr %l205
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t330, { i64, [4 x i64] } %t331, i32 %t329)
  store { i64, ptr } %t333, ptr %l209
  br label %bb59
bb59:
  %t334 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t334, ptr %l198, !tbaa !27
  br label %bb60
bb60:
  %t335 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l192, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t342, { i64, ptr } %t341)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t344 = load i64, ptr %l24, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l24, !tbaa !24
  br label %bb49
bb63:
  %t348 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %l213
  br label %bb64
bb64:
  %t349 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l213
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t349, ptr %l26
  store i32 0, ptr %l27, !tbaa !23
  %t350 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t351 = getelementptr %"compiler/mir:Range", ptr %t350, i32 0, i32 1
  %t352 = load i32, ptr %t351, !tbaa !23
  store i32 %t352, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t354 = load i32, ptr %l28, !tbaa !23
  %t355 = load i32, ptr %l27, !tbaa !23
  %t358 = icmp sgt i32 %t354, %t355
  br i1 %t358, label %bb65, label %bb66
bb65:
  %t360 = load i32, ptr %l29, !tbaa !23
  %t362 = icmp sgt i32 %t360, 0
  br i1 %t362, label %bb67, label %bb68
bb66:
  store i32 0, ptr %l218, !tbaa !23
  br label %bb70
bb67:
  %t364 = load i32, ptr %l28, !tbaa !23
  %t365 = load i32, ptr %l27, !tbaa !23
  %t368 = sub i32 %t364, %t365
  %t369 = load i32, ptr %l29, !tbaa !23
  %t372 = add i32 %t368, %t369
  %t374 = sub i32 %t372, 1
  %t375 = load i32, ptr %l29, !tbaa !23
  %t378 = sdiv i32 %t374, %t375
  store i32 %t378, ptr %l221, !tbaa !23
  br label %bb69
bb68:
  store i32 0, ptr %l221, !tbaa !23
  br label %bb69
bb69:
  %t380 = load i32, ptr %l221, !tbaa !23
  store i32 %t380, ptr %l218, !tbaa !23
  br label %bb70
bb70:
  %t381 = load i32, ptr %l218, !tbaa !23
  store i32 %t381, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb71
bb71:
  %t382 = load i32, ptr %l31, !tbaa !23
  %t383 = load i32, ptr %l30, !tbaa !23
  %t386 = icmp slt i32 %t382, %t383
  %t388 = xor i1 %t386, true
  br i1 %t388, label %bb72, label %bb73
bb72:
  br label %bb93
bb73:
  br label %bb74
bb74:
  %t390 = load i32, ptr %l27, !tbaa !23
  %t391 = load i32, ptr %l31, !tbaa !23
  %t392 = load i32, ptr %l29, !tbaa !23
  %t395 = mul i32 %t391, %t392
  %t398 = add i32 %t390, %t395
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/emit:fnEm", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/mir:Fn", ptr %t403, i32 0, i32 12
  %t406 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t407 = getelementptr %"compiler/mir:Range", ptr %t406, i32 0, i32 0
  %t408 = load i32, ptr %t407, !tbaa !23
  %t410 = sext i32 %t408 to i64
  %t413 = sext i32 %t398 to i64
  %t416 = add i64 %t410, %t413
  %t419 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t405, i64 %t416)
  store { i64, [1 x i64] } %t419, ptr %l247
  br label %bb75
bb75:
  %t420 = load { i64, [1 x i64] }, ptr %l247
  store { i64, [1 x i64] } %t420, ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d368, i32 0, i32 1) })
  br label %bb76
bb76:
  %t422 = load { i64, [1 x i64] }, ptr %l33
  %t424 = extractvalue { i64, [1 x i64] } %t422, 0
  %t425 = icmp eq i64 %t424, 2
  br i1 %t425, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb81
bb79:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d369, i32 0, i32 1) })
  br label %bb80
bb80:
  br label %bb91
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb90
bb84:
  store %olang.scope zeroinitializer, ptr %s15
  %t428 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s15, ptr %s15, ptr %t428, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d370, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d371, i32 0, i32 1) })
  br label %bb85
bb85:
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l253, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load { i64, [1 x i64] }, ptr %l33
  %t435 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s15, ptr %t431, { i64, [1 x i64] } %t432)
  store { i64, ptr } %t435, ptr %l256
  br label %bb86
bb86:
  %t436 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t438 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = add i64 %t437, %t440
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t444 = add i64 %t441, %t443
  %t445 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t444)
  call void @olang_textcopy(ptr %t445, ptr %t436, i64 %t437)
  %t446 = getelementptr i8, ptr %t445, i64 %t437
  call void @olang_textcopy(ptr %t446, ptr %t439, i64 %t440)
  %t447 = getelementptr i8, ptr %t446, i64 %t440
  call void @olang_textcopy(ptr %t447, ptr %t442, i64 %t443)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t445, 1
  %t451 = extractvalue { i64, ptr } %t449, 0
  %t452 = extractvalue { i64, ptr } %t449, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t457 = load ptr, ptr %l253, !tbaa !29
  %t459 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t457, { i64, ptr } %t456)
  store { i64, ptr } %t459, ptr %l259
  br label %bb87
bb87:
  %t460 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t460, ptr %l34, !tbaa !27
  %t461 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t461, 1
  %t464 = extractvalue { i64, ptr } %t461, 0
  %t465 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t463, i64 %t464)
  %t466 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } %t467, 1
  %t471 = mul i64 %t469, 1
  %t472 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t471)
  call void @llvm.memcpy.p0.p0.i64(ptr %t472, ptr %t470, i64 %t471, i1 false)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t472, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } %t474)
  br label %bb88
bb88:
  %t477 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t477, 1
  %t480 = extractvalue { i64, ptr } %t477, 0
  %t481 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t480)
  call void @olang_textcopy(ptr %t481, ptr %t479, i64 %t480)
  %t482 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t481, 1
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t486 = extractvalue { i64, ptr } %t483, 1
  %t487 = mul i64 %t485, 1
  %t488 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t487)
  call void @llvm.memcpy.p0.p0.i64(ptr %t488, ptr %t486, i64 %t487, i1 false)
  %t489 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t488, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t490)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s15)
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_a90a878cc09c574e_a9a55cce621e609a)
  unreachable
bb91:
  br label %bb92
bb92:
  %t493 = load i32, ptr %l31, !tbaa !23
  %t495 = add i32 %t493, 1
  store i32 %t495, ptr %l31, !tbaa !23
  br label %bb71
bb93:
  store i32 0, ptr %l35, !tbaa !23
  %t497 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t498 = getelementptr %"compiler/mir:Range", ptr %t497, i32 0, i32 1
  %t499 = load i32, ptr %t498, !tbaa !23
  store i32 %t499, ptr %l36, !tbaa !23
  store i32 1, ptr %l37, !tbaa !23
  %t501 = load i32, ptr %l36, !tbaa !23
  %t502 = load i32, ptr %l35, !tbaa !23
  %t505 = icmp sgt i32 %t501, %t502
  br i1 %t505, label %bb94, label %bb95
bb94:
  %t507 = load i32, ptr %l37, !tbaa !23
  %t509 = icmp sgt i32 %t507, 0
  br i1 %t509, label %bb96, label %bb97
bb95:
  store i32 0, ptr %l274, !tbaa !23
  br label %bb99
bb96:
  %t511 = load i32, ptr %l36, !tbaa !23
  %t512 = load i32, ptr %l35, !tbaa !23
  %t515 = sub i32 %t511, %t512
  %t516 = load i32, ptr %l37, !tbaa !23
  %t519 = add i32 %t515, %t516
  %t521 = sub i32 %t519, 1
  %t522 = load i32, ptr %l37, !tbaa !23
  %t525 = sdiv i32 %t521, %t522
  store i32 %t525, ptr %l277, !tbaa !23
  br label %bb98
bb97:
  store i32 0, ptr %l277, !tbaa !23
  br label %bb98
bb98:
  %t527 = load i32, ptr %l277, !tbaa !23
  store i32 %t527, ptr %l274, !tbaa !23
  br label %bb99
bb99:
  %t528 = load i32, ptr %l274, !tbaa !23
  store i32 %t528, ptr %l38, !tbaa !23
  store i32 0, ptr %l39, !tbaa !23
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s21
  %t529 = load i32, ptr %l39, !tbaa !23
  %t530 = load i32, ptr %l38, !tbaa !23
  %t533 = icmp slt i32 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s21)
  br label %bb109
bb102:
  br label %bb103
bb103:
  %t537 = load i32, ptr %l35, !tbaa !23
  %t538 = load i32, ptr %l39, !tbaa !23
  %t539 = load i32, ptr %l37, !tbaa !23
  %t542 = mul i32 %t538, %t539
  %t545 = add i32 %t537, %t542
  store i32 %t545, ptr %l40, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d374, i32 0, i32 1) })
  br label %bb104
bb104:
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l296, !tbaa !29
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/emit:fnEm", ptr %t549, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t554 = getelementptr %"compiler/mir:Fn", ptr %t552, i32 0, i32 13
  %t555 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t556 = getelementptr %"compiler/mir:Range", ptr %t555, i32 0, i32 0
  %t557 = load i32, ptr %t556, !tbaa !23
  %t559 = sext i32 %t557 to i64
  %t560 = load i32, ptr %l40, !tbaa !23
  %t562 = sext i32 %t560 to i64
  %t565 = add i64 %t559, %t562
  %t568 = call %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t554, i64 %t565)
  store %"compiler/mir:Place" %t568, ptr %l305
  br label %bb105
bb105:
  %t569 = load ptr, ptr %l296, !tbaa !29
  %t570 = load %"compiler/mir:Place", ptr %l305
  %t571 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s21, ptr %t569, %"compiler/mir:Place" %t570)
  store { { i64, ptr }, i32 } %t571, ptr %l306
  br label %bb106
bb106:
  %t572 = load { { i64, ptr }, i32 }, ptr %l306
  store { { i64, ptr }, i32 } %t572, ptr %l41
  %t573 = getelementptr { { i64, ptr }, i32 }, ptr %l41, i32 0, i32 0
  %t574 = load { i64, ptr }, ptr %t573, !tbaa !27
  store { i64, ptr } %t574, ptr %l307, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t575, 0
  store i64 %t576, ptr %l308, !tbaa !24
  %t577 = load i64, ptr %l308, !tbaa !24
  %t578 = mul i64 %t577, 1
  %t579 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t578)
  %t580 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t579, 1
  store { i64, ptr } %t581, ptr %l309, !tbaa !27
  %t582 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = load i64, ptr %l308, !tbaa !24
  %t587 = mul i64 %t586, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t583, ptr %t585, i64 %t587, i1 false)
  %t588 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t591 = extractvalue { i64, ptr } %t588, 1
  %t592 = extractvalue { i64, ptr } %t588, 0
  %t593 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t592)
  call void @olang_textcopy(ptr %t593, ptr %t591, i64 %t592)
  %t594 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t595 = insertvalue { i64, ptr } %t594, ptr %t593, 1
  %t597 = extractvalue { i64, ptr } %t595, 0
  %t598 = extractvalue { i64, ptr } %t595, 1
  %t599 = mul i64 %t597, 1
  %t600 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t599)
  call void @llvm.memcpy.p0.p0.i64(ptr %t600, ptr %t598, i64 %t599, i1 false)
  %t601 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t600, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t602)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s21)
  br label %bb108
bb108:
  %t605 = load i32, ptr %l39, !tbaa !23
  %t607 = add i32 %t605, 1
  store i32 %t607, ptr %l39, !tbaa !23
  br label %bb100
bb109:
  store i32 0, ptr %l43, !tbaa !23
  %t609 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t610 = getelementptr %"compiler/mir:Range", ptr %t609, i32 0, i32 1
  %t611 = load i32, ptr %t610, !tbaa !23
  store i32 %t611, ptr %l44, !tbaa !23
  store i32 1, ptr %l45, !tbaa !23
  %t613 = load i32, ptr %l44, !tbaa !23
  %t614 = load i32, ptr %l43, !tbaa !23
  %t617 = icmp sgt i32 %t613, %t614
  br i1 %t617, label %bb110, label %bb111
bb110:
  %t619 = load i32, ptr %l45, !tbaa !23
  %t621 = icmp sgt i32 %t619, 0
  br i1 %t621, label %bb112, label %bb113
bb111:
  store i32 0, ptr %l320, !tbaa !23
  br label %bb115
bb112:
  %t623 = load i32, ptr %l44, !tbaa !23
  %t624 = load i32, ptr %l43, !tbaa !23
  %t627 = sub i32 %t623, %t624
  %t628 = load i32, ptr %l45, !tbaa !23
  %t631 = add i32 %t627, %t628
  %t633 = sub i32 %t631, 1
  %t634 = load i32, ptr %l45, !tbaa !23
  %t637 = sdiv i32 %t633, %t634
  store i32 %t637, ptr %l323, !tbaa !23
  br label %bb114
bb113:
  store i32 0, ptr %l323, !tbaa !23
  br label %bb114
bb114:
  %t639 = load i32, ptr %l323, !tbaa !23
  store i32 %t639, ptr %l320, !tbaa !23
  br label %bb115
bb115:
  %t640 = load i32, ptr %l320, !tbaa !23
  store i32 %t640, ptr %l46, !tbaa !23
  store i32 0, ptr %l47, !tbaa !23
  br label %bb116
bb116:
  %t641 = load i32, ptr %l47, !tbaa !23
  %t642 = load i32, ptr %l46, !tbaa !23
  %t645 = icmp slt i32 %t641, %t642
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb117, label %bb118
bb117:
  br label %bb129
bb118:
  br label %bb119
bb119:
  %t649 = load i32, ptr %l43, !tbaa !23
  %t650 = load i32, ptr %l47, !tbaa !23
  %t651 = load i32, ptr %l45, !tbaa !23
  %t654 = mul i32 %t650, %t651
  %t657 = add i32 %t649, %t654
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/emit:fnEm", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = getelementptr %"compiler/mir:Fn", ptr %t662, i32 0, i32 17
  %t665 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t666 = getelementptr %"compiler/mir:Range", ptr %t665, i32 0, i32 0
  %t667 = load i32, ptr %t666, !tbaa !23
  %t669 = sext i32 %t667 to i64
  %t672 = sext i32 %t657 to i64
  %t675 = add i64 %t669, %t672
  %t678 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t664, i64 %t675)
  store %"compiler/mir:TaskClause" %t678, ptr %l349
  br label %bb120
bb120:
  %t679 = getelementptr %"compiler/mir:TaskClause", ptr %l349, i32 0, i32 2
  %t680 = load { i64, [4 x i64] }, ptr %t679
  store { i64, [4 x i64] } %t680, ptr %l49
  %t682 = load { i64, [4 x i64] }, ptr %l49
  %t684 = extractvalue { i64, [4 x i64] } %t682, 0
  %t685 = icmp eq i64 %t684, 0
  %t687 = xor i1 %t685, true
  br i1 %t687, label %bb121, label %bb122
bb121:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d375, i32 0, i32 1) })
  br label %bb123
bb122:
  br label %bb127
bb123:
  store ptr %l19, ptr %l355, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l356, !tbaa !29
  %t691 = load { i64, [4 x i64] }, ptr %l49
  store { i64, [4 x i64] } %t691, ptr %l357
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load { i64, [4 x i64] }, ptr %l49
  %t696 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t692, { i64, [4 x i64] } %t693)
  store i32 %t696, ptr %l360
  br label %bb124
bb124:
  %t697 = load ptr, ptr %l356, !tbaa !29
  %t698 = load { i64, [4 x i64] }, ptr %l357
  %t699 = load i32, ptr %l360, !tbaa !23
  %t700 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t697, { i64, [4 x i64] } %t698, i32 %t699)
  store { i64, ptr } %t700, ptr %l361
  br label %bb125
bb125:
  %t701 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 0
  %t703 = extractvalue { i64, ptr } %t701, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  %t708 = load ptr, ptr %l355, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t708, { i64, ptr } %t707)
  br label %bb126
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t710 = load i32, ptr %l47, !tbaa !23
  %t712 = add i32 %t710, 1
  store i32 %t712, ptr %l47, !tbaa !23
  br label %bb116
bb129:
  %t714 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t715 = getelementptr %"compiler/mir:Range", ptr %t714, i32 0, i32 1
  %t716 = load i32, ptr %t715, !tbaa !23
  %t718 = sext i32 %t716 to i64
  store i64 %t718, ptr %l366, !tbaa !24
  %t719 = load i64, ptr %l366, !tbaa !24
  %t720 = icmp sge i64 %t719, 0
  br i1 %t720, label %bb130, label %bb131
bb130:
  %t722 = load i64, ptr %l366, !tbaa !24
  %t723 = icmp sle i64 %t722, 1152921504606846975
  br i1 %t723, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb132:
  %t725 = load i64, ptr %l366, !tbaa !24
  %t726 = mul i64 %t725, 8
  %t727 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t726)
  store i64 0, ptr %t728
  br label %fill.729
fill.729:
  %t732 = load i64, ptr %t728
  %t733 = icmp slt i64 %t732, %t725
  br i1 %t733, label %fillb.730, label %filld.731
fillb.730:
  %t734 = getelementptr i64, ptr %t727, i64 %t732
  store i64 -1, ptr %t734
  %t735 = add i64 %t732, 1
  store i64 %t735, ptr %t728
  br label %fill.729
filld.731:
  %t736 = insertvalue { i64, ptr } undef, i64 %t725, 0
  %t737 = insertvalue { i64, ptr } %t736, ptr %t727, 1
  store { i64, ptr } %t737, ptr %l50, !tbaa !27
  store i32 0, ptr %l51, !tbaa !23
  %t739 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t740 = getelementptr %"compiler/mir:Range", ptr %t739, i32 0, i32 1
  %t741 = load i32, ptr %t740, !tbaa !23
  store i32 %t741, ptr %l52, !tbaa !23
  store i32 1, ptr %l53, !tbaa !23
  %t743 = load i32, ptr %l52, !tbaa !23
  %t744 = load i32, ptr %l51, !tbaa !23
  %t747 = icmp sgt i32 %t743, %t744
  br i1 %t747, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb134:
  %t749 = load i32, ptr %l53, !tbaa !23
  %t751 = icmp sgt i32 %t749, 0
  br i1 %t751, label %bb136, label %bb137
bb135:
  store i32 0, ptr %l374, !tbaa !23
  br label %bb139
bb136:
  %t753 = load i32, ptr %l52, !tbaa !23
  %t754 = load i32, ptr %l51, !tbaa !23
  %t757 = sub i32 %t753, %t754
  %t758 = load i32, ptr %l53, !tbaa !23
  %t761 = add i32 %t757, %t758
  %t763 = sub i32 %t761, 1
  %t764 = load i32, ptr %l53, !tbaa !23
  %t767 = sdiv i32 %t763, %t764
  store i32 %t767, ptr %l377, !tbaa !23
  br label %bb138
bb137:
  store i32 0, ptr %l377, !tbaa !23
  br label %bb138
bb138:
  %t769 = load i32, ptr %l377, !tbaa !23
  store i32 %t769, ptr %l374, !tbaa !23
  br label %bb139
bb139:
  %t770 = load i32, ptr %l374, !tbaa !23
  store i32 %t770, ptr %l54, !tbaa !23
  store i32 0, ptr %l55, !tbaa !23
  br label %bb140
bb140:
  %t771 = load i32, ptr %l55, !tbaa !23
  %t772 = load i32, ptr %l54, !tbaa !23
  %t775 = icmp slt i32 %t771, %t772
  %t777 = xor i1 %t775, true
  br i1 %t777, label %bb141, label %bb142
bb141:
  br label %bb169
bb142:
  br label %bb143
bb143:
  %t779 = load i32, ptr %l51, !tbaa !23
  %t780 = load i32, ptr %l55, !tbaa !23
  %t781 = load i32, ptr %l53, !tbaa !23
  %t784 = mul i32 %t780, %t781
  %t787 = add i32 %t779, %t784
  store i32 %t787, ptr %l56, !tbaa !23
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = getelementptr %"compiler/emit:fnEm", ptr %t789, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t794 = getelementptr %"compiler/mir:Fn", ptr %t792, i32 0, i32 12
  %t795 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t796 = getelementptr %"compiler/mir:Range", ptr %t795, i32 0, i32 0
  %t797 = load i32, ptr %t796, !tbaa !23
  %t799 = sext i32 %t797 to i64
  %t800 = load i32, ptr %l56, !tbaa !23
  %t802 = sext i32 %t800 to i64
  %t805 = add i64 %t799, %t802
  %t808 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t794, i64 %t805)
  store { i64, [1 x i64] } %t808, ptr %l403
  br label %bb144
bb144:
  %t809 = load { i64, [1 x i64] }, ptr %l403
  store { i64, [1 x i64] } %t809, ptr %l57
  %t810 = load { i64, [1 x i64] }, ptr %l57
  %t812 = extractvalue { i64, [1 x i64] } %t810, 0
  %t813 = icmp eq i64 %t812, 3
  br i1 %t813, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb167
bb148:
  %t815 = load { i64, [1 x i64] }, ptr %l57
  %t817 = extractvalue { i64, [1 x i64] } %t815, 0
  %t818 = icmp eq i64 %t817, 2
  br i1 %t818, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb155
bb151:
  %t820 = load i32, ptr %l56, !tbaa !23
  store i32 %t820, ptr %l408, !tbaa !23
  %t822 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t822, ptr %l410
  br label %bb152
bb152:
  %t823 = load i64, ptr %l410, !tbaa !24
  %t824 = load i32, ptr %l408, !tbaa !23
  %t825 = sext i32 %t824 to i64
  %t826 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t827 = load ptr, ptr %t826, !tbaa !27
  %t828 = getelementptr i64, ptr %t827, i64 %t825
  store i64 %t823, ptr %t828, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d376, i32 0, i32 1) })
  br label %bb153
bb153:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d377, i32 0, i32 1) })
  br label %bb154
bb154:
  br label %bb167
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb166
bb158:
  store %olang.scope zeroinitializer, ptr %s32
  %t831 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s32, ptr %s32, ptr %t831, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d378, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d379, i32 0, i32 1) })
  br label %bb159
bb159:
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l414, !tbaa !29
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load { i64, [1 x i64] }, ptr %l57
  %t838 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s32, ptr %t834, { i64, [1 x i64] } %t835)
  store { i64, ptr } %t838, ptr %l417
  br label %bb160
bb160:
  %t839 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t840 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t841 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t842 = extractvalue { i64, ptr } %t841, 1
  %t843 = extractvalue { i64, ptr } %t841, 0
  %t844 = add i64 %t840, %t843
  %t845 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t846 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t847 = add i64 %t844, %t846
  %t848 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t847)
  call void @olang_textcopy(ptr %t848, ptr %t839, i64 %t840)
  %t849 = getelementptr i8, ptr %t848, i64 %t840
  call void @olang_textcopy(ptr %t849, ptr %t842, i64 %t843)
  %t850 = getelementptr i8, ptr %t849, i64 %t843
  call void @olang_textcopy(ptr %t850, ptr %t845, i64 %t846)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t848, 1
  %t854 = extractvalue { i64, ptr } %t852, 0
  %t855 = extractvalue { i64, ptr } %t852, 1
  %t856 = mul i64 %t854, 1
  %t857 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t856)
  call void @llvm.memcpy.p0.p0.i64(ptr %t857, ptr %t855, i64 %t856, i1 false)
  %t858 = insertvalue { i64, ptr } undef, i64 %t854, 0
  %t859 = insertvalue { i64, ptr } %t858, ptr %t857, 1
  %t860 = load ptr, ptr %l414, !tbaa !29
  %t862 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t860, { i64, ptr } %t859)
  store { i64, ptr } %t862, ptr %l420
  br label %bb161
bb161:
  %t863 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t863, ptr %l58, !tbaa !27
  %t864 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t866 = extractvalue { i64, ptr } %t864, 1
  %t867 = extractvalue { i64, ptr } %t864, 0
  %t868 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t867)
  call void @olang_textcopy(ptr %t868, ptr %t866, i64 %t867)
  %t869 = insertvalue { i64, ptr } undef, i64 %t867, 0
  %t870 = insertvalue { i64, ptr } %t869, ptr %t868, 1
  %t872 = extractvalue { i64, ptr } %t870, 0
  %t873 = extractvalue { i64, ptr } %t870, 1
  %t874 = mul i64 %t872, 1
  %t875 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t874)
  call void @llvm.memcpy.p0.p0.i64(ptr %t875, ptr %t873, i64 %t874, i1 false)
  %t876 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t875, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } %t877)
  br label %bb162
bb162:
  %t880 = load i32, ptr %l56, !tbaa !23
  store i32 %t880, ptr %l425, !tbaa !23
  %t882 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t882, ptr %l427
  br label %bb163
bb163:
  %t883 = load i64, ptr %l427, !tbaa !24
  %t884 = load i32, ptr %l425, !tbaa !23
  %t885 = sext i32 %t884 to i64
  %t886 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t887 = load ptr, ptr %t886, !tbaa !27
  %t888 = getelementptr i64, ptr %t887, i64 %t885
  store i64 %t883, ptr %t888, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d382, i32 0, i32 1) })
  br label %bb164
bb164:
  %t890 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t890, 1
  %t893 = extractvalue { i64, ptr } %t890, 0
  %t894 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t893)
  call void @olang_textcopy(ptr %t894, ptr %t892, i64 %t893)
  %t895 = insertvalue { i64, ptr } undef, i64 %t893, 0
  %t896 = insertvalue { i64, ptr } %t895, ptr %t894, 1
  %t898 = extractvalue { i64, ptr } %t896, 0
  %t899 = extractvalue { i64, ptr } %t896, 1
  %t900 = mul i64 %t898, 1
  %t901 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t900)
  call void @llvm.memcpy.p0.p0.i64(ptr %t901, ptr %t899, i64 %t900, i1 false)
  %t902 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t903 = insertvalue { i64, ptr } %t902, ptr %t901, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t903)
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s32)
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_45f21d64bb841654_8b47099e9550bca0)
  unreachable
bb167:
  br label %bb168
bb168:
  %t906 = load i32, ptr %l55, !tbaa !23
  %t908 = add i32 %t906, 1
  store i32 %t908, ptr %l55, !tbaa !23
  br label %bb140
bb169:
  %t910 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t910, ptr %l435
  br label %bb170
bb170:
  %t911 = load %"std/prelude/text:StringBuilder", ptr %l435
  store %"std/prelude/text:StringBuilder" %t911, ptr %l59
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d383, i32 0, i32 1) })
  br label %bb171
bb171:
  store i64 0, ptr %l60, !tbaa !24
  %t914 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t914, ptr %l438
  br label %bb172
bb172:
  %t915 = load i64, ptr %l438, !tbaa !24
  store i64 %t915, ptr %l61, !tbaa !24
  store i64 1, ptr %l62, !tbaa !24
  %t916 = load i64, ptr %l61, !tbaa !24
  %t917 = load i64, ptr %l60, !tbaa !24
  %t920 = icmp sgt i64 %t916, %t917
  br i1 %t920, label %bb173, label %bb174
bb173:
  %t922 = load i64, ptr %l62, !tbaa !24
  %t924 = icmp sgt i64 %t922, 0
  br i1 %t924, label %bb175, label %bb176
bb174:
  store i64 0, ptr %l442, !tbaa !24
  br label %bb178
bb175:
  %t926 = load i64, ptr %l61, !tbaa !24
  %t927 = load i64, ptr %l60, !tbaa !24
  %t930 = sub i64 %t926, %t927
  %t931 = load i64, ptr %l62, !tbaa !24
  %t934 = add i64 %t930, %t931
  %t936 = sub i64 %t934, 1
  %t937 = load i64, ptr %l62, !tbaa !24
  %t940 = sdiv i64 %t936, %t937
  store i64 %t940, ptr %l445, !tbaa !24
  br label %bb177
bb176:
  store i64 0, ptr %l445, !tbaa !24
  br label %bb177
bb177:
  %t942 = load i64, ptr %l445, !tbaa !24
  store i64 %t942, ptr %l442, !tbaa !24
  br label %bb178
bb178:
  %t943 = load i64, ptr %l442, !tbaa !24
  store i64 %t943, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb179
bb179:
  %t944 = load i64, ptr %l64, !tbaa !24
  %t945 = load i64, ptr %l63, !tbaa !24
  %t948 = icmp slt i64 %t944, %t945
  %t950 = xor i1 %t948, true
  br i1 %t950, label %bb180, label %bb181
bb180:
  br label %bb190
bb181:
  br label %bb182
bb182:
  %t952 = load i64, ptr %l60, !tbaa !24
  %t953 = load i64, ptr %l64, !tbaa !24
  %t954 = load i64, ptr %l62, !tbaa !24
  %t957 = mul i64 %t953, %t954
  %t960 = add i64 %t952, %t957
  store i64 %t960, ptr %l65, !tbaa !24
  %t962 = load i64, ptr %l65, !tbaa !24
  %t964 = icmp sgt i64 %t962, 0
  br i1 %t964, label %bb183, label %bb184
bb183:
  store %olang.scope zeroinitializer, ptr %s39
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %l59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d384, i32 0, i32 1) })
  br label %bb185
bb184:
  br label %bb186
bb185:
  call void @__olang_scope_close(ptr %s39)
  br label %bb186
bb186:
  store ptr %l59, ptr %l466, !tbaa !29
  %t967 = load i64, ptr %l65, !tbaa !24
  %t970 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l18, i64 %t967)
  store { i64, ptr } %t970, ptr %l469
  br label %bb187
bb187:
  %t971 = load ptr, ptr %l466, !tbaa !29
  %t972 = load { i64, ptr }, ptr %l469, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t971, { i64, ptr } %t972)
  br label %bb188
bb188:
  br label %bb189
bb189:
  %t973 = load i64, ptr %l64, !tbaa !24
  %t975 = add i64 %t973, 1
  store i64 %t975, ptr %l64, !tbaa !24
  br label %bb179
bb190:
  %t978 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t978, ptr %l473
  br label %bb191
bb191:
  %t979 = load i64, ptr %l473, !tbaa !24
  %t980 = icmp eq i64 %t979, 0
  br i1 %t980, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s41
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %l59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d385, i32 0, i32 1) })
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s41)
  br label %bb195
bb195:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) })
  br label %bb196
bb196:
  %t985 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l59)
  store { i64, ptr } %t985, ptr %l478
  br label %bb197
bb197:
  %t986 = load { i64, ptr }, ptr %l478, !tbaa !27
  store { i64, ptr } %t986, ptr %l66, !tbaa !27
  %t987 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t987, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d387, i32 0, i32 1) })
  br label %bb198
bb198:
  %t989 = load ptr, ptr %l0, !tbaa !29
  store ptr %t989, ptr %l480, !tbaa !29
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t992 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t993 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t995 = extractvalue { i64, ptr } %t991, 1
  %t996 = extractvalue { i64, ptr } %t991, 0
  %t997 = add i64 %t993, %t996
  %t998 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t999 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t1000 = add i64 %t997, %t999
  %t1001 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1000)
  call void @olang_textcopy(ptr %t1001, ptr %t992, i64 %t993)
  %t1002 = getelementptr i8, ptr %t1001, i64 %t993
  call void @olang_textcopy(ptr %t1002, ptr %t995, i64 %t996)
  %t1003 = getelementptr i8, ptr %t1002, i64 %t996
  call void @olang_textcopy(ptr %t1003, ptr %t998, i64 %t999)
  %t1004 = insertvalue { i64, ptr } undef, i64 %t1000, 0
  %t1005 = insertvalue { i64, ptr } %t1004, ptr %t1001, 1
  %t1007 = extractvalue { i64, ptr } %t1005, 0
  %t1008 = extractvalue { i64, ptr } %t1005, 1
  %t1009 = mul i64 %t1007, 1
  %t1010 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1009)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1010, ptr %t1008, i64 %t1009, i1 false)
  %t1011 = insertvalue { i64, ptr } undef, i64 %t1007, 0
  %t1012 = insertvalue { i64, ptr } %t1011, ptr %t1010, 1
  %t1015 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t990, { i64, ptr } %t1012)
  store { i64, ptr } %t1015, ptr %l485
  br label %bb199
bb199:
  %t1016 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t1017 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t1018 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t1019 = extractvalue { i64, ptr } %t1018, 1
  %t1020 = extractvalue { i64, ptr } %t1018, 0
  %t1021 = add i64 %t1017, %t1020
  %t1022 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t1023 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t1024 = add i64 %t1021, %t1023
  %t1025 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1024)
  call void @olang_textcopy(ptr %t1025, ptr %t1016, i64 %t1017)
  %t1026 = getelementptr i8, ptr %t1025, i64 %t1017
  call void @olang_textcopy(ptr %t1026, ptr %t1019, i64 %t1020)
  %t1027 = getelementptr i8, ptr %t1026, i64 %t1020
  call void @olang_textcopy(ptr %t1027, ptr %t1022, i64 %t1023)
  %t1028 = insertvalue { i64, ptr } undef, i64 %t1024, 0
  %t1029 = insertvalue { i64, ptr } %t1028, ptr %t1025, 1
  %t1031 = extractvalue { i64, ptr } %t1029, 0
  %t1032 = extractvalue { i64, ptr } %t1029, 1
  %t1033 = mul i64 %t1031, 1
  %t1034 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1033)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1034, ptr %t1032, i64 %t1033, i1 false)
  %t1035 = insertvalue { i64, ptr } undef, i64 %t1031, 0
  %t1036 = insertvalue { i64, ptr } %t1035, ptr %t1034, 1
  %t1037 = load ptr, ptr %l480, !tbaa !29
  %t1039 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1037, { i64, ptr } %t1036)
  store { i64, ptr } %t1039, ptr %l488
  br label %bb200
bb200:
  %t1040 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t1041 = load ptr, ptr %l0, !tbaa !29
  %t1042 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1044 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t1045 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t1047 = extractvalue { i64, ptr } %t1042, 1
  %t1048 = extractvalue { i64, ptr } %t1042, 0
  %t1049 = add i64 %t1045, %t1048
  %t1050 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t1051 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t1052 = add i64 %t1049, %t1051
  %t1054 = extractvalue { i64, ptr } %t1040, 1
  %t1055 = extractvalue { i64, ptr } %t1040, 0
  %t1056 = add i64 %t1052, %t1055
  %t1057 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t1058 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t1059 = add i64 %t1056, %t1058
  %t1060 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1059)
  call void @olang_textcopy(ptr %t1060, ptr %t1044, i64 %t1045)
  %t1061 = getelementptr i8, ptr %t1060, i64 %t1045
  call void @olang_textcopy(ptr %t1061, ptr %t1047, i64 %t1048)
  %t1062 = getelementptr i8, ptr %t1061, i64 %t1048
  call void @olang_textcopy(ptr %t1062, ptr %t1050, i64 %t1051)
  %t1063 = getelementptr i8, ptr %t1062, i64 %t1051
  call void @olang_textcopy(ptr %t1063, ptr %t1054, i64 %t1055)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1055
  call void @olang_textcopy(ptr %t1064, ptr %t1057, i64 %t1058)
  %t1065 = insertvalue { i64, ptr } undef, i64 %t1059, 0
  %t1066 = insertvalue { i64, ptr } %t1065, ptr %t1060, 1
  %t1068 = extractvalue { i64, ptr } %t1066, 0
  %t1069 = extractvalue { i64, ptr } %t1066, 1
  %t1070 = mul i64 %t1068, 1
  %t1071 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1070)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1071, ptr %t1069, i64 %t1070, i1 false)
  %t1072 = insertvalue { i64, ptr } undef, i64 %t1068, 0
  %t1073 = insertvalue { i64, ptr } %t1072, ptr %t1071, 1
  %t1076 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1041, { i64, ptr } %t1073)
  store { i64, ptr } %t1076, ptr %l494
  br label %bb201
bb201:
  %t1077 = load { i64, ptr }, ptr %l494, !tbaa !27
  store { i64, ptr } %t1077, ptr %l68, !tbaa !27
  %t1078 = load i1, ptr %l8, !tbaa !21
  br i1 %t1078, label %bb202, label %bb203
bb202:
  store i64 1, ptr %l496, !tbaa !24
  br label %bb204
bb203:
  store i64 0, ptr %l496, !tbaa !24
  br label %bb204
bb204:
  %t1080 = load i64, ptr %l496, !tbaa !24
  store i64 %t1080, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  %t1082 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l18)
  store i64 %t1082, ptr %l498
  br label %bb205
bb205:
  %t1083 = load i64, ptr %l498, !tbaa !24
  store i64 %t1083, ptr %l71, !tbaa !24
  store i64 1, ptr %l72, !tbaa !24
  %t1084 = load i64, ptr %l71, !tbaa !24
  %t1085 = load i64, ptr %l70, !tbaa !24
  %t1088 = icmp sgt i64 %t1084, %t1085
  br i1 %t1088, label %bb206, label %bb207
bb206:
  %t1090 = load i64, ptr %l72, !tbaa !24
  %t1092 = icmp sgt i64 %t1090, 0
  br i1 %t1092, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l502, !tbaa !24
  br label %bb211
bb208:
  %t1094 = load i64, ptr %l71, !tbaa !24
  %t1095 = load i64, ptr %l70, !tbaa !24
  %t1098 = sub i64 %t1094, %t1095
  %t1099 = load i64, ptr %l72, !tbaa !24
  %t1102 = add i64 %t1098, %t1099
  %t1104 = sub i64 %t1102, 1
  %t1105 = load i64, ptr %l72, !tbaa !24
  %t1108 = sdiv i64 %t1104, %t1105
  store i64 %t1108, ptr %l505, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l505, !tbaa !24
  br label %bb210
bb210:
  %t1110 = load i64, ptr %l505, !tbaa !24
  store i64 %t1110, ptr %l502, !tbaa !24
  br label %bb211
bb211:
  %t1111 = load i64, ptr %l502, !tbaa !24
  store i64 %t1111, ptr %l73, !tbaa !24
  store i64 0, ptr %l74, !tbaa !24
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s46
  %t1112 = load i64, ptr %l74, !tbaa !24
  %t1113 = load i64, ptr %l73, !tbaa !24
  %t1116 = icmp slt i64 %t1112, %t1113
  %t1118 = xor i1 %t1116, true
  br i1 %t1118, label %bb213, label %bb214
bb213:
  call void @__olang_scope_close(ptr %s46)
  br label %bb228
bb214:
  br label %bb215
bb215:
  %t1120 = load i64, ptr %l70, !tbaa !24
  %t1121 = load i64, ptr %l74, !tbaa !24
  %t1122 = load i64, ptr %l72, !tbaa !24
  %t1125 = mul i64 %t1121, %t1122
  %t1128 = add i64 %t1120, %t1125
  store i64 %t1128, ptr %l75, !tbaa !24
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1131 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1132 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1133 = load i64, ptr %l75, !tbaa !24
  %t1134 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t1135 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t1137 = extractvalue { i64, ptr } %t1131, 1
  %t1138 = extractvalue { i64, ptr } %t1131, 0
  %t1139 = add i64 %t1135, %t1138
  %t1140 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t1141 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t1142 = add i64 %t1139, %t1141
  %t1144 = extractvalue { i64, ptr } %t1132, 1
  %t1145 = extractvalue { i64, ptr } %t1132, 0
  %t1146 = add i64 %t1142, %t1145
  %t1147 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t1148 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t1149 = add i64 %t1146, %t1148
  %t1151 = call i64 @__olang_fmt_i64(ptr null, i64 %t1133)
  %t1152 = add i64 %t1149, %t1151
  %t1153 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1152)
  call void @olang_textcopy(ptr %t1153, ptr %t1134, i64 %t1135)
  %t1154 = getelementptr i8, ptr %t1153, i64 %t1135
  call void @olang_textcopy(ptr %t1154, ptr %t1137, i64 %t1138)
  %t1155 = getelementptr i8, ptr %t1154, i64 %t1138
  call void @olang_textcopy(ptr %t1155, ptr %t1140, i64 %t1141)
  %t1156 = getelementptr i8, ptr %t1155, i64 %t1141
  call void @olang_textcopy(ptr %t1156, ptr %t1144, i64 %t1145)
  %t1157 = getelementptr i8, ptr %t1156, i64 %t1145
  call void @olang_textcopy(ptr %t1157, ptr %t1147, i64 %t1148)
  %t1158 = getelementptr i8, ptr %t1157, i64 %t1148
  %t1159 = call i64 @__olang_fmt_i64(ptr %t1158, i64 %t1133)
  %t1160 = insertvalue { i64, ptr } undef, i64 %t1152, 0
  %t1161 = insertvalue { i64, ptr } %t1160, ptr %t1153, 1
  %t1163 = extractvalue { i64, ptr } %t1161, 0
  %t1164 = extractvalue { i64, ptr } %t1161, 1
  %t1165 = mul i64 %t1163, 1
  %t1166 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1166, ptr %t1164, i64 %t1165, i1 false)
  %t1167 = insertvalue { i64, ptr } undef, i64 %t1163, 0
  %t1168 = insertvalue { i64, ptr } %t1167, ptr %t1166, 1
  %t1171 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s46, ptr %s46, ptr %t1130, { i64, ptr } %t1168)
  store { i64, ptr } %t1171, ptr %l529
  br label %bb216
bb216:
  %t1172 = load { i64, ptr }, ptr %l529, !tbaa !27
  store { i64, ptr } %t1172, ptr %l76, !tbaa !27
  %t1173 = load i64, ptr %l75, !tbaa !24
  %t1176 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l19, i64 %t1173)
  store { i64, ptr } %t1176, ptr %l532
  br label %bb217
bb217:
  %t1177 = load { i64, ptr }, ptr %l532, !tbaa !27
  %t1178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s46, { i64, ptr } %t1177, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d398, i32 0, i32 1) })
  store i1 %t1178, ptr %l533
  br label %bb218
bb218:
  %t1179 = load i1, ptr %l533, !tbaa !21
  br i1 %t1179, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s48
  %t1180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1180, ptr %l534, !tbaa !29
  %t1181 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t1181, ptr %l535, !tbaa !27
  %t1182 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t1182, ptr %l536, !tbaa !27
  %t1183 = load i64, ptr %l75, !tbaa !24
  %t1184 = load i64, ptr %l69, !tbaa !24
  %t1187 = sub i64 %t1183, %t1184
  %t1189 = getelementptr { i64, ptr }, ptr %l536, i32 0, i32 1
  %t1190 = load ptr, ptr %t1189, !tbaa !27
  %t1191 = getelementptr i32, ptr %t1190, i64 %t1187
  %t1192 = load i32, ptr %t1191, !tbaa !33
  store i32 %t1192, ptr %l540, !tbaa !23
  %t1193 = load ptr, ptr %l0, !tbaa !29
  %t1194 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t1195 = load %"compiler/mir:Range", ptr %t1194
  %t1196 = load i64, ptr %l75, !tbaa !24
  %t1197 = load i64, ptr %l69, !tbaa !24
  %t1200 = sub i64 %t1196, %t1197
  %t1204 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1193, %"compiler/mir:Range" %t1195, i64 %t1200)
  store { i64, [4 x i64] } %t1204, ptr %l546
  br label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s49
  %t1205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1205, ptr %l547, !tbaa !29
  %t1206 = load i64, ptr %l75, !tbaa !24
  %t1209 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l18, i64 %t1206)
  store { i64, ptr } %t1209, ptr %l550
  br label %bb223
bb221:
  %t1210 = load ptr, ptr %l534, !tbaa !29
  %t1211 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1212 = load i32, ptr %l540, !tbaa !23
  %t1213 = load { i64, [4 x i64] }, ptr %l546
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s46, ptr %s48, ptr %t1210, { i64, ptr } %t1211, i32 %t1212, { i64, [4 x i64] } %t1213, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s48)
  br label %bb226
bb223:
  %t1214 = load i64, ptr %l75, !tbaa !24
  %t1217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l19, i64 %t1214)
  store { i64, ptr } %t1217, ptr %l553
  br label %bb224
bb224:
  %t1218 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t1219 = load ptr, ptr %l547, !tbaa !29
  %t1220 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1221 = load { i64, ptr }, ptr %l553, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s46, ptr %s49, ptr %t1219, { i64, ptr } %t1220, { i64, ptr } %t1221, { i64, ptr } %t1218, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s49)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s46)
  br label %bb227
bb227:
  %t1223 = load i64, ptr %l74, !tbaa !24
  %t1225 = add i64 %t1223, 1
  store i64 %t1225, ptr %l74, !tbaa !24
  br label %bb212
bb228:
  %t1227 = load ptr, ptr %l0, !tbaa !29
  %t1228 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1229 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t1230 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t1232 = extractvalue { i64, ptr } %t1228, 1
  %t1233 = extractvalue { i64, ptr } %t1228, 0
  %t1234 = add i64 %t1230, %t1233
  %t1235 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t1236 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t1237 = add i64 %t1234, %t1236
  %t1238 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1237)
  call void @olang_textcopy(ptr %t1238, ptr %t1229, i64 %t1230)
  %t1239 = getelementptr i8, ptr %t1238, i64 %t1230
  call void @olang_textcopy(ptr %t1239, ptr %t1232, i64 %t1233)
  %t1240 = getelementptr i8, ptr %t1239, i64 %t1233
  call void @olang_textcopy(ptr %t1240, ptr %t1235, i64 %t1236)
  %t1241 = insertvalue { i64, ptr } undef, i64 %t1237, 0
  %t1242 = insertvalue { i64, ptr } %t1241, ptr %t1238, 1
  %t1244 = extractvalue { i64, ptr } %t1242, 0
  %t1245 = extractvalue { i64, ptr } %t1242, 1
  %t1246 = mul i64 %t1244, 1
  %t1247 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1247, ptr %t1245, i64 %t1246, i1 false)
  %t1248 = insertvalue { i64, ptr } undef, i64 %t1244, 0
  %t1249 = insertvalue { i64, ptr } %t1248, ptr %t1247, 1
  %t1252 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1227, { i64, ptr } %t1249)
  store { i64, ptr } %t1252, ptr %l561
  br label %bb229
bb229:
  %t1253 = load { i64, ptr }, ptr %l561, !tbaa !27
  store { i64, ptr } %t1253, ptr %l77, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, ptr %l562, !tbaa !27
  %t1254 = load { i64, ptr }, ptr %l562, !tbaa !27
  store { i64, ptr } %t1254, ptr %l563, !tbaa !27
  %t1255 = load { i64, ptr }, ptr %l563, !tbaa !27
  %t1256 = extractvalue { i64, ptr } %t1255, 0
  store i64 %t1256, ptr %l564, !tbaa !24
  %t1257 = load i64, ptr %l564, !tbaa !24
  %t1258 = mul i64 %t1257, 1
  %t1259 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1258)
  %t1260 = insertvalue { i64, ptr } undef, i64 %t1257, 0
  %t1261 = insertvalue { i64, ptr } %t1260, ptr %t1259, 1
  store { i64, ptr } %t1261, ptr %l565, !tbaa !27
  %t1262 = getelementptr { i64, ptr }, ptr %l565, i32 0, i32 1
  %t1263 = load ptr, ptr %t1262, !tbaa !27
  %t1264 = getelementptr { i64, ptr }, ptr %l563, i32 0, i32 1
  %t1265 = load ptr, ptr %t1264, !tbaa !27
  %t1266 = load i64, ptr %l564, !tbaa !24
  %t1267 = mul i64 %t1266, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1263, ptr %t1265, i64 %t1267, i1 false)
  %t1268 = load { i64, ptr }, ptr %l565, !tbaa !27
  store { i64, ptr } %t1268, ptr %l78, !tbaa !27
  store ptr %l26, ptr %l79, !tbaa !29
  store i64 0, ptr %l80, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s53
  %t1270 = load i64, ptr %l80, !tbaa !24
  store i64 %t1270, ptr %l567, !tbaa !24
  %t1271 = load ptr, ptr %l79, !tbaa !29
  %t1273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t1271)
  store i64 %t1273, ptr %l569
  br label %bb231
bb231:
  %t1274 = load i64, ptr %l567, !tbaa !24
  %t1275 = load i64, ptr %l569, !tbaa !24
  %t1276 = icmp slt i64 %t1274, %t1275
  %t1278 = xor i1 %t1276, true
  br i1 %t1278, label %bb232, label %bb233
bb232:
  call void @__olang_scope_close(ptr %s53)
  br label %bb244
bb233:
  br label %bb234
bb234:
  %t1280 = load ptr, ptr %l79, !tbaa !29
  %t1281 = load i64, ptr %l80, !tbaa !24
  %t1284 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t1280, i64 %t1281)
  store { i64, ptr } %t1284, ptr %l574
  br label %bb235
bb235:
  %t1285 = load { i64, ptr }, ptr %l574, !tbaa !27
  store { i64, ptr } %t1285, ptr %l81, !tbaa !27
  %t1286 = load ptr, ptr %l0, !tbaa !29
  %t1287 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1288 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t1289 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t1291 = extractvalue { i64, ptr } %t1287, 1
  %t1292 = extractvalue { i64, ptr } %t1287, 0
  %t1293 = add i64 %t1289, %t1292
  %t1294 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t1295 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t1296 = add i64 %t1293, %t1295
  %t1297 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1296)
  call void @olang_textcopy(ptr %t1297, ptr %t1288, i64 %t1289)
  %t1298 = getelementptr i8, ptr %t1297, i64 %t1289
  call void @olang_textcopy(ptr %t1298, ptr %t1291, i64 %t1292)
  %t1299 = getelementptr i8, ptr %t1298, i64 %t1292
  call void @olang_textcopy(ptr %t1299, ptr %t1294, i64 %t1295)
  %t1300 = insertvalue { i64, ptr } undef, i64 %t1296, 0
  %t1301 = insertvalue { i64, ptr } %t1300, ptr %t1297, 1
  %t1303 = extractvalue { i64, ptr } %t1301, 0
  %t1304 = extractvalue { i64, ptr } %t1301, 1
  %t1305 = mul i64 %t1303, 1
  %t1306 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1306, ptr %t1304, i64 %t1305, i1 false)
  %t1307 = insertvalue { i64, ptr } undef, i64 %t1303, 0
  %t1308 = insertvalue { i64, ptr } %t1307, ptr %t1306, 1
  %t1311 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s53, ptr %s53, ptr %t1286, { i64, ptr } %t1308)
  store { i64, ptr } %t1311, ptr %l579
  br label %bb236
bb236:
  %t1312 = load { i64, ptr }, ptr %l579, !tbaa !27
  store { i64, ptr } %t1312, ptr %l82, !tbaa !27
  %t1313 = load ptr, ptr %l0, !tbaa !29
  %t1314 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1315 = load { i64, ptr }, ptr %l82, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s53, ptr %s0, ptr %s53, ptr %s53, ptr %t1313, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d404, i32 0, i32 1) }, { i64, ptr } %t1314, { i64, ptr } %t1315, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb237
bb237:
  %t1319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1319, ptr %l583, !tbaa !29
  %t1320 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t1320, ptr %l584, !tbaa !27
  %t1321 = load ptr, ptr %l0, !tbaa !29
  %t1322 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t1323 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t1324 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t1326 = extractvalue { i64, ptr } %t1322, 1
  %t1327 = extractvalue { i64, ptr } %t1322, 0
  %t1328 = add i64 %t1324, %t1327
  %t1329 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t1330 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t1331 = add i64 %t1328, %t1330
  %t1332 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1331)
  call void @olang_textcopy(ptr %t1332, ptr %t1323, i64 %t1324)
  %t1333 = getelementptr i8, ptr %t1332, i64 %t1324
  call void @olang_textcopy(ptr %t1333, ptr %t1326, i64 %t1327)
  %t1334 = getelementptr i8, ptr %t1333, i64 %t1327
  call void @olang_textcopy(ptr %t1334, ptr %t1329, i64 %t1330)
  %t1335 = insertvalue { i64, ptr } undef, i64 %t1331, 0
  %t1336 = insertvalue { i64, ptr } %t1335, ptr %t1332, 1
  %t1338 = extractvalue { i64, ptr } %t1336, 0
  %t1339 = extractvalue { i64, ptr } %t1336, 1
  %t1340 = mul i64 %t1338, 1
  %t1341 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1341, ptr %t1339, i64 %t1340, i1 false)
  %t1342 = insertvalue { i64, ptr } undef, i64 %t1338, 0
  %t1343 = insertvalue { i64, ptr } %t1342, ptr %t1341, 1
  %t1346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s53, ptr %s53, ptr %t1321, { i64, ptr } %t1343)
  store { i64, ptr } %t1346, ptr %l589
  br label %bb238
bb238:
  %t1347 = load { i64, ptr }, ptr %l589, !tbaa !27
  %t1348 = extractvalue { i64, ptr } %t1347, 0
  %t1349 = extractvalue { i64, ptr } %t1347, 1
  %t1350 = mul i64 %t1348, 1
  %t1351 = call ptr @__olang_scope_alloc(ptr %s53, i64 %t1350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1351, ptr %t1349, i64 %t1350, i1 false)
  %t1352 = insertvalue { i64, ptr } undef, i64 %t1348, 0
  %t1353 = insertvalue { i64, ptr } %t1352, ptr %t1351, 1
  %t1354 = load ptr, ptr %l583, !tbaa !29
  %t1355 = load { i64, ptr }, ptr %l584, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s53, ptr %s0, ptr %s53, ptr %s53, ptr %t1354, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d407, i32 0, i32 1) }, { i64, ptr } %t1355, { i64, ptr } %t1353, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb239
bb239:
  %t1357 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t1357, ptr %l591, !tbaa !27
  %t1358 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1359 = extractvalue { i64, ptr } %t1358, 0
  %t1360 = load { i64, ptr }, ptr %l591, !tbaa !27
  %t1361 = extractvalue { i64, ptr } %t1360, 0
  store i64 %t1361, ptr %l593, !tbaa !24
  %t1363 = load i64, ptr %l593, !tbaa !24
  %t1364 = icmp eq i64 %t1359, %t1363
  br i1 %t1364, label %bb240, label %bb241
bb240:
  %t1366 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t1367 = load ptr, ptr %t1366, !tbaa !27
  %t1368 = getelementptr { i64, ptr }, ptr %l591, i32 0, i32 1
  %t1369 = load ptr, ptr %t1368, !tbaa !27
  %t1370 = load i64, ptr %l593, !tbaa !24
  %t1371 = mul i64 %t1370, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1367, ptr %t1369, i64 %t1371, i1 false)
  br label %bb242
bb241:
  %t1372 = load { i64, ptr }, ptr %l591, !tbaa !27
  %t1373 = extractvalue { i64, ptr } %t1372, 0
  store i64 %t1373, ptr %l595, !tbaa !24
  %t1374 = load i64, ptr %l595, !tbaa !24
  %t1375 = mul i64 %t1374, 1
  %t1376 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1375)
  %t1377 = insertvalue { i64, ptr } undef, i64 %t1374, 0
  %t1378 = insertvalue { i64, ptr } %t1377, ptr %t1376, 1
  store { i64, ptr } %t1378, ptr %l596, !tbaa !27
  %t1379 = getelementptr { i64, ptr }, ptr %l596, i32 0, i32 1
  %t1380 = load ptr, ptr %t1379, !tbaa !27
  %t1381 = getelementptr { i64, ptr }, ptr %l591, i32 0, i32 1
  %t1382 = load ptr, ptr %t1381, !tbaa !27
  %t1383 = load i64, ptr %l595, !tbaa !24
  %t1384 = mul i64 %t1383, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1380, ptr %t1382, i64 %t1384, i1 false)
  %t1385 = load { i64, ptr }, ptr %l596, !tbaa !27
  store { i64, ptr } %t1385, ptr %l78, !tbaa !27
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s53)
  br label %bb243
bb243:
  %t1386 = load i64, ptr %l80, !tbaa !24
  %t1388 = add i64 %t1386, 1
  store i64 %t1388, ptr %l80, !tbaa !24
  br label %bb230
bb244:
  %t1390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1390, ptr %l599, !tbaa !29
  %t1391 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t1391, ptr %l600, !tbaa !27
  %t1392 = load ptr, ptr %l0, !tbaa !29
  %t1393 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1394 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t1395 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t1397 = extractvalue { i64, ptr } %t1393, 1
  %t1398 = extractvalue { i64, ptr } %t1393, 0
  %t1399 = add i64 %t1395, %t1398
  %t1400 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t1401 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t1402 = add i64 %t1399, %t1401
  %t1403 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1402)
  call void @olang_textcopy(ptr %t1403, ptr %t1394, i64 %t1395)
  %t1404 = getelementptr i8, ptr %t1403, i64 %t1395
  call void @olang_textcopy(ptr %t1404, ptr %t1397, i64 %t1398)
  %t1405 = getelementptr i8, ptr %t1404, i64 %t1398
  call void @olang_textcopy(ptr %t1405, ptr %t1400, i64 %t1401)
  %t1406 = insertvalue { i64, ptr } undef, i64 %t1402, 0
  %t1407 = insertvalue { i64, ptr } %t1406, ptr %t1403, 1
  %t1409 = extractvalue { i64, ptr } %t1407, 0
  %t1410 = extractvalue { i64, ptr } %t1407, 1
  %t1411 = mul i64 %t1409, 1
  %t1412 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1411)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1412, ptr %t1410, i64 %t1411, i1 false)
  %t1413 = insertvalue { i64, ptr } undef, i64 %t1409, 0
  %t1414 = insertvalue { i64, ptr } %t1413, ptr %t1412, 1
  %t1417 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1392, { i64, ptr } %t1414)
  store { i64, ptr } %t1417, ptr %l605
  br label %bb245
bb245:
  %t1418 = load { i64, ptr }, ptr %l605, !tbaa !27
  %t1419 = extractvalue { i64, ptr } %t1418, 0
  %t1420 = extractvalue { i64, ptr } %t1418, 1
  %t1421 = mul i64 %t1419, 1
  %t1422 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1422, ptr %t1420, i64 %t1421, i1 false)
  %t1423 = insertvalue { i64, ptr } undef, i64 %t1419, 0
  %t1424 = insertvalue { i64, ptr } %t1423, ptr %t1422, 1
  %t1425 = load ptr, ptr %l599, !tbaa !29
  %t1426 = load { i64, ptr }, ptr %l600, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1425, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d410, i32 0, i32 1) }, { i64, ptr } %t1426, { i64, ptr } %t1424, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb246
bb246:
  %t1428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1428, ptr %l607, !tbaa !29
  %t1429 = load ptr, ptr %l0, !tbaa !29
  %t1430 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1431 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t1432 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t1434 = extractvalue { i64, ptr } %t1430, 1
  %t1435 = extractvalue { i64, ptr } %t1430, 0
  %t1436 = add i64 %t1432, %t1435
  %t1437 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d412, i32 0, i32 1) }, 1
  %t1438 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d412, i32 0, i32 1) }, 0
  %t1439 = add i64 %t1436, %t1438
  %t1440 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1439)
  call void @olang_textcopy(ptr %t1440, ptr %t1431, i64 %t1432)
  %t1441 = getelementptr i8, ptr %t1440, i64 %t1432
  call void @olang_textcopy(ptr %t1441, ptr %t1434, i64 %t1435)
  %t1442 = getelementptr i8, ptr %t1441, i64 %t1435
  call void @olang_textcopy(ptr %t1442, ptr %t1437, i64 %t1438)
  %t1443 = insertvalue { i64, ptr } undef, i64 %t1439, 0
  %t1444 = insertvalue { i64, ptr } %t1443, ptr %t1440, 1
  %t1446 = extractvalue { i64, ptr } %t1444, 0
  %t1447 = extractvalue { i64, ptr } %t1444, 1
  %t1448 = mul i64 %t1446, 1
  %t1449 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1449, ptr %t1447, i64 %t1448, i1 false)
  %t1450 = insertvalue { i64, ptr } undef, i64 %t1446, 0
  %t1451 = insertvalue { i64, ptr } %t1450, ptr %t1449, 1
  %t1454 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1429, { i64, ptr } %t1451)
  store { i64, ptr } %t1454, ptr %l612
  br label %bb247
bb247:
  %t1455 = load { i64, ptr }, ptr %l612, !tbaa !27
  %t1456 = extractvalue { i64, ptr } %t1455, 0
  %t1457 = extractvalue { i64, ptr } %t1455, 1
  %t1458 = mul i64 %t1456, 1
  %t1459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1459, ptr %t1457, i64 %t1458, i1 false)
  %t1460 = insertvalue { i64, ptr } undef, i64 %t1456, 0
  %t1461 = insertvalue { i64, ptr } %t1460, ptr %t1459, 1
  %t1462 = load ptr, ptr %l607, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1462, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d413, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d414, i32 0, i32 1) }, { i64, ptr } %t1461, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb248
bb248:
  %t1464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1464, ptr %l614, !tbaa !29
  %t1465 = load ptr, ptr %l0, !tbaa !29
  %t1466 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1467 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t1468 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t1470 = extractvalue { i64, ptr } %t1466, 1
  %t1471 = extractvalue { i64, ptr } %t1466, 0
  %t1472 = add i64 %t1468, %t1471
  %t1473 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t1474 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t1475 = add i64 %t1472, %t1474
  %t1476 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1475)
  call void @olang_textcopy(ptr %t1476, ptr %t1467, i64 %t1468)
  %t1477 = getelementptr i8, ptr %t1476, i64 %t1468
  call void @olang_textcopy(ptr %t1477, ptr %t1470, i64 %t1471)
  %t1478 = getelementptr i8, ptr %t1477, i64 %t1471
  call void @olang_textcopy(ptr %t1478, ptr %t1473, i64 %t1474)
  %t1479 = insertvalue { i64, ptr } undef, i64 %t1475, 0
  %t1480 = insertvalue { i64, ptr } %t1479, ptr %t1476, 1
  %t1482 = extractvalue { i64, ptr } %t1480, 0
  %t1483 = extractvalue { i64, ptr } %t1480, 1
  %t1484 = mul i64 %t1482, 1
  %t1485 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1485, ptr %t1483, i64 %t1484, i1 false)
  %t1486 = insertvalue { i64, ptr } undef, i64 %t1482, 0
  %t1487 = insertvalue { i64, ptr } %t1486, ptr %t1485, 1
  %t1490 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1465, { i64, ptr } %t1487)
  store { i64, ptr } %t1490, ptr %l619
  br label %bb249
bb249:
  %t1491 = load { i64, ptr }, ptr %l619, !tbaa !27
  %t1492 = extractvalue { i64, ptr } %t1491, 0
  %t1493 = extractvalue { i64, ptr } %t1491, 1
  %t1494 = mul i64 %t1492, 1
  %t1495 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1495, ptr %t1493, i64 %t1494, i1 false)
  %t1496 = insertvalue { i64, ptr } undef, i64 %t1492, 0
  %t1497 = insertvalue { i64, ptr } %t1496, ptr %t1495, 1
  %t1498 = load ptr, ptr %l614, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1498, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d417, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, { i64, ptr } %t1497, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb250
bb250:
  %t1500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1500, ptr %l621, !tbaa !29
  %t1501 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1501, ptr %l622, !tbaa !27
  %t1502 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1502, ptr %l623
  %t1503 = load i1, ptr %l8, !tbaa !21
  store i1 %t1503, ptr %l624, !tbaa !21
  %t1504 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t1504, ptr %l625, !tbaa !27
  %t1505 = load i32, ptr %l6, !tbaa !23
  store i32 %t1505, ptr %l626, !tbaa !23
  %t1506 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t1507 = getelementptr %"compiler/mir:Range", ptr %t1506, i32 0, i32 1
  %t1508 = load i32, ptr %t1507, !tbaa !23
  %t1510 = sext i32 %t1508 to i64
  store i64 %t1510, ptr %l628, !tbaa !24
  %t1511 = load %"compiler/mir:Task", ptr %l2
  store %"compiler/mir:Task" %t1511, ptr %l629
  %t1512 = load ptr, ptr %l0, !tbaa !29
  %t1514 = getelementptr %"compiler/emit:fnEm", ptr %t1512, i32 0, i32 1
  %t1515 = load ptr, ptr %t1514, !tbaa !29
  %t1517 = getelementptr %"compiler/mir:Fn", ptr %t1515, i32 0, i32 8
  %t1518 = load i32, ptr %l1, !tbaa !23
  %t1520 = sext i32 %t1518 to i64
  %t1523 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t1517, i64 %t1520)
  store %"compiler/mir:ScopeInfo" %t1523, ptr %l635
  br label %bb251
bb251:
  %t1524 = getelementptr %"compiler/mir:ScopeInfo", ptr %l635, i32 0, i32 4
  %t1525 = load i32, ptr %t1524, !tbaa !23
  %t1526 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1527 = load ptr, ptr %l621, !tbaa !29
  %t1528 = load { i64, ptr }, ptr %l622, !tbaa !27
  %t1529 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l623
  %t1530 = load i1, ptr %l624, !tbaa !21
  %t1531 = load { i64, ptr }, ptr %l625, !tbaa !27
  %t1532 = load i32, ptr %l626, !tbaa !23
  %t1533 = load i64, ptr %l628, !tbaa !24
  %t1534 = load %"compiler/mir:Task", ptr %l629
  %t1537 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1527, { i64, ptr } %t1528, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1529, i1 %t1530, { i64, ptr } %t1531, i32 %t1532, i64 %t1533, %"compiler/mir:Task" %t1534, i32 %t1525, { i64, ptr } %t1526)
  store { i64, ptr } %t1537, ptr %l638
  br label %bb252
bb252:
  %t1538 = load { i64, ptr }, ptr %l638, !tbaa !27
  store { i64, ptr } %t1538, ptr %l83, !tbaa !27
  %t1539 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1539, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d419, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d420, i32 0, i32 1) })
  br label %bb253
bb253:
  %t1541 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1541, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d421, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d422, i32 0, i32 1) })
  br label %bb254
bb254:
  %t1543 = load ptr, ptr %l0, !tbaa !29
  %t1545 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1543, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d423, i32 0, i32 1) })
  store { i64, ptr } %t1545, ptr %l642
  br label %bb255
bb255:
  %t1546 = load { i64, ptr }, ptr %l642, !tbaa !27
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1549 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1550 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1551 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1552 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t1553 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t1555 = extractvalue { i64, ptr } %t1546, 1
  %t1556 = extractvalue { i64, ptr } %t1546, 0
  %t1557 = add i64 %t1553, %t1556
  %t1558 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t1559 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t1560 = add i64 %t1557, %t1559
  %t1562 = extractvalue { i64, ptr } %t1549, 1
  %t1563 = extractvalue { i64, ptr } %t1549, 0
  %t1564 = add i64 %t1560, %t1563
  %t1565 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t1566 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t1567 = add i64 %t1564, %t1566
  %t1569 = extractvalue { i64, ptr } %t1550, 1
  %t1570 = extractvalue { i64, ptr } %t1550, 0
  %t1571 = add i64 %t1567, %t1570
  %t1572 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t1573 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t1574 = add i64 %t1571, %t1573
  %t1576 = extractvalue { i64, ptr } %t1551, 1
  %t1577 = extractvalue { i64, ptr } %t1551, 0
  %t1578 = add i64 %t1574, %t1577
  %t1579 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t1580 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t1581 = add i64 %t1578, %t1580
  %t1582 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1581)
  call void @olang_textcopy(ptr %t1582, ptr %t1552, i64 %t1553)
  %t1583 = getelementptr i8, ptr %t1582, i64 %t1553
  call void @olang_textcopy(ptr %t1583, ptr %t1555, i64 %t1556)
  %t1584 = getelementptr i8, ptr %t1583, i64 %t1556
  call void @olang_textcopy(ptr %t1584, ptr %t1558, i64 %t1559)
  %t1585 = getelementptr i8, ptr %t1584, i64 %t1559
  call void @olang_textcopy(ptr %t1585, ptr %t1562, i64 %t1563)
  %t1586 = getelementptr i8, ptr %t1585, i64 %t1563
  call void @olang_textcopy(ptr %t1586, ptr %t1565, i64 %t1566)
  %t1587 = getelementptr i8, ptr %t1586, i64 %t1566
  call void @olang_textcopy(ptr %t1587, ptr %t1569, i64 %t1570)
  %t1588 = getelementptr i8, ptr %t1587, i64 %t1570
  call void @olang_textcopy(ptr %t1588, ptr %t1572, i64 %t1573)
  %t1589 = getelementptr i8, ptr %t1588, i64 %t1573
  call void @olang_textcopy(ptr %t1589, ptr %t1576, i64 %t1577)
  %t1590 = getelementptr i8, ptr %t1589, i64 %t1577
  call void @olang_textcopy(ptr %t1590, ptr %t1579, i64 %t1580)
  %t1591 = insertvalue { i64, ptr } undef, i64 %t1581, 0
  %t1592 = insertvalue { i64, ptr } %t1591, ptr %t1582, 1
  %t1594 = extractvalue { i64, ptr } %t1592, 0
  %t1595 = extractvalue { i64, ptr } %t1592, 1
  %t1596 = mul i64 %t1594, 1
  %t1597 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1597, ptr %t1595, i64 %t1596, i1 false)
  %t1598 = insertvalue { i64, ptr } undef, i64 %t1594, 0
  %t1599 = insertvalue { i64, ptr } %t1598, ptr %t1597, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1547, { i64, ptr } %t1599)
  br label %bb256
bb256:
  %t1602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1602, ptr %l650, !tbaa !29
  %t1603 = load ptr, ptr %l0, !tbaa !29
  %t1604 = load i32, ptr %l1, !tbaa !23
  %t1605 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t1606 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t1608 = sext i32 %t1604 to i64
  %t1609 = call i64 @__olang_fmt_i64(ptr null, i64 %t1608)
  %t1610 = add i64 %t1606, %t1609
  %t1611 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1610)
  call void @olang_textcopy(ptr %t1611, ptr %t1605, i64 %t1606)
  %t1612 = getelementptr i8, ptr %t1611, i64 %t1606
  %t1613 = call i64 @__olang_fmt_i64(ptr %t1612, i64 %t1608)
  %t1614 = insertvalue { i64, ptr } undef, i64 %t1610, 0
  %t1615 = insertvalue { i64, ptr } %t1614, ptr %t1611, 1
  %t1617 = extractvalue { i64, ptr } %t1615, 0
  %t1618 = extractvalue { i64, ptr } %t1615, 1
  %t1619 = mul i64 %t1617, 1
  %t1620 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1619)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1620, ptr %t1618, i64 %t1619, i1 false)
  %t1621 = insertvalue { i64, ptr } undef, i64 %t1617, 0
  %t1622 = insertvalue { i64, ptr } %t1621, ptr %t1620, 1
  %t1625 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1603, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d429, i32 0, i32 1) }, { i64, ptr } %t1622, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store { i64, ptr } %t1625, ptr %l655
  br label %bb257
bb257:
  %t1626 = load { i64, ptr }, ptr %l655, !tbaa !27
  %t1627 = extractvalue { i64, ptr } %t1626, 0
  %t1628 = extractvalue { i64, ptr } %t1626, 1
  %t1629 = mul i64 %t1627, 1
  %t1630 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1630, ptr %t1628, i64 %t1629, i1 false)
  %t1631 = insertvalue { i64, ptr } undef, i64 %t1627, 0
  %t1632 = insertvalue { i64, ptr } %t1631, ptr %t1630, 1
  %t1633 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1634 = load ptr, ptr %l650, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1634, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d430, i32 0, i32 1) }, { i64, ptr } %t1632, { i64, ptr } %t1633, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb258
bb258:
  %t1637 = load ptr, ptr %l0, !tbaa !29
  %t1638 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1639 = load i32, ptr %l1, !tbaa !23
  %t1640 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t1641 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t1643 = sext i32 %t1639 to i64
  %t1644 = call i64 @__olang_fmt_i64(ptr null, i64 %t1643)
  %t1645 = add i64 %t1641, %t1644
  %t1646 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1645)
  call void @olang_textcopy(ptr %t1646, ptr %t1640, i64 %t1641)
  %t1647 = getelementptr i8, ptr %t1646, i64 %t1641
  %t1648 = call i64 @__olang_fmt_i64(ptr %t1647, i64 %t1643)
  %t1649 = insertvalue { i64, ptr } undef, i64 %t1645, 0
  %t1650 = insertvalue { i64, ptr } %t1649, ptr %t1646, 1
  %t1652 = extractvalue { i64, ptr } %t1650, 0
  %t1653 = extractvalue { i64, ptr } %t1650, 1
  %t1654 = mul i64 %t1652, 1
  %t1655 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1654)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1655, ptr %t1653, i64 %t1654, i1 false)
  %t1656 = insertvalue { i64, ptr } undef, i64 %t1652, 0
  %t1657 = insertvalue { i64, ptr } %t1656, ptr %t1655, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1637, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, { i64, ptr } %t1638, { i64, ptr } %t1657, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l26 = alloca i32
  %l29 = alloca i32
  %l51 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l63 = alloca %"compiler/mir:Place"
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca i32
  %l72 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l135 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Task" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  store i32 0, ptr %l8, !tbaa !23
  %t11 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr %l8, !tbaa !23
  %t19 = icmp sgt i32 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t23 = icmp sgt i32 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l26, !tbaa !23
  br label %bb6
bb3:
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr %l8, !tbaa !23
  %t29 = sub i32 %t25, %t26
  %t30 = load i32, ptr %l10, !tbaa !23
  %t33 = add i32 %t29, %t30
  %t35 = sub i32 %t33, 1
  %t36 = load i32, ptr %l10, !tbaa !23
  %t39 = sdiv i32 %t35, %t36
  store i32 %t39, ptr %l29, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l29, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l29, !tbaa !23
  store i32 %t41, ptr %l26, !tbaa !23
  br label %bb6
bb6:
  %t42 = load i32, ptr %l26, !tbaa !23
  store i32 %t42, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = load i32, ptr %l11, !tbaa !23
  %t47 = icmp slt i32 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t51 = load i32, ptr %l8, !tbaa !23
  %t52 = load i32, ptr %l12, !tbaa !23
  %t53 = load i32, ptr %l10, !tbaa !23
  %t56 = mul i32 %t52, %t53
  %t59 = add i32 %t51, %t56
  store i32 %t59, ptr %l13, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/mir:Task", ptr %l2
  %t63 = load i32, ptr %l13, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t69 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %t61, %"compiler/mir:Task" %t62, i64 %t65)
  store i1 %t69, ptr %l51
  br label %bb11
bb11:
  %t70 = load i1, ptr %l51, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb13:
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l7, !tbaa !29
  store ptr %t73, ptr %l53, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l54, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 13
  %t81 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t82 = getelementptr %"compiler/mir:Range", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i32, ptr %l13, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = add i64 %t85, %t88
  %t94 = call %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t80, i64 %t91)
  store %"compiler/mir:Place" %t94, ptr %l63
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load %"compiler/mir:Place", ptr %l63
  %t97 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t95, %"compiler/mir:Place" %t96)
  store i32 %t97, ptr %l64
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l53, !tbaa !29
  %t99 = load i32, ptr %l64, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t100, ptr %l65
  br label %bb17
bb17:
  %t101 = load i32, ptr %l65, !tbaa !23
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t102, i32 %t101)
  store i32 %t106, ptr %l68
  br label %bb18
bb18:
  %t107 = load i32, ptr %l68, !tbaa !23
  store i32 %t107, ptr %l15, !tbaa !23
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l15, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l72
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t116, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d433, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d434, i32 0, i32 1) })
  br label %bb20
bb20:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = load i32, ptr %l13, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t118, 1
  %t124 = extractvalue { i64, ptr } %t118, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t130 = sext i32 %t119 to i64
  %t131 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %t130)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  store { i64, ptr } %t139, ptr %l16, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = load i32, ptr %l13, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t146 = extractvalue { i64, ptr } %t141, 1
  %t147 = extractvalue { i64, ptr } %t141, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = getelementptr i8, ptr %t158, i64 %t150
  %t160 = call i64 @__olang_fmt_i64(ptr %t159, i64 %t153)
  %t161 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t156, 1
  store { i64, ptr } %t162, ptr %l17, !tbaa !27
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t167 = load i32, ptr %l13, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t172 = add i64 %a3, %t169
  %t173 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t175 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t178 = extractvalue { i64, ptr } %t165, 1
  %t179 = extractvalue { i64, ptr } %t165, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t185 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t186 = add i64 %t183, %t185
  %t187 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t173, 1
  %t192 = extractvalue { i64, ptr } %t173, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t198 = extractvalue { i64, ptr } %t174, 1
  %t199 = extractvalue { i64, ptr } %t174, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t175, i64 %t176)
  %t205 = getelementptr i8, ptr %t204, i64 %t176
  call void @olang_textcopy(ptr %t205, ptr %t178, i64 %t179)
  %t206 = getelementptr i8, ptr %t205, i64 %t179
  call void @olang_textcopy(ptr %t206, ptr %t181, i64 %t182)
  %t207 = getelementptr i8, ptr %t206, i64 %t182
  %t208 = call i64 @__olang_fmt_i64(ptr %t207, i64 %t172)
  %t209 = getelementptr i8, ptr %t207, i64 %t185
  call void @olang_textcopy(ptr %t209, ptr %t187, i64 %t188)
  %t210 = getelementptr i8, ptr %t209, i64 %t188
  call void @olang_textcopy(ptr %t210, ptr %t191, i64 %t192)
  %t211 = getelementptr i8, ptr %t210, i64 %t192
  call void @olang_textcopy(ptr %t211, ptr %t194, i64 %t195)
  %t212 = getelementptr i8, ptr %t211, i64 %t195
  call void @olang_textcopy(ptr %t212, ptr %t198, i64 %t199)
  %t213 = getelementptr i8, ptr %t212, i64 %t199
  call void @olang_textcopy(ptr %t213, ptr %t201, i64 %t202)
  %t214 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t204, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = extractvalue { i64, ptr } %t215, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t164, { i64, ptr } %t222)
  br label %bb21
bb21:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t233 = extractvalue { i64, ptr } %t226, 1
  %t234 = extractvalue { i64, ptr } %t226, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t227, 1
  %t241 = extractvalue { i64, ptr } %t227, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t247 = extractvalue { i64, ptr } %t228, 1
  %t248 = extractvalue { i64, ptr } %t228, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t252 = add i64 %t249, %t251
  %t254 = extractvalue { i64, ptr } %t229, 1
  %t255 = extractvalue { i64, ptr } %t229, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t230, i64 %t231)
  %t261 = getelementptr i8, ptr %t260, i64 %t231
  call void @olang_textcopy(ptr %t261, ptr %t233, i64 %t234)
  %t262 = getelementptr i8, ptr %t261, i64 %t234
  call void @olang_textcopy(ptr %t262, ptr %t236, i64 %t237)
  %t263 = getelementptr i8, ptr %t262, i64 %t237
  call void @olang_textcopy(ptr %t263, ptr %t240, i64 %t241)
  %t264 = getelementptr i8, ptr %t263, i64 %t241
  call void @olang_textcopy(ptr %t264, ptr %t243, i64 %t244)
  %t265 = getelementptr i8, ptr %t264, i64 %t244
  call void @olang_textcopy(ptr %t265, ptr %t247, i64 %t248)
  %t266 = getelementptr i8, ptr %t265, i64 %t248
  call void @olang_textcopy(ptr %t266, ptr %t250, i64 %t251)
  %t267 = getelementptr i8, ptr %t266, i64 %t251
  call void @olang_textcopy(ptr %t267, ptr %t254, i64 %t255)
  %t268 = getelementptr i8, ptr %t267, i64 %t255
  call void @olang_textcopy(ptr %t268, ptr %t257, i64 %t258)
  %t269 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t260, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = extractvalue { i64, ptr } %t270, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t225, { i64, ptr } %t277)
  br label %bb22
bb22:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t282 = load i32, ptr %l13, !tbaa !23
  %t283 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t284 = load i32, ptr %l13, !tbaa !23
  %t285 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t288 = extractvalue { i64, ptr } %t281, 1
  %t289 = extractvalue { i64, ptr } %t281, 0
  %t290 = add i64 %t286, %t289
  %t291 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t295 = sext i32 %t282 to i64
  %t296 = call i64 @__olang_fmt_i64(ptr null, i64 %t295)
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t302 = extractvalue { i64, ptr } %t283, 1
  %t303 = extractvalue { i64, ptr } %t283, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t309 = sext i32 %t284 to i64
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t309)
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t285, i64 %t286)
  %t316 = getelementptr i8, ptr %t315, i64 %t286
  call void @olang_textcopy(ptr %t316, ptr %t288, i64 %t289)
  %t317 = getelementptr i8, ptr %t316, i64 %t289
  call void @olang_textcopy(ptr %t317, ptr %t291, i64 %t292)
  %t318 = getelementptr i8, ptr %t317, i64 %t292
  %t319 = call i64 @__olang_fmt_i64(ptr %t318, i64 %t295)
  %t320 = getelementptr i8, ptr %t318, i64 %t296
  call void @olang_textcopy(ptr %t320, ptr %t298, i64 %t299)
  %t321 = getelementptr i8, ptr %t320, i64 %t299
  call void @olang_textcopy(ptr %t321, ptr %t302, i64 %t303)
  %t322 = getelementptr i8, ptr %t321, i64 %t303
  call void @olang_textcopy(ptr %t322, ptr %t305, i64 %t306)
  %t323 = getelementptr i8, ptr %t322, i64 %t306
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t309)
  %t325 = getelementptr i8, ptr %t323, i64 %t310
  call void @olang_textcopy(ptr %t325, ptr %t312, i64 %t313)
  %t326 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t315, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = extractvalue { i64, ptr } %t327, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t280, { i64, ptr } %t334)
  br label %bb23
bb23:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l104, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t338, ptr %l105, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t339, ptr %l106, !tbaa !27
  %t340 = load ptr, ptr %l7, !tbaa !29
  %t341 = load i32, ptr %l15, !tbaa !23
  %t344 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t340, i32 %t341)
  store i64 %t344, ptr %l109
  br label %bb24
bb24:
  %t345 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t350 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = add i64 %t349, %t352
  %t354 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t357 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 1
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = add i64 %t356, %t359
  %t361 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t363 = add i64 %t360, %t362
  %t364 = load i64, ptr %l109, !tbaa !24
  %t365 = call i64 @__olang_fmt_i64(ptr null, i64 %t364)
  %t366 = add i64 %t363, %t365
  %t367 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t369 = add i64 %t366, %t368
  %t371 = extractvalue { i64, ptr } %t345, 1
  %t372 = extractvalue { i64, ptr } %t345, 0
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t378 = extractvalue { i64, ptr } %t346, 1
  %t379 = extractvalue { i64, ptr } %t346, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t385 = extractvalue { i64, ptr } %t347, 1
  %t386 = extractvalue { i64, ptr } %t347, 0
  %t387 = add i64 %t383, %t386
  %t388 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t390 = add i64 %t387, %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t348, i64 %t349)
  %t392 = getelementptr i8, ptr %t391, i64 %t349
  call void @olang_textcopy(ptr %t392, ptr %t351, i64 %t352)
  %t393 = getelementptr i8, ptr %t392, i64 %t352
  call void @olang_textcopy(ptr %t393, ptr %t354, i64 %t355)
  %t394 = getelementptr i8, ptr %t393, i64 %t355
  call void @olang_textcopy(ptr %t394, ptr %t358, i64 %t359)
  %t395 = getelementptr i8, ptr %t394, i64 %t359
  call void @olang_textcopy(ptr %t395, ptr %t361, i64 %t362)
  %t396 = getelementptr i8, ptr %t395, i64 %t362
  %t397 = call i64 @__olang_fmt_i64(ptr %t396, i64 %t364)
  %t398 = getelementptr i8, ptr %t396, i64 %t365
  call void @olang_textcopy(ptr %t398, ptr %t367, i64 %t368)
  %t399 = getelementptr i8, ptr %t398, i64 %t368
  call void @olang_textcopy(ptr %t399, ptr %t371, i64 %t372)
  %t400 = getelementptr i8, ptr %t399, i64 %t372
  call void @olang_textcopy(ptr %t400, ptr %t374, i64 %t375)
  %t401 = getelementptr i8, ptr %t400, i64 %t375
  call void @olang_textcopy(ptr %t401, ptr %t378, i64 %t379)
  %t402 = getelementptr i8, ptr %t401, i64 %t379
  call void @olang_textcopy(ptr %t402, ptr %t381, i64 %t382)
  %t403 = getelementptr i8, ptr %t402, i64 %t382
  call void @olang_textcopy(ptr %t403, ptr %t385, i64 %t386)
  %t404 = getelementptr i8, ptr %t403, i64 %t386
  call void @olang_textcopy(ptr %t404, ptr %t388, i64 %t389)
  %t405 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t391, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } %t406, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t414 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t414, { i64, ptr } %t413)
  br label %bb25
bb25:
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t421 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t422 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t424 = extractvalue { i64, ptr } %t417, 1
  %t425 = extractvalue { i64, ptr } %t417, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t429 = add i64 %t426, %t428
  %t431 = extractvalue { i64, ptr } %t418, 1
  %t432 = extractvalue { i64, ptr } %t418, 0
  %t433 = add i64 %t429, %t432
  %t434 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t435 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t436 = add i64 %t433, %t435
  %t438 = extractvalue { i64, ptr } %t419, 1
  %t439 = extractvalue { i64, ptr } %t419, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t443 = add i64 %t440, %t442
  %t445 = extractvalue { i64, ptr } %t420, 1
  %t446 = extractvalue { i64, ptr } %t420, 0
  %t447 = add i64 %t443, %t446
  %t448 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t450 = add i64 %t447, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t421, i64 %t422)
  %t452 = getelementptr i8, ptr %t451, i64 %t422
  call void @olang_textcopy(ptr %t452, ptr %t424, i64 %t425)
  %t453 = getelementptr i8, ptr %t452, i64 %t425
  call void @olang_textcopy(ptr %t453, ptr %t427, i64 %t428)
  %t454 = getelementptr i8, ptr %t453, i64 %t428
  call void @olang_textcopy(ptr %t454, ptr %t431, i64 %t432)
  %t455 = getelementptr i8, ptr %t454, i64 %t432
  call void @olang_textcopy(ptr %t455, ptr %t434, i64 %t435)
  %t456 = getelementptr i8, ptr %t455, i64 %t435
  call void @olang_textcopy(ptr %t456, ptr %t438, i64 %t439)
  %t457 = getelementptr i8, ptr %t456, i64 %t439
  call void @olang_textcopy(ptr %t457, ptr %t441, i64 %t442)
  %t458 = getelementptr i8, ptr %t457, i64 %t442
  call void @olang_textcopy(ptr %t458, ptr %t445, i64 %t446)
  %t459 = getelementptr i8, ptr %t458, i64 %t446
  call void @olang_textcopy(ptr %t459, ptr %t448, i64 %t449)
  %t460 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t451, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = extractvalue { i64, ptr } %t461, 1
  %t465 = mul i64 %t463, 1
  %t466 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t465)
  call void @llvm.memcpy.p0.p0.i64(ptr %t466, ptr %t464, i64 %t465, i1 false)
  %t467 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t416, { i64, ptr } %t468)
  br label %bb26
bb26:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t474 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t475 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t478 = extractvalue { i64, ptr } %t472, 1
  %t479 = extractvalue { i64, ptr } %t472, 0
  %t480 = add i64 %t476, %t479
  %t481 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t483 = add i64 %t480, %t482
  %t485 = extractvalue { i64, ptr } %t473, 1
  %t486 = extractvalue { i64, ptr } %t473, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t492 = extractvalue { i64, ptr } %t474, 1
  %t493 = extractvalue { i64, ptr } %t474, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t475, i64 %t476)
  %t499 = getelementptr i8, ptr %t498, i64 %t476
  call void @olang_textcopy(ptr %t499, ptr %t478, i64 %t479)
  %t500 = getelementptr i8, ptr %t499, i64 %t479
  call void @olang_textcopy(ptr %t500, ptr %t481, i64 %t482)
  %t501 = getelementptr i8, ptr %t500, i64 %t482
  call void @olang_textcopy(ptr %t501, ptr %t485, i64 %t486)
  %t502 = getelementptr i8, ptr %t501, i64 %t486
  call void @olang_textcopy(ptr %t502, ptr %t488, i64 %t489)
  %t503 = getelementptr i8, ptr %t502, i64 %t489
  call void @olang_textcopy(ptr %t503, ptr %t492, i64 %t493)
  %t504 = getelementptr i8, ptr %t503, i64 %t493
  call void @olang_textcopy(ptr %t504, ptr %t495, i64 %t496)
  %t505 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t498, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t471, { i64, ptr } %t513)
  br label %bb27
bb27:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t517 = load i32, ptr %l13, !tbaa !23
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t520 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t521 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t524 = sext i32 %t517 to i64
  %t525 = call i64 @__olang_fmt_i64(ptr null, i64 %t524)
  %t526 = add i64 %t522, %t525
  %t527 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t528 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t529 = add i64 %t526, %t528
  %t531 = extractvalue { i64, ptr } %t518, 1
  %t532 = extractvalue { i64, ptr } %t518, 0
  %t533 = add i64 %t529, %t532
  %t534 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d471, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d471, i32 0, i32 1) }, 0
  %t536 = add i64 %t533, %t535
  %t538 = extractvalue { i64, ptr } %t519, 1
  %t539 = extractvalue { i64, ptr } %t519, 0
  %t540 = add i64 %t536, %t539
  %t541 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t543 = add i64 %t540, %t542
  %t545 = extractvalue { i64, ptr } %t520, 1
  %t546 = extractvalue { i64, ptr } %t520, 0
  %t547 = add i64 %t543, %t546
  %t548 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d473, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d473, i32 0, i32 1) }, 0
  %t550 = add i64 %t547, %t549
  %t551 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t521, i64 %t522)
  %t552 = getelementptr i8, ptr %t551, i64 %t522
  %t553 = call i64 @__olang_fmt_i64(ptr %t552, i64 %t524)
  %t554 = getelementptr i8, ptr %t552, i64 %t525
  call void @olang_textcopy(ptr %t554, ptr %t527, i64 %t528)
  %t555 = getelementptr i8, ptr %t554, i64 %t528
  call void @olang_textcopy(ptr %t555, ptr %t531, i64 %t532)
  %t556 = getelementptr i8, ptr %t555, i64 %t532
  call void @olang_textcopy(ptr %t556, ptr %t534, i64 %t535)
  %t557 = getelementptr i8, ptr %t556, i64 %t535
  call void @olang_textcopy(ptr %t557, ptr %t538, i64 %t539)
  %t558 = getelementptr i8, ptr %t557, i64 %t539
  call void @olang_textcopy(ptr %t558, ptr %t541, i64 %t542)
  %t559 = getelementptr i8, ptr %t558, i64 %t542
  call void @olang_textcopy(ptr %t559, ptr %t545, i64 %t546)
  %t560 = getelementptr i8, ptr %t559, i64 %t546
  call void @olang_textcopy(ptr %t560, ptr %t548, i64 %t549)
  %t561 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t551, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t516, { i64, ptr } %t569)
  br label %bb28
bb28:
  %t572 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t572, ptr %l135, !tbaa !27
  %t573 = load i32, ptr %l13, !tbaa !23
  %t575 = sext i32 %t573 to i64
  %t576 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i64, ptr %t577, i64 %t575
  %t579 = load i64, ptr %t578, !tbaa !34
  %t581 = icmp sge i64 %t579, 0
  br i1 %t581, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t583 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s13, ptr %t583, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d474, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t585 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s13, ptr %s13, ptr %t585, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d475, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d476, i32 0, i32 1) })
  br label %bb32
bb32:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t589, ptr %l143, !tbaa !27
  %t590 = load i32, ptr %l13, !tbaa !23
  %t592 = sext i32 %t590 to i64
  %t593 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr i64, ptr %t594, i64 %t592
  %t596 = load i64, ptr %t595, !tbaa !34
  %t597 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t599 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t600 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t602 = extractvalue { i64, ptr } %t588, 1
  %t603 = extractvalue { i64, ptr } %t588, 0
  %t604 = add i64 %t600, %t603
  %t605 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t606 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d478, i32 0, i32 1) }, 0
  %t607 = add i64 %t604, %t606
  %t609 = call i64 @__olang_fmt_i64(ptr null, i64 %t596)
  %t610 = add i64 %t607, %t609
  %t611 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t612 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t613 = add i64 %t610, %t612
  %t615 = extractvalue { i64, ptr } %t597, 1
  %t616 = extractvalue { i64, ptr } %t597, 0
  %t617 = add i64 %t613, %t616
  %t618 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d480, i32 0, i32 1) }, 1
  %t619 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d480, i32 0, i32 1) }, 0
  %t620 = add i64 %t617, %t619
  %t622 = extractvalue { i64, ptr } %t598, 1
  %t623 = extractvalue { i64, ptr } %t598, 0
  %t624 = add i64 %t620, %t623
  %t625 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d481, i32 0, i32 1) }, 1
  %t626 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d481, i32 0, i32 1) }, 0
  %t627 = add i64 %t624, %t626
  %t628 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t627)
  call void @olang_textcopy(ptr %t628, ptr %t599, i64 %t600)
  %t629 = getelementptr i8, ptr %t628, i64 %t600
  call void @olang_textcopy(ptr %t629, ptr %t602, i64 %t603)
  %t630 = getelementptr i8, ptr %t629, i64 %t603
  call void @olang_textcopy(ptr %t630, ptr %t605, i64 %t606)
  %t631 = getelementptr i8, ptr %t630, i64 %t606
  %t632 = call i64 @__olang_fmt_i64(ptr %t631, i64 %t596)
  %t633 = getelementptr i8, ptr %t631, i64 %t609
  call void @olang_textcopy(ptr %t633, ptr %t611, i64 %t612)
  %t634 = getelementptr i8, ptr %t633, i64 %t612
  call void @olang_textcopy(ptr %t634, ptr %t615, i64 %t616)
  %t635 = getelementptr i8, ptr %t634, i64 %t616
  call void @olang_textcopy(ptr %t635, ptr %t618, i64 %t619)
  %t636 = getelementptr i8, ptr %t635, i64 %t619
  call void @olang_textcopy(ptr %t636, ptr %t622, i64 %t623)
  %t637 = getelementptr i8, ptr %t636, i64 %t623
  call void @olang_textcopy(ptr %t637, ptr %t625, i64 %t626)
  %t638 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t639 = insertvalue { i64, ptr } %t638, ptr %t628, 1
  %t641 = extractvalue { i64, ptr } %t639, 0
  %t642 = extractvalue { i64, ptr } %t639, 1
  %t643 = mul i64 %t641, 1
  %t644 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t643)
  call void @llvm.memcpy.p0.p0.i64(ptr %t644, ptr %t642, i64 %t643, i1 false)
  %t645 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t587, { i64, ptr } %t646)
  br label %bb33
bb33:
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t650 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t652 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t653 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t654 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t655 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t656 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t658 = extractvalue { i64, ptr } %t650, 1
  %t659 = extractvalue { i64, ptr } %t650, 0
  %t660 = add i64 %t656, %t659
  %t661 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t663 = add i64 %t660, %t662
  %t665 = extractvalue { i64, ptr } %t651, 1
  %t666 = extractvalue { i64, ptr } %t651, 0
  %t667 = add i64 %t663, %t666
  %t668 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t672 = extractvalue { i64, ptr } %t652, 1
  %t673 = extractvalue { i64, ptr } %t652, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t679 = extractvalue { i64, ptr } %t653, 1
  %t680 = extractvalue { i64, ptr } %t653, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t686 = extractvalue { i64, ptr } %t654, 1
  %t687 = extractvalue { i64, ptr } %t654, 0
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t690 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t691 = add i64 %t688, %t690
  %t692 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t691)
  call void @olang_textcopy(ptr %t692, ptr %t655, i64 %t656)
  %t693 = getelementptr i8, ptr %t692, i64 %t656
  call void @olang_textcopy(ptr %t693, ptr %t658, i64 %t659)
  %t694 = getelementptr i8, ptr %t693, i64 %t659
  call void @olang_textcopy(ptr %t694, ptr %t661, i64 %t662)
  %t695 = getelementptr i8, ptr %t694, i64 %t662
  call void @olang_textcopy(ptr %t695, ptr %t665, i64 %t666)
  %t696 = getelementptr i8, ptr %t695, i64 %t666
  call void @olang_textcopy(ptr %t696, ptr %t668, i64 %t669)
  %t697 = getelementptr i8, ptr %t696, i64 %t669
  call void @olang_textcopy(ptr %t697, ptr %t672, i64 %t673)
  %t698 = getelementptr i8, ptr %t697, i64 %t673
  call void @olang_textcopy(ptr %t698, ptr %t675, i64 %t676)
  %t699 = getelementptr i8, ptr %t698, i64 %t676
  call void @olang_textcopy(ptr %t699, ptr %t679, i64 %t680)
  %t700 = getelementptr i8, ptr %t699, i64 %t680
  call void @olang_textcopy(ptr %t700, ptr %t682, i64 %t683)
  %t701 = getelementptr i8, ptr %t700, i64 %t683
  call void @olang_textcopy(ptr %t701, ptr %t686, i64 %t687)
  %t702 = getelementptr i8, ptr %t701, i64 %t687
  call void @olang_textcopy(ptr %t702, ptr %t689, i64 %t690)
  %t703 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t692, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = extractvalue { i64, ptr } %t704, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t649, { i64, ptr } %t711)
  br label %bb34
bb34:
  %t714 = load ptr, ptr %l1, !tbaa !29
  %t715 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t717 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t718 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t719 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  %t721 = extractvalue { i64, ptr } %t715, 1
  %t722 = extractvalue { i64, ptr } %t715, 0
  %t723 = add i64 %t719, %t722
  %t724 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t725 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  %t726 = add i64 %t723, %t725
  %t728 = extractvalue { i64, ptr } %t716, 1
  %t729 = extractvalue { i64, ptr } %t716, 0
  %t730 = add i64 %t726, %t729
  %t731 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t732 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t733 = add i64 %t730, %t732
  %t735 = extractvalue { i64, ptr } %t717, 1
  %t736 = extractvalue { i64, ptr } %t717, 0
  %t737 = add i64 %t733, %t736
  %t738 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t739 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  %t740 = add i64 %t737, %t739
  %t741 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t740)
  call void @olang_textcopy(ptr %t741, ptr %t718, i64 %t719)
  %t742 = getelementptr i8, ptr %t741, i64 %t719
  call void @olang_textcopy(ptr %t742, ptr %t721, i64 %t722)
  %t743 = getelementptr i8, ptr %t742, i64 %t722
  call void @olang_textcopy(ptr %t743, ptr %t724, i64 %t725)
  %t744 = getelementptr i8, ptr %t743, i64 %t725
  call void @olang_textcopy(ptr %t744, ptr %t728, i64 %t729)
  %t745 = getelementptr i8, ptr %t744, i64 %t729
  call void @olang_textcopy(ptr %t745, ptr %t731, i64 %t732)
  %t746 = getelementptr i8, ptr %t745, i64 %t732
  call void @olang_textcopy(ptr %t746, ptr %t735, i64 %t736)
  %t747 = getelementptr i8, ptr %t746, i64 %t736
  call void @olang_textcopy(ptr %t747, ptr %t738, i64 %t739)
  %t748 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t749 = insertvalue { i64, ptr } %t748, ptr %t741, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = extractvalue { i64, ptr } %t749, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t714, { i64, ptr } %t756)
  br label %bb35
bb35:
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t760 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t761 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t762 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t763 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t764 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t766 = extractvalue { i64, ptr } %t760, 1
  %t767 = extractvalue { i64, ptr } %t760, 0
  %t768 = add i64 %t764, %t767
  %t769 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t773 = extractvalue { i64, ptr } %t761, 1
  %t774 = extractvalue { i64, ptr } %t761, 0
  %t775 = add i64 %t771, %t774
  %t776 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t778 = add i64 %t775, %t777
  %t780 = extractvalue { i64, ptr } %t762, 1
  %t781 = extractvalue { i64, ptr } %t762, 0
  %t782 = add i64 %t778, %t781
  %t783 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t785 = add i64 %t782, %t784
  %t786 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t785)
  call void @olang_textcopy(ptr %t786, ptr %t763, i64 %t764)
  %t787 = getelementptr i8, ptr %t786, i64 %t764
  call void @olang_textcopy(ptr %t787, ptr %t766, i64 %t767)
  %t788 = getelementptr i8, ptr %t787, i64 %t767
  call void @olang_textcopy(ptr %t788, ptr %t769, i64 %t770)
  %t789 = getelementptr i8, ptr %t788, i64 %t770
  call void @olang_textcopy(ptr %t789, ptr %t773, i64 %t774)
  %t790 = getelementptr i8, ptr %t789, i64 %t774
  call void @olang_textcopy(ptr %t790, ptr %t776, i64 %t777)
  %t791 = getelementptr i8, ptr %t790, i64 %t777
  call void @olang_textcopy(ptr %t791, ptr %t780, i64 %t781)
  %t792 = getelementptr i8, ptr %t791, i64 %t781
  call void @olang_textcopy(ptr %t792, ptr %t783, i64 %t784)
  %t793 = insertvalue { i64, ptr } undef, i64 %t785, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t786, 1
  %t796 = extractvalue { i64, ptr } %t794, 0
  %t797 = extractvalue { i64, ptr } %t794, 1
  %t798 = mul i64 %t796, 1
  %t799 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t798)
  call void @llvm.memcpy.p0.p0.i64(ptr %t799, ptr %t797, i64 %t798, i1 false)
  %t800 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t799, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t759, { i64, ptr } %t801)
  br label %bb36
bb36:
  %t804 = load ptr, ptr %l1, !tbaa !29
  %t805 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t806 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t807 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d496, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d496, i32 0, i32 1) }, 0
  %t810 = extractvalue { i64, ptr } %t805, 1
  %t811 = extractvalue { i64, ptr } %t805, 0
  %t812 = add i64 %t808, %t811
  %t813 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t814 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t815 = add i64 %t812, %t814
  %t817 = extractvalue { i64, ptr } %t806, 1
  %t818 = extractvalue { i64, ptr } %t806, 0
  %t819 = add i64 %t815, %t818
  %t820 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t821 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t822 = add i64 %t819, %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t807, i64 %t808)
  %t824 = getelementptr i8, ptr %t823, i64 %t808
  call void @olang_textcopy(ptr %t824, ptr %t810, i64 %t811)
  %t825 = getelementptr i8, ptr %t824, i64 %t811
  call void @olang_textcopy(ptr %t825, ptr %t813, i64 %t814)
  %t826 = getelementptr i8, ptr %t825, i64 %t814
  call void @olang_textcopy(ptr %t826, ptr %t817, i64 %t818)
  %t827 = getelementptr i8, ptr %t826, i64 %t818
  call void @olang_textcopy(ptr %t827, ptr %t820, i64 %t821)
  %t828 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t823, 1
  %t831 = extractvalue { i64, ptr } %t829, 0
  %t832 = extractvalue { i64, ptr } %t829, 1
  %t833 = mul i64 %t831, 1
  %t834 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t833)
  call void @llvm.memcpy.p0.p0.i64(ptr %t834, ptr %t832, i64 %t833, i1 false)
  %t835 = insertvalue { i64, ptr } undef, i64 %t831, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t834, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t804, { i64, ptr } %t836)
  br label %bb37
bb37:
  %t839 = load ptr, ptr %l1, !tbaa !29
  %t840 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t842 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t844 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t845 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t846 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t848 = extractvalue { i64, ptr } %t840, 1
  %t849 = extractvalue { i64, ptr } %t840, 0
  %t850 = add i64 %t846, %t849
  %t851 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t852 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t853 = add i64 %t850, %t852
  %t855 = extractvalue { i64, ptr } %t841, 1
  %t856 = extractvalue { i64, ptr } %t841, 0
  %t857 = add i64 %t853, %t856
  %t858 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t859 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  %t860 = add i64 %t857, %t859
  %t862 = extractvalue { i64, ptr } %t842, 1
  %t863 = extractvalue { i64, ptr } %t842, 0
  %t864 = add i64 %t860, %t863
  %t865 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t866 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t867 = add i64 %t864, %t866
  %t869 = extractvalue { i64, ptr } %t843, 1
  %t870 = extractvalue { i64, ptr } %t843, 0
  %t871 = add i64 %t867, %t870
  %t872 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t873 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t874 = add i64 %t871, %t873
  %t876 = extractvalue { i64, ptr } %t844, 1
  %t877 = extractvalue { i64, ptr } %t844, 0
  %t878 = add i64 %t874, %t877
  %t879 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t880 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t881 = add i64 %t878, %t880
  %t882 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t881)
  call void @olang_textcopy(ptr %t882, ptr %t845, i64 %t846)
  %t883 = getelementptr i8, ptr %t882, i64 %t846
  call void @olang_textcopy(ptr %t883, ptr %t848, i64 %t849)
  %t884 = getelementptr i8, ptr %t883, i64 %t849
  call void @olang_textcopy(ptr %t884, ptr %t851, i64 %t852)
  %t885 = getelementptr i8, ptr %t884, i64 %t852
  call void @olang_textcopy(ptr %t885, ptr %t855, i64 %t856)
  %t886 = getelementptr i8, ptr %t885, i64 %t856
  call void @olang_textcopy(ptr %t886, ptr %t858, i64 %t859)
  %t887 = getelementptr i8, ptr %t886, i64 %t859
  call void @olang_textcopy(ptr %t887, ptr %t862, i64 %t863)
  %t888 = getelementptr i8, ptr %t887, i64 %t863
  call void @olang_textcopy(ptr %t888, ptr %t865, i64 %t866)
  %t889 = getelementptr i8, ptr %t888, i64 %t866
  call void @olang_textcopy(ptr %t889, ptr %t869, i64 %t870)
  %t890 = getelementptr i8, ptr %t889, i64 %t870
  call void @olang_textcopy(ptr %t890, ptr %t872, i64 %t873)
  %t891 = getelementptr i8, ptr %t890, i64 %t873
  call void @olang_textcopy(ptr %t891, ptr %t876, i64 %t877)
  %t892 = getelementptr i8, ptr %t891, i64 %t877
  call void @olang_textcopy(ptr %t892, ptr %t879, i64 %t880)
  %t893 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t894 = insertvalue { i64, ptr } %t893, ptr %t882, 1
  %t896 = extractvalue { i64, ptr } %t894, 0
  %t897 = extractvalue { i64, ptr } %t894, 1
  %t898 = mul i64 %t896, 1
  %t899 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t898)
  call void @llvm.memcpy.p0.p0.i64(ptr %t899, ptr %t897, i64 %t898, i1 false)
  %t900 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t899, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t839, { i64, ptr } %t901)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s13)
  br label %bb39
bb39:
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t905 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t906 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t907 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t910 = extractvalue { i64, ptr } %t905, 1
  %t911 = extractvalue { i64, ptr } %t905, 0
  %t912 = add i64 %t908, %t911
  %t913 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t914 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t915 = add i64 %t912, %t914
  %t917 = extractvalue { i64, ptr } %t906, 1
  %t918 = extractvalue { i64, ptr } %t906, 0
  %t919 = add i64 %t915, %t918
  %t920 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t921 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t922 = add i64 %t919, %t921
  %t923 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t922)
  call void @olang_textcopy(ptr %t923, ptr %t907, i64 %t908)
  %t924 = getelementptr i8, ptr %t923, i64 %t908
  call void @olang_textcopy(ptr %t924, ptr %t910, i64 %t911)
  %t925 = getelementptr i8, ptr %t924, i64 %t911
  call void @olang_textcopy(ptr %t925, ptr %t913, i64 %t914)
  %t926 = getelementptr i8, ptr %t925, i64 %t914
  call void @olang_textcopy(ptr %t926, ptr %t917, i64 %t918)
  %t927 = getelementptr i8, ptr %t926, i64 %t918
  call void @olang_textcopy(ptr %t927, ptr %t920, i64 %t921)
  %t928 = insertvalue { i64, ptr } undef, i64 %t922, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t923, 1
  %t931 = extractvalue { i64, ptr } %t929, 0
  %t932 = extractvalue { i64, ptr } %t929, 1
  %t933 = mul i64 %t931, 1
  %t934 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t933)
  call void @llvm.memcpy.p0.p0.i64(ptr %t934, ptr %t932, i64 %t933, i1 false)
  %t935 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t936 = insertvalue { i64, ptr } %t935, ptr %t934, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t904, { i64, ptr } %t936)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t939 = load i32, ptr %l12, !tbaa !23
  %t941 = add i32 %t939, 1
  store i32 %t941, ptr %l12, !tbaa !23
  br label %bb7
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/emit:Emitter", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = load i1, ptr %l23, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l9 = alloca i1
  %l18 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d508, i32 0, i32 1) })
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:fnEm", ptr %t5, i32 0, i32 5
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 18
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d509, i32 0, i32 1) })
  store i1 %t16, ptr %l9
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:fnEm", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 18
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t26)
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %t29, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d510, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t36, { i64, ptr } %t39)
  store i1 %t40, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i1, ptr %l22, !tbaa !21
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t43, i32 0, i32 5
  store ptr %t45, ptr %l24, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %s3, ptr %t46)
  store { i64, ptr } %t48, ptr %l26
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } %t55)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/emit:fnEm", ptr %t58, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t60, i8 10)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l18
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t27, ptr %l19
  br label %bb4
bb4:
  %t28 = load i64, ptr %l19, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l32
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i32, ptr %l32, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l33
  br label %bb11
bb11:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l38
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i32, ptr %l38, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l39
  br label %bb13
bb13:
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d511, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d511, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t69, i64 %t70)
  %t90 = getelementptr i8, ptr %t89, i64 %t70
  call void @olang_textcopy(ptr %t90, ptr %t72, i64 %t73)
  %t91 = getelementptr i8, ptr %t90, i64 %t73
  call void @olang_textcopy(ptr %t91, ptr %t75, i64 %t76)
  %t92 = getelementptr i8, ptr %t91, i64 %t76
  call void @olang_textcopy(ptr %t92, ptr %t79, i64 %t80)
  %t93 = getelementptr i8, ptr %t92, i64 %t80
  call void @olang_textcopy(ptr %t93, ptr %t82, i64 %t83)
  %t94 = getelementptr i8, ptr %t93, i64 %t83
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t89, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l28, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t104, { i64, ptr } %t103)
  store { i64, ptr } %t106, ptr %l42
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t107 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb15:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l43, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l44, !tbaa !29
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l47
  br label %bb16
bb16:
  %t115 = load ptr, ptr %l44, !tbaa !29
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t115, i32 %t116)
  store { i64, ptr } %t117, ptr %l48
  br label %bb17
bb17:
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l49, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l50, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l53
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l50, !tbaa !29
  %t126 = load i32, ptr %l53, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t125, i32 %t126)
  store { i64, ptr } %t127, ptr %l54
  br label %bb19
bb19:
  %t128 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t130 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t128, i64 %t129)
  %t149 = getelementptr i8, ptr %t148, i64 %t129
  call void @olang_textcopy(ptr %t149, ptr %t131, i64 %t132)
  %t150 = getelementptr i8, ptr %t149, i64 %t132
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t138, i64 %t139)
  %t152 = getelementptr i8, ptr %t151, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l43, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t163, { i64, ptr } %t162)
  store { i64, ptr } %t165, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t166, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2emathInexact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathInexact
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2etbaaField_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 21, 2
  %t4 = insertvalue [15 x i64] %t3, i64 61, 3
  %t5 = insertvalue [15 x i64] %t4, i64 62, 4
  %t6 = insertvalue [15 x i64] %t5, i64 23, 5
  %t7 = insertvalue [15 x i64] %t6, i64 24, 6
  %t8 = insertvalue [15 x i64] %t7, i64 22, 7
  %t9 = insertvalue [15 x i64] %t8, i64 63, 8
  %t10 = insertvalue [15 x i64] %t9, i64 64, 9
  %t11 = insertvalue [15 x i64] %t10, i64 65, 10
  %t12 = insertvalue [15 x i64] %t11, i64 66, 11
  %t13 = insertvalue [15 x i64] %t12, i64 67, 12
  %t14 = insertvalue [15 x i64] %t13, i64 25, 13
  %t15 = insertvalue [15 x i64] %t14, i64 26, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2femit_2etbaaField
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2femit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2femit_2ePartSize_2einit()
  br label %bb1
bb1:
  call void @compiler_2femit_2ePartSizeDev_2einit()
  br label %bb2
bb2:
  call void @compiler_2femit_2eHomeShared_2einit()
  br label %bb3
bb3:
  call void @compiler_2femit_2eHomeLocal_2einit()
  br label %bb4
bb4:
  call void @compiler_2femit_2eHomeInst_2einit()
  br label %bb5
bb5:
  call void @compiler_2femit_2eHomeLoc_2einit()
  br label %bb6
bb6:
  call void @compiler_2femit_2etbaaName_2einit()
  br label %bb7
bb7:
  call void @compiler_2femit_2etbaaField_2einit()
  br label %bb8
bb8:
  call void @compiler_2femit_2etbaaElem_2einit()
  br label %bb9
bb9:
  call void @compiler_2femit_2etbaaTree_2einit()
  br label %bb10
bb10:
  call void @compiler_2femit_2ehexDigits_2einit()
  br label %bb11
bb11:
  call void @compiler_2femit_2emathExact_2einit()
  br label %bb12
bb12:
  call void @compiler_2femit_2emathInexact_2einit()
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @__olang_ert_req_clear()
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"const " }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" *" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"int64_t " }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"_len" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"const " }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" *" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" *buf" }>, align 8
@.d17 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"int64_t cap" }>, align 8
@.d18 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"int64_t *len" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"int32_t" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"int64_t" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" *result" }>, align 8
@.d22 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"int32_t" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"/* " }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" */\0A" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c");\0A" }>, align 8
@.d30 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr, ptr" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr byval(" }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d40 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"distinct !DICompileUnit(language: DW_LANG_C, file: !" }>, align 8
@.d41 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", producer: \22olang\22, " }>, align 8
@.d42 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d45 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: " }>, align 8
@.d46 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", size: 64)" }>, align 8
@.d47 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d48 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d49 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", size: 64, offset: 0)" }>, align 8
@.d50 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d51 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d52 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", size: 64, offset: 64)" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"!{!" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d56 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d57 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"\22, size: 128, elements: !" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d59 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"!DISubroutineType(types: !{})" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"define linkonce_odr void @" }>, align 8
@.d65 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"_rt(ptr %inst, ptr %scope) #0 {\0Aentry:\0A  call " }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d69 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr %scope" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d71 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr %inst)\0A  ret void\0A}\0A\0A" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"_rt" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d79 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" nobuiltin memory(write)" }>, align 8
@.d83 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"declare" }>, align 8
@.d84 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"define internal void @" }>, align 8
@.d85 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c".drop(ptr %h, ptr %scope) #0 {\0Aentry:\0A" }>, align 8
@.d86 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"  %p = call ptr @llvm.coro.promise(ptr %h, i32 8, i1 false)\0A" }>, align 8
@.d87 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  %pr = getelementptr " }>, align 8
@.d88 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c", ptr %p, i32 0, i32 1\0A  %r = load i32, ptr %pr\0A" }>, align 8
@.d89 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"  %idle = icmp eq i32 %r, 0\0A  br i1 %idle, label %d, label %x\0Ad:\0A  call void @llvm.coro.destroy(ptr %h)\0A" }>, align 8
@.d90 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"  br label %x\0Ax:\0A  ret void\0A}\0A\0A" }>, align 8
@.d91 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"; olang - emitted by the self-hosted compiler (compiler/emit.olang)\0Atarget triple = \22" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22\0A\0A" }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-t" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-i" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d98 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d101 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d102 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d103 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d104 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d105 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d106 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d114 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d115 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d116 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d117 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d118 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d119 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d120 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d121 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d122 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"getelementptr ptr, ptr " }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d124 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"load ptr, ptr " }>, align 8
@.d125 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"@llvm." }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d130 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d131 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d132 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d136 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d137 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d138 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d139 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d140 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { ptr, ptr } " }>, align 8
@.d141 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d143 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d145 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d147 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call void " }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d150 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d154 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d156 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d158 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d159 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d162 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d163 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d164 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d165 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ok" }>, align 8
@.d166 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d167 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d168 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d169 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d170 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d171 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d172 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%k" }>, align 8
@.d173 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d174 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d175 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"h = lshr i32 " }>, align 8
@.d176 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 16\0A  " }>, align 8
@.d177 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d178 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"h, " }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d180 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d181 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d182 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d184 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d185 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"o = or i1 " }>, align 8
@.d186 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d189 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d190 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %take" }>, align 8
@.d191 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %pass" }>, align 8
@.d192 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Atake" }>, align 8
@.d193 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hv" }>, align 8
@.d195 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" = load { ptr, ptr }, ptr %f" }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d197 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hc" }>, align 8
@.d198 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" = extractvalue { ptr, ptr } %hv" }>, align 8
@.d199 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", 0\0A  %he" }>, align 8
@.d200 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d201 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"ptr %he" }>, align 8
@.d202 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %ho" }>, align 8
@.d203 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = alloca " }>, align 8
@.d204 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d205 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d206 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d207 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d208 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hs" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d210 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" = load ptr, ptr @__olang_prog_scope\0A" }>, align 8
@.d211 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hs" }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d213 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d214 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d215 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  call void %hc" }>, align 8
@.d216 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d217 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d218 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hr" }>, align 8
@.d219 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = call " }>, align 8
@.d220 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" %hc" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d222 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d223 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hr" }>, align 8
@.d224 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hl" }>, align 8
@.d225 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d226 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hl" }>, align 8
@.d229 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d230 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hd" }>, align 8
@.d231 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d232 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A  store " }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d234 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hd" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d236 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hd" }>, align 8
@.d237 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d238 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d239 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d240 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hx" }>, align 8
@.d241 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d242 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = extractvalue " }>, align 8
@.d243 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d244 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d246 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  store " }>, align 8
@.d247 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" %hx" }>, align 8
@.d248 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d249 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hd" }>, align 8
@.d250 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d251 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d252 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"  ret ptr null\0Apass" }>, align 8
@.d253 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d254 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d255 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d256 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d257 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d258 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d259 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d260 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d261 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call ptr @__olang_scope_alloc(ptr " }>, align 8
@.d262 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d263 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d264 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"llvm.memcpy.p0.p0.i64" }>, align 8
@.d265 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d266 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @llvm.memcpy.p0.p0.i64(ptr " }>, align 8
@.d267 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d268 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d269 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d270 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d271 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d272 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d273 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a C callback that is no export fn named at the call" }>, align 8
@.d274 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d275 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"add" }>, align 8
@.d276 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"sub" }>, align 8
@.d277 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mul" }>, align 8
@.d278 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d279 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d280 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"llvm." }>, align 8
@.d281 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c".with.overflow.i" }>, align 8
@.d282 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d283 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i1 } @" }>, align 8
@.d284 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d285 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d286 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d287 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"call { " }>, align 8
@.d288 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i1 } @" }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d290 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d291 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d292 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d293 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"extractvalue { " }>, align 8
@.d294 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i1 } " }>, align 8
@.d295 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d296 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d297 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"shl " }>, align 8
@.d298 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" 1, " }>, align 8
@.d299 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp eq " }>, align 8
@.d300 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d301 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d302 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp eq " }>, align 8
@.d303 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d304 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", -1" }>, align 8
@.d305 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d306 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d307 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp ne " }>, align 8
@.d308 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d309 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d310 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"shl " }>, align 8
@.d311 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" 1, " }>, align 8
@.d312 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp eq " }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d314 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d315 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fpext " }>, align 8
@.d316 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d317 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to double" }>, align 8
@.d318 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d319 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d320 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d321 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", -1.0" }>, align 8
@.d322 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d323 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d324 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp oge double " }>, align 8
@.d325 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d326 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d327 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d328 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d329 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d330 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d331 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d332 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"xor i1 " }>, align 8
@.d333 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", true" }>, align 8
@.d334 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"icmp ne " }>, align 8
@.d335 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d336 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d337 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d338 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"icmp slt " }>, align 8
@.d339 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d340 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d341 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"icmp slt " }>, align 8
@.d342 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d343 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d344 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"or i1 " }>, align 8
@.d345 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d346 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an overflow test of " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d520, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d520, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d525, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d525, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d530, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d530, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d531, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d531, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d532, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d532, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d533, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d533, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d534, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d534, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d535, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d535, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d536, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d536, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d537, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d537, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d538, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d538, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d540, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d540, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d543, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d543, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d544, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d544, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d545, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d545, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d547, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d547, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d548, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d548, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d549, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d549, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d553, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d553, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d556, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d556, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d347 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d348 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d349 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d350 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d351 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"sub i64 " }>, align 8
@.d352 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d353 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bs" }>, align 8
@.d354 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d355 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d356 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" = call ptr @__olang_scope_alloc_a(ptr %big, i64 " }>, align 8
@.d357 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d358 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d359 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%s" }>, align 8
@.d360 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d361 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d362 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d364 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a task calling an extern" }>, align 8
@.d365 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a task calling through an any" }>, align 8
@.d366 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d367 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d368 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d369 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d370 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_standin" }>, align 8
@.d371 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr @__olang_standin(ptr)" }>, align 8
@.d372 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_standin(ptr " }>, align 8
@.d373 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d374 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d375 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d376 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d377 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d378 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_standin" }>, align 8
@.d379 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr @__olang_standin(ptr)" }>, align 8
@.d380 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_standin(ptr " }>, align 8
@.d381 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d382 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d383 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d384 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d385 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d386 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d387 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_scope_alloc_a" }>, align 8
@.d388 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d389 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c", ptr null, i32 1" }>, align 8
@.d390 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ptrtoint ptr " }>, align 8
@.d391 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d392 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d393 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d394 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 8)" }>, align 8
@.d395 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d396 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d397 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d398 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d399 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d400 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 32, i64 8)" }>, align 8
@.d401 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d402 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d403 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 16, i64 8)" }>, align 8
@.d404 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d405 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { ptr, ptr }, ptr " }>, align 8
@.d406 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d407 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d408 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr " }>, align 8
@.d409 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 2" }>, align 8
@.d410 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d411 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr " }>, align 8
@.d412 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d413 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d414 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d415 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr " }>, align 8
@.d416 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 3" }>, align 8
@.d417 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d418 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d419 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_worker_get" }>, align 8
@.d420 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr @__olang_worker_get()" }>, align 8
@.d421 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_worker_start" }>, align 8
@.d422 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @__olang_worker_start(ptr, ptr, ptr, ptr)" }>, align 8
@.d423 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_worker_get()" }>, align 8
@.d424 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_worker_start(ptr " }>, align 8
@.d425 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d426 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d427 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d428 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%jh" }>, align 8
@.d429 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d430 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d431 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%jh" }>, align 8
@.d432 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d433 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d434 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d435 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%tf" }>, align 8
@.d436 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d437 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"tf" }>, align 8
@.d438 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d439 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d440 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"d = load ptr, ptr %f" }>, align 8
@.d441 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d442 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"v = load { i64, ptr }, ptr " }>, align 8
@.d443 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d444 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d445 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"n = extractvalue { i64, ptr } " }>, align 8
@.d446 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"v, 0\0A  " }>, align 8
@.d447 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"p = extractvalue { i64, ptr } " }>, align 8
@.d448 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"v, 1\0A" }>, align 8
@.d449 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d450 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"on = extractvalue { i64, ptr } %old" }>, align 8
@.d451 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", 0\0A  " }>, align 8
@.d452 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"op = extractvalue { i64, ptr } %old" }>, align 8
@.d453 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d454 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d455 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"b = mul i64 " }>, align 8
@.d456 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"n, " }>, align 8
@.d457 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d458 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"s = icmp eq i64 " }>, align 8
@.d459 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"on\0A" }>, align 8
@.d460 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d461 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"s, label %" }>, align 8
@.d462 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"i, label %" }>, align 8
@.d463 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"f\0A" }>, align 8
@.d464 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i:\0A" }>, align 8
@.d465 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d466 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"op, ptr " }>, align 8
@.d467 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d468 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d469 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  store { i64, ptr } %old" }>, align 8
@.d470 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d471 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"d\0A  br label %" }>, align 8
@.d472 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d473 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"f:\0A" }>, align 8
@.d474 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d475 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d476 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d477 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d478 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"c = load ptr, ptr %f" }>, align 8
@.d479 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d480 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"z = icmp eq ptr " }>, align 8
@.d481 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"c, null\0A" }>, align 8
@.d482 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d483 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"g = load ptr, ptr @__olang_prog_scope\0A  " }>, align 8
@.d484 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"w = select i1 " }>, align 8
@.d485 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"z, ptr " }>, align 8
@.d486 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"g, ptr " }>, align 8
@.d487 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c\0A" }>, align 8
@.d488 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d489 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"q = call ptr @__olang_scope_alloc(ptr " }>, align 8
@.d490 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"w, i64 " }>, align 8
@.d491 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"b)\0A" }>, align 8
@.d492 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d493 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"q, ptr " }>, align 8
@.d494 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d495 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d496 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d497 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"x = insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d498 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"n, 0\0A" }>, align 8
@.d499 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d500 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"y = insertvalue { i64, ptr } " }>, align 8
@.d501 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"x, ptr " }>, align 8
@.d502 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"q, 1\0A  store { i64, ptr } " }>, align 8
@.d503 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"y, ptr " }>, align 8
@.d504 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d505 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  br label %" }>, align 8
@.d506 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d507 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"e:\0A" }>, align 8
@.d508 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d509 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d510 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d511 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trunc " }>, align 8
@.d512 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d513 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d514 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d515 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d516 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d517 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Neg" }>, align 8
@.d518 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitNot" }>, align 8
@.d519 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Not" }>, align 8
@.d520 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Add" }>, align 8
@.d521 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Sub" }>, align 8
@.d522 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Mul" }>, align 8
@.d523 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Div" }>, align 8
@.d524 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Rem" }>, align 8
@.d525 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shl" }>, align 8
@.d526 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shr" }>, align 8
@.d527 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitAnd" }>, align 8
@.d528 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.BitOr" }>, align 8
@.d529 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitXor" }>, align 8
@.d530 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Eq" }>, align 8
@.d531 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ne" }>, align 8
@.d532 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Lt" }>, align 8
@.d533 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Le" }>, align 8
@.d534 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Gt" }>, align 8
@.d535 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ge" }>, align 8
@.d536 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Same" }>, align 8
@.d537 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Convert" }>, align 8
@.d538 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Bitcast" }>, align 8
@.d539 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Len" }>, align 8
@.d540 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.IsCase" }>, align 8
@.d541 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicLoad" }>, align 8
@.d542 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AtomicStore" }>, align 8
@.d543 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.AtomicAdd" }>, align 8
@.d544 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicSwap" }>, align 8
@.d545 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"PrimOp.AtomicCompareSwap" }>, align 8
@.d546 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.Retire" }>, align 8
@.d547 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Destroy" }>, align 8
@.d548 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"PrimOp.LeadingZeros" }>, align 8
@.d549 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"PrimOp.TrailingZeros" }>, align 8
@.d550 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.PopCount" }>, align 8
@.d551 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.RotateLeft" }>, align 8
@.d552 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.RotateRight" }>, align 8
@.d553 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ByteSwap" }>, align 8
@.d554 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.Holds" }>, align 8
@.d555 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.LaneLen" }>, align 8
@.d556 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.NonEmpty" }>, align 8
@.d557 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.AnyMake" }>, align 8
@.d558 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AnyInstance" }>, align 8
@.d559 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.AnyIs" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b7cf39b9bc6342b8_b5524b9e4a088564 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i1 %a2, i64 %a3, i64 %a4, ptr %a5, i64 %a6, ptr %a7, i64 %a8)
declare %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Object" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignatureText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2854570d7fadf599_61afc1034d008305 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9506350913203bfc_41d6488afcc367c0 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2a2725b2da5e1bad_47abef39162bd051 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_aa85ef0c362238c9_b248055339837d6d = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathInexact = external constant <{ ptr }>
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2femit_2efnTypeOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39 = external constant [0 x i8]
@olang_loc_fd5758dba8282ae8_cbed788f914882ac = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ccff4b50b9448573_2ea1a60810f956ef = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4e101a65701de364_bb0ca6f6f49ef738 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7181fb99348382a8_4bd06d378e143a0c = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d166383632e6ec4e_5cd1ec2f29a4b0f2 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1, { i64, ptr } %a2, i32 %a3)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_9199a3ab2b5d08f_bd3a4c654376a573 = external constant [0 x i8]
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4 = external constant [0 x i8]
@olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757 = external constant [0 x i8]
@olang_loc_dde810cb192bdc32_ece13dbcfe1403b6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c0167577194c5569_3f3b475069b70a4d = external constant [0 x i8]
@olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c = external constant [0 x i8]
@olang_loc_d4e74db3ab2eecf_2f1d311192c757bb = external constant [0 x i8]
@olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7d1301c542cf69c7_2a1b7d2f181cc69b = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
@olang_loc_9185a77390ef7566_ed985a49c11fac9a = external constant [0 x i8]
@olang_loc_b58edc65c6718b49_26c0578031dccca5 = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %a0)
@olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b = external constant [0 x i8]
@olang_loc_a90a878cc09c574e_a9a55cce621e609a = external constant [0 x i8]
declare %"compiler/mir:Place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9287686e475a7dbe_ea834ed677e35522 = external constant [0 x i8]
@olang_loc_45f21d64bb841654_8b47099e9550bca0 = external constant [0 x i8]
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, i1 %a3, { i64, ptr } %a4, i32 %a5, i64 %a6, %"compiler/mir:Task" %a7, i32 %a8, { i64, ptr } %a9)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %v0)
@G_2ecompiler_2femit_2etbaaField = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\3D\00\00\00\00\00\00\00\3E\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\41\00\00\00\00\00\00\00\42\00\00\00\00\00\00\00\43\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
declare void @compiler_2femit_2ePartSize_2einit()
declare void @compiler_2femit_2eHomeShared_2einit()
declare void @compiler_2femit_2eHomeLocal_2einit()
declare void @compiler_2femit_2eHomeInst_2einit()
declare void @compiler_2femit_2eHomeLoc_2einit()
declare void @compiler_2femit_2etbaaName_2einit()
declare void @compiler_2femit_2etbaaElem_2einit()
declare void @compiler_2femit_2etbaaTree_2einit()
declare void @compiler_2femit_2ehexDigits_2einit()
declare void @compiler_2femit_2emathExact_2einit()
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
