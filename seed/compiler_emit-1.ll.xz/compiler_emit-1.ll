; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
define dso_local void @compiler_2femit_2ePartSizeDev_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 524288, ptr @G_2ecompiler_2femit_2ePartSizeDev, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 2, ptr @.d0 }, 1
  %t3 = extractvalue { i64, ptr } { i64 2, ptr @.d0 }, 0
  %t5 = sext i32 %a0 to i64
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t5)
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t5)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l27 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %s1, ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %t10
  store ptr %t10, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s1, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b7cf39b9bc6342b8_b5524b9e4a088564)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t41
  %t46 = load i64, ptr %t45, !tbaa !34
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/lower:Lowerer", ptr %t51, i32 0, i32 1
  %t57 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t53, i64 %t46)
  store ptr %t57, ptr %l34
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 1
  %t61 = load { i64, [2 x i64] }, ptr %t60
  store { i64, [2 x i64] } %t61, ptr %l8
  %t63 = load { i64, [2 x i64] }, ptr %l8
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 0
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t69 = getelementptr { i64 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l9, !tbaa !24
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t72 = load ptr, ptr %lp1
  store ptr %t72, ptr %l40, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/emit:Emitter", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t81, i64 %t82)
  store i64 %t85, ptr %l47
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = load i64, ptr %l47, !tbaa !24
  %t88 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t86, i64 %t87)
  store ptr %t88, ptr %l48
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load ptr, ptr %l41, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t93, i32 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb20
bb20:
  %t96 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t97, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } %t101, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_bd540bd6a40c6889_fa12f95675f29f55)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb10
bb29:
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l5, !tbaa !24
  %t119 = add i64 %t115, %t116
  store i64 %t119, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb3
bb31:
  call void @__olang_scope_close(ptr %s1)
  %t121 = load ptr, ptr %lp1
  %t122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t121
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/emit:Reused"
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/emit:Reused"
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %lp41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l91 = alloca %"compiler/emit:Object"
  %l93 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l109 = alloca { i64, ptr }
  %l121 = alloca i32
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l154 = alloca i64
  %l157 = alloca i1
  %l161 = alloca i1
  %l165 = alloca i1
  %l167 = alloca i64
  %l171 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i32
  %l191 = alloca { i64, ptr }
  %l197 = alloca i1
  %l208 = alloca i1
  %l215 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca i32
  %l228 = alloca { i64, ptr }
  %l234 = alloca i1
  %l235 = alloca i1
  %l247 = alloca i1
  %l250 = alloca i1
  %l258 = alloca i64
  %l262 = alloca i64
  %l265 = alloca i64
  %l286 = alloca i64
  %l290 = alloca i64
  %l291 = alloca i32
  %l296 = alloca ptr
  %l302 = alloca %"compiler/emit:Object"
  %l308 = alloca i1
  %l310 = alloca %"compiler/emit:Reused"
  %l314 = alloca ptr
  %l316 = alloca i64
  %l319 = alloca i64
  %l323 = alloca i64
  %l326 = alloca i64
  %l347 = alloca i64
  %l350 = alloca ptr
  %l351 = alloca i64
  %l355 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l361 = alloca ptr
  %l364 = alloca ptr
  %l377 = alloca i64
  %l381 = alloca i64
  %l384 = alloca i64
  %l403 = alloca ptr
  %l406 = alloca %"compiler/emit:Object"
  %l411 = alloca ptr
  %l414 = alloca %"compiler/emit:Object"
  %l428 = alloca { i64, ptr }
  %l431 = alloca { i64, ptr }
  %l432 = alloca i32
  %l441 = alloca { i64, ptr }
  %l446 = alloca ptr
  %l448 = alloca { i64, ptr }
  %l452 = alloca { i64, ptr }
  %l455 = alloca ptr
  %l473 = alloca ptr
  %l474 = alloca ptr
  %l477 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l63
  br label %bb2
bb2:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t5, ptr %lp1
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  %t7 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:Emitter", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 5
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l2
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/emit:Emitter", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 7
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 38
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:Emitter", ptr %t35, i32 0, i32 5
  %t38 = load i1, ptr %t37, !tbaa !21
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb4:
  br label %bb13
bb5:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %t42)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t44 = load ptr, ptr %lp1
  store ptr %t44, ptr %l78, !tbaa !29
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t45)
  store ptr %t48, ptr %l81
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l81, !tbaa !29
  %t51 = getelementptr %"compiler/load:Module", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = extractvalue { i64, ptr } %t52, 0
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t54, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l85, !tbaa !27
  store i32 0, ptr %l86
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l3, !tbaa !24
  %t70 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t66, i64 %t67, i1 true, i64 0, i64 1, ptr null, i64 -1, ptr null, i64 -1)
  store { i64, ptr } %t70, ptr %l89
  br label %bb10
bb10:
  %t71 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t79 = load i32, ptr %l86
  %t81 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t78, i32 %t79, { i64, ptr } %t77)
  store %"compiler/emit:Object" %t81, ptr %l91
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l78, !tbaa !29
  %t83 = load %"compiler/emit:Object", ptr %l91
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t82, %"compiler/emit:Object" %t83)
  br label %bb12
bb12:
  %t84 = load ptr, ptr %lp1
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t84
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %rv
  br label %ret
bb13:
  %t87 = load ptr, ptr @__olang_prog_scope
  %t88 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t87)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l93
  br label %bb14
bb14:
  %t89 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %l4
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 17
  store ptr %t92, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l100
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb17, label %ok.102
ok.102:
  store { i64, ptr } %t99, ptr %l99
  br label %bb16
bb16:
  %t103 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t103, ptr %l96, !tbaa !27
  br label %bb21
bb17:
  %t104 = load i32, ptr %l100, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e19c419b1337c5fa_618f10f3ec8a7f5e)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb21:
  %t109 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t109, ptr %l7, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t122, ptr %l109, !tbaa !27
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i64, ptr %t126, i64 %t123
  %t128 = load i64, ptr %t127, !tbaa !34
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t128, i1 true)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t133 = load i64, ptr %l9, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l9, !tbaa !24
  br label %bb22
bb28:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = add i64 %t137, %t138
  store i64 %t141, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  br label %bb15
bb30:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/emit:Emitter", ptr %t143, i32 0, i32 4
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb31, label %bb32
bb31:
  store i32 2, ptr %l121
  br label %bb33
bb32:
  store i32 1, ptr %l121
  br label %bb33
bb33:
  %t150 = load i32, ptr %l121
  store i32 %t150, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/emit:Emitter", ptr %t151, i32 0, i32 15
  %t155 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t153)
  store i64 %t155, ptr %l126
  br label %bb34
bb34:
  %t156 = load i64, ptr %l126, !tbaa !24
  store i64 %t156, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = icmp sgt i64 %t157, %t158
  br i1 %t161, label %bb35, label %bb36
bb35:
  %t163 = load i64, ptr %l15, !tbaa !24
  %t165 = icmp sgt i64 %t163, 0
  br i1 %t165, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb40
bb37:
  %t167 = load i64, ptr %l14, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = add i64 %t171, %t172
  %t177 = sub i64 %t175, 1
  %t178 = load i64, ptr %l15, !tbaa !24
  %t181 = sdiv i64 %t177, %t178
  store i64 %t181, ptr %l133, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb39
bb39:
  %t183 = load i64, ptr %l133, !tbaa !24
  store i64 %t183, ptr %l130, !tbaa !24
  br label %bb40
bb40:
  %t184 = load i64, ptr %l130, !tbaa !24
  store i64 %t184, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = icmp slt i64 %t185, %t186
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb43:
  br label %bb44
bb44:
  %t193 = load i64, ptr %l13, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = load i64, ptr %l15, !tbaa !24
  %t198 = mul i64 %t194, %t195
  %t201 = add i64 %t193, %t198
  store i64 %t201, ptr %l18, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/emit:Emitter", ptr %t203, i32 0, i32 17
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t205, i64 %t206)
  store i64 %t209, ptr %l154
  br label %bb45
bb45:
  %t210 = load i64, ptr %l154, !tbaa !24
  store i64 %t210, ptr %l19, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb48
bb47:
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t219 = icmp eq i64 %t215, %t216
  store i1 %t219, ptr %l157, !tbaa !21
  br label %bb48
bb48:
  %t221 = load i1, ptr %l157, !tbaa !21
  br i1 %t221, label %bb49, label %bb50
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/emit:Emitter", ptr %t222, i32 0, i32 61
  %t225 = load i64, ptr %l19, !tbaa !24
  %t228 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i1 %t228, ptr %l165
  br label %bb51
bb50:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb52
bb51:
  %t229 = load i1, ptr %l165, !tbaa !21
  %t230 = xor i1 %t229, true
  store i1 %t230, ptr %l161, !tbaa !21
  br label %bb52
bb52:
  %t232 = load i1, ptr %l161, !tbaa !21
  br i1 %t232, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t233 = load i64, ptr %l12, !tbaa !24
  store i64 %t233, ptr %l167, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/emit:Emitter", ptr %t234, i32 0, i32 16
  %t237 = load i64, ptr %l18, !tbaa !24
  %t240 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s10, ptr %t236, i64 %t237)
  store { i64, ptr } %t240, ptr %l171
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t241 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = load i64, ptr %l167, !tbaa !24
  %t245 = add i64 %t243, %t242
  store i64 %t245, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t247 = load i64, ptr %l17, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l17, !tbaa !24
  br label %bb41
bb58:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/emit:Emitter", ptr %t251, i32 0, i32 60
  store ptr %t253, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s13
  %t255 = load ptr, ptr %l20, !tbaa !29
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t255, i64 %t256)
  %t260 = extractvalue { i32, { i64, ptr } } %t259, 1
  %t261 = extractvalue { i32, { i64, ptr } } %t259, 0
  store i32 %t261, ptr %l182
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb61, label %ok.263
ok.263:
  store { i64, ptr } %t260, ptr %l181
  br label %bb60
bb60:
  %t264 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t264, ptr %l178, !tbaa !27
  br label %bb65
bb61:
  %t265 = load i32, ptr %l182, !tbaa !23
  %t266 = ashr i32 %t265, 16
  %t268 = icmp eq i32 %t266, 1
  br i1 %t268, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_903aaa7827cdea7b_7e0f2a3cd8c84bdf)
  unreachable
bb64:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb77
bb65:
  %t270 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t270, ptr %l22, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  store i64 %t273, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s14
  %t275 = load i64, ptr %l24, !tbaa !24
  %t276 = load i64, ptr %l23, !tbaa !24
  %t279 = icmp slt i64 %t275, %t276
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t283 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t283, ptr %l191, !tbaa !27
  %t284 = load i64, ptr %l24, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr %"compiler/emit:Reused", ptr %t287, i64 %t284
  %t289 = load %"compiler/emit:Reused", ptr %t288
  store %"compiler/emit:Reused" %t289, ptr %l25
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/emit:Emitter", ptr %t291, i32 0, i32 61
  %t294 = getelementptr %"compiler/emit:Reused", ptr %l25, i32 0, i32 0
  %t295 = load i64, ptr %t294, !tbaa !24
  %t298 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t293, i64 %t295)
  store i1 %t298, ptr %l197
  br label %bb70
bb70:
  %t299 = load i1, ptr %l197, !tbaa !21
  br i1 %t299, label %bb71, label %bb72
bb71:
  %t300 = load i64, ptr %l12, !tbaa !24
  %t301 = getelementptr %"compiler/emit:Reused", ptr %l25, i32 0, i32 4
  %t302 = load i64, ptr %t301, !tbaa !24
  %t305 = add i64 %t300, %t302
  store i64 %t305, ptr %l12, !tbaa !24
  br label %bb73
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s14)
  br label %bb74
bb74:
  %t307 = load i64, ptr %l24, !tbaa !24
  %t309 = add i64 %t307, 1
  store i64 %t309, ptr %l24, !tbaa !24
  br label %bb66
bb75:
  %t311 = load i64, ptr %l21, !tbaa !24
  %t312 = load i64, ptr %l23, !tbaa !24
  %t315 = add i64 %t311, %t312
  store i64 %t315, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb76
bb76:
  br label %bb59
bb77:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/emit:Emitter", ptr %t317, i32 0, i32 5
  %t320 = load i1, ptr %t319, !tbaa !21
  br i1 %t320, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb80
bb79:
  %t322 = load i64, ptr %l12, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/emit:Emitter", ptr %t323, i32 0, i32 39
  %t326 = load i64, ptr %t325, !tbaa !24
  %t329 = icmp sge i64 %t322, %t326
  store i1 %t329, ptr %l208, !tbaa !21
  br label %bb80
bb80:
  %t331 = load i1, ptr %l208, !tbaa !21
  store i1 %t331, ptr %l26, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/emit:Emitter", ptr %t332, i32 0, i32 60
  store ptr %t334, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t336 = load ptr, ptr %l27, !tbaa !29
  %t337 = load i64, ptr %l28, !tbaa !24
  %t340 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t336, i64 %t337)
  %t341 = extractvalue { i32, { i64, ptr } } %t340, 1
  %t342 = extractvalue { i32, { i64, ptr } } %t340, 0
  store i32 %t342, ptr %l219
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb83, label %ok.344
ok.344:
  store { i64, ptr } %t341, ptr %l218
  br label %bb82
bb82:
  %t345 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t345, ptr %l215, !tbaa !27
  br label %bb87
bb83:
  %t346 = load i32, ptr %l219, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  br i1 %t349, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_913058ce5338c700_ff17fcf7b48c01a4)
  unreachable
bb86:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb87:
  %t351 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t351, ptr %l29, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s19
  %t356 = load i64, ptr %l31, !tbaa !24
  %t357 = load i64, ptr %l30, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s19)
  br label %bb100
bb90:
  br label %bb91
bb91:
  %t364 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t364, ptr %l228, !tbaa !27
  %t365 = load i64, ptr %l31, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr %"compiler/emit:Reused", ptr %t368, i64 %t365
  %t370 = load %"compiler/emit:Reused", ptr %t369
  store %"compiler/emit:Reused" %t370, ptr %l32
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/emit:Emitter", ptr %t372, i32 0, i32 61
  %t375 = getelementptr %"compiler/emit:Reused", ptr %l32, i32 0, i32 0
  %t376 = load i64, ptr %t375, !tbaa !24
  %t379 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t374, i64 %t376)
  store i1 %t379, ptr %l234
  br label %bb92
bb92:
  %t380 = load i1, ptr %l234, !tbaa !21
  br i1 %t380, label %bb93, label %bb94
bb93:
  %t381 = getelementptr %"compiler/emit:Reused", ptr %l32, i32 0, i32 5
  %t382 = load i1, ptr %t381, !tbaa !21
  %t383 = load i1, ptr %l26, !tbaa !21
  %t386 = icmp ne i1 %t382, %t383
  store i1 %t386, ptr %l235, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb95
bb95:
  %t388 = load i1, ptr %l235, !tbaa !21
  br i1 %t388, label %bb96, label %bb97
bb96:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/emit:Emitter", ptr %t389, i32 0, i32 63
  store i1 true, ptr %t391, !tbaa !21
  %t392 = load ptr, ptr %lp1
  %t393 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t392
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t393, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s19)
  br label %bb99
bb99:
  %t395 = load i64, ptr %l31, !tbaa !24
  %t397 = add i64 %t395, 1
  store i64 %t397, ptr %l31, !tbaa !24
  br label %bb88
bb100:
  %t399 = load i64, ptr %l28, !tbaa !24
  %t400 = load i64, ptr %l30, !tbaa !24
  %t403 = add i64 %t399, %t400
  store i64 %t403, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  br label %bb81
bb102:
  %t405 = load i1, ptr %l26, !tbaa !21
  br i1 %t405, label %bb103, label %bb104
bb103:
  %t407 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t410 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t407)
  store i1 %t410, ptr %l250
  br label %bb105
bb104:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb106
bb105:
  %t411 = load i1, ptr %l250, !tbaa !21
  store i1 %t411, ptr %l247, !tbaa !21
  br label %bb106
bb106:
  %t412 = load i1, ptr %l247, !tbaa !21
  store i1 %t412, ptr %l33, !tbaa !21
  %t413 = load i1, ptr %l33, !tbaa !21
  br i1 %t413, label %bb107, label %bb108
bb107:
  %t415 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroups(ptr %v0, ptr %t415)
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/emit:Emitter", ptr %t417, i32 0, i32 5
  %t420 = load i1, ptr %t419, !tbaa !21
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb111, label %bb112
bb111:
  %t424 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %t424)
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb114
bb114:
  store i64 0, ptr %l34, !tbaa !24
  %t427 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l2)
  store i64 %t427, ptr %l258
  br label %bb115
bb115:
  %t428 = load i64, ptr %l258, !tbaa !24
  store i64 %t428, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t429 = load i64, ptr %l35, !tbaa !24
  %t430 = load i64, ptr %l34, !tbaa !24
  %t433 = icmp sgt i64 %t429, %t430
  br i1 %t433, label %bb116, label %bb117
bb116:
  %t435 = load i64, ptr %l36, !tbaa !24
  %t437 = icmp sgt i64 %t435, 0
  br i1 %t437, label %bb118, label %bb119
bb117:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb121
bb118:
  %t439 = load i64, ptr %l35, !tbaa !24
  %t440 = load i64, ptr %l34, !tbaa !24
  %t443 = sub i64 %t439, %t440
  %t444 = load i64, ptr %l36, !tbaa !24
  %t447 = add i64 %t443, %t444
  %t449 = sub i64 %t447, 1
  %t450 = load i64, ptr %l36, !tbaa !24
  %t453 = sdiv i64 %t449, %t450
  store i64 %t453, ptr %l265, !tbaa !24
  br label %bb120
bb119:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb120
bb120:
  %t455 = load i64, ptr %l265, !tbaa !24
  store i64 %t455, ptr %l262, !tbaa !24
  br label %bb121
bb121:
  %t456 = load i64, ptr %l262, !tbaa !24
  store i64 %t456, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s25
  %t457 = load i64, ptr %l38, !tbaa !24
  %t458 = load i64, ptr %l37, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  br label %bb184
bb124:
  br label %bb125
bb125:
  %t465 = load i64, ptr %l34, !tbaa !24
  %t466 = load i64, ptr %l38, !tbaa !24
  %t467 = load i64, ptr %l36, !tbaa !24
  %t470 = mul i64 %t466, %t467
  %t473 = add i64 %t465, %t470
  store i64 %t473, ptr %l39, !tbaa !24
  %t475 = load i64, ptr %l39, !tbaa !24
  %t476 = load i64, ptr %l3, !tbaa !24
  %t479 = icmp eq i64 %t475, %t476
  br i1 %t479, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s25)
  br label %bb183
bb127:
  br label %bb128
bb128:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/emit:Emitter", ptr %t481, i32 0, i32 61
  %t484 = load i64, ptr %l39, !tbaa !24
  %t487 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t483, i64 %t484)
  %t488 = extractvalue { i32, i64 } %t487, 1
  %t489 = extractvalue { i32, i64 } %t487, 0
  store i32 %t489, ptr %l291
  %t490 = icmp ne i32 %t489, 0
  br i1 %t490, label %bb130, label %ok.491
ok.491:
  store i64 %t488, ptr %l290
  br label %bb129
bb129:
  %t492 = load i64, ptr %l290, !tbaa !24
  store i64 %t492, ptr %l286, !tbaa !24
  br label %bb132
bb130:
  br label %bb131
bb131:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l286, !tbaa !24
  br label %bb132
bb132:
  %t493 = load i64, ptr %l286, !tbaa !24
  store i64 %t493, ptr %l40, !tbaa !24
  %t494 = load i64, ptr %l40, !tbaa !24
  %t496 = icmp sge i64 %t494, 0
  br i1 %t496, label %bb133, label %bb134
bb133:
  %t498 = load i64, ptr %l39, !tbaa !24
  %t501 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t498)
  store ptr %t501, ptr %l296
  br label %bb135
bb134:
  %t502 = load i64, ptr %l39, !tbaa !24
  %t505 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t502)
  store i1 %t505, ptr %l308
  br label %bb138
bb135:
  %t506 = load ptr, ptr %l296, !tbaa !29
  %t508 = getelementptr %"compiler/load:Module", ptr %t506, i32 0, i32 2
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t509, 1
  %t512 = extractvalue { i64, ptr } %t509, 0
  %t513 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t512)
  call void @olang_textcopy(ptr %t513, ptr %t511, i64 %t512)
  %t514 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t515 = insertvalue { i64, ptr } %t514, ptr %t513, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = extractvalue { i64, ptr } %t515, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t525 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t522, i32 0, { i64, ptr } { i64 0, ptr @.d1 })
  store %"compiler/emit:Object" %t525, ptr %l302
  br label %bb136
bb136:
  %t526 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t526, ptr %lp41
  %t527 = load %"compiler/emit:Object", ptr %l302
  %t528 = load ptr, ptr %lp41
  store %"compiler/emit:Object" %t527, ptr %t528
  %t529 = load i64, ptr %l40, !tbaa !24
  %t531 = load ptr, ptr %lp41
  %t532 = getelementptr %"compiler/emit:Object", ptr %t531, i32 0, i32 3
  store i64 %t529, ptr %t532, !tbaa !24
  %t533 = load ptr, ptr %lp1
  %t534 = load ptr, ptr %lp41
  %t535 = load %"compiler/emit:Object", ptr %t534
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t533, %"compiler/emit:Object" %t535)
  br label %bb137
bb137:
  br label %bb182
bb138:
  %t538 = load i1, ptr %l308, !tbaa !21
  br i1 %t538, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s30
  %t539 = load i64, ptr %l39, !tbaa !24
  %t541 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %t539)
  store %"compiler/emit:Reused" %t541, ptr %l310
  br label %bb141
bb140:
  br label %bb181
bb141:
  %t542 = load %"compiler/emit:Reused", ptr %l310
  %t543 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/emit:Reused" %t542, ptr %t543
  store ptr %t543, ptr %l42, !tbaa !29
  %t545 = load ptr, ptr %l42, !tbaa !29
  %t546 = load i1, ptr %l26, !tbaa !21
  %t549 = getelementptr %"compiler/emit:Reused", ptr %t545, i32 0, i32 5
  store i1 %t546, ptr %t549, !tbaa !21
  %t550 = load ptr, ptr %l42, !tbaa !29
  store ptr %t550, ptr %l314, !tbaa !29
  %t551 = load ptr, ptr %lp1
  %t553 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %t551)
  store i64 %t553, ptr %l316
  br label %bb142
bb142:
  %t554 = load i64, ptr %l316, !tbaa !24
  %t555 = load ptr, ptr %l314, !tbaa !29
  %t556 = getelementptr %"compiler/emit:Reused", ptr %t555, i32 0, i32 7
  store i64 %t554, ptr %t556, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/emit:Emitter", ptr %t557, i32 0, i32 15
  %t561 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t559)
  store i64 %t561, ptr %l319
  br label %bb143
bb143:
  %t562 = load i64, ptr %l319, !tbaa !24
  store i64 %t562, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t563 = load i64, ptr %l44, !tbaa !24
  %t564 = load i64, ptr %l43, !tbaa !24
  %t567 = icmp sgt i64 %t563, %t564
  br i1 %t567, label %bb144, label %bb145
bb144:
  %t569 = load i64, ptr %l45, !tbaa !24
  %t571 = icmp sgt i64 %t569, 0
  br i1 %t571, label %bb146, label %bb147
bb145:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb149
bb146:
  %t573 = load i64, ptr %l44, !tbaa !24
  %t574 = load i64, ptr %l43, !tbaa !24
  %t577 = sub i64 %t573, %t574
  %t578 = load i64, ptr %l45, !tbaa !24
  %t581 = add i64 %t577, %t578
  %t583 = sub i64 %t581, 1
  %t584 = load i64, ptr %l45, !tbaa !24
  %t587 = sdiv i64 %t583, %t584
  store i64 %t587, ptr %l326, !tbaa !24
  br label %bb148
bb147:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb148
bb148:
  %t589 = load i64, ptr %l326, !tbaa !24
  store i64 %t589, ptr %l323, !tbaa !24
  br label %bb149
bb149:
  %t590 = load i64, ptr %l323, !tbaa !24
  store i64 %t590, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s32
  %t591 = load i64, ptr %l47, !tbaa !24
  %t592 = load i64, ptr %l46, !tbaa !24
  %t595 = icmp slt i64 %t591, %t592
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s32)
  br label %bb160
bb152:
  br label %bb153
bb153:
  %t599 = load i64, ptr %l43, !tbaa !24
  %t600 = load i64, ptr %l47, !tbaa !24
  %t601 = load i64, ptr %l45, !tbaa !24
  %t604 = mul i64 %t600, %t601
  %t607 = add i64 %t599, %t604
  store i64 %t607, ptr %l48, !tbaa !24
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/emit:Emitter", ptr %t609, i32 0, i32 17
  %t612 = load i64, ptr %l48, !tbaa !24
  %t615 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t611, i64 %t612)
  store i64 %t615, ptr %l347
  br label %bb154
bb154:
  %t616 = load i64, ptr %l39, !tbaa !24
  %t617 = load i64, ptr %l347, !tbaa !24
  %t619 = icmp eq i64 %t617, %t616
  br i1 %t619, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s33
  %t621 = load ptr, ptr %l42, !tbaa !29
  store ptr %t621, ptr %l350, !tbaa !29
  %t622 = load ptr, ptr %l350, !tbaa !29
  %t623 = getelementptr %"compiler/emit:Reused", ptr %t622, i32 0, i32 4
  %t624 = load i64, ptr %t623, !tbaa !24
  store i64 %t624, ptr %l351, !tbaa !24
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/emit:Emitter", ptr %t625, i32 0, i32 16
  %t628 = load i64, ptr %l48, !tbaa !24
  %t631 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s33, ptr %t627, i64 %t628)
  store { i64, ptr } %t631, ptr %l355
  br label %bb157
bb156:
  br label %bb158
bb157:
  %t632 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 0
  %t634 = load i64, ptr %l351, !tbaa !24
  %t636 = add i64 %t634, %t633
  %t638 = load ptr, ptr %l350, !tbaa !29
  %t639 = getelementptr %"compiler/emit:Reused", ptr %t638, i32 0, i32 4
  store i64 %t636, ptr %t639, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s32)
  br label %bb159
bb159:
  %t640 = load i64, ptr %l47, !tbaa !24
  %t642 = add i64 %t640, 1
  store i64 %t642, ptr %l47, !tbaa !24
  br label %bb150
bb160:
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l360, !tbaa !29
  %t645 = load ptr, ptr %lp1
  store ptr %t645, ptr %l361, !tbaa !29
  %t646 = load i64, ptr %l39, !tbaa !24
  %t649 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t646)
  store ptr %t649, ptr %l364
  br label %bb161
bb161:
  %t650 = load ptr, ptr %l364, !tbaa !29
  %t652 = getelementptr %"compiler/load:Module", ptr %t650, i32 0, i32 2
  %t653 = load { i64, ptr }, ptr %t652, !tbaa !27
  %t655 = extractvalue { i64, ptr } %t653, 1
  %t656 = extractvalue { i64, ptr } %t653, 0
  %t657 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t656)
  call void @olang_textcopy(ptr %t657, ptr %t655, i64 %t656)
  %t658 = insertvalue { i64, ptr } undef, i64 %t656, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = extractvalue { i64, ptr } %t659, 1
  %t663 = mul i64 %t661, 1
  %t664 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t663)
  call void @llvm.memcpy.p0.p0.i64(ptr %t664, ptr %t662, i64 %t663, i1 false)
  %t665 = insertvalue { i64, ptr } undef, i64 %t661, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t664, 1
  %t667 = load i64, ptr %l39, !tbaa !24
  %t668 = load i1, ptr %l26, !tbaa !21
  %t669 = load ptr, ptr %l42, !tbaa !29
  %t671 = getelementptr %"compiler/emit:Reused", ptr %t669, i32 0, i32 6
  %t672 = load ptr, ptr %l360, !tbaa !29
  %t673 = load ptr, ptr %l361, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s30, ptr %v0, ptr %t672, ptr %t673, { i64, ptr } %t666, i32 0, i64 %t667, i1 false, i1 %t668, ptr %t671, i64 -1)
  br label %bb162
bb162:
  %t679 = load ptr, ptr %l42, !tbaa !29
  %t681 = getelementptr %"compiler/emit:Reused", ptr %t679, i32 0, i32 7
  %t682 = load i64, ptr %t681, !tbaa !24
  store i64 %t682, ptr %l49, !tbaa !24
  %t684 = load ptr, ptr %lp1
  %t686 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %t684)
  store i64 %t686, ptr %l377
  br label %bb163
bb163:
  %t687 = load i64, ptr %l377, !tbaa !24
  store i64 %t687, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t688 = load i64, ptr %l50, !tbaa !24
  %t689 = load i64, ptr %l49, !tbaa !24
  %t692 = icmp sgt i64 %t688, %t689
  br i1 %t692, label %bb164, label %bb165
bb164:
  %t694 = load i64, ptr %l51, !tbaa !24
  %t696 = icmp sgt i64 %t694, 0
  br i1 %t696, label %bb166, label %bb167
bb165:
  store i64 0, ptr %l381, !tbaa !24
  br label %bb169
bb166:
  %t698 = load i64, ptr %l50, !tbaa !24
  %t699 = load i64, ptr %l49, !tbaa !24
  %t702 = sub i64 %t698, %t699
  %t703 = load i64, ptr %l51, !tbaa !24
  %t706 = add i64 %t702, %t703
  %t708 = sub i64 %t706, 1
  %t709 = load i64, ptr %l51, !tbaa !24
  %t712 = sdiv i64 %t708, %t709
  store i64 %t712, ptr %l384, !tbaa !24
  br label %bb168
bb167:
  store i64 0, ptr %l384, !tbaa !24
  br label %bb168
bb168:
  %t714 = load i64, ptr %l384, !tbaa !24
  store i64 %t714, ptr %l381, !tbaa !24
  br label %bb169
bb169:
  %t715 = load i64, ptr %l381, !tbaa !24
  store i64 %t715, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb170
bb170:
  store %olang.scope zeroinitializer, ptr %s37
  %t716 = load i64, ptr %l53, !tbaa !24
  %t717 = load i64, ptr %l52, !tbaa !24
  %t720 = icmp slt i64 %t716, %t717
  %t722 = xor i1 %t720, true
  br i1 %t722, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s37)
  br label %bb179
bb172:
  br label %bb173
bb173:
  %t724 = load i64, ptr %l49, !tbaa !24
  %t725 = load i64, ptr %l53, !tbaa !24
  %t726 = load i64, ptr %l51, !tbaa !24
  %t729 = mul i64 %t725, %t726
  %t732 = add i64 %t724, %t729
  store i64 %t732, ptr %l54, !tbaa !24
  %t734 = load ptr, ptr %l42, !tbaa !29
  %t736 = getelementptr %"compiler/emit:Reused", ptr %t734, i32 0, i32 1
  store ptr %t736, ptr %l403, !tbaa !29
  %t737 = load ptr, ptr %lp1
  %t738 = load i64, ptr %l54, !tbaa !24
  %t741 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t737, i64 %t738)
  store %"compiler/emit:Object" %t741, ptr %l406
  br label %bb174
bb174:
  %t742 = getelementptr %"compiler/emit:Object", ptr %l406, i32 0, i32 0
  %t743 = load { i64, ptr }, ptr %t742, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t743, 1
  %t746 = extractvalue { i64, ptr } %t743, 0
  %t747 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t746)
  call void @olang_textcopy(ptr %t747, ptr %t745, i64 %t746)
  %t748 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t749 = insertvalue { i64, ptr } %t748, ptr %t747, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = extractvalue { i64, ptr } %t749, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  %t757 = load ptr, ptr %l403, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t757, { i64, ptr } %t756)
  br label %bb175
bb175:
  %t759 = load ptr, ptr %l42, !tbaa !29
  %t761 = getelementptr %"compiler/emit:Reused", ptr %t759, i32 0, i32 2
  store ptr %t761, ptr %l411, !tbaa !29
  %t762 = load ptr, ptr %lp1
  %t763 = load i64, ptr %l54, !tbaa !24
  %t766 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %s37, ptr %t762, i64 %t763)
  store %"compiler/emit:Object" %t766, ptr %l414
  br label %bb176
bb176:
  %t767 = getelementptr %"compiler/emit:Object", ptr %l414, i32 0, i32 1
  %t768 = load i32, ptr %t767
  %t770 = trunc i64 4 to i32
  %t771 = icmp eq i32 %t768, %t770
  %t772 = load ptr, ptr %l411, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t772, i1 %t771)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s37)
  br label %bb178
bb178:
  %t774 = load i64, ptr %l53, !tbaa !24
  %t776 = add i64 %t774, 1
  store i64 %t776, ptr %l53, !tbaa !24
  br label %bb170
bb179:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t780 = getelementptr %"compiler/emit:Emitter", ptr %t778, i32 0, i32 62
  %t781 = load ptr, ptr %l42, !tbaa !29
  %t783 = load %"compiler/emit:Reused", ptr %t781
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t780, %"compiler/emit:Reused" %t783)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s30)
  br label %bb181
bb181:
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s25)
  br label %bb183
bb183:
  %t786 = load i64, ptr %l38, !tbaa !24
  %t788 = add i64 %t786, 1
  store i64 %t788, ptr %l38, !tbaa !24
  br label %bb122
bb184:
  %t790 = load i1, ptr %l33, !tbaa !21
  br i1 %t790, label %bb185, label %bb186
bb185:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/emit:Emitter", ptr %t792, i32 0, i32 67
  store ptr %t794, ptr %l55, !tbaa !29
  store i64 0, ptr %l56, !tbaa !24
  br label %bb187
bb186:
  br label %bb208
bb187:
  store %olang.scope zeroinitializer, ptr %s43
  %t796 = load ptr, ptr %l55, !tbaa !29
  %t797 = load i64, ptr %l56, !tbaa !24
  %t800 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t796, i64 %t797)
  %t801 = extractvalue { i32, { i64, ptr } } %t800, 1
  %t802 = extractvalue { i32, { i64, ptr } } %t800, 0
  store i32 %t802, ptr %l432
  %t803 = icmp ne i32 %t802, 0
  br i1 %t803, label %bb189, label %ok.804
ok.804:
  store { i64, ptr } %t801, ptr %l431
  br label %bb188
bb188:
  %t805 = load { i64, ptr }, ptr %l431, !tbaa !27
  store { i64, ptr } %t805, ptr %l428, !tbaa !27
  br label %bb193
bb189:
  %t806 = load i32, ptr %l432, !tbaa !23
  %t807 = ashr i32 %t806, 16
  %t809 = icmp eq i32 %t807, 1
  br i1 %t809, label %bb190, label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_1327b3efebd3a791_482154403c367095)
  unreachable
bb192:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s43)
  br label %bb207
bb193:
  %t811 = load { i64, ptr }, ptr %l428, !tbaa !27
  store { i64, ptr } %t811, ptr %l57, !tbaa !27
  %t812 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t812, 0
  store i64 %t814, ptr %l58, !tbaa !24
  store i64 0, ptr %l59, !tbaa !24
  br label %bb194
bb194:
  store %olang.scope zeroinitializer, ptr %s44
  %t816 = load i64, ptr %l59, !tbaa !24
  %t817 = load i64, ptr %l58, !tbaa !24
  %t820 = icmp slt i64 %t816, %t817
  %t822 = xor i1 %t820, true
  br i1 %t822, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s44)
  br label %bb205
bb196:
  br label %bb197
bb197:
  %t824 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t824, ptr %l441, !tbaa !27
  %t825 = load i64, ptr %l59, !tbaa !24
  %t827 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !27
  %t829 = getelementptr i64, ptr %t828, i64 %t825
  %t830 = load i64, ptr %t829, !tbaa !34
  store i64 %t830, ptr %l60, !tbaa !24
  %t832 = load i64, ptr %l3, !tbaa !24
  %t835 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t832)
  store ptr %t835, ptr %l446
  br label %bb198
bb198:
  %t836 = load ptr, ptr %l446, !tbaa !29
  %t838 = getelementptr %"compiler/load:Module", ptr %t836, i32 0, i32 2
  %t839 = load { i64, ptr }, ptr %t838, !tbaa !27
  store { i64, ptr } %t839, ptr %l448, !tbaa !27
  %t840 = load i64, ptr %l60, !tbaa !24
  %t841 = load i64, ptr %l3, !tbaa !24
  %t844 = icmp eq i64 %t840, %t841
  br i1 %t844, label %bb199, label %bb200
bb199:
  store { i64, ptr } { i64 0, ptr @.d2 }, ptr %l452, !tbaa !27
  br label %bb202
bb200:
  %t846 = load i64, ptr %l60, !tbaa !24
  %t849 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t846)
  store ptr %t849, ptr %l455
  br label %bb201
bb201:
  %t850 = load ptr, ptr %l455, !tbaa !29
  %t852 = getelementptr %"compiler/load:Module", ptr %t850, i32 0, i32 2
  %t853 = load { i64, ptr }, ptr %t852, !tbaa !27
  %t854 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t855 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t857 = extractvalue { i64, ptr } %t853, 1
  %t858 = extractvalue { i64, ptr } %t853, 0
  %t859 = add i64 %t855, %t858
  %t860 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t859)
  call void @olang_textcopy(ptr %t860, ptr %t854, i64 %t855)
  %t861 = getelementptr i8, ptr %t860, i64 %t855
  call void @olang_textcopy(ptr %t861, ptr %t857, i64 %t858)
  %t862 = insertvalue { i64, ptr } undef, i64 %t859, 0
  %t863 = insertvalue { i64, ptr } %t862, ptr %t860, 1
  %t865 = extractvalue { i64, ptr } %t863, 0
  %t866 = extractvalue { i64, ptr } %t863, 1
  %t867 = mul i64 %t865, 1
  %t868 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t867)
  call void @llvm.memcpy.p0.p0.i64(ptr %t868, ptr %t866, i64 %t867, i1 false)
  %t869 = insertvalue { i64, ptr } undef, i64 %t865, 0
  %t870 = insertvalue { i64, ptr } %t869, ptr %t868, 1
  store { i64, ptr } %t870, ptr %l452, !tbaa !27
  br label %bb202
bb202:
  %t872 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t872, 1
  %t874 = extractvalue { i64, ptr } %t872, 0
  %t875 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t876 = extractvalue { i64, ptr } %t875, 1
  %t877 = extractvalue { i64, ptr } %t875, 0
  %t878 = add i64 %t874, %t877
  %t879 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t878)
  call void @olang_textcopy(ptr %t879, ptr %t873, i64 %t874)
  %t880 = getelementptr i8, ptr %t879, i64 %t874
  call void @olang_textcopy(ptr %t880, ptr %t876, i64 %t877)
  %t881 = insertvalue { i64, ptr } undef, i64 %t878, 0
  %t882 = insertvalue { i64, ptr } %t881, ptr %t879, 1
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load ptr, ptr %lp1
  %t887 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t888 = load i1, ptr %l26, !tbaa !21
  %t889 = load i64, ptr %l60, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s44, ptr %s44, ptr %t884, ptr %t885, { i64, ptr } %t882, i32 3, i64 %t887, i1 false, i1 %t888, ptr null, i64 %t889)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s44)
  br label %bb204
bb204:
  %t897 = load i64, ptr %l59, !tbaa !24
  %t899 = add i64 %t897, 1
  store i64 %t899, ptr %l59, !tbaa !24
  br label %bb194
bb205:
  %t901 = load i64, ptr %l56, !tbaa !24
  %t902 = load i64, ptr %l58, !tbaa !24
  %t905 = add i64 %t901, %t902
  store i64 %t905, ptr %l56, !tbaa !24
  call void @__olang_scope_close(ptr %s43)
  br label %bb206
bb206:
  br label %bb187
bb207:
  br label %bb208
bb208:
  %t907 = load ptr, ptr %l0, !tbaa !29
  store ptr %t907, ptr %l473, !tbaa !29
  %t908 = load ptr, ptr %lp1
  store ptr %t908, ptr %l474, !tbaa !29
  %t909 = load i64, ptr %l3, !tbaa !24
  %t912 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l2, i64 %t909)
  store ptr %t912, ptr %l477
  br label %bb209
bb209:
  %t913 = load ptr, ptr %l477, !tbaa !29
  %t915 = getelementptr %"compiler/load:Module", ptr %t913, i32 0, i32 2
  %t916 = load { i64, ptr }, ptr %t915, !tbaa !27
  %t918 = extractvalue { i64, ptr } %t916, 1
  %t919 = extractvalue { i64, ptr } %t916, 0
  %t920 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t919)
  call void @olang_textcopy(ptr %t920, ptr %t918, i64 %t919)
  %t921 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t922 = insertvalue { i64, ptr } %t921, ptr %t920, 1
  %t924 = extractvalue { i64, ptr } %t922, 0
  %t925 = extractvalue { i64, ptr } %t922, 1
  %t926 = mul i64 %t924, 1
  %t927 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t926)
  call void @llvm.memcpy.p0.p0.i64(ptr %t927, ptr %t925, i64 %t926, i1 false)
  %t928 = insertvalue { i64, ptr } undef, i64 %t924, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t927, 1
  %t930 = load i32, ptr %l11
  %t931 = load i64, ptr %l3, !tbaa !24
  %t932 = load i1, ptr %l33, !tbaa !21
  %t934 = xor i1 %t932, true
  %t935 = load i1, ptr %l26, !tbaa !21
  %t936 = load ptr, ptr %l473, !tbaa !29
  %t937 = load ptr, ptr %l474, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t936, ptr %t937, { i64, ptr } %t929, i32 %t930, i64 %t931, i1 %t934, i1 %t935, ptr null, i64 -1)
  br label %bb210
bb210:
  %t943 = load ptr, ptr %lp1
  %t944 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t943
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t944, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i32, ptr %l14, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb12
bb12:
  %t63 = load i32, ptr %l41
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t68, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i32, ptr %l3, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l47
  br label %bb16
bb16:
  %t75 = load i32, ptr %l47
  %t77 = trunc i64 18 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l54
  br label %bb19
bb18:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb21
bb19:
  %t86 = load ptr, ptr %l51, !tbaa !29
  %t87 = load i32, ptr %l54, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t88, ptr %l55
  br label %bb20
bb20:
  %t89 = load i32, ptr %l55
  %t91 = trunc i64 4 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l50, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load i32, ptr %l3, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l61
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i32, ptr %l61, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l62
  br label %bb25
bb25:
  %t104 = load i32, ptr %l62, !tbaa !23
  store i32 %t104, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb26:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t105, ptr %rv
  br label %ret
bb27:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb8
bb28:
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecEntryDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i32
  %l111 = alloca i64
  %l117 = alloca i32
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l126 = alloca i32
  %l128 = alloca { i64, ptr }
  %l134 = alloca i32
  %l142 = alloca i32
  %l145 = alloca i1
  %l146 = alloca ptr
  %l149 = alloca i32
  %l150 = alloca i32
  %l153 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l183 = alloca i32
  %l187 = alloca i1
  %l191 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l203 = alloca i1
  %l206 = alloca i1
  %l207 = alloca ptr
  %l210 = alloca i32
  %l211 = alloca i32
  %l212 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l229 = alloca i64
  %l233 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l243 = alloca i64
  %l245 = alloca i64
  %l246 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l253 = alloca i64
  %l255 = alloca %"std/prelude/text:StringBuilder"
  %l256 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l268 = alloca i64
  %l272 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l276 = alloca i32
  %l286 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l305 = alloca i64
  %l306 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l39
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l39, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Func", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t15, i32 %t19)
  store { i64, ptr } %t22, ptr %l43
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t24, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l45
  br label %bb3
bb3:
  %t31 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l7
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l46, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l49
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l46, !tbaa !29
  %t39 = load i32, ptr %l49, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t40, ptr %l50
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb6, label %bb7
bb6:
  %t52 = load i64, ptr %l11, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb11
bb8:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l59, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb10
bb10:
  %t72 = load i64, ptr %l59, !tbaa !24
  store i64 %t72, ptr %l56, !tbaa !24
  br label %bb11
bb11:
  %t73 = load i64, ptr %l56, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load i64, ptr %l13, !tbaa !24
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb14:
  br label %bb15
bb15:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l14, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Sig", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t104 = icmp slt i64 %t92, %t101
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Func", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Sig", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l87, !tbaa !27
  %t114 = load i64, ptr %l14, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t121 = getelementptr %"compiler/ast:Param", ptr %t119, i32 0, i32 1
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t106, i32 %t122)
  store { i64, ptr } %t125, ptr %l91
  br label %bb18
bb17:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t130 = call i64 @__olang_fmt_i64(ptr null, i64 %t126)
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t127, i64 %t128)
  %t133 = getelementptr i8, ptr %t132, i64 %t128
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t126)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l83, !tbaa !27
  br label %bb19
bb18:
  %t138 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l83, !tbaa !27
  br label %bb19
bb19:
  %t145 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t145, ptr %l15, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t146, ptr %l95, !tbaa !27
  %t147 = load i64, ptr %l14, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  store i32 %t152, ptr %l16, !tbaa !23
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t155 = load i32, ptr %l16, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l100
  br label %bb20
bb20:
  %t159 = load i32, ptr %l100, !tbaa !23
  store i32 %t159, ptr %l17, !tbaa !23
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t161 = load i32, ptr %l17, !tbaa !23
  %t164 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l103
  br label %bb21
bb21:
  %t165 = load i1, ptr %l103, !tbaa !21
  br i1 %t165, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t166 = load ptr, ptr %l4, !tbaa !29
  store ptr %t166, ptr %l104, !tbaa !29
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t168 = load i32, ptr %l17, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l107
  br label %bb24
bb23:
  br label %bb58
bb24:
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t173 = load i32, ptr %l107, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t174, ptr %l108
  br label %bb25
bb25:
  %t175 = load i32, ptr %l108, !tbaa !23
  store i32 %t175, ptr %l18, !tbaa !23
  %t176 = load ptr, ptr %l4, !tbaa !29
  %t177 = load i32, ptr %l17, !tbaa !23
  %t180 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t176, i32 %t177)
  store i64 %t180, ptr %l111
  br label %bb26
bb26:
  %t181 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t182 = load i64, ptr %l111, !tbaa !24
  %t184 = and i64 %t182, %t181
  %t186 = icmp eq i64 %t184, 0
  store i1 %t186, ptr %l19, !tbaa !21
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t189 = load i32, ptr %l18, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l117
  br label %bb27
bb27:
  %t193 = load i32, ptr %l117
  %t195 = trunc i64 19 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l7, ptr %l120, !tbaa !29
  %t198 = load i1, ptr %l19, !tbaa !21
  br i1 %t198, label %bb30, label %bb31
bb29:
  br label %bb41
bb30:
  store { i64, ptr } { i64 6, ptr @.d5 }, ptr %l122, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr @.d6 }, ptr %l122, !tbaa !27
  br label %bb32
bb32:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l123, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t202 = load i32, ptr %l18, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l126
  br label %bb33
bb33:
  %t206 = load ptr, ptr %l3, !tbaa !29
  %t207 = load ptr, ptr %l123, !tbaa !29
  %t208 = load i32, ptr %l126, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s7, ptr %t207, i32 %t208, ptr %t206)
  store { i64, ptr } %t210, ptr %l128
  br label %bb34
bb34:
  %t211 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 2, ptr @.d7 }, 1
  %t220 = extractvalue { i64, ptr } { i64 2, ptr @.d7 }, 0
  %t221 = add i64 %t218, %t220
  %t223 = extractvalue { i64, ptr } %t211, 1
  %t224 = extractvalue { i64, ptr } %t211, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t213, i64 %t214)
  %t227 = getelementptr i8, ptr %t226, i64 %t214
  call void @olang_textcopy(ptr %t227, ptr %t216, i64 %t217)
  %t228 = getelementptr i8, ptr %t227, i64 %t217
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t223, i64 %t224)
  %t230 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t226, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb35
bb35:
  %t241 = load ptr, ptr %l4, !tbaa !29
  %t242 = load i32, ptr %l18, !tbaa !23
  %t245 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t241, i32 %t242)
  store i32 %t245, ptr %l134
  br label %bb36
bb36:
  %t246 = load i32, ptr %l134, !tbaa !23
  %t247 = icmp eq i32 %t246, 0
  br i1 %t247, label %bb37, label %bb38
bb37:
  %t249 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t250 = extractvalue { i64, ptr } { i64 8, ptr @.d8 }, 1
  %t251 = extractvalue { i64, ptr } { i64 8, ptr @.d8 }, 0
  %t253 = extractvalue { i64, ptr } %t249, 1
  %t254 = extractvalue { i64, ptr } %t249, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 4, ptr @.d9 }, 1
  %t257 = extractvalue { i64, ptr } { i64 4, ptr @.d9 }, 0
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t250, i64 %t251)
  %t260 = getelementptr i8, ptr %t259, i64 %t251
  call void @olang_textcopy(ptr %t260, ptr %t253, i64 %t254)
  %t261 = getelementptr i8, ptr %t260, i64 %t254
  call void @olang_textcopy(ptr %t261, ptr %t256, i64 %t257)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t259, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t270)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb41:
  %t273 = load ptr, ptr %l4, !tbaa !29
  %t274 = load i32, ptr %l18, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l142
  br label %bb42
bb42:
  %t278 = load i32, ptr %l142
  %t280 = trunc i64 18 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb43, label %bb44
bb43:
  %t283 = load ptr, ptr %l4, !tbaa !29
  store ptr %t283, ptr %l146, !tbaa !29
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t285 = load i32, ptr %l18, !tbaa !23
  %t288 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t284, i32 %t285)
  store i32 %t288, ptr %l149
  br label %bb45
bb44:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb47
bb45:
  %t289 = load ptr, ptr %l146, !tbaa !29
  %t290 = load i32, ptr %l149, !tbaa !23
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t289, i32 %t290)
  store i32 %t291, ptr %l150
  br label %bb46
bb46:
  %t292 = load i32, ptr %l150
  %t294 = trunc i64 5 to i32
  %t295 = icmp eq i32 %t292, %t294
  store i1 %t295, ptr %l145, !tbaa !21
  br label %bb47
bb47:
  %t297 = load i1, ptr %l145, !tbaa !21
  br i1 %t297, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l7, ptr %l153, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l16, !tbaa !23
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t304 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s11, ptr %t298, i32 %t299, ptr %t300)
  store { i64, ptr } %t304, ptr %l157
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t305 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t311 = add i64 %t308, %t310
  %t313 = extractvalue { i64, ptr } %t305, 1
  %t314 = extractvalue { i64, ptr } %t305, 0
  %t315 = add i64 %t311, %t314
  %t316 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t315)
  call void @olang_textcopy(ptr %t316, ptr %t307, i64 %t308)
  %t317 = getelementptr i8, ptr %t316, i64 %t308
  call void @olang_textcopy(ptr %t317, ptr %t309, i64 %t310)
  %t318 = getelementptr i8, ptr %t317, i64 %t310
  call void @olang_textcopy(ptr %t318, ptr %t313, i64 %t314)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t316, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t328, { i64, ptr } %t327)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb52:
  store ptr %l7, ptr %l161, !tbaa !29
  %t330 = load i1, ptr %l19, !tbaa !21
  br i1 %t330, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr @.d11 }, ptr %l163, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr @.d12 }, ptr %l163, !tbaa !27
  br label %bb55
bb55:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i32, ptr %l18, !tbaa !23
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t338 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s6, ptr %t332, i32 %t333, ptr %t334)
  store { i64, ptr } %t338, ptr %l167
  br label %bb56
bb56:
  %t339 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 1
  %t348 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t339, 1
  %t352 = extractvalue { i64, ptr } %t339, 0
  %t353 = add i64 %t349, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t341, i64 %t342)
  %t355 = getelementptr i8, ptr %t354, i64 %t342
  call void @olang_textcopy(ptr %t355, ptr %t344, i64 %t345)
  %t356 = getelementptr i8, ptr %t355, i64 %t345
  call void @olang_textcopy(ptr %t356, ptr %t347, i64 %t348)
  %t357 = getelementptr i8, ptr %t356, i64 %t348
  call void @olang_textcopy(ptr %t357, ptr %t351, i64 %t352)
  %t358 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t354, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } %t359, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t367 = load ptr, ptr %l161, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t367, { i64, ptr } %t366)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb58:
  store ptr %l7, ptr %l171, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr %l16, !tbaa !23
  %t371 = load ptr, ptr %l3, !tbaa !29
  %t375 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s3, ptr %t369, i32 %t370, ptr %t371)
  store { i64, ptr } %t375, ptr %l175
  br label %bb59
bb59:
  %t376 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t382 = add i64 %t379, %t381
  %t384 = extractvalue { i64, ptr } %t376, 1
  %t385 = extractvalue { i64, ptr } %t376, 0
  %t386 = add i64 %t382, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t378, i64 %t379)
  %t388 = getelementptr i8, ptr %t387, i64 %t379
  call void @olang_textcopy(ptr %t388, ptr %t380, i64 %t381)
  %t389 = getelementptr i8, ptr %t388, i64 %t381
  call void @olang_textcopy(ptr %t389, ptr %t384, i64 %t385)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t387, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } %t391, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t399 = load ptr, ptr %l171, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t399, { i64, ptr } %t398)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb61:
  %t401 = load i64, ptr %l13, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l13, !tbaa !24
  br label %bb12
bb62:
  %t405 = load ptr, ptr %l4, !tbaa !29
  %t406 = load i32, ptr %l2, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l183
  br label %bb63
bb63:
  %t410 = load i32, ptr %l183, !tbaa !23
  store i32 %t410, ptr %l20, !tbaa !23
  %t411 = load i32, ptr %l20, !tbaa !23
  %t412 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t415 = icmp ne i32 %t411, %t412
  br i1 %t415, label %bb64, label %bb65
bb64:
  %t417 = load i32, ptr %l20, !tbaa !23
  %t418 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t421 = icmp ne i32 %t417, %t418
  store i1 %t421, ptr %l187, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb66
bb66:
  %t423 = load i1, ptr %l187, !tbaa !21
  store i1 %t423, ptr %l21, !tbaa !21
  %t424 = load ptr, ptr %l4, !tbaa !29
  store ptr %t424, ptr %l191, !tbaa !29
  %t425 = load ptr, ptr %l4, !tbaa !29
  %t426 = load i32, ptr %l2, !tbaa !23
  %t429 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t425, i32 %t426)
  store i32 %t429, ptr %l194
  br label %bb67
bb67:
  %t430 = load ptr, ptr %l191, !tbaa !29
  %t431 = load i32, ptr %l194, !tbaa !23
  %t432 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t430, i32 %t431)
  store { i64, ptr } %t432, ptr %l195
  br label %bb68
bb68:
  %t433 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 0
  %t436 = icmp sgt i64 %t434, 0
  store i1 %t436, ptr %l22, !tbaa !21
  store { i64, ptr } { i64 4, ptr @.d15 }, ptr %l198, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t438, ptr %l199, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  store i64 %t440, ptr %l200, !tbaa !24
  %t441 = load i64, ptr %l200, !tbaa !24
  %t442 = mul i64 %t441, 1
  %t443 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t442)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t443, 1
  store { i64, ptr } %t445, ptr %l201, !tbaa !27
  %t446 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = load i64, ptr %l200, !tbaa !24
  %t451 = mul i64 %t450, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t447, ptr %t449, i64 %t451, i1 false)
  %t452 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t452, ptr %l23, !tbaa !27
  %t453 = load i1, ptr %l21, !tbaa !21
  br i1 %t453, label %bb69, label %bb70
bb69:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i32, ptr %l20, !tbaa !23
  %t459 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %t455, i32 %t456)
  store i1 %t459, ptr %l206
  br label %bb71
bb70:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb72
bb71:
  %t460 = load i1, ptr %l206, !tbaa !21
  store i1 %t460, ptr %l203, !tbaa !21
  br label %bb72
bb72:
  %t461 = load i1, ptr %l203, !tbaa !21
  br i1 %t461, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s16
  %t462 = load ptr, ptr %l4, !tbaa !29
  store ptr %t462, ptr %l207, !tbaa !29
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i32, ptr %l20, !tbaa !23
  %t467 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t463, i32 %t464)
  store i32 %t467, ptr %l210
  br label %bb75
bb74:
  %t468 = load i1, ptr %l22, !tbaa !21
  br i1 %t468, label %bb90, label %bb91
bb75:
  %t470 = load ptr, ptr %l207, !tbaa !29
  %t471 = load i32, ptr %l210, !tbaa !23
  %t472 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t470, i32 %t471)
  store i32 %t472, ptr %l211
  br label %bb76
bb76:
  %t473 = load i32, ptr %l211, !tbaa !23
  store ptr %l7, ptr %l212, !tbaa !29
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l3, !tbaa !29
  %t480 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s16, ptr %t474, i32 %t473, ptr %t476)
  store { i64, ptr } %t480, ptr %l216
  br label %bb77
bb77:
  %t481 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = extractvalue { i64, ptr } { i64 5, ptr @.d16 }, 1
  %t485 = extractvalue { i64, ptr } { i64 5, ptr @.d16 }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t482, i64 %t483)
  %t488 = getelementptr i8, ptr %t487, i64 %t483
  call void @olang_textcopy(ptr %t488, ptr %t484, i64 %t485)
  %t489 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t487, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } %t490, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t498 = load ptr, ptr %l212, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t498, { i64, ptr } %t497)
  br label %bb78
bb78:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 11, ptr @.d17 })
  br label %bb79
bb79:
  %t501 = load i1, ptr %l22, !tbaa !21
  br i1 %t501, label %bb80, label %bb81
bb80:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 12, ptr @.d18 })
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t504 = load i1, ptr %l22, !tbaa !21
  br i1 %t504, label %bb84, label %bb85
bb84:
  store { i64, ptr } { i64 7, ptr @.d19 }, ptr %l224, !tbaa !27
  %t506 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t506, ptr %l223, !tbaa !27
  br label %bb86
bb85:
  store { i64, ptr } { i64 7, ptr @.d20 }, ptr %l226, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t508, ptr %l223, !tbaa !27
  br label %bb86
bb86:
  %t510 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l229, !tbaa !24
  %t515 = load i64, ptr %l229, !tbaa !24
  %t516 = icmp eq i64 %t511, %t515
  br i1 %t516, label %bb87, label %bb88
bb87:
  %t518 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = load i64, ptr %l229, !tbaa !24
  %t523 = mul i64 %t522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t519, ptr %t521, i64 %t523, i1 false)
  br label %bb89
bb88:
  %t524 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t524, ptr %l23, !tbaa !27
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s16)
  br label %bb108
bb90:
  %t525 = load i1, ptr %l21, !tbaa !21
  br i1 %t525, label %bb92, label %bb93
bb91:
  %t527 = load i1, ptr %l21, !tbaa !21
  br i1 %t527, label %bb100, label %bb101
bb92:
  store %olang.scope zeroinitializer, ptr %s21
  store ptr %l7, ptr %l233, !tbaa !29
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l20, !tbaa !23
  %t531 = load ptr, ptr %l3, !tbaa !29
  %t535 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s21, ptr %t529, i32 %t530, ptr %t531)
  store { i64, ptr } %t535, ptr %l237
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t536 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 1
  %t538 = extractvalue { i64, ptr } %t536, 0
  %t539 = extractvalue { i64, ptr } { i64 8, ptr @.d21 }, 1
  %t540 = extractvalue { i64, ptr } { i64 8, ptr @.d21 }, 0
  %t541 = add i64 %t538, %t540
  %t542 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t537, i64 %t538)
  %t543 = getelementptr i8, ptr %t542, i64 %t538
  call void @olang_textcopy(ptr %t543, ptr %t539, i64 %t540)
  %t544 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t542, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = extractvalue { i64, ptr } %t545, 1
  %t549 = mul i64 %t547, 1
  %t550 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t549)
  call void @llvm.memcpy.p0.p0.i64(ptr %t550, ptr %t548, i64 %t549, i1 false)
  %t551 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  %t553 = load ptr, ptr %l233, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t553, { i64, ptr } %t552)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  store { i64, ptr } { i64 7, ptr @.d22 }, ptr %l240, !tbaa !27
  %t555 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t555, ptr %l241, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t556, 0
  %t558 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 0
  store i64 %t559, ptr %l243, !tbaa !24
  %t561 = load i64, ptr %l243, !tbaa !24
  %t562 = icmp eq i64 %t557, %t561
  br i1 %t562, label %bb97, label %bb98
bb97:
  %t564 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = load i64, ptr %l243, !tbaa !24
  %t569 = mul i64 %t568, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t565, ptr %t567, i64 %t569, i1 false)
  br label %bb99
bb98:
  %t570 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t570, 0
  store i64 %t571, ptr %l245, !tbaa !24
  %t572 = load i64, ptr %l245, !tbaa !24
  %t573 = mul i64 %t572, 1
  %t574 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t573)
  %t575 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  store { i64, ptr } %t576, ptr %l246, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = load i64, ptr %l245, !tbaa !24
  %t582 = mul i64 %t581, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t578, ptr %t580, i64 %t582, i1 false)
  %t583 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t583, ptr %l23, !tbaa !27
  br label %bb99
bb99:
  br label %bb107
bb100:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i32, ptr %l20, !tbaa !23
  %t586 = load ptr, ptr %l3, !tbaa !29
  %t590 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %s0, ptr %t584, i32 %t585, ptr %t586)
  store { i64, ptr } %t590, ptr %l251
  br label %bb102
bb101:
  br label %bb106
bb102:
  %t591 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 0
  %t593 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t593, 0
  store i64 %t594, ptr %l253, !tbaa !24
  %t596 = load i64, ptr %l253, !tbaa !24
  %t597 = icmp eq i64 %t592, %t596
  br i1 %t597, label %bb103, label %bb104
bb103:
  %t599 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = load i64, ptr %l253, !tbaa !24
  %t604 = mul i64 %t603, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t600, ptr %t602, i64 %t604, i1 false)
  br label %bb105
bb104:
  %t605 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t605, ptr %l23, !tbaa !27
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t606 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t606, ptr %l255
  br label %bb109
bb109:
  %t607 = load %"std/prelude/text:StringBuilder", ptr %l255
  store %"std/prelude/text:StringBuilder" %t607, ptr %l25
  store ptr %l25, ptr %l256, !tbaa !29
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i64, ptr %l1, !tbaa !24
  %t612 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignatureText(ptr %v0, ptr %s0, ptr %t608, i64 %t609)
  store { i64, ptr } %t612, ptr %l259
  br label %bb110
bb110:
  %t613 = extractvalue { i64, ptr } { i64 3, ptr @.d23 }, 1
  %t614 = extractvalue { i64, ptr } { i64 3, ptr @.d23 }, 0
  %t615 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 4, ptr @.d24 }, 1
  %t620 = extractvalue { i64, ptr } { i64 4, ptr @.d24 }, 0
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t613, i64 %t614)
  %t623 = getelementptr i8, ptr %t622, i64 %t614
  call void @olang_textcopy(ptr %t623, ptr %t616, i64 %t617)
  %t624 = getelementptr i8, ptr %t623, i64 %t617
  call void @olang_textcopy(ptr %t624, ptr %t619, i64 %t620)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t634 = load ptr, ptr %l256, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t634, { i64, ptr } %t633)
  br label %bb111
bb111:
  %t636 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t636, 1
  %t640 = extractvalue { i64, ptr } %t636, 0
  %t641 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t642 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t643 = add i64 %t640, %t642
  %t645 = extractvalue { i64, ptr } %t637, 1
  %t646 = extractvalue { i64, ptr } %t637, 0
  %t647 = add i64 %t643, %t646
  %t648 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t649 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t650 = add i64 %t647, %t649
  %t651 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t650)
  call void @olang_textcopy(ptr %t651, ptr %t639, i64 %t640)
  %t652 = getelementptr i8, ptr %t651, i64 %t640
  call void @olang_textcopy(ptr %t652, ptr %t641, i64 %t642)
  %t653 = getelementptr i8, ptr %t652, i64 %t642
  call void @olang_textcopy(ptr %t653, ptr %t645, i64 %t646)
  %t654 = getelementptr i8, ptr %t653, i64 %t646
  call void @olang_textcopy(ptr %t654, ptr %t648, i64 %t649)
  %t655 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t651, 1
  %t658 = extractvalue { i64, ptr } %t656, 0
  %t659 = extractvalue { i64, ptr } %t656, 1
  %t660 = mul i64 %t658, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t661, ptr %t659, i64 %t660, i1 false)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } %t663)
  br label %bb112
bb112:
  %t667 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l7)
  store i64 %t667, ptr %l268
  br label %bb113
bb113:
  %t668 = load i64, ptr %l268, !tbaa !24
  %t669 = icmp eq i64 %t668, 0
  br i1 %t669, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l25, { i64, ptr } { i64 4, ptr @.d27 })
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s27)
  br label %bb117
bb117:
  store ptr %l7, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s29
  %t673 = load ptr, ptr %l26, !tbaa !29
  %t674 = load i64, ptr %l27, !tbaa !24
  %t677 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t673, i64 %t674)
  %t678 = extractvalue { i32, { i64, ptr } } %t677, 1
  %t679 = extractvalue { i32, { i64, ptr } } %t677, 0
  store i32 %t679, ptr %l276
  %t680 = icmp ne i32 %t679, 0
  br i1 %t680, label %bb120, label %ok.681
ok.681:
  store { i64, ptr } %t678, ptr %l275
  br label %bb119
bb119:
  %t682 = load { i64, ptr }, ptr %l275, !tbaa !27
  store { i64, ptr } %t682, ptr %l272, !tbaa !27
  br label %bb124
bb120:
  %t683 = load i32, ptr %l276, !tbaa !23
  %t684 = ashr i32 %t683, 16
  %t686 = icmp eq i32 %t684, 1
  br i1 %t686, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_4ceab00ffc5fe877_bbdeb91fb78880cb)
  unreachable
bb123:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s29)
  br label %bb137
bb124:
  %t688 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t688, ptr %l29, !tbaa !27
  %t689 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t689, 0
  store i64 %t691, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s30
  %t693 = load i64, ptr %l31, !tbaa !24
  %t694 = load i64, ptr %l30, !tbaa !24
  %t697 = icmp slt i64 %t693, %t694
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s30)
  br label %bb135
bb127:
  br label %bb128
bb128:
  %t701 = load i64, ptr %l28, !tbaa !24
  %t703 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t703, ptr %l286, !tbaa !27
  %t704 = load i64, ptr %l31, !tbaa !24
  %t706 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t707 = load ptr, ptr %t706, !tbaa !27
  %t708 = getelementptr { i64, ptr }, ptr %t707, i64 %t704
  %t709 = load { i64, ptr }, ptr %t708, !tbaa !37
  store { i64, ptr } %t709, ptr %l33, !tbaa !27
  %t713 = icmp sgt i64 %t701, 0
  br i1 %t713, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s31
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %l25, { i64, ptr } { i64 2, ptr @.d28 })
  br label %bb131
bb130:
  br label %bb132
bb131:
  call void @__olang_scope_close(ptr %s31)
  br label %bb132
bb132:
  %t716 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } %t716)
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s30)
  br label %bb134
bb134:
  %t719 = load i64, ptr %l31, !tbaa !24
  %t721 = add i64 %t719, 1
  store i64 %t721, ptr %l31, !tbaa !24
  %t723 = load i64, ptr %l28, !tbaa !24
  %t725 = add i64 %t723, 1
  store i64 %t725, ptr %l28, !tbaa !24
  br label %bb125
bb135:
  %t727 = load i64, ptr %l27, !tbaa !24
  %t728 = load i64, ptr %l30, !tbaa !24
  %t731 = add i64 %t727, %t728
  store i64 %t731, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb136
bb136:
  br label %bb118
bb137:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } { i64 3, ptr @.d29 })
  br label %bb138
bb138:
  %t735 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l25)
  store { i64, ptr } %t735, ptr %l303
  br label %bb139
bb139:
  %t736 = load { i64, ptr }, ptr %l303, !tbaa !27
  store { i64, ptr } %t736, ptr %l304, !tbaa !27
  %t737 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t738 = extractvalue { i64, ptr } %t737, 0
  store i64 %t738, ptr %l305, !tbaa !24
  %t739 = load i64, ptr %l305, !tbaa !24
  %t740 = mul i64 %t739, 1
  %t741 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t740)
  %t742 = insertvalue { i64, ptr } undef, i64 %t739, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t741, 1
  store { i64, ptr } %t743, ptr %l306, !tbaa !27
  %t744 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t745 = load ptr, ptr %t744, !tbaa !27
  %t746 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = load i64, ptr %l305, !tbaa !24
  %t749 = mul i64 %t748, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t745, ptr %t747, i64 %t749, i1 false)
  %t750 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t750, ptr %l304, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t751 = load { i64, ptr }, ptr %l304, !tbaa !27
  store { i64, ptr } %t751, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/cabi:Way"
  %l8 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l76 = alloca %"compiler/cabi:Way"
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l5, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load i32, ptr %l16
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 %a3, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l19, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load ptr, ptr %l21, !tbaa !29
  %t27 = getelementptr %"compiler/cabi:Regs", ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = sub i64 %t28, 2
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = getelementptr %"compiler/cabi:Regs", ptr %t32, i32 0, i32 0
  store i64 %t30, ptr %t33, !tbaa !24
  store { i64, ptr } { i64 8, ptr @.d30 }, ptr %l24, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l27, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l30
  br label %bb9
bb9:
  %t55 = load i32, ptr %l30
  %t57 = trunc i64 21 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t62 = getelementptr %"compiler/cabi:Regs", ptr %t61, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = sub i64 %t63, 1
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Regs", ptr %t67, i32 0, i32 0
  store i64 %t65, ptr %t68, !tbaa !24
  store { i64, ptr } { i64 3, ptr @.d31 }, ptr %l36, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t69, ptr %l37, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l38, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l39, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l42
  br label %bb13
bb13:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb14, label %bb15
bb14:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l46
  br label %bb16
bb15:
  %t96 = load i32, ptr %l5, !tbaa !23
  store i32 %t96, ptr %l43, !tbaa !23
  br label %bb17
bb16:
  %t98 = load i32, ptr %l46, !tbaa !23
  store i32 %t98, ptr %l43, !tbaa !23
  br label %bb17
bb17:
  %t99 = load i32, ptr %l43, !tbaa !23
  store i32 %t99, ptr %l6, !tbaa !23
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t101 = load i32, ptr %l5, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l50
  br label %bb18
bb18:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb20:
  %t106 = load ptr, ptr %l4, !tbaa !29
  store ptr %t106, ptr %l52, !tbaa !29
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  %t115 = load i32, ptr %l56
  %t117 = trunc i64 19 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l51, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l59, !tbaa !29
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = getelementptr %"compiler/cabi:Regs", ptr %t122, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = sub i64 %t124, 1
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = getelementptr %"compiler/cabi:Regs", ptr %t128, i32 0, i32 0
  store i64 %t126, ptr %t129, !tbaa !24
  store { i64, ptr } { i64 3, ptr @.d32 }, ptr %l62, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t130, ptr %l63, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l64, !tbaa !24
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l65, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l64, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l69
  br label %bb27
bb27:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/emit:Emitter", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/emit:Emitter", ptr %t158, i32 0, i32 45
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t162 = load i32, ptr %l1, !tbaa !23
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t168 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t157, { i64, ptr } %t161, i32 %t162, ptr %t163)
  store %"compiler/cabi:Way" %t168, ptr %l76
  br label %bb28
bb28:
  %t169 = load %"compiler/cabi:Way", ptr %l76
  store %"compiler/cabi:Way" %t169, ptr %l7
  %t170 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 0
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l8
  %t173 = load i32, ptr %l8
  %t175 = trunc i64 0 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s4, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l83
  br label %bb32
bb32:
  %t183 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t184, { i64, ptr } { i64 0, ptr @.d33 })
  store i1 %t186, ptr %l85
  br label %bb33
bb33:
  %t187 = load i1, ptr %l85, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb34, label %bb35
bb34:
  %t190 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t195 = extractvalue { i64, ptr } %t191, 1
  %t196 = extractvalue { i64, ptr } %t191, 0
  %t197 = add i64 %t193, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = getelementptr i8, ptr %t198, i64 %t193
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l87, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr @.d35 }, ptr %l87, !tbaa !27
  br label %bb36
bb36:
  %t210 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = add i64 %t212, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t211, i64 %t212)
  %t218 = getelementptr i8, ptr %t217, i64 %t212
  call void @olang_textcopy(ptr %t218, ptr %t214, i64 %t215)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t217, 1
  store { i64, ptr } %t220, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb37:
  %t222 = load i32, ptr %l8
  %t224 = trunc i64 1 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t228 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t228, ptr %l95
  br label %bb41
bb41:
  %t229 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t229, ptr %l78, !tbaa !27
  br label %bb54
bb42:
  %t230 = load i32, ptr %l8
  %t232 = trunc i64 2 to i32
  %t233 = icmp eq i32 %t230, %t232
  br i1 %t233, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb49
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l1, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s8, ptr %t235, i32 %t236)
  store { i64, ptr } %t239, ptr %l100
  br label %bb46
bb46:
  %t240 = load ptr, ptr %l4, !tbaa !29
  %t241 = load i32, ptr %l1, !tbaa !23
  %t244 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t240, i32 %t241)
  store i64 %t244, ptr %l103
  br label %bb47
bb47:
  %t245 = load i64, ptr %l103, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t245, i64 8)
  store i64 %t246, ptr %l104
  br label %bb48
bb48:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr @.d36 }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr @.d36 }, 0
  %t249 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 8, ptr @.d37 }, 1
  %t254 = extractvalue { i64, ptr } { i64 8, ptr @.d37 }, 0
  %t255 = add i64 %t252, %t254
  %t256 = load i64, ptr %l104, !tbaa !24
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t256)
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t247, i64 %t248)
  %t260 = getelementptr i8, ptr %t259, i64 %t248
  call void @olang_textcopy(ptr %t260, ptr %t250, i64 %t251)
  %t261 = getelementptr i8, ptr %t260, i64 %t251
  call void @olang_textcopy(ptr %t261, ptr %t253, i64 %t254)
  %t262 = getelementptr i8, ptr %t261, i64 %t254
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t256)
  %t264 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t259, 1
  store { i64, ptr } %t265, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 3, ptr @.d38 }, ptr %l106, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t267, ptr %l78, !tbaa !27
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2854570d7fadf599_61afc1034d008305)
  unreachable
bb54:
  %t269 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l108, !tbaa !24
  %t271 = load i64, ptr %l108, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l109, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l108, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t282, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb29
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l20
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 6
  store ptr %t24, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %t26, i64 %t27)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l27
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb7, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  br label %bb11
bb7:
  %t36 = load i32, ptr %l27, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9506350913203bfc_41d6488afcc367c0)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb11:
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i64 %t55
  %t60 = load { i64, [1 x i64] }, ptr %t59
  %t64 = extractvalue { i64, [1 x i64] } %t60, 0
  %t65 = icmp eq i64 %t64, 4
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2a2725b2da5e1bad_47abef39162bd051)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb12
bb26:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = add i64 %t75, %t76
  store i64 %t79, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb5
bb28:
  br label %bb48
bb29:
  %t81 = load { i64, [2 x i64] }, ptr %l1
  %t83 = extractvalue { i64, [2 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 1
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t87 = getelementptr { i32 }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l10, !tbaa !23
  br label %bb32
bb31:
  br label %bb43
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 3
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l52, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:Emitter", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/emit:Emitter", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/lower:Lowerer", ptr %t101, i32 0, i32 1
  %t104 = load i32, ptr %l10, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t109 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t103, i64 %t106)
  store ptr %t109, ptr %l60
  br label %bb33
bb33:
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l54, !tbaa !29
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t114, i32 %t113)
  store i32 %t116, ptr %l63
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l52, !tbaa !29
  %t118 = load i32, ptr %l63, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l64
  br label %bb35
bb35:
  %t120 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t120, ptr %l11, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t131, ptr %l71, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 0
  %t135 = load i32, ptr %t134, !tbaa !33
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t130, i32 %t135)
  store i1 %t138, ptr %l73
  br label %bb38
bb37:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb39
bb38:
  %t139 = load i1, ptr %l73, !tbaa !21
  store i1 %t139, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l68, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_98184d77b87c9296_c4a7a562026735ba)
  unreachable
bb48:
  %t141 = load i64, ptr %l2, !tbaa !24
  store i64 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:Emitter", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr @.d39 })
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t10, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 51
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:Emitter", ptr %t8, i32 0, i32 51
  %t11 = load i64, ptr %t10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 51
  store i64 %t17, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:Emitter", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t29, i64 %t39)
  store ptr %t42, ptr %l19
  br label %bb5
bb5:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t45 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load ptr, ptr %l10, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t47, i64 %t46)
  store i64 %t49, ptr %l22
  br label %bb6
bb6:
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 51
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = extractvalue { i64, ptr } { i64 52, ptr @.d40 }, 1
  %t58 = extractvalue { i64, ptr } { i64 52, ptr @.d40 }, 0
  %t60 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t61 = add i64 %t58, %t60
  %t62 = extractvalue { i64, ptr } { i64 21, ptr @.d41 }, 1
  %t63 = extractvalue { i64, ptr } { i64 21, ptr @.d41 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = extractvalue { i64, ptr } { i64 63, ptr @.d42 }, 1
  %t66 = extractvalue { i64, ptr } { i64 63, ptr @.d42 }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t57, i64 %t58)
  %t69 = getelementptr i8, ptr %t68, i64 %t58
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t50)
  %t71 = getelementptr i8, ptr %t69, i64 %t60
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = getelementptr i8, ptr %t71, i64 %t63
  call void @olang_textcopy(ptr %t72, ptr %t65, i64 %t66)
  %t73 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t68, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } %t74, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t51, i64 %t55, { i64, ptr } %t81)
  br label %bb7
bb7:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/emit:Emitter", ptr %t85, i32 0, i32 51
  %t88 = load i64, ptr %t87, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i64, ptr %l14, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 56
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t11 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t10, i64 %t11)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l21
  br label %bb3
bb3:
  %t18 = load i64, ptr %l21, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp ne i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l27
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l29
  br label %bb8
bb8:
  %t34 = load i64, ptr %l29, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l35
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t46 = load i64, ptr %l35, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l37
  br label %bb12
bb12:
  %t50 = load i64, ptr %l37, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = getelementptr i8, ptr %t63, i64 %t59
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 4, ptr @.d44 }, ptr %l42, !tbaa !27
  br label %bb15
bb15:
  %t76 = extractvalue { i64, ptr } { i64 51, ptr @.d45 }, 1
  %t77 = extractvalue { i64, ptr } { i64 51, ptr @.d45 }, 0
  %t78 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 11, ptr @.d46 }, 1
  %t83 = extractvalue { i64, ptr } { i64 11, ptr @.d46 }, 0
  %t84 = add i64 %t81, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = getelementptr i8, ptr %t86, i64 %t80
  call void @olang_textcopy(ptr %t87, ptr %t82, i64 %t83)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t85, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s2, ptr %t97, i64 %t98, { i64, ptr } %t96)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l49
  br label %bb18
bb18:
  %t103 = load i64, ptr %l49, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l51
  br label %bb19
bb19:
  %t107 = load i64, ptr %l51, !tbaa !24
  store i64 %t107, ptr %l11, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t108)
  store i64 %t110, ptr %l53
  br label %bb20
bb20:
  %t111 = load i64, ptr %l53, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = extractvalue { i64, ptr } { i64 42, ptr @.d47 }, 1
  %t117 = extractvalue { i64, ptr } { i64 42, ptr @.d47 }, 0
  %t119 = extractvalue { i64, ptr } %a2, 1
  %t120 = extractvalue { i64, ptr } %a2, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 14, ptr @.d48 }, 1
  %t123 = extractvalue { i64, ptr } { i64 14, ptr @.d48 }, 0
  %t124 = add i64 %t121, %t123
  %t126 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t127 = add i64 %t124, %t126
  %t128 = extractvalue { i64, ptr } { i64 22, ptr @.d49 }, 1
  %t129 = extractvalue { i64, ptr } { i64 22, ptr @.d49 }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t116, i64 %t117)
  %t132 = getelementptr i8, ptr %t131, i64 %t117
  call void @olang_textcopy(ptr %t132, ptr %t119, i64 %t120)
  %t133 = getelementptr i8, ptr %t132, i64 %t120
  call void @olang_textcopy(ptr %t133, ptr %t122, i64 %t123)
  %t134 = getelementptr i8, ptr %t133, i64 %t123
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t115)
  %t136 = getelementptr i8, ptr %t134, i64 %t126
  call void @olang_textcopy(ptr %t136, ptr %t128, i64 %t129)
  %t137 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t131, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t112, i64 %t113, { i64, ptr } %t145)
  br label %bb21
bb21:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = extractvalue { i64, ptr } { i64 42, ptr @.d50 }, 1
  %t154 = extractvalue { i64, ptr } { i64 42, ptr @.d50 }, 0
  %t156 = extractvalue { i64, ptr } %a4, 1
  %t157 = extractvalue { i64, ptr } %a4, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 14, ptr @.d51 }, 1
  %t160 = extractvalue { i64, ptr } { i64 14, ptr @.d51 }, 0
  %t161 = add i64 %t158, %t160
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t152)
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 23, ptr @.d52 }, 1
  %t166 = extractvalue { i64, ptr } { i64 23, ptr @.d52 }, 0
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t153, i64 %t154)
  %t169 = getelementptr i8, ptr %t168, i64 %t154
  call void @olang_textcopy(ptr %t169, ptr %t156, i64 %t157)
  %t170 = getelementptr i8, ptr %t169, i64 %t157
  call void @olang_textcopy(ptr %t170, ptr %t159, i64 %t160)
  %t171 = getelementptr i8, ptr %t170, i64 %t160
  %t172 = call i64 @__olang_fmt_i64(ptr %t171, i64 %t152)
  %t173 = getelementptr i8, ptr %t171, i64 %t163
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t168, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t149, i64 %t150, { i64, ptr } %t182)
  br label %bb22
bb22:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l10, !tbaa !24
  %t189 = load i64, ptr %l11, !tbaa !24
  %t190 = extractvalue { i64, ptr } { i64 3, ptr @.d53 }, 1
  %t191 = extractvalue { i64, ptr } { i64 3, ptr @.d53 }, 0
  %t193 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t194 = add i64 %t191, %t193
  %t195 = extractvalue { i64, ptr } { i64 3, ptr @.d54 }, 1
  %t196 = extractvalue { i64, ptr } { i64 3, ptr @.d54 }, 0
  %t197 = add i64 %t194, %t196
  %t199 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t200 = add i64 %t197, %t199
  %t201 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t190, i64 %t191)
  %t205 = getelementptr i8, ptr %t204, i64 %t191
  %t206 = call i64 @__olang_fmt_i64(ptr %t205, i64 %t188)
  %t207 = getelementptr i8, ptr %t205, i64 %t193
  call void @olang_textcopy(ptr %t207, ptr %t195, i64 %t196)
  %t208 = getelementptr i8, ptr %t207, i64 %t196
  %t209 = call i64 @__olang_fmt_i64(ptr %t208, i64 %t189)
  %t210 = getelementptr i8, ptr %t208, i64 %t199
  call void @olang_textcopy(ptr %t210, ptr %t201, i64 %t202)
  %t211 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t204, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t186, i64 %t187, { i64, ptr } %t219)
  br label %bb23
bb23:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l72, !tbaa !29
  %t224 = load i64, ptr %l6, !tbaa !24
  store i64 %t224, ptr %l73, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l1, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s0, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l76
  br label %bb24
bb24:
  %t230 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t238 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t236)
  store { i64, ptr } %t238, ptr %l78
  br label %bb25
bb25:
  %t239 = load i64, ptr %l12, !tbaa !24
  %t240 = extractvalue { i64, ptr } { i64 52, ptr @.d56 }, 1
  %t241 = extractvalue { i64, ptr } { i64 52, ptr @.d56 }, 0
  %t242 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = extractvalue { i64, ptr } { i64 25, ptr @.d57 }, 1
  %t247 = extractvalue { i64, ptr } { i64 25, ptr @.d57 }, 0
  %t248 = add i64 %t245, %t247
  %t250 = call i64 @__olang_fmt_i64(ptr null, i64 %t239)
  %t251 = add i64 %t248, %t250
  %t252 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t253 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  %t254 = add i64 %t251, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t240, i64 %t241)
  %t256 = getelementptr i8, ptr %t255, i64 %t241
  call void @olang_textcopy(ptr %t256, ptr %t243, i64 %t244)
  %t257 = getelementptr i8, ptr %t256, i64 %t244
  call void @olang_textcopy(ptr %t257, ptr %t246, i64 %t247)
  %t258 = getelementptr i8, ptr %t257, i64 %t247
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t239)
  %t260 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t260, ptr %t252, i64 %t253)
  %t261 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t255, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l72, !tbaa !29
  %t271 = load i64, ptr %l73, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t270, i64 %t271, { i64, ptr } %t269)
  br label %bb26
bb26:
  %t273 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t273, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 52
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 52
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 52
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 29, ptr @.d59 })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 52
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr @.d60 })
  %t13 = extractvalue { i32, i64 } %t12, 1
  %t14 = extractvalue { i32, i64 } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store i64 %t13, ptr %l10
  br label %bb2
bb2:
  %t17 = load i64, ptr %l10, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t18 = load i64, ptr %l8, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 6, ptr @.d61 })
  store i1 %t25, ptr %l16
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb11:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l18, !tbaa !27
  br label %bb18
bb12:
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb14:
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb16:
  %t57 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = load i64, ptr %l22, !tbaa !24
  %t61 = getelementptr i8, ptr %t58, i64 %t59
  %t62 = sub i64 %t60, %t59
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l18, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t6 = extractvalue { i64, ptr } %a2, 1
  %t7 = extractvalue { i64, ptr } %a2, 0
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = extractvalue { i64, ptr } %t14, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %a1, i64 %t3, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr @.d63 })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edtorThunk(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l33 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t10 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t6, { i64, [2 x i64] } %t7)
  store { i64, ptr } %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l1
  %t16 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  store i32 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i32, ptr %l20, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t18, ptr %l21
  br label %bb3
bb3:
  %t19 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t19, ptr %l5
  store ptr %l5, ptr %l22, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l26
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr @.d64 }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr @.d64 }, 0
  %t29 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 46, ptr @.d65 }, 1
  %t34 = extractvalue { i64, ptr } { i64 46, ptr @.d65 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 2, ptr @.d66 }, 1
  %t41 = extractvalue { i64, ptr } { i64 2, ptr @.d66 }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t26, 1
  %t45 = extractvalue { i64, ptr } %t26, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t27, i64 %t28)
  %t51 = getelementptr i8, ptr %t50, i64 %t28
  call void @olang_textcopy(ptr %t51, ptr %t30, i64 %t31)
  %t52 = getelementptr i8, ptr %t51, i64 %t31
  call void @olang_textcopy(ptr %t52, ptr %t33, i64 %t34)
  %t53 = getelementptr i8, ptr %t52, i64 %t34
  call void @olang_textcopy(ptr %t53, ptr %t37, i64 %t38)
  %t54 = getelementptr i8, ptr %t53, i64 %t38
  call void @olang_textcopy(ptr %t54, ptr %t40, i64 %t41)
  %t55 = getelementptr i8, ptr %t54, i64 %t41
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t50, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t66, { i64, ptr } %t65)
  br label %bb5
bb5:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, [2 x i64] }, ptr %l1
  %t70 = load i32, ptr %l4, !tbaa !23
  %t74 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t68, { i64, [2 x i64] } %t69, i32 %t70)
  store i64 %t74, ptr %l33
  br label %bb6
bb6:
  %t75 = load i64, ptr %l33, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb7, label %bb8
bb7:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb12
bb9:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l41, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb11
bb11:
  %t104 = load i64, ptr %l41, !tbaa !24
  store i64 %t104, ptr %l38, !tbaa !24
  br label %bb12
bb12:
  %t105 = load i64, ptr %l38, !tbaa !24
  store i64 %t105, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  %t126 = icmp sgt i64 %t122, 0
  br i1 %t126, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 2, ptr @.d68 })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l5, { i64, ptr } { i64 10, ptr @.d69 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb13
bb23:
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l5, { i64, ptr } { i64 2, ptr @.d70 })
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 25, ptr @.d71 })
  br label %bb28
bb28:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l69, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = extractvalue { i64, ptr } { i64 3, ptr @.d72 }, 1
  %t146 = extractvalue { i64, ptr } { i64 3, ptr @.d72 }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = getelementptr i8, ptr %t148, i64 %t144
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t159, ptr %l73, !tbaa !24
  %t161 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t161, ptr %l75
  br label %bb29
bb29:
  %t162 = load ptr, ptr %l69, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t164 = load i64, ptr %l73, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t162, { i64, ptr } %t163, i64 %t164, { i64, ptr } %t165, { i64, ptr } { i64 0, ptr @.d73 })
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t10, i64 %a1)
  store ptr %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t19, i32 %t18)
  store { i64, ptr } %t21, ptr %l16
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t28, ptr %lp4
  %t30 = load ptr, ptr %lp4
  store { i64, ptr } %t27, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %lp4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v1, ptr %t31, { i64, ptr } %t33, i32 %t34)
  store { i64, ptr } %t38, ptr %l21
  br label %bb3
bb3:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t39, ptr %lp5
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t41 = load ptr, ptr %lp5
  store { i64, ptr } %t40, ptr %t41, !tbaa !27
  %t42 = load ptr, ptr %lp5
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr @.d74 })
  store i1 %t45, ptr %l23
  br label %bb4
bb4:
  %t46 = load i1, ptr %l23, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp5
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t54 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t51)
  store i1 %t54, ptr %l27
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t55 = load i1, ptr %l27, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %lp5
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l30, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s3, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l33
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t66 = load ptr, ptr %lp5
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l34, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb11
bb11:
  %t73 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t74, i64 %t75)
  %t94 = getelementptr i8, ptr %t93, i64 %t75
  call void @olang_textcopy(ptr %t94, ptr %t76, i64 %t77)
  %t95 = getelementptr i8, ptr %t94, i64 %t77
  call void @olang_textcopy(ptr %t95, ptr %t80, i64 %t81)
  %t96 = getelementptr i8, ptr %t95, i64 %t81
  call void @olang_textcopy(ptr %t96, ptr %t83, i64 %t84)
  %t97 = getelementptr i8, ptr %t96, i64 %t84
  call void @olang_textcopy(ptr %t97, ptr %t87, i64 %t88)
  %t98 = getelementptr i8, ptr %t97, i64 %t88
  call void @olang_textcopy(ptr %t98, ptr %t90, i64 %t91)
  %t99 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t93, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l29, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s3, ptr %t108, { i64, ptr } %t109, { i64, ptr } %t107)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t111 = load ptr, ptr %lp5
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t112, ptr %rv
  br label %ret
bb14:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %lp4
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t119 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t114, { i64, ptr } %t116)
  store i1 %t119, ptr %l43
  br label %bb15
bb15:
  %t120 = load i1, ptr %l43, !tbaa !21
  br i1 %t120, label %bb16, label %bb17
bb16:
  %t121 = load ptr, ptr %lp4
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l45
  br label %bb19
bb19:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t125, ptr %l6
  store ptr %l6, ptr %l46, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l2, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %s0, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l49
  br label %bb20
bb20:
  %t131 = load ptr, ptr %lp4
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } { i64 2, ptr @.d78 }, 1
  %t137 = extractvalue { i64, ptr } { i64 2, ptr @.d78 }, 0
  %t138 = add i64 %t135, %t137
  %t140 = extractvalue { i64, ptr } %t132, 1
  %t141 = extractvalue { i64, ptr } %t132, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t134, i64 %t135)
  %t147 = getelementptr i8, ptr %t146, i64 %t135
  call void @olang_textcopy(ptr %t147, ptr %t136, i64 %t137)
  %t148 = getelementptr i8, ptr %t147, i64 %t137
  call void @olang_textcopy(ptr %t148, ptr %t140, i64 %t141)
  %t149 = getelementptr i8, ptr %t148, i64 %t141
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t159, { i64, ptr } %t158)
  br label %bb21
bb21:
  store ptr %l6, ptr %l53, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l54, !tbaa !29
  %t162 = load i32, ptr %l2, !tbaa !23
  store i32 %t162, ptr %l55, !tbaa !23
  %t163 = load ptr, ptr %lp4
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 8, ptr @.d80 })
  store i1 %t166, ptr %l57
  br label %bb22
bb22:
  %t167 = load ptr, ptr %l54, !tbaa !29
  %t168 = load i32, ptr %l55, !tbaa !23
  %t169 = load i1, ptr %l57, !tbaa !21
  %t170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %s0, ptr %t167, i32 %t168, i1 %t169)
  store { i64, ptr } %t170, ptr %l58
  br label %bb23
bb23:
  %t171 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t178 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t178, { i64, ptr } %t177)
  br label %bb24
bb24:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr @.d81 })
  br label %bb25
bb25:
  %t181 = load ptr, ptr %lp4
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load ptr, ptr @__olang_prog_scope
  %t186 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %t183, ptr %v1, ptr @G_2ecompiler_2femit_2emathInexact, { i64, ptr } %t182)
  store i1 %t186, ptr %l63
  br label %bb26
bb26:
  %t187 = load i1, ptr %l63, !tbaa !21
  br i1 %t187, label %bb27, label %bb28
bb27:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s0, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l67
  br label %bb29
bb28:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb31
bb29:
  %t193 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t199, { i64, ptr } { i64 0, ptr @.d82 })
  store i1 %t201, ptr %l69
  br label %bb30
bb30:
  %t202 = load i1, ptr %l69, !tbaa !21
  %t203 = xor i1 %t202, true
  store i1 %t203, ptr %l64, !tbaa !21
  br label %bb31
bb31:
  %t205 = load i1, ptr %l64, !tbaa !21
  br i1 %t205, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l6, { i64, ptr } { i64 24, ptr @.d83 })
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l72, !tbaa !29
  %t208 = load ptr, ptr %lp4
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l73, !tbaa !27
  %t211 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t211, ptr %l75
  br label %bb36
bb36:
  %t212 = load ptr, ptr %l72, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s0, ptr %t212, { i64, ptr } %t213, { i64, ptr } %t214)
  br label %bb37
bb37:
  %t215 = load ptr, ptr %lp4
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 19
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [2 x i64] }, ptr %l1
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t15, { i64, [2 x i64] } %t16, i32 %a2, { i64, ptr } %t18, i64 %a4, i1 %a5, { i64, ptr } { i64 7, ptr @.d84 })
  store { i64, ptr } %t27, ptr %l22
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t28, ptr %l8, !tbaa !27
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:Emitter", ptr %t29, i32 0, i32 58
  store ptr %t31, ptr %l24, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 15
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l27
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2femit_2efnTypeOf(ptr %s0, ptr %v0, { i64, ptr } %t37)
  store { i64, ptr } %t39, ptr %l29
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t47, i64 %t48, { i64, ptr } %t46)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t50, { i64, ptr } %t51, i64 %t52, { i64, ptr } %a6, { i64, ptr } %t54)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 9
  %t9 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t1)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 9
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 21
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d85 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d85 }, 0
  %t8 = extractvalue { i64, ptr } %t4, 1
  %t9 = extractvalue { i64, ptr } %t4, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t5, i64 %t6)
  %t15 = getelementptr i8, ptr %t14, i64 %t6
  call void @olang_textcopy(ptr %t15, ptr %t8, i64 %t9)
  %t16 = getelementptr i8, ptr %t15, i64 %t9
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t14, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 66
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroups(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l107 = alloca i64
  %l113 = alloca i64
  %l119 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i64
  %l146 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i1
  %l157 = alloca i64
  %l159 = alloca i64
  %l169 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i32
  %l182 = alloca { i64, ptr }
  %l185 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i32
  %l197 = alloca %"compiler/emit:Reused"
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l212 = alloca { i64, ptr }
  %l215 = alloca i64
  %l219 = alloca i64
  %l220 = alloca i32
  %l223 = alloca i1
  %l227 = alloca i64
  %l230 = alloca i1
  %l234 = alloca i1
  %l256 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l257 = alloca i64
  %l259 = alloca i64
  %l264 = alloca i64
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l279 = alloca i64
  %l282 = alloca i64
  %l300 = alloca { i64, ptr }
  %l304 = alloca i64
  %l306 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l311 = alloca i64
  %l312 = alloca { i64, ptr }
  %l315 = alloca i64
  %l316 = alloca i64
  %l321 = alloca i64
  %l322 = alloca i32
  %l328 = alloca i64
  %l335 = alloca i1
  %l345 = alloca i1
  %l349 = alloca i1
  %l352 = alloca i1
  %l365 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l368 = alloca i64
  %l372 = alloca i64
  %l375 = alloca i64
  %l396 = alloca i64
  %l402 = alloca i1
  %l408 = alloca ptr
  %l409 = alloca i64
  %l413 = alloca i64
  %l414 = alloca i32
  %l419 = alloca { i64, ptr }
  %l422 = alloca { i64, ptr }
  %l423 = alloca i32
  %l432 = alloca { i64, ptr }
  %l437 = alloca i1
  %l439 = alloca ptr
  %l440 = alloca i64
  %l443 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %t102 = alloca i64
  %t127 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 7
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l70
  br label %bb1
bb1:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l1)
  store i64 %t27, ptr %l72
  br label %bb2
bb2:
  %t28 = load i64, ptr %l72, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb8
bb5:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l79, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l79, !tbaa !24
  store i64 %t55, ptr %l76, !tbaa !24
  br label %bb8
bb8:
  %t56 = load i64, ptr %l76, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l2, !tbaa !24
  %t79 = icmp ne i64 %t75, %t76
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t81)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  %t88 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t88)
  br label %bb19
bb19:
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l1)
  store i64 %t92, ptr %l107
  br label %bb20
bb20:
  %t93 = load i64, ptr %l107, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l107, !tbaa !24
  %t97 = icmp sle i64 %t96, 1152921504606846975
  br i1 %t97, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb23:
  %t99 = load i64, ptr %l107, !tbaa !24
  %t100 = mul i64 %t99, 8
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  store i64 0, ptr %t102
  br label %fill.103
fill.103:
  %t106 = load i64, ptr %t102
  %t107 = icmp slt i64 %t106, %t99
  br i1 %t107, label %fillb.104, label %filld.105
fillb.104:
  %t108 = getelementptr i64, ptr %t101, i64 %t106
  store i64 -1, ptr %t108
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %t102
  br label %fill.103
filld.105:
  %t110 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t101, 1
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %t113, i32 0, i32 15
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l113
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39)
  unreachable
bb25:
  %t118 = load i64, ptr %l113, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l113, !tbaa !24
  %t122 = icmp sle i64 %t121, 1152921504606846975
  br i1 %t122, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb28:
  %t124 = load i64, ptr %l113, !tbaa !24
  %t125 = mul i64 %t124, 8
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  store i64 0, ptr %t127
  br label %fill.128
fill.128:
  %t131 = load i64, ptr %t127
  %t132 = icmp slt i64 %t131, %t124
  br i1 %t132, label %fillb.129, label %filld.130
fillb.129:
  %t133 = getelementptr i64, ptr %t126, i64 %t131
  store i64 -1, ptr %t133
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %t127
  br label %fill.128
filld.130:
  %t135 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t126, 1
  store { i64, ptr } %t136, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/emit:Emitter", ptr %t138, i32 0, i32 15
  %t142 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t140)
  store i64 %t142, ptr %l119
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_fd5758dba8282ae8_cbed788f914882ac)
  unreachable
bb30:
  %t143 = load i64, ptr %l119, !tbaa !24
  store i64 %t143, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb31, label %bb32
bb31:
  %t150 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb36
bb33:
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l14, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l126, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb35
bb35:
  %t170 = load i64, ptr %l126, !tbaa !24
  store i64 %t170, ptr %l123, !tbaa !24
  br label %bb36
bb36:
  %t171 = load i64, ptr %l123, !tbaa !24
  store i64 %t171, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t172 = load i64, ptr %l16, !tbaa !24
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t180 = load i64, ptr %l12, !tbaa !24
  %t181 = load i64, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l17, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/emit:Emitter", ptr %t190, i32 0, i32 15
  %t194 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l146
  br label %bb41
bb41:
  %t195 = load i64, ptr %l146, !tbaa !24
  %t196 = sub i64 %t195, 1
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = sub i64 %t196, %t197
  store i64 %t200, ptr %l18, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/emit:Emitter", ptr %t202, i32 0, i32 17
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t204, i64 %t205)
  store i64 %t208, ptr %l153
  br label %bb42
bb42:
  %t209 = load i64, ptr %l153, !tbaa !24
  store i64 %t209, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l19, !tbaa !24
  %t212 = icmp sge i64 %t210, 0
  br i1 %t212, label %bb43, label %bb44
bb43:
  %t214 = load i64, ptr %l19, !tbaa !24
  store i64 %t214, ptr %l157, !tbaa !24
  %t216 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l1)
  store i64 %t216, ptr %l159
  br label %bb45
bb44:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb46
bb45:
  %t217 = load i64, ptr %l157, !tbaa !24
  %t218 = load i64, ptr %l159, !tbaa !24
  %t219 = icmp slt i64 %t217, %t218
  store i1 %t219, ptr %l156, !tbaa !21
  br label %bb46
bb46:
  %t221 = load i1, ptr %l156, !tbaa !21
  br i1 %t221, label %bb47, label %bb48
bb47:
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l19, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t223
  %t228 = load i64, ptr %t227, !tbaa !34
  %t231 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i64, ptr %t232, i64 %t222
  store i64 %t228, ptr %t233, !tbaa !34
  %t234 = load i64, ptr %l19, !tbaa !24
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i64, ptr %t239, i64 %t234
  store i64 %t235, ptr %t240, !tbaa !34
  br label %bb49
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t241 = load i64, ptr %l16, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l16, !tbaa !24
  br label %bb37
bb51:
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t246 = load ptr, ptr %l20, !tbaa !29
  %t247 = load i64, ptr %l21, !tbaa !24
  %t250 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t246, i64 %t247)
  %t251 = extractvalue { i32, { i64, ptr } } %t250, 1
  %t252 = extractvalue { i32, { i64, ptr } } %t250, 0
  store i32 %t252, ptr %l173
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb54, label %ok.254
ok.254:
  store { i64, ptr } %t251, ptr %l172
  br label %bb53
bb53:
  %t255 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t255, ptr %l169, !tbaa !27
  br label %bb58
bb54:
  %t256 = load i32, ptr %l173, !tbaa !23
  %t257 = ashr i32 %t256, 16
  %t259 = icmp eq i32 %t257, 1
  br i1 %t259, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_a549d449f3dfe0fc_20c0e66cb00bd9e8)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb175
bb58:
  %t261 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t261, ptr %l22, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t266 = load i64, ptr %l24, !tbaa !24
  %t267 = load i64, ptr %l23, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb173
bb61:
  br label %bb62
bb62:
  %t274 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t274, ptr %l182, !tbaa !27
  %t275 = load i64, ptr %l24, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr i64, ptr %t278, i64 %t275
  %t280 = load i64, ptr %t279, !tbaa !34
  store i64 %t280, ptr %l25, !tbaa !24
  %t282 = load ptr, ptr @__olang_prog_scope
  %t283 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t282)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t283, ptr %l185
  br label %bb63
bb63:
  %t284 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l185
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %l26
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/emit:Emitter", ptr %t285, i32 0, i32 61
  %t288 = load i64, ptr %l25, !tbaa !24
  %t291 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t287, i64 %t288)
  %t292 = extractvalue { i32, i64 } %t291, 1
  %t293 = extractvalue { i32, i64 } %t291, 0
  store i32 %t293, ptr %l191
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb65, label %ok.295
ok.295:
  store i64 %t292, ptr %l190
  br label %bb64
bb64:
  %t296 = load i64, ptr %l190, !tbaa !24
  store i64 %t296, ptr %l186, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l186, !tbaa !24
  br label %bb67
bb67:
  %t297 = load i64, ptr %l186, !tbaa !24
  store i64 %t297, ptr %l27, !tbaa !24
  %t298 = load i64, ptr %l27, !tbaa !24
  %t300 = icmp sge i64 %t298, 0
  br i1 %t300, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/emit:Emitter", ptr %t302, i32 0, i32 60
  %t305 = load i64, ptr %l27, !tbaa !24
  %t308 = call %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v0, ptr %t304, i64 %t305)
  store %"compiler/emit:Reused" %t308, ptr %l197
  br label %bb70
bb69:
  %t309 = load i64, ptr %l25, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr i64, ptr %t312, i64 %t309
  %t314 = load i64, ptr %t313, !tbaa !34
  store i64 %t314, ptr %l35, !tbaa !24
  br label %bb103
bb70:
  %t316 = getelementptr %"compiler/emit:Reused", ptr %l197, i32 0, i32 6
  store ptr %t316, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t318 = load ptr, ptr %l28, !tbaa !29
  %t319 = load i64, ptr %l29, !tbaa !24
  %t322 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s13, ptr %t318, i64 %t319)
  %t323 = extractvalue { i32, { i64, ptr } } %t322, 1
  %t324 = extractvalue { i32, { i64, ptr } } %t322, 0
  store i32 %t324, ptr %l203
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb73, label %ok.326
ok.326:
  store { i64, ptr } %t323, ptr %l202
  br label %bb72
bb72:
  %t327 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t327, ptr %l199, !tbaa !27
  br label %bb77
bb73:
  %t328 = load i32, ptr %l203, !tbaa !23
  %t329 = ashr i32 %t328, 16
  %t331 = icmp eq i32 %t329, 1
  br i1 %t331, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_3a6ac4f3bb1dc0ad_502f03c6a68bc9b9)
  unreachable
bb76:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb102
bb77:
  %t333 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t333, ptr %l30, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s15
  %t338 = load i64, ptr %l32, !tbaa !24
  %t339 = load i64, ptr %l31, !tbaa !24
  %t342 = icmp slt i64 %t338, %t339
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s15)
  br label %bb100
bb80:
  br label %bb81
bb81:
  %t346 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t346, ptr %l212, !tbaa !27
  %t347 = load i64, ptr %l32, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %t350, i64 %t347
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !37
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/emit:Emitter", ptr %t354, i32 0, i32 19
  %t360 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s13, ptr %t356, { i64, ptr } %t352)
  %t361 = extractvalue { i32, i64 } %t360, 1
  %t362 = extractvalue { i32, i64 } %t360, 0
  store i32 %t362, ptr %l220
  %t363 = icmp ne i32 %t362, 0
  br i1 %t363, label %bb83, label %ok.364
ok.364:
  store i64 %t361, ptr %l219
  br label %bb82
bb82:
  %t365 = load i64, ptr %l219, !tbaa !24
  store i64 %t365, ptr %l215, !tbaa !24
  br label %bb85
bb83:
  br label %bb84
bb84:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l215, !tbaa !24
  br label %bb85
bb85:
  %t366 = load i64, ptr %l215, !tbaa !24
  store i64 %t366, ptr %l34, !tbaa !24
  %t367 = load i64, ptr %l34, !tbaa !24
  %t369 = icmp sge i64 %t367, 0
  br i1 %t369, label %bb86, label %bb87
bb86:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/emit:Emitter", ptr %t371, i32 0, i32 17
  %t374 = load i64, ptr %l34, !tbaa !24
  %t377 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t373, i64 %t374)
  store i64 %t377, ptr %l227
  br label %bb88
bb87:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb89
bb88:
  %t378 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t379 = load i64, ptr %l227, !tbaa !24
  %t381 = icmp eq i64 %t379, %t378
  store i1 %t381, ptr %l223, !tbaa !21
  br label %bb89
bb89:
  %t383 = load i1, ptr %l223, !tbaa !21
  br i1 %t383, label %bb90, label %bb91
bb90:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/emit:Emitter", ptr %t384, i32 0, i32 66
  %t387 = load i64, ptr %l34, !tbaa !24
  %t390 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t386, i64 %t387)
  store i1 %t390, ptr %l234
  br label %bb92
bb91:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb93
bb92:
  %t391 = load i1, ptr %l234, !tbaa !21
  %t392 = xor i1 %t391, true
  store i1 %t392, ptr %l230, !tbaa !21
  br label %bb93
bb93:
  %t394 = load i1, ptr %l230, !tbaa !21
  br i1 %t394, label %bb94, label %bb95
bb94:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/emit:Emitter", ptr %t395, i32 0, i32 66
  %t398 = load i64, ptr %l34, !tbaa !24
  %t399 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t397, i64 %t398, i64 %t399)
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t403 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s11, ptr %l26, i64 %t403)
  br label %bb97
bb97:
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb99
bb99:
  %t406 = load i64, ptr %l32, !tbaa !24
  %t408 = add i64 %t406, 1
  store i64 %t408, ptr %l32, !tbaa !24
  br label %bb78
bb100:
  %t410 = load i64, ptr %l29, !tbaa !24
  %t411 = load i64, ptr %l31, !tbaa !24
  %t414 = add i64 %t410, %t411
  store i64 %t414, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb101
bb101:
  br label %bb71
bb102:
  call void @__olang_scope_close(ptr %s13)
  br label %bb110
bb103:
  store %olang.scope zeroinitializer, ptr %s20
  %t416 = load i64, ptr %l35, !tbaa !24
  %t418 = icmp sge i64 %t416, 0
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s20)
  br label %bb109
bb105:
  br label %bb106
bb106:
  %t422 = load i64, ptr %l35, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s11, ptr %l26, i64 %t422)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s20)
  br label %bb108
bb108:
  %t425 = load i64, ptr %l35, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr i64, ptr %t428, i64 %t425
  %t430 = load i64, ptr %t429, !tbaa !34
  store i64 %t430, ptr %l35, !tbaa !24
  br label %bb103
bb109:
  br label %bb110
bb110:
  %t432 = load ptr, ptr @__olang_prog_scope
  %t433 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t432)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t433, ptr %l256
  br label %bb111
bb111:
  %t434 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l256
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t434, ptr %l36
  store i64 0, ptr %l37, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s22
  %t435 = load i64, ptr %l37, !tbaa !24
  store i64 %t435, ptr %l257, !tbaa !24
  %t437 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s11, ptr %l26)
  store i64 %t437, ptr %l259
  br label %bb113
bb113:
  %t438 = load i64, ptr %l257, !tbaa !24
  %t439 = load i64, ptr %l259, !tbaa !24
  %t440 = icmp slt i64 %t438, %t439
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s22)
  br label %bb171
bb115:
  br label %bb116
bb116:
  %t444 = load i64, ptr %l37, !tbaa !24
  %t447 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s11, ptr %l26, i64 %t444)
  store i64 %t447, ptr %l264
  br label %bb117
bb117:
  %t448 = load i64, ptr %l264, !tbaa !24
  store i64 %t448, ptr %l38, !tbaa !24
  %t449 = load i64, ptr %l37, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l37, !tbaa !24
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/emit:Emitter", ptr %t453, i32 0, i32 16
  %t456 = load i64, ptr %l38, !tbaa !24
  %t459 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t455, i64 %t456)
  store { i64, ptr } %t459, ptr %l270
  br label %bb118
bb118:
  %t460 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t460, ptr %l39, !tbaa !27
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i64, ptr %l38, !tbaa !24
  %t465 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %t461, i64 %t462)
  store { i64, ptr } %t465, ptr %l273
  br label %bb119
bb119:
  %t466 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t466, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 0
  store i64 %t469, ptr %l42, !tbaa !24
  store i64 3, ptr %l43, !tbaa !24
  %t471 = load i64, ptr %l42, !tbaa !24
  %t472 = load i64, ptr %l41, !tbaa !24
  %t475 = icmp sgt i64 %t471, %t472
  br i1 %t475, label %bb120, label %bb121
bb120:
  %t477 = load i64, ptr %l43, !tbaa !24
  %t479 = icmp sgt i64 %t477, 0
  br i1 %t479, label %bb122, label %bb123
bb121:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb125
bb122:
  %t481 = load i64, ptr %l42, !tbaa !24
  %t482 = load i64, ptr %l41, !tbaa !24
  %t485 = sub i64 %t481, %t482
  %t486 = load i64, ptr %l43, !tbaa !24
  %t489 = add i64 %t485, %t486
  %t491 = sub i64 %t489, 1
  %t492 = load i64, ptr %l43, !tbaa !24
  %t495 = sdiv i64 %t491, %t492
  store i64 %t495, ptr %l282, !tbaa !24
  br label %bb124
bb123:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb124
bb124:
  %t497 = load i64, ptr %l282, !tbaa !24
  store i64 %t497, ptr %l279, !tbaa !24
  br label %bb125
bb125:
  %t498 = load i64, ptr %l279, !tbaa !24
  store i64 %t498, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s24
  %t499 = load i64, ptr %l45, !tbaa !24
  %t500 = load i64, ptr %l44, !tbaa !24
  %t503 = icmp slt i64 %t499, %t500
  %t505 = xor i1 %t503, true
  br i1 %t505, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s24)
  br label %bb169
bb128:
  br label %bb129
bb129:
  %t507 = load i64, ptr %l41, !tbaa !24
  %t508 = load i64, ptr %l45, !tbaa !24
  %t509 = load i64, ptr %l43, !tbaa !24
  %t512 = mul i64 %t508, %t509
  %t515 = add i64 %t507, %t512
  store i64 %t515, ptr %l46, !tbaa !24
  %t517 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t517, ptr %l300, !tbaa !27
  %t518 = load i64, ptr %l46, !tbaa !24
  %t520 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = getelementptr i64, ptr %t521, i64 %t518
  %t523 = load i64, ptr %t522, !tbaa !34
  %t525 = icmp ne i64 %t523, 0
  br i1 %t525, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s24)
  br label %bb168
bb131:
  br label %bb132
bb132:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/emit:Emitter", ptr %t527, i32 0, i32 19
  store ptr %t529, ptr %l306, !tbaa !29
  %t530 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t530, ptr %l307, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t531, ptr %l308, !tbaa !27
  %t532 = load i64, ptr %l46, !tbaa !24
  %t534 = add i64 %t532, 1
  %t536 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr i64, ptr %t537, i64 %t534
  %t539 = load i64, ptr %t538, !tbaa !34
  store i64 %t539, ptr %l311, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t540, ptr %l312, !tbaa !27
  %t541 = load i64, ptr %l46, !tbaa !24
  %t543 = add i64 %t541, 2
  %t545 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr i64, ptr %t546, i64 %t543
  %t548 = load i64, ptr %t547, !tbaa !34
  store i64 %t548, ptr %l315, !tbaa !24
  %t549 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t549, 0
  store i64 %t550, ptr %l316, !tbaa !24
  %t551 = load i64, ptr %l311, !tbaa !24
  %t552 = icmp sge i64 %t551, 0
  br i1 %t552, label %bb133, label %bb134
bb133:
  %t554 = load i64, ptr %l311, !tbaa !24
  %t555 = load i64, ptr %l315, !tbaa !24
  %t556 = icmp sle i64 %t554, %t555
  br i1 %t556, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_7729a42c6cf896d9_c9c75da2e4237ced)
  unreachable
bb135:
  %t558 = load i64, ptr %l315, !tbaa !24
  %t559 = load i64, ptr %l316, !tbaa !24
  %t560 = icmp sle i64 %t558, %t559
  br i1 %t560, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_7729a42c6cf896d9_c9c75da2e4237ced)
  unreachable
bb137:
  %t562 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = load i64, ptr %l311, !tbaa !24
  %t565 = load i64, ptr %l315, !tbaa !24
  %t566 = getelementptr i8, ptr %t563, i64 %t564
  %t567 = sub i64 %t565, %t564
  %t568 = insertvalue { i64, ptr } undef, i64 %t567, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t566, 1
  %t570 = load ptr, ptr %l306, !tbaa !29
  %t572 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t570, { i64, ptr } %t569)
  %t573 = extractvalue { i32, i64 } %t572, 1
  %t574 = extractvalue { i32, i64 } %t572, 0
  store i32 %t574, ptr %l322
  %t575 = icmp ne i32 %t574, 0
  br i1 %t575, label %bb140, label %ok.576
ok.576:
  store i64 %t573, ptr %l321
  br label %bb139
bb138:
  call void @__olang_check_failed(ptr @olang_loc_7729a42c6cf896d9_c9c75da2e4237ced)
  unreachable
bb139:
  %t577 = load i64, ptr %l321, !tbaa !24
  store i64 %t577, ptr %l304, !tbaa !24
  br label %bb142
bb140:
  br label %bb141
bb141:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l304, !tbaa !24
  br label %bb142
bb142:
  %t578 = load i64, ptr %l304, !tbaa !24
  store i64 %t578, ptr %l47, !tbaa !24
  %t579 = load i64, ptr %l47, !tbaa !24
  %t581 = icmp slt i64 %t579, 0
  br i1 %t581, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s24)
  br label %bb168
bb144:
  br label %bb145
bb145:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/emit:Emitter", ptr %t583, i32 0, i32 17
  %t586 = load i64, ptr %l47, !tbaa !24
  %t589 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t585, i64 %t586)
  store i64 %t589, ptr %l328
  br label %bb146
bb146:
  %t590 = load i64, ptr %l328, !tbaa !24
  store i64 %t590, ptr %l48, !tbaa !24
  %t591 = load i64, ptr %l48, !tbaa !24
  %t592 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t595 = icmp eq i64 %t591, %t592
  br i1 %t595, label %bb147, label %bb148
bb147:
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = getelementptr %"compiler/emit:Emitter", ptr %t597, i32 0, i32 66
  %t600 = load i64, ptr %l47, !tbaa !24
  %t603 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t599, i64 %t600)
  store i1 %t603, ptr %l335
  br label %bb149
bb148:
  %t604 = load i64, ptr %l48, !tbaa !24
  %t605 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t608 = icmp eq i64 %t604, %t605
  br i1 %t608, label %bb155, label %bb156
bb149:
  %t610 = load i1, ptr %l335, !tbaa !21
  br i1 %t610, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s24)
  br label %bb168
bb151:
  br label %bb152
bb152:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/emit:Emitter", ptr %t611, i32 0, i32 66
  %t614 = load i64, ptr %l47, !tbaa !24
  %t615 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t613, i64 %t614, i64 %t615)
  br label %bb153
bb153:
  %t619 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s11, ptr %l26, i64 %t619)
  br label %bb154
bb154:
  br label %bb167
bb155:
  store i1 true, ptr %l345, !tbaa !21
  br label %bb157
bb156:
  %t622 = load i64, ptr %l48, !tbaa !24
  %t623 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t626 = icmp eq i64 %t622, %t623
  store i1 %t626, ptr %l345, !tbaa !21
  br label %bb157
bb157:
  %t628 = load i1, ptr %l345, !tbaa !21
  br i1 %t628, label %bb158, label %bb159
bb158:
  %t629 = load i64, ptr %l47, !tbaa !24
  %t632 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s11, ptr %l36, i64 %t629)
  store i1 %t632, ptr %l352
  br label %bb160
bb159:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb161
bb160:
  %t633 = load i1, ptr %l352, !tbaa !21
  %t634 = xor i1 %t633, true
  store i1 %t634, ptr %l349, !tbaa !21
  br label %bb161
bb161:
  %t636 = load i1, ptr %l349, !tbaa !21
  br i1 %t636, label %bb162, label %bb163
bb162:
  %t637 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s11, ptr %l36, i64 %t637, i1 true)
  br label %bb164
bb163:
  br label %bb166
bb164:
  %t640 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s11, ptr %l26, i64 %t640)
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s24)
  br label %bb168
bb168:
  %t643 = load i64, ptr %l45, !tbaa !24
  %t645 = add i64 %t643, 1
  store i64 %t645, ptr %l45, !tbaa !24
  br label %bb126
bb169:
  call void @__olang_scope_close(ptr %s22)
  br label %bb170
bb170:
  br label %bb112
bb171:
  call void @__olang_scope_close(ptr %s11)
  br label %bb172
bb172:
  %t647 = load i64, ptr %l24, !tbaa !24
  %t649 = add i64 %t647, 1
  store i64 %t649, ptr %l24, !tbaa !24
  br label %bb59
bb173:
  %t651 = load i64, ptr %l21, !tbaa !24
  %t652 = load i64, ptr %l23, !tbaa !24
  %t655 = add i64 %t651, %t652
  store i64 %t655, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb174
bb174:
  br label %bb52
bb175:
  %t657 = load ptr, ptr @__olang_prog_scope
  %t658 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t657)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t658, ptr %l365
  br label %bb176
bb176:
  %t659 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l365
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t659, ptr %l49
  store i64 0, ptr %l50, !tbaa !24
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = getelementptr %"compiler/emit:Emitter", ptr %t660, i32 0, i32 15
  %t664 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t662)
  store i64 %t664, ptr %l368
  br label %bb177
bb177:
  %t665 = load i64, ptr %l368, !tbaa !24
  store i64 %t665, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t666 = load i64, ptr %l51, !tbaa !24
  %t667 = load i64, ptr %l50, !tbaa !24
  %t670 = icmp sgt i64 %t666, %t667
  br i1 %t670, label %bb178, label %bb179
bb178:
  %t672 = load i64, ptr %l52, !tbaa !24
  %t674 = icmp sgt i64 %t672, 0
  br i1 %t674, label %bb180, label %bb181
bb179:
  store i64 0, ptr %l372, !tbaa !24
  br label %bb183
bb180:
  %t676 = load i64, ptr %l51, !tbaa !24
  %t677 = load i64, ptr %l50, !tbaa !24
  %t680 = sub i64 %t676, %t677
  %t681 = load i64, ptr %l52, !tbaa !24
  %t684 = add i64 %t680, %t681
  %t686 = sub i64 %t684, 1
  %t687 = load i64, ptr %l52, !tbaa !24
  %t690 = sdiv i64 %t686, %t687
  store i64 %t690, ptr %l375, !tbaa !24
  br label %bb182
bb181:
  store i64 0, ptr %l375, !tbaa !24
  br label %bb182
bb182:
  %t692 = load i64, ptr %l375, !tbaa !24
  store i64 %t692, ptr %l372, !tbaa !24
  br label %bb183
bb183:
  %t693 = load i64, ptr %l372, !tbaa !24
  store i64 %t693, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb184
bb184:
  store %olang.scope zeroinitializer, ptr %s34
  %t694 = load i64, ptr %l54, !tbaa !24
  %t695 = load i64, ptr %l53, !tbaa !24
  %t698 = icmp slt i64 %t694, %t695
  %t700 = xor i1 %t698, true
  br i1 %t700, label %bb185, label %bb186
bb185:
  call void @__olang_scope_close(ptr %s34)
  br label %bb203
bb186:
  br label %bb187
bb187:
  %t702 = load i64, ptr %l50, !tbaa !24
  %t703 = load i64, ptr %l54, !tbaa !24
  %t704 = load i64, ptr %l52, !tbaa !24
  %t707 = mul i64 %t703, %t704
  %t710 = add i64 %t702, %t707
  store i64 %t710, ptr %l55, !tbaa !24
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/emit:Emitter", ptr %t712, i32 0, i32 17
  %t715 = load i64, ptr %l55, !tbaa !24
  %t718 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t714, i64 %t715)
  store i64 %t718, ptr %l396
  br label %bb188
bb188:
  %t719 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t720 = load i64, ptr %l396, !tbaa !24
  %t722 = icmp ne i64 %t720, %t719
  br i1 %t722, label %bb189, label %bb190
bb189:
  call void @__olang_scope_close(ptr %s34)
  br label %bb202
bb190:
  br label %bb191
bb191:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/emit:Emitter", ptr %t724, i32 0, i32 66
  %t727 = load i64, ptr %l55, !tbaa !24
  %t730 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t726, i64 %t727)
  store i1 %t730, ptr %l402
  br label %bb192
bb192:
  %t731 = load i1, ptr %l402, !tbaa !21
  %t732 = xor i1 %t731, true
  br i1 %t732, label %bb193, label %bb194
bb193:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/emit:Emitter", ptr %t734, i32 0, i32 66
  %t737 = load i64, ptr %l55, !tbaa !24
  %t738 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t736, i64 %t737, i64 %t738)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  store ptr %l49, ptr %l408, !tbaa !29
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/emit:Emitter", ptr %t742, i32 0, i32 66
  %t745 = load i64, ptr %l55, !tbaa !24
  %t748 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t744, i64 %t745)
  %t749 = extractvalue { i32, i64 } %t748, 1
  %t750 = extractvalue { i32, i64 } %t748, 0
  store i32 %t750, ptr %l414
  %t751 = icmp ne i32 %t750, 0
  br i1 %t751, label %bb198, label %ok.752
ok.752:
  store i64 %t749, ptr %l413
  br label %bb197
bb197:
  %t753 = load i64, ptr %l413, !tbaa !24
  store i64 %t753, ptr %l409, !tbaa !24
  br label %bb200
bb198:
  br label %bb199
bb199:
  call void @__olang_ert_req_clear()
  %t754 = load i64, ptr %l2, !tbaa !24
  store i64 %t754, ptr %l409, !tbaa !24
  br label %bb200
bb200:
  %t756 = load ptr, ptr %l408, !tbaa !29
  %t757 = load i64, ptr %l409, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t756, i64 %t757, i1 true)
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s34)
  br label %bb202
bb202:
  %t758 = load i64, ptr %l54, !tbaa !24
  %t760 = add i64 %t758, 1
  store i64 %t760, ptr %l54, !tbaa !24
  br label %bb184
bb203:
  store ptr %l3, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb204
bb204:
  store %olang.scope zeroinitializer, ptr %s39
  %t763 = load ptr, ptr %l56, !tbaa !29
  %t764 = load i64, ptr %l57, !tbaa !24
  %t767 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t763, i64 %t764)
  %t768 = extractvalue { i32, { i64, ptr } } %t767, 1
  %t769 = extractvalue { i32, { i64, ptr } } %t767, 0
  store i32 %t769, ptr %l423
  %t770 = icmp ne i32 %t769, 0
  br i1 %t770, label %bb206, label %ok.771
ok.771:
  store { i64, ptr } %t768, ptr %l422
  br label %bb205
bb205:
  %t772 = load { i64, ptr }, ptr %l422, !tbaa !27
  store { i64, ptr } %t772, ptr %l419, !tbaa !27
  br label %bb210
bb206:
  %t773 = load i32, ptr %l423, !tbaa !23
  %t774 = ashr i32 %t773, 16
  %t776 = icmp eq i32 %t774, 1
  br i1 %t776, label %bb207, label %bb208
bb207:
  br label %bb209
bb208:
  call void @__olang_check_failed(ptr @olang_loc_17fafaf8ddeba01b_252e647ba0a345f)
  unreachable
bb209:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s39)
  br label %bb225
bb210:
  %t778 = load { i64, ptr }, ptr %l419, !tbaa !27
  store { i64, ptr } %t778, ptr %l58, !tbaa !27
  %t779 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t781 = extractvalue { i64, ptr } %t779, 0
  store i64 %t781, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb211
bb211:
  store %olang.scope zeroinitializer, ptr %s40
  %t783 = load i64, ptr %l60, !tbaa !24
  %t784 = load i64, ptr %l59, !tbaa !24
  %t787 = icmp slt i64 %t783, %t784
  %t789 = xor i1 %t787, true
  br i1 %t789, label %bb212, label %bb213
bb212:
  call void @__olang_scope_close(ptr %s40)
  br label %bb223
bb213:
  br label %bb214
bb214:
  %t791 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t791, ptr %l432, !tbaa !27
  %t792 = load i64, ptr %l60, !tbaa !24
  %t794 = getelementptr { i64, ptr }, ptr %l432, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !27
  %t796 = getelementptr i64, ptr %t795, i64 %t792
  %t797 = load i64, ptr %t796, !tbaa !34
  store i64 %t797, ptr %l61, !tbaa !24
  %t799 = load i64, ptr %l61, !tbaa !24
  %t802 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l49, i64 %t799)
  store i1 %t802, ptr %l437
  br label %bb215
bb215:
  %t803 = load i1, ptr %l437, !tbaa !21
  br i1 %t803, label %bb216, label %bb217
bb216:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t806 = getelementptr %"compiler/emit:Emitter", ptr %t804, i32 0, i32 68
  store ptr %t806, ptr %l439, !tbaa !29
  %t807 = load i64, ptr %l61, !tbaa !24
  store i64 %t807, ptr %l440, !tbaa !24
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t810 = getelementptr %"compiler/emit:Emitter", ptr %t808, i32 0, i32 67
  %t812 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t810)
  store i64 %t812, ptr %l443
  br label %bb218
bb217:
  br label %bb221
bb218:
  %t813 = load ptr, ptr %l439, !tbaa !29
  %t814 = load i64, ptr %l440, !tbaa !24
  %t815 = load i64, ptr %l443, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t813, i64 %t814, i64 %t815)
  br label %bb219
bb219:
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t818 = getelementptr %"compiler/emit:Emitter", ptr %t816, i32 0, i32 67
  %t819 = load i64, ptr %l61, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t818, i64 %t819)
  br label %bb220
bb220:
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s40)
  br label %bb222
bb222:
  %t822 = load i64, ptr %l60, !tbaa !24
  %t824 = add i64 %t822, 1
  store i64 %t824, ptr %l60, !tbaa !24
  br label %bb211
bb223:
  %t826 = load i64, ptr %l57, !tbaa !24
  %t827 = load i64, ptr %l59, !tbaa !24
  %t830 = add i64 %t826, %t827
  store i64 %t830, ptr %l57, !tbaa !24
  call void @__olang_scope_close(ptr %s39)
  br label %bb224
bb224:
  br label %bb204
bb225:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i64 %a4, i1 %a5, i1 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca i64
  %l57 = alloca i64
  %l76 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l124 = alloca i64
  %l127 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i64
  %l136 = alloca i64
  %l140 = alloca { i64, ptr }
  %l147 = alloca i64
  %l154 = alloca i64
  %l165 = alloca i1
  %l172 = alloca i64
  %l175 = alloca i64
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca i32
  %l221 = alloca { i64, ptr }
  %l223 = alloca %"compiler/emit:Object"
  %l229 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l241 = alloca { i64, ptr }
  %l243 = alloca %"compiler/emit:Object"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l6, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 4
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l37, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l37, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t9, %t19
  store i1 %t22, ptr %l40, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l40, !tbaa !21
  store i1 %t24, ptr %l9, !tbaa !21
  %t25 = load i1, ptr %l9, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i64 2, ptr %l48, !tbaa !24
  br label %bb9
bb8:
  store i64 1, ptr %l48, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l48, !tbaa !24
  store i64 %t27, ptr %l10, !tbaa !24
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t28)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l49
  br label %bb10
bb10:
  %t30 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l10, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l12, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l14, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb13:
  %t43 = load i64, ptr %l13, !tbaa !24
  %t44 = load i64, ptr %l12, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l14, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l14, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l57, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l57, !tbaa !24
  store i64 %t59, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l54, !tbaa !24
  store i64 %t60, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load i64, ptr %l16, !tbaa !24
  %t62 = load i64, ptr %l15, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l16, !tbaa !24
  %t71 = load i64, ptr %l14, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l17, !tbaa !24
  %t79 = load i1, ptr %l9, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load i64, ptr %l17, !tbaa !24
  store i64 %t81, ptr %l76, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l76, !tbaa !24
  br label %bb23
bb23:
  %t83 = load i64, ptr %l76, !tbaa !24
  store i64 %t83, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/emit:Emitter", ptr %t84, i32 0, i32 15
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l80
  br label %bb24
bb24:
  %t89 = load i64, ptr %l80, !tbaa !24
  store i64 %t89, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t90 = load i64, ptr %l21, !tbaa !24
  %t91 = load i64, ptr %l20, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t96 = load i64, ptr %l22, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb30
bb27:
  %t100 = load i64, ptr %l21, !tbaa !24
  %t101 = load i64, ptr %l20, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l22, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l22, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l87, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l87, !tbaa !24
  store i64 %t116, ptr %l84, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l84, !tbaa !24
  store i64 %t117, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load i64, ptr %l24, !tbaa !24
  %t119 = load i64, ptr %l23, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb61
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l20, !tbaa !24
  %t127 = load i64, ptr %l24, !tbaa !24
  %t128 = load i64, ptr %l22, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l25, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:Emitter", ptr %t136, i32 0, i32 17
  %t139 = load i64, ptr %l25, !tbaa !24
  %t142 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l108
  br label %bb35
bb35:
  %t143 = load i64, ptr %l108, !tbaa !24
  store i64 %t143, ptr %l26, !tbaa !24
  %t144 = load i64, ptr %l26, !tbaa !24
  %t145 = load i64, ptr %l4, !tbaa !24
  %t148 = icmp eq i64 %t144, %t145
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb41
bb37:
  %t150 = load i1, ptr %l5, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  %t152 = load i64, ptr %l26, !tbaa !24
  %t153 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  store i1 %t156, ptr %l114, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb40
bb40:
  %t158 = load i1, ptr %l114, !tbaa !21
  store i1 %t158, ptr %l112, !tbaa !21
  br label %bb41
bb41:
  %t159 = load i1, ptr %l112, !tbaa !21
  br i1 %t159, label %bb42, label %bb43
bb42:
  %t160 = load i64, ptr %l18, !tbaa !24
  %t162 = icmp slt i64 %t160, 0
  br i1 %t162, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb48
bb44:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb47
bb45:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l25, !tbaa !24
  %t168 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %t164, i64 %t165)
  store i64 %t168, ptr %l124
  br label %bb46
bb46:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t170 = load i64, ptr %l124, !tbaa !24
  %t172 = icmp eq i64 %t170, %t169
  store i1 %t172, ptr %l121, !tbaa !21
  br label %bb47
bb47:
  %t174 = load i1, ptr %l121, !tbaa !21
  store i1 %t174, ptr %l118, !tbaa !21
  br label %bb48
bb48:
  %t175 = load i1, ptr %l118, !tbaa !21
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t176 = load i64, ptr %l8, !tbaa !24
  %t178 = icmp slt i64 %t176, 0
  br i1 %t178, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb54
bb52:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l25, !tbaa !24
  %t184 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t180, i64 %t181)
  store i64 %t184, ptr %l133
  br label %bb53
bb53:
  %t185 = load i64, ptr %l8, !tbaa !24
  %t186 = load i64, ptr %l133, !tbaa !24
  %t188 = icmp eq i64 %t186, %t185
  store i1 %t188, ptr %l130, !tbaa !21
  br label %bb54
bb54:
  %t190 = load i1, ptr %l130, !tbaa !21
  store i1 %t190, ptr %l127, !tbaa !21
  br label %bb55
bb55:
  %t191 = load i1, ptr %l127, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t192 = load i64, ptr %l19, !tbaa !24
  store i64 %t192, ptr %l136, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %t193, i32 0, i32 16
  %t196 = load i64, ptr %l25, !tbaa !24
  %t199 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s5, ptr %t195, i64 %t196)
  store { i64, ptr } %t199, ptr %l140
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t200 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = load i64, ptr %l136, !tbaa !24
  %t204 = add i64 %t202, %t201
  store i64 %t204, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb60:
  %t206 = load i64, ptr %l24, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l24, !tbaa !24
  br label %bb31
bb61:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = icmp eq i64 %t210, 1
  br i1 %t212, label %bb62, label %bb63
bb62:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/emit:Emitter", ptr %t214, i32 0, i32 40
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = sdiv i64 %t217, 4
  store i64 %t219, ptr %l147, !tbaa !24
  br label %bb64
bb63:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %t221, i32 0, i32 40
  %t224 = load i64, ptr %t223, !tbaa !24
  store i64 %t224, ptr %l147, !tbaa !24
  br label %bb64
bb64:
  %t226 = load i64, ptr %l147, !tbaa !24
  store i64 %t226, ptr %l27, !tbaa !24
  %t227 = load i1, ptr %l6, !tbaa !21
  br i1 %t227, label %bb65, label %bb66
bb65:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t230 = load i64, ptr %l27, !tbaa !24
  %t233 = add i64 %t229, %t230
  %t235 = sub i64 %t233, 1
  %t236 = load i64, ptr %l27, !tbaa !24
  %t239 = sdiv i64 %t235, %t236
  store i64 %t239, ptr %l154, !tbaa !24
  br label %bb67
bb66:
  store i64 1, ptr %l154, !tbaa !24
  br label %bb67
bb67:
  %t241 = load i64, ptr %l154, !tbaa !24
  store i64 %t241, ptr %l28, !tbaa !24
  %t242 = load i64, ptr %l28, !tbaa !24
  %t244 = icmp slt i64 %t242, 1
  br i1 %t244, label %bb68, label %bb69
bb68:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t248 = icmp eq i64 %t246, 1
  br i1 %t248, label %bb71, label %bb72
bb71:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = icmp eq i64 %t250, 0
  store i1 %t252, ptr %l165, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb73
bb73:
  %t254 = load i1, ptr %l165, !tbaa !21
  br i1 %t254, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb75:
  br label %bb76
bb76:
  store i64 0, ptr %l29, !tbaa !24
  %t255 = load i64, ptr %l28, !tbaa !24
  store i64 %t255, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t257 = load i64, ptr %l30, !tbaa !24
  %t258 = load i64, ptr %l29, !tbaa !24
  %t261 = icmp sgt i64 %t257, %t258
  br i1 %t261, label %bb77, label %bb78
bb77:
  %t263 = load i64, ptr %l31, !tbaa !24
  %t265 = icmp sgt i64 %t263, 0
  br i1 %t265, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb82
bb79:
  %t267 = load i64, ptr %l30, !tbaa !24
  %t268 = load i64, ptr %l29, !tbaa !24
  %t271 = sub i64 %t267, %t268
  %t272 = load i64, ptr %l31, !tbaa !24
  %t275 = add i64 %t271, %t272
  %t277 = sub i64 %t275, 1
  %t278 = load i64, ptr %l31, !tbaa !24
  %t281 = sdiv i64 %t277, %t278
  store i64 %t281, ptr %l175, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb81
bb81:
  %t283 = load i64, ptr %l175, !tbaa !24
  store i64 %t283, ptr %l172, !tbaa !24
  br label %bb82
bb82:
  %t284 = load i64, ptr %l172, !tbaa !24
  store i64 %t284, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t285 = load i64, ptr %l33, !tbaa !24
  %t286 = load i64, ptr %l32, !tbaa !24
  %t289 = icmp slt i64 %t285, %t286
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb97
bb85:
  br label %bb86
bb86:
  %t293 = load i64, ptr %l29, !tbaa !24
  %t294 = load i64, ptr %l33, !tbaa !24
  %t295 = load i64, ptr %l31, !tbaa !24
  %t298 = mul i64 %t294, %t295
  %t301 = add i64 %t293, %t298
  store i64 %t301, ptr %l34, !tbaa !24
  %t303 = load i64, ptr %l18, !tbaa !24
  %t305 = icmp ne i64 %t303, 1
  br i1 %t305, label %bb87, label %bb88
bb87:
  %t307 = load i64, ptr %l34, !tbaa !24
  %t309 = icmp eq i64 %t307, 0
  br i1 %t309, label %bb89, label %bb90
bb88:
  %t311 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t312 = load i64, ptr %l34, !tbaa !24
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = extractvalue { i64, ptr } %t311, 0
  %t316 = extractvalue { i64, ptr } { i64 2, ptr @.d87 }, 1
  %t317 = extractvalue { i64, ptr } { i64 2, ptr @.d87 }, 0
  %t318 = add i64 %t315, %t317
  %t320 = call i64 @__olang_fmt_i64(ptr null, i64 %t312)
  %t321 = add i64 %t318, %t320
  %t322 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t321)
  call void @olang_textcopy(ptr %t322, ptr %t314, i64 %t315)
  %t323 = getelementptr i8, ptr %t322, i64 %t315
  call void @olang_textcopy(ptr %t323, ptr %t316, i64 %t317)
  %t324 = getelementptr i8, ptr %t323, i64 %t317
  %t325 = call i64 @__olang_fmt_i64(ptr %t324, i64 %t312)
  %t326 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t322, 1
  store { i64, ptr } %t327, ptr %l195, !tbaa !27
  br label %bb92
bb89:
  %t329 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = extractvalue { i64, ptr } %t329, 0
  %t333 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t331, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l198, !tbaa !27
  br label %bb91
bb90:
  %t337 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t338 = load i64, ptr %l34, !tbaa !24
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = extractvalue { i64, ptr } %t337, 0
  %t342 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t343 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  %t344 = add i64 %t341, %t343
  %t346 = call i64 @__olang_fmt_i64(ptr null, i64 %t338)
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = getelementptr i8, ptr %t348, i64 %t341
  call void @olang_textcopy(ptr %t349, ptr %t342, i64 %t343)
  %t350 = getelementptr i8, ptr %t349, i64 %t343
  %t351 = call i64 @__olang_fmt_i64(ptr %t350, i64 %t338)
  %t352 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t348, 1
  store { i64, ptr } %t353, ptr %l198, !tbaa !27
  br label %bb91
bb91:
  %t355 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t355, ptr %l195, !tbaa !27
  br label %bb92
bb92:
  %t356 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l207, !tbaa !29
  %t360 = extractvalue { i64, ptr } %t356, 1
  %t361 = extractvalue { i64, ptr } %t356, 0
  %t362 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t360, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = extractvalue { i64, ptr } %t364, 1
  %t368 = mul i64 %t366, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  call void @llvm.memcpy.p0.p0.i64(ptr %t369, ptr %t367, i64 %t368, i1 false)
  %t370 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  store { i64, ptr } %t371, ptr %l210, !tbaa !27
  %t372 = load i32, ptr %l3
  store i32 %t372, ptr %l211
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i64, ptr %l4, !tbaa !24
  %t375 = load i1, ptr %l5, !tbaa !21
  %t376 = load i64, ptr %l34, !tbaa !24
  %t377 = load i64, ptr %l28, !tbaa !24
  %t379 = load i64, ptr %l18, !tbaa !24
  %t380 = load i64, ptr %l8, !tbaa !24
  %t390 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v3, ptr %s0, ptr %v1, ptr %t373, i64 %t374, i1 %t375, i64 %t376, i64 %t377, ptr %a7, i64 %t379, ptr %l11, i64 %t380)
  store { i64, ptr } %t390, ptr %l221
  br label %bb93
bb93:
  %t391 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 0
  %t393 = extractvalue { i64, ptr } %t391, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t398 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t399 = load i32, ptr %l211
  %t401 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t398, i32 %t399, { i64, ptr } %t397)
  store %"compiler/emit:Object" %t401, ptr %l223
  br label %bb94
bb94:
  %t402 = load ptr, ptr %l207, !tbaa !29
  %t403 = load %"compiler/emit:Object", ptr %l223
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t402, %"compiler/emit:Object" %t403)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t404 = load i64, ptr %l33, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l33, !tbaa !24
  br label %bb83
bb97:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb98:
  %t408 = load i64, ptr %l16, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l16, !tbaa !24
  br label %bb17
bb99:
  %t413 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %s0, ptr %l11)
  store i64 %t413, ptr %l229
  br label %bb100
bb100:
  %t414 = load i64, ptr %l229, !tbaa !24
  %t415 = icmp sgt i64 %t414, 0
  br i1 %t415, label %bb101, label %bb102
bb101:
  %t417 = load ptr, ptr %l1, !tbaa !29
  store ptr %t417, ptr %l231, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t418, ptr %l232, !tbaa !27
  %t419 = load i32, ptr %l3
  %t421 = trunc i64 3 to i32
  %t422 = icmp eq i32 %t419, %t421
  br i1 %t422, label %bb103, label %bb104
bb102:
  br label %bb109
bb103:
  store { i64, ptr } { i64 2, ptr @.d89 }, ptr %l235, !tbaa !27
  br label %bb105
bb104:
  store { i64, ptr } { i64 0, ptr @.d90 }, ptr %l235, !tbaa !27
  br label %bb105
bb105:
  %t424 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = add i64 %t426, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t425, i64 %t426)
  %t432 = getelementptr i8, ptr %t431, i64 %t426
  call void @olang_textcopy(ptr %t432, ptr %t428, i64 %t429)
  %t433 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t431, 1
  %t436 = extractvalue { i64, ptr } %t434, 0
  %t437 = extractvalue { i64, ptr } %t434, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l237, !tbaa !27
  store i32 4, ptr %l238
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t445 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %s0, ptr %v1, ptr %t442, ptr %l11)
  store { i64, ptr } %t445, ptr %l241
  br label %bb106
bb106:
  %t446 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 0
  %t448 = extractvalue { i64, ptr } %t446, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t454 = load i32, ptr %l238
  %t456 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t453, i32 %t454, { i64, ptr } %t452)
  store %"compiler/emit:Object" %t456, ptr %l243
  br label %bb107
bb107:
  %t457 = load ptr, ptr %l231, !tbaa !29
  %t458 = load %"compiler/emit:Object", ptr %l243
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t457, %"compiler/emit:Object" %t458)
  br label %bb108
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t29, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l24
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l24, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t43, ptr %l25
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t13 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t4, i64 %a1, i64 %t9)
  store { i64, ptr } %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 1, ptr @.d91 })
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l14
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb3, label %ok.21
ok.21:
  store i64 %t18, ptr %l13
  br label %bb2
bb2:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l11, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb8, label %bb9
bb7:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l17, !tbaa !27
  br label %bb14
bb8:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = icmp sle i64 0, %t41
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb10:
  %t44 = load i64, ptr %l18, !tbaa !24
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb12:
  %t48 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l18, !tbaa !24
  %t51 = getelementptr i8, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = extractvalue { i64, ptr } %t54, 0
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t56, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l41 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i32
  %l109 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t289 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l20
  br label %bb1
bb1:
  %t14 = load i32, ptr %l20, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l23
  br label %bb2
bb2:
  %t20 = load i32, ptr %l23
  store i32 %t20, ptr %l6
  %t21 = load i32, ptr %l6
  %t23 = trunc i64 24 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb4:
  %t26 = load i32, ptr %l6
  %t28 = trunc i64 18 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l33
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb7:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l34
  br label %bb8
bb8:
  %t40 = load i32, ptr %l34
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l29, !tbaa !21
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l41
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t57 = load i1, ptr %l41, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t60)
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l47
  br label %bb17
bb17:
  %t73 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s1, ptr %s1, ptr %t74, { i64, ptr } %t75, i64 8)
  store { i64, ptr } %t78, ptr %l50
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t80, { i64, ptr } %t81, { i64, ptr } { i64 15, ptr @.d92 }, { i64, ptr } %t82, { i64, ptr } { i64 0, ptr @.d93 })
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t90 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t89)
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %t87)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = extractvalue { i64, ptr } { i64 14, ptr @.d94 }, 1
  %t105 = extractvalue { i64, ptr } { i64 14, ptr @.d94 }, 0
  %t107 = extractvalue { i64, ptr } %t102, 1
  %t108 = extractvalue { i64, ptr } %t102, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 6, ptr @.d95 }, 1
  %t111 = extractvalue { i64, ptr } { i64 6, ptr @.d95 }, 0
  %t112 = add i64 %t109, %t111
  %t114 = extractvalue { i64, ptr } %t103, 1
  %t115 = extractvalue { i64, ptr } %t103, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 14, ptr @.d96 }, 1
  %t118 = extractvalue { i64, ptr } { i64 14, ptr @.d96 }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t110, i64 %t111)
  %t123 = getelementptr i8, ptr %t122, i64 %t111
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t120, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t136 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t101, { i64, ptr } %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb20
bb20:
  %t137 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l54, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t144, { i64, ptr } { i64 3, ptr @.d97 }, { i64, ptr } %t145, { i64, ptr } %t143, { i64, ptr } { i64 0, ptr @.d98 })
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l4, !tbaa !29
  store ptr %t147, ptr %l65, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l5, !tbaa !23
  %t152 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l68
  br label %bb22
bb22:
  %t153 = load ptr, ptr %l65, !tbaa !29
  %t154 = load i32, ptr %l68, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l69
  br label %bb23
bb23:
  %t156 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l10, !tbaa !23
  %t164 = load i32, ptr %l10, !tbaa !23
  %t166 = icmp ne i32 %t164, 0
  br i1 %t166, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l75, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l76, !tbaa !23
  %t170 = load ptr, ptr %l4, !tbaa !29
  store ptr %t170, ptr %l77, !tbaa !29
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t172 = load i32, ptr %l10, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l80
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t176 = load ptr, ptr %l77, !tbaa !29
  %t177 = load i32, ptr %l80, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l81
  br label %bb27
bb27:
  %t179 = load %"compiler/mir:Range", ptr %l3
  %t180 = load ptr, ptr %l75, !tbaa !29
  %t181 = load i32, ptr %l76, !tbaa !23
  %t182 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %s6, ptr %t180, i32 %t181, { i64, ptr } %t182, %"compiler/mir:Range" %t179)
  store { i64, ptr } %t184, ptr %l83
  br label %bb28
bb28:
  %t185 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l10, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l87
  br label %bb29
bb29:
  %t192 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l88, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t199, ptr %l89, !tbaa !27
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 14, ptr @.d99 }, 1
  %t204 = extractvalue { i64, ptr } { i64 14, ptr @.d99 }, 0
  %t206 = extractvalue { i64, ptr } %t201, 1
  %t207 = extractvalue { i64, ptr } %t201, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 6, ptr @.d100 }, 1
  %t210 = extractvalue { i64, ptr } { i64 6, ptr @.d100 }, 0
  %t211 = add i64 %t208, %t210
  %t213 = extractvalue { i64, ptr } %t202, 1
  %t214 = extractvalue { i64, ptr } %t202, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 14, ptr @.d101 }, 1
  %t217 = extractvalue { i64, ptr } { i64 14, ptr @.d101 }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t203, i64 %t204)
  %t220 = getelementptr i8, ptr %t219, i64 %t204
  call void @olang_textcopy(ptr %t220, ptr %t206, i64 %t207)
  %t221 = getelementptr i8, ptr %t220, i64 %t207
  call void @olang_textcopy(ptr %t221, ptr %t209, i64 %t210)
  %t222 = getelementptr i8, ptr %t221, i64 %t210
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t219, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t235 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s6, ptr %s6, ptr %t200, { i64, ptr } %t232)
  store { i64, ptr } %t235, ptr %l95
  br label %bb30
bb30:
  %t236 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t243 = load ptr, ptr %l84, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %t243, { i64, ptr } %t244, { i64, ptr } %t245, { i64, ptr } %t242, { i64, ptr } { i64 0, ptr @.d102 })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t253 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %v1, ptr %v1, ptr %t247, { i64, ptr } %t248, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr @.d103 })
  store { i64, ptr } %t253, ptr %l100
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s1)
  %t254 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t254, ptr %rv
  br label %ret
bb34:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l5, !tbaa !23
  %t259 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t259, ptr %l103
  br label %bb35
bb35:
  %t260 = load i32, ptr %l103, !tbaa !23
  store i32 %t260, ptr %l12, !tbaa !23
  %t261 = load i32, ptr %l12, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  br i1 %t265, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l12, !tbaa !23
  %t271 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t267, i32 %t268)
  store i64 %t271, ptr %l109
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t272 = load i64, ptr %l109, !tbaa !24
  store i64 %t272, ptr %l110, !tbaa !24
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t275 = load i32, ptr %l12, !tbaa !23
  %t278 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l113
  br label %bb39
bb39:
  %t279 = load i64, ptr %l110, !tbaa !24
  %t280 = icmp sge i64 %t279, 0
  br i1 %t280, label %bb40, label %bb41
bb40:
  %t282 = load i64, ptr %l110, !tbaa !24
  %t283 = icmp sle i64 %t282, 2305843009213693951
  br i1 %t283, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb42:
  %t285 = load i64, ptr %l110, !tbaa !24
  %t286 = mul i64 %t285, 4
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  %t288 = load i32, ptr %l113, !tbaa !23
  store i64 0, ptr %t289
  br label %fill.290
fill.290:
  %t293 = load i64, ptr %t289
  %t294 = icmp slt i64 %t293, %t285
  br i1 %t294, label %fillb.291, label %filld.292
fillb.291:
  %t295 = getelementptr i32, ptr %t287, i64 %t293
  store i32 %t288, ptr %t295
  %t296 = add i64 %t293, 1
  store i64 %t296, ptr %t289
  br label %fill.290
filld.292:
  %t297 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t287, 1
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l12, !tbaa !23
  %t303 = load %"compiler/mir:Range", ptr %l3
  %t308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %s8, ptr %v1, ptr %t300, i32 %t301, { i64, ptr } %t298, %"compiler/mir:Range" %t303)
  store { i64, ptr } %t308, ptr %l121
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb44:
  call void @__olang_scope_close(ptr %s8)
  %t309 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
bb45:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l122, !tbaa !29
  %t311 = load i32, ptr %l5, !tbaa !23
  store i32 %t311, ptr %l123, !tbaa !23
  %t312 = load ptr, ptr %l4, !tbaa !29
  store ptr %t312, ptr %l124, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l5, !tbaa !23
  %t317 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t313, i32 %t314)
  store i32 %t317, ptr %l127
  br label %bb46
bb46:
  %t318 = load ptr, ptr %l124, !tbaa !29
  %t319 = load i32, ptr %l127, !tbaa !23
  %t320 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t318, i32 %t319)
  store { i64, ptr } %t320, ptr %l128
  br label %bb47
bb47:
  %t321 = load %"compiler/mir:Range", ptr %l3
  %t322 = load ptr, ptr %l122, !tbaa !29
  %t323 = load i32, ptr %l123, !tbaa !23
  %t324 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %v1, ptr %t322, i32 %t323, { i64, ptr } %t324, %"compiler/mir:Range" %t321)
  store { i64, ptr } %t326, ptr %l130
  br label %bb48
bb48:
  %t327 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t327, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l6 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l3
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t13, %a2
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1)
  unreachable
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, [7 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l110 = alloca i64
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l134 = alloca { i64, ptr }
  %l136 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l156 = alloca i64
  %l162 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca i64
  %l180 = alloca i1
  %l182 = alloca i1
  %l193 = alloca i32
  %l194 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca { i64, ptr }
  %l204 = alloca i1
  %l208 = alloca i1
  %l211 = alloca i1
  %l212 = alloca %"std/prelude/text:StringBuilder"
  %l214 = alloca i1
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca i64
  %l223 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l242 = alloca i32
  %l245 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l276 = alloca { i64, [1 x i64] }
  %l277 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l285 = alloca i32
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l295 = alloca i64
  %l298 = alloca i64
  %l322 = alloca { i64, [4 x i64] }
  %l325 = alloca i1
  %l327 = alloca i1
  %l335 = alloca i1
  %l340 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l356 = alloca { i64, ptr }
  %l359 = alloca { i64, ptr }
  %l361 = alloca ptr
  %l364 = alloca { i64, ptr }
  %l367 = alloca { i64, ptr }
  %l373 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l383 = alloca { i64, ptr }
  %l386 = alloca ptr
  %l388 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l402 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca { i64, ptr }
  %l407 = alloca { i64, ptr }
  %l408 = alloca i64
  %l409 = alloca { i64, ptr }
  %l411 = alloca i1
  %l412 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l415 = alloca { i64, ptr }
  %l418 = alloca ptr
  %l419 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l422 = alloca { i64, ptr }
  %l425 = alloca { i64, ptr }
  %l427 = alloca i64
  %l433 = alloca { i64, ptr }
  %l434 = alloca { i64, ptr }
  %l435 = alloca i64
  %l436 = alloca { i64, ptr }
  %l438 = alloca { i64, ptr }
  %l440 = alloca i64
  %l442 = alloca i64
  %l443 = alloca { i64, ptr }
  %l448 = alloca { i64, ptr }
  %l454 = alloca { i64, ptr }
  %l457 = alloca i64
  %l461 = alloca i1
  %l465 = alloca { i64, ptr }
  %l472 = alloca { i64, ptr }
  %l476 = alloca ptr
  %l477 = alloca { i64, ptr }
  %l480 = alloca { i64, ptr }
  %l486 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l489 = alloca ptr
  %l490 = alloca { i64, ptr }
  %l492 = alloca { i64, ptr }
  %l499 = alloca i1
  %l501 = alloca i1
  %l505 = alloca { { i64, ptr }, i32 }
  %l506 = alloca { i64, ptr }
  %l507 = alloca i64
  %l508 = alloca { i64, ptr }
  %l511 = alloca ptr
  %l512 = alloca { i64, ptr }
  %l513 = alloca { i64, ptr }
  %l516 = alloca i64
  %l517 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l524 = alloca ptr
  %l526 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  store { i64, ptr } { i64 0, ptr @.d104 }, ptr %l58, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t11, ptr %l59, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l60, !tbaa !24
  %t14 = load i64, ptr %l60, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l61, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l60, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d105 }, ptr %l62, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t26, ptr %l63, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l64, !tbaa !24
  %t29 = load i64, ptr %l64, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l65, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l64, !tbaa !24
  %t39 = mul i64 %t38, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d106 }, ptr %l66, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t41, ptr %l67, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l68, !tbaa !24
  %t44 = load i64, ptr %l68, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l69, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l68, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  store i1 false, ptr %l7, !tbaa !21
  %t56 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t57 = load { i64, [7 x i64] }, ptr %t56
  store { i64, [7 x i64] } %t57, ptr %l8
  %t59 = load { i64, [7 x i64] }, ptr %l8
  %t61 = extractvalue { i64, [7 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb1, label %bb2
bb1:
  %t64 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, [2 x i64] }, ptr %t65
  store { i64, [2 x i64] } %t66, ptr %l9
  %t68 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t69 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l10, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:fnEm", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t75, { i64, [2 x i64] } %t76)
  br label %bb4
bb4:
  %t79 = load i32, ptr %l10, !tbaa !23
  store i32 %t79, ptr %l3, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load { i64, [2 x i64] }, ptr %l9
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s1, ptr %t84, { i64, [2 x i64] } %t85)
  store { i64, ptr } %t88, ptr %l82
  br label %bb5
bb5:
  %t89 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 0
  %t91 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l83, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l85, !tbaa !24
  %t104 = load i64, ptr %l85, !tbaa !24
  %t105 = icmp eq i64 %t100, %t104
  br i1 %t105, label %bb6, label %bb7
bb6:
  %t107 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l85, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  br label %bb8
bb7:
  %t113 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t113, ptr %l4, !tbaa !27
  br label %bb8
bb8:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:fnEm", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load { i64, [2 x i64] }, ptr %l9
  %t121 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t117, { i64, [2 x i64] } %t118)
  store i1 %t121, ptr %l90
  br label %bb9
bb9:
  %t122 = load i1, ptr %l90, !tbaa !21
  br i1 %t122, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr @.d108 }, ptr %l91, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t123, ptr %l92, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l94, !tbaa !24
  %t129 = load i64, ptr %l94, !tbaa !24
  %t130 = icmp eq i64 %t125, %t129
  br i1 %t130, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t132 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l94, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  br label %bb14
bb13:
  %t138 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l96, !tbaa !24
  %t140 = load i64, ptr %l96, !tbaa !24
  %t141 = mul i64 %t140, 1
  %t142 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l97, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l96, !tbaa !24
  %t150 = mul i64 %t149, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t146, ptr %t148, i64 %t150, i1 false)
  %t151 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t151, ptr %l5, !tbaa !27
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb16:
  %t152 = load { i64, [7 x i64] }, ptr %l8
  %t154 = extractvalue { i64, [7 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 1
  br i1 %t155, label %bb17, label %bb18
bb17:
  %t157 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t158 = getelementptr { i64, i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i64, ptr %t158
  store i64 %t159, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t162 = getelementptr { i64, i32 }, ptr %t161, i32 0, i32 1
  %t163 = load i32, ptr %t162
  store i32 %t163, ptr %l12, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t165 = load i32, ptr %l12, !tbaa !23
  store i32 %t165, ptr %l3, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/emit:fnEm", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l11, !tbaa !24
  %t172 = load i32, ptr %l12, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %s4, ptr %t170, i64 %t171, i32 %t172)
  store { i64, ptr } %t176, ptr %l107
  br label %bb20
bb20:
  %t177 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 0
  %t179 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t177, i64 %t178)
  %t184 = getelementptr i8, ptr %t183, i64 %t178
  call void @olang_textcopy(ptr %t184, ptr %t180, i64 %t181)
  %t185 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t183, 1
  store { i64, ptr } %t186, ptr %l108, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l110, !tbaa !24
  %t192 = load i64, ptr %l110, !tbaa !24
  %t193 = icmp eq i64 %t188, %t192
  br i1 %t193, label %bb21, label %bb22
bb21:
  %t195 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l110, !tbaa !24
  %t200 = mul i64 %t199, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %t198, i64 %t200, i1 false)
  br label %bb23
bb22:
  %t201 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t201, ptr %l4, !tbaa !27
  br label %bb23
bb23:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb24:
  %t202 = load { i64, [7 x i64] }, ptr %l8
  %t204 = extractvalue { i64, [7 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 2
  br i1 %t205, label %bb25, label %bb26
bb25:
  %t207 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t208 = getelementptr { { i64, [4 x i64] } }, ptr %t207, i32 0, i32 0
  %t209 = load { i64, [4 x i64] }, ptr %t208
  store { i64, [4 x i64] } %t209, ptr %l13
  br label %bb27
bb26:
  br label %bb38
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load { i64, [4 x i64] }, ptr %l13
  %t215 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t211, { i64, [4 x i64] } %t212)
  store i32 %t215, ptr %l117
  br label %bb28
bb28:
  %t216 = load i32, ptr %l117, !tbaa !23
  store i32 %t216, ptr %l3, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, [4 x i64] }, ptr %l13
  %t219 = load i32, ptr %l3, !tbaa !23
  %t223 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s6, ptr %t217, { i64, [4 x i64] } %t218, i32 %t219)
  store { i64, ptr } %t223, ptr %l121
  br label %bb29
bb29:
  %t224 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t224, ptr %l14, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t227 = extractvalue { i64, ptr } { i64 26, ptr @.d110 }, 1
  %t228 = extractvalue { i64, ptr } { i64 26, ptr @.d110 }, 0
  %t230 = extractvalue { i64, ptr } %t226, 1
  %t231 = extractvalue { i64, ptr } %t226, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 3, ptr @.d111 }, 1
  %t234 = extractvalue { i64, ptr } { i64 3, ptr @.d111 }, 0
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t227, i64 %t228)
  %t237 = getelementptr i8, ptr %t236, i64 %t228
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  call void @olang_textcopy(ptr %t238, ptr %t233, i64 %t234)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t236, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t250 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t225, { i64, ptr } %t247)
  store { i64, ptr } %t250, ptr %l126
  br label %bb30
bb30:
  %t251 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l128, !tbaa !24
  %t256 = load i64, ptr %l128, !tbaa !24
  %t257 = icmp eq i64 %t252, %t256
  br i1 %t257, label %bb31, label %bb32
bb31:
  %t259 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l128, !tbaa !24
  %t264 = mul i64 %t263, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t260, ptr %t262, i64 %t264, i1 false)
  br label %bb33
bb32:
  %t265 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t265, ptr %l4, !tbaa !27
  br label %bb33
bb33:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t268 = extractvalue { i64, ptr } { i64 26, ptr @.d112 }, 1
  %t269 = extractvalue { i64, ptr } { i64 26, ptr @.d112 }, 0
  %t271 = extractvalue { i64, ptr } %t267, 1
  %t272 = extractvalue { i64, ptr } %t267, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 3, ptr @.d113 }, 1
  %t275 = extractvalue { i64, ptr } { i64 3, ptr @.d113 }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t268, i64 %t269)
  %t278 = getelementptr i8, ptr %t277, i64 %t269
  call void @olang_textcopy(ptr %t278, ptr %t271, i64 %t272)
  %t279 = getelementptr i8, ptr %t278, i64 %t272
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t277, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t291 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t266, { i64, ptr } %t288)
  store { i64, ptr } %t291, ptr %l134
  br label %bb34
bb34:
  %t292 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  %t294 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  store i64 %t295, ptr %l136, !tbaa !24
  %t297 = load i64, ptr %l136, !tbaa !24
  %t298 = icmp eq i64 %t293, %t297
  br i1 %t298, label %bb35, label %bb36
bb35:
  %t300 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l136, !tbaa !24
  %t305 = mul i64 %t304, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t301, ptr %t303, i64 %t305, i1 false)
  br label %bb37
bb36:
  %t306 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t306, ptr %l5, !tbaa !27
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb38:
  %t307 = load { i64, [7 x i64] }, ptr %l8
  %t309 = extractvalue { i64, [7 x i64] } %t307, 0
  %t310 = icmp eq i64 %t309, 3
  br i1 %t310, label %bb39, label %bb40
bb39:
  %t312 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t313 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t312, i32 0, i32 0
  %t314 = load { i64, [4 x i64] }, ptr %t313
  store { i64, [4 x i64] } %t314, ptr %l15
  %t316 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t317 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t316, i32 0, i32 1
  %t318 = load i64, ptr %t317
  store i64 %t318, ptr %l16, !tbaa !24
  %t320 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t321 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t320, i32 0, i32 2
  %t322 = load i32, ptr %t321
  store i32 %t322, ptr %l17, !tbaa !23
  br label %bb41
bb40:
  br label %bb54
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t324 = load i32, ptr %l17, !tbaa !23
  store i32 %t324, ptr %l3, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l144, !tbaa !29
  %t327 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t327, ptr %l145
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load { i64, [4 x i64] }, ptr %l15
  %t332 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t328, { i64, [4 x i64] } %t329)
  store i32 %t332, ptr %l148
  br label %bb42
bb42:
  %t333 = load ptr, ptr %l144, !tbaa !29
  %t334 = load { i64, [4 x i64] }, ptr %l145
  %t335 = load i32, ptr %l148, !tbaa !23
  %t336 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s9, ptr %t333, { i64, [4 x i64] } %t334, i32 %t335)
  store { i64, ptr } %t336, ptr %l149
  br label %bb43
bb43:
  %t337 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t337, ptr %l18, !tbaa !27
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t340 = extractvalue { i64, ptr } { i64 26, ptr @.d114 }, 1
  %t341 = extractvalue { i64, ptr } { i64 26, ptr @.d114 }, 0
  %t343 = extractvalue { i64, ptr } %t339, 1
  %t344 = extractvalue { i64, ptr } %t339, 0
  %t345 = add i64 %t341, %t344
  %t346 = extractvalue { i64, ptr } { i64 3, ptr @.d115 }, 1
  %t347 = extractvalue { i64, ptr } { i64 3, ptr @.d115 }, 0
  %t348 = add i64 %t345, %t347
  %t349 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t340, i64 %t341)
  %t350 = getelementptr i8, ptr %t349, i64 %t341
  call void @olang_textcopy(ptr %t350, ptr %t343, i64 %t344)
  %t351 = getelementptr i8, ptr %t350, i64 %t344
  call void @olang_textcopy(ptr %t351, ptr %t346, i64 %t347)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t349, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t338, { i64, ptr } %t360)
  store { i64, ptr } %t363, ptr %l154
  br label %bb44
bb44:
  %t364 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  store i64 %t367, ptr %l156, !tbaa !24
  %t369 = load i64, ptr %l156, !tbaa !24
  %t370 = icmp eq i64 %t365, %t369
  br i1 %t370, label %bb45, label %bb46
bb45:
  %t372 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = load i64, ptr %l156, !tbaa !24
  %t377 = mul i64 %t376, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t373, ptr %t375, i64 %t377, i1 false)
  br label %bb47
bb46:
  %t378 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t378, ptr %l6, !tbaa !27
  br label %bb47
bb47:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t381 = extractvalue { i64, ptr } { i64 26, ptr @.d116 }, 1
  %t382 = extractvalue { i64, ptr } { i64 26, ptr @.d116 }, 0
  %t384 = extractvalue { i64, ptr } %t380, 1
  %t385 = extractvalue { i64, ptr } %t380, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 3, ptr @.d117 }, 1
  %t388 = extractvalue { i64, ptr } { i64 3, ptr @.d117 }, 0
  %t389 = add i64 %t386, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t384, i64 %t385)
  %t392 = getelementptr i8, ptr %t391, i64 %t385
  call void @olang_textcopy(ptr %t392, ptr %t387, i64 %t388)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t404 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t379, { i64, ptr } %t401)
  store { i64, ptr } %t404, ptr %l162
  br label %bb48
bb48:
  %t405 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t409 = load i64, ptr %l16, !tbaa !24
  %t412 = add i64 %t408, %t409
  %t413 = extractvalue { i64, ptr } { i64 23, ptr @.d118 }, 1
  %t414 = extractvalue { i64, ptr } { i64 23, ptr @.d118 }, 0
  %t416 = extractvalue { i64, ptr } %t405, 1
  %t417 = extractvalue { i64, ptr } %t405, 0
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 6, ptr @.d119 }, 1
  %t420 = extractvalue { i64, ptr } { i64 6, ptr @.d119 }, 0
  %t421 = add i64 %t418, %t420
  %t423 = call i64 @__olang_fmt_i64(ptr null, i64 %t412)
  %t424 = add i64 %t421, %t423
  %t425 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t413, i64 %t414)
  %t426 = getelementptr i8, ptr %t425, i64 %t414
  call void @olang_textcopy(ptr %t426, ptr %t416, i64 %t417)
  %t427 = getelementptr i8, ptr %t426, i64 %t417
  call void @olang_textcopy(ptr %t427, ptr %t419, i64 %t420)
  %t428 = getelementptr i8, ptr %t427, i64 %t420
  %t429 = call i64 @__olang_fmt_i64(ptr %t428, i64 %t412)
  %t430 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t425, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t441 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t406, { i64, ptr } %t438)
  store { i64, ptr } %t441, ptr %l170
  br label %bb49
bb49:
  %t442 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = extractvalue { i64, ptr } { i64 14, ptr @.d120 }, 1
  %t446 = extractvalue { i64, ptr } { i64 14, ptr @.d120 }, 0
  %t448 = extractvalue { i64, ptr } %t442, 1
  %t449 = extractvalue { i64, ptr } %t442, 0
  %t450 = add i64 %t446, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t445, i64 %t446)
  %t452 = getelementptr i8, ptr %t451, i64 %t446
  call void @olang_textcopy(ptr %t452, ptr %t448, i64 %t449)
  %t453 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t451, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = extractvalue { i64, ptr } %t454, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  %t464 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t443, { i64, ptr } %t461)
  store { i64, ptr } %t464, ptr %l175
  br label %bb50
bb50:
  %t465 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l177, !tbaa !24
  %t470 = load i64, ptr %l177, !tbaa !24
  %t471 = icmp eq i64 %t466, %t470
  br i1 %t471, label %bb51, label %bb52
bb51:
  %t473 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = load i64, ptr %l177, !tbaa !24
  %t478 = mul i64 %t477, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t474, ptr %t476, i64 %t478, i1 false)
  br label %bb53
bb52:
  %t479 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t479, ptr %l4, !tbaa !27
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_d166383632e6ec4e_5cd1ec2f29a4b0f2)
  unreachable
bb55:
  %t480 = load i1, ptr %l7, !tbaa !21
  br i1 %t480, label %bb56, label %bb57
bb56:
  %t482 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t484 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t482, { i64, ptr } { i64 6, ptr @.d121 })
  store i1 %t484, ptr %l182
  br label %bb58
bb57:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb59
bb58:
  %t485 = load i1, ptr %l182, !tbaa !21
  %t486 = xor i1 %t485, true
  store i1 %t486, ptr %l180, !tbaa !21
  br label %bb59
bb59:
  %t488 = load i1, ptr %l180, !tbaa !21
  br i1 %t488, label %bb60, label %bb61
bb60:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load %"compiler/mir:Call", ptr %l1
  %t491 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t492 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %s0, ptr %t489, %"compiler/mir:Call" %t490, { i64, ptr } %t491, i32 %t492)
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb63:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/emit:fnEm", ptr %t497, i32 0, i32 0
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t501 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t500, i32 %t501)
  br label %bb64
bb64:
  %t504 = load ptr, ptr %l2, !tbaa !29
  %t505 = load i32, ptr %l3, !tbaa !23
  %t508 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t504, i32 %t505)
  store i32 %t508, ptr %l193
  br label %bb65
bb65:
  %t509 = load i32, ptr %l193, !tbaa !23
  store i32 %t509, ptr %l21, !tbaa !23
  %t510 = load ptr, ptr %l2, !tbaa !29
  store ptr %t510, ptr %l194, !tbaa !29
  %t511 = load ptr, ptr %l2, !tbaa !29
  %t512 = load i32, ptr %l3, !tbaa !23
  %t515 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t511, i32 %t512)
  store i32 %t515, ptr %l197
  br label %bb66
bb66:
  %t516 = load ptr, ptr %l194, !tbaa !29
  %t517 = load i32, ptr %l197, !tbaa !23
  %t518 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t516, i32 %t517)
  store { i64, ptr } %t518, ptr %l198
  br label %bb67
bb67:
  %t519 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t522 = icmp sgt i64 %t520, 0
  store i1 %t522, ptr %l22, !tbaa !21
  %t524 = load i32, ptr %l21, !tbaa !23
  %t525 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t528 = icmp ne i32 %t524, %t525
  br i1 %t528, label %bb68, label %bb69
bb68:
  %t530 = load i32, ptr %l21, !tbaa !23
  %t531 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t534 = icmp ne i32 %t530, %t531
  store i1 %t534, ptr %l204, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb70
bb70:
  %t536 = load i1, ptr %l204, !tbaa !21
  br i1 %t536, label %bb71, label %bb72
bb71:
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load i32, ptr %l21, !tbaa !23
  %t541 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t537, i32 %t538)
  store i1 %t541, ptr %l211
  br label %bb73
bb72:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb74
bb73:
  %t542 = load i1, ptr %l211, !tbaa !21
  store i1 %t542, ptr %l208, !tbaa !21
  br label %bb74
bb74:
  %t543 = load i1, ptr %l208, !tbaa !21
  store i1 %t543, ptr %l23, !tbaa !21
  %t544 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t544, ptr %l212
  br label %bb75
bb75:
  %t545 = load %"std/prelude/text:StringBuilder", ptr %l212
  store %"std/prelude/text:StringBuilder" %t545, ptr %l24
  store i1 true, ptr %l25, !tbaa !21
  %t546 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t548 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t546, { i64, ptr } { i64 0, ptr @.d122 })
  store i1 %t548, ptr %l214
  br label %bb76
bb76:
  %t549 = load i1, ptr %l214, !tbaa !21
  %t550 = xor i1 %t549, true
  br i1 %t550, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  %t552 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t553 = extractvalue { i64, ptr } { i64 4, ptr @.d123 }, 1
  %t554 = extractvalue { i64, ptr } { i64 4, ptr @.d123 }, 0
  %t556 = extractvalue { i64, ptr } %t552, 1
  %t557 = extractvalue { i64, ptr } %t552, 0
  %t558 = add i64 %t554, %t557
  %t559 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t558)
  call void @olang_textcopy(ptr %t559, ptr %t553, i64 %t554)
  %t560 = getelementptr i8, ptr %t559, i64 %t554
  call void @olang_textcopy(ptr %t560, ptr %t556, i64 %t557)
  %t561 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t559, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l24, { i64, ptr } %t569)
  br label %bb79
bb78:
  br label %bb80
bb79:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb80
bb80:
  store { i64, ptr } { i64 0, ptr @.d124 }, ptr %l220, !tbaa !27
  %t572 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t572, ptr %l221, !tbaa !27
  %t573 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  store i64 %t574, ptr %l222, !tbaa !24
  %t575 = load i64, ptr %l222, !tbaa !24
  %t576 = mul i64 %t575, 1
  %t577 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t576)
  %t578 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  store { i64, ptr } %t579, ptr %l223, !tbaa !27
  %t580 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = load i64, ptr %l222, !tbaa !24
  %t585 = mul i64 %t584, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t581, ptr %t583, i64 %t585, i1 false)
  %t586 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t586, ptr %l26, !tbaa !27
  %t587 = load i1, ptr %l23, !tbaa !21
  br i1 %t587, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i32, ptr %l21, !tbaa !23
  %t593 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s0, ptr %t589, i32 %t590)
  store { i64, ptr } %t593, ptr %l227
  br label %bb83
bb82:
  br label %bb92
bb83:
  %t594 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t595 = extractvalue { i64, ptr } %t594, 0
  %t596 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  store i64 %t597, ptr %l229, !tbaa !24
  %t599 = load i64, ptr %l229, !tbaa !24
  %t600 = icmp eq i64 %t595, %t599
  br i1 %t600, label %bb84, label %bb85
bb84:
  %t602 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !27
  %t606 = load i64, ptr %l229, !tbaa !24
  %t607 = mul i64 %t606, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t603, ptr %t605, i64 %t607, i1 false)
  br label %bb86
bb85:
  %t608 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t608, ptr %l26, !tbaa !27
  br label %bb86
bb86:
  %t609 = load i1, ptr %l25, !tbaa !21
  %t611 = xor i1 %t609, true
  br i1 %t611, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l24, { i64, ptr } { i64 2, ptr @.d125 })
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t614 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t615 = extractvalue { i64, ptr } { i64 4, ptr @.d126 }, 1
  %t616 = extractvalue { i64, ptr } { i64 4, ptr @.d126 }, 0
  %t618 = extractvalue { i64, ptr } %t614, 1
  %t619 = extractvalue { i64, ptr } %t614, 0
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  call void @olang_textcopy(ptr %t622, ptr %t618, i64 %t619)
  %t623 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t621, 1
  %t626 = extractvalue { i64, ptr } %t624, 0
  %t627 = extractvalue { i64, ptr } %t624, 1
  %t628 = mul i64 %t626, 1
  %t629 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t629, ptr %t627, i64 %t628, i1 false)
  %t630 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %l24, { i64, ptr } %t631)
  br label %bb91
bb91:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb92
bb92:
  store i32 0, ptr %l27, !tbaa !23
  %t634 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t635 = getelementptr %"compiler/mir:Range", ptr %t634, i32 0, i32 1
  %t636 = load i32, ptr %t635, !tbaa !23
  store i32 %t636, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t638 = load i32, ptr %l28, !tbaa !23
  %t639 = load i32, ptr %l27, !tbaa !23
  %t642 = icmp sgt i32 %t638, %t639
  br i1 %t642, label %bb93, label %bb94
bb93:
  %t644 = load i32, ptr %l29, !tbaa !23
  %t646 = icmp sgt i32 %t644, 0
  br i1 %t646, label %bb95, label %bb96
bb94:
  store i32 0, ptr %l242, !tbaa !23
  br label %bb98
bb95:
  %t648 = load i32, ptr %l28, !tbaa !23
  %t649 = load i32, ptr %l27, !tbaa !23
  %t652 = sub i32 %t648, %t649
  %t653 = load i32, ptr %l29, !tbaa !23
  %t656 = add i32 %t652, %t653
  %t658 = sub i32 %t656, 1
  %t659 = load i32, ptr %l29, !tbaa !23
  %t662 = sdiv i32 %t658, %t659
  store i32 %t662, ptr %l245, !tbaa !23
  br label %bb97
bb96:
  store i32 0, ptr %l245, !tbaa !23
  br label %bb97
bb97:
  %t664 = load i32, ptr %l245, !tbaa !23
  store i32 %t664, ptr %l242, !tbaa !23
  br label %bb98
bb98:
  %t665 = load i32, ptr %l242, !tbaa !23
  store i32 %t665, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s21
  %t666 = load i32, ptr %l31, !tbaa !23
  %t667 = load i32, ptr %l30, !tbaa !23
  %t670 = icmp slt i32 %t666, %t667
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s21)
  br label %bb111
bb101:
  br label %bb102
bb102:
  %t674 = load i32, ptr %l27, !tbaa !23
  %t675 = load i32, ptr %l31, !tbaa !23
  %t676 = load i32, ptr %l29, !tbaa !23
  %t679 = mul i32 %t675, %t676
  %t682 = add i32 %t674, %t679
  store i32 %t682, ptr %l32, !tbaa !23
  %t684 = load i1, ptr %l25, !tbaa !21
  %t686 = xor i1 %t684, true
  br i1 %t686, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l24, { i64, ptr } { i64 2, ptr @.d127 })
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb106:
  store i1 false, ptr %l25, !tbaa !21
  store ptr %l24, ptr %l266, !tbaa !29
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l267, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/emit:fnEm", ptr %t690, i32 0, i32 1
  %t693 = load ptr, ptr %t692, !tbaa !29
  %t695 = getelementptr %"compiler/mir:Fn", ptr %t693, i32 0, i32 12
  %t696 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t697 = getelementptr %"compiler/mir:Range", ptr %t696, i32 0, i32 0
  %t698 = load i32, ptr %t697, !tbaa !23
  %t700 = sext i32 %t698 to i64
  %t701 = load i32, ptr %l32, !tbaa !23
  %t703 = sext i32 %t701 to i64
  %t706 = add i64 %t700, %t703
  %t709 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t695, i64 %t706)
  store { i64, [1 x i64] } %t709, ptr %l276
  br label %bb107
bb107:
  %t710 = load ptr, ptr %l267, !tbaa !29
  %t711 = load { i64, [1 x i64] }, ptr %l276
  %t712 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s21, ptr %t710, { i64, [1 x i64] } %t711)
  store { i64, ptr } %t712, ptr %l277
  br label %bb108
bb108:
  %t713 = extractvalue { i64, ptr } { i64 4, ptr @.d128 }, 1
  %t714 = extractvalue { i64, ptr } { i64 4, ptr @.d128 }, 0
  %t715 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 1
  %t717 = extractvalue { i64, ptr } %t715, 0
  %t718 = add i64 %t714, %t717
  %t719 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t718)
  call void @olang_textcopy(ptr %t719, ptr %t713, i64 %t714)
  %t720 = getelementptr i8, ptr %t719, i64 %t714
  call void @olang_textcopy(ptr %t720, ptr %t716, i64 %t717)
  %t721 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t722 = insertvalue { i64, ptr } %t721, ptr %t719, 1
  %t724 = extractvalue { i64, ptr } %t722, 0
  %t725 = extractvalue { i64, ptr } %t722, 1
  %t726 = mul i64 %t724, 1
  %t727 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t726)
  call void @llvm.memcpy.p0.p0.i64(ptr %t727, ptr %t725, i64 %t726, i1 false)
  %t728 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t727, 1
  %t730 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t730, { i64, ptr } %t729)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s21)
  br label %bb110
bb110:
  %t732 = load i32, ptr %l31, !tbaa !23
  %t734 = add i32 %t732, 1
  store i32 %t734, ptr %l31, !tbaa !23
  br label %bb99
bb111:
  %t736 = load ptr, ptr %l2, !tbaa !29
  store ptr %t736, ptr %l282, !tbaa !29
  %t737 = load ptr, ptr %l2, !tbaa !29
  %t738 = load i32, ptr %l3, !tbaa !23
  %t741 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t737, i32 %t738)
  store i32 %t741, ptr %l285
  br label %bb112
bb112:
  %t742 = load ptr, ptr %l282, !tbaa !29
  %t743 = load i32, ptr %l285, !tbaa !23
  %t744 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t742, i32 %t743)
  store { i64, ptr } %t744, ptr %l286
  br label %bb113
bb113:
  %t745 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t745, ptr %l33, !tbaa !27
  %t746 = load ptr, ptr %l2, !tbaa !29
  %t747 = load i32, ptr %l3, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t746, i32 %t747)
  store { i64, ptr } %t750, ptr %l289
  br label %bb114
bb114:
  %t751 = load { i64, ptr }, ptr %l289, !tbaa !27
  store { i64, ptr } %t751, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t752 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t752, 0
  store i64 %t754, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t756 = load i64, ptr %l36, !tbaa !24
  %t757 = load i64, ptr %l35, !tbaa !24
  %t760 = icmp sgt i64 %t756, %t757
  br i1 %t760, label %bb115, label %bb116
bb115:
  %t762 = load i64, ptr %l37, !tbaa !24
  %t764 = icmp sgt i64 %t762, 0
  br i1 %t764, label %bb117, label %bb118
bb116:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb120
bb117:
  %t766 = load i64, ptr %l36, !tbaa !24
  %t767 = load i64, ptr %l35, !tbaa !24
  %t770 = sub i64 %t766, %t767
  %t771 = load i64, ptr %l37, !tbaa !24
  %t774 = add i64 %t770, %t771
  %t776 = sub i64 %t774, 1
  %t777 = load i64, ptr %l37, !tbaa !24
  %t780 = sdiv i64 %t776, %t777
  store i64 %t780, ptr %l298, !tbaa !24
  br label %bb119
bb118:
  store i64 0, ptr %l298, !tbaa !24
  br label %bb119
bb119:
  %t782 = load i64, ptr %l298, !tbaa !24
  store i64 %t782, ptr %l295, !tbaa !24
  br label %bb120
bb120:
  %t783 = load i64, ptr %l295, !tbaa !24
  store i64 %t783, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s26
  %t784 = load i64, ptr %l39, !tbaa !24
  %t785 = load i64, ptr %l38, !tbaa !24
  %t788 = icmp slt i64 %t784, %t785
  %t790 = xor i1 %t788, true
  br i1 %t790, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s26)
  br label %bb168
bb123:
  br label %bb124
bb124:
  %t792 = load i64, ptr %l35, !tbaa !24
  %t793 = load i64, ptr %l39, !tbaa !24
  %t794 = load i64, ptr %l37, !tbaa !24
  %t797 = mul i64 %t793, %t794
  %t800 = add i64 %t792, %t797
  store i64 %t800, ptr %l40, !tbaa !24
  %t802 = load i1, ptr %l25, !tbaa !21
  %t804 = xor i1 %t802, true
  br i1 %t804, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l24, { i64, ptr } { i64 2, ptr @.d129 })
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_scope_close(ptr %s27)
  br label %bb128
bb128:
  store i1 false, ptr %l25, !tbaa !21
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t809 = load %"compiler/mir:Range", ptr %t808
  %t810 = load i64, ptr %l40, !tbaa !24
  %t814 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t807, %"compiler/mir:Range" %t809, i64 %t810)
  store { i64, [4 x i64] } %t814, ptr %l322
  br label %bb129
bb129:
  %t815 = load { i64, [4 x i64] }, ptr %l322
  store { i64, [4 x i64] } %t815, ptr %l41
  %t816 = load i64, ptr %l40, !tbaa !24
  %t818 = icmp eq i64 %t816, 0
  br i1 %t818, label %bb130, label %bb131
bb130:
  %t820 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t822 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s26, { i64, ptr } %t820, { i64, ptr } { i64 0, ptr @.d130 })
  store i1 %t822, ptr %l327
  br label %bb132
bb131:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb133
bb132:
  %t823 = load i1, ptr %l327, !tbaa !21
  %t824 = xor i1 %t823, true
  store i1 %t824, ptr %l325, !tbaa !21
  br label %bb133
bb133:
  %t826 = load i1, ptr %l325, !tbaa !21
  br i1 %t826, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s28
  %t827 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t828 = extractvalue { i64, ptr } { i64 4, ptr @.d131 }, 1
  %t829 = extractvalue { i64, ptr } { i64 4, ptr @.d131 }, 0
  %t831 = extractvalue { i64, ptr } %t827, 1
  %t832 = extractvalue { i64, ptr } %t827, 0
  %t833 = add i64 %t829, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t828, i64 %t829)
  %t835 = getelementptr i8, ptr %t834, i64 %t829
  call void @olang_textcopy(ptr %t835, ptr %t831, i64 %t832)
  %t836 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t834, 1
  %t839 = extractvalue { i64, ptr } %t837, 0
  %t840 = extractvalue { i64, ptr } %t837, 1
  %t841 = mul i64 %t839, 1
  %t842 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t841)
  call void @llvm.memcpy.p0.p0.i64(ptr %t842, ptr %t840, i64 %t841, i1 false)
  %t843 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t844 = insertvalue { i64, ptr } %t843, ptr %t842, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l24, { i64, ptr } %t844)
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb137:
  %t847 = load i1, ptr %l7, !tbaa !21
  %t849 = xor i1 %t847, true
  br i1 %t849, label %bb138, label %bb139
bb138:
  %t851 = load i64, ptr %l40, !tbaa !24
  %t853 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !27
  %t855 = getelementptr i8, ptr %t854, i64 %t851
  %t856 = load i8, ptr %t855, !tbaa !32
  %t858 = icmp eq i8 %t856, 109
  store i1 %t858, ptr %l335, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb140
bb140:
  %t860 = load i1, ptr %l335, !tbaa !21
  br i1 %t860, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s30
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t862, ptr %l340, !tbaa !27
  %t863 = load i64, ptr %l40, !tbaa !24
  %t865 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = getelementptr i32, ptr %t866, i64 %t863
  %t868 = load i32, ptr %t867, !tbaa !33
  %t871 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s30, ptr %t861, i32 %t868)
  store { i64, ptr } %t871, ptr %l343
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t872 = load { i64, ptr }, ptr %l343, !tbaa !27
  store { i64, ptr } %t872, ptr %l42, !tbaa !27
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t874 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t875 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t875, ptr %l346, !tbaa !27
  %t876 = load i64, ptr %l40, !tbaa !24
  %t878 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !27
  %t880 = getelementptr i32, ptr %t879, i64 %t876
  %t881 = load i32, ptr %t880, !tbaa !33
  %t882 = load { i64, [4 x i64] }, ptr %l41
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s30, ptr %s30, ptr %t873, { i64, ptr } %t874, i32 %t881, { i64, [4 x i64] } %t882, { i64, ptr } { i64 0, ptr @.d132 })
  br label %bb144
bb144:
  %t887 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t888 = extractvalue { i64, ptr } { i64 4, ptr @.d133 }, 1
  %t889 = extractvalue { i64, ptr } { i64 4, ptr @.d133 }, 0
  %t891 = extractvalue { i64, ptr } %t887, 1
  %t892 = extractvalue { i64, ptr } %t887, 0
  %t893 = add i64 %t889, %t892
  %t894 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t893)
  call void @olang_textcopy(ptr %t894, ptr %t888, i64 %t889)
  %t895 = getelementptr i8, ptr %t894, i64 %t889
  call void @olang_textcopy(ptr %t895, ptr %t891, i64 %t892)
  %t896 = insertvalue { i64, ptr } undef, i64 %t893, 0
  %t897 = insertvalue { i64, ptr } %t896, ptr %t894, 1
  %t899 = extractvalue { i64, ptr } %t897, 0
  %t900 = extractvalue { i64, ptr } %t897, 1
  %t901 = mul i64 %t899, 1
  %t902 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t901)
  call void @llvm.memcpy.p0.p0.i64(ptr %t902, ptr %t900, i64 %t901, i1 false)
  %t903 = insertvalue { i64, ptr } undef, i64 %t899, 0
  %t904 = insertvalue { i64, ptr } %t903, ptr %t902, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s30, ptr %l24, { i64, ptr } %t904)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb146:
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t908 = load { i64, [4 x i64] }, ptr %l41
  %t909 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t909, ptr %l356, !tbaa !27
  %t910 = load i64, ptr %l40, !tbaa !24
  %t912 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = getelementptr i32, ptr %t913, i64 %t910
  %t915 = load i32, ptr %t914, !tbaa !33
  %t919 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s26, ptr %t907, { i64, [4 x i64] } %t908, i32 %t915)
  store { i64, ptr } %t919, ptr %l359
  br label %bb147
bb147:
  %t920 = load { i64, ptr }, ptr %l359, !tbaa !27
  store { i64, ptr } %t920, ptr %l43, !tbaa !27
  %t921 = load i1, ptr %l7, !tbaa !21
  br i1 %t921, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s32
  store ptr %l24, ptr %l361, !tbaa !29
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t925 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t925, ptr %l364, !tbaa !27
  %t926 = load i64, ptr %l40, !tbaa !24
  %t928 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t929 = load ptr, ptr %t928, !tbaa !27
  %t930 = getelementptr i32, ptr %t929, i64 %t926
  %t931 = load i32, ptr %t930, !tbaa !33
  %t935 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s26, ptr %s32, ptr %t923, { i64, ptr } %t924, i32 %t931)
  store { i64, ptr } %t935, ptr %l367
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t936 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 0
  %t938 = extractvalue { i64, ptr } %t936, 1
  %t939 = mul i64 %t937, 1
  %t940 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t939)
  call void @llvm.memcpy.p0.p0.i64(ptr %t940, ptr %t938, i64 %t939, i1 false)
  %t941 = insertvalue { i64, ptr } undef, i64 %t937, 0
  %t942 = insertvalue { i64, ptr } %t941, ptr %t940, 1
  %t943 = load ptr, ptr %l361, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s32, ptr %t943, { i64, ptr } %t942)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb152:
  %t945 = load i64, ptr %l40, !tbaa !24
  %t947 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t948 = load ptr, ptr %t947, !tbaa !27
  %t949 = getelementptr i8, ptr %t948, i64 %t945
  %t950 = load i8, ptr %t949, !tbaa !32
  %t954 = icmp eq i8 %t950, 115
  br i1 %t954, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb159
bb155:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l24, ptr %l373, !tbaa !29
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t957 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t958 = extractvalue { i64, ptr } { i64 26, ptr @.d134 }, 1
  %t959 = extractvalue { i64, ptr } { i64 26, ptr @.d134 }, 0
  %t961 = extractvalue { i64, ptr } %t957, 1
  %t962 = extractvalue { i64, ptr } %t957, 0
  %t963 = add i64 %t959, %t962
  %t964 = extractvalue { i64, ptr } { i64 3, ptr @.d135 }, 1
  %t965 = extractvalue { i64, ptr } { i64 3, ptr @.d135 }, 0
  %t966 = add i64 %t963, %t965
  %t967 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t966)
  call void @olang_textcopy(ptr %t967, ptr %t958, i64 %t959)
  %t968 = getelementptr i8, ptr %t967, i64 %t959
  call void @olang_textcopy(ptr %t968, ptr %t961, i64 %t962)
  %t969 = getelementptr i8, ptr %t968, i64 %t962
  call void @olang_textcopy(ptr %t969, ptr %t964, i64 %t965)
  %t970 = insertvalue { i64, ptr } undef, i64 %t966, 0
  %t971 = insertvalue { i64, ptr } %t970, ptr %t967, 1
  %t973 = extractvalue { i64, ptr } %t971, 0
  %t974 = extractvalue { i64, ptr } %t971, 1
  %t975 = mul i64 %t973, 1
  %t976 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t975)
  call void @llvm.memcpy.p0.p0.i64(ptr %t976, ptr %t974, i64 %t975, i1 false)
  %t977 = insertvalue { i64, ptr } undef, i64 %t973, 0
  %t978 = insertvalue { i64, ptr } %t977, ptr %t976, 1
  %t981 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s33, ptr %s33, ptr %t956, { i64, ptr } %t978)
  store { i64, ptr } %t981, ptr %l378
  br label %bb156
bb156:
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t983 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t984 = extractvalue { i64, ptr } { i64 26, ptr @.d136 }, 1
  %t985 = extractvalue { i64, ptr } { i64 26, ptr @.d136 }, 0
  %t987 = extractvalue { i64, ptr } %t983, 1
  %t988 = extractvalue { i64, ptr } %t983, 0
  %t989 = add i64 %t985, %t988
  %t990 = extractvalue { i64, ptr } { i64 3, ptr @.d137 }, 1
  %t991 = extractvalue { i64, ptr } { i64 3, ptr @.d137 }, 0
  %t992 = add i64 %t989, %t991
  %t993 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t992)
  call void @olang_textcopy(ptr %t993, ptr %t984, i64 %t985)
  %t994 = getelementptr i8, ptr %t993, i64 %t985
  call void @olang_textcopy(ptr %t994, ptr %t987, i64 %t988)
  %t995 = getelementptr i8, ptr %t994, i64 %t988
  call void @olang_textcopy(ptr %t995, ptr %t990, i64 %t991)
  %t996 = insertvalue { i64, ptr } undef, i64 %t992, 0
  %t997 = insertvalue { i64, ptr } %t996, ptr %t993, 1
  %t999 = extractvalue { i64, ptr } %t997, 0
  %t1000 = extractvalue { i64, ptr } %t997, 1
  %t1001 = mul i64 %t999, 1
  %t1002 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1001)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1002, ptr %t1000, i64 %t1001, i1 false)
  %t1003 = insertvalue { i64, ptr } undef, i64 %t999, 0
  %t1004 = insertvalue { i64, ptr } %t1003, ptr %t1002, 1
  %t1007 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s33, ptr %s33, ptr %t982, { i64, ptr } %t1004)
  store { i64, ptr } %t1007, ptr %l383
  br label %bb157
bb157:
  %t1008 = extractvalue { i64, ptr } { i64 4, ptr @.d138 }, 1
  %t1009 = extractvalue { i64, ptr } { i64 4, ptr @.d138 }, 0
  %t1010 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t1011 = extractvalue { i64, ptr } %t1010, 1
  %t1012 = extractvalue { i64, ptr } %t1010, 0
  %t1013 = add i64 %t1009, %t1012
  %t1014 = extractvalue { i64, ptr } { i64 6, ptr @.d139 }, 1
  %t1015 = extractvalue { i64, ptr } { i64 6, ptr @.d139 }, 0
  %t1016 = add i64 %t1013, %t1015
  %t1017 = load { i64, ptr }, ptr %l383, !tbaa !27
  %t1018 = extractvalue { i64, ptr } %t1017, 1
  %t1019 = extractvalue { i64, ptr } %t1017, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1020)
  call void @olang_textcopy(ptr %t1021, ptr %t1008, i64 %t1009)
  %t1022 = getelementptr i8, ptr %t1021, i64 %t1009
  call void @olang_textcopy(ptr %t1022, ptr %t1011, i64 %t1012)
  %t1023 = getelementptr i8, ptr %t1022, i64 %t1012
  call void @olang_textcopy(ptr %t1023, ptr %t1014, i64 %t1015)
  %t1024 = getelementptr i8, ptr %t1023, i64 %t1015
  call void @olang_textcopy(ptr %t1024, ptr %t1018, i64 %t1019)
  %t1025 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1026 = insertvalue { i64, ptr } %t1025, ptr %t1021, 1
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  %t1029 = extractvalue { i64, ptr } %t1026, 1
  %t1030 = mul i64 %t1028, 1
  %t1031 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1030)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1031, ptr %t1029, i64 %t1030, i1 false)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1028, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1031, 1
  %t1034 = load ptr, ptr %l373, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %t1034, { i64, ptr } %t1033)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s33)
  br label %bb166
bb159:
  br i1 true, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb165
bb162:
  store %olang.scope zeroinitializer, ptr %s37
  store ptr %l24, ptr %l386, !tbaa !29
  %t1036 = load ptr, ptr %l0, !tbaa !29
  %t1037 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t1037, ptr %l388, !tbaa !27
  %t1038 = load i64, ptr %l40, !tbaa !24
  %t1040 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t1041 = load ptr, ptr %t1040, !tbaa !27
  %t1042 = getelementptr i32, ptr %t1041, i64 %t1038
  %t1043 = load i32, ptr %t1042, !tbaa !33
  %t1046 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s37, ptr %t1036, i32 %t1043)
  store { i64, ptr } %t1046, ptr %l391
  br label %bb163
bb163:
  %t1047 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1048 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t1049 = extractvalue { i64, ptr } %t1048, 1
  %t1050 = extractvalue { i64, ptr } %t1048, 0
  %t1051 = extractvalue { i64, ptr } { i64 1, ptr @.d140 }, 1
  %t1052 = extractvalue { i64, ptr } { i64 1, ptr @.d140 }, 0
  %t1053 = add i64 %t1050, %t1052
  %t1055 = extractvalue { i64, ptr } %t1047, 1
  %t1056 = extractvalue { i64, ptr } %t1047, 0
  %t1057 = add i64 %t1053, %t1056
  %t1058 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1057)
  call void @olang_textcopy(ptr %t1058, ptr %t1049, i64 %t1050)
  %t1059 = getelementptr i8, ptr %t1058, i64 %t1050
  call void @olang_textcopy(ptr %t1059, ptr %t1051, i64 %t1052)
  %t1060 = getelementptr i8, ptr %t1059, i64 %t1052
  call void @olang_textcopy(ptr %t1060, ptr %t1055, i64 %t1056)
  %t1061 = insertvalue { i64, ptr } undef, i64 %t1057, 0
  %t1062 = insertvalue { i64, ptr } %t1061, ptr %t1058, 1
  %t1064 = extractvalue { i64, ptr } %t1062, 0
  %t1065 = extractvalue { i64, ptr } %t1062, 1
  %t1066 = mul i64 %t1064, 1
  %t1067 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1066)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1067, ptr %t1065, i64 %t1066, i1 false)
  %t1068 = insertvalue { i64, ptr } undef, i64 %t1064, 0
  %t1069 = insertvalue { i64, ptr } %t1068, ptr %t1067, 1
  %t1070 = load ptr, ptr %l386, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s37, ptr %t1070, { i64, ptr } %t1069)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s37)
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_9199a3ab2b5d08f_bd3a4c654376a573)
  unreachable
bb166:
  call void @__olang_scope_close(ptr %s26)
  br label %bb167
bb167:
  %t1072 = load i64, ptr %l39, !tbaa !24
  %t1074 = add i64 %t1072, 1
  store i64 %t1074, ptr %l39, !tbaa !24
  br label %bb121
bb168:
  %t1076 = load i1, ptr %l7, !tbaa !21
  br i1 %t1076, label %bb169, label %bb170
bb169:
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1080 = getelementptr %"compiler/emit:fnEm", ptr %t1078, i32 0, i32 0
  %t1081 = load ptr, ptr %t1080, !tbaa !29
  %t1082 = load i32, ptr %l3, !tbaa !23
  %t1085 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s0, ptr %t1081, i32 %t1082)
  store { i64, ptr } %t1085, ptr %l402
  br label %bb171
bb170:
  %t1086 = load ptr, ptr %l2, !tbaa !29
  %t1087 = load i32, ptr %l3, !tbaa !23
  %t1090 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t1086, i32 %t1087)
  store { i64, ptr } %t1090, ptr %l405
  br label %bb172
bb171:
  %t1091 = load { i64, ptr }, ptr %l402, !tbaa !27
  store { i64, ptr } %t1091, ptr %l398, !tbaa !27
  br label %bb173
bb172:
  %t1092 = load { i64, ptr }, ptr %l405, !tbaa !27
  store { i64, ptr } %t1092, ptr %l398, !tbaa !27
  br label %bb173
bb173:
  %t1093 = load { i64, ptr }, ptr %l398, !tbaa !27
  store { i64, ptr } %t1093, ptr %l45, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d141 }, ptr %l406, !tbaa !27
  %t1094 = load { i64, ptr }, ptr %l406, !tbaa !27
  store { i64, ptr } %t1094, ptr %l407, !tbaa !27
  %t1095 = load { i64, ptr }, ptr %l407, !tbaa !27
  %t1096 = extractvalue { i64, ptr } %t1095, 0
  store i64 %t1096, ptr %l408, !tbaa !24
  %t1097 = load i64, ptr %l408, !tbaa !24
  %t1098 = mul i64 %t1097, 1
  %t1099 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1098)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1097, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1099, 1
  store { i64, ptr } %t1101, ptr %l409, !tbaa !27
  %t1102 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t1103 = load ptr, ptr %t1102, !tbaa !27
  %t1104 = getelementptr { i64, ptr }, ptr %l407, i32 0, i32 1
  %t1105 = load ptr, ptr %t1104, !tbaa !27
  %t1106 = load i64, ptr %l408, !tbaa !24
  %t1107 = mul i64 %t1106, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1103, ptr %t1105, i64 %t1107, i1 false)
  %t1108 = load { i64, ptr }, ptr %l409, !tbaa !27
  store { i64, ptr } %t1108, ptr %l46, !tbaa !27
  %t1109 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1109, { i64, ptr } { i64 4, ptr @.d142 })
  store i1 %t1111, ptr %l411
  br label %bb174
bb174:
  %t1112 = load i1, ptr %l411, !tbaa !21
  br i1 %t1112, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s40
  %t1113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1113, ptr %l412, !tbaa !29
  %t1114 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1114, ptr %l413, !tbaa !27
  %t1116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s40, ptr %l24)
  store { i64, ptr } %t1116, ptr %l415
  br label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s42
  %t1117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1117, ptr %l418, !tbaa !29
  %t1118 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1118, ptr %l419, !tbaa !27
  %t1119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t1119, ptr %l420, !tbaa !27
  %t1121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s42, ptr %l24)
  store { i64, ptr } %t1121, ptr %l422
  br label %bb179
bb177:
  %t1122 = extractvalue { i64, ptr } { i64 10, ptr @.d143 }, 1
  %t1123 = extractvalue { i64, ptr } { i64 10, ptr @.d143 }, 0
  %t1124 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t1125 = extractvalue { i64, ptr } %t1124, 1
  %t1126 = extractvalue { i64, ptr } %t1124, 0
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 1, ptr @.d144 }, 1
  %t1129 = extractvalue { i64, ptr } { i64 1, ptr @.d144 }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = load { i64, ptr }, ptr %l415, !tbaa !27
  %t1132 = extractvalue { i64, ptr } %t1131, 1
  %t1133 = extractvalue { i64, ptr } %t1131, 0
  %t1134 = add i64 %t1130, %t1133
  %t1135 = extractvalue { i64, ptr } { i64 1, ptr @.d145 }, 1
  %t1136 = extractvalue { i64, ptr } { i64 1, ptr @.d145 }, 0
  %t1137 = add i64 %t1134, %t1136
  %t1138 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1137)
  call void @olang_textcopy(ptr %t1138, ptr %t1122, i64 %t1123)
  %t1139 = getelementptr i8, ptr %t1138, i64 %t1123
  call void @olang_textcopy(ptr %t1139, ptr %t1125, i64 %t1126)
  %t1140 = getelementptr i8, ptr %t1139, i64 %t1126
  call void @olang_textcopy(ptr %t1140, ptr %t1128, i64 %t1129)
  %t1141 = getelementptr i8, ptr %t1140, i64 %t1129
  call void @olang_textcopy(ptr %t1141, ptr %t1132, i64 %t1133)
  %t1142 = getelementptr i8, ptr %t1141, i64 %t1133
  call void @olang_textcopy(ptr %t1142, ptr %t1135, i64 %t1136)
  %t1143 = insertvalue { i64, ptr } undef, i64 %t1137, 0
  %t1144 = insertvalue { i64, ptr } %t1143, ptr %t1138, 1
  %t1146 = extractvalue { i64, ptr } %t1144, 0
  %t1147 = extractvalue { i64, ptr } %t1144, 1
  %t1148 = mul i64 %t1146, 1
  %t1149 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1149, ptr %t1147, i64 %t1148, i1 false)
  %t1150 = insertvalue { i64, ptr } undef, i64 %t1146, 0
  %t1151 = insertvalue { i64, ptr } %t1150, ptr %t1149, 1
  %t1152 = load ptr, ptr %l412, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s40, ptr %t1152, { i64, ptr } %t1151)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s40)
  br label %bb184
bb179:
  %t1154 = extractvalue { i64, ptr } { i64 5, ptr @.d146 }, 1
  %t1155 = extractvalue { i64, ptr } { i64 5, ptr @.d146 }, 0
  %t1156 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1156, 1
  %t1158 = extractvalue { i64, ptr } %t1156, 0
  %t1159 = add i64 %t1155, %t1158
  %t1160 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 1
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 0
  %t1162 = add i64 %t1159, %t1161
  %t1163 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t1164 = extractvalue { i64, ptr } %t1163, 1
  %t1165 = extractvalue { i64, ptr } %t1163, 0
  %t1166 = add i64 %t1162, %t1165
  %t1167 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 1
  %t1168 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 0
  %t1169 = add i64 %t1166, %t1168
  %t1170 = load { i64, ptr }, ptr %l422, !tbaa !27
  %t1171 = extractvalue { i64, ptr } %t1170, 1
  %t1172 = extractvalue { i64, ptr } %t1170, 0
  %t1173 = add i64 %t1169, %t1172
  %t1174 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 1
  %t1175 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 0
  %t1176 = add i64 %t1173, %t1175
  %t1177 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1176)
  call void @olang_textcopy(ptr %t1177, ptr %t1154, i64 %t1155)
  %t1178 = getelementptr i8, ptr %t1177, i64 %t1155
  call void @olang_textcopy(ptr %t1178, ptr %t1157, i64 %t1158)
  %t1179 = getelementptr i8, ptr %t1178, i64 %t1158
  call void @olang_textcopy(ptr %t1179, ptr %t1160, i64 %t1161)
  %t1180 = getelementptr i8, ptr %t1179, i64 %t1161
  call void @olang_textcopy(ptr %t1180, ptr %t1164, i64 %t1165)
  %t1181 = getelementptr i8, ptr %t1180, i64 %t1165
  call void @olang_textcopy(ptr %t1181, ptr %t1167, i64 %t1168)
  %t1182 = getelementptr i8, ptr %t1181, i64 %t1168
  call void @olang_textcopy(ptr %t1182, ptr %t1171, i64 %t1172)
  %t1183 = getelementptr i8, ptr %t1182, i64 %t1172
  call void @olang_textcopy(ptr %t1183, ptr %t1174, i64 %t1175)
  %t1184 = insertvalue { i64, ptr } undef, i64 %t1176, 0
  %t1185 = insertvalue { i64, ptr } %t1184, ptr %t1177, 1
  %t1187 = extractvalue { i64, ptr } %t1185, 0
  %t1188 = extractvalue { i64, ptr } %t1185, 1
  %t1189 = mul i64 %t1187, 1
  %t1190 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1190, ptr %t1188, i64 %t1189, i1 false)
  %t1191 = insertvalue { i64, ptr } undef, i64 %t1187, 0
  %t1192 = insertvalue { i64, ptr } %t1191, ptr %t1190, 1
  %t1193 = load ptr, ptr %l418, !tbaa !29
  %t1195 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1193, { i64, ptr } %t1192)
  store { i64, ptr } %t1195, ptr %l425
  br label %bb180
bb180:
  %t1196 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1197 = extractvalue { i64, ptr } %t1196, 0
  %t1198 = load { i64, ptr }, ptr %l425, !tbaa !27
  %t1199 = extractvalue { i64, ptr } %t1198, 0
  store i64 %t1199, ptr %l427, !tbaa !24
  %t1201 = load i64, ptr %l427, !tbaa !24
  %t1202 = icmp eq i64 %t1197, %t1201
  br i1 %t1202, label %bb181, label %bb182
bb181:
  %t1204 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t1205 = load ptr, ptr %t1204, !tbaa !27
  %t1206 = getelementptr { i64, ptr }, ptr %l425, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206, !tbaa !27
  %t1208 = load i64, ptr %l427, !tbaa !24
  %t1209 = mul i64 %t1208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1205, ptr %t1207, i64 %t1209, i1 false)
  br label %bb183
bb182:
  %t1210 = load { i64, ptr }, ptr %l425, !tbaa !27
  store { i64, ptr } %t1210, ptr %l46, !tbaa !27
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s42)
  br label %bb184
bb184:
  %t1211 = load i32, ptr %l21, !tbaa !23
  %t1212 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1215 = icmp eq i32 %t1211, %t1212
  br i1 %t1215, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s44
  %t1217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s44, ptr %t1217, { i64, ptr } { i64 11, ptr @.d150 })
  br label %bb187
bb186:
  br label %bb188
bb187:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb188:
  store { i64, ptr } { i64 0, ptr @.d151 }, ptr %l433, !tbaa !27
  %t1219 = load { i64, ptr }, ptr %l433, !tbaa !27
  store { i64, ptr } %t1219, ptr %l434, !tbaa !27
  %t1220 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t1221 = extractvalue { i64, ptr } %t1220, 0
  store i64 %t1221, ptr %l435, !tbaa !24
  %t1222 = load i64, ptr %l435, !tbaa !24
  %t1223 = mul i64 %t1222, 1
  %t1224 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1223)
  %t1225 = insertvalue { i64, ptr } undef, i64 %t1222, 0
  %t1226 = insertvalue { i64, ptr } %t1225, ptr %t1224, 1
  store { i64, ptr } %t1226, ptr %l436, !tbaa !27
  %t1227 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t1228 = load ptr, ptr %t1227, !tbaa !27
  %t1229 = getelementptr { i64, ptr }, ptr %l434, i32 0, i32 1
  %t1230 = load ptr, ptr %t1229, !tbaa !27
  %t1231 = load i64, ptr %l435, !tbaa !24
  %t1232 = mul i64 %t1231, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1228, ptr %t1230, i64 %t1232, i1 false)
  %t1233 = load { i64, ptr }, ptr %l436, !tbaa !27
  store { i64, ptr } %t1233, ptr %l47, !tbaa !27
  %t1234 = load i1, ptr %l23, !tbaa !21
  br i1 %t1234, label %bb189, label %bb190
bb189:
  %t1236 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1236, ptr %l438, !tbaa !27
  %t1237 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1238 = extractvalue { i64, ptr } %t1237, 0
  %t1239 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1239, 0
  store i64 %t1240, ptr %l440, !tbaa !24
  %t1242 = load i64, ptr %l440, !tbaa !24
  %t1243 = icmp eq i64 %t1238, %t1242
  br i1 %t1243, label %bb191, label %bb192
bb190:
  %t1245 = load i32, ptr %l21, !tbaa !23
  %t1246 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1249 = icmp ne i32 %t1245, %t1246
  br i1 %t1249, label %bb194, label %bb195
bb191:
  %t1251 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1252 = load ptr, ptr %t1251, !tbaa !27
  %t1253 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t1254 = load ptr, ptr %t1253, !tbaa !27
  %t1255 = load i64, ptr %l440, !tbaa !24
  %t1256 = mul i64 %t1255, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1252, ptr %t1254, i64 %t1256, i1 false)
  br label %bb193
bb192:
  %t1257 = load { i64, ptr }, ptr %l438, !tbaa !27
  %t1258 = extractvalue { i64, ptr } %t1257, 0
  store i64 %t1258, ptr %l442, !tbaa !24
  %t1259 = load i64, ptr %l442, !tbaa !24
  %t1260 = mul i64 %t1259, 1
  %t1261 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1260)
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1261, 1
  store { i64, ptr } %t1263, ptr %l443, !tbaa !27
  %t1264 = getelementptr { i64, ptr }, ptr %l443, i32 0, i32 1
  %t1265 = load ptr, ptr %t1264, !tbaa !27
  %t1266 = getelementptr { i64, ptr }, ptr %l438, i32 0, i32 1
  %t1267 = load ptr, ptr %t1266, !tbaa !27
  %t1268 = load i64, ptr %l442, !tbaa !24
  %t1269 = mul i64 %t1268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1265, ptr %t1267, i64 %t1269, i1 false)
  %t1270 = load { i64, ptr }, ptr %l443, !tbaa !27
  store { i64, ptr } %t1270, ptr %l47, !tbaa !27
  br label %bb193
bb193:
  br label %bb204
bb194:
  %t1271 = load i1, ptr %l22, !tbaa !21
  br i1 %t1271, label %bb196, label %bb197
bb195:
  br label %bb203
bb196:
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1274 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1275 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1276 = extractvalue { i64, ptr } { i64 13, ptr @.d152 }, 1
  %t1277 = extractvalue { i64, ptr } { i64 13, ptr @.d152 }, 0
  %t1279 = extractvalue { i64, ptr } %t1274, 1
  %t1280 = extractvalue { i64, ptr } %t1274, 0
  %t1281 = add i64 %t1277, %t1280
  %t1282 = extractvalue { i64, ptr } { i64 1, ptr @.d153 }, 1
  %t1283 = extractvalue { i64, ptr } { i64 1, ptr @.d153 }, 0
  %t1284 = add i64 %t1281, %t1283
  %t1286 = extractvalue { i64, ptr } %t1275, 1
  %t1287 = extractvalue { i64, ptr } %t1275, 0
  %t1288 = add i64 %t1284, %t1287
  %t1289 = extractvalue { i64, ptr } { i64 3, ptr @.d154 }, 1
  %t1290 = extractvalue { i64, ptr } { i64 3, ptr @.d154 }, 0
  %t1291 = add i64 %t1288, %t1290
  %t1292 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1291)
  call void @olang_textcopy(ptr %t1292, ptr %t1276, i64 %t1277)
  %t1293 = getelementptr i8, ptr %t1292, i64 %t1277
  call void @olang_textcopy(ptr %t1293, ptr %t1279, i64 %t1280)
  %t1294 = getelementptr i8, ptr %t1293, i64 %t1280
  call void @olang_textcopy(ptr %t1294, ptr %t1282, i64 %t1283)
  %t1295 = getelementptr i8, ptr %t1294, i64 %t1283
  call void @olang_textcopy(ptr %t1295, ptr %t1286, i64 %t1287)
  %t1296 = getelementptr i8, ptr %t1295, i64 %t1287
  call void @olang_textcopy(ptr %t1296, ptr %t1289, i64 %t1290)
  %t1297 = insertvalue { i64, ptr } undef, i64 %t1291, 0
  %t1298 = insertvalue { i64, ptr } %t1297, ptr %t1292, 1
  %t1300 = extractvalue { i64, ptr } %t1298, 0
  %t1301 = extractvalue { i64, ptr } %t1298, 1
  %t1302 = mul i64 %t1300, 1
  %t1303 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1303, ptr %t1301, i64 %t1302, i1 false)
  %t1304 = insertvalue { i64, ptr } undef, i64 %t1300, 0
  %t1305 = insertvalue { i64, ptr } %t1304, ptr %t1303, 1
  %t1308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1273, { i64, ptr } %t1305)
  store { i64, ptr } %t1308, ptr %l454
  br label %bb198
bb197:
  %t1309 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1309, ptr %l448, !tbaa !27
  br label %bb199
bb198:
  %t1311 = load { i64, ptr }, ptr %l454, !tbaa !27
  store { i64, ptr } %t1311, ptr %l448, !tbaa !27
  br label %bb199
bb199:
  %t1312 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1313 = extractvalue { i64, ptr } %t1312, 0
  %t1314 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t1315 = extractvalue { i64, ptr } %t1314, 0
  store i64 %t1315, ptr %l457, !tbaa !24
  %t1317 = load i64, ptr %l457, !tbaa !24
  %t1318 = icmp eq i64 %t1313, %t1317
  br i1 %t1318, label %bb200, label %bb201
bb200:
  %t1320 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1321 = load ptr, ptr %t1320, !tbaa !27
  %t1322 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t1323 = load ptr, ptr %t1322, !tbaa !27
  %t1324 = load i64, ptr %l457, !tbaa !24
  %t1325 = mul i64 %t1324, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1321, ptr %t1323, i64 %t1325, i1 false)
  br label %bb202
bb201:
  %t1326 = load { i64, ptr }, ptr %l448, !tbaa !27
  store { i64, ptr } %t1326, ptr %l47, !tbaa !27
  br label %bb202
bb202:
  br label %bb203
bb203:
  br label %bb204
bb204:
  %t1327 = load i1, ptr %l22, !tbaa !21
  br i1 %t1327, label %bb205, label %bb206
bb205:
  store %olang.scope zeroinitializer, ptr %s49
  %t1329 = load i1, ptr %l23, !tbaa !21
  br i1 %t1329, label %bb207, label %bb208
bb206:
  br label %bb224
bb207:
  store i1 true, ptr %l461, !tbaa !21
  br label %bb209
bb208:
  %t1331 = load i32, ptr %l21, !tbaa !23
  %t1332 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1335 = icmp eq i32 %t1331, %t1332
  store i1 %t1335, ptr %l461, !tbaa !21
  br label %bb209
bb209:
  %t1337 = load i1, ptr %l461, !tbaa !21
  br i1 %t1337, label %bb210, label %bb211
bb210:
  %t1338 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1338, ptr %l465, !tbaa !27
  br label %bb213
bb211:
  %t1340 = load ptr, ptr %l0, !tbaa !29
  %t1341 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1342 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1343 = extractvalue { i64, ptr } { i64 13, ptr @.d155 }, 1
  %t1344 = extractvalue { i64, ptr } { i64 13, ptr @.d155 }, 0
  %t1346 = extractvalue { i64, ptr } %t1341, 1
  %t1347 = extractvalue { i64, ptr } %t1341, 0
  %t1348 = add i64 %t1344, %t1347
  %t1349 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 1
  %t1350 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 0
  %t1351 = add i64 %t1348, %t1350
  %t1353 = extractvalue { i64, ptr } %t1342, 1
  %t1354 = extractvalue { i64, ptr } %t1342, 0
  %t1355 = add i64 %t1351, %t1354
  %t1356 = extractvalue { i64, ptr } { i64 3, ptr @.d157 }, 1
  %t1357 = extractvalue { i64, ptr } { i64 3, ptr @.d157 }, 0
  %t1358 = add i64 %t1355, %t1357
  %t1359 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1358)
  call void @olang_textcopy(ptr %t1359, ptr %t1343, i64 %t1344)
  %t1360 = getelementptr i8, ptr %t1359, i64 %t1344
  call void @olang_textcopy(ptr %t1360, ptr %t1346, i64 %t1347)
  %t1361 = getelementptr i8, ptr %t1360, i64 %t1347
  call void @olang_textcopy(ptr %t1361, ptr %t1349, i64 %t1350)
  %t1362 = getelementptr i8, ptr %t1361, i64 %t1350
  call void @olang_textcopy(ptr %t1362, ptr %t1353, i64 %t1354)
  %t1363 = getelementptr i8, ptr %t1362, i64 %t1354
  call void @olang_textcopy(ptr %t1363, ptr %t1356, i64 %t1357)
  %t1364 = insertvalue { i64, ptr } undef, i64 %t1358, 0
  %t1365 = insertvalue { i64, ptr } %t1364, ptr %t1359, 1
  %t1367 = extractvalue { i64, ptr } %t1365, 0
  %t1368 = extractvalue { i64, ptr } %t1365, 1
  %t1369 = mul i64 %t1367, 1
  %t1370 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1370, ptr %t1368, i64 %t1369, i1 false)
  %t1371 = insertvalue { i64, ptr } undef, i64 %t1367, 0
  %t1372 = insertvalue { i64, ptr } %t1371, ptr %t1370, 1
  %t1375 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1340, { i64, ptr } %t1372)
  store { i64, ptr } %t1375, ptr %l472
  br label %bb212
bb212:
  %t1376 = load { i64, ptr }, ptr %l472, !tbaa !27
  store { i64, ptr } %t1376, ptr %l465, !tbaa !27
  br label %bb213
bb213:
  %t1377 = load { i64, ptr }, ptr %l465, !tbaa !27
  store { i64, ptr } %t1377, ptr %l48, !tbaa !27
  %t1378 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t1379 = load i32, ptr %t1378, !tbaa !23
  %t1380 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t1383 = icmp ne i32 %t1379, %t1380
  br i1 %t1383, label %bb214, label %bb215
bb214:
  store %olang.scope zeroinitializer, ptr %s51
  %t1385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1385, ptr %l476, !tbaa !29
  %t1386 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t1386, ptr %l477, !tbaa !27
  %t1387 = load ptr, ptr %l0, !tbaa !29
  %t1388 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t1389 = load i32, ptr %t1388, !tbaa !23
  %t1392 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s51, ptr %t1387, i32 %t1389)
  store { i64, ptr } %t1392, ptr %l480
  br label %bb216
bb215:
  br label %bb218
bb216:
  %t1393 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t1394 = extractvalue { i64, ptr } %t1393, 0
  %t1395 = extractvalue { i64, ptr } %t1393, 1
  %t1396 = mul i64 %t1394, 1
  %t1397 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1397, ptr %t1395, i64 %t1396, i1 false)
  %t1398 = insertvalue { i64, ptr } undef, i64 %t1394, 0
  %t1399 = insertvalue { i64, ptr } %t1398, ptr %t1397, 1
  %t1400 = load ptr, ptr %l476, !tbaa !29
  %t1401 = load { i64, ptr }, ptr %l477, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s51, ptr %s49, ptr %s51, ptr %s51, ptr %t1400, { i64, ptr } { i64 3, ptr @.d158 }, { i64, ptr } %t1401, { i64, ptr } %t1399, { i64, ptr } { i64 0, ptr @.d159 })
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s51)
  br label %bb218
bb218:
  %t1403 = load ptr, ptr %l0, !tbaa !29
  %t1404 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1405 = extractvalue { i64, ptr } { i64 12, ptr @.d160 }, 1
  %t1406 = extractvalue { i64, ptr } { i64 12, ptr @.d160 }, 0
  %t1408 = extractvalue { i64, ptr } %t1404, 1
  %t1409 = extractvalue { i64, ptr } %t1404, 0
  %t1410 = add i64 %t1406, %t1409
  %t1411 = extractvalue { i64, ptr } { i64 3, ptr @.d161 }, 1
  %t1412 = extractvalue { i64, ptr } { i64 3, ptr @.d161 }, 0
  %t1413 = add i64 %t1410, %t1412
  %t1414 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1413)
  call void @olang_textcopy(ptr %t1414, ptr %t1405, i64 %t1406)
  %t1415 = getelementptr i8, ptr %t1414, i64 %t1406
  call void @olang_textcopy(ptr %t1415, ptr %t1408, i64 %t1409)
  %t1416 = getelementptr i8, ptr %t1415, i64 %t1409
  call void @olang_textcopy(ptr %t1416, ptr %t1411, i64 %t1412)
  %t1417 = insertvalue { i64, ptr } undef, i64 %t1413, 0
  %t1418 = insertvalue { i64, ptr } %t1417, ptr %t1414, 1
  %t1420 = extractvalue { i64, ptr } %t1418, 0
  %t1421 = extractvalue { i64, ptr } %t1418, 1
  %t1422 = mul i64 %t1420, 1
  %t1423 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1422)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1423, ptr %t1421, i64 %t1422, i1 false)
  %t1424 = insertvalue { i64, ptr } undef, i64 %t1420, 0
  %t1425 = insertvalue { i64, ptr } %t1424, ptr %t1423, 1
  %t1428 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s49, ptr %s49, ptr %t1403, { i64, ptr } %t1425)
  store { i64, ptr } %t1428, ptr %l486
  br label %bb219
bb219:
  %t1429 = load { i64, ptr }, ptr %l486, !tbaa !27
  store { i64, ptr } %t1429, ptr %l49, !tbaa !27
  %t1430 = load ptr, ptr %l0, !tbaa !29
  %t1432 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s49, ptr %s49, ptr %t1430, { i64, ptr } { i64 2, ptr @.d162 })
  store { i64, ptr } %t1432, ptr %l488
  br label %bb220
bb220:
  %t1433 = load { i64, ptr }, ptr %l488, !tbaa !27
  store { i64, ptr } %t1433, ptr %l50, !tbaa !27
  %t1434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1434, ptr %l489, !tbaa !29
  %t1435 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t1435, ptr %l490, !tbaa !27
  %t1436 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t1437 = load i32, ptr %t1436, !tbaa !23
  %t1439 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s49, i32 %t1437)
  store { i64, ptr } %t1439, ptr %l492
  br label %bb221
bb221:
  %t1440 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1441 = extractvalue { i64, ptr } { i64 6, ptr @.d163 }, 1
  %t1442 = extractvalue { i64, ptr } { i64 6, ptr @.d163 }, 0
  %t1443 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t1444 = extractvalue { i64, ptr } %t1443, 1
  %t1445 = extractvalue { i64, ptr } %t1443, 0
  %t1446 = add i64 %t1442, %t1445
  %t1447 = extractvalue { i64, ptr } { i64 9, ptr @.d164 }, 1
  %t1448 = extractvalue { i64, ptr } { i64 9, ptr @.d164 }, 0
  %t1449 = add i64 %t1446, %t1448
  %t1450 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t1451 = extractvalue { i64, ptr } %t1450, 1
  %t1452 = extractvalue { i64, ptr } %t1450, 0
  %t1453 = add i64 %t1449, %t1452
  %t1454 = extractvalue { i64, ptr } { i64 9, ptr @.d165 }, 1
  %t1455 = extractvalue { i64, ptr } { i64 9, ptr @.d165 }, 0
  %t1456 = add i64 %t1453, %t1455
  %t1458 = extractvalue { i64, ptr } %t1440, 1
  %t1459 = extractvalue { i64, ptr } %t1440, 0
  %t1460 = add i64 %t1456, %t1459
  %t1461 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1460)
  call void @olang_textcopy(ptr %t1461, ptr %t1441, i64 %t1442)
  %t1462 = getelementptr i8, ptr %t1461, i64 %t1442
  call void @olang_textcopy(ptr %t1462, ptr %t1444, i64 %t1445)
  %t1463 = getelementptr i8, ptr %t1462, i64 %t1445
  call void @olang_textcopy(ptr %t1463, ptr %t1447, i64 %t1448)
  %t1464 = getelementptr i8, ptr %t1463, i64 %t1448
  call void @olang_textcopy(ptr %t1464, ptr %t1451, i64 %t1452)
  %t1465 = getelementptr i8, ptr %t1464, i64 %t1452
  call void @olang_textcopy(ptr %t1465, ptr %t1454, i64 %t1455)
  %t1466 = getelementptr i8, ptr %t1465, i64 %t1455
  call void @olang_textcopy(ptr %t1466, ptr %t1458, i64 %t1459)
  %t1467 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1468 = insertvalue { i64, ptr } %t1467, ptr %t1461, 1
  %t1470 = extractvalue { i64, ptr } %t1468, 0
  %t1471 = extractvalue { i64, ptr } %t1468, 1
  %t1472 = mul i64 %t1470, 1
  %t1473 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1472)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1473, ptr %t1471, i64 %t1472, i1 false)
  %t1474 = insertvalue { i64, ptr } undef, i64 %t1470, 0
  %t1475 = insertvalue { i64, ptr } %t1474, ptr %t1473, 1
  %t1476 = load ptr, ptr %l489, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s49, ptr %t1476, { i64, ptr } %t1475)
  br label %bb222
bb222:
  %t1478 = load ptr, ptr %l0, !tbaa !29
  %t1479 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s49, ptr %t1478, { i64, ptr } %t1479)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s49)
  br label %bb224
bb224:
  %t1482 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t1483 = load i1, ptr %t1482, !tbaa !21
  br i1 %t1483, label %bb225, label %bb226
bb225:
  %t1485 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1487 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1485, { i64, ptr } { i64 0, ptr @.d166 })
  store i1 %t1487, ptr %l501
  br label %bb227
bb226:
  store i1 false, ptr %l499, !tbaa !21
  br label %bb228
bb227:
  %t1488 = load i1, ptr %l501, !tbaa !21
  %t1489 = xor i1 %t1488, true
  store i1 %t1489, ptr %l499, !tbaa !21
  br label %bb228
bb228:
  %t1491 = load i1, ptr %l499, !tbaa !21
  br i1 %t1491, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s54
  %t1492 = load ptr, ptr %l0, !tbaa !29
  %t1493 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t1494 = load %"compiler/mir:Place", ptr %t1493
  %t1497 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s54, ptr %t1492, %"compiler/mir:Place" %t1494)
  store { { i64, ptr }, i32 } %t1497, ptr %l505
  br label %bb231
bb230:
  br label %bb239
bb231:
  %t1498 = load { { i64, ptr }, i32 }, ptr %l505
  store { { i64, ptr }, i32 } %t1498, ptr %l51
  %t1499 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t1500 = load { i64, ptr }, ptr %t1499, !tbaa !27
  store { i64, ptr } %t1500, ptr %l506, !tbaa !27
  %t1501 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t1502 = extractvalue { i64, ptr } %t1501, 0
  store i64 %t1502, ptr %l507, !tbaa !24
  %t1503 = load i64, ptr %l507, !tbaa !24
  %t1504 = mul i64 %t1503, 1
  %t1505 = call ptr @__olang_scope_alloc_zeroed(ptr %s54, i64 %t1504)
  %t1506 = insertvalue { i64, ptr } undef, i64 %t1503, 0
  %t1507 = insertvalue { i64, ptr } %t1506, ptr %t1505, 1
  store { i64, ptr } %t1507, ptr %l508, !tbaa !27
  %t1508 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1509 = load ptr, ptr %t1508, !tbaa !27
  %t1510 = getelementptr { i64, ptr }, ptr %l506, i32 0, i32 1
  %t1511 = load ptr, ptr %t1510, !tbaa !27
  %t1512 = load i64, ptr %l507, !tbaa !24
  %t1513 = mul i64 %t1512, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1509, ptr %t1511, i64 %t1513, i1 false)
  %t1514 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1514, ptr %l52, !tbaa !27
  %t1515 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 1
  %t1516 = load i32, ptr %t1515, !tbaa !23
  store i32 %t1516, ptr %l53, !tbaa !23
  %t1518 = load i1, ptr %l23, !tbaa !21
  br i1 %t1518, label %bb232, label %bb233
bb232:
  %t1520 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1520, ptr %l511, !tbaa !29
  %t1521 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1521, ptr %l512, !tbaa !27
  %t1522 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1522, ptr %l513, !tbaa !27
  %t1523 = load ptr, ptr %l0, !tbaa !29
  %t1524 = load i32, ptr %l21, !tbaa !23
  %t1527 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1523, i32 %t1524)
  store i64 %t1527, ptr %l516
  br label %bb234
bb233:
  store %olang.scope zeroinitializer, ptr %s56
  %t1528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1528, ptr %l517, !tbaa !29
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1530 = load i32, ptr %l53, !tbaa !23
  %t1533 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s56, ptr %t1529, i32 %t1530)
  store { i64, ptr } %t1533, ptr %l520
  br label %bb236
bb234:
  %t1534 = load ptr, ptr %l511, !tbaa !29
  %t1535 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t1536 = load { i64, ptr }, ptr %l513, !tbaa !27
  %t1537 = load i64, ptr %l516, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s54, ptr %s0, ptr %t1534, { i64, ptr } %t1535, { i64, ptr } %t1536, i64 %t1537)
  br label %bb235
bb235:
  br label %bb238
bb236:
  %t1538 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1539 = extractvalue { i64, ptr } %t1538, 0
  %t1540 = extractvalue { i64, ptr } %t1538, 1
  %t1541 = mul i64 %t1539, 1
  %t1542 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1541)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1542, ptr %t1540, i64 %t1541, i1 false)
  %t1543 = insertvalue { i64, ptr } undef, i64 %t1539, 0
  %t1544 = insertvalue { i64, ptr } %t1543, ptr %t1542, 1
  %t1545 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1546 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1547 = load ptr, ptr %l517, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s56, ptr %s0, ptr %s54, ptr %s56, ptr %t1547, { i64, ptr } %t1544, { i64, ptr } %t1545, { i64, ptr } %t1546, { i64, ptr } { i64 0, ptr @.d167 })
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s56)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s54)
  br label %bb239
bb239:
  %t1551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1551, ptr %l524, !tbaa !29
  %t1552 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t1553 = load i32, ptr %t1552, !tbaa !23
  %t1555 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %t1553)
  store { i64, ptr } %t1555, ptr %l526
  br label %bb240
bb240:
  %t1556 = extractvalue { i64, ptr } { i64 10, ptr @.d168 }, 1
  %t1557 = extractvalue { i64, ptr } { i64 10, ptr @.d168 }, 0
  %t1558 = load { i64, ptr }, ptr %l526, !tbaa !27
  %t1559 = extractvalue { i64, ptr } %t1558, 1
  %t1560 = extractvalue { i64, ptr } %t1558, 0
  %t1561 = add i64 %t1557, %t1560
  %t1562 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1561)
  call void @olang_textcopy(ptr %t1562, ptr %t1556, i64 %t1557)
  %t1563 = getelementptr i8, ptr %t1562, i64 %t1557
  call void @olang_textcopy(ptr %t1563, ptr %t1559, i64 %t1560)
  %t1564 = insertvalue { i64, ptr } undef, i64 %t1561, 0
  %t1565 = insertvalue { i64, ptr } %t1564, ptr %t1562, 1
  %t1567 = extractvalue { i64, ptr } %t1565, 0
  %t1568 = extractvalue { i64, ptr } %t1565, 1
  %t1569 = mul i64 %t1567, 1
  %t1570 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1569)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1570, ptr %t1568, i64 %t1569, i1 false)
  %t1571 = insertvalue { i64, ptr } undef, i64 %t1567, 0
  %t1572 = insertvalue { i64, ptr } %t1571, ptr %t1570, 1
  %t1573 = load ptr, ptr %l524, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1573, { i64, ptr } %t1572)
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3, i32 %a4, i64 %a5, i64 %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:TaskClause"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"compiler/typed:Item"
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l54 = alloca i32
  %l60 = alloca i32
  %l63 = alloca i32
  %l89 = alloca %"compiler/mir:TaskClause"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l107 = alloca i32
  %l110 = alloca i32
  %l136 = alloca %"compiler/typed:Item"
  %l140 = alloca i64
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l188 = alloca i32
  %l203 = alloca %"std/prelude/text:StringBuilder"
  %l210 = alloca i32
  %l214 = alloca i1
  %l218 = alloca i1
  %l221 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i32
  %l227 = alloca { i64, ptr }
  %l238 = alloca i64
  %l242 = alloca i64
  %l245 = alloca i64
  %l278 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca { i64, ptr }
  %l284 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i32
  %l288 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca i32
  %l293 = alloca { i64, ptr }
  %l294 = alloca i32
  %l296 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l302 = alloca i64
  %l305 = alloca ptr
  %l306 = alloca i32
  %l309 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l316 = alloca i64
  %l319 = alloca i1
  %l321 = alloca i1
  %l326 = alloca ptr
  %l327 = alloca i32
  %l328 = alloca i64
  %l331 = alloca { i64, ptr }
  %l336 = alloca ptr
  %l337 = alloca ptr
  %l340 = alloca i32
  %l341 = alloca i32
  %l342 = alloca { i64, ptr }
  %l347 = alloca i32
  %l350 = alloca i32
  %l377 = alloca ptr
  %l378 = alloca i32
  %l379 = alloca i32
  %l382 = alloca { i64, ptr }
  %l387 = alloca ptr
  %l389 = alloca { i64, ptr }
  %l392 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %t725 = alloca { i64, [4 x i64] }, align 8
  %t728 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/mir:Task" %a3, ptr %l3
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t11, i32 %a4)
  store i32 %t15, ptr %l54
  br label %bb1
bb1:
  %t16 = load i32, ptr %l54, !tbaa !23
  store i32 %t16, ptr %l10, !tbaa !23
  store i64 %a5, ptr %l11, !tbaa !24
  store i32 0, ptr %l12, !tbaa !23
  %t19 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t20 = getelementptr %"compiler/mir:Range", ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t23 = load i32, ptr %l13, !tbaa !23
  %t24 = load i32, ptr %l12, !tbaa !23
  %t27 = icmp sgt i32 %t23, %t24
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t31 = icmp sgt i32 %t29, 0
  br i1 %t31, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l60, !tbaa !23
  br label %bb7
bb4:
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = load i32, ptr %l12, !tbaa !23
  %t37 = sub i32 %t33, %t34
  %t38 = load i32, ptr %l14, !tbaa !23
  %t41 = add i32 %t37, %t38
  %t43 = sub i32 %t41, 1
  %t44 = load i32, ptr %l14, !tbaa !23
  %t47 = sdiv i32 %t43, %t44
  store i32 %t47, ptr %l63, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l63, !tbaa !23
  br label %bb6
bb6:
  %t49 = load i32, ptr %l63, !tbaa !23
  store i32 %t49, ptr %l60, !tbaa !23
  br label %bb7
bb7:
  %t50 = load i32, ptr %l60, !tbaa !23
  store i32 %t50, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i32, ptr %l16, !tbaa !23
  %t52 = load i32, ptr %l15, !tbaa !23
  %t55 = icmp slt i32 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb10:
  br label %bb11
bb11:
  %t59 = load i32, ptr %l12, !tbaa !23
  %t60 = load i32, ptr %l16, !tbaa !23
  %t61 = load i32, ptr %l14, !tbaa !23
  %t64 = mul i32 %t60, %t61
  %t67 = add i32 %t59, %t64
  store i32 %t67, ptr %l17, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 17
  %t75 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i32, ptr %l17, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = add i64 %t79, %t82
  %t88 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t74, i64 %t85)
  store %"compiler/mir:TaskClause" %t88, ptr %l89
  br label %bb12
bb12:
  %t89 = load %"compiler/mir:TaskClause", ptr %l89
  store %"compiler/mir:TaskClause" %t89, ptr %l18
  store { i64, ptr } { i64 4, ptr @.d169 }, ptr %l90, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t90, ptr %l91, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l92, !tbaa !24
  %t93 = load i64, ptr %l92, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l93, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l92, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t104, ptr %l19, !tbaa !27
  %t105 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 1
  %t106 = load i1, ptr %t105, !tbaa !21
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 5, ptr @.d170 }, ptr %l96, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t110, ptr %l97, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l99, !tbaa !24
  %t116 = load i64, ptr %l99, !tbaa !24
  %t117 = icmp eq i64 %t112, %t116
  br i1 %t117, label %bb15, label %bb16
bb14:
  br label %bb41
bb15:
  %t119 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l99, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  br label %bb17
bb16:
  %t125 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l101, !tbaa !24
  %t127 = load i64, ptr %l101, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l102, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l101, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t138, ptr %l19, !tbaa !27
  br label %bb17
bb17:
  store i32 0, ptr %l20, !tbaa !23
  %t139 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t140 = getelementptr %"compiler/mir:Range", ptr %t139, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l21, !tbaa !23
  store i32 1, ptr %l22, !tbaa !23
  %t143 = load i32, ptr %l21, !tbaa !23
  %t144 = load i32, ptr %l20, !tbaa !23
  %t147 = icmp sgt i32 %t143, %t144
  br i1 %t147, label %bb18, label %bb19
bb18:
  %t149 = load i32, ptr %l22, !tbaa !23
  %t151 = icmp sgt i32 %t149, 0
  br i1 %t151, label %bb20, label %bb21
bb19:
  store i32 0, ptr %l107, !tbaa !23
  br label %bb23
bb20:
  %t153 = load i32, ptr %l21, !tbaa !23
  %t154 = load i32, ptr %l20, !tbaa !23
  %t157 = sub i32 %t153, %t154
  %t158 = load i32, ptr %l22, !tbaa !23
  %t161 = add i32 %t157, %t158
  %t163 = sub i32 %t161, 1
  %t164 = load i32, ptr %l22, !tbaa !23
  %t167 = sdiv i32 %t163, %t164
  store i32 %t167, ptr %l110, !tbaa !23
  br label %bb22
bb21:
  store i32 0, ptr %l110, !tbaa !23
  br label %bb22
bb22:
  %t169 = load i32, ptr %l110, !tbaa !23
  store i32 %t169, ptr %l107, !tbaa !23
  br label %bb23
bb23:
  %t170 = load i32, ptr %l107, !tbaa !23
  store i32 %t170, ptr %l23, !tbaa !23
  store i32 0, ptr %l24, !tbaa !23
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load i32, ptr %l24, !tbaa !23
  %t172 = load i32, ptr %l23, !tbaa !23
  %t175 = icmp slt i32 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t179 = load i32, ptr %l20, !tbaa !23
  %t180 = load i32, ptr %l24, !tbaa !23
  %t181 = load i32, ptr %l22, !tbaa !23
  %t184 = mul i32 %t180, %t181
  %t187 = add i32 %t179, %t184
  store i32 %t187, ptr %l25, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/mir:Fn", ptr %t192, i32 0, i32 18
  %t195 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t196 = getelementptr %"compiler/mir:Range", ptr %t195, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t200 = load i32, ptr %l25, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t205 = add i64 %t199, %t202
  %t208 = call %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t194, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l136
  br label %bb28
bb28:
  %t209 = load %"compiler/typed:Item", ptr %l136
  store %"compiler/typed:Item" %t209, ptr %l26
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t211 = load i32, ptr %l10, !tbaa !23
  %t212 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 0
  %t213 = load i32, ptr %t212, !tbaa !23
  %t217 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t210, i32 %t211, i32 %t213)
  store i64 %t217, ptr %l140
  br label %bb29
bb29:
  %t218 = load i64, ptr %l140, !tbaa !24
  store i64 %t218, ptr %l27, !tbaa !24
  %t219 = load i32, ptr %l17, !tbaa !23
  %t220 = load i32, ptr %l25, !tbaa !23
  %t221 = extractvalue { i64, ptr } { i64 2, ptr @.d171 }, 1
  %t222 = extractvalue { i64, ptr } { i64 2, ptr @.d171 }, 0
  %t224 = sext i32 %t219 to i64
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d172 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d172 }, 0
  %t229 = add i64 %t226, %t228
  %t231 = sext i32 %t220 to i64
  %t232 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t233 = add i64 %t229, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t221, i64 %t222)
  %t235 = getelementptr i8, ptr %t234, i64 %t222
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t224)
  %t237 = getelementptr i8, ptr %t235, i64 %t225
  call void @olang_textcopy(ptr %t237, ptr %t227, i64 %t228)
  %t238 = getelementptr i8, ptr %t237, i64 %t228
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t231)
  %t240 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t234, 1
  store { i64, ptr } %t241, ptr %l28, !tbaa !27
  %t243 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = icmp slt i64 %t244, 0
  br i1 %t246, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t253 = load i64, ptr %l27, !tbaa !24
  %t254 = extractvalue { i64, ptr } { i64 2, ptr @.d173 }, 1
  %t255 = extractvalue { i64, ptr } { i64 2, ptr @.d173 }, 0
  %t257 = extractvalue { i64, ptr } %t249, 1
  %t258 = extractvalue { i64, ptr } %t249, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 13, ptr @.d174 }, 1
  %t261 = extractvalue { i64, ptr } { i64 13, ptr @.d174 }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t250, 1
  %t265 = extractvalue { i64, ptr } %t250, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 7, ptr @.d175 }, 1
  %t268 = extractvalue { i64, ptr } { i64 7, ptr @.d175 }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t251, 1
  %t272 = extractvalue { i64, ptr } %t251, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 15, ptr @.d176 }, 1
  %t275 = extractvalue { i64, ptr } { i64 15, ptr @.d176 }, 0
  %t276 = add i64 %t273, %t275
  %t278 = extractvalue { i64, ptr } %t252, 1
  %t279 = extractvalue { i64, ptr } %t252, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 3, ptr @.d177 }, 1
  %t282 = extractvalue { i64, ptr } { i64 3, ptr @.d177 }, 0
  %t283 = add i64 %t280, %t282
  %t285 = call i64 @__olang_fmt_i64(ptr null, i64 %t253)
  %t286 = add i64 %t283, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr @.d178 }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr @.d178 }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t254, i64 %t255)
  %t291 = getelementptr i8, ptr %t290, i64 %t255
  call void @olang_textcopy(ptr %t291, ptr %t257, i64 %t258)
  %t292 = getelementptr i8, ptr %t291, i64 %t258
  call void @olang_textcopy(ptr %t292, ptr %t260, i64 %t261)
  %t293 = getelementptr i8, ptr %t292, i64 %t261
  call void @olang_textcopy(ptr %t293, ptr %t264, i64 %t265)
  %t294 = getelementptr i8, ptr %t293, i64 %t265
  call void @olang_textcopy(ptr %t294, ptr %t267, i64 %t268)
  %t295 = getelementptr i8, ptr %t294, i64 %t268
  call void @olang_textcopy(ptr %t295, ptr %t271, i64 %t272)
  %t296 = getelementptr i8, ptr %t295, i64 %t272
  call void @olang_textcopy(ptr %t296, ptr %t274, i64 %t275)
  %t297 = getelementptr i8, ptr %t296, i64 %t275
  call void @olang_textcopy(ptr %t297, ptr %t278, i64 %t279)
  %t298 = getelementptr i8, ptr %t297, i64 %t279
  call void @olang_textcopy(ptr %t298, ptr %t281, i64 %t282)
  %t299 = getelementptr i8, ptr %t298, i64 %t282
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t253)
  %t301 = getelementptr i8, ptr %t299, i64 %t285
  call void @olang_textcopy(ptr %t301, ptr %t287, i64 %t288)
  %t302 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t290, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } %t303, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t248, { i64, ptr } %t310)
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t316 = load i64, ptr %l27, !tbaa !24
  %t318 = shl i64 %t316, 16
  %t319 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = or i64 %t318, %t320
  %t324 = extractvalue { i64, ptr } { i64 2, ptr @.d179 }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr @.d179 }, 0
  %t327 = extractvalue { i64, ptr } %t314, 1
  %t328 = extractvalue { i64, ptr } %t314, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 15, ptr @.d180 }, 1
  %t331 = extractvalue { i64, ptr } { i64 15, ptr @.d180 }, 0
  %t332 = add i64 %t329, %t331
  %t334 = extractvalue { i64, ptr } %t315, 1
  %t335 = extractvalue { i64, ptr } %t315, 0
  %t336 = add i64 %t332, %t335
  %t337 = extractvalue { i64, ptr } { i64 2, ptr @.d181 }, 1
  %t338 = extractvalue { i64, ptr } { i64 2, ptr @.d181 }, 0
  %t339 = add i64 %t336, %t338
  %t341 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t342 = add i64 %t339, %t341
  %t343 = extractvalue { i64, ptr } { i64 1, ptr @.d182 }, 1
  %t344 = extractvalue { i64, ptr } { i64 1, ptr @.d182 }, 0
  %t345 = add i64 %t342, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t324, i64 %t325)
  %t347 = getelementptr i8, ptr %t346, i64 %t325
  call void @olang_textcopy(ptr %t347, ptr %t327, i64 %t328)
  %t348 = getelementptr i8, ptr %t347, i64 %t328
  call void @olang_textcopy(ptr %t348, ptr %t330, i64 %t331)
  %t349 = getelementptr i8, ptr %t348, i64 %t331
  call void @olang_textcopy(ptr %t349, ptr %t334, i64 %t335)
  %t350 = getelementptr i8, ptr %t349, i64 %t335
  call void @olang_textcopy(ptr %t350, ptr %t337, i64 %t338)
  %t351 = getelementptr i8, ptr %t350, i64 %t338
  %t352 = call i64 @__olang_fmt_i64(ptr %t351, i64 %t323)
  %t353 = getelementptr i8, ptr %t351, i64 %t341
  call void @olang_textcopy(ptr %t353, ptr %t343, i64 %t344)
  %t354 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t346, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t313, { i64, ptr } %t362)
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t369 = extractvalue { i64, ptr } { i64 2, ptr @.d183 }, 1
  %t370 = extractvalue { i64, ptr } { i64 2, ptr @.d183 }, 0
  %t372 = extractvalue { i64, ptr } %t366, 1
  %t373 = extractvalue { i64, ptr } %t366, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 10, ptr @.d184 }, 1
  %t376 = extractvalue { i64, ptr } { i64 10, ptr @.d184 }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t367, 1
  %t380 = extractvalue { i64, ptr } %t367, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 2, ptr @.d185 }, 1
  %t383 = extractvalue { i64, ptr } { i64 2, ptr @.d185 }, 0
  %t384 = add i64 %t381, %t383
  %t386 = extractvalue { i64, ptr } %t368, 1
  %t387 = extractvalue { i64, ptr } %t368, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr @.d186 }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr @.d186 }, 0
  %t391 = add i64 %t388, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t369, i64 %t370)
  %t393 = getelementptr i8, ptr %t392, i64 %t370
  call void @olang_textcopy(ptr %t393, ptr %t372, i64 %t373)
  %t394 = getelementptr i8, ptr %t393, i64 %t373
  call void @olang_textcopy(ptr %t394, ptr %t375, i64 %t376)
  %t395 = getelementptr i8, ptr %t394, i64 %t376
  call void @olang_textcopy(ptr %t395, ptr %t379, i64 %t380)
  %t396 = getelementptr i8, ptr %t395, i64 %t380
  call void @olang_textcopy(ptr %t396, ptr %t382, i64 %t383)
  %t397 = getelementptr i8, ptr %t396, i64 %t383
  call void @olang_textcopy(ptr %t397, ptr %t386, i64 %t387)
  %t398 = getelementptr i8, ptr %t397, i64 %t387
  call void @olang_textcopy(ptr %t398, ptr %t389, i64 %t390)
  %t399 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t392, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t365, { i64, ptr } %t407)
  br label %bb35
bb35:
  %t410 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 1
  %t413 = extractvalue { i64, ptr } %t410, 0
  %t414 = extractvalue { i64, ptr } { i64 1, ptr @.d187 }, 1
  %t415 = extractvalue { i64, ptr } { i64 1, ptr @.d187 }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t412, i64 %t413)
  %t418 = getelementptr i8, ptr %t417, i64 %t413
  call void @olang_textcopy(ptr %t418, ptr %t414, i64 %t415)
  %t419 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t417, 1
  store { i64, ptr } %t420, ptr %l170, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  %t423 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l172, !tbaa !24
  %t426 = load i64, ptr %l172, !tbaa !24
  %t427 = icmp eq i64 %t422, %t426
  br i1 %t427, label %bb36, label %bb37
bb36:
  %t429 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = load i64, ptr %l172, !tbaa !24
  %t434 = mul i64 %t433, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t430, ptr %t432, i64 %t434, i1 false)
  br label %bb38
bb37:
  %t435 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t435, ptr %l19, !tbaa !27
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t436 = load i32, ptr %l24, !tbaa !23
  %t438 = add i32 %t436, 1
  store i32 %t438, ptr %l24, !tbaa !23
  br label %bb24
bb40:
  br label %bb41
bb41:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t442 = load i32, ptr %l17, !tbaa !23
  %t443 = load i32, ptr %l17, !tbaa !23
  %t444 = load i32, ptr %l17, !tbaa !23
  %t445 = extractvalue { i64, ptr } { i64 8, ptr @.d188 }, 1
  %t446 = extractvalue { i64, ptr } { i64 8, ptr @.d188 }, 0
  %t448 = extractvalue { i64, ptr } %t441, 1
  %t449 = extractvalue { i64, ptr } %t441, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 13, ptr @.d189 }, 1
  %t452 = extractvalue { i64, ptr } { i64 13, ptr @.d189 }, 0
  %t453 = add i64 %t450, %t452
  %t455 = sext i32 %t442 to i64
  %t456 = call i64 @__olang_fmt_i64(ptr null, i64 %t455)
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 13, ptr @.d190 }, 1
  %t459 = extractvalue { i64, ptr } { i64 13, ptr @.d190 }, 0
  %t460 = add i64 %t457, %t459
  %t462 = sext i32 %t443 to i64
  %t463 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 5, ptr @.d191 }, 1
  %t466 = extractvalue { i64, ptr } { i64 5, ptr @.d191 }, 0
  %t467 = add i64 %t464, %t466
  %t469 = sext i32 %t444 to i64
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t469)
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 2, ptr @.d192 }, 1
  %t473 = extractvalue { i64, ptr } { i64 2, ptr @.d192 }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t445, i64 %t446)
  %t476 = getelementptr i8, ptr %t475, i64 %t446
  call void @olang_textcopy(ptr %t476, ptr %t448, i64 %t449)
  %t477 = getelementptr i8, ptr %t476, i64 %t449
  call void @olang_textcopy(ptr %t477, ptr %t451, i64 %t452)
  %t478 = getelementptr i8, ptr %t477, i64 %t452
  %t479 = call i64 @__olang_fmt_i64(ptr %t478, i64 %t455)
  %t480 = getelementptr i8, ptr %t478, i64 %t456
  call void @olang_textcopy(ptr %t480, ptr %t458, i64 %t459)
  %t481 = getelementptr i8, ptr %t480, i64 %t459
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t462)
  %t483 = getelementptr i8, ptr %t481, i64 %t463
  call void @olang_textcopy(ptr %t483, ptr %t465, i64 %t466)
  %t484 = getelementptr i8, ptr %t483, i64 %t466
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t469)
  %t486 = getelementptr i8, ptr %t484, i64 %t470
  call void @olang_textcopy(ptr %t486, ptr %t472, i64 %t473)
  %t487 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t475, 1
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t440, { i64, ptr } %t495)
  br label %bb42
bb42:
  %t498 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t499 = load { i64, [4 x i64] }, ptr %t498
  %t501 = extractvalue { i64, [4 x i64] } %t499, 0
  %t502 = icmp eq i64 %t501, 0
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t508 = load { i64, [4 x i64] }, ptr %t507
  %t511 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t506, { i64, [4 x i64] } %t508)
  store i32 %t511, ptr %l188
  br label %bb45
bb44:
  br label %bb134
bb45:
  %t512 = load i32, ptr %l188, !tbaa !23
  store i32 %t512, ptr %l29, !tbaa !23
  %t513 = load ptr, ptr %l8, !tbaa !29
  %t514 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t513, i32 %t514)
  br label %bb46
bb46:
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t518 = load i32, ptr %l17, !tbaa !23
  %t519 = load i64, ptr %l11, !tbaa !24
  %t520 = extractvalue { i64, ptr } { i64 5, ptr @.d193 }, 1
  %t521 = extractvalue { i64, ptr } { i64 5, ptr @.d193 }, 0
  %t523 = sext i32 %t518 to i64
  %t524 = call i64 @__olang_fmt_i64(ptr null, i64 %t523)
  %t525 = add i64 %t521, %t524
  %t526 = extractvalue { i64, ptr } { i64 28, ptr @.d194 }, 1
  %t527 = extractvalue { i64, ptr } { i64 28, ptr @.d194 }, 0
  %t528 = add i64 %t525, %t527
  %t530 = call i64 @__olang_fmt_i64(ptr null, i64 %t519)
  %t531 = add i64 %t528, %t530
  %t532 = extractvalue { i64, ptr } { i64 1, ptr @.d195 }, 1
  %t533 = extractvalue { i64, ptr } { i64 1, ptr @.d195 }, 0
  %t534 = add i64 %t531, %t533
  %t535 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t520, i64 %t521)
  %t536 = getelementptr i8, ptr %t535, i64 %t521
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t523)
  %t538 = getelementptr i8, ptr %t536, i64 %t524
  call void @olang_textcopy(ptr %t538, ptr %t526, i64 %t527)
  %t539 = getelementptr i8, ptr %t538, i64 %t527
  %t540 = call i64 @__olang_fmt_i64(ptr %t539, i64 %t519)
  %t541 = getelementptr i8, ptr %t539, i64 %t530
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t535, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t546 = extractvalue { i64, ptr } %t543, 1
  %t547 = mul i64 %t545, 1
  %t548 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t517, { i64, ptr } %t550)
  br label %bb47
bb47:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t554 = load i32, ptr %l17, !tbaa !23
  %t555 = load i32, ptr %l17, !tbaa !23
  %t556 = load i32, ptr %l17, !tbaa !23
  %t557 = load i32, ptr %l17, !tbaa !23
  %t558 = extractvalue { i64, ptr } { i64 5, ptr @.d196 }, 1
  %t559 = extractvalue { i64, ptr } { i64 5, ptr @.d196 }, 0
  %t561 = sext i32 %t554 to i64
  %t562 = call i64 @__olang_fmt_i64(ptr null, i64 %t561)
  %t563 = add i64 %t559, %t562
  %t564 = extractvalue { i64, ptr } { i64 32, ptr @.d197 }, 1
  %t565 = extractvalue { i64, ptr } { i64 32, ptr @.d197 }, 0
  %t566 = add i64 %t563, %t565
  %t568 = sext i32 %t555 to i64
  %t569 = call i64 @__olang_fmt_i64(ptr null, i64 %t568)
  %t570 = add i64 %t566, %t569
  %t571 = extractvalue { i64, ptr } { i64 9, ptr @.d198 }, 1
  %t572 = extractvalue { i64, ptr } { i64 9, ptr @.d198 }, 0
  %t573 = add i64 %t570, %t572
  %t575 = sext i32 %t556 to i64
  %t576 = call i64 @__olang_fmt_i64(ptr null, i64 %t575)
  %t577 = add i64 %t573, %t576
  %t578 = extractvalue { i64, ptr } { i64 32, ptr @.d199 }, 1
  %t579 = extractvalue { i64, ptr } { i64 32, ptr @.d199 }, 0
  %t580 = add i64 %t577, %t579
  %t582 = sext i32 %t557 to i64
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t584 = add i64 %t580, %t583
  %t585 = extractvalue { i64, ptr } { i64 4, ptr @.d200 }, 1
  %t586 = extractvalue { i64, ptr } { i64 4, ptr @.d200 }, 0
  %t587 = add i64 %t584, %t586
  %t588 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t558, i64 %t559)
  %t589 = getelementptr i8, ptr %t588, i64 %t559
  %t590 = call i64 @__olang_fmt_i64(ptr %t589, i64 %t561)
  %t591 = getelementptr i8, ptr %t589, i64 %t562
  call void @olang_textcopy(ptr %t591, ptr %t564, i64 %t565)
  %t592 = getelementptr i8, ptr %t591, i64 %t565
  %t593 = call i64 @__olang_fmt_i64(ptr %t592, i64 %t568)
  %t594 = getelementptr i8, ptr %t592, i64 %t569
  call void @olang_textcopy(ptr %t594, ptr %t571, i64 %t572)
  %t595 = getelementptr i8, ptr %t594, i64 %t572
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t575)
  %t597 = getelementptr i8, ptr %t595, i64 %t576
  call void @olang_textcopy(ptr %t597, ptr %t578, i64 %t579)
  %t598 = getelementptr i8, ptr %t597, i64 %t579
  %t599 = call i64 @__olang_fmt_i64(ptr %t598, i64 %t582)
  %t600 = getelementptr i8, ptr %t598, i64 %t583
  call void @olang_textcopy(ptr %t600, ptr %t585, i64 %t586)
  %t601 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t588, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = extractvalue { i64, ptr } %t602, 1
  %t606 = mul i64 %t604, 1
  %t607 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t606)
  call void @llvm.memcpy.p0.p0.i64(ptr %t607, ptr %t605, i64 %t606, i1 false)
  %t608 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t553, { i64, ptr } %t609)
  br label %bb48
bb48:
  %t612 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s15)
  store %"std/prelude/text:StringBuilder" %t612, ptr %l203
  br label %bb49
bb49:
  %t613 = load %"std/prelude/text:StringBuilder", ptr %l203
  store %"std/prelude/text:StringBuilder" %t613, ptr %l30
  %t614 = load i32, ptr %l17, !tbaa !23
  %t615 = extractvalue { i64, ptr } { i64 7, ptr @.d201 }, 1
  %t616 = extractvalue { i64, ptr } { i64 7, ptr @.d201 }, 0
  %t618 = sext i32 %t614 to i64
  %t619 = call i64 @__olang_fmt_i64(ptr null, i64 %t618)
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  %t623 = call i64 @__olang_fmt_i64(ptr %t622, i64 %t618)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t621, 1
  %t627 = extractvalue { i64, ptr } %t625, 0
  %t628 = extractvalue { i64, ptr } %t625, 1
  %t629 = mul i64 %t627, 1
  %t630 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t630, ptr %t628, i64 %t629, i1 false)
  %t631 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t630, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s15, ptr %l30, { i64, ptr } %t632)
  br label %bb50
bb50:
  %t635 = load ptr, ptr %l9, !tbaa !29
  %t636 = load i32, ptr %l29, !tbaa !23
  %t639 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t635, i32 %t636)
  store i32 %t639, ptr %l210
  br label %bb51
bb51:
  %t640 = load i32, ptr %l210, !tbaa !23
  store i32 %t640, ptr %l31, !tbaa !23
  %t641 = load i32, ptr %l31, !tbaa !23
  %t642 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t645 = icmp ne i32 %t641, %t642
  br i1 %t645, label %bb52, label %bb53
bb52:
  %t647 = load i32, ptr %l31, !tbaa !23
  %t648 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t651 = icmp ne i32 %t647, %t648
  store i1 %t651, ptr %l214, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb54
bb54:
  %t653 = load i1, ptr %l214, !tbaa !21
  br i1 %t653, label %bb55, label %bb56
bb55:
  %t654 = load ptr, ptr %l9, !tbaa !29
  %t655 = load i32, ptr %l31, !tbaa !23
  %t658 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t654, i32 %t655)
  store i1 %t658, ptr %l221
  br label %bb57
bb56:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb58
bb57:
  %t659 = load i1, ptr %l221, !tbaa !21
  store i1 %t659, ptr %l218, !tbaa !21
  br label %bb58
bb58:
  %t660 = load i1, ptr %l218, !tbaa !21
  store i1 %t660, ptr %l32, !tbaa !21
  %t661 = load i1, ptr %l32, !tbaa !21
  br i1 %t661, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s19
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l223, !tbaa !29
  %t664 = load i32, ptr %l17, !tbaa !23
  store i32 %t664, ptr %l224, !tbaa !23
  %t665 = load ptr, ptr %l8, !tbaa !29
  %t666 = load i32, ptr %l31, !tbaa !23
  %t669 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s19, ptr %t665, i32 %t666)
  store { i64, ptr } %t669, ptr %l227
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t670 = extractvalue { i64, ptr } { i64 5, ptr @.d202 }, 1
  %t671 = extractvalue { i64, ptr } { i64 5, ptr @.d202 }, 0
  %t672 = load i32, ptr %l224, !tbaa !23
  %t673 = sext i32 %t672 to i64
  %t674 = call i64 @__olang_fmt_i64(ptr null, i64 %t673)
  %t675 = add i64 %t671, %t674
  %t676 = extractvalue { i64, ptr } { i64 10, ptr @.d203 }, 1
  %t677 = extractvalue { i64, ptr } { i64 10, ptr @.d203 }, 0
  %t678 = add i64 %t675, %t677
  %t679 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = add i64 %t678, %t681
  %t683 = extractvalue { i64, ptr } { i64 1, ptr @.d204 }, 1
  %t684 = extractvalue { i64, ptr } { i64 1, ptr @.d204 }, 0
  %t685 = add i64 %t682, %t684
  %t686 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t685)
  call void @olang_textcopy(ptr %t686, ptr %t670, i64 %t671)
  %t687 = getelementptr i8, ptr %t686, i64 %t671
  %t688 = call i64 @__olang_fmt_i64(ptr %t687, i64 %t673)
  %t689 = getelementptr i8, ptr %t687, i64 %t674
  call void @olang_textcopy(ptr %t689, ptr %t676, i64 %t677)
  %t690 = getelementptr i8, ptr %t689, i64 %t677
  call void @olang_textcopy(ptr %t690, ptr %t680, i64 %t681)
  %t691 = getelementptr i8, ptr %t690, i64 %t681
  call void @olang_textcopy(ptr %t691, ptr %t683, i64 %t684)
  %t692 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t686, 1
  %t695 = extractvalue { i64, ptr } %t693, 0
  %t696 = extractvalue { i64, ptr } %t693, 1
  %t697 = mul i64 %t695, 1
  %t698 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t697)
  call void @llvm.memcpy.p0.p0.i64(ptr %t698, ptr %t696, i64 %t697, i1 false)
  %t699 = insertvalue { i64, ptr } undef, i64 %t695, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t698, 1
  %t701 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t701, { i64, ptr } %t700)
  br label %bb62
bb62:
  %t703 = load i32, ptr %l17, !tbaa !23
  %t704 = extractvalue { i64, ptr } { i64 9, ptr @.d205 }, 1
  %t705 = extractvalue { i64, ptr } { i64 9, ptr @.d205 }, 0
  %t707 = sext i32 %t703 to i64
  %t708 = call i64 @__olang_fmt_i64(ptr null, i64 %t707)
  %t709 = add i64 %t705, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t704, i64 %t705)
  %t711 = getelementptr i8, ptr %t710, i64 %t705
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t707)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t710, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = extractvalue { i64, ptr } %t714, 1
  %t718 = mul i64 %t716, 1
  %t719 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t719, ptr %t717, i64 %t718, i1 false)
  %t720 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t719, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s19, ptr %l30, { i64, ptr } %t721)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s19)
  br label %bb64
bb64:
  store i64 0, ptr %l33, !tbaa !24
  %t724 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t725
  %t726 = getelementptr { i64, [4 x i64] }, ptr %t725, i32 0, i32 0
  store i64 0, ptr %t726
  %t727 = load { i64, [4 x i64] }, ptr %t725
  store { i64, [7 x i64] } zeroinitializer, ptr %t728
  %t729 = getelementptr { i64, [7 x i64] }, ptr %t728, i32 0, i32 0
  store i64 2, ptr %t729
  %t731 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t727, 0
  %t732 = getelementptr { i64, [7 x i64] }, ptr %t728, i32 0, i32 1
  store { { i64, [4 x i64] } } %t731, ptr %t732
  %t733 = load { i64, [7 x i64] }, ptr %t728
  %t734 = load i32, ptr %l29, !tbaa !23
  %t738 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t724, { i64, [7 x i64] } %t733, i32 %t734)
  store i64 %t738, ptr %l238
  br label %bb65
bb65:
  %t739 = load i64, ptr %l238, !tbaa !24
  store i64 %t739, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t740 = load i64, ptr %l34, !tbaa !24
  %t741 = load i64, ptr %l33, !tbaa !24
  %t744 = icmp sgt i64 %t740, %t741
  br i1 %t744, label %bb66, label %bb67
bb66:
  %t746 = load i64, ptr %l35, !tbaa !24
  %t748 = icmp sgt i64 %t746, 0
  br i1 %t748, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb71
bb68:
  %t750 = load i64, ptr %l34, !tbaa !24
  %t751 = load i64, ptr %l33, !tbaa !24
  %t754 = sub i64 %t750, %t751
  %t755 = load i64, ptr %l35, !tbaa !24
  %t758 = add i64 %t754, %t755
  %t760 = sub i64 %t758, 1
  %t761 = load i64, ptr %l35, !tbaa !24
  %t764 = sdiv i64 %t760, %t761
  store i64 %t764, ptr %l245, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb70
bb70:
  %t766 = load i64, ptr %l245, !tbaa !24
  store i64 %t766, ptr %l242, !tbaa !24
  br label %bb71
bb71:
  %t767 = load i64, ptr %l242, !tbaa !24
  store i64 %t767, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t768 = load i64, ptr %l37, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s23)
  br label %bb80
bb74:
  br label %bb75
bb75:
  %t776 = load i64, ptr %l33, !tbaa !24
  %t777 = load i64, ptr %l37, !tbaa !24
  %t778 = load i64, ptr %l35, !tbaa !24
  %t781 = mul i64 %t777, %t778
  %t784 = add i64 %t776, %t781
  store i64 %t784, ptr %l38, !tbaa !24
  %t786 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s23, ptr %s23, ptr %t786, { i64, ptr } { i64 18, ptr @.d206 }, { i64, ptr } { i64 67, ptr @.d207 })
  br label %bb76
bb76:
  %t788 = load ptr, ptr %l1, !tbaa !29
  %t789 = load i32, ptr %l17, !tbaa !23
  %t790 = load i64, ptr %l38, !tbaa !24
  %t791 = extractvalue { i64, ptr } { i64 5, ptr @.d208 }, 1
  %t792 = extractvalue { i64, ptr } { i64 5, ptr @.d208 }, 0
  %t794 = sext i32 %t789 to i64
  %t795 = call i64 @__olang_fmt_i64(ptr null, i64 %t794)
  %t796 = add i64 %t792, %t795
  %t797 = extractvalue { i64, ptr } { i64 1, ptr @.d209 }, 1
  %t798 = extractvalue { i64, ptr } { i64 1, ptr @.d209 }, 0
  %t799 = add i64 %t796, %t798
  %t801 = call i64 @__olang_fmt_i64(ptr null, i64 %t790)
  %t802 = add i64 %t799, %t801
  %t803 = extractvalue { i64, ptr } { i64 37, ptr @.d210 }, 1
  %t804 = extractvalue { i64, ptr } { i64 37, ptr @.d210 }, 0
  %t805 = add i64 %t802, %t804
  %t806 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t791, i64 %t792)
  %t807 = getelementptr i8, ptr %t806, i64 %t792
  %t808 = call i64 @__olang_fmt_i64(ptr %t807, i64 %t794)
  %t809 = getelementptr i8, ptr %t807, i64 %t795
  call void @olang_textcopy(ptr %t809, ptr %t797, i64 %t798)
  %t810 = getelementptr i8, ptr %t809, i64 %t798
  %t811 = call i64 @__olang_fmt_i64(ptr %t810, i64 %t790)
  %t812 = getelementptr i8, ptr %t810, i64 %t801
  call void @olang_textcopy(ptr %t812, ptr %t803, i64 %t804)
  %t813 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t806, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = extractvalue { i64, ptr } %t814, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t788, { i64, ptr } %t821)
  br label %bb77
bb77:
  %t824 = load i32, ptr %l17, !tbaa !23
  %t825 = load i64, ptr %l38, !tbaa !24
  %t826 = extractvalue { i64, ptr } { i64 9, ptr @.d211 }, 1
  %t827 = extractvalue { i64, ptr } { i64 9, ptr @.d211 }, 0
  %t829 = sext i32 %t824 to i64
  %t830 = call i64 @__olang_fmt_i64(ptr null, i64 %t829)
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 1, ptr @.d212 }, 1
  %t833 = extractvalue { i64, ptr } { i64 1, ptr @.d212 }, 0
  %t834 = add i64 %t831, %t833
  %t836 = call i64 @__olang_fmt_i64(ptr null, i64 %t825)
  %t837 = add i64 %t834, %t836
  %t838 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t837)
  call void @olang_textcopy(ptr %t838, ptr %t826, i64 %t827)
  %t839 = getelementptr i8, ptr %t838, i64 %t827
  %t840 = call i64 @__olang_fmt_i64(ptr %t839, i64 %t829)
  %t841 = getelementptr i8, ptr %t839, i64 %t830
  call void @olang_textcopy(ptr %t841, ptr %t832, i64 %t833)
  %t842 = getelementptr i8, ptr %t841, i64 %t833
  %t843 = call i64 @__olang_fmt_i64(ptr %t842, i64 %t825)
  %t844 = insertvalue { i64, ptr } undef, i64 %t837, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t838, 1
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t848 = extractvalue { i64, ptr } %t845, 1
  %t849 = mul i64 %t847, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t849)
  call void @llvm.memcpy.p0.p0.i64(ptr %t850, ptr %t848, i64 %t849, i1 false)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s23, ptr %l30, { i64, ptr } %t852)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s23)
  br label %bb79
bb79:
  %t855 = load i64, ptr %l37, !tbaa !24
  %t857 = add i64 %t855, 1
  store i64 %t857, ptr %l37, !tbaa !24
  br label %bb72
bb80:
  %t859 = load ptr, ptr %l9, !tbaa !29
  %t860 = load i32, ptr %l29, !tbaa !23
  %t863 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s15, ptr %t859, i32 %t860)
  store { i64, ptr } %t863, ptr %l278
  br label %bb81
bb81:
  %t864 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t864, ptr %l39, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d213 }, ptr %l279, !tbaa !27
  %t865 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t865, ptr %l280, !tbaa !27
  %t866 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l281, !tbaa !24
  %t868 = load i64, ptr %l281, !tbaa !24
  %t869 = mul i64 %t868, 1
  %t870 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t869)
  %t871 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  store { i64, ptr } %t872, ptr %l282, !tbaa !27
  %t873 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = load i64, ptr %l281, !tbaa !24
  %t878 = mul i64 %t877, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t874, ptr %t876, i64 %t878, i1 false)
  %t879 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t879, ptr %l40, !tbaa !27
  %t880 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t882 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t880, { i64, ptr } { i64 4, ptr @.d214 })
  store i1 %t882, ptr %l284
  br label %bb82
bb82:
  %t883 = load i1, ptr %l284, !tbaa !21
  br i1 %t883, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s27
  %t884 = load ptr, ptr %l1, !tbaa !29
  store ptr %t884, ptr %l285, !tbaa !29
  %t885 = load i32, ptr %l17, !tbaa !23
  store i32 %t885, ptr %l286, !tbaa !23
  %t887 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s27, ptr %l30)
  store { i64, ptr } %t887, ptr %l288
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s29
  %t888 = load ptr, ptr %l1, !tbaa !29
  store ptr %t888, ptr %l291, !tbaa !29
  %t889 = load i32, ptr %l17, !tbaa !23
  store i32 %t889, ptr %l292, !tbaa !23
  %t890 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t890, ptr %l293, !tbaa !27
  %t891 = load i32, ptr %l17, !tbaa !23
  store i32 %t891, ptr %l294, !tbaa !23
  %t893 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s29, ptr %l30)
  store { i64, ptr } %t893, ptr %l296
  br label %bb87
bb85:
  %t894 = extractvalue { i64, ptr } { i64 15, ptr @.d215 }, 1
  %t895 = extractvalue { i64, ptr } { i64 15, ptr @.d215 }, 0
  %t896 = load i32, ptr %l286, !tbaa !23
  %t897 = sext i32 %t896 to i64
  %t898 = call i64 @__olang_fmt_i64(ptr null, i64 %t897)
  %t899 = add i64 %t895, %t898
  %t900 = extractvalue { i64, ptr } { i64 1, ptr @.d216 }, 1
  %t901 = extractvalue { i64, ptr } { i64 1, ptr @.d216 }, 0
  %t902 = add i64 %t899, %t901
  %t903 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 2, ptr @.d217 }, 1
  %t908 = extractvalue { i64, ptr } { i64 2, ptr @.d217 }, 0
  %t909 = add i64 %t906, %t908
  %t910 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t909)
  call void @olang_textcopy(ptr %t910, ptr %t894, i64 %t895)
  %t911 = getelementptr i8, ptr %t910, i64 %t895
  %t912 = call i64 @__olang_fmt_i64(ptr %t911, i64 %t897)
  %t913 = getelementptr i8, ptr %t911, i64 %t898
  call void @olang_textcopy(ptr %t913, ptr %t900, i64 %t901)
  %t914 = getelementptr i8, ptr %t913, i64 %t901
  call void @olang_textcopy(ptr %t914, ptr %t904, i64 %t905)
  %t915 = getelementptr i8, ptr %t914, i64 %t905
  call void @olang_textcopy(ptr %t915, ptr %t907, i64 %t908)
  %t916 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t917 = insertvalue { i64, ptr } %t916, ptr %t910, 1
  %t919 = extractvalue { i64, ptr } %t917, 0
  %t920 = extractvalue { i64, ptr } %t917, 1
  %t921 = mul i64 %t919, 1
  %t922 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t921)
  call void @llvm.memcpy.p0.p0.i64(ptr %t922, ptr %t920, i64 %t921, i1 false)
  %t923 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t922, 1
  %t925 = load ptr, ptr %l285, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t925, { i64, ptr } %t924)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb92
bb87:
  %t927 = extractvalue { i64, ptr } { i64 5, ptr @.d218 }, 1
  %t928 = extractvalue { i64, ptr } { i64 5, ptr @.d218 }, 0
  %t929 = load i32, ptr %l292, !tbaa !23
  %t930 = sext i32 %t929 to i64
  %t931 = call i64 @__olang_fmt_i64(ptr null, i64 %t930)
  %t932 = add i64 %t928, %t931
  %t933 = extractvalue { i64, ptr } { i64 8, ptr @.d219 }, 1
  %t934 = extractvalue { i64, ptr } { i64 8, ptr @.d219 }, 0
  %t935 = add i64 %t932, %t934
  %t936 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 1
  %t938 = extractvalue { i64, ptr } %t936, 0
  %t939 = add i64 %t935, %t938
  %t940 = extractvalue { i64, ptr } { i64 4, ptr @.d220 }, 1
  %t941 = extractvalue { i64, ptr } { i64 4, ptr @.d220 }, 0
  %t942 = add i64 %t939, %t941
  %t943 = load i32, ptr %l294, !tbaa !23
  %t944 = sext i32 %t943 to i64
  %t945 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t946 = add i64 %t942, %t945
  %t947 = extractvalue { i64, ptr } { i64 1, ptr @.d221 }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr @.d221 }, 0
  %t949 = add i64 %t946, %t948
  %t950 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t951 = extractvalue { i64, ptr } %t950, 1
  %t952 = extractvalue { i64, ptr } %t950, 0
  %t953 = add i64 %t949, %t952
  %t954 = extractvalue { i64, ptr } { i64 2, ptr @.d222 }, 1
  %t955 = extractvalue { i64, ptr } { i64 2, ptr @.d222 }, 0
  %t956 = add i64 %t953, %t955
  %t957 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t956)
  call void @olang_textcopy(ptr %t957, ptr %t927, i64 %t928)
  %t958 = getelementptr i8, ptr %t957, i64 %t928
  %t959 = call i64 @__olang_fmt_i64(ptr %t958, i64 %t930)
  %t960 = getelementptr i8, ptr %t958, i64 %t931
  call void @olang_textcopy(ptr %t960, ptr %t933, i64 %t934)
  %t961 = getelementptr i8, ptr %t960, i64 %t934
  call void @olang_textcopy(ptr %t961, ptr %t937, i64 %t938)
  %t962 = getelementptr i8, ptr %t961, i64 %t938
  call void @olang_textcopy(ptr %t962, ptr %t940, i64 %t941)
  %t963 = getelementptr i8, ptr %t962, i64 %t941
  %t964 = call i64 @__olang_fmt_i64(ptr %t963, i64 %t944)
  %t965 = getelementptr i8, ptr %t963, i64 %t945
  call void @olang_textcopy(ptr %t965, ptr %t947, i64 %t948)
  %t966 = getelementptr i8, ptr %t965, i64 %t948
  call void @olang_textcopy(ptr %t966, ptr %t951, i64 %t952)
  %t967 = getelementptr i8, ptr %t966, i64 %t952
  call void @olang_textcopy(ptr %t967, ptr %t954, i64 %t955)
  %t968 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t957, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = extractvalue { i64, ptr } %t969, 1
  %t973 = mul i64 %t971, 1
  %t974 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t974, ptr %t972, i64 %t973, i1 false)
  %t975 = insertvalue { i64, ptr } undef, i64 %t971, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t974, 1
  %t977 = load ptr, ptr %l291, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s29, ptr %t977, { i64, ptr } %t976)
  br label %bb88
bb88:
  %t979 = load i32, ptr %l17, !tbaa !23
  %t980 = extractvalue { i64, ptr } { i64 3, ptr @.d223 }, 1
  %t981 = extractvalue { i64, ptr } { i64 3, ptr @.d223 }, 0
  %t983 = sext i32 %t979 to i64
  %t984 = call i64 @__olang_fmt_i64(ptr null, i64 %t983)
  %t985 = add i64 %t981, %t984
  %t986 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t985)
  call void @olang_textcopy(ptr %t986, ptr %t980, i64 %t981)
  %t987 = getelementptr i8, ptr %t986, i64 %t981
  %t988 = call i64 @__olang_fmt_i64(ptr %t987, i64 %t983)
  %t989 = insertvalue { i64, ptr } undef, i64 %t985, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t986, 1
  store { i64, ptr } %t990, ptr %l300, !tbaa !27
  %t991 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t992 = extractvalue { i64, ptr } %t991, 0
  %t993 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t993, 0
  store i64 %t994, ptr %l302, !tbaa !24
  %t996 = load i64, ptr %l302, !tbaa !24
  %t997 = icmp eq i64 %t992, %t996
  br i1 %t997, label %bb89, label %bb90
bb89:
  %t999 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t1000 = load ptr, ptr %t999, !tbaa !27
  %t1001 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = load i64, ptr %l302, !tbaa !24
  %t1004 = mul i64 %t1003, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1000, ptr %t1002, i64 %t1004, i1 false)
  br label %bb91
bb90:
  %t1005 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t1005, ptr %l40, !tbaa !27
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s29)
  br label %bb92
bb92:
  %t1006 = load i1, ptr %l32, !tbaa !21
  br i1 %t1006, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s32
  %t1008 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1008, ptr %l305, !tbaa !29
  %t1009 = load i32, ptr %l17, !tbaa !23
  store i32 %t1009, ptr %l306, !tbaa !23
  %t1010 = load ptr, ptr %l8, !tbaa !29
  %t1011 = load i32, ptr %l31, !tbaa !23
  %t1014 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t1010, i32 %t1011)
  store { i64, ptr } %t1014, ptr %l309
  br label %bb95
bb94:
  br label %bb100
bb95:
  %t1015 = load i32, ptr %l17, !tbaa !23
  %t1016 = extractvalue { i64, ptr } { i64 5, ptr @.d224 }, 1
  %t1017 = extractvalue { i64, ptr } { i64 5, ptr @.d224 }, 0
  %t1018 = load i32, ptr %l306, !tbaa !23
  %t1019 = sext i32 %t1018 to i64
  %t1020 = call i64 @__olang_fmt_i64(ptr null, i64 %t1019)
  %t1021 = add i64 %t1017, %t1020
  %t1022 = extractvalue { i64, ptr } { i64 8, ptr @.d225 }, 1
  %t1023 = extractvalue { i64, ptr } { i64 8, ptr @.d225 }, 0
  %t1024 = add i64 %t1021, %t1023
  %t1025 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t1026 = extractvalue { i64, ptr } %t1025, 1
  %t1027 = extractvalue { i64, ptr } %t1025, 0
  %t1028 = add i64 %t1024, %t1027
  %t1029 = extractvalue { i64, ptr } { i64 9, ptr @.d226 }, 1
  %t1030 = extractvalue { i64, ptr } { i64 9, ptr @.d226 }, 0
  %t1031 = add i64 %t1028, %t1030
  %t1033 = sext i32 %t1015 to i64
  %t1034 = call i64 @__olang_fmt_i64(ptr null, i64 %t1033)
  %t1035 = add i64 %t1031, %t1034
  %t1036 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 1
  %t1037 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 0
  %t1038 = add i64 %t1035, %t1037
  %t1039 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1038)
  call void @olang_textcopy(ptr %t1039, ptr %t1016, i64 %t1017)
  %t1040 = getelementptr i8, ptr %t1039, i64 %t1017
  %t1041 = call i64 @__olang_fmt_i64(ptr %t1040, i64 %t1019)
  %t1042 = getelementptr i8, ptr %t1040, i64 %t1020
  call void @olang_textcopy(ptr %t1042, ptr %t1022, i64 %t1023)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1023
  call void @olang_textcopy(ptr %t1043, ptr %t1026, i64 %t1027)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1027
  call void @olang_textcopy(ptr %t1044, ptr %t1029, i64 %t1030)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1030
  %t1046 = call i64 @__olang_fmt_i64(ptr %t1045, i64 %t1033)
  %t1047 = getelementptr i8, ptr %t1045, i64 %t1034
  call void @olang_textcopy(ptr %t1047, ptr %t1036, i64 %t1037)
  %t1048 = insertvalue { i64, ptr } undef, i64 %t1038, 0
  %t1049 = insertvalue { i64, ptr } %t1048, ptr %t1039, 1
  %t1051 = extractvalue { i64, ptr } %t1049, 0
  %t1052 = extractvalue { i64, ptr } %t1049, 1
  %t1053 = mul i64 %t1051, 1
  %t1054 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1053)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1054, ptr %t1052, i64 %t1053, i1 false)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1054, 1
  %t1057 = load ptr, ptr %l305, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t1057, { i64, ptr } %t1056)
  br label %bb96
bb96:
  %t1059 = load i32, ptr %l17, !tbaa !23
  %t1060 = extractvalue { i64, ptr } { i64 3, ptr @.d228 }, 1
  %t1061 = extractvalue { i64, ptr } { i64 3, ptr @.d228 }, 0
  %t1063 = sext i32 %t1059 to i64
  %t1064 = call i64 @__olang_fmt_i64(ptr null, i64 %t1063)
  %t1065 = add i64 %t1061, %t1064
  %t1066 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t1065)
  call void @olang_textcopy(ptr %t1066, ptr %t1060, i64 %t1061)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1061
  %t1068 = call i64 @__olang_fmt_i64(ptr %t1067, i64 %t1063)
  %t1069 = insertvalue { i64, ptr } undef, i64 %t1065, 0
  %t1070 = insertvalue { i64, ptr } %t1069, ptr %t1066, 1
  store { i64, ptr } %t1070, ptr %l314, !tbaa !27
  %t1071 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1072 = extractvalue { i64, ptr } %t1071, 0
  %t1073 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  store i64 %t1074, ptr %l316, !tbaa !24
  %t1076 = load i64, ptr %l316, !tbaa !24
  %t1077 = icmp eq i64 %t1072, %t1076
  br i1 %t1077, label %bb97, label %bb98
bb97:
  %t1079 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t1080 = load ptr, ptr %t1079, !tbaa !27
  %t1081 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t1082 = load ptr, ptr %t1081, !tbaa !27
  %t1083 = load i64, ptr %l316, !tbaa !24
  %t1084 = mul i64 %t1083, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1080, ptr %t1082, i64 %t1084, i1 false)
  br label %bb99
bb98:
  %t1085 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t1085, ptr %l40, !tbaa !27
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s32)
  br label %bb100
bb100:
  %t1086 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1088 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t1086, { i64, ptr } { i64 0, ptr @.d229 })
  store i1 %t1088, ptr %l319
  br label %bb101
bb101:
  %t1089 = load i1, ptr %l319, !tbaa !21
  %t1090 = xor i1 %t1089, true
  br i1 %t1090, label %bb102, label %bb103
bb102:
  %t1092 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1093 = getelementptr %"compiler/mir:Range", ptr %t1092, i32 0, i32 1
  %t1094 = load i32, ptr %t1093, !tbaa !23
  %t1096 = icmp sgt i32 %t1094, 0
  store i1 %t1096, ptr %l321, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb104
bb104:
  %t1098 = load i1, ptr %l321, !tbaa !21
  br i1 %t1098, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s35
  %t1099 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1100 = getelementptr %"compiler/mir:Range", ptr %t1099, i32 0, i32 1
  %t1101 = load i32, ptr %t1100, !tbaa !23
  %t1103 = icmp eq i32 %t1101, 1
  br i1 %t1103, label %bb107, label %bb108
bb106:
  br label %bb133
bb107:
  store %olang.scope zeroinitializer, ptr %s36
  %t1105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1105, ptr %l326, !tbaa !29
  %t1106 = load i32, ptr %l17, !tbaa !23
  store i32 %t1106, ptr %l327, !tbaa !23
  %t1107 = load i64, ptr %l6, !tbaa !24
  store i64 %t1107, ptr %l328, !tbaa !24
  %t1108 = load ptr, ptr %l8, !tbaa !29
  %t1109 = load i32, ptr %l31, !tbaa !23
  %t1112 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s36, ptr %t1108, i32 %t1109)
  store { i64, ptr } %t1112, ptr %l331
  br label %bb109
bb108:
  %t1113 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1113, ptr %l336, !tbaa !29
  %t1114 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1114, ptr %l337, !tbaa !29
  %t1115 = load ptr, ptr %l9, !tbaa !29
  %t1116 = load i32, ptr %l31, !tbaa !23
  %t1119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1115, i32 %t1116)
  store i32 %t1119, ptr %l340
  br label %bb111
bb109:
  %t1120 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1121 = load i32, ptr %l17, !tbaa !23
  %t1122 = extractvalue { i64, ptr } { i64 5, ptr @.d230 }, 1
  %t1123 = extractvalue { i64, ptr } { i64 5, ptr @.d230 }, 0
  %t1124 = load i32, ptr %l327, !tbaa !23
  %t1125 = sext i32 %t1124 to i64
  %t1126 = call i64 @__olang_fmt_i64(ptr null, i64 %t1125)
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 19, ptr @.d231 }, 1
  %t1129 = extractvalue { i64, ptr } { i64 19, ptr @.d231 }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = load i64, ptr %l328, !tbaa !24
  %t1132 = call i64 @__olang_fmt_i64(ptr null, i64 %t1131)
  %t1133 = add i64 %t1130, %t1132
  %t1134 = extractvalue { i64, ptr } { i64 9, ptr @.d232 }, 1
  %t1135 = extractvalue { i64, ptr } { i64 9, ptr @.d232 }, 0
  %t1136 = add i64 %t1133, %t1135
  %t1137 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 1
  %t1139 = extractvalue { i64, ptr } %t1137, 0
  %t1140 = add i64 %t1136, %t1139
  %t1141 = extractvalue { i64, ptr } { i64 1, ptr @.d233 }, 1
  %t1142 = extractvalue { i64, ptr } { i64 1, ptr @.d233 }, 0
  %t1143 = add i64 %t1140, %t1142
  %t1145 = extractvalue { i64, ptr } %t1120, 1
  %t1146 = extractvalue { i64, ptr } %t1120, 0
  %t1147 = add i64 %t1143, %t1146
  %t1148 = extractvalue { i64, ptr } { i64 9, ptr @.d234 }, 1
  %t1149 = extractvalue { i64, ptr } { i64 9, ptr @.d234 }, 0
  %t1150 = add i64 %t1147, %t1149
  %t1152 = sext i32 %t1121 to i64
  %t1153 = call i64 @__olang_fmt_i64(ptr null, i64 %t1152)
  %t1154 = add i64 %t1150, %t1153
  %t1155 = extractvalue { i64, ptr } { i64 1, ptr @.d235 }, 1
  %t1156 = extractvalue { i64, ptr } { i64 1, ptr @.d235 }, 0
  %t1157 = add i64 %t1154, %t1156
  %t1158 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1157)
  call void @olang_textcopy(ptr %t1158, ptr %t1122, i64 %t1123)
  %t1159 = getelementptr i8, ptr %t1158, i64 %t1123
  %t1160 = call i64 @__olang_fmt_i64(ptr %t1159, i64 %t1125)
  %t1161 = getelementptr i8, ptr %t1159, i64 %t1126
  call void @olang_textcopy(ptr %t1161, ptr %t1128, i64 %t1129)
  %t1162 = getelementptr i8, ptr %t1161, i64 %t1129
  %t1163 = call i64 @__olang_fmt_i64(ptr %t1162, i64 %t1131)
  %t1164 = getelementptr i8, ptr %t1162, i64 %t1132
  call void @olang_textcopy(ptr %t1164, ptr %t1134, i64 %t1135)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1135
  call void @olang_textcopy(ptr %t1165, ptr %t1138, i64 %t1139)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1139
  call void @olang_textcopy(ptr %t1166, ptr %t1141, i64 %t1142)
  %t1167 = getelementptr i8, ptr %t1166, i64 %t1142
  call void @olang_textcopy(ptr %t1167, ptr %t1145, i64 %t1146)
  %t1168 = getelementptr i8, ptr %t1167, i64 %t1146
  call void @olang_textcopy(ptr %t1168, ptr %t1148, i64 %t1149)
  %t1169 = getelementptr i8, ptr %t1168, i64 %t1149
  %t1170 = call i64 @__olang_fmt_i64(ptr %t1169, i64 %t1152)
  %t1171 = getelementptr i8, ptr %t1169, i64 %t1153
  call void @olang_textcopy(ptr %t1171, ptr %t1155, i64 %t1156)
  %t1172 = insertvalue { i64, ptr } undef, i64 %t1157, 0
  %t1173 = insertvalue { i64, ptr } %t1172, ptr %t1158, 1
  %t1175 = extractvalue { i64, ptr } %t1173, 0
  %t1176 = extractvalue { i64, ptr } %t1173, 1
  %t1177 = mul i64 %t1175, 1
  %t1178 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1178, ptr %t1176, i64 %t1177, i1 false)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1175, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1178, 1
  %t1181 = load ptr, ptr %l326, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t1181, { i64, ptr } %t1180)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s36)
  br label %bb131
bb111:
  %t1183 = load ptr, ptr %l337, !tbaa !29
  %t1184 = load i32, ptr %l340, !tbaa !23
  %t1185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1183, i32 %t1184)
  store i32 %t1185, ptr %l341
  br label %bb112
bb112:
  %t1186 = load ptr, ptr %l336, !tbaa !29
  %t1187 = load i32, ptr %l341, !tbaa !23
  %t1188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1186, i32 %t1187)
  store { i64, ptr } %t1188, ptr %l342
  br label %bb113
bb113:
  %t1189 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t1189, ptr %l41, !tbaa !27
  store i32 0, ptr %l42, !tbaa !23
  %t1190 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1191 = getelementptr %"compiler/mir:Range", ptr %t1190, i32 0, i32 1
  %t1192 = load i32, ptr %t1191, !tbaa !23
  store i32 %t1192, ptr %l43, !tbaa !23
  store i32 1, ptr %l44, !tbaa !23
  %t1194 = load i32, ptr %l43, !tbaa !23
  %t1195 = load i32, ptr %l42, !tbaa !23
  %t1198 = icmp sgt i32 %t1194, %t1195
  br i1 %t1198, label %bb114, label %bb115
bb114:
  %t1200 = load i32, ptr %l44, !tbaa !23
  %t1202 = icmp sgt i32 %t1200, 0
  br i1 %t1202, label %bb116, label %bb117
bb115:
  store i32 0, ptr %l347, !tbaa !23
  br label %bb119
bb116:
  %t1204 = load i32, ptr %l43, !tbaa !23
  %t1205 = load i32, ptr %l42, !tbaa !23
  %t1208 = sub i32 %t1204, %t1205
  %t1209 = load i32, ptr %l44, !tbaa !23
  %t1212 = add i32 %t1208, %t1209
  %t1214 = sub i32 %t1212, 1
  %t1215 = load i32, ptr %l44, !tbaa !23
  %t1218 = sdiv i32 %t1214, %t1215
  store i32 %t1218, ptr %l350, !tbaa !23
  br label %bb118
bb117:
  store i32 0, ptr %l350, !tbaa !23
  br label %bb118
bb118:
  %t1220 = load i32, ptr %l350, !tbaa !23
  store i32 %t1220, ptr %l347, !tbaa !23
  br label %bb119
bb119:
  %t1221 = load i32, ptr %l347, !tbaa !23
  store i32 %t1221, ptr %l45, !tbaa !23
  store i32 0, ptr %l46, !tbaa !23
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s40
  %t1222 = load i32, ptr %l46, !tbaa !23
  %t1223 = load i32, ptr %l45, !tbaa !23
  %t1226 = icmp slt i32 %t1222, %t1223
  %t1228 = xor i1 %t1226, true
  br i1 %t1228, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s40)
  br label %bb130
bb122:
  br label %bb123
bb123:
  %t1230 = load i32, ptr %l42, !tbaa !23
  %t1231 = load i32, ptr %l46, !tbaa !23
  %t1232 = load i32, ptr %l44, !tbaa !23
  %t1235 = mul i32 %t1231, %t1232
  %t1238 = add i32 %t1230, %t1235
  store i32 %t1238, ptr %l47, !tbaa !23
  %t1240 = load ptr, ptr %l1, !tbaa !29
  %t1241 = load i32, ptr %l17, !tbaa !23
  %t1242 = load i32, ptr %l47, !tbaa !23
  %t1243 = load i64, ptr %l6, !tbaa !24
  %t1244 = load i32, ptr %l47, !tbaa !23
  %t1246 = sext i32 %t1244 to i64
  %t1249 = add i64 %t1243, %t1246
  %t1250 = extractvalue { i64, ptr } { i64 5, ptr @.d236 }, 1
  %t1251 = extractvalue { i64, ptr } { i64 5, ptr @.d236 }, 0
  %t1253 = sext i32 %t1241 to i64
  %t1254 = call i64 @__olang_fmt_i64(ptr null, i64 %t1253)
  %t1255 = add i64 %t1251, %t1254
  %t1256 = extractvalue { i64, ptr } { i64 1, ptr @.d237 }, 1
  %t1257 = extractvalue { i64, ptr } { i64 1, ptr @.d237 }, 0
  %t1258 = add i64 %t1255, %t1257
  %t1260 = sext i32 %t1242 to i64
  %t1261 = call i64 @__olang_fmt_i64(ptr null, i64 %t1260)
  %t1262 = add i64 %t1258, %t1261
  %t1263 = extractvalue { i64, ptr } { i64 19, ptr @.d238 }, 1
  %t1264 = extractvalue { i64, ptr } { i64 19, ptr @.d238 }, 0
  %t1265 = add i64 %t1262, %t1264
  %t1267 = call i64 @__olang_fmt_i64(ptr null, i64 %t1249)
  %t1268 = add i64 %t1265, %t1267
  %t1269 = extractvalue { i64, ptr } { i64 1, ptr @.d239 }, 1
  %t1270 = extractvalue { i64, ptr } { i64 1, ptr @.d239 }, 0
  %t1271 = add i64 %t1268, %t1270
  %t1272 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1271)
  call void @olang_textcopy(ptr %t1272, ptr %t1250, i64 %t1251)
  %t1273 = getelementptr i8, ptr %t1272, i64 %t1251
  %t1274 = call i64 @__olang_fmt_i64(ptr %t1273, i64 %t1253)
  %t1275 = getelementptr i8, ptr %t1273, i64 %t1254
  call void @olang_textcopy(ptr %t1275, ptr %t1256, i64 %t1257)
  %t1276 = getelementptr i8, ptr %t1275, i64 %t1257
  %t1277 = call i64 @__olang_fmt_i64(ptr %t1276, i64 %t1260)
  %t1278 = getelementptr i8, ptr %t1276, i64 %t1261
  call void @olang_textcopy(ptr %t1278, ptr %t1263, i64 %t1264)
  %t1279 = getelementptr i8, ptr %t1278, i64 %t1264
  %t1280 = call i64 @__olang_fmt_i64(ptr %t1279, i64 %t1249)
  %t1281 = getelementptr i8, ptr %t1279, i64 %t1267
  call void @olang_textcopy(ptr %t1281, ptr %t1269, i64 %t1270)
  %t1282 = insertvalue { i64, ptr } undef, i64 %t1271, 0
  %t1283 = insertvalue { i64, ptr } %t1282, ptr %t1272, 1
  %t1285 = extractvalue { i64, ptr } %t1283, 0
  %t1286 = extractvalue { i64, ptr } %t1283, 1
  %t1287 = mul i64 %t1285, 1
  %t1288 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1288, ptr %t1286, i64 %t1287, i1 false)
  %t1289 = insertvalue { i64, ptr } undef, i64 %t1285, 0
  %t1290 = insertvalue { i64, ptr } %t1289, ptr %t1288, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1240, { i64, ptr } %t1290)
  br label %bb124
bb124:
  %t1293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1293, ptr %l377, !tbaa !29
  %t1294 = load i32, ptr %l17, !tbaa !23
  store i32 %t1294, ptr %l378, !tbaa !23
  %t1295 = load i32, ptr %l47, !tbaa !23
  store i32 %t1295, ptr %l379, !tbaa !23
  %t1296 = load ptr, ptr %l8, !tbaa !29
  %t1297 = load i32, ptr %l31, !tbaa !23
  %t1300 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1296, i32 %t1297)
  store { i64, ptr } %t1300, ptr %l382
  br label %bb125
bb125:
  %t1301 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1302 = load i32, ptr %l47, !tbaa !23
  %t1303 = extractvalue { i64, ptr } { i64 5, ptr @.d240 }, 1
  %t1304 = extractvalue { i64, ptr } { i64 5, ptr @.d240 }, 0
  %t1305 = load i32, ptr %l378, !tbaa !23
  %t1306 = sext i32 %t1305 to i64
  %t1307 = call i64 @__olang_fmt_i64(ptr null, i64 %t1306)
  %t1308 = add i64 %t1304, %t1307
  %t1309 = extractvalue { i64, ptr } { i64 1, ptr @.d241 }, 1
  %t1310 = extractvalue { i64, ptr } { i64 1, ptr @.d241 }, 0
  %t1311 = add i64 %t1308, %t1310
  %t1312 = load i32, ptr %l379, !tbaa !23
  %t1313 = sext i32 %t1312 to i64
  %t1314 = call i64 @__olang_fmt_i64(ptr null, i64 %t1313)
  %t1315 = add i64 %t1311, %t1314
  %t1316 = extractvalue { i64, ptr } { i64 16, ptr @.d242 }, 1
  %t1317 = extractvalue { i64, ptr } { i64 16, ptr @.d242 }, 0
  %t1318 = add i64 %t1315, %t1317
  %t1319 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t1320 = extractvalue { i64, ptr } %t1319, 1
  %t1321 = extractvalue { i64, ptr } %t1319, 0
  %t1322 = add i64 %t1318, %t1321
  %t1323 = extractvalue { i64, ptr } { i64 1, ptr @.d243 }, 1
  %t1324 = extractvalue { i64, ptr } { i64 1, ptr @.d243 }, 0
  %t1325 = add i64 %t1322, %t1324
  %t1327 = extractvalue { i64, ptr } %t1301, 1
  %t1328 = extractvalue { i64, ptr } %t1301, 0
  %t1329 = add i64 %t1325, %t1328
  %t1330 = extractvalue { i64, ptr } { i64 2, ptr @.d244 }, 1
  %t1331 = extractvalue { i64, ptr } { i64 2, ptr @.d244 }, 0
  %t1332 = add i64 %t1329, %t1331
  %t1334 = sext i32 %t1302 to i64
  %t1335 = call i64 @__olang_fmt_i64(ptr null, i64 %t1334)
  %t1336 = add i64 %t1332, %t1335
  %t1337 = extractvalue { i64, ptr } { i64 1, ptr @.d245 }, 1
  %t1338 = extractvalue { i64, ptr } { i64 1, ptr @.d245 }, 0
  %t1339 = add i64 %t1336, %t1338
  %t1340 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1339)
  call void @olang_textcopy(ptr %t1340, ptr %t1303, i64 %t1304)
  %t1341 = getelementptr i8, ptr %t1340, i64 %t1304
  %t1342 = call i64 @__olang_fmt_i64(ptr %t1341, i64 %t1306)
  %t1343 = getelementptr i8, ptr %t1341, i64 %t1307
  call void @olang_textcopy(ptr %t1343, ptr %t1309, i64 %t1310)
  %t1344 = getelementptr i8, ptr %t1343, i64 %t1310
  %t1345 = call i64 @__olang_fmt_i64(ptr %t1344, i64 %t1313)
  %t1346 = getelementptr i8, ptr %t1344, i64 %t1314
  call void @olang_textcopy(ptr %t1346, ptr %t1316, i64 %t1317)
  %t1347 = getelementptr i8, ptr %t1346, i64 %t1317
  call void @olang_textcopy(ptr %t1347, ptr %t1320, i64 %t1321)
  %t1348 = getelementptr i8, ptr %t1347, i64 %t1321
  call void @olang_textcopy(ptr %t1348, ptr %t1323, i64 %t1324)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1324
  call void @olang_textcopy(ptr %t1349, ptr %t1327, i64 %t1328)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1328
  call void @olang_textcopy(ptr %t1350, ptr %t1330, i64 %t1331)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1331
  %t1352 = call i64 @__olang_fmt_i64(ptr %t1351, i64 %t1334)
  %t1353 = getelementptr i8, ptr %t1351, i64 %t1335
  call void @olang_textcopy(ptr %t1353, ptr %t1337, i64 %t1338)
  %t1354 = insertvalue { i64, ptr } undef, i64 %t1339, 0
  %t1355 = insertvalue { i64, ptr } %t1354, ptr %t1340, 1
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  %t1358 = extractvalue { i64, ptr } %t1355, 1
  %t1359 = mul i64 %t1357, 1
  %t1360 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1360, ptr %t1358, i64 %t1359, i1 false)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1357, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1360, 1
  %t1363 = load ptr, ptr %l377, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1363, { i64, ptr } %t1362)
  br label %bb126
bb126:
  %t1365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1365, ptr %l387, !tbaa !29
  %t1366 = load ptr, ptr %l8, !tbaa !29
  %t1367 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1367, ptr %l389, !tbaa !27
  %t1368 = load i32, ptr %l47, !tbaa !23
  %t1370 = sext i32 %t1368 to i64
  %t1371 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t1372 = load ptr, ptr %t1371, !tbaa !27
  %t1373 = getelementptr i32, ptr %t1372, i64 %t1370
  %t1374 = load i32, ptr %t1373, !tbaa !33
  %t1377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1366, i32 %t1374)
  store { i64, ptr } %t1377, ptr %l392
  br label %bb127
bb127:
  %t1378 = load i32, ptr %l17, !tbaa !23
  %t1379 = load i32, ptr %l47, !tbaa !23
  %t1380 = load i32, ptr %l17, !tbaa !23
  %t1381 = load i32, ptr %l47, !tbaa !23
  %t1382 = extractvalue { i64, ptr } { i64 8, ptr @.d246 }, 1
  %t1383 = extractvalue { i64, ptr } { i64 8, ptr @.d246 }, 0
  %t1384 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t1385 = extractvalue { i64, ptr } %t1384, 1
  %t1386 = extractvalue { i64, ptr } %t1384, 0
  %t1387 = add i64 %t1383, %t1386
  %t1388 = extractvalue { i64, ptr } { i64 4, ptr @.d247 }, 1
  %t1389 = extractvalue { i64, ptr } { i64 4, ptr @.d247 }, 0
  %t1390 = add i64 %t1387, %t1389
  %t1392 = sext i32 %t1378 to i64
  %t1393 = call i64 @__olang_fmt_i64(ptr null, i64 %t1392)
  %t1394 = add i64 %t1390, %t1393
  %t1395 = extractvalue { i64, ptr } { i64 1, ptr @.d248 }, 1
  %t1396 = extractvalue { i64, ptr } { i64 1, ptr @.d248 }, 0
  %t1397 = add i64 %t1394, %t1396
  %t1399 = sext i32 %t1379 to i64
  %t1400 = call i64 @__olang_fmt_i64(ptr null, i64 %t1399)
  %t1401 = add i64 %t1397, %t1400
  %t1402 = extractvalue { i64, ptr } { i64 9, ptr @.d249 }, 1
  %t1403 = extractvalue { i64, ptr } { i64 9, ptr @.d249 }, 0
  %t1404 = add i64 %t1401, %t1403
  %t1406 = sext i32 %t1380 to i64
  %t1407 = call i64 @__olang_fmt_i64(ptr null, i64 %t1406)
  %t1408 = add i64 %t1404, %t1407
  %t1409 = extractvalue { i64, ptr } { i64 1, ptr @.d250 }, 1
  %t1410 = extractvalue { i64, ptr } { i64 1, ptr @.d250 }, 0
  %t1411 = add i64 %t1408, %t1410
  %t1413 = sext i32 %t1381 to i64
  %t1414 = call i64 @__olang_fmt_i64(ptr null, i64 %t1413)
  %t1415 = add i64 %t1411, %t1414
  %t1416 = extractvalue { i64, ptr } { i64 1, ptr @.d251 }, 1
  %t1417 = extractvalue { i64, ptr } { i64 1, ptr @.d251 }, 0
  %t1418 = add i64 %t1415, %t1417
  %t1419 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1418)
  call void @olang_textcopy(ptr %t1419, ptr %t1382, i64 %t1383)
  %t1420 = getelementptr i8, ptr %t1419, i64 %t1383
  call void @olang_textcopy(ptr %t1420, ptr %t1385, i64 %t1386)
  %t1421 = getelementptr i8, ptr %t1420, i64 %t1386
  call void @olang_textcopy(ptr %t1421, ptr %t1388, i64 %t1389)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1389
  %t1423 = call i64 @__olang_fmt_i64(ptr %t1422, i64 %t1392)
  %t1424 = getelementptr i8, ptr %t1422, i64 %t1393
  call void @olang_textcopy(ptr %t1424, ptr %t1395, i64 %t1396)
  %t1425 = getelementptr i8, ptr %t1424, i64 %t1396
  %t1426 = call i64 @__olang_fmt_i64(ptr %t1425, i64 %t1399)
  %t1427 = getelementptr i8, ptr %t1425, i64 %t1400
  call void @olang_textcopy(ptr %t1427, ptr %t1402, i64 %t1403)
  %t1428 = getelementptr i8, ptr %t1427, i64 %t1403
  %t1429 = call i64 @__olang_fmt_i64(ptr %t1428, i64 %t1406)
  %t1430 = getelementptr i8, ptr %t1428, i64 %t1407
  call void @olang_textcopy(ptr %t1430, ptr %t1409, i64 %t1410)
  %t1431 = getelementptr i8, ptr %t1430, i64 %t1410
  %t1432 = call i64 @__olang_fmt_i64(ptr %t1431, i64 %t1413)
  %t1433 = getelementptr i8, ptr %t1431, i64 %t1414
  call void @olang_textcopy(ptr %t1433, ptr %t1416, i64 %t1417)
  %t1434 = insertvalue { i64, ptr } undef, i64 %t1418, 0
  %t1435 = insertvalue { i64, ptr } %t1434, ptr %t1419, 1
  %t1437 = extractvalue { i64, ptr } %t1435, 0
  %t1438 = extractvalue { i64, ptr } %t1435, 1
  %t1439 = mul i64 %t1437, 1
  %t1440 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1440, ptr %t1438, i64 %t1439, i1 false)
  %t1441 = insertvalue { i64, ptr } undef, i64 %t1437, 0
  %t1442 = insertvalue { i64, ptr } %t1441, ptr %t1440, 1
  %t1443 = load ptr, ptr %l387, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1443, { i64, ptr } %t1442)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s40)
  br label %bb129
bb129:
  %t1445 = load i32, ptr %l46, !tbaa !23
  %t1447 = add i32 %t1445, 1
  store i32 %t1447, ptr %l46, !tbaa !23
  br label %bb120
bb130:
  br label %bb131
bb131:
  %t1449 = load ptr, ptr %l0, !tbaa !29
  %t1450 = load ptr, ptr %l1, !tbaa !29
  %t1451 = load %"compiler/mir:Task", ptr %l3
  %t1452 = load i64, ptr %l6, !tbaa !24
  %t1454 = load i32, ptr %l17, !tbaa !23
  %t1455 = extractvalue { i64, ptr } { i64 1, ptr @.d252 }, 1
  %t1456 = extractvalue { i64, ptr } { i64 1, ptr @.d252 }, 0
  %t1458 = sext i32 %t1454 to i64
  %t1459 = call i64 @__olang_fmt_i64(ptr null, i64 %t1458)
  %t1460 = add i64 %t1456, %t1459
  %t1461 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1460)
  call void @olang_textcopy(ptr %t1461, ptr %t1455, i64 %t1456)
  %t1462 = getelementptr i8, ptr %t1461, i64 %t1456
  %t1463 = call i64 @__olang_fmt_i64(ptr %t1462, i64 %t1458)
  %t1464 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1465 = insertvalue { i64, ptr } %t1464, ptr %t1461, 1
  %t1467 = extractvalue { i64, ptr } %t1465, 0
  %t1468 = extractvalue { i64, ptr } %t1465, 1
  %t1469 = mul i64 %t1467, 1
  %t1470 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1470, ptr %t1468, i64 %t1469, i1 false)
  %t1471 = insertvalue { i64, ptr } undef, i64 %t1467, 0
  %t1472 = insertvalue { i64, ptr } %t1471, ptr %t1470, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v3, ptr %s35, ptr %t1449, ptr %t1450, %"compiler/mir:Task" %t1451, i64 %t1452, { i64, ptr } %a7, { i64, ptr } %t1472)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s35)
  br label %bb133
bb133:
  %t1479 = load i64, ptr %l11, !tbaa !24
  %t1481 = add i64 %t1479, 1
  store i64 %t1481, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb134
bb134:
  %t1483 = load ptr, ptr %l1, !tbaa !29
  %t1484 = load i32, ptr %l17, !tbaa !23
  %t1485 = extractvalue { i64, ptr } { i64 19, ptr @.d253 }, 1
  %t1486 = extractvalue { i64, ptr } { i64 19, ptr @.d253 }, 0
  %t1488 = sext i32 %t1484 to i64
  %t1489 = call i64 @__olang_fmt_i64(ptr null, i64 %t1488)
  %t1490 = add i64 %t1486, %t1489
  %t1491 = extractvalue { i64, ptr } { i64 2, ptr @.d254 }, 1
  %t1492 = extractvalue { i64, ptr } { i64 2, ptr @.d254 }, 0
  %t1493 = add i64 %t1490, %t1492
  %t1494 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1493)
  call void @olang_textcopy(ptr %t1494, ptr %t1485, i64 %t1486)
  %t1495 = getelementptr i8, ptr %t1494, i64 %t1486
  %t1496 = call i64 @__olang_fmt_i64(ptr %t1495, i64 %t1488)
  %t1497 = getelementptr i8, ptr %t1495, i64 %t1489
  call void @olang_textcopy(ptr %t1497, ptr %t1491, i64 %t1492)
  %t1498 = insertvalue { i64, ptr } undef, i64 %t1493, 0
  %t1499 = insertvalue { i64, ptr } %t1498, ptr %t1494, 1
  %t1501 = extractvalue { i64, ptr } %t1499, 0
  %t1502 = extractvalue { i64, ptr } %t1499, 1
  %t1503 = mul i64 %t1501, 1
  %t1504 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1503)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1504, ptr %t1502, i64 %t1503, i1 false)
  %t1505 = insertvalue { i64, ptr } undef, i64 %t1501, 0
  %t1506 = insertvalue { i64, ptr } %t1505, ptr %t1504, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t1483, { i64, ptr } %t1506)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s2)
  br label %bb136
bb136:
  %t1509 = load i32, ptr %l16, !tbaa !23
  %t1511 = add i32 %t1509, 1
  store i32 %t1511, ptr %l16, !tbaa !23
  br label %bb8
bb137:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v2, ptr %t2, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = mul i64 %t8, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t9, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v2, ptr %v1, ptr %v2, ptr %t16, { i64, ptr } %t13, { i64, ptr } %a2, i32 %a3)
  store { i64, ptr } %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t10, i32 %a3)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i32, ptr %l17, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } { i64 26, ptr @.d255 }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr @.d255 }, 0
  %t24 = extractvalue { i64, ptr } %t20, 1
  %t25 = extractvalue { i64, ptr } %t20, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 3, ptr @.d256 }, 1
  %t28 = extractvalue { i64, ptr } { i64 3, ptr @.d256 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } %t41)
  store { i64, ptr } %t44, ptr %l22
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 26, ptr @.d257 }, 1
  %t49 = extractvalue { i64, ptr } { i64 26, ptr @.d257 }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr @.d258 }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr @.d258 }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l27
  br label %bb4
bb4:
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l28, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l29, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l32
  br label %bb5
bb5:
  %t80 = extractvalue { i64, ptr } { i64 8, ptr @.d259 }, 1
  %t81 = extractvalue { i64, ptr } { i64 8, ptr @.d259 }, 0
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 2, ptr @.d260 }, 1
  %t87 = extractvalue { i64, ptr } { i64 2, ptr @.d260 }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t80, i64 %t81)
  %t93 = getelementptr i8, ptr %t92, i64 %t81
  call void @olang_textcopy(ptr %t93, ptr %t83, i64 %t84)
  %t94 = getelementptr i8, ptr %t93, i64 %t84
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t89)
  %t97 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t92, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l28, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  store { i64, ptr } %t108, ptr %l35
  br label %bb6
bb6:
  %t109 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 19, ptr @.d261 })
  br label %bb7
bb7:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 34, ptr @.d262 }, 1
  %t119 = extractvalue { i64, ptr } { i64 34, ptr @.d262 }, 0
  %t121 = extractvalue { i64, ptr } %a1, 1
  %t122 = extractvalue { i64, ptr } %a1, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 6, ptr @.d263 }, 1
  %t125 = extractvalue { i64, ptr } { i64 6, ptr @.d263 }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t117, 1
  %t129 = extractvalue { i64, ptr } %t117, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t118, i64 %t119)
  %t135 = getelementptr i8, ptr %t134, i64 %t119
  call void @olang_textcopy(ptr %t135, ptr %t121, i64 %t122)
  %t136 = getelementptr i8, ptr %t135, i64 %t122
  call void @olang_textcopy(ptr %t136, ptr %t124, i64 %t125)
  %t137 = getelementptr i8, ptr %t136, i64 %t125
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t134, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t150 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t115, { i64, ptr } %t147)
  store { i64, ptr } %t150, ptr %l43
  br label %bb8
bb8:
  %t151 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/emit:fnEm", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t155, { i64, ptr } { i64 21, ptr @.d265 }, { i64, ptr } { i64 46, ptr @.d266 })
  br label %bb9
bb9:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 37, ptr @.d267 }, 1
  %t162 = extractvalue { i64, ptr } { i64 37, ptr @.d267 }, 0
  %t164 = extractvalue { i64, ptr } %t158, 1
  %t165 = extractvalue { i64, ptr } %t158, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 6, ptr @.d268 }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr @.d268 }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t159, 1
  %t172 = extractvalue { i64, ptr } %t159, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 6, ptr @.d269 }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr @.d269 }, 0
  %t176 = add i64 %t173, %t175
  %t178 = extractvalue { i64, ptr } %t160, 1
  %t179 = extractvalue { i64, ptr } %t160, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 11, ptr @.d270 }, 1
  %t182 = extractvalue { i64, ptr } { i64 11, ptr @.d270 }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t161, i64 %t162)
  %t185 = getelementptr i8, ptr %t184, i64 %t162
  call void @olang_textcopy(ptr %t185, ptr %t164, i64 %t165)
  %t186 = getelementptr i8, ptr %t185, i64 %t165
  call void @olang_textcopy(ptr %t186, ptr %t167, i64 %t168)
  %t187 = getelementptr i8, ptr %t186, i64 %t168
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t174, i64 %t175)
  %t189 = getelementptr i8, ptr %t188, i64 %t175
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t184, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t199)
  br label %bb10
bb10:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t202, { i64, ptr } %t203, { i64, ptr } %t204)
  store { i64, ptr } %t208, ptr %l55
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t209 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { { i64, ptr }, i32 }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %t1, %"compiler/mir:Place" %a1)
  store { { i64, ptr }, i32 } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { { i64, ptr }, i32 }, ptr %l8
  store { { i64, ptr }, i32 } %t6, ptr %l2
  %t7 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t23 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t26, i32 %t24)
  store i32 %t30, ptr %l15
  br label %bb2
bb2:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp ne i32 %t32, %t33
  br i1 %t36, label %bb3, label %bb4
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l22
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb6
bb5:
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l19, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l24, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } { i64 32, ptr @.d271 }, 1
  %t65 = extractvalue { i64, ptr } { i64 32, ptr @.d271 }, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = extractvalue { i64, ptr } %t63, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 14, ptr @.d272 }, 1
  %t71 = extractvalue { i64, ptr } { i64 14, ptr @.d272 }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t87 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t62, { i64, ptr } %t84)
  store { i64, ptr } %t87, ptr %l31
  br label %bb10
bb10:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/emit:fnEm", ptr %t95, i32 0, i32 14
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t99 = load ptr, ptr %l26, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %t99, { i64, ptr } { i64 3, ptr @.d273 }, { i64, ptr } %t94, { i64, ptr } %t98)
  store { i64, ptr } %t102, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 23
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t12, i64 %t15)
  store i1 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4)
  unreachable
bb10:
  %t20 = load i1, ptr %l3, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportNamed(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/mir:BasicBlock"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, [21 x i64] }
  %l18 = alloca %"compiler/mir:Place"
  %l19 = alloca { i64, [15 x i64] }
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, [2 x i64] }
  %l23 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, [21 x i64] }
  %l68 = alloca { i64, [21 x i64] }
  %l74 = alloca i1
  %l78 = alloca i1
  %l92 = alloca ptr
  %l99 = alloca ptr
  %l102 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 -1, ptr %l2, !tbaa !23
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb13
bb3:
  %t10 = getelementptr %"compiler/mir:Place", ptr %l3, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l4
  %t13 = load { i64, [2 x i64] }, ptr %l4
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l5, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757)
  unreachable
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_dde810cb192bdc32_ece13dbcfe1403b6)
  unreachable
bb18:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/mir:Fn", ptr %t27, i32 0, i32 9
  store ptr %t29, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l39
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb21, label %ok.39
ok.39:
  store { i64, ptr } %t36, ptr %l38
  br label %bb20
bb20:
  %t40 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t40, ptr %l35, !tbaa !27
  br label %bb25
bb21:
  %t41 = load i32, ptr %l39, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c0167577194c5569_3f3b475069b70a4d)
  unreachable
bb24:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb95
bb25:
  %t46 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb93
bb28:
  br label %bb29
bb29:
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t59, ptr %l48, !tbaa !27
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/mir:BasicBlock", ptr %t63, i64 %t60
  %t65 = load %"compiler/mir:BasicBlock", ptr %t64
  store %"compiler/mir:BasicBlock" %t65, ptr %l11
  %t67 = getelementptr %"compiler/mir:BasicBlock", ptr %l11, i32 0, i32 0
  store ptr %t67, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t69 = load ptr, ptr %l12, !tbaa !29
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t69, i64 %t70)
  %t74 = extractvalue { i32, { i64, ptr } } %t73, 1
  %t75 = extractvalue { i32, { i64, ptr } } %t73, 0
  store i32 %t75, ptr %l56
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb32, label %ok.77
ok.77:
  store { i64, ptr } %t74, ptr %l55
  br label %bb31
bb31:
  %t78 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t78, ptr %l52, !tbaa !27
  br label %bb36
bb32:
  %t79 = load i32, ptr %l56, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c)
  unreachable
bb35:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb91
bb36:
  %t84 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t84, ptr %l14, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t89 = load i64, ptr %l16, !tbaa !24
  %t90 = load i64, ptr %l15, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb39:
  br label %bb40
bb40:
  %t97 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t97, ptr %l65, !tbaa !27
  %t98 = load i64, ptr %l16, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, [21 x i64] }, ptr %t101, i64 %t98
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t102, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l67, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %l17, i64 176, i1 false)
  %t103 = load { i64, [21 x i64] }, ptr %l68
  %t104 = extractvalue { i64, [21 x i64] } %t103, 0
  %t105 = icmp eq i64 %t104, 0
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t107, i32 0, i32 1
  %t109 = load %"compiler/mir:Place", ptr %t108
  store %"compiler/mir:Place" %t109, ptr %l18
  %t111 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t111, i32 0, i32 2
  %t113 = load { i64, [15 x i64] }, ptr %t112
  store { i64, [15 x i64] } %t113, ptr %l19
  br label %bb43
bb42:
  br label %bb82
bb43:
  %t115 = getelementptr %"compiler/mir:Place", ptr %l18, i32 0, i32 1
  %t116 = getelementptr %"compiler/mir:Range", ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb47
bb45:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/mir:Place", ptr %l18
  %t123 = load i32, ptr %l2, !tbaa !23
  %t127 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t121, %"compiler/mir:Place" %t122, i32 %t123)
  store i1 %t127, ptr %l78
  br label %bb46
bb46:
  %t128 = load i1, ptr %l78, !tbaa !21
  %t129 = xor i1 %t128, true
  store i1 %t129, ptr %l74, !tbaa !21
  br label %bb47
bb47:
  %t131 = load i1, ptr %l74, !tbaa !21
  br i1 %t131, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb49:
  br label %bb50
bb50:
  %t132 = load { i64, [15 x i64] }, ptr %l19
  %t134 = extractvalue { i64, [15 x i64] } %t132, 0
  %t135 = icmp eq i64 %t134, 10
  br i1 %t135, label %bb51, label %bb52
bb51:
  %t137 = getelementptr { i64, [15 x i64] }, ptr %l19, i32 0, i32 1
  %t138 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t137, i32 0, i32 0
  %t139 = load { i64, [2 x i64] }, ptr %t138
  store { i64, [2 x i64] } %t139, ptr %l20
  br label %bb53
bb52:
  br label %bb76
bb53:
  %t141 = load { i64, [2 x i64] }, ptr %l20
  %t143 = extractvalue { i64, [2 x i64] } %t141, 0
  %t144 = icmp eq i64 %t143, 0
  br i1 %t144, label %bb54, label %bb55
bb54:
  %t146 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t147 = getelementptr { i32 }, ptr %t146, i32 0, i32 0
  %t148 = load i32, ptr %t147
  store i32 %t148, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb70
bb56:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/emit:fnEm", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/emit:Emitter", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/lower:Lowerer", ptr %t156, i32 0, i32 1
  %t159 = load i32, ptr %l21, !tbaa !23
  %t161 = sext i32 %t159 to i64
  %t164 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t158, i64 %t161)
  store ptr %t164, ptr %l92
  br label %bb57
bb57:
  %t165 = load ptr, ptr %l92, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Body", ptr %t165, i32 0, i32 1
  %t168 = load { i64, [2 x i64] }, ptr %t167
  store { i64, [2 x i64] } %t168, ptr %l22
  %t170 = load { i64, [2 x i64] }, ptr %l22
  %t172 = extractvalue { i64, [2 x i64] } %t170, 0
  %t173 = icmp eq i64 %t172, 0
  br i1 %t173, label %bb58, label %bb59
bb58:
  %t175 = getelementptr { i64, [2 x i64] }, ptr %l22, i32 0, i32 1
  %t176 = getelementptr { i64 }, ptr %t175, i32 0, i32 0
  %t177 = load i64, ptr %t176
  store i64 %t177, ptr %l23, !tbaa !24
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/emit:fnEm", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  store ptr %t182, ptr %l99, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/emit:fnEm", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/emit:Emitter", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/emit:fnEm", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t197 = load i64, ptr %l23, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l107
  br label %bb61
bb61:
  %t201 = load ptr, ptr %l102, !tbaa !29
  %t202 = load i64, ptr %l107, !tbaa !24
  %t203 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t201, i64 %t202)
  store ptr %t203, ptr %l108
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l108, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Func", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %t206, !tbaa !23
  %t208 = load ptr, ptr %l99, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t208, i32 %t207)
  store { i64, ptr } %t210, ptr %l111
  br label %bb63
bb63:
  %t211 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t212, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_d4e74db3ab2eecf_2f1d311192c757bb)
  unreachable
bb69:
  br label %bb75
bb70:
  br i1 true, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a)
  unreachable
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_3cc845cddd6e7d45_72b333e08cb265d1)
  unreachable
bb81:
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_ed841b109784c94_6cdd8d327349fd40)
  unreachable
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb88:
  %t218 = load i64, ptr %l16, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l16, !tbaa !24
  br label %bb37
bb89:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = load i64, ptr %l15, !tbaa !24
  %t226 = add i64 %t222, %t223
  store i64 %t226, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb90:
  br label %bb30
bb91:
  call void @__olang_scope_close(ptr %s7)
  br label %bb92
bb92:
  %t228 = load i64, ptr %l10, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l10, !tbaa !24
  br label %bb26
bb93:
  %t232 = load i64, ptr %l7, !tbaa !24
  %t233 = load i64, ptr %l9, !tbaa !24
  %t236 = add i64 %t232, %t233
  store i64 %t236, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb94
bb94:
  br label %bb19
bb95:
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s0, ptr %t238, { i64, ptr } { i64 51, ptr @.d274 })
  br label %bb96
bb96:
  store { i64, ptr } { i64 4, ptr @.d275 }, ptr %l124, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t240, ptr %l125, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l126, !tbaa !24
  %t243 = load i64, ptr %l126, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l127, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l126, !tbaa !24
  %t253 = mul i64 %t252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t254, ptr %l125, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t255 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eoverflows(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %lp28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l35 = alloca { i64, [4 x i64] }
  %l38 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i32
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %l57 = alloca i64
  %l64 = alloca ptr
  %l67 = alloca { i64, [4 x i64] }
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l115 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l161 = alloca i64
  %l171 = alloca { i64, ptr }
  %l176 = alloca i1
  %l181 = alloca i64
  %l188 = alloca { i64, ptr }
  %l190 = alloca i64
  %l194 = alloca i64
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca i64
  %l202 = alloca { i64, ptr }
  %l205 = alloca i1
  %l210 = alloca { i64, ptr }
  %l212 = alloca i64
  %l214 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca i64
  %l228 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l243 = alloca i64
  %l245 = alloca ptr
  %l246 = alloca { i64, ptr }
  %l250 = alloca i64
  %l257 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l262 = alloca i64
  %l264 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l275 = alloca i64
  %l277 = alloca ptr
  %l283 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l304 = alloca i1
  %l307 = alloca i1
  %l310 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l312 = alloca i64
  %l313 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l324 = alloca i64
  %l331 = alloca { i64, ptr }
  %l333 = alloca i64
  %l340 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l342 = alloca i32
  %l344 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l347 = alloca { i64, ptr }
  %l348 = alloca i64
  %l349 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.builder
  %s44room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l3
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t9, %"compiler/mir:Range" %t10, i64 0)
  store { i64, [4 x i64] } %t13, ptr %l35
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l5
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t15, { i64, [4 x i64] } %t16)
  store i32 %t19, ptr %l38
  br label %bb2
bb2:
  %t20 = load i32, ptr %l38, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l41
  br label %bb3
bb3:
  %t26 = load i32, ptr %l41, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l44
  br label %bb4
bb4:
  %t32 = load i32, ptr %l44, !tbaa !23
  store i32 %t32, ptr %l8, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l5
  %t41 = load i32, ptr %l6, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t39, { i64, [4 x i64] } %t40, i32 %t41)
  store { i64, ptr } %t45, ptr %l51
  br label %bb6
bb6:
  %t46 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l54
  br label %bb7
bb7:
  %t52 = load i1, ptr %l54, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l57
  br label %bb8
bb8:
  %t58 = load i64, ptr %l57, !tbaa !24
  store i64 %t58, ptr %l12, !tbaa !24
  %t59 = load i32, ptr %l1
  %t61 = trunc i64 3 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t64 = load i32, ptr %l1
  %t66 = trunc i64 4 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t69 = load i32, ptr %l1
  %t71 = trunc i64 5 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb37
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l64, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/mir:Range", ptr %l3
  %t79 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %t76, i64 1)
  store { i64, [4 x i64] } %t79, ptr %l67
  br label %bb16
bb16:
  %t80 = load i32, ptr %l6, !tbaa !23
  %t81 = load ptr, ptr %l64, !tbaa !29
  %t82 = load { i64, [4 x i64] }, ptr %l67
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t81, { i64, [4 x i64] } %t82, i32 %t80)
  store { i64, ptr } %t84, ptr %l69
  br label %bb17
bb17:
  %t85 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t85, ptr %l13, !tbaa !27
  %t86 = load i32, ptr %l1
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store { i64, ptr } { i64 3, ptr @.d276 }, ptr %l70, !tbaa !27
  br label %bb30
bb21:
  %t91 = load i32, ptr %l1
  %t93 = trunc i64 4 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, ptr } { i64 3, ptr @.d277 }, ptr %l70, !tbaa !27
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store { i64, ptr } { i64 3, ptr @.d278 }, ptr %l70, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_7d1301c542cf69c7_2a1b7d2f181cc69b)
  unreachable
bb30:
  %t96 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t96, ptr %l14, !tbaa !27
  %t97 = load i1, ptr %l11, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 1, ptr @.d279 }, ptr %l76, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 1, ptr @.d280 }, ptr %l76, !tbaa !27
  br label %bb33
bb33:
  %t99 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = extractvalue { i64, ptr } { i64 5, ptr @.d281 }, 1
  %t102 = extractvalue { i64, ptr } { i64 5, ptr @.d281 }, 0
  %t103 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t108 = extractvalue { i64, ptr } %t99, 1
  %t109 = extractvalue { i64, ptr } %t99, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 16, ptr @.d282 }, 1
  %t112 = extractvalue { i64, ptr } { i64 16, ptr @.d282 }, 0
  %t113 = add i64 %t110, %t112
  %t115 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t116 = add i64 %t113, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t101, i64 %t102)
  %t118 = getelementptr i8, ptr %t117, i64 %t102
  call void @olang_textcopy(ptr %t118, ptr %t104, i64 %t105)
  %t119 = getelementptr i8, ptr %t118, i64 %t105
  call void @olang_textcopy(ptr %t119, ptr %t108, i64 %t109)
  %t120 = getelementptr i8, ptr %t119, i64 %t109
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t100)
  %t123 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t117, 1
  store { i64, ptr } %t124, ptr %l15, !tbaa !27
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/emit:fnEm", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = extractvalue { i64, ptr } { i64 2, ptr @.d283 }, 1
  %t136 = extractvalue { i64, ptr } { i64 2, ptr @.d283 }, 0
  %t138 = extractvalue { i64, ptr } %t131, 1
  %t139 = extractvalue { i64, ptr } %t131, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 8, ptr @.d284 }, 1
  %t142 = extractvalue { i64, ptr } { i64 8, ptr @.d284 }, 0
  %t143 = add i64 %t140, %t142
  %t145 = extractvalue { i64, ptr } %t132, 1
  %t146 = extractvalue { i64, ptr } %t132, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d285 }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d285 }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t133, 1
  %t153 = extractvalue { i64, ptr } %t133, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 2, ptr @.d286 }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr @.d286 }, 0
  %t157 = add i64 %t154, %t156
  %t159 = extractvalue { i64, ptr } %t134, 1
  %t160 = extractvalue { i64, ptr } %t134, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d287 }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d287 }, 0
  %t164 = add i64 %t161, %t163
  %t165 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t164)
  call void @olang_textcopy(ptr %t165, ptr %t135, i64 %t136)
  %t166 = getelementptr i8, ptr %t165, i64 %t136
  call void @olang_textcopy(ptr %t166, ptr %t138, i64 %t139)
  %t167 = getelementptr i8, ptr %t166, i64 %t139
  call void @olang_textcopy(ptr %t167, ptr %t141, i64 %t142)
  %t168 = getelementptr i8, ptr %t167, i64 %t142
  call void @olang_textcopy(ptr %t168, ptr %t145, i64 %t146)
  %t169 = getelementptr i8, ptr %t168, i64 %t146
  call void @olang_textcopy(ptr %t169, ptr %t148, i64 %t149)
  %t170 = getelementptr i8, ptr %t169, i64 %t149
  call void @olang_textcopy(ptr %t170, ptr %t152, i64 %t153)
  %t171 = getelementptr i8, ptr %t170, i64 %t153
  call void @olang_textcopy(ptr %t171, ptr %t155, i64 %t156)
  %t172 = getelementptr i8, ptr %t171, i64 %t156
  call void @olang_textcopy(ptr %t172, ptr %t159, i64 %t160)
  %t173 = getelementptr i8, ptr %t172, i64 %t160
  call void @olang_textcopy(ptr %t173, ptr %t162, i64 %t163)
  %t174 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t165, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t129, { i64, ptr } %t130, { i64, ptr } %t182)
  br label %bb34
bb34:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t193 = extractvalue { i64, ptr } { i64 7, ptr @.d288 }, 1
  %t194 = extractvalue { i64, ptr } { i64 7, ptr @.d288 }, 0
  %t196 = extractvalue { i64, ptr } %t187, 1
  %t197 = extractvalue { i64, ptr } %t187, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 8, ptr @.d289 }, 1
  %t200 = extractvalue { i64, ptr } { i64 8, ptr @.d289 }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t188, 1
  %t204 = extractvalue { i64, ptr } %t188, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 1, ptr @.d290 }, 1
  %t207 = extractvalue { i64, ptr } { i64 1, ptr @.d290 }, 0
  %t208 = add i64 %t205, %t207
  %t210 = extractvalue { i64, ptr } %t189, 1
  %t211 = extractvalue { i64, ptr } %t189, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 1, ptr @.d291 }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr @.d291 }, 0
  %t215 = add i64 %t212, %t214
  %t217 = extractvalue { i64, ptr } %t190, 1
  %t218 = extractvalue { i64, ptr } %t190, 0
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 2, ptr @.d292 }, 1
  %t221 = extractvalue { i64, ptr } { i64 2, ptr @.d292 }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t191, 1
  %t225 = extractvalue { i64, ptr } %t191, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d293 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d293 }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t192, 1
  %t232 = extractvalue { i64, ptr } %t192, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 1, ptr @.d294 }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr @.d294 }, 0
  %t236 = add i64 %t233, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t193, i64 %t194)
  %t238 = getelementptr i8, ptr %t237, i64 %t194
  call void @olang_textcopy(ptr %t238, ptr %t196, i64 %t197)
  %t239 = getelementptr i8, ptr %t238, i64 %t197
  call void @olang_textcopy(ptr %t239, ptr %t199, i64 %t200)
  %t240 = getelementptr i8, ptr %t239, i64 %t200
  call void @olang_textcopy(ptr %t240, ptr %t203, i64 %t204)
  %t241 = getelementptr i8, ptr %t240, i64 %t204
  call void @olang_textcopy(ptr %t241, ptr %t206, i64 %t207)
  %t242 = getelementptr i8, ptr %t241, i64 %t207
  call void @olang_textcopy(ptr %t242, ptr %t210, i64 %t211)
  %t243 = getelementptr i8, ptr %t242, i64 %t211
  call void @olang_textcopy(ptr %t243, ptr %t213, i64 %t214)
  %t244 = getelementptr i8, ptr %t243, i64 %t214
  call void @olang_textcopy(ptr %t244, ptr %t217, i64 %t218)
  %t245 = getelementptr i8, ptr %t244, i64 %t218
  call void @olang_textcopy(ptr %t245, ptr %t220, i64 %t221)
  %t246 = getelementptr i8, ptr %t245, i64 %t221
  call void @olang_textcopy(ptr %t246, ptr %t224, i64 %t225)
  %t247 = getelementptr i8, ptr %t246, i64 %t225
  call void @olang_textcopy(ptr %t247, ptr %t227, i64 %t228)
  %t248 = getelementptr i8, ptr %t247, i64 %t228
  call void @olang_textcopy(ptr %t248, ptr %t231, i64 %t232)
  %t249 = getelementptr i8, ptr %t248, i64 %t232
  call void @olang_textcopy(ptr %t249, ptr %t234, i64 %t235)
  %t250 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t237, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t261 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t186, { i64, ptr } %t258)
  store { i64, ptr } %t261, ptr %l98
  br label %bb35
bb35:
  %t262 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t266 = extractvalue { i64, ptr } { i64 15, ptr @.d295 }, 1
  %t267 = extractvalue { i64, ptr } { i64 15, ptr @.d295 }, 0
  %t269 = extractvalue { i64, ptr } %t264, 1
  %t270 = extractvalue { i64, ptr } %t264, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 7, ptr @.d296 }, 1
  %t273 = extractvalue { i64, ptr } { i64 7, ptr @.d296 }, 0
  %t274 = add i64 %t271, %t273
  %t276 = extractvalue { i64, ptr } %t262, 1
  %t277 = extractvalue { i64, ptr } %t262, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 3, ptr @.d297 }, 1
  %t280 = extractvalue { i64, ptr } { i64 3, ptr @.d297 }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t266, i64 %t267)
  %t283 = getelementptr i8, ptr %t282, i64 %t267
  call void @olang_textcopy(ptr %t283, ptr %t269, i64 %t270)
  %t284 = getelementptr i8, ptr %t283, i64 %t270
  call void @olang_textcopy(ptr %t284, ptr %t272, i64 %t273)
  %t285 = getelementptr i8, ptr %t284, i64 %t273
  call void @olang_textcopy(ptr %t285, ptr %t276, i64 %t277)
  %t286 = getelementptr i8, ptr %t285, i64 %t277
  call void @olang_textcopy(ptr %t286, ptr %t279, i64 %t280)
  %t287 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t282, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t298 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t263, { i64, ptr } %t295)
  store { i64, ptr } %t298, ptr %l104
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t299 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t299, ptr %rv
  br label %ret
bb37:
  %t300 = load i32, ptr %l1
  %t302 = trunc i64 6 to i32
  %t303 = icmp eq i32 %t300, %t302
  br i1 %t303, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb55
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t305 = load i1, ptr %l11, !tbaa !21
  br i1 %t305, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr @.d298 }, ptr %l108, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t307, ptr %l109, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l110, !tbaa !24
  %t310 = load i64, ptr %l110, !tbaa !24
  %t311 = mul i64 %t310, 1
  %t312 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t311)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, ptr } %t314, ptr %l111, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = load i64, ptr %l110, !tbaa !24
  %t320 = mul i64 %t319, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t316, ptr %t318, i64 %t320, i1 false)
  %t321 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t321, ptr %l109, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t322 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t322, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l112, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load %"compiler/mir:Range", ptr %l3
  %t328 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t324, %"compiler/mir:Range" %t325, i64 1)
  store { i64, [4 x i64] } %t328, ptr %l115
  br label %bb44
bb44:
  %t329 = load i32, ptr %l6, !tbaa !23
  %t330 = load ptr, ptr %l112, !tbaa !29
  %t331 = load { i64, [4 x i64] }, ptr %l115
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s9, ptr %t330, { i64, [4 x i64] } %t331, i32 %t329)
  store { i64, ptr } %t333, ptr %l117
  br label %bb45
bb45:
  %t334 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t334, ptr %l17, !tbaa !27
  %t335 = load i64, ptr %l12, !tbaa !24
  %t337 = icmp slt i64 %t335, 64
  br i1 %t337, label %bb46, label %bb47
bb46:
  %t339 = load i64, ptr %l12, !tbaa !24
  %t341 = sub i64 %t339, 1
  store i64 %t341, ptr %l122, !tbaa !24
  %t342 = load i64, ptr %l122, !tbaa !24
  %t343 = load i64, ptr %l122, !tbaa !24
  %t344 = shl i64 1, %t343
  %t346 = call i64 @__olang_fmt_i64(ptr null, i64 %t344)
  %t347 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t346)
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t344)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  store { i64, ptr } %t357, ptr %l120, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 20, ptr @.d299 }, ptr %l120, !tbaa !27
  br label %bb48
bb48:
  %t359 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t359, ptr %l18, !tbaa !27
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l126, !tbaa !29
  %t361 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t361, ptr %l127, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t362, ptr %l128, !tbaa !27
  %t363 = load i64, ptr %l12, !tbaa !24
  %t365 = icmp slt i64 %t363, 64
  br i1 %t365, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 1, ptr @.d300 }, ptr %l131, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 0, ptr @.d301 }, ptr %l131, !tbaa !27
  br label %bb51
bb51:
  %t367 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t368 = extractvalue { i64, ptr } { i64 8, ptr @.d302 }, 1
  %t369 = extractvalue { i64, ptr } { i64 8, ptr @.d302 }, 0
  %t370 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 1, ptr @.d303 }, 1
  %t375 = extractvalue { i64, ptr } { i64 1, ptr @.d303 }, 0
  %t376 = add i64 %t373, %t375
  %t377 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 2, ptr @.d304 }, 1
  %t382 = extractvalue { i64, ptr } { i64 2, ptr @.d304 }, 0
  %t383 = add i64 %t380, %t382
  %t384 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t384, 1
  %t386 = extractvalue { i64, ptr } %t384, 0
  %t387 = add i64 %t383, %t386
  %t389 = extractvalue { i64, ptr } %t367, 1
  %t390 = extractvalue { i64, ptr } %t367, 0
  %t391 = add i64 %t387, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t368, i64 %t369)
  %t393 = getelementptr i8, ptr %t392, i64 %t369
  call void @olang_textcopy(ptr %t393, ptr %t371, i64 %t372)
  %t394 = getelementptr i8, ptr %t393, i64 %t372
  call void @olang_textcopy(ptr %t394, ptr %t374, i64 %t375)
  %t395 = getelementptr i8, ptr %t394, i64 %t375
  call void @olang_textcopy(ptr %t395, ptr %t378, i64 %t379)
  %t396 = getelementptr i8, ptr %t395, i64 %t379
  call void @olang_textcopy(ptr %t396, ptr %t381, i64 %t382)
  %t397 = getelementptr i8, ptr %t396, i64 %t382
  call void @olang_textcopy(ptr %t397, ptr %t385, i64 %t386)
  %t398 = getelementptr i8, ptr %t397, i64 %t386
  call void @olang_textcopy(ptr %t398, ptr %t389, i64 %t390)
  %t399 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t392, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  %t408 = load ptr, ptr %l126, !tbaa !29
  %t410 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t408, { i64, ptr } %t407)
  store { i64, ptr } %t410, ptr %l135
  br label %bb52
bb52:
  %t411 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t411, ptr %l19, !tbaa !27
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t415 = extractvalue { i64, ptr } { i64 8, ptr @.d305 }, 1
  %t416 = extractvalue { i64, ptr } { i64 8, ptr @.d305 }, 0
  %t418 = extractvalue { i64, ptr } %t413, 1
  %t419 = extractvalue { i64, ptr } %t413, 0
  %t420 = add i64 %t416, %t419
  %t421 = extractvalue { i64, ptr } { i64 1, ptr @.d306 }, 1
  %t422 = extractvalue { i64, ptr } { i64 1, ptr @.d306 }, 0
  %t423 = add i64 %t420, %t422
  %t425 = extractvalue { i64, ptr } %t414, 1
  %t426 = extractvalue { i64, ptr } %t414, 0
  %t427 = add i64 %t423, %t426
  %t428 = extractvalue { i64, ptr } { i64 4, ptr @.d307 }, 1
  %t429 = extractvalue { i64, ptr } { i64 4, ptr @.d307 }, 0
  %t430 = add i64 %t427, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t415, i64 %t416)
  %t432 = getelementptr i8, ptr %t431, i64 %t416
  call void @olang_textcopy(ptr %t432, ptr %t418, i64 %t419)
  %t433 = getelementptr i8, ptr %t432, i64 %t419
  call void @olang_textcopy(ptr %t433, ptr %t421, i64 %t422)
  %t434 = getelementptr i8, ptr %t433, i64 %t422
  call void @olang_textcopy(ptr %t434, ptr %t425, i64 %t426)
  %t435 = getelementptr i8, ptr %t434, i64 %t426
  call void @olang_textcopy(ptr %t435, ptr %t428, i64 %t429)
  %t436 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t431, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = extractvalue { i64, ptr } %t437, 1
  %t441 = mul i64 %t439, 1
  %t442 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t441)
  call void @llvm.memcpy.p0.p0.i64(ptr %t442, ptr %t440, i64 %t441, i1 false)
  %t443 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  %t447 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t412, { i64, ptr } %t444)
  store { i64, ptr } %t447, ptr %l141
  br label %bb53
bb53:
  %t448 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t452 = extractvalue { i64, ptr } { i64 7, ptr @.d308 }, 1
  %t453 = extractvalue { i64, ptr } { i64 7, ptr @.d308 }, 0
  %t455 = extractvalue { i64, ptr } %t450, 1
  %t456 = extractvalue { i64, ptr } %t450, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 2, ptr @.d309 }, 1
  %t459 = extractvalue { i64, ptr } { i64 2, ptr @.d309 }, 0
  %t460 = add i64 %t457, %t459
  %t462 = extractvalue { i64, ptr } %t448, 1
  %t463 = extractvalue { i64, ptr } %t448, 0
  %t464 = add i64 %t460, %t463
  %t465 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t452, i64 %t453)
  %t466 = getelementptr i8, ptr %t465, i64 %t453
  call void @olang_textcopy(ptr %t466, ptr %t455, i64 %t456)
  %t467 = getelementptr i8, ptr %t466, i64 %t456
  call void @olang_textcopy(ptr %t467, ptr %t458, i64 %t459)
  %t468 = getelementptr i8, ptr %t467, i64 %t459
  call void @olang_textcopy(ptr %t468, ptr %t462, i64 %t463)
  %t469 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t465, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t480 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t449, { i64, ptr } %t477)
  store { i64, ptr } %t480, ptr %l147
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t481 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t481, ptr %rv
  br label %ret
bb55:
  %t482 = load i32, ptr %l1
  %t484 = trunc i64 0 to i32
  %t485 = icmp eq i32 %t482, %t484
  br i1 %t485, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb67
bb58:
  store %olang.scope zeroinitializer, ptr %s15
  %t487 = load i1, ptr %l11, !tbaa !21
  br i1 %t487, label %bb59, label %bb60
bb59:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t492 = extractvalue { i64, ptr } { i64 8, ptr @.d310 }, 1
  %t493 = extractvalue { i64, ptr } { i64 8, ptr @.d310 }, 0
  %t495 = extractvalue { i64, ptr } %t490, 1
  %t496 = extractvalue { i64, ptr } %t490, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 1, ptr @.d311 }, 1
  %t499 = extractvalue { i64, ptr } { i64 1, ptr @.d311 }, 0
  %t500 = add i64 %t497, %t499
  %t502 = extractvalue { i64, ptr } %t491, 1
  %t503 = extractvalue { i64, ptr } %t491, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 3, ptr @.d312 }, 1
  %t506 = extractvalue { i64, ptr } { i64 3, ptr @.d312 }, 0
  %t507 = add i64 %t504, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t492, i64 %t493)
  %t509 = getelementptr i8, ptr %t508, i64 %t493
  call void @olang_textcopy(ptr %t509, ptr %t495, i64 %t496)
  %t510 = getelementptr i8, ptr %t509, i64 %t496
  call void @olang_textcopy(ptr %t510, ptr %t498, i64 %t499)
  %t511 = getelementptr i8, ptr %t510, i64 %t499
  call void @olang_textcopy(ptr %t511, ptr %t502, i64 %t503)
  %t512 = getelementptr i8, ptr %t511, i64 %t503
  call void @olang_textcopy(ptr %t512, ptr %t505, i64 %t506)
  %t513 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t508, 1
  %t516 = extractvalue { i64, ptr } %t514, 0
  %t517 = extractvalue { i64, ptr } %t514, 1
  %t518 = mul i64 %t516, 1
  %t519 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t518)
  call void @llvm.memcpy.p0.p0.i64(ptr %t519, ptr %t517, i64 %t518, i1 false)
  %t520 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  %t524 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t489, { i64, ptr } %t521)
  store { i64, ptr } %t524, ptr %l156
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t525 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t525, ptr %rv
  br label %ret
bb62:
  %t526 = load i64, ptr %l12, !tbaa !24
  %t528 = icmp slt i64 %t526, 64
  br i1 %t528, label %bb63, label %bb64
bb63:
  %t530 = load i64, ptr %l12, !tbaa !24
  %t532 = sub i64 %t530, 1
  store i64 %t532, ptr %l161, !tbaa !24
  %t533 = load i64, ptr %l161, !tbaa !24
  %t534 = load i64, ptr %l161, !tbaa !24
  %t535 = shl i64 1, %t534
  %t537 = call i64 @__olang_fmt_i64(ptr null, i64 %t535)
  %t538 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t537)
  %t539 = call i64 @__olang_fmt_i64(ptr %t538, i64 %t535)
  %t540 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t538, 1
  %t543 = extractvalue { i64, ptr } %t541, 0
  %t544 = extractvalue { i64, ptr } %t541, 1
  %t545 = mul i64 %t543, 1
  %t546 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t545)
  call void @llvm.memcpy.p0.p0.i64(ptr %t546, ptr %t544, i64 %t545, i1 false)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t546, 1
  store { i64, ptr } %t548, ptr %l159, !tbaa !27
  br label %bb65
bb64:
  store { i64, ptr } { i64 19, ptr @.d313 }, ptr %l159, !tbaa !27
  br label %bb65
bb65:
  %t550 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t553 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t555 = extractvalue { i64, ptr } { i64 8, ptr @.d314 }, 1
  %t556 = extractvalue { i64, ptr } { i64 8, ptr @.d314 }, 0
  %t558 = extractvalue { i64, ptr } %t552, 1
  %t559 = extractvalue { i64, ptr } %t552, 0
  %t560 = add i64 %t556, %t559
  %t561 = extractvalue { i64, ptr } { i64 1, ptr @.d315 }, 1
  %t562 = extractvalue { i64, ptr } { i64 1, ptr @.d315 }, 0
  %t563 = add i64 %t560, %t562
  %t565 = extractvalue { i64, ptr } %t553, 1
  %t566 = extractvalue { i64, ptr } %t553, 0
  %t567 = add i64 %t563, %t566
  %t568 = extractvalue { i64, ptr } { i64 3, ptr @.d316 }, 1
  %t569 = extractvalue { i64, ptr } { i64 3, ptr @.d316 }, 0
  %t570 = add i64 %t567, %t569
  %t572 = extractvalue { i64, ptr } %t550, 1
  %t573 = extractvalue { i64, ptr } %t550, 0
  %t574 = add i64 %t570, %t573
  %t575 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t574)
  call void @olang_textcopy(ptr %t575, ptr %t555, i64 %t556)
  %t576 = getelementptr i8, ptr %t575, i64 %t556
  call void @olang_textcopy(ptr %t576, ptr %t558, i64 %t559)
  %t577 = getelementptr i8, ptr %t576, i64 %t559
  call void @olang_textcopy(ptr %t577, ptr %t561, i64 %t562)
  %t578 = getelementptr i8, ptr %t577, i64 %t562
  call void @olang_textcopy(ptr %t578, ptr %t565, i64 %t566)
  %t579 = getelementptr i8, ptr %t578, i64 %t566
  call void @olang_textcopy(ptr %t579, ptr %t568, i64 %t569)
  %t580 = getelementptr i8, ptr %t579, i64 %t569
  call void @olang_textcopy(ptr %t580, ptr %t572, i64 %t573)
  %t581 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t575, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  %t585 = extractvalue { i64, ptr } %t582, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t592 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t551, { i64, ptr } %t589)
  store { i64, ptr } %t592, ptr %l171
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t593 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t593, ptr %rv
  br label %ret
bb67:
  %t594 = load i32, ptr %l1
  %t596 = trunc i64 20 to i32
  %t597 = icmp eq i32 %t594, %t596
  br i1 %t597, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb137
bb70:
  store %olang.scope zeroinitializer, ptr %s20
  %t599 = load ptr, ptr %l4, !tbaa !29
  %t600 = load i32, ptr %l7, !tbaa !23
  %t603 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t599, i32 %t600)
  store i1 %t603, ptr %l176
  br label %bb71
bb71:
  %t604 = load i1, ptr %l176, !tbaa !21
  br i1 %t604, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s21
  %t605 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t607 = extractvalue { i64, ptr } %t605, 1
  %t608 = extractvalue { i64, ptr } %t605, 0
  %t609 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t607, i64 %t608)
  %t610 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t609, 1
  store { i64, ptr } %t611, ptr %l22, !tbaa !27
  %t613 = load ptr, ptr %l4, !tbaa !29
  %t614 = load i32, ptr %l7, !tbaa !23
  %t617 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t613, i32 %t614)
  store i64 %t617, ptr %l181
  br label %bb74
bb73:
  br label %bb116
bb74:
  %t618 = load i64, ptr %l181, !tbaa !24
  %t619 = icmp ne i64 %t618, 64
  br i1 %t619, label %bb75, label %bb76
bb75:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t624 = extractvalue { i64, ptr } { i64 6, ptr @.d317 }, 1
  %t625 = extractvalue { i64, ptr } { i64 6, ptr @.d317 }, 0
  %t627 = extractvalue { i64, ptr } %t622, 1
  %t628 = extractvalue { i64, ptr } %t622, 0
  %t629 = add i64 %t625, %t628
  %t630 = extractvalue { i64, ptr } { i64 1, ptr @.d318 }, 1
  %t631 = extractvalue { i64, ptr } { i64 1, ptr @.d318 }, 0
  %t632 = add i64 %t629, %t631
  %t634 = extractvalue { i64, ptr } %t623, 1
  %t635 = extractvalue { i64, ptr } %t623, 0
  %t636 = add i64 %t632, %t635
  %t637 = extractvalue { i64, ptr } { i64 10, ptr @.d319 }, 1
  %t638 = extractvalue { i64, ptr } { i64 10, ptr @.d319 }, 0
  %t639 = add i64 %t636, %t638
  %t640 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t639)
  call void @olang_textcopy(ptr %t640, ptr %t624, i64 %t625)
  %t641 = getelementptr i8, ptr %t640, i64 %t625
  call void @olang_textcopy(ptr %t641, ptr %t627, i64 %t628)
  %t642 = getelementptr i8, ptr %t641, i64 %t628
  call void @olang_textcopy(ptr %t642, ptr %t630, i64 %t631)
  %t643 = getelementptr i8, ptr %t642, i64 %t631
  call void @olang_textcopy(ptr %t643, ptr %t634, i64 %t635)
  %t644 = getelementptr i8, ptr %t643, i64 %t635
  call void @olang_textcopy(ptr %t644, ptr %t637, i64 %t638)
  %t645 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t640, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = extractvalue { i64, ptr } %t646, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  %t656 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t621, { i64, ptr } %t653)
  store { i64, ptr } %t656, ptr %l188
  br label %bb77
bb76:
  br label %bb81
bb77:
  %t657 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  %t659 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t659, 0
  store i64 %t660, ptr %l190, !tbaa !24
  %t662 = load i64, ptr %l190, !tbaa !24
  %t663 = icmp eq i64 %t658, %t662
  br i1 %t663, label %bb78, label %bb79
bb78:
  %t665 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !27
  %t667 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !27
  %t669 = load i64, ptr %l190, !tbaa !24
  %t670 = mul i64 %t669, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t666, ptr %t668, i64 %t670, i1 false)
  br label %bb80
bb79:
  %t671 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t671, ptr %l22, !tbaa !27
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t672 = load ptr, ptr %l4, !tbaa !29
  %t673 = load i32, ptr %l8, !tbaa !23
  %t676 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t672, i32 %t673)
  store i64 %t676, ptr %l194
  br label %bb82
bb82:
  %t677 = load i64, ptr %l194, !tbaa !24
  store i64 %t677, ptr %l23, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d320 }, ptr %l195, !tbaa !27
  %t678 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t678, ptr %l196, !tbaa !27
  %t679 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 0
  store i64 %t680, ptr %l197, !tbaa !24
  %t681 = load i64, ptr %l197, !tbaa !24
  %t682 = mul i64 %t681, 1
  %t683 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t682)
  %t684 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  store { i64, ptr } %t685, ptr %l198, !tbaa !27
  %t686 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = load i64, ptr %l197, !tbaa !24
  %t691 = mul i64 %t690, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t687, ptr %t689, i64 %t691, i1 false)
  %t692 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t692, ptr %l24, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d321 }, ptr %l199, !tbaa !27
  %t693 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t693, ptr %l200, !tbaa !27
  %t694 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t695 = extractvalue { i64, ptr } %t694, 0
  store i64 %t695, ptr %l201, !tbaa !24
  %t696 = load i64, ptr %l201, !tbaa !24
  %t697 = mul i64 %t696, 1
  %t698 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t697)
  %t699 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t698, 1
  store { i64, ptr } %t700, ptr %l202, !tbaa !27
  %t701 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !27
  %t705 = load i64, ptr %l201, !tbaa !24
  %t706 = mul i64 %t705, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t702, ptr %t704, i64 %t706, i1 false)
  %t707 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t707, ptr %l25, !tbaa !27
  %t708 = load ptr, ptr %l4, !tbaa !29
  %t709 = load i32, ptr %l8, !tbaa !23
  %t712 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t708, i32 %t709)
  store i1 %t712, ptr %l205
  br label %bb83
bb83:
  %t713 = load i1, ptr %l205, !tbaa !21
  br i1 %t713, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s25
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t715 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t716 = extractvalue { i64, ptr } { i64 16, ptr @.d322 }, 1
  %t717 = extractvalue { i64, ptr } { i64 16, ptr @.d322 }, 0
  %t719 = extractvalue { i64, ptr } %t715, 1
  %t720 = extractvalue { i64, ptr } %t715, 0
  %t721 = add i64 %t717, %t720
  %t722 = extractvalue { i64, ptr } { i64 6, ptr @.d323 }, 1
  %t723 = extractvalue { i64, ptr } { i64 6, ptr @.d323 }, 0
  %t724 = add i64 %t721, %t723
  %t725 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t724)
  call void @olang_textcopy(ptr %t725, ptr %t716, i64 %t717)
  %t726 = getelementptr i8, ptr %t725, i64 %t717
  call void @olang_textcopy(ptr %t726, ptr %t719, i64 %t720)
  %t727 = getelementptr i8, ptr %t726, i64 %t720
  call void @olang_textcopy(ptr %t727, ptr %t722, i64 %t723)
  %t728 = insertvalue { i64, ptr } undef, i64 %t724, 0
  %t729 = insertvalue { i64, ptr } %t728, ptr %t725, 1
  %t731 = extractvalue { i64, ptr } %t729, 0
  %t732 = extractvalue { i64, ptr } %t729, 1
  %t733 = mul i64 %t731, 1
  %t734 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t733)
  call void @llvm.memcpy.p0.p0.i64(ptr %t734, ptr %t732, i64 %t733, i1 false)
  %t735 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  %t739 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t714, { i64, ptr } %t736)
  store { i64, ptr } %t739, ptr %l210
  br label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s28
  %t740 = load i64, ptr %l23, !tbaa !24
  %t742 = icmp eq i64 %t740, 64
  br i1 %t742, label %bb95, label %bb96
bb86:
  %t744 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 0
  %t746 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 0
  store i64 %t747, ptr %l212, !tbaa !24
  %t749 = load i64, ptr %l212, !tbaa !24
  %t750 = icmp eq i64 %t745, %t749
  br i1 %t750, label %bb87, label %bb88
bb87:
  %t752 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !27
  %t754 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = load i64, ptr %l212, !tbaa !24
  %t757 = mul i64 %t756, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t753, ptr %t755, i64 %t757, i1 false)
  br label %bb89
bb88:
  %t758 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t758, ptr %l24, !tbaa !27
  br label %bb89
bb89:
  %t759 = load ptr, ptr %l0, !tbaa !29
  store ptr %t759, ptr %l214, !tbaa !29
  %t760 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t760, ptr %l215, !tbaa !27
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t763 = getelementptr %"compiler/emit:fnEm", ptr %t761, i32 0, i32 0
  %t764 = load ptr, ptr %t763, !tbaa !29
  %t765 = load i64, ptr %l23, !tbaa !24
  %t768 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s25, ptr %t764, i64 %t765)
  store { i64, ptr } %t768, ptr %l219
  br label %bb90
bb90:
  %t769 = extractvalue { i64, ptr } { i64 16, ptr @.d324 }, 1
  %t770 = extractvalue { i64, ptr } { i64 16, ptr @.d324 }, 0
  %t771 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t772 = extractvalue { i64, ptr } %t771, 1
  %t773 = extractvalue { i64, ptr } %t771, 0
  %t774 = add i64 %t770, %t773
  %t775 = extractvalue { i64, ptr } { i64 2, ptr @.d325 }, 1
  %t776 = extractvalue { i64, ptr } { i64 2, ptr @.d325 }, 0
  %t777 = add i64 %t774, %t776
  %t778 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t779 = extractvalue { i64, ptr } %t778, 1
  %t780 = extractvalue { i64, ptr } %t778, 0
  %t781 = add i64 %t777, %t780
  %t782 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t781)
  call void @olang_textcopy(ptr %t782, ptr %t769, i64 %t770)
  %t783 = getelementptr i8, ptr %t782, i64 %t770
  call void @olang_textcopy(ptr %t783, ptr %t772, i64 %t773)
  %t784 = getelementptr i8, ptr %t783, i64 %t773
  call void @olang_textcopy(ptr %t784, ptr %t775, i64 %t776)
  %t785 = getelementptr i8, ptr %t784, i64 %t776
  call void @olang_textcopy(ptr %t785, ptr %t779, i64 %t780)
  %t786 = insertvalue { i64, ptr } undef, i64 %t781, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t782, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  %t795 = load ptr, ptr %l214, !tbaa !29
  %t797 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t795, { i64, ptr } %t794)
  store { i64, ptr } %t797, ptr %l222
  br label %bb91
bb91:
  %t798 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 0
  %t800 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t801 = extractvalue { i64, ptr } %t800, 0
  store i64 %t801, ptr %l224, !tbaa !24
  %t803 = load i64, ptr %l224, !tbaa !24
  %t804 = icmp eq i64 %t799, %t803
  br i1 %t804, label %bb92, label %bb93
bb92:
  %t806 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t807 = load ptr, ptr %t806, !tbaa !27
  %t808 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t809 = load ptr, ptr %t808, !tbaa !27
  %t810 = load i64, ptr %l224, !tbaa !24
  %t811 = mul i64 %t810, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t807, ptr %t809, i64 %t811, i1 false)
  br label %bb94
bb93:
  %t812 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t812, ptr %l25, !tbaa !27
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s25)
  br label %bb113
bb95:
  store %olang.scope zeroinitializer, ptr %s29
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l228, !tbaa !29
  %t814 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t814, ptr %l229, !tbaa !27
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/emit:fnEm", ptr %t815, i32 0, i32 0
  %t818 = load ptr, ptr %t817, !tbaa !29
  %t819 = bitcast double 0x3ff0000000000000 to i64
  %t821 = shl i64 63, 52
  %t824 = add i64 %t819, %t821
  %t825 = shl i64 1, 63
  %t828 = or i64 %t824, %t825
  %t831 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s29, ptr %t818, i32 14, i64 %t828)
  store { i64, ptr } %t831, ptr %l238
  br label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s31
  %t832 = load ptr, ptr %l0, !tbaa !29
  store ptr %t832, ptr %l245, !tbaa !29
  %t833 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t833, ptr %l246, !tbaa !27
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t836 = getelementptr %"compiler/emit:fnEm", ptr %t834, i32 0, i32 0
  %t837 = load ptr, ptr %t836, !tbaa !29
  %t838 = load i64, ptr %l23, !tbaa !24
  %t840 = sub i64 %t838, 1
  store i64 %t840, ptr %l250, !tbaa !24
  %t841 = load i64, ptr %l250, !tbaa !24
  %t842 = load i64, ptr %l250, !tbaa !24
  %t843 = shl i64 1, %t842
  %t845 = sitofp i64 %t843 to double
  %t847 = fsub double 0x0000000000000000, %t845
  %t849 = fsub double %t847, 0x3ff0000000000000
  %t851 = bitcast double %t849 to i64
  %t855 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s31, ptr %t837, i32 14, i64 %t851)
  store { i64, ptr } %t855, ptr %l257
  br label %bb102
bb97:
  %t856 = extractvalue { i64, ptr } { i64 16, ptr @.d326 }, 1
  %t857 = extractvalue { i64, ptr } { i64 16, ptr @.d326 }, 0
  %t858 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t859 = extractvalue { i64, ptr } %t858, 1
  %t860 = extractvalue { i64, ptr } %t858, 0
  %t861 = add i64 %t857, %t860
  %t862 = extractvalue { i64, ptr } { i64 2, ptr @.d327 }, 1
  %t863 = extractvalue { i64, ptr } { i64 2, ptr @.d327 }, 0
  %t864 = add i64 %t861, %t863
  %t865 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t866 = extractvalue { i64, ptr } %t865, 1
  %t867 = extractvalue { i64, ptr } %t865, 0
  %t868 = add i64 %t864, %t867
  %t869 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t868)
  call void @olang_textcopy(ptr %t869, ptr %t856, i64 %t857)
  %t870 = getelementptr i8, ptr %t869, i64 %t857
  call void @olang_textcopy(ptr %t870, ptr %t859, i64 %t860)
  %t871 = getelementptr i8, ptr %t870, i64 %t860
  call void @olang_textcopy(ptr %t871, ptr %t862, i64 %t863)
  %t872 = getelementptr i8, ptr %t871, i64 %t863
  call void @olang_textcopy(ptr %t872, ptr %t866, i64 %t867)
  %t873 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t874 = insertvalue { i64, ptr } %t873, ptr %t869, 1
  %t876 = extractvalue { i64, ptr } %t874, 0
  %t877 = extractvalue { i64, ptr } %t874, 1
  %t878 = mul i64 %t876, 1
  %t879 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t878)
  call void @llvm.memcpy.p0.p0.i64(ptr %t879, ptr %t877, i64 %t878, i1 false)
  %t880 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t879, 1
  %t882 = load ptr, ptr %l228, !tbaa !29
  %t884 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t882, { i64, ptr } %t881)
  store { i64, ptr } %t884, ptr %l241
  br label %bb98
bb98:
  %t885 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t885, 0
  %t887 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t888 = extractvalue { i64, ptr } %t887, 0
  store i64 %t888, ptr %l243, !tbaa !24
  %t890 = load i64, ptr %l243, !tbaa !24
  %t891 = icmp eq i64 %t886, %t890
  br i1 %t891, label %bb99, label %bb100
bb99:
  %t893 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t894 = load ptr, ptr %t893, !tbaa !27
  %t895 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t896 = load ptr, ptr %t895, !tbaa !27
  %t897 = load i64, ptr %l243, !tbaa !24
  %t898 = mul i64 %t897, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t894, ptr %t896, i64 %t898, i1 false)
  br label %bb101
bb100:
  %t899 = load { i64, ptr }, ptr %l241, !tbaa !27
  store { i64, ptr } %t899, ptr %l24, !tbaa !27
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s29)
  br label %bb107
bb102:
  %t900 = extractvalue { i64, ptr } { i64 16, ptr @.d328 }, 1
  %t901 = extractvalue { i64, ptr } { i64 16, ptr @.d328 }, 0
  %t902 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t902, 1
  %t904 = extractvalue { i64, ptr } %t902, 0
  %t905 = add i64 %t901, %t904
  %t906 = extractvalue { i64, ptr } { i64 2, ptr @.d329 }, 1
  %t907 = extractvalue { i64, ptr } { i64 2, ptr @.d329 }, 0
  %t908 = add i64 %t905, %t907
  %t909 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t910 = extractvalue { i64, ptr } %t909, 1
  %t911 = extractvalue { i64, ptr } %t909, 0
  %t912 = add i64 %t908, %t911
  %t913 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t912)
  call void @olang_textcopy(ptr %t913, ptr %t900, i64 %t901)
  %t914 = getelementptr i8, ptr %t913, i64 %t901
  call void @olang_textcopy(ptr %t914, ptr %t903, i64 %t904)
  %t915 = getelementptr i8, ptr %t914, i64 %t904
  call void @olang_textcopy(ptr %t915, ptr %t906, i64 %t907)
  %t916 = getelementptr i8, ptr %t915, i64 %t907
  call void @olang_textcopy(ptr %t916, ptr %t910, i64 %t911)
  %t917 = insertvalue { i64, ptr } undef, i64 %t912, 0
  %t918 = insertvalue { i64, ptr } %t917, ptr %t913, 1
  %t920 = extractvalue { i64, ptr } %t918, 0
  %t921 = extractvalue { i64, ptr } %t918, 1
  %t922 = mul i64 %t920, 1
  %t923 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t922)
  call void @llvm.memcpy.p0.p0.i64(ptr %t923, ptr %t921, i64 %t922, i1 false)
  %t924 = insertvalue { i64, ptr } undef, i64 %t920, 0
  %t925 = insertvalue { i64, ptr } %t924, ptr %t923, 1
  %t926 = load ptr, ptr %l245, !tbaa !29
  %t928 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t926, { i64, ptr } %t925)
  store { i64, ptr } %t928, ptr %l260
  br label %bb103
bb103:
  %t929 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t930 = extractvalue { i64, ptr } %t929, 0
  %t931 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t932 = extractvalue { i64, ptr } %t931, 0
  store i64 %t932, ptr %l262, !tbaa !24
  %t934 = load i64, ptr %l262, !tbaa !24
  %t935 = icmp eq i64 %t930, %t934
  br i1 %t935, label %bb104, label %bb105
bb104:
  %t937 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t938 = load ptr, ptr %t937, !tbaa !27
  %t939 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t940 = load ptr, ptr %t939, !tbaa !27
  %t941 = load i64, ptr %l262, !tbaa !24
  %t942 = mul i64 %t941, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t938, ptr %t940, i64 %t942, i1 false)
  br label %bb106
bb105:
  %t943 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t943, ptr %l24, !tbaa !27
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s31)
  br label %bb107
bb107:
  %t944 = load ptr, ptr %l0, !tbaa !29
  store ptr %t944, ptr %l264, !tbaa !29
  %t945 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t945, ptr %l265, !tbaa !27
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/emit:fnEm", ptr %t946, i32 0, i32 0
  %t949 = load ptr, ptr %t948, !tbaa !29
  %t950 = load i64, ptr %l23, !tbaa !24
  %t952 = sub i64 %t950, 1
  %t955 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s28, ptr %t949, i64 %t952)
  store { i64, ptr } %t955, ptr %l270
  br label %bb108
bb108:
  %t956 = extractvalue { i64, ptr } { i64 16, ptr @.d330 }, 1
  %t957 = extractvalue { i64, ptr } { i64 16, ptr @.d330 }, 0
  %t958 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t959 = extractvalue { i64, ptr } %t958, 1
  %t960 = extractvalue { i64, ptr } %t958, 0
  %t961 = add i64 %t957, %t960
  %t962 = extractvalue { i64, ptr } { i64 2, ptr @.d331 }, 1
  %t963 = extractvalue { i64, ptr } { i64 2, ptr @.d331 }, 0
  %t964 = add i64 %t961, %t963
  %t965 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t966 = extractvalue { i64, ptr } %t965, 1
  %t967 = extractvalue { i64, ptr } %t965, 0
  %t968 = add i64 %t964, %t967
  %t969 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t968)
  call void @olang_textcopy(ptr %t969, ptr %t956, i64 %t957)
  %t970 = getelementptr i8, ptr %t969, i64 %t957
  call void @olang_textcopy(ptr %t970, ptr %t959, i64 %t960)
  %t971 = getelementptr i8, ptr %t970, i64 %t960
  call void @olang_textcopy(ptr %t971, ptr %t962, i64 %t963)
  %t972 = getelementptr i8, ptr %t971, i64 %t963
  call void @olang_textcopy(ptr %t972, ptr %t966, i64 %t967)
  %t973 = insertvalue { i64, ptr } undef, i64 %t968, 0
  %t974 = insertvalue { i64, ptr } %t973, ptr %t969, 1
  %t976 = extractvalue { i64, ptr } %t974, 0
  %t977 = extractvalue { i64, ptr } %t974, 1
  %t978 = mul i64 %t976, 1
  %t979 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t978)
  call void @llvm.memcpy.p0.p0.i64(ptr %t979, ptr %t977, i64 %t978, i1 false)
  %t980 = insertvalue { i64, ptr } undef, i64 %t976, 0
  %t981 = insertvalue { i64, ptr } %t980, ptr %t979, 1
  %t982 = load ptr, ptr %l264, !tbaa !29
  %t984 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t982, { i64, ptr } %t981)
  store { i64, ptr } %t984, ptr %l273
  br label %bb109
bb109:
  %t985 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t986 = extractvalue { i64, ptr } %t985, 0
  %t987 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 0
  store i64 %t988, ptr %l275, !tbaa !24
  %t990 = load i64, ptr %l275, !tbaa !24
  %t991 = icmp eq i64 %t986, %t990
  br i1 %t991, label %bb110, label %bb111
bb110:
  %t993 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t994 = load ptr, ptr %t993, !tbaa !27
  %t995 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t996 = load ptr, ptr %t995, !tbaa !27
  %t997 = load i64, ptr %l275, !tbaa !24
  %t998 = mul i64 %t997, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t994, ptr %t996, i64 %t998, i1 false)
  br label %bb112
bb111:
  %t999 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t999, ptr %l25, !tbaa !27
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s28)
  br label %bb113
bb113:
  %t1000 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1000, ptr %l277, !tbaa !29
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1002 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1003 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t1004 = extractvalue { i64, ptr } { i64 7, ptr @.d332 }, 1
  %t1005 = extractvalue { i64, ptr } { i64 7, ptr @.d332 }, 0
  %t1007 = extractvalue { i64, ptr } %t1002, 1
  %t1008 = extractvalue { i64, ptr } %t1002, 0
  %t1009 = add i64 %t1005, %t1008
  %t1010 = extractvalue { i64, ptr } { i64 2, ptr @.d333 }, 1
  %t1011 = extractvalue { i64, ptr } { i64 2, ptr @.d333 }, 0
  %t1012 = add i64 %t1009, %t1011
  %t1014 = extractvalue { i64, ptr } %t1003, 1
  %t1015 = extractvalue { i64, ptr } %t1003, 0
  %t1016 = add i64 %t1012, %t1015
  %t1017 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t1016)
  call void @olang_textcopy(ptr %t1017, ptr %t1004, i64 %t1005)
  %t1018 = getelementptr i8, ptr %t1017, i64 %t1005
  call void @olang_textcopy(ptr %t1018, ptr %t1007, i64 %t1008)
  %t1019 = getelementptr i8, ptr %t1018, i64 %t1008
  call void @olang_textcopy(ptr %t1019, ptr %t1010, i64 %t1011)
  %t1020 = getelementptr i8, ptr %t1019, i64 %t1011
  call void @olang_textcopy(ptr %t1020, ptr %t1014, i64 %t1015)
  %t1021 = insertvalue { i64, ptr } undef, i64 %t1016, 0
  %t1022 = insertvalue { i64, ptr } %t1021, ptr %t1017, 1
  %t1024 = extractvalue { i64, ptr } %t1022, 0
  %t1025 = extractvalue { i64, ptr } %t1022, 1
  %t1026 = mul i64 %t1024, 1
  %t1027 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t1026)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1027, ptr %t1025, i64 %t1026, i1 false)
  %t1028 = insertvalue { i64, ptr } undef, i64 %t1024, 0
  %t1029 = insertvalue { i64, ptr } %t1028, ptr %t1027, 1
  %t1032 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t1001, { i64, ptr } %t1029)
  store { i64, ptr } %t1032, ptr %l283
  br label %bb114
bb114:
  %t1033 = extractvalue { i64, ptr } { i64 7, ptr @.d334 }, 1
  %t1034 = extractvalue { i64, ptr } { i64 7, ptr @.d334 }, 0
  %t1035 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t1036 = extractvalue { i64, ptr } %t1035, 1
  %t1037 = extractvalue { i64, ptr } %t1035, 0
  %t1038 = add i64 %t1034, %t1037
  %t1039 = extractvalue { i64, ptr } { i64 6, ptr @.d335 }, 1
  %t1040 = extractvalue { i64, ptr } { i64 6, ptr @.d335 }, 0
  %t1041 = add i64 %t1038, %t1040
  %t1042 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1041)
  call void @olang_textcopy(ptr %t1042, ptr %t1033, i64 %t1034)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1034
  call void @olang_textcopy(ptr %t1043, ptr %t1036, i64 %t1037)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1037
  call void @olang_textcopy(ptr %t1044, ptr %t1039, i64 %t1040)
  %t1045 = insertvalue { i64, ptr } undef, i64 %t1041, 0
  %t1046 = insertvalue { i64, ptr } %t1045, ptr %t1042, 1
  %t1048 = extractvalue { i64, ptr } %t1046, 0
  %t1049 = extractvalue { i64, ptr } %t1046, 1
  %t1050 = mul i64 %t1048, 1
  %t1051 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1050)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1051, ptr %t1049, i64 %t1050, i1 false)
  %t1052 = insertvalue { i64, ptr } undef, i64 %t1048, 0
  %t1053 = insertvalue { i64, ptr } %t1052, ptr %t1051, 1
  %t1054 = load ptr, ptr %l277, !tbaa !29
  %t1056 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1054, { i64, ptr } %t1053)
  store { i64, ptr } %t1056, ptr %l286
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t1057 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t1057, ptr %rv
  br label %ret
bb116:
  %t1058 = load ptr, ptr %l0, !tbaa !29
  %t1059 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1060 = load i32, ptr %l6, !tbaa !23
  %t1061 = load i32, ptr %l2, !tbaa !23
  %t1066 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %s0, ptr %s20, ptr %t1058, { i64, ptr } %t1059, i32 %t1060, i32 %t1061)
  store { i64, ptr } %t1066, ptr %l291
  br label %bb117
bb117:
  %t1067 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t1067, ptr %l26, !tbaa !27
  %t1068 = load ptr, ptr %l0, !tbaa !29
  %t1069 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1070 = load i32, ptr %l2, !tbaa !23
  %t1071 = load i32, ptr %l6, !tbaa !23
  %t1076 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %s20, ptr %s20, ptr %t1068, { i64, ptr } %t1069, i32 %t1070, i32 %t1071)
  store { i64, ptr } %t1076, ptr %l296
  br label %bb118
bb118:
  %t1077 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1079 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t1081 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1082 = extractvalue { i64, ptr } { i64 8, ptr @.d336 }, 1
  %t1083 = extractvalue { i64, ptr } { i64 8, ptr @.d336 }, 0
  %t1085 = extractvalue { i64, ptr } %t1079, 1
  %t1086 = extractvalue { i64, ptr } %t1079, 0
  %t1087 = add i64 %t1083, %t1086
  %t1088 = extractvalue { i64, ptr } { i64 1, ptr @.d337 }, 1
  %t1089 = extractvalue { i64, ptr } { i64 1, ptr @.d337 }, 0
  %t1090 = add i64 %t1087, %t1089
  %t1092 = extractvalue { i64, ptr } %t1077, 1
  %t1093 = extractvalue { i64, ptr } %t1077, 0
  %t1094 = add i64 %t1090, %t1093
  %t1095 = extractvalue { i64, ptr } { i64 2, ptr @.d338 }, 1
  %t1096 = extractvalue { i64, ptr } { i64 2, ptr @.d338 }, 0
  %t1097 = add i64 %t1094, %t1096
  %t1099 = extractvalue { i64, ptr } %t1081, 1
  %t1100 = extractvalue { i64, ptr } %t1081, 0
  %t1101 = add i64 %t1097, %t1100
  %t1102 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1101)
  call void @olang_textcopy(ptr %t1102, ptr %t1082, i64 %t1083)
  %t1103 = getelementptr i8, ptr %t1102, i64 %t1083
  call void @olang_textcopy(ptr %t1103, ptr %t1085, i64 %t1086)
  %t1104 = getelementptr i8, ptr %t1103, i64 %t1086
  call void @olang_textcopy(ptr %t1104, ptr %t1088, i64 %t1089)
  %t1105 = getelementptr i8, ptr %t1104, i64 %t1089
  call void @olang_textcopy(ptr %t1105, ptr %t1092, i64 %t1093)
  %t1106 = getelementptr i8, ptr %t1105, i64 %t1093
  call void @olang_textcopy(ptr %t1106, ptr %t1095, i64 %t1096)
  %t1107 = getelementptr i8, ptr %t1106, i64 %t1096
  call void @olang_textcopy(ptr %t1107, ptr %t1099, i64 %t1100)
  %t1108 = insertvalue { i64, ptr } undef, i64 %t1101, 0
  %t1109 = insertvalue { i64, ptr } %t1108, ptr %t1102, 1
  %t1111 = extractvalue { i64, ptr } %t1109, 0
  %t1112 = extractvalue { i64, ptr } %t1109, 1
  %t1113 = mul i64 %t1111, 1
  %t1114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1114, ptr %t1112, i64 %t1113, i1 false)
  %t1115 = insertvalue { i64, ptr } undef, i64 %t1111, 0
  %t1116 = insertvalue { i64, ptr } %t1115, ptr %t1114, 1
  %t1119 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1078, { i64, ptr } %t1116)
  store { i64, ptr } %t1119, ptr %l303
  br label %bb119
bb119:
  %t1120 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t1120, ptr %lp28
  %t1121 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t1122 = load ptr, ptr %lp28
  store { i64, ptr } %t1121, ptr %t1122, !tbaa !27
  %t1123 = load i1, ptr %l11, !tbaa !21
  store i1 %t1123, ptr %l304, !tbaa !21
  %t1124 = load ptr, ptr %l4, !tbaa !29
  %t1125 = load i32, ptr %l8, !tbaa !23
  %t1128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t1124, i32 %t1125)
  store i1 %t1128, ptr %l307
  br label %bb120
bb120:
  %t1129 = load i1, ptr %l304, !tbaa !21
  %t1130 = load i1, ptr %l307, !tbaa !21
  %t1131 = icmp eq i1 %t1129, %t1130
  br i1 %t1131, label %bb121, label %bb122
bb121:
  %t1133 = load ptr, ptr %lp28
  %t1134 = load { i64, ptr }, ptr %t1133, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1134, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  store { i64, ptr } { i64 0, ptr @.d339 }, ptr %l310, !tbaa !27
  %t1136 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t1136, ptr %l311, !tbaa !27
  %t1137 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 0
  store i64 %t1138, ptr %l312, !tbaa !24
  %t1139 = load i64, ptr %l312, !tbaa !24
  %t1140 = mul i64 %t1139, 1
  %t1141 = call ptr @__olang_scope_alloc_zeroed(ptr %s20, i64 %t1140)
  %t1142 = insertvalue { i64, ptr } undef, i64 %t1139, 0
  %t1143 = insertvalue { i64, ptr } %t1142, ptr %t1141, 1
  store { i64, ptr } %t1143, ptr %l313, !tbaa !27
  %t1144 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t1145 = load ptr, ptr %t1144, !tbaa !27
  %t1146 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t1147 = load ptr, ptr %t1146, !tbaa !27
  %t1148 = load i64, ptr %l312, !tbaa !24
  %t1149 = mul i64 %t1148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1145, ptr %t1147, i64 %t1149, i1 false)
  %t1150 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t1150, ptr %l29, !tbaa !27
  %t1151 = load i1, ptr %l11, !tbaa !21
  br i1 %t1151, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s38
  %t1153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1153, ptr %l315, !tbaa !29
  %t1154 = load ptr, ptr %l0, !tbaa !29
  %t1155 = load i32, ptr %l8, !tbaa !23
  %t1158 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s38, ptr %t1154, i32 %t1155)
  store { i64, ptr } %t1158, ptr %l318
  br label %bb126
bb125:
  %t1159 = load ptr, ptr %l0, !tbaa !29
  %t1160 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t1161 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t1162 = extractvalue { i64, ptr } { i64 9, ptr @.d340 }, 1
  %t1163 = extractvalue { i64, ptr } { i64 9, ptr @.d340 }, 0
  %t1165 = extractvalue { i64, ptr } %t1160, 1
  %t1166 = extractvalue { i64, ptr } %t1160, 0
  %t1167 = add i64 %t1163, %t1166
  %t1168 = extractvalue { i64, ptr } { i64 1, ptr @.d341 }, 1
  %t1169 = extractvalue { i64, ptr } { i64 1, ptr @.d341 }, 0
  %t1170 = add i64 %t1167, %t1169
  %t1172 = extractvalue { i64, ptr } %t1161, 1
  %t1173 = extractvalue { i64, ptr } %t1161, 0
  %t1174 = add i64 %t1170, %t1173
  %t1175 = extractvalue { i64, ptr } { i64 3, ptr @.d342 }, 1
  %t1176 = extractvalue { i64, ptr } { i64 3, ptr @.d342 }, 0
  %t1177 = add i64 %t1174, %t1176
  %t1178 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1177)
  call void @olang_textcopy(ptr %t1178, ptr %t1162, i64 %t1163)
  %t1179 = getelementptr i8, ptr %t1178, i64 %t1163
  call void @olang_textcopy(ptr %t1179, ptr %t1165, i64 %t1166)
  %t1180 = getelementptr i8, ptr %t1179, i64 %t1166
  call void @olang_textcopy(ptr %t1180, ptr %t1168, i64 %t1169)
  %t1181 = getelementptr i8, ptr %t1180, i64 %t1169
  call void @olang_textcopy(ptr %t1181, ptr %t1172, i64 %t1173)
  %t1182 = getelementptr i8, ptr %t1181, i64 %t1173
  call void @olang_textcopy(ptr %t1182, ptr %t1175, i64 %t1176)
  %t1183 = insertvalue { i64, ptr } undef, i64 %t1177, 0
  %t1184 = insertvalue { i64, ptr } %t1183, ptr %t1178, 1
  %t1186 = extractvalue { i64, ptr } %t1184, 0
  %t1187 = extractvalue { i64, ptr } %t1184, 1
  %t1188 = mul i64 %t1186, 1
  %t1189 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1189, ptr %t1187, i64 %t1188, i1 false)
  %t1190 = insertvalue { i64, ptr } undef, i64 %t1186, 0
  %t1191 = insertvalue { i64, ptr } %t1190, ptr %t1189, 1
  %t1194 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s20, ptr %s20, ptr %t1159, { i64, ptr } %t1191)
  store { i64, ptr } %t1194, ptr %l331
  br label %bb131
bb126:
  %t1195 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1196 = extractvalue { i64, ptr } { i64 9, ptr @.d343 }, 1
  %t1197 = extractvalue { i64, ptr } { i64 9, ptr @.d343 }, 0
  %t1198 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t1199 = extractvalue { i64, ptr } %t1198, 1
  %t1200 = extractvalue { i64, ptr } %t1198, 0
  %t1201 = add i64 %t1197, %t1200
  %t1202 = extractvalue { i64, ptr } { i64 1, ptr @.d344 }, 1
  %t1203 = extractvalue { i64, ptr } { i64 1, ptr @.d344 }, 0
  %t1204 = add i64 %t1201, %t1203
  %t1206 = extractvalue { i64, ptr } %t1195, 1
  %t1207 = extractvalue { i64, ptr } %t1195, 0
  %t1208 = add i64 %t1204, %t1207
  %t1209 = extractvalue { i64, ptr } { i64 3, ptr @.d345 }, 1
  %t1210 = extractvalue { i64, ptr } { i64 3, ptr @.d345 }, 0
  %t1211 = add i64 %t1208, %t1210
  %t1212 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1211)
  call void @olang_textcopy(ptr %t1212, ptr %t1196, i64 %t1197)
  %t1213 = getelementptr i8, ptr %t1212, i64 %t1197
  call void @olang_textcopy(ptr %t1213, ptr %t1199, i64 %t1200)
  %t1214 = getelementptr i8, ptr %t1213, i64 %t1200
  call void @olang_textcopy(ptr %t1214, ptr %t1202, i64 %t1203)
  %t1215 = getelementptr i8, ptr %t1214, i64 %t1203
  call void @olang_textcopy(ptr %t1215, ptr %t1206, i64 %t1207)
  %t1216 = getelementptr i8, ptr %t1215, i64 %t1207
  call void @olang_textcopy(ptr %t1216, ptr %t1209, i64 %t1210)
  %t1217 = insertvalue { i64, ptr } undef, i64 %t1211, 0
  %t1218 = insertvalue { i64, ptr } %t1217, ptr %t1212, 1
  %t1220 = extractvalue { i64, ptr } %t1218, 0
  %t1221 = extractvalue { i64, ptr } %t1218, 1
  %t1222 = mul i64 %t1220, 1
  %t1223 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t1222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1223, ptr %t1221, i64 %t1222, i1 false)
  %t1224 = insertvalue { i64, ptr } undef, i64 %t1220, 0
  %t1225 = insertvalue { i64, ptr } %t1224, ptr %t1223, 1
  %t1226 = load ptr, ptr %l315, !tbaa !29
  %t1228 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s20, ptr %s20, ptr %t1226, { i64, ptr } %t1225)
  store { i64, ptr } %t1228, ptr %l322
  br label %bb127
bb127:
  %t1229 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1230 = extractvalue { i64, ptr } %t1229, 0
  %t1231 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1231, 0
  store i64 %t1232, ptr %l324, !tbaa !24
  %t1234 = load i64, ptr %l324, !tbaa !24
  %t1235 = icmp eq i64 %t1230, %t1234
  br i1 %t1235, label %bb128, label %bb129
bb128:
  %t1237 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1238 = load ptr, ptr %t1237, !tbaa !27
  %t1239 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t1240 = load ptr, ptr %t1239, !tbaa !27
  %t1241 = load i64, ptr %l324, !tbaa !24
  %t1242 = mul i64 %t1241, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1238, ptr %t1240, i64 %t1242, i1 false)
  br label %bb130
bb129:
  %t1243 = load { i64, ptr }, ptr %l322, !tbaa !27
  store { i64, ptr } %t1243, ptr %l29, !tbaa !27
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s38)
  br label %bb135
bb131:
  %t1244 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1245 = extractvalue { i64, ptr } %t1244, 0
  %t1246 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t1247 = extractvalue { i64, ptr } %t1246, 0
  store i64 %t1247, ptr %l333, !tbaa !24
  %t1249 = load i64, ptr %l333, !tbaa !24
  %t1250 = icmp eq i64 %t1245, %t1249
  br i1 %t1250, label %bb132, label %bb133
bb132:
  %t1252 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1253 = load ptr, ptr %t1252, !tbaa !27
  %t1254 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t1255 = load ptr, ptr %t1254, !tbaa !27
  %t1256 = load i64, ptr %l333, !tbaa !24
  %t1257 = mul i64 %t1256, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1253, ptr %t1255, i64 %t1257, i1 false)
  br label %bb134
bb133:
  %t1258 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t1258, ptr %l29, !tbaa !27
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t1259 = load ptr, ptr %l0, !tbaa !29
  %t1260 = load ptr, ptr %lp28
  %t1261 = load { i64, ptr }, ptr %t1260, !tbaa !27
  %t1262 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1263 = extractvalue { i64, ptr } { i64 6, ptr @.d346 }, 1
  %t1264 = extractvalue { i64, ptr } { i64 6, ptr @.d346 }, 0
  %t1266 = extractvalue { i64, ptr } %t1261, 1
  %t1267 = extractvalue { i64, ptr } %t1261, 0
  %t1268 = add i64 %t1264, %t1267
  %t1269 = extractvalue { i64, ptr } { i64 2, ptr @.d347 }, 1
  %t1270 = extractvalue { i64, ptr } { i64 2, ptr @.d347 }, 0
  %t1271 = add i64 %t1268, %t1270
  %t1273 = extractvalue { i64, ptr } %t1262, 1
  %t1274 = extractvalue { i64, ptr } %t1262, 0
  %t1275 = add i64 %t1271, %t1274
  %t1276 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1275)
  call void @olang_textcopy(ptr %t1276, ptr %t1263, i64 %t1264)
  %t1277 = getelementptr i8, ptr %t1276, i64 %t1264
  call void @olang_textcopy(ptr %t1277, ptr %t1266, i64 %t1267)
  %t1278 = getelementptr i8, ptr %t1277, i64 %t1267
  call void @olang_textcopy(ptr %t1278, ptr %t1269, i64 %t1270)
  %t1279 = getelementptr i8, ptr %t1278, i64 %t1270
  call void @olang_textcopy(ptr %t1279, ptr %t1273, i64 %t1274)
  %t1280 = insertvalue { i64, ptr } undef, i64 %t1275, 0
  %t1281 = insertvalue { i64, ptr } %t1280, ptr %t1276, 1
  %t1283 = extractvalue { i64, ptr } %t1281, 0
  %t1284 = extractvalue { i64, ptr } %t1281, 1
  %t1285 = mul i64 %t1283, 1
  %t1286 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1286, ptr %t1284, i64 %t1285, i1 false)
  %t1287 = insertvalue { i64, ptr } undef, i64 %t1283, 0
  %t1288 = insertvalue { i64, ptr } %t1287, ptr %t1286, 1
  %t1291 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t1259, { i64, ptr } %t1288)
  store { i64, ptr } %t1291, ptr %l340
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t1292 = load { i64, ptr }, ptr %l340, !tbaa !27
  store { i64, ptr } %t1292, ptr %rv
  br label %ret
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb143
bb140:
  store %olang.scope zeroinitializer, ptr %s43
  %t1293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1293, ptr %l341, !tbaa !29
  %t1294 = load i32, ptr %l1
  store i32 %t1294, ptr %l342
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s44
  store ptr %s44room, ptr %s44
  %t1295 = extractvalue { i64, ptr } { i64 20, ptr @.d348 }, 1
  %t1296 = extractvalue { i64, ptr } { i64 20, ptr @.d348 }, 0
  call void @__olang_sb_put(ptr %s44, ptr %t1295, i64 %t1296)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s44, ptr %l342, i64 0)
  br label %bb141
bb141:
  %t1298 = load ptr, ptr %s44
  %t1299 = getelementptr %olang.builder, ptr %s44, i32 0, i32 1
  %t1300 = load i64, ptr %t1299
  %t1301 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1300)
  call void @olang_textcopy(ptr %t1301, ptr %t1298, i64 %t1300)
  %t1302 = insertvalue { i64, ptr } undef, i64 %t1300, 0
  %t1303 = insertvalue { i64, ptr } %t1302, ptr %t1301, 1
  store { i64, ptr } %t1303, ptr %l344, !tbaa !27
  %t1304 = getelementptr %olang.builder, ptr %s44, i32 0, i32 3
  %t1305 = load ptr, ptr %t1304
  %t1306 = icmp ne ptr %t1305, null
  br i1 %t1306, label %sbgrew.1307, label %sbdone.1308
sbgrew.1307:
  call void @__olang_sb_done(ptr %s44)
  br label %sbdone.1308
sbdone.1308:
  %t1309 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t1310 = extractvalue { i64, ptr } %t1309, 0
  %t1311 = extractvalue { i64, ptr } %t1309, 1
  %t1312 = mul i64 %t1310, 1
  %t1313 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1313, ptr %t1311, i64 %t1312, i1 false)
  %t1314 = insertvalue { i64, ptr } undef, i64 %t1310, 0
  %t1315 = insertvalue { i64, ptr } %t1314, ptr %t1313, 1
  %t1316 = load ptr, ptr %l341, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s43, ptr %t1316, { i64, ptr } %t1315)
  br label %bb142
bb142:
  store { i64, ptr } { i64 5, ptr @.d349 }, ptr %l346, !tbaa !27
  %t1318 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t1318, ptr %l347, !tbaa !27
  %t1319 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t1320 = extractvalue { i64, ptr } %t1319, 0
  store i64 %t1320, ptr %l348, !tbaa !24
  %t1321 = load i64, ptr %l348, !tbaa !24
  %t1322 = mul i64 %t1321, 1
  %t1323 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1322)
  %t1324 = insertvalue { i64, ptr } undef, i64 %t1321, 0
  %t1325 = insertvalue { i64, ptr } %t1324, ptr %t1323, 1
  store { i64, ptr } %t1325, ptr %l349, !tbaa !27
  %t1326 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t1327 = load ptr, ptr %t1326, !tbaa !27
  %t1328 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t1329 = load ptr, ptr %t1328, !tbaa !27
  %t1330 = load i64, ptr %l348, !tbaa !24
  %t1331 = mul i64 %t1330, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1327, ptr %t1329, i64 %t1331, i1 false)
  %t1332 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t1332, ptr %l347, !tbaa !27
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s0)
  %t1333 = load { i64, ptr }, ptr %l347, !tbaa !27
  store { i64, ptr } %t1333, ptr %rv
  br label %ret
bb143:
  call void @__olang_check_failed(ptr @olang_loc_9185a77390ef7566_ed985a49c11fac9a)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = sext i32 %t10 to i64
  %t16 = icmp eq i64 %t12, %a2
  store i1 %t16, ptr %l4, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b58edc65c6718b49_26c0578031dccca5)
  unreachable
bb9:
  %t18 = load i1, ptr %l4, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Place", ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t9, %"compiler/mir:Place" %t10)
  store i32 %t13, ptr %l19
  br label %bb1
bb1:
  %t14 = load i32, ptr %l19, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t15, i32 %t14)
  store i32 %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t21, i32 %t20)
  store i32 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i32, ptr %l25, !tbaa !23
  store i32 %t26, ptr %l8, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Place", ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Place" %t28)
  store { i64, ptr } %t31, ptr %l28
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l9, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [4 x i64] }, ptr %l2
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t34, { i64, [4 x i64] } %t35, i32 %t36)
  store { i64, ptr } %t40, ptr %l33
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, [4 x i64] }, ptr %l2
  %t52 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t48, { i64, [4 x i64] } %t49)
  store i32 %t52, ptr %l37
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t55 = load i32, ptr %l37, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t53, { i64, ptr } %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l38
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l3
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t59, { i64, [4 x i64] } %t60, i32 %t61)
  store { i64, ptr } %t65, ptr %l43
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, [4 x i64] }, ptr %l3
  %t77 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t73, { i64, [4 x i64] } %t74)
  store i32 %t77, ptr %l47
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = load i32, ptr %l47, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t78, { i64, ptr } %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l48
  br label %bb10
bb10:
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t82, ptr %l11, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l52
  br label %bb11
bb11:
  %t89 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 14, ptr @.d350 }, 1
  %t92 = extractvalue { i64, ptr } { i64 14, ptr @.d350 }, 0
  %t93 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 6, ptr @.d351 }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr @.d351 }, 0
  %t99 = add i64 %t96, %t98
  %t101 = extractvalue { i64, ptr } %t89, 1
  %t102 = extractvalue { i64, ptr } %t89, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 6, ptr @.d352 }, 1
  %t105 = extractvalue { i64, ptr } { i64 6, ptr @.d352 }, 0
  %t106 = add i64 %t103, %t105
  %t108 = extractvalue { i64, ptr } %t90, 1
  %t109 = extractvalue { i64, ptr } %t90, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t91, i64 %t92)
  %t112 = getelementptr i8, ptr %t111, i64 %t92
  call void @olang_textcopy(ptr %t112, ptr %t94, i64 %t95)
  %t113 = getelementptr i8, ptr %t112, i64 %t95
  call void @olang_textcopy(ptr %t113, ptr %t97, i64 %t98)
  %t114 = getelementptr i8, ptr %t113, i64 %t98
  call void @olang_textcopy(ptr %t114, ptr %t101, i64 %t102)
  %t115 = getelementptr i8, ptr %t114, i64 %t102
  call void @olang_textcopy(ptr %t115, ptr %t104, i64 %t105)
  %t116 = getelementptr i8, ptr %t115, i64 %t105
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t111, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l49, !tbaa !29
  %t128 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t126, { i64, ptr } %t125)
  store { i64, ptr } %t128, ptr %l57
  br label %bb12
bb12:
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t129, ptr %lp12
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = load ptr, ptr %lp12
  store { i64, ptr } %t130, ptr %t131, !tbaa !27
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l58, !tbaa !29
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t133, i32 %a4)
  store i32 %t137, ptr %l61
  br label %bb13
bb13:
  %t138 = load ptr, ptr %l58, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb14
bb14:
  %t141 = load i32, ptr %l62, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t142, i32 %t141)
  store i1 %t146, ptr %l65
  br label %bb15
bb15:
  %t147 = load i1, ptr %l65, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb16, label %bb17
bb16:
  %t150 = load ptr, ptr %lp12
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l68, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 8, ptr @.d353 }, 1
  %t158 = extractvalue { i64, ptr } { i64 8, ptr @.d353 }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr @.d354 }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr @.d354 }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t156, 1
  %t168 = extractvalue { i64, ptr } %t156, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t157, i64 %t158)
  %t171 = getelementptr i8, ptr %t170, i64 %t158
  call void @olang_textcopy(ptr %t171, ptr %t160, i64 %t161)
  %t172 = getelementptr i8, ptr %t171, i64 %t161
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t167, i64 %t168)
  %t174 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t170, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t154, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l74
  br label %bb19
bb19:
  %t186 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %lp12
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t195 = load ptr, ptr %l68, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t195, { i64, ptr } %t192, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l77
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sle i64 %t6, 65536
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %t10, i32 %t11)
  store { i64, ptr } %t14, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l8, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v1, ptr %t27, { i64, ptr } %t28, i64 %t29)
  store { i64, ptr } %t30, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %t32)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l20
  br label %bb9
bb9:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t40, { i64, ptr } { i64 2, ptr @.d355 })
  store { i64, ptr } %t42, ptr %l22
  br label %bb10
bb10:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d356 }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr @.d356 }, 0
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t53, ptr %lp3
  %t55 = load ptr, ptr %lp3
  store { i64, ptr } %t52, ptr %t55, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/emit:fnEm", ptr %t56, i32 0, i32 4
  store ptr %t58, ptr %l25, !tbaa !29
  %t59 = load ptr, ptr %lp3
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l26, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l29
  br label %bb11
bb11:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = icmp sgt i64 %t66, 8
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l32, !tbaa !24
  br label %bb14
bb13:
  store i64 8, ptr %l32, !tbaa !24
  br label %bb14
bb14:
  %t72 = extractvalue { i64, ptr } { i64 2, ptr @.d357 }, 1
  %t73 = extractvalue { i64, ptr } { i64 2, ptr @.d357 }, 0
  %t74 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 49, ptr @.d358 }, 1
  %t79 = extractvalue { i64, ptr } { i64 49, ptr @.d358 }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l29, !tbaa !24
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t83 = add i64 %t80, %t82
  %t84 = extractvalue { i64, ptr } { i64 6, ptr @.d359 }, 1
  %t85 = extractvalue { i64, ptr } { i64 6, ptr @.d359 }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load i64, ptr %l32, !tbaa !24
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr @.d360 }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr @.d360 }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t72, i64 %t73)
  %t94 = getelementptr i8, ptr %t93, i64 %t73
  call void @olang_textcopy(ptr %t94, ptr %t75, i64 %t76)
  %t95 = getelementptr i8, ptr %t94, i64 %t76
  call void @olang_textcopy(ptr %t95, ptr %t78, i64 %t79)
  %t96 = getelementptr i8, ptr %t95, i64 %t79
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t81)
  %t98 = getelementptr i8, ptr %t96, i64 %t82
  call void @olang_textcopy(ptr %t98, ptr %t84, i64 %t85)
  %t99 = getelementptr i8, ptr %t98, i64 %t85
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t87)
  %t101 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t101, ptr %t90, i64 %t91)
  %t102 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t93, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t111, { i64, ptr } %t110)
  br label %bb15
bb15:
  %t113 = load ptr, ptr %lp3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Task" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/mir:Task"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, [7 x i64] }
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca { { i64, ptr }, i32 }
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca { i64, [1 x i64] }
  %l58 = alloca { i64, ptr }
  %l59 = alloca %"std/prelude/text:StringBuilder"
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i64
  %l138 = alloca i32
  %l142 = alloca { i64, ptr }
  %l144 = alloca i64
  %l151 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l156 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l167 = alloca i64
  %l170 = alloca i64
  %l188 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l208 = alloca { i64, [4 x i64] }
  %l209 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l216 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l221 = alloca i32
  %l224 = alloca i32
  %l250 = alloca { i64, [1 x i64] }
  %l256 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l277 = alloca i32
  %l280 = alloca i32
  %l299 = alloca ptr
  %l308 = alloca %"compiler/mir:Place"
  %l309 = alloca { { i64, ptr }, i32 }
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l312 = alloca { i64, ptr }
  %l323 = alloca i32
  %l326 = alloca i32
  %l352 = alloca %"compiler/mir:TaskClause"
  %l358 = alloca ptr
  %l359 = alloca ptr
  %l360 = alloca { i64, [4 x i64] }
  %l363 = alloca i32
  %l364 = alloca { i64, ptr }
  %l369 = alloca i64
  %l377 = alloca i32
  %l380 = alloca i32
  %l406 = alloca { i64, [1 x i64] }
  %l411 = alloca i32
  %l413 = alloca i64
  %l417 = alloca ptr
  %l420 = alloca { i64, ptr }
  %l423 = alloca { i64, ptr }
  %l428 = alloca i32
  %l430 = alloca i64
  %l438 = alloca %"std/prelude/text:StringBuilder"
  %l441 = alloca i64
  %l445 = alloca i64
  %l448 = alloca i64
  %l469 = alloca ptr
  %l472 = alloca { i64, ptr }
  %l476 = alloca i64
  %l481 = alloca { i64, ptr }
  %l483 = alloca ptr
  %l488 = alloca { i64, ptr }
  %l491 = alloca { i64, ptr }
  %l497 = alloca { i64, ptr }
  %l499 = alloca i64
  %l501 = alloca i64
  %l505 = alloca i64
  %l508 = alloca i64
  %l532 = alloca { i64, ptr }
  %l535 = alloca { i64, ptr }
  %l536 = alloca i1
  %l537 = alloca ptr
  %l538 = alloca { i64, ptr }
  %l539 = alloca { i64, ptr }
  %l543 = alloca i32
  %l549 = alloca { i64, [4 x i64] }
  %l550 = alloca ptr
  %l553 = alloca { i64, ptr }
  %l556 = alloca { i64, ptr }
  %l564 = alloca { i64, ptr }
  %l565 = alloca { i64, ptr }
  %l566 = alloca { i64, ptr }
  %l567 = alloca i64
  %l568 = alloca { i64, ptr }
  %l570 = alloca { i64, ptr }
  %l573 = alloca { i64, ptr }
  %l574 = alloca i32
  %l583 = alloca { i64, ptr }
  %l590 = alloca { i64, ptr }
  %l594 = alloca ptr
  %l595 = alloca { i64, ptr }
  %l600 = alloca { i64, ptr }
  %l602 = alloca { i64, ptr }
  %l604 = alloca i64
  %l606 = alloca i64
  %l607 = alloca { i64, ptr }
  %l613 = alloca ptr
  %l614 = alloca { i64, ptr }
  %l619 = alloca { i64, ptr }
  %l621 = alloca ptr
  %l626 = alloca { i64, ptr }
  %l628 = alloca ptr
  %l633 = alloca { i64, ptr }
  %l635 = alloca ptr
  %l636 = alloca { i64, ptr }
  %l637 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l638 = alloca i1
  %l639 = alloca { i64, ptr }
  %l640 = alloca i32
  %l642 = alloca i64
  %l643 = alloca %"compiler/mir:Task"
  %l649 = alloca %"compiler/mir:ScopeInfo"
  %l652 = alloca { i64, ptr }
  %l656 = alloca { i64, ptr }
  %l664 = alloca ptr
  %l669 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %t731 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/mir:Task" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = extractvalue { i64, ptr } { i64 2, ptr @.d361 }, 1
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d361 }, 0
  %t18 = sext i32 %t14 to i64
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = getelementptr i8, ptr %t21, i64 %t16
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t18)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  store { i64, ptr } { i64 0, ptr @.d362 }, ptr %l96, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t29, ptr %l97, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l98, !tbaa !24
  %t32 = load i64, ptr %l98, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l99, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l98, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i1 false, ptr %l8, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d363 }, ptr %l100, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t44, ptr %l101, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l102, !tbaa !24
  %t47 = load i64, ptr %l102, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l103, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l102, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t58, ptr %l9, !tbaa !27
  %t59 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 0
  %t60 = load { i64, [7 x i64] }, ptr %t59
  store { i64, [7 x i64] } %t60, ptr %l10
  %t62 = load { i64, [7 x i64] }, ptr %l10
  %t64 = extractvalue { i64, [7 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb1, label %bb2
bb1:
  %t67 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t68 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t67, i32 0, i32 0
  %t69 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t69, ptr %l11
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t72 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l12, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t76 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t75, { i64, [2 x i64] } %t76)
  br label %bb4
bb4:
  %t79 = load i32, ptr %l12, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t82 = load { i64, [2 x i64] }, ptr %l11
  %t85 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s2, ptr %t81, { i64, [2 x i64] } %t82)
  store { i64, ptr } %t85, ptr %l114
  br label %bb5
bb5:
  %t86 = extractvalue { i64, ptr } { i64 1, ptr @.d364 }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d364 }, 0
  %t88 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t86, i64 %t87)
  %t93 = getelementptr i8, ptr %t92, i64 %t87
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l115, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l117, !tbaa !24
  %t101 = load i64, ptr %l117, !tbaa !24
  %t102 = icmp eq i64 %t97, %t101
  br i1 %t102, label %bb6, label %bb7
bb6:
  %t104 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l117, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  br label %bb8
bb7:
  %t110 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t110, ptr %l7, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  %t111 = load { i64, [7 x i64] }, ptr %l10
  %t113 = extractvalue { i64, [7 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 1
  br i1 %t114, label %bb10, label %bb11
bb10:
  %t116 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t117 = getelementptr { i64, i32 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l13, !tbaa !24
  %t120 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t121 = getelementptr { i64, i32 }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l14, !tbaa !23
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load i32, ptr %l14, !tbaa !23
  store i32 %t124, ptr %l6, !tbaa !23
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i32, ptr %l14, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %s4, ptr %t126, i64 %t127, i32 %t128)
  store { i64, ptr } %t132, ptr %l127
  br label %bb13
bb13:
  %t133 = extractvalue { i64, ptr } { i64 1, ptr @.d365 }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d365 }, 0
  %t135 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  store { i64, ptr } %t142, ptr %l128, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  %t145 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l130, !tbaa !24
  %t148 = load i64, ptr %l130, !tbaa !24
  %t149 = icmp eq i64 %t144, %t148
  br i1 %t149, label %bb14, label %bb15
bb14:
  %t151 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l130, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  br label %bb16
bb15:
  %t157 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  br label %bb16
bb16:
  %t158 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %t158, { i64, ptr } { i64 24, ptr @.d366 })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb18:
  %t160 = load { i64, [7 x i64] }, ptr %l10
  %t162 = extractvalue { i64, [7 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 2
  br i1 %t163, label %bb19, label %bb20
bb19:
  %t165 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t166 = getelementptr { { i64, [4 x i64] } }, ptr %t165, i32 0, i32 0
  %t167 = load { i64, [4 x i64] }, ptr %t166
  store { i64, [4 x i64] } %t167, ptr %l15
  br label %bb21
bb20:
  br label %bb27
bb21:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, [4 x i64] }, ptr %l15
  %t173 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t169, { i64, [4 x i64] } %t170)
  store i32 %t173, ptr %l138
  br label %bb22
bb22:
  %t174 = load i32, ptr %l138, !tbaa !23
  store i32 %t174, ptr %l6, !tbaa !23
  store i1 true, ptr %l8, !tbaa !21
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, [4 x i64] }, ptr %l15
  %t177 = load i32, ptr %l6, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t175, { i64, [4 x i64] } %t176, i32 %t177)
  store { i64, ptr } %t181, ptr %l142
  br label %bb23
bb23:
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l144, !tbaa !24
  %t187 = load i64, ptr %l144, !tbaa !24
  %t188 = icmp eq i64 %t183, %t187
  br i1 %t188, label %bb24, label %bb25
bb24:
  %t190 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l144, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  br label %bb26
bb25:
  %t196 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t196, ptr %l9, !tbaa !27
  br label %bb26
bb26:
  br label %bb33
bb27:
  %t197 = load { i64, [7 x i64] }, ptr %l10
  %t199 = extractvalue { i64, [7 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 3
  br i1 %t200, label %bb28, label %bb29
bb28:
  %t202 = getelementptr { i64, [7 x i64] }, ptr %l10, i32 0, i32 1
  %t203 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t202, i32 0, i32 2
  %t204 = load i32, ptr %t203
  store i32 %t204, ptr %l16, !tbaa !23
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load i32, ptr %l16, !tbaa !23
  store i32 %t206, ptr %l6, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s7, ptr %t208, { i64, ptr } { i64 29, ptr @.d367 })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b)
  unreachable
bb33:
  %t210 = load ptr, ptr %l3, !tbaa !29
  store ptr %t210, ptr %l151, !tbaa !29
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t212 = load i32, ptr %l6, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l154
  br label %bb34
bb34:
  %t216 = load ptr, ptr %l151, !tbaa !29
  %t217 = load i32, ptr %l154, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t216, i32 %t217)
  store { i64, ptr } %t218, ptr %l155
  br label %bb35
bb35:
  %t219 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t219, ptr %l17, !tbaa !27
  %t220 = load ptr, ptr @__olang_prog_scope
  %t221 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t220)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t221, ptr %l156
  br label %bb36
bb36:
  %t222 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l156
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l18
  %t223 = load ptr, ptr @__olang_prog_scope
  %t224 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t223)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l157
  br label %bb37
bb37:
  %t225 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %l19
  %t226 = load i1, ptr %l8, !tbaa !21
  br i1 %t226, label %bb38, label %bb39
bb38:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 12, ptr @.d368 })
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t229 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t229)
  br label %bb41
bb41:
  br label %bb42
bb42:
  store i64 0, ptr %l20, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  store i64 %t234, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t236 = load i64, ptr %l21, !tbaa !24
  %t237 = load i64, ptr %l20, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb43, label %bb44
bb43:
  %t242 = load i64, ptr %l22, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb48
bb45:
  %t246 = load i64, ptr %l21, !tbaa !24
  %t247 = load i64, ptr %l20, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l22, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l170, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb47
bb47:
  %t262 = load i64, ptr %l170, !tbaa !24
  store i64 %t262, ptr %l167, !tbaa !24
  br label %bb48
bb48:
  %t263 = load i64, ptr %l167, !tbaa !24
  store i64 %t263, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t264 = load i64, ptr %l24, !tbaa !24
  %t265 = load i64, ptr %l23, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t272 = load i64, ptr %l20, !tbaa !24
  %t273 = load i64, ptr %l24, !tbaa !24
  %t274 = load i64, ptr %l22, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l25, !tbaa !24
  store ptr %l18, ptr %l188, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t283, ptr %l190, !tbaa !27
  %t284 = load i64, ptr %l25, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i32, ptr %t287, i64 %t284
  %t289 = load i32, ptr %t288, !tbaa !33
  %t292 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t282, i32 %t289)
  store { i64, ptr } %t292, ptr %l193
  br label %bb53
bb53:
  %t293 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  %t295 = extractvalue { i64, ptr } %t293, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t300 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t300, { i64, ptr } %t299)
  br label %bb54
bb54:
  store ptr %l19, ptr %l195, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t303, ptr %l197, !tbaa !27
  %t304 = load i64, ptr %l25, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i32, ptr %t307, i64 %t304
  %t309 = load i32, ptr %t308, !tbaa !33
  %t312 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t302, i32 %t309)
  store i1 %t312, ptr %l200
  br label %bb55
bb55:
  %t313 = load i1, ptr %l200, !tbaa !21
  br i1 %t313, label %bb56, label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr @.d369 }, ptr %l202, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t314, ptr %l201, !tbaa !27
  br label %bb60
bb57:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l204, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t319 = load %"compiler/mir:Range", ptr %t318
  %t320 = load i64, ptr %l25, !tbaa !24
  %t324 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t317, %"compiler/mir:Range" %t319, i64 %t320)
  store { i64, [4 x i64] } %t324, ptr %l208
  br label %bb58
bb58:
  %t325 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t325, ptr %l209, !tbaa !27
  %t326 = load i64, ptr %l25, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i32, ptr %t329, i64 %t326
  %t331 = load i32, ptr %t330, !tbaa !33
  %t332 = load ptr, ptr %l204, !tbaa !29
  %t333 = load { i64, [4 x i64] }, ptr %l208
  %t335 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t332, { i64, [4 x i64] } %t333, i32 %t331)
  store { i64, ptr } %t335, ptr %l212
  br label %bb59
bb59:
  %t336 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t336, ptr %l201, !tbaa !27
  br label %bb60
bb60:
  %t337 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 0
  %t339 = extractvalue { i64, ptr } %t337, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t344 = load ptr, ptr %l195, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t344, { i64, ptr } %t343)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb62
bb62:
  %t346 = load i64, ptr %l24, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l24, !tbaa !24
  br label %bb49
bb63:
  %t350 = load ptr, ptr @__olang_prog_scope
  %t351 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t350)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %l216
  br label %bb64
bb64:
  %t352 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l216
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t352, ptr %l26
  store i32 0, ptr %l27, !tbaa !23
  %t353 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t354 = getelementptr %"compiler/mir:Range", ptr %t353, i32 0, i32 1
  %t355 = load i32, ptr %t354, !tbaa !23
  store i32 %t355, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t357 = load i32, ptr %l28, !tbaa !23
  %t358 = load i32, ptr %l27, !tbaa !23
  %t361 = icmp sgt i32 %t357, %t358
  br i1 %t361, label %bb65, label %bb66
bb65:
  %t363 = load i32, ptr %l29, !tbaa !23
  %t365 = icmp sgt i32 %t363, 0
  br i1 %t365, label %bb67, label %bb68
bb66:
  store i32 0, ptr %l221, !tbaa !23
  br label %bb70
bb67:
  %t367 = load i32, ptr %l28, !tbaa !23
  %t368 = load i32, ptr %l27, !tbaa !23
  %t371 = sub i32 %t367, %t368
  %t372 = load i32, ptr %l29, !tbaa !23
  %t375 = add i32 %t371, %t372
  %t377 = sub i32 %t375, 1
  %t378 = load i32, ptr %l29, !tbaa !23
  %t381 = sdiv i32 %t377, %t378
  store i32 %t381, ptr %l224, !tbaa !23
  br label %bb69
bb68:
  store i32 0, ptr %l224, !tbaa !23
  br label %bb69
bb69:
  %t383 = load i32, ptr %l224, !tbaa !23
  store i32 %t383, ptr %l221, !tbaa !23
  br label %bb70
bb70:
  %t384 = load i32, ptr %l221, !tbaa !23
  store i32 %t384, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t385 = load i32, ptr %l31, !tbaa !23
  %t386 = load i32, ptr %l30, !tbaa !23
  %t389 = icmp slt i32 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s13)
  br label %bb93
bb73:
  br label %bb74
bb74:
  %t393 = load i32, ptr %l27, !tbaa !23
  %t394 = load i32, ptr %l31, !tbaa !23
  %t395 = load i32, ptr %l29, !tbaa !23
  %t398 = mul i32 %t394, %t395
  %t401 = add i32 %t393, %t398
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/emit:fnEm", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/mir:Fn", ptr %t406, i32 0, i32 12
  %t409 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t410 = getelementptr %"compiler/mir:Range", ptr %t409, i32 0, i32 0
  %t411 = load i32, ptr %t410, !tbaa !23
  %t413 = sext i32 %t411 to i64
  %t416 = sext i32 %t401 to i64
  %t419 = add i64 %t413, %t416
  %t422 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t408, i64 %t419)
  store { i64, [1 x i64] } %t422, ptr %l250
  br label %bb75
bb75:
  %t423 = load { i64, [1 x i64] }, ptr %l250
  store { i64, [1 x i64] } %t423, ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr @.d370 })
  br label %bb76
bb76:
  %t425 = load { i64, [1 x i64] }, ptr %l33
  %t427 = extractvalue { i64, [1 x i64] } %t425, 0
  %t428 = icmp eq i64 %t427, 2
  br i1 %t428, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb81
bb79:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 4, ptr @.d371 })
  br label %bb80
bb80:
  br label %bb91
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb90
bb84:
  store %olang.scope zeroinitializer, ptr %s15
  %t431 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s15, ptr %s15, ptr %t431, { i64, ptr } { i64 15, ptr @.d372 }, { i64, ptr } { i64 25, ptr @.d373 })
  br label %bb85
bb85:
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l256, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load { i64, [1 x i64] }, ptr %l33
  %t438 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s15, ptr %t434, { i64, [1 x i64] } %t435)
  store { i64, ptr } %t438, ptr %l259
  br label %bb86
bb86:
  %t439 = extractvalue { i64, ptr } { i64 30, ptr @.d374 }, 1
  %t440 = extractvalue { i64, ptr } { i64 30, ptr @.d374 }, 0
  %t441 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 1, ptr @.d375 }, 1
  %t446 = extractvalue { i64, ptr } { i64 1, ptr @.d375 }, 0
  %t447 = add i64 %t444, %t446
  %t448 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t447)
  call void @olang_textcopy(ptr %t448, ptr %t439, i64 %t440)
  %t449 = getelementptr i8, ptr %t448, i64 %t440
  call void @olang_textcopy(ptr %t449, ptr %t442, i64 %t443)
  %t450 = getelementptr i8, ptr %t449, i64 %t443
  call void @olang_textcopy(ptr %t450, ptr %t445, i64 %t446)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t448, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } %t452, 1
  %t456 = mul i64 %t454, 1
  %t457 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t457, ptr %t455, i64 %t456, i1 false)
  %t458 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  %t460 = load ptr, ptr %l256, !tbaa !29
  %t462 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t460, { i64, ptr } %t459)
  store { i64, ptr } %t462, ptr %l262
  br label %bb87
bb87:
  %t463 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t463, ptr %l34, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t464, 1
  %t467 = extractvalue { i64, ptr } %t464, 0
  %t468 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t466, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } %t477)
  br label %bb88
bb88:
  %t480 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 1
  %t483 = extractvalue { i64, ptr } %t480, 0
  %t484 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t483)
  call void @olang_textcopy(ptr %t484, ptr %t482, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t493)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s15)
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_a90a878cc09c574e_a9a55cce621e609a)
  unreachable
bb91:
  call void @__olang_scope_close(ptr %s13)
  br label %bb92
bb92:
  %t496 = load i32, ptr %l31, !tbaa !23
  %t498 = add i32 %t496, 1
  store i32 %t498, ptr %l31, !tbaa !23
  br label %bb71
bb93:
  store i32 0, ptr %l35, !tbaa !23
  %t500 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t501 = getelementptr %"compiler/mir:Range", ptr %t500, i32 0, i32 1
  %t502 = load i32, ptr %t501, !tbaa !23
  store i32 %t502, ptr %l36, !tbaa !23
  store i32 1, ptr %l37, !tbaa !23
  %t504 = load i32, ptr %l36, !tbaa !23
  %t505 = load i32, ptr %l35, !tbaa !23
  %t508 = icmp sgt i32 %t504, %t505
  br i1 %t508, label %bb94, label %bb95
bb94:
  %t510 = load i32, ptr %l37, !tbaa !23
  %t512 = icmp sgt i32 %t510, 0
  br i1 %t512, label %bb96, label %bb97
bb95:
  store i32 0, ptr %l277, !tbaa !23
  br label %bb99
bb96:
  %t514 = load i32, ptr %l36, !tbaa !23
  %t515 = load i32, ptr %l35, !tbaa !23
  %t518 = sub i32 %t514, %t515
  %t519 = load i32, ptr %l37, !tbaa !23
  %t522 = add i32 %t518, %t519
  %t524 = sub i32 %t522, 1
  %t525 = load i32, ptr %l37, !tbaa !23
  %t528 = sdiv i32 %t524, %t525
  store i32 %t528, ptr %l280, !tbaa !23
  br label %bb98
bb97:
  store i32 0, ptr %l280, !tbaa !23
  br label %bb98
bb98:
  %t530 = load i32, ptr %l280, !tbaa !23
  store i32 %t530, ptr %l277, !tbaa !23
  br label %bb99
bb99:
  %t531 = load i32, ptr %l277, !tbaa !23
  store i32 %t531, ptr %l38, !tbaa !23
  store i32 0, ptr %l39, !tbaa !23
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s21
  %t532 = load i32, ptr %l39, !tbaa !23
  %t533 = load i32, ptr %l38, !tbaa !23
  %t536 = icmp slt i32 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s21)
  br label %bb109
bb102:
  br label %bb103
bb103:
  %t540 = load i32, ptr %l35, !tbaa !23
  %t541 = load i32, ptr %l39, !tbaa !23
  %t542 = load i32, ptr %l37, !tbaa !23
  %t545 = mul i32 %t541, %t542
  %t548 = add i32 %t540, %t545
  store i32 %t548, ptr %l40, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr @.d376 })
  br label %bb104
bb104:
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l299, !tbaa !29
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/emit:fnEm", ptr %t552, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !29
  %t557 = getelementptr %"compiler/mir:Fn", ptr %t555, i32 0, i32 13
  %t558 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t559 = getelementptr %"compiler/mir:Range", ptr %t558, i32 0, i32 0
  %t560 = load i32, ptr %t559, !tbaa !23
  %t562 = sext i32 %t560 to i64
  %t563 = load i32, ptr %l40, !tbaa !23
  %t565 = sext i32 %t563 to i64
  %t568 = add i64 %t562, %t565
  %t571 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t557, i64 %t568)
  store %"compiler/mir:Place" %t571, ptr %l308
  br label %bb105
bb105:
  %t572 = load ptr, ptr %l299, !tbaa !29
  %t573 = load %"compiler/mir:Place", ptr %l308
  %t574 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s21, ptr %t572, %"compiler/mir:Place" %t573)
  store { { i64, ptr }, i32 } %t574, ptr %l309
  br label %bb106
bb106:
  %t575 = load { { i64, ptr }, i32 }, ptr %l309
  store { { i64, ptr }, i32 } %t575, ptr %l41
  %t576 = getelementptr { { i64, ptr }, i32 }, ptr %l41, i32 0, i32 0
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  store { i64, ptr } %t577, ptr %l310, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 0
  store i64 %t579, ptr %l311, !tbaa !24
  %t580 = load i64, ptr %l311, !tbaa !24
  %t581 = mul i64 %t580, 1
  %t582 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t581)
  %t583 = insertvalue { i64, ptr } undef, i64 %t580, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  store { i64, ptr } %t584, ptr %l312, !tbaa !27
  %t585 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = load i64, ptr %l311, !tbaa !24
  %t590 = mul i64 %t589, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t586, ptr %t588, i64 %t590, i1 false)
  %t591 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t591, 1
  %t595 = extractvalue { i64, ptr } %t591, 0
  %t596 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t595)
  call void @olang_textcopy(ptr %t596, ptr %t594, i64 %t595)
  %t597 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t596, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } %t598, 1
  %t602 = mul i64 %t600, 1
  %t603 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t602)
  call void @llvm.memcpy.p0.p0.i64(ptr %t603, ptr %t601, i64 %t602, i1 false)
  %t604 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t603, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t605)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s21)
  br label %bb108
bb108:
  %t608 = load i32, ptr %l39, !tbaa !23
  %t610 = add i32 %t608, 1
  store i32 %t610, ptr %l39, !tbaa !23
  br label %bb100
bb109:
  store i32 0, ptr %l43, !tbaa !23
  %t612 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t613 = getelementptr %"compiler/mir:Range", ptr %t612, i32 0, i32 1
  %t614 = load i32, ptr %t613, !tbaa !23
  store i32 %t614, ptr %l44, !tbaa !23
  store i32 1, ptr %l45, !tbaa !23
  %t616 = load i32, ptr %l44, !tbaa !23
  %t617 = load i32, ptr %l43, !tbaa !23
  %t620 = icmp sgt i32 %t616, %t617
  br i1 %t620, label %bb110, label %bb111
bb110:
  %t622 = load i32, ptr %l45, !tbaa !23
  %t624 = icmp sgt i32 %t622, 0
  br i1 %t624, label %bb112, label %bb113
bb111:
  store i32 0, ptr %l323, !tbaa !23
  br label %bb115
bb112:
  %t626 = load i32, ptr %l44, !tbaa !23
  %t627 = load i32, ptr %l43, !tbaa !23
  %t630 = sub i32 %t626, %t627
  %t631 = load i32, ptr %l45, !tbaa !23
  %t634 = add i32 %t630, %t631
  %t636 = sub i32 %t634, 1
  %t637 = load i32, ptr %l45, !tbaa !23
  %t640 = sdiv i32 %t636, %t637
  store i32 %t640, ptr %l326, !tbaa !23
  br label %bb114
bb113:
  store i32 0, ptr %l326, !tbaa !23
  br label %bb114
bb114:
  %t642 = load i32, ptr %l326, !tbaa !23
  store i32 %t642, ptr %l323, !tbaa !23
  br label %bb115
bb115:
  %t643 = load i32, ptr %l323, !tbaa !23
  store i32 %t643, ptr %l46, !tbaa !23
  store i32 0, ptr %l47, !tbaa !23
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s25
  %t644 = load i32, ptr %l47, !tbaa !23
  %t645 = load i32, ptr %l46, !tbaa !23
  %t648 = icmp slt i32 %t644, %t645
  %t650 = xor i1 %t648, true
  br i1 %t650, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s25)
  br label %bb129
bb118:
  br label %bb119
bb119:
  %t652 = load i32, ptr %l43, !tbaa !23
  %t653 = load i32, ptr %l47, !tbaa !23
  %t654 = load i32, ptr %l45, !tbaa !23
  %t657 = mul i32 %t653, %t654
  %t660 = add i32 %t652, %t657
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/emit:fnEm", ptr %t662, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !29
  %t667 = getelementptr %"compiler/mir:Fn", ptr %t665, i32 0, i32 17
  %t668 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 4
  %t669 = getelementptr %"compiler/mir:Range", ptr %t668, i32 0, i32 0
  %t670 = load i32, ptr %t669, !tbaa !23
  %t672 = sext i32 %t670 to i64
  %t675 = sext i32 %t660 to i64
  %t678 = add i64 %t672, %t675
  %t681 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t667, i64 %t678)
  store %"compiler/mir:TaskClause" %t681, ptr %l352
  br label %bb120
bb120:
  %t682 = getelementptr %"compiler/mir:TaskClause", ptr %l352, i32 0, i32 2
  %t683 = load { i64, [4 x i64] }, ptr %t682
  store { i64, [4 x i64] } %t683, ptr %l49
  %t685 = load { i64, [4 x i64] }, ptr %l49
  %t687 = extractvalue { i64, [4 x i64] } %t685, 0
  %t688 = icmp eq i64 %t687, 0
  %t690 = xor i1 %t688, true
  br i1 %t690, label %bb121, label %bb122
bb121:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 12, ptr @.d377 })
  br label %bb123
bb122:
  br label %bb127
bb123:
  store ptr %l19, ptr %l358, !tbaa !29
  %t693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t693, ptr %l359, !tbaa !29
  %t694 = load { i64, [4 x i64] }, ptr %l49
  store { i64, [4 x i64] } %t694, ptr %l360
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load { i64, [4 x i64] }, ptr %l49
  %t699 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t695, { i64, [4 x i64] } %t696)
  store i32 %t699, ptr %l363
  br label %bb124
bb124:
  %t700 = load ptr, ptr %l359, !tbaa !29
  %t701 = load { i64, [4 x i64] }, ptr %l360
  %t702 = load i32, ptr %l363, !tbaa !23
  %t703 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t700, { i64, [4 x i64] } %t701, i32 %t702)
  store { i64, ptr } %t703, ptr %l364
  br label %bb125
bb125:
  %t704 = load { i64, ptr }, ptr %l364, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t704, 0
  %t706 = extractvalue { i64, ptr } %t704, 1
  %t707 = mul i64 %t705, 1
  %t708 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t707)
  call void @llvm.memcpy.p0.p0.i64(ptr %t708, ptr %t706, i64 %t707, i1 false)
  %t709 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  %t711 = load ptr, ptr %l358, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t711, { i64, ptr } %t710)
  br label %bb126
bb126:
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s25)
  br label %bb128
bb128:
  %t713 = load i32, ptr %l47, !tbaa !23
  %t715 = add i32 %t713, 1
  store i32 %t715, ptr %l47, !tbaa !23
  br label %bb116
bb129:
  %t717 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t718 = getelementptr %"compiler/mir:Range", ptr %t717, i32 0, i32 1
  %t719 = load i32, ptr %t718, !tbaa !23
  %t721 = sext i32 %t719 to i64
  store i64 %t721, ptr %l369, !tbaa !24
  %t722 = load i64, ptr %l369, !tbaa !24
  %t723 = icmp sge i64 %t722, 0
  br i1 %t723, label %bb130, label %bb131
bb130:
  %t725 = load i64, ptr %l369, !tbaa !24
  %t726 = icmp sle i64 %t725, 1152921504606846975
  br i1 %t726, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb132:
  %t728 = load i64, ptr %l369, !tbaa !24
  %t729 = mul i64 %t728, 8
  %t730 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t729)
  store i64 0, ptr %t731
  br label %fill.732
fill.732:
  %t735 = load i64, ptr %t731
  %t736 = icmp slt i64 %t735, %t728
  br i1 %t736, label %fillb.733, label %filld.734
fillb.733:
  %t737 = getelementptr i64, ptr %t730, i64 %t735
  store i64 -1, ptr %t737
  %t738 = add i64 %t735, 1
  store i64 %t738, ptr %t731
  br label %fill.732
filld.734:
  %t739 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t740 = insertvalue { i64, ptr } %t739, ptr %t730, 1
  store { i64, ptr } %t740, ptr %l50, !tbaa !27
  store i32 0, ptr %l51, !tbaa !23
  %t742 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t743 = getelementptr %"compiler/mir:Range", ptr %t742, i32 0, i32 1
  %t744 = load i32, ptr %t743, !tbaa !23
  store i32 %t744, ptr %l52, !tbaa !23
  store i32 1, ptr %l53, !tbaa !23
  %t746 = load i32, ptr %l52, !tbaa !23
  %t747 = load i32, ptr %l51, !tbaa !23
  %t750 = icmp sgt i32 %t746, %t747
  br i1 %t750, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @olang_loc_9287686e475a7dbe_ea834ed677e35522)
  unreachable
bb134:
  %t752 = load i32, ptr %l53, !tbaa !23
  %t754 = icmp sgt i32 %t752, 0
  br i1 %t754, label %bb136, label %bb137
bb135:
  store i32 0, ptr %l377, !tbaa !23
  br label %bb139
bb136:
  %t756 = load i32, ptr %l52, !tbaa !23
  %t757 = load i32, ptr %l51, !tbaa !23
  %t760 = sub i32 %t756, %t757
  %t761 = load i32, ptr %l53, !tbaa !23
  %t764 = add i32 %t760, %t761
  %t766 = sub i32 %t764, 1
  %t767 = load i32, ptr %l53, !tbaa !23
  %t770 = sdiv i32 %t766, %t767
  store i32 %t770, ptr %l380, !tbaa !23
  br label %bb138
bb137:
  store i32 0, ptr %l380, !tbaa !23
  br label %bb138
bb138:
  %t772 = load i32, ptr %l380, !tbaa !23
  store i32 %t772, ptr %l377, !tbaa !23
  br label %bb139
bb139:
  %t773 = load i32, ptr %l377, !tbaa !23
  store i32 %t773, ptr %l54, !tbaa !23
  store i32 0, ptr %l55, !tbaa !23
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s29
  %t774 = load i32, ptr %l55, !tbaa !23
  %t775 = load i32, ptr %l54, !tbaa !23
  %t778 = icmp slt i32 %t774, %t775
  %t780 = xor i1 %t778, true
  br i1 %t780, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s29)
  br label %bb169
bb142:
  br label %bb143
bb143:
  %t782 = load i32, ptr %l51, !tbaa !23
  %t783 = load i32, ptr %l55, !tbaa !23
  %t784 = load i32, ptr %l53, !tbaa !23
  %t787 = mul i32 %t783, %t784
  %t790 = add i32 %t782, %t787
  store i32 %t790, ptr %l56, !tbaa !23
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/emit:fnEm", ptr %t792, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = getelementptr %"compiler/mir:Fn", ptr %t795, i32 0, i32 12
  %t798 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 7
  %t799 = getelementptr %"compiler/mir:Range", ptr %t798, i32 0, i32 0
  %t800 = load i32, ptr %t799, !tbaa !23
  %t802 = sext i32 %t800 to i64
  %t803 = load i32, ptr %l56, !tbaa !23
  %t805 = sext i32 %t803 to i64
  %t808 = add i64 %t802, %t805
  %t811 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t797, i64 %t808)
  store { i64, [1 x i64] } %t811, ptr %l406
  br label %bb144
bb144:
  %t812 = load { i64, [1 x i64] }, ptr %l406
  store { i64, [1 x i64] } %t812, ptr %l57
  %t813 = load { i64, [1 x i64] }, ptr %l57
  %t815 = extractvalue { i64, [1 x i64] } %t813, 0
  %t816 = icmp eq i64 %t815, 3
  br i1 %t816, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb167
bb148:
  %t818 = load { i64, [1 x i64] }, ptr %l57
  %t820 = extractvalue { i64, [1 x i64] } %t818, 0
  %t821 = icmp eq i64 %t820, 2
  br i1 %t821, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb155
bb151:
  %t823 = load i32, ptr %l56, !tbaa !23
  store i32 %t823, ptr %l411, !tbaa !23
  %t825 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l18)
  store i64 %t825, ptr %l413
  br label %bb152
bb152:
  %t826 = load i64, ptr %l413, !tbaa !24
  %t827 = load i32, ptr %l411, !tbaa !23
  %t828 = sext i32 %t827 to i64
  %t829 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !27
  %t831 = getelementptr i64, ptr %t830, i64 %t828
  store i64 %t826, ptr %t831, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr @.d378 })
  br label %bb153
bb153:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } { i64 4, ptr @.d379 })
  br label %bb154
bb154:
  br label %bb167
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb166
bb158:
  store %olang.scope zeroinitializer, ptr %s32
  %t834 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s32, ptr %s32, ptr %t834, { i64, ptr } { i64 15, ptr @.d380 }, { i64, ptr } { i64 25, ptr @.d381 })
  br label %bb159
bb159:
  %t836 = load ptr, ptr %l0, !tbaa !29
  store ptr %t836, ptr %l417, !tbaa !29
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t838 = load { i64, [1 x i64] }, ptr %l57
  %t841 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s32, ptr %t837, { i64, [1 x i64] } %t838)
  store { i64, ptr } %t841, ptr %l420
  br label %bb160
bb160:
  %t842 = extractvalue { i64, ptr } { i64 30, ptr @.d382 }, 1
  %t843 = extractvalue { i64, ptr } { i64 30, ptr @.d382 }, 0
  %t844 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t845 = extractvalue { i64, ptr } %t844, 1
  %t846 = extractvalue { i64, ptr } %t844, 0
  %t847 = add i64 %t843, %t846
  %t848 = extractvalue { i64, ptr } { i64 1, ptr @.d383 }, 1
  %t849 = extractvalue { i64, ptr } { i64 1, ptr @.d383 }, 0
  %t850 = add i64 %t847, %t849
  %t851 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t850)
  call void @olang_textcopy(ptr %t851, ptr %t842, i64 %t843)
  %t852 = getelementptr i8, ptr %t851, i64 %t843
  call void @olang_textcopy(ptr %t852, ptr %t845, i64 %t846)
  %t853 = getelementptr i8, ptr %t852, i64 %t846
  call void @olang_textcopy(ptr %t853, ptr %t848, i64 %t849)
  %t854 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t855 = insertvalue { i64, ptr } %t854, ptr %t851, 1
  %t857 = extractvalue { i64, ptr } %t855, 0
  %t858 = extractvalue { i64, ptr } %t855, 1
  %t859 = mul i64 %t857, 1
  %t860 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t859)
  call void @llvm.memcpy.p0.p0.i64(ptr %t860, ptr %t858, i64 %t859, i1 false)
  %t861 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t862 = insertvalue { i64, ptr } %t861, ptr %t860, 1
  %t863 = load ptr, ptr %l417, !tbaa !29
  %t865 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t863, { i64, ptr } %t862)
  store { i64, ptr } %t865, ptr %l423
  br label %bb161
bb161:
  %t866 = load { i64, ptr }, ptr %l423, !tbaa !27
  store { i64, ptr } %t866, ptr %l58, !tbaa !27
  %t867 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t867, 1
  %t870 = extractvalue { i64, ptr } %t867, 0
  %t871 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t870)
  call void @olang_textcopy(ptr %t871, ptr %t869, i64 %t870)
  %t872 = insertvalue { i64, ptr } undef, i64 %t870, 0
  %t873 = insertvalue { i64, ptr } %t872, ptr %t871, 1
  %t875 = extractvalue { i64, ptr } %t873, 0
  %t876 = extractvalue { i64, ptr } %t873, 1
  %t877 = mul i64 %t875, 1
  %t878 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t877)
  call void @llvm.memcpy.p0.p0.i64(ptr %t878, ptr %t876, i64 %t877, i1 false)
  %t879 = insertvalue { i64, ptr } undef, i64 %t875, 0
  %t880 = insertvalue { i64, ptr } %t879, ptr %t878, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } %t880)
  br label %bb162
bb162:
  %t883 = load i32, ptr %l56, !tbaa !23
  store i32 %t883, ptr %l428, !tbaa !23
  %t885 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l18)
  store i64 %t885, ptr %l430
  br label %bb163
bb163:
  %t886 = load i64, ptr %l430, !tbaa !24
  %t887 = load i32, ptr %l428, !tbaa !23
  %t888 = sext i32 %t887 to i64
  %t889 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t890 = load ptr, ptr %t889, !tbaa !27
  %t891 = getelementptr i64, ptr %t890, i64 %t888
  store i64 %t886, ptr %t891, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l18, { i64, ptr } { i64 3, ptr @.d384 })
  br label %bb164
bb164:
  %t893 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t895 = extractvalue { i64, ptr } %t893, 1
  %t896 = extractvalue { i64, ptr } %t893, 0
  %t897 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t896)
  call void @olang_textcopy(ptr %t897, ptr %t895, i64 %t896)
  %t898 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t899 = insertvalue { i64, ptr } %t898, ptr %t897, 1
  %t901 = extractvalue { i64, ptr } %t899, 0
  %t902 = extractvalue { i64, ptr } %t899, 1
  %t903 = mul i64 %t901, 1
  %t904 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t903)
  call void @llvm.memcpy.p0.p0.i64(ptr %t904, ptr %t902, i64 %t903, i1 false)
  %t905 = insertvalue { i64, ptr } undef, i64 %t901, 0
  %t906 = insertvalue { i64, ptr } %t905, ptr %t904, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t906)
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s32)
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_45f21d64bb841654_8b47099e9550bca0)
  unreachable
bb167:
  call void @__olang_scope_close(ptr %s29)
  br label %bb168
bb168:
  %t909 = load i32, ptr %l55, !tbaa !23
  %t911 = add i32 %t909, 1
  store i32 %t911, ptr %l55, !tbaa !23
  br label %bb140
bb169:
  %t913 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t913, ptr %l438
  br label %bb170
bb170:
  %t914 = load %"std/prelude/text:StringBuilder", ptr %l438
  store %"std/prelude/text:StringBuilder" %t914, ptr %l59
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l59, { i64, ptr } { i64 2, ptr @.d385 })
  br label %bb171
bb171:
  store i64 0, ptr %l60, !tbaa !24
  %t917 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l18)
  store i64 %t917, ptr %l441
  br label %bb172
bb172:
  %t918 = load i64, ptr %l441, !tbaa !24
  store i64 %t918, ptr %l61, !tbaa !24
  store i64 1, ptr %l62, !tbaa !24
  %t919 = load i64, ptr %l61, !tbaa !24
  %t920 = load i64, ptr %l60, !tbaa !24
  %t923 = icmp sgt i64 %t919, %t920
  br i1 %t923, label %bb173, label %bb174
bb173:
  %t925 = load i64, ptr %l62, !tbaa !24
  %t927 = icmp sgt i64 %t925, 0
  br i1 %t927, label %bb175, label %bb176
bb174:
  store i64 0, ptr %l445, !tbaa !24
  br label %bb178
bb175:
  %t929 = load i64, ptr %l61, !tbaa !24
  %t930 = load i64, ptr %l60, !tbaa !24
  %t933 = sub i64 %t929, %t930
  %t934 = load i64, ptr %l62, !tbaa !24
  %t937 = add i64 %t933, %t934
  %t939 = sub i64 %t937, 1
  %t940 = load i64, ptr %l62, !tbaa !24
  %t943 = sdiv i64 %t939, %t940
  store i64 %t943, ptr %l448, !tbaa !24
  br label %bb177
bb176:
  store i64 0, ptr %l448, !tbaa !24
  br label %bb177
bb177:
  %t945 = load i64, ptr %l448, !tbaa !24
  store i64 %t945, ptr %l445, !tbaa !24
  br label %bb178
bb178:
  %t946 = load i64, ptr %l445, !tbaa !24
  store i64 %t946, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s38
  %t947 = load i64, ptr %l64, !tbaa !24
  %t948 = load i64, ptr %l63, !tbaa !24
  %t951 = icmp slt i64 %t947, %t948
  %t953 = xor i1 %t951, true
  br i1 %t953, label %bb180, label %bb181
bb180:
  call void @__olang_scope_close(ptr %s38)
  br label %bb190
bb181:
  br label %bb182
bb182:
  %t955 = load i64, ptr %l60, !tbaa !24
  %t956 = load i64, ptr %l64, !tbaa !24
  %t957 = load i64, ptr %l62, !tbaa !24
  %t960 = mul i64 %t956, %t957
  %t963 = add i64 %t955, %t960
  store i64 %t963, ptr %l65, !tbaa !24
  %t965 = load i64, ptr %l65, !tbaa !24
  %t967 = icmp sgt i64 %t965, 0
  br i1 %t967, label %bb183, label %bb184
bb183:
  store %olang.scope zeroinitializer, ptr %s39
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %l59, { i64, ptr } { i64 2, ptr @.d386 })
  br label %bb185
bb184:
  br label %bb186
bb185:
  call void @__olang_scope_close(ptr %s39)
  br label %bb186
bb186:
  store ptr %l59, ptr %l469, !tbaa !29
  %t970 = load i64, ptr %l65, !tbaa !24
  %t973 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l18, i64 %t970)
  store { i64, ptr } %t973, ptr %l472
  br label %bb187
bb187:
  %t974 = load ptr, ptr %l469, !tbaa !29
  %t975 = load { i64, ptr }, ptr %l472, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t974, { i64, ptr } %t975)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s38)
  br label %bb189
bb189:
  %t976 = load i64, ptr %l64, !tbaa !24
  %t978 = add i64 %t976, 1
  store i64 %t978, ptr %l64, !tbaa !24
  br label %bb179
bb190:
  %t981 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l18)
  store i64 %t981, ptr %l476
  br label %bb191
bb191:
  %t982 = load i64, ptr %l476, !tbaa !24
  %t983 = icmp eq i64 %t982, 0
  br i1 %t983, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s41
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %l59, { i64, ptr } { i64 2, ptr @.d387 })
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s41)
  br label %bb195
bb195:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l59, { i64, ptr } { i64 2, ptr @.d388 })
  br label %bb196
bb196:
  %t988 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l59)
  store { i64, ptr } %t988, ptr %l481
  br label %bb197
bb197:
  %t989 = load { i64, ptr }, ptr %l481, !tbaa !27
  store { i64, ptr } %t989, ptr %l66, !tbaa !27
  %t990 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t990, { i64, ptr } { i64 21, ptr @.d389 })
  br label %bb198
bb198:
  %t992 = load ptr, ptr %l0, !tbaa !29
  store ptr %t992, ptr %l483, !tbaa !29
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t995 = extractvalue { i64, ptr } { i64 14, ptr @.d390 }, 1
  %t996 = extractvalue { i64, ptr } { i64 14, ptr @.d390 }, 0
  %t998 = extractvalue { i64, ptr } %t994, 1
  %t999 = extractvalue { i64, ptr } %t994, 0
  %t1000 = add i64 %t996, %t999
  %t1001 = extractvalue { i64, ptr } { i64 17, ptr @.d391 }, 1
  %t1002 = extractvalue { i64, ptr } { i64 17, ptr @.d391 }, 0
  %t1003 = add i64 %t1000, %t1002
  %t1004 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1003)
  call void @olang_textcopy(ptr %t1004, ptr %t995, i64 %t996)
  %t1005 = getelementptr i8, ptr %t1004, i64 %t996
  call void @olang_textcopy(ptr %t1005, ptr %t998, i64 %t999)
  %t1006 = getelementptr i8, ptr %t1005, i64 %t999
  call void @olang_textcopy(ptr %t1006, ptr %t1001, i64 %t1002)
  %t1007 = insertvalue { i64, ptr } undef, i64 %t1003, 0
  %t1008 = insertvalue { i64, ptr } %t1007, ptr %t1004, 1
  %t1010 = extractvalue { i64, ptr } %t1008, 0
  %t1011 = extractvalue { i64, ptr } %t1008, 1
  %t1012 = mul i64 %t1010, 1
  %t1013 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1012)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1013, ptr %t1011, i64 %t1012, i1 false)
  %t1014 = insertvalue { i64, ptr } undef, i64 %t1010, 0
  %t1015 = insertvalue { i64, ptr } %t1014, ptr %t1013, 1
  %t1018 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t993, { i64, ptr } %t1015)
  store { i64, ptr } %t1018, ptr %l488
  br label %bb199
bb199:
  %t1019 = extractvalue { i64, ptr } { i64 13, ptr @.d392 }, 1
  %t1020 = extractvalue { i64, ptr } { i64 13, ptr @.d392 }, 0
  %t1021 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t1022 = extractvalue { i64, ptr } %t1021, 1
  %t1023 = extractvalue { i64, ptr } %t1021, 0
  %t1024 = add i64 %t1020, %t1023
  %t1025 = extractvalue { i64, ptr } { i64 7, ptr @.d393 }, 1
  %t1026 = extractvalue { i64, ptr } { i64 7, ptr @.d393 }, 0
  %t1027 = add i64 %t1024, %t1026
  %t1028 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1027)
  call void @olang_textcopy(ptr %t1028, ptr %t1019, i64 %t1020)
  %t1029 = getelementptr i8, ptr %t1028, i64 %t1020
  call void @olang_textcopy(ptr %t1029, ptr %t1022, i64 %t1023)
  %t1030 = getelementptr i8, ptr %t1029, i64 %t1023
  call void @olang_textcopy(ptr %t1030, ptr %t1025, i64 %t1026)
  %t1031 = insertvalue { i64, ptr } undef, i64 %t1027, 0
  %t1032 = insertvalue { i64, ptr } %t1031, ptr %t1028, 1
  %t1034 = extractvalue { i64, ptr } %t1032, 0
  %t1035 = extractvalue { i64, ptr } %t1032, 1
  %t1036 = mul i64 %t1034, 1
  %t1037 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1036)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1037, ptr %t1035, i64 %t1036, i1 false)
  %t1038 = insertvalue { i64, ptr } undef, i64 %t1034, 0
  %t1039 = insertvalue { i64, ptr } %t1038, ptr %t1037, 1
  %t1040 = load ptr, ptr %l483, !tbaa !29
  %t1042 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1040, { i64, ptr } %t1039)
  store { i64, ptr } %t1042, ptr %l491
  br label %bb200
bb200:
  %t1043 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t1044 = load ptr, ptr %l0, !tbaa !29
  %t1045 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1047 = extractvalue { i64, ptr } { i64 36, ptr @.d394 }, 1
  %t1048 = extractvalue { i64, ptr } { i64 36, ptr @.d394 }, 0
  %t1050 = extractvalue { i64, ptr } %t1045, 1
  %t1051 = extractvalue { i64, ptr } %t1045, 0
  %t1052 = add i64 %t1048, %t1051
  %t1053 = extractvalue { i64, ptr } { i64 6, ptr @.d395 }, 1
  %t1054 = extractvalue { i64, ptr } { i64 6, ptr @.d395 }, 0
  %t1055 = add i64 %t1052, %t1054
  %t1057 = extractvalue { i64, ptr } %t1043, 1
  %t1058 = extractvalue { i64, ptr } %t1043, 0
  %t1059 = add i64 %t1055, %t1058
  %t1060 = extractvalue { i64, ptr } { i64 8, ptr @.d396 }, 1
  %t1061 = extractvalue { i64, ptr } { i64 8, ptr @.d396 }, 0
  %t1062 = add i64 %t1059, %t1061
  %t1063 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1062)
  call void @olang_textcopy(ptr %t1063, ptr %t1047, i64 %t1048)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1048
  call void @olang_textcopy(ptr %t1064, ptr %t1050, i64 %t1051)
  %t1065 = getelementptr i8, ptr %t1064, i64 %t1051
  call void @olang_textcopy(ptr %t1065, ptr %t1053, i64 %t1054)
  %t1066 = getelementptr i8, ptr %t1065, i64 %t1054
  call void @olang_textcopy(ptr %t1066, ptr %t1057, i64 %t1058)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1058
  call void @olang_textcopy(ptr %t1067, ptr %t1060, i64 %t1061)
  %t1068 = insertvalue { i64, ptr } undef, i64 %t1062, 0
  %t1069 = insertvalue { i64, ptr } %t1068, ptr %t1063, 1
  %t1071 = extractvalue { i64, ptr } %t1069, 0
  %t1072 = extractvalue { i64, ptr } %t1069, 1
  %t1073 = mul i64 %t1071, 1
  %t1074 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1073)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1074, ptr %t1072, i64 %t1073, i1 false)
  %t1075 = insertvalue { i64, ptr } undef, i64 %t1071, 0
  %t1076 = insertvalue { i64, ptr } %t1075, ptr %t1074, 1
  %t1079 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1044, { i64, ptr } %t1076)
  store { i64, ptr } %t1079, ptr %l497
  br label %bb201
bb201:
  %t1080 = load { i64, ptr }, ptr %l497, !tbaa !27
  store { i64, ptr } %t1080, ptr %l68, !tbaa !27
  %t1081 = load i1, ptr %l8, !tbaa !21
  br i1 %t1081, label %bb202, label %bb203
bb202:
  store i64 1, ptr %l499, !tbaa !24
  br label %bb204
bb203:
  store i64 0, ptr %l499, !tbaa !24
  br label %bb204
bb204:
  %t1083 = load i64, ptr %l499, !tbaa !24
  store i64 %t1083, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  %t1085 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l18)
  store i64 %t1085, ptr %l501
  br label %bb205
bb205:
  %t1086 = load i64, ptr %l501, !tbaa !24
  store i64 %t1086, ptr %l71, !tbaa !24
  store i64 1, ptr %l72, !tbaa !24
  %t1087 = load i64, ptr %l71, !tbaa !24
  %t1088 = load i64, ptr %l70, !tbaa !24
  %t1091 = icmp sgt i64 %t1087, %t1088
  br i1 %t1091, label %bb206, label %bb207
bb206:
  %t1093 = load i64, ptr %l72, !tbaa !24
  %t1095 = icmp sgt i64 %t1093, 0
  br i1 %t1095, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l505, !tbaa !24
  br label %bb211
bb208:
  %t1097 = load i64, ptr %l71, !tbaa !24
  %t1098 = load i64, ptr %l70, !tbaa !24
  %t1101 = sub i64 %t1097, %t1098
  %t1102 = load i64, ptr %l72, !tbaa !24
  %t1105 = add i64 %t1101, %t1102
  %t1107 = sub i64 %t1105, 1
  %t1108 = load i64, ptr %l72, !tbaa !24
  %t1111 = sdiv i64 %t1107, %t1108
  store i64 %t1111, ptr %l508, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l508, !tbaa !24
  br label %bb210
bb210:
  %t1113 = load i64, ptr %l508, !tbaa !24
  store i64 %t1113, ptr %l505, !tbaa !24
  br label %bb211
bb211:
  %t1114 = load i64, ptr %l505, !tbaa !24
  store i64 %t1114, ptr %l73, !tbaa !24
  store i64 0, ptr %l74, !tbaa !24
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s46
  %t1115 = load i64, ptr %l74, !tbaa !24
  %t1116 = load i64, ptr %l73, !tbaa !24
  %t1119 = icmp slt i64 %t1115, %t1116
  %t1121 = xor i1 %t1119, true
  br i1 %t1121, label %bb213, label %bb214
bb213:
  call void @__olang_scope_close(ptr %s46)
  br label %bb228
bb214:
  br label %bb215
bb215:
  %t1123 = load i64, ptr %l70, !tbaa !24
  %t1124 = load i64, ptr %l74, !tbaa !24
  %t1125 = load i64, ptr %l72, !tbaa !24
  %t1128 = mul i64 %t1124, %t1125
  %t1131 = add i64 %t1123, %t1128
  store i64 %t1131, ptr %l75, !tbaa !24
  %t1133 = load ptr, ptr %l0, !tbaa !29
  %t1134 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1135 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1136 = load i64, ptr %l75, !tbaa !24
  %t1137 = extractvalue { i64, ptr } { i64 14, ptr @.d397 }, 1
  %t1138 = extractvalue { i64, ptr } { i64 14, ptr @.d397 }, 0
  %t1140 = extractvalue { i64, ptr } %t1134, 1
  %t1141 = extractvalue { i64, ptr } %t1134, 0
  %t1142 = add i64 %t1138, %t1141
  %t1143 = extractvalue { i64, ptr } { i64 6, ptr @.d398 }, 1
  %t1144 = extractvalue { i64, ptr } { i64 6, ptr @.d398 }, 0
  %t1145 = add i64 %t1142, %t1144
  %t1147 = extractvalue { i64, ptr } %t1135, 1
  %t1148 = extractvalue { i64, ptr } %t1135, 0
  %t1149 = add i64 %t1145, %t1148
  %t1150 = extractvalue { i64, ptr } { i64 13, ptr @.d399 }, 1
  %t1151 = extractvalue { i64, ptr } { i64 13, ptr @.d399 }, 0
  %t1152 = add i64 %t1149, %t1151
  %t1154 = call i64 @__olang_fmt_i64(ptr null, i64 %t1136)
  %t1155 = add i64 %t1152, %t1154
  %t1156 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1155)
  call void @olang_textcopy(ptr %t1156, ptr %t1137, i64 %t1138)
  %t1157 = getelementptr i8, ptr %t1156, i64 %t1138
  call void @olang_textcopy(ptr %t1157, ptr %t1140, i64 %t1141)
  %t1158 = getelementptr i8, ptr %t1157, i64 %t1141
  call void @olang_textcopy(ptr %t1158, ptr %t1143, i64 %t1144)
  %t1159 = getelementptr i8, ptr %t1158, i64 %t1144
  call void @olang_textcopy(ptr %t1159, ptr %t1147, i64 %t1148)
  %t1160 = getelementptr i8, ptr %t1159, i64 %t1148
  call void @olang_textcopy(ptr %t1160, ptr %t1150, i64 %t1151)
  %t1161 = getelementptr i8, ptr %t1160, i64 %t1151
  %t1162 = call i64 @__olang_fmt_i64(ptr %t1161, i64 %t1136)
  %t1163 = insertvalue { i64, ptr } undef, i64 %t1155, 0
  %t1164 = insertvalue { i64, ptr } %t1163, ptr %t1156, 1
  %t1166 = extractvalue { i64, ptr } %t1164, 0
  %t1167 = extractvalue { i64, ptr } %t1164, 1
  %t1168 = mul i64 %t1166, 1
  %t1169 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1169, ptr %t1167, i64 %t1168, i1 false)
  %t1170 = insertvalue { i64, ptr } undef, i64 %t1166, 0
  %t1171 = insertvalue { i64, ptr } %t1170, ptr %t1169, 1
  %t1174 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s46, ptr %s46, ptr %t1133, { i64, ptr } %t1171)
  store { i64, ptr } %t1174, ptr %l532
  br label %bb216
bb216:
  %t1175 = load { i64, ptr }, ptr %l532, !tbaa !27
  store { i64, ptr } %t1175, ptr %l76, !tbaa !27
  %t1176 = load i64, ptr %l75, !tbaa !24
  %t1179 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l19, i64 %t1176)
  store { i64, ptr } %t1179, ptr %l535
  br label %bb217
bb217:
  %t1180 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s46, { i64, ptr } %t1180, { i64, ptr } { i64 0, ptr @.d400 })
  store i1 %t1181, ptr %l536
  br label %bb218
bb218:
  %t1182 = load i1, ptr %l536, !tbaa !21
  br i1 %t1182, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s48
  %t1183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1183, ptr %l537, !tbaa !29
  %t1184 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t1184, ptr %l538, !tbaa !27
  %t1185 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t1185, ptr %l539, !tbaa !27
  %t1186 = load i64, ptr %l75, !tbaa !24
  %t1187 = load i64, ptr %l69, !tbaa !24
  %t1190 = sub i64 %t1186, %t1187
  %t1192 = getelementptr { i64, ptr }, ptr %l539, i32 0, i32 1
  %t1193 = load ptr, ptr %t1192, !tbaa !27
  %t1194 = getelementptr i32, ptr %t1193, i64 %t1190
  %t1195 = load i32, ptr %t1194, !tbaa !33
  store i32 %t1195, ptr %l543, !tbaa !23
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1197 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 1
  %t1198 = load %"compiler/mir:Range", ptr %t1197
  %t1199 = load i64, ptr %l75, !tbaa !24
  %t1200 = load i64, ptr %l69, !tbaa !24
  %t1203 = sub i64 %t1199, %t1200
  %t1207 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t1196, %"compiler/mir:Range" %t1198, i64 %t1203)
  store { i64, [4 x i64] } %t1207, ptr %l549
  br label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s49
  %t1208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1208, ptr %l550, !tbaa !29
  %t1209 = load i64, ptr %l75, !tbaa !24
  %t1212 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l18, i64 %t1209)
  store { i64, ptr } %t1212, ptr %l553
  br label %bb223
bb221:
  %t1213 = load ptr, ptr %l537, !tbaa !29
  %t1214 = load { i64, ptr }, ptr %l538, !tbaa !27
  %t1215 = load i32, ptr %l543, !tbaa !23
  %t1216 = load { i64, [4 x i64] }, ptr %l549
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s46, ptr %s48, ptr %t1213, { i64, ptr } %t1214, i32 %t1215, { i64, [4 x i64] } %t1216, { i64, ptr } { i64 0, ptr @.d401 })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s48)
  br label %bb226
bb223:
  %t1217 = load i64, ptr %l75, !tbaa !24
  %t1220 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l19, i64 %t1217)
  store { i64, ptr } %t1220, ptr %l556
  br label %bb224
bb224:
  %t1221 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t1222 = load ptr, ptr %l550, !tbaa !29
  %t1223 = load { i64, ptr }, ptr %l553, !tbaa !27
  %t1224 = load { i64, ptr }, ptr %l556, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s46, ptr %s49, ptr %t1222, { i64, ptr } %t1223, { i64, ptr } %t1224, { i64, ptr } %t1221, { i64, ptr } { i64 0, ptr @.d402 })
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s49)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s46)
  br label %bb227
bb227:
  %t1226 = load i64, ptr %l74, !tbaa !24
  %t1228 = add i64 %t1226, 1
  store i64 %t1228, ptr %l74, !tbaa !24
  br label %bb212
bb228:
  %t1230 = load ptr, ptr %l0, !tbaa !29
  %t1231 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1232 = extractvalue { i64, ptr } { i64 36, ptr @.d403 }, 1
  %t1233 = extractvalue { i64, ptr } { i64 36, ptr @.d403 }, 0
  %t1235 = extractvalue { i64, ptr } %t1231, 1
  %t1236 = extractvalue { i64, ptr } %t1231, 0
  %t1237 = add i64 %t1233, %t1236
  %t1238 = extractvalue { i64, ptr } { i64 16, ptr @.d404 }, 1
  %t1239 = extractvalue { i64, ptr } { i64 16, ptr @.d404 }, 0
  %t1240 = add i64 %t1237, %t1239
  %t1241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1240)
  call void @olang_textcopy(ptr %t1241, ptr %t1232, i64 %t1233)
  %t1242 = getelementptr i8, ptr %t1241, i64 %t1233
  call void @olang_textcopy(ptr %t1242, ptr %t1235, i64 %t1236)
  %t1243 = getelementptr i8, ptr %t1242, i64 %t1236
  call void @olang_textcopy(ptr %t1243, ptr %t1238, i64 %t1239)
  %t1244 = insertvalue { i64, ptr } undef, i64 %t1240, 0
  %t1245 = insertvalue { i64, ptr } %t1244, ptr %t1241, 1
  %t1247 = extractvalue { i64, ptr } %t1245, 0
  %t1248 = extractvalue { i64, ptr } %t1245, 1
  %t1249 = mul i64 %t1247, 1
  %t1250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1250, ptr %t1248, i64 %t1249, i1 false)
  %t1251 = insertvalue { i64, ptr } undef, i64 %t1247, 0
  %t1252 = insertvalue { i64, ptr } %t1251, ptr %t1250, 1
  %t1255 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1230, { i64, ptr } %t1252)
  store { i64, ptr } %t1255, ptr %l564
  br label %bb229
bb229:
  %t1256 = load { i64, ptr }, ptr %l564, !tbaa !27
  store { i64, ptr } %t1256, ptr %l77, !tbaa !27
  store { i64, ptr } { i64 4, ptr @.d405 }, ptr %l565, !tbaa !27
  %t1257 = load { i64, ptr }, ptr %l565, !tbaa !27
  store { i64, ptr } %t1257, ptr %l566, !tbaa !27
  %t1258 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t1259 = extractvalue { i64, ptr } %t1258, 0
  store i64 %t1259, ptr %l567, !tbaa !24
  %t1260 = load i64, ptr %l567, !tbaa !24
  %t1261 = mul i64 %t1260, 1
  %t1262 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1261)
  %t1263 = insertvalue { i64, ptr } undef, i64 %t1260, 0
  %t1264 = insertvalue { i64, ptr } %t1263, ptr %t1262, 1
  store { i64, ptr } %t1264, ptr %l568, !tbaa !27
  %t1265 = getelementptr { i64, ptr }, ptr %l568, i32 0, i32 1
  %t1266 = load ptr, ptr %t1265, !tbaa !27
  %t1267 = getelementptr { i64, ptr }, ptr %l566, i32 0, i32 1
  %t1268 = load ptr, ptr %t1267, !tbaa !27
  %t1269 = load i64, ptr %l567, !tbaa !24
  %t1270 = mul i64 %t1269, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1266, ptr %t1268, i64 %t1270, i1 false)
  %t1271 = load { i64, ptr }, ptr %l568, !tbaa !27
  store { i64, ptr } %t1271, ptr %l78, !tbaa !27
  store ptr %l26, ptr %l79, !tbaa !29
  store i64 0, ptr %l80, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s53
  %t1273 = load ptr, ptr %l79, !tbaa !29
  %t1274 = load i64, ptr %l80, !tbaa !24
  %t1277 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t1273, i64 %t1274)
  %t1278 = extractvalue { i32, { i64, ptr } } %t1277, 1
  %t1279 = extractvalue { i32, { i64, ptr } } %t1277, 0
  store i32 %t1279, ptr %l574
  %t1280 = icmp ne i32 %t1279, 0
  br i1 %t1280, label %bb232, label %ok.1281
ok.1281:
  store { i64, ptr } %t1278, ptr %l573
  br label %bb231
bb231:
  %t1282 = load { i64, ptr }, ptr %l573, !tbaa !27
  store { i64, ptr } %t1282, ptr %l570, !tbaa !27
  br label %bb236
bb232:
  %t1283 = load i32, ptr %l574, !tbaa !23
  %t1284 = ashr i32 %t1283, 16
  %t1286 = icmp eq i32 %t1284, 1
  br i1 %t1286, label %bb233, label %bb234
bb233:
  br label %bb235
bb234:
  call void @__olang_check_failed(ptr @olang_loc_d9d0b2b7ed8bee73_863b180db322a137)
  unreachable
bb235:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s53)
  br label %bb251
bb236:
  %t1288 = load { i64, ptr }, ptr %l570, !tbaa !27
  store { i64, ptr } %t1288, ptr %l81, !tbaa !27
  %t1289 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t1291 = extractvalue { i64, ptr } %t1289, 0
  store i64 %t1291, ptr %l82, !tbaa !24
  store i64 0, ptr %l83, !tbaa !24
  br label %bb237
bb237:
  store %olang.scope zeroinitializer, ptr %s54
  %t1293 = load i64, ptr %l83, !tbaa !24
  %t1294 = load i64, ptr %l82, !tbaa !24
  %t1297 = icmp slt i64 %t1293, %t1294
  %t1299 = xor i1 %t1297, true
  br i1 %t1299, label %bb238, label %bb239
bb238:
  call void @__olang_scope_close(ptr %s54)
  br label %bb249
bb239:
  br label %bb240
bb240:
  %t1301 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t1301, ptr %l583, !tbaa !27
  %t1302 = load i64, ptr %l83, !tbaa !24
  %t1304 = getelementptr { i64, ptr }, ptr %l583, i32 0, i32 1
  %t1305 = load ptr, ptr %t1304, !tbaa !27
  %t1306 = getelementptr { i64, ptr }, ptr %t1305, i64 %t1302
  %t1307 = load { i64, ptr }, ptr %t1306, !tbaa !37
  store { i64, ptr } %t1307, ptr %l84, !tbaa !27
  %t1309 = load ptr, ptr %l0, !tbaa !29
  %t1310 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1311 = extractvalue { i64, ptr } { i64 36, ptr @.d406 }, 1
  %t1312 = extractvalue { i64, ptr } { i64 36, ptr @.d406 }, 0
  %t1314 = extractvalue { i64, ptr } %t1310, 1
  %t1315 = extractvalue { i64, ptr } %t1310, 0
  %t1316 = add i64 %t1312, %t1315
  %t1317 = extractvalue { i64, ptr } { i64 16, ptr @.d407 }, 1
  %t1318 = extractvalue { i64, ptr } { i64 16, ptr @.d407 }, 0
  %t1319 = add i64 %t1316, %t1318
  %t1320 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1319)
  call void @olang_textcopy(ptr %t1320, ptr %t1311, i64 %t1312)
  %t1321 = getelementptr i8, ptr %t1320, i64 %t1312
  call void @olang_textcopy(ptr %t1321, ptr %t1314, i64 %t1315)
  %t1322 = getelementptr i8, ptr %t1321, i64 %t1315
  call void @olang_textcopy(ptr %t1322, ptr %t1317, i64 %t1318)
  %t1323 = insertvalue { i64, ptr } undef, i64 %t1319, 0
  %t1324 = insertvalue { i64, ptr } %t1323, ptr %t1320, 1
  %t1326 = extractvalue { i64, ptr } %t1324, 0
  %t1327 = extractvalue { i64, ptr } %t1324, 1
  %t1328 = mul i64 %t1326, 1
  %t1329 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1329, ptr %t1327, i64 %t1328, i1 false)
  %t1330 = insertvalue { i64, ptr } undef, i64 %t1326, 0
  %t1331 = insertvalue { i64, ptr } %t1330, ptr %t1329, 1
  %t1334 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s54, ptr %s54, ptr %t1309, { i64, ptr } %t1331)
  store { i64, ptr } %t1334, ptr %l590
  br label %bb241
bb241:
  %t1335 = load { i64, ptr }, ptr %l590, !tbaa !27
  store { i64, ptr } %t1335, ptr %l85, !tbaa !27
  %t1336 = load ptr, ptr %l0, !tbaa !29
  %t1337 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1338 = load { i64, ptr }, ptr %l85, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s54, ptr %s0, ptr %s54, ptr %s54, ptr %t1336, { i64, ptr } { i64 3, ptr @.d408 }, { i64, ptr } %t1337, { i64, ptr } %t1338, { i64, ptr } { i64 0, ptr @.d409 })
  br label %bb242
bb242:
  %t1342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1342, ptr %l594, !tbaa !29
  %t1343 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t1343, ptr %l595, !tbaa !27
  %t1344 = load ptr, ptr %l0, !tbaa !29
  %t1345 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t1346 = extractvalue { i64, ptr } { i64 32, ptr @.d410 }, 1
  %t1347 = extractvalue { i64, ptr } { i64 32, ptr @.d410 }, 0
  %t1349 = extractvalue { i64, ptr } %t1345, 1
  %t1350 = extractvalue { i64, ptr } %t1345, 0
  %t1351 = add i64 %t1347, %t1350
  %t1352 = extractvalue { i64, ptr } { i64 14, ptr @.d411 }, 1
  %t1353 = extractvalue { i64, ptr } { i64 14, ptr @.d411 }, 0
  %t1354 = add i64 %t1351, %t1353
  %t1355 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1354)
  call void @olang_textcopy(ptr %t1355, ptr %t1346, i64 %t1347)
  %t1356 = getelementptr i8, ptr %t1355, i64 %t1347
  call void @olang_textcopy(ptr %t1356, ptr %t1349, i64 %t1350)
  %t1357 = getelementptr i8, ptr %t1356, i64 %t1350
  call void @olang_textcopy(ptr %t1357, ptr %t1352, i64 %t1353)
  %t1358 = insertvalue { i64, ptr } undef, i64 %t1354, 0
  %t1359 = insertvalue { i64, ptr } %t1358, ptr %t1355, 1
  %t1361 = extractvalue { i64, ptr } %t1359, 0
  %t1362 = extractvalue { i64, ptr } %t1359, 1
  %t1363 = mul i64 %t1361, 1
  %t1364 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1364, ptr %t1362, i64 %t1363, i1 false)
  %t1365 = insertvalue { i64, ptr } undef, i64 %t1361, 0
  %t1366 = insertvalue { i64, ptr } %t1365, ptr %t1364, 1
  %t1369 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s54, ptr %s54, ptr %t1344, { i64, ptr } %t1366)
  store { i64, ptr } %t1369, ptr %l600
  br label %bb243
bb243:
  %t1370 = load { i64, ptr }, ptr %l600, !tbaa !27
  %t1371 = extractvalue { i64, ptr } %t1370, 0
  %t1372 = extractvalue { i64, ptr } %t1370, 1
  %t1373 = mul i64 %t1371, 1
  %t1374 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1374, ptr %t1372, i64 %t1373, i1 false)
  %t1375 = insertvalue { i64, ptr } undef, i64 %t1371, 0
  %t1376 = insertvalue { i64, ptr } %t1375, ptr %t1374, 1
  %t1377 = load ptr, ptr %l594, !tbaa !29
  %t1378 = load { i64, ptr }, ptr %l595, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s54, ptr %s0, ptr %s54, ptr %s54, ptr %t1377, { i64, ptr } { i64 3, ptr @.d412 }, { i64, ptr } %t1378, { i64, ptr } %t1376, { i64, ptr } { i64 0, ptr @.d413 })
  br label %bb244
bb244:
  %t1380 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t1380, ptr %l602, !tbaa !27
  %t1381 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1382 = extractvalue { i64, ptr } %t1381, 0
  %t1383 = load { i64, ptr }, ptr %l602, !tbaa !27
  %t1384 = extractvalue { i64, ptr } %t1383, 0
  store i64 %t1384, ptr %l604, !tbaa !24
  %t1386 = load i64, ptr %l604, !tbaa !24
  %t1387 = icmp eq i64 %t1382, %t1386
  br i1 %t1387, label %bb245, label %bb246
bb245:
  %t1389 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t1390 = load ptr, ptr %t1389, !tbaa !27
  %t1391 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1392 = load ptr, ptr %t1391, !tbaa !27
  %t1393 = load i64, ptr %l604, !tbaa !24
  %t1394 = mul i64 %t1393, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1390, ptr %t1392, i64 %t1394, i1 false)
  br label %bb247
bb246:
  %t1395 = load { i64, ptr }, ptr %l602, !tbaa !27
  %t1396 = extractvalue { i64, ptr } %t1395, 0
  store i64 %t1396, ptr %l606, !tbaa !24
  %t1397 = load i64, ptr %l606, !tbaa !24
  %t1398 = mul i64 %t1397, 1
  %t1399 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1398)
  %t1400 = insertvalue { i64, ptr } undef, i64 %t1397, 0
  %t1401 = insertvalue { i64, ptr } %t1400, ptr %t1399, 1
  store { i64, ptr } %t1401, ptr %l607, !tbaa !27
  %t1402 = getelementptr { i64, ptr }, ptr %l607, i32 0, i32 1
  %t1403 = load ptr, ptr %t1402, !tbaa !27
  %t1404 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1405 = load ptr, ptr %t1404, !tbaa !27
  %t1406 = load i64, ptr %l606, !tbaa !24
  %t1407 = mul i64 %t1406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1403, ptr %t1405, i64 %t1407, i1 false)
  %t1408 = load { i64, ptr }, ptr %l607, !tbaa !27
  store { i64, ptr } %t1408, ptr %l78, !tbaa !27
  br label %bb247
bb247:
  call void @__olang_scope_close(ptr %s54)
  br label %bb248
bb248:
  %t1409 = load i64, ptr %l83, !tbaa !24
  %t1411 = add i64 %t1409, 1
  store i64 %t1411, ptr %l83, !tbaa !24
  br label %bb237
bb249:
  %t1413 = load i64, ptr %l80, !tbaa !24
  %t1414 = load i64, ptr %l82, !tbaa !24
  %t1417 = add i64 %t1413, %t1414
  store i64 %t1417, ptr %l80, !tbaa !24
  call void @__olang_scope_close(ptr %s53)
  br label %bb250
bb250:
  br label %bb230
bb251:
  %t1419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1419, ptr %l613, !tbaa !29
  %t1420 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t1420, ptr %l614, !tbaa !27
  %t1421 = load ptr, ptr %l0, !tbaa !29
  %t1422 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1423 = extractvalue { i64, ptr } { i64 42, ptr @.d414 }, 1
  %t1424 = extractvalue { i64, ptr } { i64 42, ptr @.d414 }, 0
  %t1426 = extractvalue { i64, ptr } %t1422, 1
  %t1427 = extractvalue { i64, ptr } %t1422, 0
  %t1428 = add i64 %t1424, %t1427
  %t1429 = extractvalue { i64, ptr } { i64 14, ptr @.d415 }, 1
  %t1430 = extractvalue { i64, ptr } { i64 14, ptr @.d415 }, 0
  %t1431 = add i64 %t1428, %t1430
  %t1432 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1431)
  call void @olang_textcopy(ptr %t1432, ptr %t1423, i64 %t1424)
  %t1433 = getelementptr i8, ptr %t1432, i64 %t1424
  call void @olang_textcopy(ptr %t1433, ptr %t1426, i64 %t1427)
  %t1434 = getelementptr i8, ptr %t1433, i64 %t1427
  call void @olang_textcopy(ptr %t1434, ptr %t1429, i64 %t1430)
  %t1435 = insertvalue { i64, ptr } undef, i64 %t1431, 0
  %t1436 = insertvalue { i64, ptr } %t1435, ptr %t1432, 1
  %t1438 = extractvalue { i64, ptr } %t1436, 0
  %t1439 = extractvalue { i64, ptr } %t1436, 1
  %t1440 = mul i64 %t1438, 1
  %t1441 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1441, ptr %t1439, i64 %t1440, i1 false)
  %t1442 = insertvalue { i64, ptr } undef, i64 %t1438, 0
  %t1443 = insertvalue { i64, ptr } %t1442, ptr %t1441, 1
  %t1446 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1421, { i64, ptr } %t1443)
  store { i64, ptr } %t1446, ptr %l619
  br label %bb252
bb252:
  %t1447 = load { i64, ptr }, ptr %l619, !tbaa !27
  %t1448 = extractvalue { i64, ptr } %t1447, 0
  %t1449 = extractvalue { i64, ptr } %t1447, 1
  %t1450 = mul i64 %t1448, 1
  %t1451 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1450)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1451, ptr %t1449, i64 %t1450, i1 false)
  %t1452 = insertvalue { i64, ptr } undef, i64 %t1448, 0
  %t1453 = insertvalue { i64, ptr } %t1452, ptr %t1451, 1
  %t1454 = load ptr, ptr %l613, !tbaa !29
  %t1455 = load { i64, ptr }, ptr %l614, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1454, { i64, ptr } { i64 3, ptr @.d416 }, { i64, ptr } %t1455, { i64, ptr } %t1453, { i64, ptr } { i64 0, ptr @.d417 })
  br label %bb253
bb253:
  %t1457 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1457, ptr %l621, !tbaa !29
  %t1458 = load ptr, ptr %l0, !tbaa !29
  %t1459 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1460 = extractvalue { i64, ptr } { i64 42, ptr @.d418 }, 1
  %t1461 = extractvalue { i64, ptr } { i64 42, ptr @.d418 }, 0
  %t1463 = extractvalue { i64, ptr } %t1459, 1
  %t1464 = extractvalue { i64, ptr } %t1459, 0
  %t1465 = add i64 %t1461, %t1464
  %t1466 = extractvalue { i64, ptr } { i64 14, ptr @.d419 }, 1
  %t1467 = extractvalue { i64, ptr } { i64 14, ptr @.d419 }, 0
  %t1468 = add i64 %t1465, %t1467
  %t1469 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1468)
  call void @olang_textcopy(ptr %t1469, ptr %t1460, i64 %t1461)
  %t1470 = getelementptr i8, ptr %t1469, i64 %t1461
  call void @olang_textcopy(ptr %t1470, ptr %t1463, i64 %t1464)
  %t1471 = getelementptr i8, ptr %t1470, i64 %t1464
  call void @olang_textcopy(ptr %t1471, ptr %t1466, i64 %t1467)
  %t1472 = insertvalue { i64, ptr } undef, i64 %t1468, 0
  %t1473 = insertvalue { i64, ptr } %t1472, ptr %t1469, 1
  %t1475 = extractvalue { i64, ptr } %t1473, 0
  %t1476 = extractvalue { i64, ptr } %t1473, 1
  %t1477 = mul i64 %t1475, 1
  %t1478 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1478, ptr %t1476, i64 %t1477, i1 false)
  %t1479 = insertvalue { i64, ptr } undef, i64 %t1475, 0
  %t1480 = insertvalue { i64, ptr } %t1479, ptr %t1478, 1
  %t1483 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1458, { i64, ptr } %t1480)
  store { i64, ptr } %t1483, ptr %l626
  br label %bb254
bb254:
  %t1484 = load { i64, ptr }, ptr %l626, !tbaa !27
  %t1485 = extractvalue { i64, ptr } %t1484, 0
  %t1486 = extractvalue { i64, ptr } %t1484, 1
  %t1487 = mul i64 %t1485, 1
  %t1488 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1487)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1488, ptr %t1486, i64 %t1487, i1 false)
  %t1489 = insertvalue { i64, ptr } undef, i64 %t1485, 0
  %t1490 = insertvalue { i64, ptr } %t1489, ptr %t1488, 1
  %t1491 = load ptr, ptr %l621, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1491, { i64, ptr } { i64 3, ptr @.d420 }, { i64, ptr } { i64 1, ptr @.d421 }, { i64, ptr } %t1490, { i64, ptr } { i64 0, ptr @.d422 })
  br label %bb255
bb255:
  %t1493 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1493, ptr %l628, !tbaa !29
  %t1494 = load ptr, ptr %l0, !tbaa !29
  %t1495 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1496 = extractvalue { i64, ptr } { i64 42, ptr @.d423 }, 1
  %t1497 = extractvalue { i64, ptr } { i64 42, ptr @.d423 }, 0
  %t1499 = extractvalue { i64, ptr } %t1495, 1
  %t1500 = extractvalue { i64, ptr } %t1495, 0
  %t1501 = add i64 %t1497, %t1500
  %t1502 = extractvalue { i64, ptr } { i64 14, ptr @.d424 }, 1
  %t1503 = extractvalue { i64, ptr } { i64 14, ptr @.d424 }, 0
  %t1504 = add i64 %t1501, %t1503
  %t1505 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1504)
  call void @olang_textcopy(ptr %t1505, ptr %t1496, i64 %t1497)
  %t1506 = getelementptr i8, ptr %t1505, i64 %t1497
  call void @olang_textcopy(ptr %t1506, ptr %t1499, i64 %t1500)
  %t1507 = getelementptr i8, ptr %t1506, i64 %t1500
  call void @olang_textcopy(ptr %t1507, ptr %t1502, i64 %t1503)
  %t1508 = insertvalue { i64, ptr } undef, i64 %t1504, 0
  %t1509 = insertvalue { i64, ptr } %t1508, ptr %t1505, 1
  %t1511 = extractvalue { i64, ptr } %t1509, 0
  %t1512 = extractvalue { i64, ptr } %t1509, 1
  %t1513 = mul i64 %t1511, 1
  %t1514 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1513)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1514, ptr %t1512, i64 %t1513, i1 false)
  %t1515 = insertvalue { i64, ptr } undef, i64 %t1511, 0
  %t1516 = insertvalue { i64, ptr } %t1515, ptr %t1514, 1
  %t1519 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1494, { i64, ptr } %t1516)
  store { i64, ptr } %t1519, ptr %l633
  br label %bb256
bb256:
  %t1520 = load { i64, ptr }, ptr %l633, !tbaa !27
  %t1521 = extractvalue { i64, ptr } %t1520, 0
  %t1522 = extractvalue { i64, ptr } %t1520, 1
  %t1523 = mul i64 %t1521, 1
  %t1524 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1523)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1524, ptr %t1522, i64 %t1523, i1 false)
  %t1525 = insertvalue { i64, ptr } undef, i64 %t1521, 0
  %t1526 = insertvalue { i64, ptr } %t1525, ptr %t1524, 1
  %t1527 = load ptr, ptr %l628, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1527, { i64, ptr } { i64 3, ptr @.d425 }, { i64, ptr } { i64 1, ptr @.d426 }, { i64, ptr } %t1526, { i64, ptr } { i64 0, ptr @.d427 })
  br label %bb257
bb257:
  %t1529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1529, ptr %l635, !tbaa !29
  %t1530 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1530, ptr %l636, !tbaa !27
  %t1531 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1531, ptr %l637
  %t1532 = load i1, ptr %l8, !tbaa !21
  store i1 %t1532, ptr %l638, !tbaa !21
  %t1533 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t1533, ptr %l639, !tbaa !27
  %t1534 = load i32, ptr %l6, !tbaa !23
  store i32 %t1534, ptr %l640, !tbaa !23
  %t1535 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 2
  %t1536 = getelementptr %"compiler/mir:Range", ptr %t1535, i32 0, i32 1
  %t1537 = load i32, ptr %t1536, !tbaa !23
  %t1539 = sext i32 %t1537 to i64
  store i64 %t1539, ptr %l642, !tbaa !24
  %t1540 = load %"compiler/mir:Task", ptr %l2
  store %"compiler/mir:Task" %t1540, ptr %l643
  %t1541 = load ptr, ptr %l0, !tbaa !29
  %t1543 = getelementptr %"compiler/emit:fnEm", ptr %t1541, i32 0, i32 1
  %t1544 = load ptr, ptr %t1543, !tbaa !29
  %t1546 = getelementptr %"compiler/mir:Fn", ptr %t1544, i32 0, i32 8
  %t1547 = load i32, ptr %l1, !tbaa !23
  %t1549 = sext i32 %t1547 to i64
  %t1552 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t1546, i64 %t1549)
  store %"compiler/mir:ScopeInfo" %t1552, ptr %l649
  br label %bb258
bb258:
  %t1553 = getelementptr %"compiler/mir:ScopeInfo", ptr %l649, i32 0, i32 4
  %t1554 = load i32, ptr %t1553, !tbaa !23
  %t1555 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1556 = load ptr, ptr %l635, !tbaa !29
  %t1557 = load { i64, ptr }, ptr %l636, !tbaa !27
  %t1558 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l637
  %t1559 = load i1, ptr %l638, !tbaa !21
  %t1560 = load { i64, ptr }, ptr %l639, !tbaa !27
  %t1561 = load i32, ptr %l640, !tbaa !23
  %t1562 = load i64, ptr %l642, !tbaa !24
  %t1563 = load %"compiler/mir:Task", ptr %l643
  %t1566 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1556, { i64, ptr } %t1557, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1558, i1 %t1559, { i64, ptr } %t1560, i32 %t1561, i64 %t1562, %"compiler/mir:Task" %t1563, i32 %t1554, { i64, ptr } %t1555)
  store { i64, ptr } %t1566, ptr %l652
  br label %bb259
bb259:
  %t1567 = load { i64, ptr }, ptr %l652, !tbaa !27
  store { i64, ptr } %t1567, ptr %l86, !tbaa !27
  %t1568 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1568, { i64, ptr } { i64 18, ptr @.d428 }, { i64, ptr } { i64 25, ptr @.d429 })
  br label %bb260
bb260:
  %t1570 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1570, { i64, ptr } { i64 20, ptr @.d430 }, { i64, ptr } { i64 46, ptr @.d431 })
  br label %bb261
bb261:
  %t1572 = load ptr, ptr %l0, !tbaa !29
  %t1574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1572, { i64, ptr } { i64 30, ptr @.d432 })
  store { i64, ptr } %t1574, ptr %l656
  br label %bb262
bb262:
  %t1575 = load { i64, ptr }, ptr %l656, !tbaa !27
  %t1576 = load ptr, ptr %l0, !tbaa !29
  %t1578 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t1579 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1580 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1581 = extractvalue { i64, ptr } { i64 36, ptr @.d433 }, 1
  %t1582 = extractvalue { i64, ptr } { i64 36, ptr @.d433 }, 0
  %t1584 = extractvalue { i64, ptr } %t1575, 1
  %t1585 = extractvalue { i64, ptr } %t1575, 0
  %t1586 = add i64 %t1582, %t1585
  %t1587 = extractvalue { i64, ptr } { i64 7, ptr @.d434 }, 1
  %t1588 = extractvalue { i64, ptr } { i64 7, ptr @.d434 }, 0
  %t1589 = add i64 %t1586, %t1588
  %t1591 = extractvalue { i64, ptr } %t1578, 1
  %t1592 = extractvalue { i64, ptr } %t1578, 0
  %t1593 = add i64 %t1589, %t1592
  %t1594 = extractvalue { i64, ptr } { i64 6, ptr @.d435 }, 1
  %t1595 = extractvalue { i64, ptr } { i64 6, ptr @.d435 }, 0
  %t1596 = add i64 %t1593, %t1595
  %t1598 = extractvalue { i64, ptr } %t1579, 1
  %t1599 = extractvalue { i64, ptr } %t1579, 0
  %t1600 = add i64 %t1596, %t1599
  %t1601 = extractvalue { i64, ptr } { i64 6, ptr @.d436 }, 1
  %t1602 = extractvalue { i64, ptr } { i64 6, ptr @.d436 }, 0
  %t1603 = add i64 %t1600, %t1602
  %t1605 = extractvalue { i64, ptr } %t1580, 1
  %t1606 = extractvalue { i64, ptr } %t1580, 0
  %t1607 = add i64 %t1603, %t1606
  %t1608 = extractvalue { i64, ptr } { i64 1, ptr @.d437 }, 1
  %t1609 = extractvalue { i64, ptr } { i64 1, ptr @.d437 }, 0
  %t1610 = add i64 %t1607, %t1609
  %t1611 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1610)
  call void @olang_textcopy(ptr %t1611, ptr %t1581, i64 %t1582)
  %t1612 = getelementptr i8, ptr %t1611, i64 %t1582
  call void @olang_textcopy(ptr %t1612, ptr %t1584, i64 %t1585)
  %t1613 = getelementptr i8, ptr %t1612, i64 %t1585
  call void @olang_textcopy(ptr %t1613, ptr %t1587, i64 %t1588)
  %t1614 = getelementptr i8, ptr %t1613, i64 %t1588
  call void @olang_textcopy(ptr %t1614, ptr %t1591, i64 %t1592)
  %t1615 = getelementptr i8, ptr %t1614, i64 %t1592
  call void @olang_textcopy(ptr %t1615, ptr %t1594, i64 %t1595)
  %t1616 = getelementptr i8, ptr %t1615, i64 %t1595
  call void @olang_textcopy(ptr %t1616, ptr %t1598, i64 %t1599)
  %t1617 = getelementptr i8, ptr %t1616, i64 %t1599
  call void @olang_textcopy(ptr %t1617, ptr %t1601, i64 %t1602)
  %t1618 = getelementptr i8, ptr %t1617, i64 %t1602
  call void @olang_textcopy(ptr %t1618, ptr %t1605, i64 %t1606)
  %t1619 = getelementptr i8, ptr %t1618, i64 %t1606
  call void @olang_textcopy(ptr %t1619, ptr %t1608, i64 %t1609)
  %t1620 = insertvalue { i64, ptr } undef, i64 %t1610, 0
  %t1621 = insertvalue { i64, ptr } %t1620, ptr %t1611, 1
  %t1623 = extractvalue { i64, ptr } %t1621, 0
  %t1624 = extractvalue { i64, ptr } %t1621, 1
  %t1625 = mul i64 %t1623, 1
  %t1626 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1625)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1626, ptr %t1624, i64 %t1625, i1 false)
  %t1627 = insertvalue { i64, ptr } undef, i64 %t1623, 0
  %t1628 = insertvalue { i64, ptr } %t1627, ptr %t1626, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1576, { i64, ptr } %t1628)
  br label %bb263
bb263:
  %t1631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1631, ptr %l664, !tbaa !29
  %t1632 = load ptr, ptr %l0, !tbaa !29
  %t1633 = load i32, ptr %l1, !tbaa !23
  %t1634 = extractvalue { i64, ptr } { i64 3, ptr @.d438 }, 1
  %t1635 = extractvalue { i64, ptr } { i64 3, ptr @.d438 }, 0
  %t1637 = sext i32 %t1633 to i64
  %t1638 = call i64 @__olang_fmt_i64(ptr null, i64 %t1637)
  %t1639 = add i64 %t1635, %t1638
  %t1640 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1639)
  call void @olang_textcopy(ptr %t1640, ptr %t1634, i64 %t1635)
  %t1641 = getelementptr i8, ptr %t1640, i64 %t1635
  %t1642 = call i64 @__olang_fmt_i64(ptr %t1641, i64 %t1637)
  %t1643 = insertvalue { i64, ptr } undef, i64 %t1639, 0
  %t1644 = insertvalue { i64, ptr } %t1643, ptr %t1640, 1
  %t1646 = extractvalue { i64, ptr } %t1644, 0
  %t1647 = extractvalue { i64, ptr } %t1644, 1
  %t1648 = mul i64 %t1646, 1
  %t1649 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1648)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1649, ptr %t1647, i64 %t1648, i1 false)
  %t1650 = insertvalue { i64, ptr } undef, i64 %t1646, 0
  %t1651 = insertvalue { i64, ptr } %t1650, ptr %t1649, 1
  %t1654 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1632, { i64, ptr } { i64 3, ptr @.d439 }, { i64, ptr } %t1651, { i64, ptr } { i64 0, ptr @.d440 })
  store { i64, ptr } %t1654, ptr %l669
  br label %bb264
bb264:
  %t1655 = load { i64, ptr }, ptr %l669, !tbaa !27
  %t1656 = extractvalue { i64, ptr } %t1655, 0
  %t1657 = extractvalue { i64, ptr } %t1655, 1
  %t1658 = mul i64 %t1656, 1
  %t1659 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1658)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1659, ptr %t1657, i64 %t1658, i1 false)
  %t1660 = insertvalue { i64, ptr } undef, i64 %t1656, 0
  %t1661 = insertvalue { i64, ptr } %t1660, ptr %t1659, 1
  %t1662 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1663 = load ptr, ptr %l664, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1663, { i64, ptr } { i64 3, ptr @.d441 }, { i64, ptr } %t1661, { i64, ptr } %t1662, { i64, ptr } { i64 0, ptr @.d442 })
  br label %bb265
bb265:
  %t1666 = load ptr, ptr %l0, !tbaa !29
  %t1667 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1668 = load i32, ptr %l1, !tbaa !23
  %t1669 = extractvalue { i64, ptr } { i64 3, ptr @.d443 }, 1
  %t1670 = extractvalue { i64, ptr } { i64 3, ptr @.d443 }, 0
  %t1672 = sext i32 %t1668 to i64
  %t1673 = call i64 @__olang_fmt_i64(ptr null, i64 %t1672)
  %t1674 = add i64 %t1670, %t1673
  %t1675 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1674)
  call void @olang_textcopy(ptr %t1675, ptr %t1669, i64 %t1670)
  %t1676 = getelementptr i8, ptr %t1675, i64 %t1670
  %t1677 = call i64 @__olang_fmt_i64(ptr %t1676, i64 %t1672)
  %t1678 = insertvalue { i64, ptr } undef, i64 %t1674, 0
  %t1679 = insertvalue { i64, ptr } %t1678, ptr %t1675, 1
  %t1681 = extractvalue { i64, ptr } %t1679, 0
  %t1682 = extractvalue { i64, ptr } %t1679, 1
  %t1683 = mul i64 %t1681, 1
  %t1684 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1684, ptr %t1682, i64 %t1683, i1 false)
  %t1685 = insertvalue { i64, ptr } undef, i64 %t1681, 0
  %t1686 = insertvalue { i64, ptr } %t1685, ptr %t1684, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1666, { i64, ptr } { i64 3, ptr @.d444 }, { i64, ptr } %t1667, { i64, ptr } %t1686, { i64, ptr } { i64 0, ptr @.d445 })
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l26 = alloca i32
  %l29 = alloca i32
  %l51 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l63 = alloca %"compiler/mir:Place"
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca i32
  %l72 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l135 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Task" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  store i32 0, ptr %l8, !tbaa !23
  %t11 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr %l8, !tbaa !23
  %t19 = icmp sgt i32 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t23 = icmp sgt i32 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l26, !tbaa !23
  br label %bb6
bb3:
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr %l8, !tbaa !23
  %t29 = sub i32 %t25, %t26
  %t30 = load i32, ptr %l10, !tbaa !23
  %t33 = add i32 %t29, %t30
  %t35 = sub i32 %t33, 1
  %t36 = load i32, ptr %l10, !tbaa !23
  %t39 = sdiv i32 %t35, %t36
  store i32 %t39, ptr %l29, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l29, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l29, !tbaa !23
  store i32 %t41, ptr %l26, !tbaa !23
  br label %bb6
bb6:
  %t42 = load i32, ptr %l26, !tbaa !23
  store i32 %t42, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = load i32, ptr %l11, !tbaa !23
  %t47 = icmp slt i32 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t51 = load i32, ptr %l8, !tbaa !23
  %t52 = load i32, ptr %l12, !tbaa !23
  %t53 = load i32, ptr %l10, !tbaa !23
  %t56 = mul i32 %t52, %t53
  %t59 = add i32 %t51, %t56
  store i32 %t59, ptr %l13, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/mir:Task", ptr %l2
  %t63 = load i32, ptr %l13, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t69 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %t61, %"compiler/mir:Task" %t62, i64 %t65)
  store i1 %t69, ptr %l51
  br label %bb11
bb11:
  %t70 = load i1, ptr %l51, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb13:
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l7, !tbaa !29
  store ptr %t73, ptr %l53, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l54, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 13
  %t81 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t82 = getelementptr %"compiler/mir:Range", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i32, ptr %l13, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = add i64 %t85, %t88
  %t94 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t80, i64 %t91)
  store %"compiler/mir:Place" %t94, ptr %l63
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load %"compiler/mir:Place", ptr %l63
  %t97 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t95, %"compiler/mir:Place" %t96)
  store i32 %t97, ptr %l64
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l53, !tbaa !29
  %t99 = load i32, ptr %l64, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t100, ptr %l65
  br label %bb17
bb17:
  %t101 = load i32, ptr %l65, !tbaa !23
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t102, i32 %t101)
  store i32 %t106, ptr %l68
  br label %bb18
bb18:
  %t107 = load i32, ptr %l68, !tbaa !23
  store i32 %t107, ptr %l15, !tbaa !23
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l15, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l72
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t116, { i64, ptr } { i64 22, ptr @.d446 }, { i64, ptr } { i64 47, ptr @.d447 })
  br label %bb20
bb20:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = load i32, ptr %l13, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 3, ptr @.d448 }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr @.d448 }, 0
  %t123 = extractvalue { i64, ptr } %t118, 1
  %t124 = extractvalue { i64, ptr } %t118, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr @.d449 }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d449 }, 0
  %t128 = add i64 %t125, %t127
  %t130 = sext i32 %t119 to i64
  %t131 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %t130)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  store { i64, ptr } %t139, ptr %l16, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = load i32, ptr %l13, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 2, ptr @.d450 }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr @.d450 }, 0
  %t146 = extractvalue { i64, ptr } %t141, 1
  %t147 = extractvalue { i64, ptr } %t141, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d451 }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d451 }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = getelementptr i8, ptr %t158, i64 %t150
  %t160 = call i64 @__olang_fmt_i64(ptr %t159, i64 %t153)
  %t161 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t156, 1
  store { i64, ptr } %t162, ptr %l17, !tbaa !27
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t167 = load i32, ptr %l13, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t172 = add i64 %a3, %t169
  %t173 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t175 = extractvalue { i64, ptr } { i64 2, ptr @.d452 }, 1
  %t176 = extractvalue { i64, ptr } { i64 2, ptr @.d452 }, 0
  %t178 = extractvalue { i64, ptr } %t165, 1
  %t179 = extractvalue { i64, ptr } %t165, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 20, ptr @.d453 }, 1
  %t182 = extractvalue { i64, ptr } { i64 20, ptr @.d453 }, 0
  %t183 = add i64 %t180, %t182
  %t185 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t186 = add i64 %t183, %t185
  %t187 = extractvalue { i64, ptr } { i64 3, ptr @.d454 }, 1
  %t188 = extractvalue { i64, ptr } { i64 3, ptr @.d454 }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t173, 1
  %t192 = extractvalue { i64, ptr } %t173, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 27, ptr @.d455 }, 1
  %t195 = extractvalue { i64, ptr } { i64 27, ptr @.d455 }, 0
  %t196 = add i64 %t193, %t195
  %t198 = extractvalue { i64, ptr } %t174, 1
  %t199 = extractvalue { i64, ptr } %t174, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 2, ptr @.d456 }, 1
  %t202 = extractvalue { i64, ptr } { i64 2, ptr @.d456 }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t175, i64 %t176)
  %t205 = getelementptr i8, ptr %t204, i64 %t176
  call void @olang_textcopy(ptr %t205, ptr %t178, i64 %t179)
  %t206 = getelementptr i8, ptr %t205, i64 %t179
  call void @olang_textcopy(ptr %t206, ptr %t181, i64 %t182)
  %t207 = getelementptr i8, ptr %t206, i64 %t182
  %t208 = call i64 @__olang_fmt_i64(ptr %t207, i64 %t172)
  %t209 = getelementptr i8, ptr %t207, i64 %t185
  call void @olang_textcopy(ptr %t209, ptr %t187, i64 %t188)
  %t210 = getelementptr i8, ptr %t209, i64 %t188
  call void @olang_textcopy(ptr %t210, ptr %t191, i64 %t192)
  %t211 = getelementptr i8, ptr %t210, i64 %t192
  call void @olang_textcopy(ptr %t211, ptr %t194, i64 %t195)
  %t212 = getelementptr i8, ptr %t211, i64 %t195
  call void @olang_textcopy(ptr %t212, ptr %t198, i64 %t199)
  %t213 = getelementptr i8, ptr %t212, i64 %t199
  call void @olang_textcopy(ptr %t213, ptr %t201, i64 %t202)
  %t214 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t204, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = extractvalue { i64, ptr } %t215, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t164, { i64, ptr } %t222)
  br label %bb21
bb21:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } { i64 2, ptr @.d457 }, 1
  %t231 = extractvalue { i64, ptr } { i64 2, ptr @.d457 }, 0
  %t233 = extractvalue { i64, ptr } %t226, 1
  %t234 = extractvalue { i64, ptr } %t226, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 30, ptr @.d458 }, 1
  %t237 = extractvalue { i64, ptr } { i64 30, ptr @.d458 }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t227, 1
  %t241 = extractvalue { i64, ptr } %t227, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 7, ptr @.d459 }, 1
  %t244 = extractvalue { i64, ptr } { i64 7, ptr @.d459 }, 0
  %t245 = add i64 %t242, %t244
  %t247 = extractvalue { i64, ptr } %t228, 1
  %t248 = extractvalue { i64, ptr } %t228, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 30, ptr @.d460 }, 1
  %t251 = extractvalue { i64, ptr } { i64 30, ptr @.d460 }, 0
  %t252 = add i64 %t249, %t251
  %t254 = extractvalue { i64, ptr } %t229, 1
  %t255 = extractvalue { i64, ptr } %t229, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 5, ptr @.d461 }, 1
  %t258 = extractvalue { i64, ptr } { i64 5, ptr @.d461 }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t230, i64 %t231)
  %t261 = getelementptr i8, ptr %t260, i64 %t231
  call void @olang_textcopy(ptr %t261, ptr %t233, i64 %t234)
  %t262 = getelementptr i8, ptr %t261, i64 %t234
  call void @olang_textcopy(ptr %t262, ptr %t236, i64 %t237)
  %t263 = getelementptr i8, ptr %t262, i64 %t237
  call void @olang_textcopy(ptr %t263, ptr %t240, i64 %t241)
  %t264 = getelementptr i8, ptr %t263, i64 %t241
  call void @olang_textcopy(ptr %t264, ptr %t243, i64 %t244)
  %t265 = getelementptr i8, ptr %t264, i64 %t244
  call void @olang_textcopy(ptr %t265, ptr %t247, i64 %t248)
  %t266 = getelementptr i8, ptr %t265, i64 %t248
  call void @olang_textcopy(ptr %t266, ptr %t250, i64 %t251)
  %t267 = getelementptr i8, ptr %t266, i64 %t251
  call void @olang_textcopy(ptr %t267, ptr %t254, i64 %t255)
  %t268 = getelementptr i8, ptr %t267, i64 %t255
  call void @olang_textcopy(ptr %t268, ptr %t257, i64 %t258)
  %t269 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t260, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = extractvalue { i64, ptr } %t270, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t225, { i64, ptr } %t277)
  br label %bb22
bb22:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t282 = load i32, ptr %l13, !tbaa !23
  %t283 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t284 = load i32, ptr %l13, !tbaa !23
  %t285 = extractvalue { i64, ptr } { i64 2, ptr @.d462 }, 1
  %t286 = extractvalue { i64, ptr } { i64 2, ptr @.d462 }, 0
  %t288 = extractvalue { i64, ptr } %t281, 1
  %t289 = extractvalue { i64, ptr } %t281, 0
  %t290 = add i64 %t286, %t289
  %t291 = extractvalue { i64, ptr } { i64 35, ptr @.d463 }, 1
  %t292 = extractvalue { i64, ptr } { i64 35, ptr @.d463 }, 0
  %t293 = add i64 %t290, %t292
  %t295 = sext i32 %t282 to i64
  %t296 = call i64 @__olang_fmt_i64(ptr null, i64 %t295)
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 6, ptr @.d464 }, 1
  %t299 = extractvalue { i64, ptr } { i64 6, ptr @.d464 }, 0
  %t300 = add i64 %t297, %t299
  %t302 = extractvalue { i64, ptr } %t283, 1
  %t303 = extractvalue { i64, ptr } %t283, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 35, ptr @.d465 }, 1
  %t306 = extractvalue { i64, ptr } { i64 35, ptr @.d465 }, 0
  %t307 = add i64 %t304, %t306
  %t309 = sext i32 %t284 to i64
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t309)
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 4, ptr @.d466 }, 1
  %t313 = extractvalue { i64, ptr } { i64 4, ptr @.d466 }, 0
  %t314 = add i64 %t311, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t285, i64 %t286)
  %t316 = getelementptr i8, ptr %t315, i64 %t286
  call void @olang_textcopy(ptr %t316, ptr %t288, i64 %t289)
  %t317 = getelementptr i8, ptr %t316, i64 %t289
  call void @olang_textcopy(ptr %t317, ptr %t291, i64 %t292)
  %t318 = getelementptr i8, ptr %t317, i64 %t292
  %t319 = call i64 @__olang_fmt_i64(ptr %t318, i64 %t295)
  %t320 = getelementptr i8, ptr %t318, i64 %t296
  call void @olang_textcopy(ptr %t320, ptr %t298, i64 %t299)
  %t321 = getelementptr i8, ptr %t320, i64 %t299
  call void @olang_textcopy(ptr %t321, ptr %t302, i64 %t303)
  %t322 = getelementptr i8, ptr %t321, i64 %t303
  call void @olang_textcopy(ptr %t322, ptr %t305, i64 %t306)
  %t323 = getelementptr i8, ptr %t322, i64 %t306
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t309)
  %t325 = getelementptr i8, ptr %t323, i64 %t310
  call void @olang_textcopy(ptr %t325, ptr %t312, i64 %t313)
  %t326 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t315, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = extractvalue { i64, ptr } %t327, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t280, { i64, ptr } %t334)
  br label %bb23
bb23:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l104, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t338, ptr %l105, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t339, ptr %l106, !tbaa !27
  %t340 = load ptr, ptr %l7, !tbaa !29
  %t341 = load i32, ptr %l15, !tbaa !23
  %t344 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t340, i32 %t341)
  store i64 %t344, ptr %l109
  br label %bb24
bb24:
  %t345 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t348 = extractvalue { i64, ptr } { i64 2, ptr @.d467 }, 1
  %t349 = extractvalue { i64, ptr } { i64 2, ptr @.d467 }, 0
  %t350 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = add i64 %t349, %t352
  %t354 = extractvalue { i64, ptr } { i64 12, ptr @.d468 }, 1
  %t355 = extractvalue { i64, ptr } { i64 12, ptr @.d468 }, 0
  %t356 = add i64 %t353, %t355
  %t357 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 1
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = add i64 %t356, %t359
  %t361 = extractvalue { i64, ptr } { i64 3, ptr @.d469 }, 1
  %t362 = extractvalue { i64, ptr } { i64 3, ptr @.d469 }, 0
  %t363 = add i64 %t360, %t362
  %t364 = load i64, ptr %l109, !tbaa !24
  %t365 = call i64 @__olang_fmt_i64(ptr null, i64 %t364)
  %t366 = add i64 %t363, %t365
  %t367 = extractvalue { i64, ptr } { i64 3, ptr @.d470 }, 1
  %t368 = extractvalue { i64, ptr } { i64 3, ptr @.d470 }, 0
  %t369 = add i64 %t366, %t368
  %t371 = extractvalue { i64, ptr } %t345, 1
  %t372 = extractvalue { i64, ptr } %t345, 0
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 16, ptr @.d471 }, 1
  %t375 = extractvalue { i64, ptr } { i64 16, ptr @.d471 }, 0
  %t376 = add i64 %t373, %t375
  %t378 = extractvalue { i64, ptr } %t346, 1
  %t379 = extractvalue { i64, ptr } %t346, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 3, ptr @.d472 }, 1
  %t382 = extractvalue { i64, ptr } { i64 3, ptr @.d472 }, 0
  %t383 = add i64 %t380, %t382
  %t385 = extractvalue { i64, ptr } %t347, 1
  %t386 = extractvalue { i64, ptr } %t347, 0
  %t387 = add i64 %t383, %t386
  %t388 = extractvalue { i64, ptr } { i64 3, ptr @.d473 }, 1
  %t389 = extractvalue { i64, ptr } { i64 3, ptr @.d473 }, 0
  %t390 = add i64 %t387, %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t348, i64 %t349)
  %t392 = getelementptr i8, ptr %t391, i64 %t349
  call void @olang_textcopy(ptr %t392, ptr %t351, i64 %t352)
  %t393 = getelementptr i8, ptr %t392, i64 %t352
  call void @olang_textcopy(ptr %t393, ptr %t354, i64 %t355)
  %t394 = getelementptr i8, ptr %t393, i64 %t355
  call void @olang_textcopy(ptr %t394, ptr %t358, i64 %t359)
  %t395 = getelementptr i8, ptr %t394, i64 %t359
  call void @olang_textcopy(ptr %t395, ptr %t361, i64 %t362)
  %t396 = getelementptr i8, ptr %t395, i64 %t362
  %t397 = call i64 @__olang_fmt_i64(ptr %t396, i64 %t364)
  %t398 = getelementptr i8, ptr %t396, i64 %t365
  call void @olang_textcopy(ptr %t398, ptr %t367, i64 %t368)
  %t399 = getelementptr i8, ptr %t398, i64 %t368
  call void @olang_textcopy(ptr %t399, ptr %t371, i64 %t372)
  %t400 = getelementptr i8, ptr %t399, i64 %t372
  call void @olang_textcopy(ptr %t400, ptr %t374, i64 %t375)
  %t401 = getelementptr i8, ptr %t400, i64 %t375
  call void @olang_textcopy(ptr %t401, ptr %t378, i64 %t379)
  %t402 = getelementptr i8, ptr %t401, i64 %t379
  call void @olang_textcopy(ptr %t402, ptr %t381, i64 %t382)
  %t403 = getelementptr i8, ptr %t402, i64 %t382
  call void @olang_textcopy(ptr %t403, ptr %t385, i64 %t386)
  %t404 = getelementptr i8, ptr %t403, i64 %t386
  call void @olang_textcopy(ptr %t404, ptr %t388, i64 %t389)
  %t405 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t391, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } %t406, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t414 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t414, { i64, ptr } %t413)
  br label %bb25
bb25:
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t421 = extractvalue { i64, ptr } { i64 8, ptr @.d474 }, 1
  %t422 = extractvalue { i64, ptr } { i64 8, ptr @.d474 }, 0
  %t424 = extractvalue { i64, ptr } %t417, 1
  %t425 = extractvalue { i64, ptr } %t417, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 10, ptr @.d475 }, 1
  %t428 = extractvalue { i64, ptr } { i64 10, ptr @.d475 }, 0
  %t429 = add i64 %t426, %t428
  %t431 = extractvalue { i64, ptr } %t418, 1
  %t432 = extractvalue { i64, ptr } %t418, 0
  %t433 = add i64 %t429, %t432
  %t434 = extractvalue { i64, ptr } { i64 10, ptr @.d476 }, 1
  %t435 = extractvalue { i64, ptr } { i64 10, ptr @.d476 }, 0
  %t436 = add i64 %t433, %t435
  %t438 = extractvalue { i64, ptr } %t419, 1
  %t439 = extractvalue { i64, ptr } %t419, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 2, ptr @.d477 }, 1
  %t442 = extractvalue { i64, ptr } { i64 2, ptr @.d477 }, 0
  %t443 = add i64 %t440, %t442
  %t445 = extractvalue { i64, ptr } %t420, 1
  %t446 = extractvalue { i64, ptr } %t420, 0
  %t447 = add i64 %t443, %t446
  %t448 = extractvalue { i64, ptr } { i64 3, ptr @.d478 }, 1
  %t449 = extractvalue { i64, ptr } { i64 3, ptr @.d478 }, 0
  %t450 = add i64 %t447, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t421, i64 %t422)
  %t452 = getelementptr i8, ptr %t451, i64 %t422
  call void @olang_textcopy(ptr %t452, ptr %t424, i64 %t425)
  %t453 = getelementptr i8, ptr %t452, i64 %t425
  call void @olang_textcopy(ptr %t453, ptr %t427, i64 %t428)
  %t454 = getelementptr i8, ptr %t453, i64 %t428
  call void @olang_textcopy(ptr %t454, ptr %t431, i64 %t432)
  %t455 = getelementptr i8, ptr %t454, i64 %t432
  call void @olang_textcopy(ptr %t455, ptr %t434, i64 %t435)
  %t456 = getelementptr i8, ptr %t455, i64 %t435
  call void @olang_textcopy(ptr %t456, ptr %t438, i64 %t439)
  %t457 = getelementptr i8, ptr %t456, i64 %t439
  call void @olang_textcopy(ptr %t457, ptr %t441, i64 %t442)
  %t458 = getelementptr i8, ptr %t457, i64 %t442
  call void @olang_textcopy(ptr %t458, ptr %t445, i64 %t446)
  %t459 = getelementptr i8, ptr %t458, i64 %t446
  call void @olang_textcopy(ptr %t459, ptr %t448, i64 %t449)
  %t460 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t451, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = extractvalue { i64, ptr } %t461, 1
  %t465 = mul i64 %t463, 1
  %t466 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t465)
  call void @llvm.memcpy.p0.p0.i64(ptr %t466, ptr %t464, i64 %t465, i1 false)
  %t467 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t416, { i64, ptr } %t468)
  br label %bb26
bb26:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t474 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t475 = extractvalue { i64, ptr } { i64 40, ptr @.d479 }, 1
  %t476 = extractvalue { i64, ptr } { i64 40, ptr @.d479 }, 0
  %t478 = extractvalue { i64, ptr } %t472, 1
  %t479 = extractvalue { i64, ptr } %t472, 0
  %t480 = add i64 %t476, %t479
  %t481 = extractvalue { i64, ptr } { i64 8, ptr @.d480 }, 1
  %t482 = extractvalue { i64, ptr } { i64 8, ptr @.d480 }, 0
  %t483 = add i64 %t480, %t482
  %t485 = extractvalue { i64, ptr } %t473, 1
  %t486 = extractvalue { i64, ptr } %t473, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 7, ptr @.d481 }, 1
  %t489 = extractvalue { i64, ptr } { i64 7, ptr @.d481 }, 0
  %t490 = add i64 %t487, %t489
  %t492 = extractvalue { i64, ptr } %t474, 1
  %t493 = extractvalue { i64, ptr } %t474, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 13, ptr @.d482 }, 1
  %t496 = extractvalue { i64, ptr } { i64 13, ptr @.d482 }, 0
  %t497 = add i64 %t494, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t475, i64 %t476)
  %t499 = getelementptr i8, ptr %t498, i64 %t476
  call void @olang_textcopy(ptr %t499, ptr %t478, i64 %t479)
  %t500 = getelementptr i8, ptr %t499, i64 %t479
  call void @olang_textcopy(ptr %t500, ptr %t481, i64 %t482)
  %t501 = getelementptr i8, ptr %t500, i64 %t482
  call void @olang_textcopy(ptr %t501, ptr %t485, i64 %t486)
  %t502 = getelementptr i8, ptr %t501, i64 %t486
  call void @olang_textcopy(ptr %t502, ptr %t488, i64 %t489)
  %t503 = getelementptr i8, ptr %t502, i64 %t489
  call void @olang_textcopy(ptr %t503, ptr %t492, i64 %t493)
  %t504 = getelementptr i8, ptr %t503, i64 %t493
  call void @olang_textcopy(ptr %t504, ptr %t495, i64 %t496)
  %t505 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t498, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t471, { i64, ptr } %t513)
  br label %bb27
bb27:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t517 = load i32, ptr %l13, !tbaa !23
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t520 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t521 = extractvalue { i64, ptr } { i64 25, ptr @.d483 }, 1
  %t522 = extractvalue { i64, ptr } { i64 25, ptr @.d483 }, 0
  %t524 = sext i32 %t517 to i64
  %t525 = call i64 @__olang_fmt_i64(ptr null, i64 %t524)
  %t526 = add i64 %t522, %t525
  %t527 = extractvalue { i64, ptr } { i64 6, ptr @.d484 }, 1
  %t528 = extractvalue { i64, ptr } { i64 6, ptr @.d484 }, 0
  %t529 = add i64 %t526, %t528
  %t531 = extractvalue { i64, ptr } %t518, 1
  %t532 = extractvalue { i64, ptr } %t518, 0
  %t533 = add i64 %t529, %t532
  %t534 = extractvalue { i64, ptr } { i64 14, ptr @.d485 }, 1
  %t535 = extractvalue { i64, ptr } { i64 14, ptr @.d485 }, 0
  %t536 = add i64 %t533, %t535
  %t538 = extractvalue { i64, ptr } %t519, 1
  %t539 = extractvalue { i64, ptr } %t519, 0
  %t540 = add i64 %t536, %t539
  %t541 = extractvalue { i64, ptr } { i64 2, ptr @.d486 }, 1
  %t542 = extractvalue { i64, ptr } { i64 2, ptr @.d486 }, 0
  %t543 = add i64 %t540, %t542
  %t545 = extractvalue { i64, ptr } %t520, 1
  %t546 = extractvalue { i64, ptr } %t520, 0
  %t547 = add i64 %t543, %t546
  %t548 = extractvalue { i64, ptr } { i64 3, ptr @.d487 }, 1
  %t549 = extractvalue { i64, ptr } { i64 3, ptr @.d487 }, 0
  %t550 = add i64 %t547, %t549
  %t551 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t521, i64 %t522)
  %t552 = getelementptr i8, ptr %t551, i64 %t522
  %t553 = call i64 @__olang_fmt_i64(ptr %t552, i64 %t524)
  %t554 = getelementptr i8, ptr %t552, i64 %t525
  call void @olang_textcopy(ptr %t554, ptr %t527, i64 %t528)
  %t555 = getelementptr i8, ptr %t554, i64 %t528
  call void @olang_textcopy(ptr %t555, ptr %t531, i64 %t532)
  %t556 = getelementptr i8, ptr %t555, i64 %t532
  call void @olang_textcopy(ptr %t556, ptr %t534, i64 %t535)
  %t557 = getelementptr i8, ptr %t556, i64 %t535
  call void @olang_textcopy(ptr %t557, ptr %t538, i64 %t539)
  %t558 = getelementptr i8, ptr %t557, i64 %t539
  call void @olang_textcopy(ptr %t558, ptr %t541, i64 %t542)
  %t559 = getelementptr i8, ptr %t558, i64 %t542
  call void @olang_textcopy(ptr %t559, ptr %t545, i64 %t546)
  %t560 = getelementptr i8, ptr %t559, i64 %t546
  call void @olang_textcopy(ptr %t560, ptr %t548, i64 %t549)
  %t561 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t551, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t516, { i64, ptr } %t569)
  br label %bb28
bb28:
  %t572 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t572, ptr %l135, !tbaa !27
  %t573 = load i32, ptr %l13, !tbaa !23
  %t575 = sext i32 %t573 to i64
  %t576 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i64, ptr %t577, i64 %t575
  %t579 = load i64, ptr %t578, !tbaa !34
  %t581 = icmp sge i64 %t579, 0
  br i1 %t581, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t583 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s13, ptr %t583, { i64, ptr } { i64 19, ptr @.d488 })
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t585 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s13, ptr %s13, ptr %t585, { i64, ptr } { i64 18, ptr @.d489 }, { i64, ptr } { i64 67, ptr @.d490 })
  br label %bb32
bb32:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t589, ptr %l143, !tbaa !27
  %t590 = load i32, ptr %l13, !tbaa !23
  %t592 = sext i32 %t590 to i64
  %t593 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr i64, ptr %t594, i64 %t592
  %t596 = load i64, ptr %t595, !tbaa !34
  %t597 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t599 = extractvalue { i64, ptr } { i64 2, ptr @.d491 }, 1
  %t600 = extractvalue { i64, ptr } { i64 2, ptr @.d491 }, 0
  %t602 = extractvalue { i64, ptr } %t588, 1
  %t603 = extractvalue { i64, ptr } %t588, 0
  %t604 = add i64 %t600, %t603
  %t605 = extractvalue { i64, ptr } { i64 20, ptr @.d492 }, 1
  %t606 = extractvalue { i64, ptr } { i64 20, ptr @.d492 }, 0
  %t607 = add i64 %t604, %t606
  %t609 = call i64 @__olang_fmt_i64(ptr null, i64 %t596)
  %t610 = add i64 %t607, %t609
  %t611 = extractvalue { i64, ptr } { i64 3, ptr @.d493 }, 1
  %t612 = extractvalue { i64, ptr } { i64 3, ptr @.d493 }, 0
  %t613 = add i64 %t610, %t612
  %t615 = extractvalue { i64, ptr } %t597, 1
  %t616 = extractvalue { i64, ptr } %t597, 0
  %t617 = add i64 %t613, %t616
  %t618 = extractvalue { i64, ptr } { i64 16, ptr @.d494 }, 1
  %t619 = extractvalue { i64, ptr } { i64 16, ptr @.d494 }, 0
  %t620 = add i64 %t617, %t619
  %t622 = extractvalue { i64, ptr } %t598, 1
  %t623 = extractvalue { i64, ptr } %t598, 0
  %t624 = add i64 %t620, %t623
  %t625 = extractvalue { i64, ptr } { i64 8, ptr @.d495 }, 1
  %t626 = extractvalue { i64, ptr } { i64 8, ptr @.d495 }, 0
  %t627 = add i64 %t624, %t626
  %t628 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t627)
  call void @olang_textcopy(ptr %t628, ptr %t599, i64 %t600)
  %t629 = getelementptr i8, ptr %t628, i64 %t600
  call void @olang_textcopy(ptr %t629, ptr %t602, i64 %t603)
  %t630 = getelementptr i8, ptr %t629, i64 %t603
  call void @olang_textcopy(ptr %t630, ptr %t605, i64 %t606)
  %t631 = getelementptr i8, ptr %t630, i64 %t606
  %t632 = call i64 @__olang_fmt_i64(ptr %t631, i64 %t596)
  %t633 = getelementptr i8, ptr %t631, i64 %t609
  call void @olang_textcopy(ptr %t633, ptr %t611, i64 %t612)
  %t634 = getelementptr i8, ptr %t633, i64 %t612
  call void @olang_textcopy(ptr %t634, ptr %t615, i64 %t616)
  %t635 = getelementptr i8, ptr %t634, i64 %t616
  call void @olang_textcopy(ptr %t635, ptr %t618, i64 %t619)
  %t636 = getelementptr i8, ptr %t635, i64 %t619
  call void @olang_textcopy(ptr %t636, ptr %t622, i64 %t623)
  %t637 = getelementptr i8, ptr %t636, i64 %t623
  call void @olang_textcopy(ptr %t637, ptr %t625, i64 %t626)
  %t638 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t639 = insertvalue { i64, ptr } %t638, ptr %t628, 1
  %t641 = extractvalue { i64, ptr } %t639, 0
  %t642 = extractvalue { i64, ptr } %t639, 1
  %t643 = mul i64 %t641, 1
  %t644 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t643)
  call void @llvm.memcpy.p0.p0.i64(ptr %t644, ptr %t642, i64 %t643, i1 false)
  %t645 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t587, { i64, ptr } %t646)
  br label %bb33
bb33:
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t650 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t652 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t653 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t654 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t655 = extractvalue { i64, ptr } { i64 2, ptr @.d496 }, 1
  %t656 = extractvalue { i64, ptr } { i64 2, ptr @.d496 }, 0
  %t658 = extractvalue { i64, ptr } %t650, 1
  %t659 = extractvalue { i64, ptr } %t650, 0
  %t660 = add i64 %t656, %t659
  %t661 = extractvalue { i64, ptr } { i64 40, ptr @.d497 }, 1
  %t662 = extractvalue { i64, ptr } { i64 40, ptr @.d497 }, 0
  %t663 = add i64 %t660, %t662
  %t665 = extractvalue { i64, ptr } %t651, 1
  %t666 = extractvalue { i64, ptr } %t651, 0
  %t667 = add i64 %t663, %t666
  %t668 = extractvalue { i64, ptr } { i64 14, ptr @.d498 }, 1
  %t669 = extractvalue { i64, ptr } { i64 14, ptr @.d498 }, 0
  %t670 = add i64 %t667, %t669
  %t672 = extractvalue { i64, ptr } %t652, 1
  %t673 = extractvalue { i64, ptr } %t652, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 7, ptr @.d499 }, 1
  %t676 = extractvalue { i64, ptr } { i64 7, ptr @.d499 }, 0
  %t677 = add i64 %t674, %t676
  %t679 = extractvalue { i64, ptr } %t653, 1
  %t680 = extractvalue { i64, ptr } %t653, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 7, ptr @.d500 }, 1
  %t683 = extractvalue { i64, ptr } { i64 7, ptr @.d500 }, 0
  %t684 = add i64 %t681, %t683
  %t686 = extractvalue { i64, ptr } %t654, 1
  %t687 = extractvalue { i64, ptr } %t654, 0
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 2, ptr @.d501 }, 1
  %t690 = extractvalue { i64, ptr } { i64 2, ptr @.d501 }, 0
  %t691 = add i64 %t688, %t690
  %t692 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t691)
  call void @olang_textcopy(ptr %t692, ptr %t655, i64 %t656)
  %t693 = getelementptr i8, ptr %t692, i64 %t656
  call void @olang_textcopy(ptr %t693, ptr %t658, i64 %t659)
  %t694 = getelementptr i8, ptr %t693, i64 %t659
  call void @olang_textcopy(ptr %t694, ptr %t661, i64 %t662)
  %t695 = getelementptr i8, ptr %t694, i64 %t662
  call void @olang_textcopy(ptr %t695, ptr %t665, i64 %t666)
  %t696 = getelementptr i8, ptr %t695, i64 %t666
  call void @olang_textcopy(ptr %t696, ptr %t668, i64 %t669)
  %t697 = getelementptr i8, ptr %t696, i64 %t669
  call void @olang_textcopy(ptr %t697, ptr %t672, i64 %t673)
  %t698 = getelementptr i8, ptr %t697, i64 %t673
  call void @olang_textcopy(ptr %t698, ptr %t675, i64 %t676)
  %t699 = getelementptr i8, ptr %t698, i64 %t676
  call void @olang_textcopy(ptr %t699, ptr %t679, i64 %t680)
  %t700 = getelementptr i8, ptr %t699, i64 %t680
  call void @olang_textcopy(ptr %t700, ptr %t682, i64 %t683)
  %t701 = getelementptr i8, ptr %t700, i64 %t683
  call void @olang_textcopy(ptr %t701, ptr %t686, i64 %t687)
  %t702 = getelementptr i8, ptr %t701, i64 %t687
  call void @olang_textcopy(ptr %t702, ptr %t689, i64 %t690)
  %t703 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t692, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = extractvalue { i64, ptr } %t704, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t649, { i64, ptr } %t711)
  br label %bb34
bb34:
  %t714 = load ptr, ptr %l1, !tbaa !29
  %t715 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t717 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t718 = extractvalue { i64, ptr } { i64 2, ptr @.d502 }, 1
  %t719 = extractvalue { i64, ptr } { i64 2, ptr @.d502 }, 0
  %t721 = extractvalue { i64, ptr } %t715, 1
  %t722 = extractvalue { i64, ptr } %t715, 0
  %t723 = add i64 %t719, %t722
  %t724 = extractvalue { i64, ptr } { i64 38, ptr @.d503 }, 1
  %t725 = extractvalue { i64, ptr } { i64 38, ptr @.d503 }, 0
  %t726 = add i64 %t723, %t725
  %t728 = extractvalue { i64, ptr } %t716, 1
  %t729 = extractvalue { i64, ptr } %t716, 0
  %t730 = add i64 %t726, %t729
  %t731 = extractvalue { i64, ptr } { i64 7, ptr @.d504 }, 1
  %t732 = extractvalue { i64, ptr } { i64 7, ptr @.d504 }, 0
  %t733 = add i64 %t730, %t732
  %t735 = extractvalue { i64, ptr } %t717, 1
  %t736 = extractvalue { i64, ptr } %t717, 0
  %t737 = add i64 %t733, %t736
  %t738 = extractvalue { i64, ptr } { i64 3, ptr @.d505 }, 1
  %t739 = extractvalue { i64, ptr } { i64 3, ptr @.d505 }, 0
  %t740 = add i64 %t737, %t739
  %t741 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t740)
  call void @olang_textcopy(ptr %t741, ptr %t718, i64 %t719)
  %t742 = getelementptr i8, ptr %t741, i64 %t719
  call void @olang_textcopy(ptr %t742, ptr %t721, i64 %t722)
  %t743 = getelementptr i8, ptr %t742, i64 %t722
  call void @olang_textcopy(ptr %t743, ptr %t724, i64 %t725)
  %t744 = getelementptr i8, ptr %t743, i64 %t725
  call void @olang_textcopy(ptr %t744, ptr %t728, i64 %t729)
  %t745 = getelementptr i8, ptr %t744, i64 %t729
  call void @olang_textcopy(ptr %t745, ptr %t731, i64 %t732)
  %t746 = getelementptr i8, ptr %t745, i64 %t732
  call void @olang_textcopy(ptr %t746, ptr %t735, i64 %t736)
  %t747 = getelementptr i8, ptr %t746, i64 %t736
  call void @olang_textcopy(ptr %t747, ptr %t738, i64 %t739)
  %t748 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t749 = insertvalue { i64, ptr } %t748, ptr %t741, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = extractvalue { i64, ptr } %t749, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t714, { i64, ptr } %t756)
  br label %bb35
bb35:
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t760 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t761 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t762 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t763 = extractvalue { i64, ptr } { i64 40, ptr @.d506 }, 1
  %t764 = extractvalue { i64, ptr } { i64 40, ptr @.d506 }, 0
  %t766 = extractvalue { i64, ptr } %t760, 1
  %t767 = extractvalue { i64, ptr } %t760, 0
  %t768 = add i64 %t764, %t767
  %t769 = extractvalue { i64, ptr } { i64 7, ptr @.d507 }, 1
  %t770 = extractvalue { i64, ptr } { i64 7, ptr @.d507 }, 0
  %t771 = add i64 %t768, %t770
  %t773 = extractvalue { i64, ptr } %t761, 1
  %t774 = extractvalue { i64, ptr } %t761, 0
  %t775 = add i64 %t771, %t774
  %t776 = extractvalue { i64, ptr } { i64 7, ptr @.d508 }, 1
  %t777 = extractvalue { i64, ptr } { i64 7, ptr @.d508 }, 0
  %t778 = add i64 %t775, %t777
  %t780 = extractvalue { i64, ptr } %t762, 1
  %t781 = extractvalue { i64, ptr } %t762, 0
  %t782 = add i64 %t778, %t781
  %t783 = extractvalue { i64, ptr } { i64 13, ptr @.d509 }, 1
  %t784 = extractvalue { i64, ptr } { i64 13, ptr @.d509 }, 0
  %t785 = add i64 %t782, %t784
  %t786 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t785)
  call void @olang_textcopy(ptr %t786, ptr %t763, i64 %t764)
  %t787 = getelementptr i8, ptr %t786, i64 %t764
  call void @olang_textcopy(ptr %t787, ptr %t766, i64 %t767)
  %t788 = getelementptr i8, ptr %t787, i64 %t767
  call void @olang_textcopy(ptr %t788, ptr %t769, i64 %t770)
  %t789 = getelementptr i8, ptr %t788, i64 %t770
  call void @olang_textcopy(ptr %t789, ptr %t773, i64 %t774)
  %t790 = getelementptr i8, ptr %t789, i64 %t774
  call void @olang_textcopy(ptr %t790, ptr %t776, i64 %t777)
  %t791 = getelementptr i8, ptr %t790, i64 %t777
  call void @olang_textcopy(ptr %t791, ptr %t780, i64 %t781)
  %t792 = getelementptr i8, ptr %t791, i64 %t781
  call void @olang_textcopy(ptr %t792, ptr %t783, i64 %t784)
  %t793 = insertvalue { i64, ptr } undef, i64 %t785, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t786, 1
  %t796 = extractvalue { i64, ptr } %t794, 0
  %t797 = extractvalue { i64, ptr } %t794, 1
  %t798 = mul i64 %t796, 1
  %t799 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t798)
  call void @llvm.memcpy.p0.p0.i64(ptr %t799, ptr %t797, i64 %t798, i1 false)
  %t800 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr %t799, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t759, { i64, ptr } %t801)
  br label %bb36
bb36:
  %t804 = load ptr, ptr %l1, !tbaa !29
  %t805 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t806 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t807 = extractvalue { i64, ptr } { i64 2, ptr @.d510 }, 1
  %t808 = extractvalue { i64, ptr } { i64 2, ptr @.d510 }, 0
  %t810 = extractvalue { i64, ptr } %t805, 1
  %t811 = extractvalue { i64, ptr } %t805, 0
  %t812 = add i64 %t808, %t811
  %t813 = extractvalue { i64, ptr } { i64 40, ptr @.d511 }, 1
  %t814 = extractvalue { i64, ptr } { i64 40, ptr @.d511 }, 0
  %t815 = add i64 %t812, %t814
  %t817 = extractvalue { i64, ptr } %t806, 1
  %t818 = extractvalue { i64, ptr } %t806, 0
  %t819 = add i64 %t815, %t818
  %t820 = extractvalue { i64, ptr } { i64 5, ptr @.d512 }, 1
  %t821 = extractvalue { i64, ptr } { i64 5, ptr @.d512 }, 0
  %t822 = add i64 %t819, %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t807, i64 %t808)
  %t824 = getelementptr i8, ptr %t823, i64 %t808
  call void @olang_textcopy(ptr %t824, ptr %t810, i64 %t811)
  %t825 = getelementptr i8, ptr %t824, i64 %t811
  call void @olang_textcopy(ptr %t825, ptr %t813, i64 %t814)
  %t826 = getelementptr i8, ptr %t825, i64 %t814
  call void @olang_textcopy(ptr %t826, ptr %t817, i64 %t818)
  %t827 = getelementptr i8, ptr %t826, i64 %t818
  call void @olang_textcopy(ptr %t827, ptr %t820, i64 %t821)
  %t828 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t823, 1
  %t831 = extractvalue { i64, ptr } %t829, 0
  %t832 = extractvalue { i64, ptr } %t829, 1
  %t833 = mul i64 %t831, 1
  %t834 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t833)
  call void @llvm.memcpy.p0.p0.i64(ptr %t834, ptr %t832, i64 %t833, i1 false)
  %t835 = insertvalue { i64, ptr } undef, i64 %t831, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t834, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t804, { i64, ptr } %t836)
  br label %bb37
bb37:
  %t839 = load ptr, ptr %l1, !tbaa !29
  %t840 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t842 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t844 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t845 = extractvalue { i64, ptr } { i64 2, ptr @.d513 }, 1
  %t846 = extractvalue { i64, ptr } { i64 2, ptr @.d513 }, 0
  %t848 = extractvalue { i64, ptr } %t840, 1
  %t849 = extractvalue { i64, ptr } %t840, 0
  %t850 = add i64 %t846, %t849
  %t851 = extractvalue { i64, ptr } { i64 29, ptr @.d514 }, 1
  %t852 = extractvalue { i64, ptr } { i64 29, ptr @.d514 }, 0
  %t853 = add i64 %t850, %t852
  %t855 = extractvalue { i64, ptr } %t841, 1
  %t856 = extractvalue { i64, ptr } %t841, 0
  %t857 = add i64 %t853, %t856
  %t858 = extractvalue { i64, ptr } { i64 7, ptr @.d515 }, 1
  %t859 = extractvalue { i64, ptr } { i64 7, ptr @.d515 }, 0
  %t860 = add i64 %t857, %t859
  %t862 = extractvalue { i64, ptr } %t842, 1
  %t863 = extractvalue { i64, ptr } %t842, 0
  %t864 = add i64 %t860, %t863
  %t865 = extractvalue { i64, ptr } { i64 26, ptr @.d516 }, 1
  %t866 = extractvalue { i64, ptr } { i64 26, ptr @.d516 }, 0
  %t867 = add i64 %t864, %t866
  %t869 = extractvalue { i64, ptr } %t843, 1
  %t870 = extractvalue { i64, ptr } %t843, 0
  %t871 = add i64 %t867, %t870
  %t872 = extractvalue { i64, ptr } { i64 7, ptr @.d517 }, 1
  %t873 = extractvalue { i64, ptr } { i64 7, ptr @.d517 }, 0
  %t874 = add i64 %t871, %t873
  %t876 = extractvalue { i64, ptr } %t844, 1
  %t877 = extractvalue { i64, ptr } %t844, 0
  %t878 = add i64 %t874, %t877
  %t879 = extractvalue { i64, ptr } { i64 2, ptr @.d518 }, 1
  %t880 = extractvalue { i64, ptr } { i64 2, ptr @.d518 }, 0
  %t881 = add i64 %t878, %t880
  %t882 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t881)
  call void @olang_textcopy(ptr %t882, ptr %t845, i64 %t846)
  %t883 = getelementptr i8, ptr %t882, i64 %t846
  call void @olang_textcopy(ptr %t883, ptr %t848, i64 %t849)
  %t884 = getelementptr i8, ptr %t883, i64 %t849
  call void @olang_textcopy(ptr %t884, ptr %t851, i64 %t852)
  %t885 = getelementptr i8, ptr %t884, i64 %t852
  call void @olang_textcopy(ptr %t885, ptr %t855, i64 %t856)
  %t886 = getelementptr i8, ptr %t885, i64 %t856
  call void @olang_textcopy(ptr %t886, ptr %t858, i64 %t859)
  %t887 = getelementptr i8, ptr %t886, i64 %t859
  call void @olang_textcopy(ptr %t887, ptr %t862, i64 %t863)
  %t888 = getelementptr i8, ptr %t887, i64 %t863
  call void @olang_textcopy(ptr %t888, ptr %t865, i64 %t866)
  %t889 = getelementptr i8, ptr %t888, i64 %t866
  call void @olang_textcopy(ptr %t889, ptr %t869, i64 %t870)
  %t890 = getelementptr i8, ptr %t889, i64 %t870
  call void @olang_textcopy(ptr %t890, ptr %t872, i64 %t873)
  %t891 = getelementptr i8, ptr %t890, i64 %t873
  call void @olang_textcopy(ptr %t891, ptr %t876, i64 %t877)
  %t892 = getelementptr i8, ptr %t891, i64 %t877
  call void @olang_textcopy(ptr %t892, ptr %t879, i64 %t880)
  %t893 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t894 = insertvalue { i64, ptr } %t893, ptr %t882, 1
  %t896 = extractvalue { i64, ptr } %t894, 0
  %t897 = extractvalue { i64, ptr } %t894, 1
  %t898 = mul i64 %t896, 1
  %t899 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t898)
  call void @llvm.memcpy.p0.p0.i64(ptr %t899, ptr %t897, i64 %t898, i1 false)
  %t900 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t899, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t839, { i64, ptr } %t901)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s13)
  br label %bb39
bb39:
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t905 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t906 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t907 = extractvalue { i64, ptr } { i64 12, ptr @.d519 }, 1
  %t908 = extractvalue { i64, ptr } { i64 12, ptr @.d519 }, 0
  %t910 = extractvalue { i64, ptr } %t905, 1
  %t911 = extractvalue { i64, ptr } %t905, 0
  %t912 = add i64 %t908, %t911
  %t913 = extractvalue { i64, ptr } { i64 2, ptr @.d520 }, 1
  %t914 = extractvalue { i64, ptr } { i64 2, ptr @.d520 }, 0
  %t915 = add i64 %t912, %t914
  %t917 = extractvalue { i64, ptr } %t906, 1
  %t918 = extractvalue { i64, ptr } %t906, 0
  %t919 = add i64 %t915, %t918
  %t920 = extractvalue { i64, ptr } { i64 3, ptr @.d521 }, 1
  %t921 = extractvalue { i64, ptr } { i64 3, ptr @.d521 }, 0
  %t922 = add i64 %t919, %t921
  %t923 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t922)
  call void @olang_textcopy(ptr %t923, ptr %t907, i64 %t908)
  %t924 = getelementptr i8, ptr %t923, i64 %t908
  call void @olang_textcopy(ptr %t924, ptr %t910, i64 %t911)
  %t925 = getelementptr i8, ptr %t924, i64 %t911
  call void @olang_textcopy(ptr %t925, ptr %t913, i64 %t914)
  %t926 = getelementptr i8, ptr %t925, i64 %t914
  call void @olang_textcopy(ptr %t926, ptr %t917, i64 %t918)
  %t927 = getelementptr i8, ptr %t926, i64 %t918
  call void @olang_textcopy(ptr %t927, ptr %t920, i64 %t921)
  %t928 = insertvalue { i64, ptr } undef, i64 %t922, 0
  %t929 = insertvalue { i64, ptr } %t928, ptr %t923, 1
  %t931 = extractvalue { i64, ptr } %t929, 0
  %t932 = extractvalue { i64, ptr } %t929, 1
  %t933 = mul i64 %t931, 1
  %t934 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t933)
  call void @llvm.memcpy.p0.p0.i64(ptr %t934, ptr %t932, i64 %t933, i1 false)
  %t935 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t936 = insertvalue { i64, ptr } %t935, ptr %t934, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t904, { i64, ptr } %t936)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t939 = load i32, ptr %l12, !tbaa !23
  %t941 = add i32 %t939, 1
  store i32 %t941, ptr %l12, !tbaa !23
  br label %bb7
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/emit:Emitter", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = load i1, ptr %l23, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l9 = alloca i1
  %l18 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 2, ptr @.d522 })
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:fnEm", ptr %t5, i32 0, i32 5
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 18
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr @.d523 })
  store i1 %t16, ptr %l9
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:fnEm", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 18
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t26)
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %t29, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 5, ptr @.d524 }, ptr %l21, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t36, { i64, ptr } %t39)
  store i1 %t40, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i1, ptr %l22, !tbaa !21
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t43, i32 0, i32 5
  store ptr %t45, ptr %l24, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %s3, ptr %t46)
  store { i64, ptr } %t48, ptr %l26
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } %t55)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/emit:fnEm", ptr %t58, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t60, i8 10)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidth(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l18
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t27, ptr %l19
  br label %bb4
bb4:
  %t28 = load i64, ptr %l19, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l32
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i32, ptr %l32, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l33
  br label %bb11
bb11:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l38
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i32, ptr %l38, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t66, i32 %t67)
  store { i64, ptr } %t68, ptr %l39
  br label %bb13
bb13:
  %t69 = extractvalue { i64, ptr } { i64 6, ptr @.d525 }, 1
  %t70 = extractvalue { i64, ptr } { i64 6, ptr @.d525 }, 0
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr @.d526 }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr @.d526 }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 4, ptr @.d527 }, 1
  %t83 = extractvalue { i64, ptr } { i64 4, ptr @.d527 }, 0
  %t84 = add i64 %t81, %t83
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t69, i64 %t70)
  %t90 = getelementptr i8, ptr %t89, i64 %t70
  call void @olang_textcopy(ptr %t90, ptr %t72, i64 %t73)
  %t91 = getelementptr i8, ptr %t90, i64 %t73
  call void @olang_textcopy(ptr %t91, ptr %t75, i64 %t76)
  %t92 = getelementptr i8, ptr %t91, i64 %t76
  call void @olang_textcopy(ptr %t92, ptr %t79, i64 %t80)
  %t93 = getelementptr i8, ptr %t92, i64 %t80
  call void @olang_textcopy(ptr %t93, ptr %t82, i64 %t83)
  %t94 = getelementptr i8, ptr %t93, i64 %t83
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t89, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l28, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t104, { i64, ptr } %t103)
  store { i64, ptr } %t106, ptr %l42
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t107 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb15:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l43, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l44, !tbaa !29
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l47
  br label %bb16
bb16:
  %t115 = load ptr, ptr %l44, !tbaa !29
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t115, i32 %t116)
  store { i64, ptr } %t117, ptr %l48
  br label %bb17
bb17:
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l49, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l50, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l53
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l50, !tbaa !29
  %t126 = load i32, ptr %l53, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t125, i32 %t126)
  store { i64, ptr } %t127, ptr %l54
  br label %bb19
bb19:
  %t128 = extractvalue { i64, ptr } { i64 5, ptr @.d528 }, 1
  %t129 = extractvalue { i64, ptr } { i64 5, ptr @.d528 }, 0
  %t130 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d529 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d529 }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 4, ptr @.d530 }, 1
  %t142 = extractvalue { i64, ptr } { i64 4, ptr @.d530 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t128, i64 %t129)
  %t149 = getelementptr i8, ptr %t148, i64 %t129
  call void @olang_textcopy(ptr %t149, ptr %t131, i64 %t132)
  %t150 = getelementptr i8, ptr %t149, i64 %t132
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t138, i64 %t139)
  %t152 = getelementptr i8, ptr %t151, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l43, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t163, { i64, ptr } %t162)
  store { i64, ptr } %t165, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t166, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2emathInexact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathInexact
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2etbaaField_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 21, 2
  %t4 = insertvalue [15 x i64] %t3, i64 61, 3
  %t5 = insertvalue [15 x i64] %t4, i64 62, 4
  %t6 = insertvalue [15 x i64] %t5, i64 23, 5
  %t7 = insertvalue [15 x i64] %t6, i64 24, 6
  %t8 = insertvalue [15 x i64] %t7, i64 22, 7
  %t9 = insertvalue [15 x i64] %t8, i64 63, 8
  %t10 = insertvalue [15 x i64] %t9, i64 64, 9
  %t11 = insertvalue [15 x i64] %t10, i64 65, 10
  %t12 = insertvalue [15 x i64] %t11, i64 66, 11
  %t13 = insertvalue [15 x i64] %t12, i64 67, 12
  %t14 = insertvalue [15 x i64] %t13, i64 25, 13
  %t15 = insertvalue [15 x i64] %t14, i64 26, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2femit_2etbaaField
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2femit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2femit_2ePartSize_2einit()
  br label %bb1
bb1:
  call void @compiler_2femit_2ePartSizeDev_2einit()
  br label %bb2
bb2:
  call void @compiler_2femit_2eHomeShared_2einit()
  br label %bb3
bb3:
  call void @compiler_2femit_2eHomeLocal_2einit()
  br label %bb4
bb4:
  call void @compiler_2femit_2eHomeInst_2einit()
  br label %bb5
bb5:
  call void @compiler_2femit_2eHomeLoc_2einit()
  br label %bb6
bb6:
  call void @compiler_2femit_2etbaaName_2einit()
  br label %bb7
bb7:
  call void @compiler_2femit_2etbaaField_2einit()
  br label %bb8
bb8:
  call void @compiler_2femit_2etbaaElem_2einit()
  br label %bb9
bb9:
  call void @compiler_2femit_2etbaaTree_2einit()
  br label %bb10
bb10:
  call void @compiler_2femit_2emathExact_2einit()
  br label %bb11
bb11:
  call void @compiler_2femit_2emathInexact_2einit()
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [2 x i8] c"bb"
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d1 = private constant [0 x i8] c""
@.d2 = private constant [0 x i8] c""
@.d3 = private constant [1 x i8] c"~"
@.d4 = private constant [1 x i8] c"a"
@.d5 = private constant [6 x i8] c"const "
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [2 x i8] c" *"
@.d8 = private constant [8 x i8] c"int64_t "
@.d9 = private constant [4 x i8] c"_len"
@.d10 = private constant [1 x i8] c" "
@.d11 = private constant [6 x i8] c"const "
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [2 x i8] c" *"
@.d14 = private constant [1 x i8] c" "
@.d15 = private constant [4 x i8] c"void"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant [5 x i8] c" *buf"
@.d17 = private constant [11 x i8] c"int64_t cap"
@.d18 = private constant [12 x i8] c"int64_t *len"
@.d19 = private constant [7 x i8] c"int32_t"
@.d20 = private constant [7 x i8] c"int64_t"
@.d21 = private constant [8 x i8] c" *result"
@.d22 = private constant [7 x i8] c"int32_t"
@.d23 = private constant [3 x i8] c"/* "
@.d24 = private constant [4 x i8] c" */\0A"
@.d25 = private constant [1 x i8] c" "
@.d26 = private constant [1 x i8] c"("
@.d27 = private constant [4 x i8] c"void"
@.d28 = private constant [2 x i8] c", "
@.d29 = private constant [3 x i8] c");\0A"
@.d30 = private constant [8 x i8] c"ptr, ptr"
@.d31 = private constant [3 x i8] c"ptr"
@.d32 = private constant [3 x i8] c"ptr"
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [1 x i8] c" "
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [10 x i8] c"ptr byval("
@.d37 = private constant [8 x i8] c") align "
@.d38 = private constant [3 x i8] c"ptr"
@.d39 = private constant [2 x i8] c"U8"
@.d40 = private constant [52 x i8] c"distinct !DICompileUnit(language: DW_LANG_C, file: !"
@.d41 = private constant [21 x i8] c", producer: \22olang\22, "
@.d42 = private constant [63 x i8] c"isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)"
@.d43 = private constant [1 x i8] c"!"
@.d44 = private constant [4 x i8] c"null"
@.d45 = private constant [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: "
@.d46 = private constant [11 x i8] c", size: 64)"
@.d47 = private constant [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22"
@.d48 = private constant [14 x i8] c"\22, baseType: !"
@.d49 = private constant [22 x i8] c", size: 64, offset: 0)"
@.d50 = private constant [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22"
@.d51 = private constant [14 x i8] c"\22, baseType: !"
@.d52 = private constant [23 x i8] c", size: 64, offset: 64)"
@.d53 = private constant [3 x i8] c"!{!"
@.d54 = private constant [3 x i8] c", !"
@.d55 = private constant [1 x i8] c"}"
@.d56 = private constant [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22"
@.d57 = private constant [25 x i8] c"\22, size: 128, elements: !"
@.d58 = private constant [1 x i8] c")"
@.d59 = private constant [29 x i8] c"!DISubroutineType(types: !{})"
@.d60 = private constant [1 x i8] c":"
@.d61 = private constant [6 x i8] c"Array<"
@.d62 = private constant [1 x i8] c"\0A"
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [26 x i8] c"define linkonce_odr void @"
@.d65 = private constant [46 x i8] c"_rt(ptr %inst, ptr %scope) #0 {\0Aentry:\0A  call "
@.d66 = private constant [2 x i8] c" @"
@.d67 = private constant [1 x i8] c"("
@.d68 = private constant [2 x i8] c", "
@.d69 = private constant [10 x i8] c"ptr %scope"
@.d70 = private constant [2 x i8] c", "
@.d71 = private constant [25 x i8] c"ptr %inst)\0A  ret void\0A}\0A\0A"
@.d72 = private constant [3 x i8] c"_rt"
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [2 x i8] c" @"
@.d76 = private constant [1 x i8] c"("
@.d77 = private constant [1 x i8] c")"
@.d78 = private constant [2 x i8] c" @"
@.d79 = private constant [1 x i8] c"("
@.d80 = private constant [8 x i8] c"__olang_"
@.d81 = private constant [1 x i8] c")"
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [24 x i8] c" nobuiltin memory(write)"
@.d84 = private constant [7 x i8] c"declare"
@.d85 = private constant [85 x i8] c"; olang - emitted by the self-hosted compiler (compiler/emit.olang)\0Atarget triple = \22"
@.d86 = private constant [3 x i8] c"\22\0A\0A"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d87 = private constant [2 x i8] c"-t"
@.d88 = private constant [1 x i8] c"-"
@.d89 = private constant [2 x i8] c"-i"
@.d90 = private constant [0 x i8] c""
@.d91 = private constant [1 x i8] c":"
@.d92 = private constant [15 x i8] c"zeroinitializer"
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [14 x i8] c"getelementptr "
@.d95 = private constant [6 x i8] c", ptr "
@.d96 = private constant [14 x i8] c", i32 0, i32 0"
@.d97 = private constant [3 x i8] c"i64"
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [14 x i8] c"getelementptr "
@.d100 = private constant [6 x i8] c", ptr "
@.d101 = private constant [14 x i8] c", i32 0, i32 1"
@.d102 = private constant [0 x i8] c""
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [0 x i8] c""
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [1 x i8] c"@"
@.d108 = private constant [4 x i8] c"null"
@.d109 = private constant [1 x i8] c"@"
@.d110 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d111 = private constant [3 x i8] c", 0"
@.d112 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d113 = private constant [3 x i8] c", 1"
@.d114 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d115 = private constant [3 x i8] c", 0"
@.d116 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d117 = private constant [3 x i8] c", 1"
@.d118 = private constant [23 x i8] c"getelementptr ptr, ptr "
@.d119 = private constant [6 x i8] c", i64 "
@.d120 = private constant [14 x i8] c"load ptr, ptr "
@.d121 = private constant [6 x i8] c"@llvm."
@.d122 = private constant [0 x i8] c""
@.d123 = private constant [4 x i8] c"ptr "
@.d124 = private constant [0 x i8] c""
@.d125 = private constant [2 x i8] c", "
@.d126 = private constant [4 x i8] c"ptr "
@.d127 = private constant [2 x i8] c", "
@.d128 = private constant [4 x i8] c"ptr "
@.d129 = private constant [2 x i8] c", "
@.d130 = private constant [0 x i8] c""
@.d131 = private constant [4 x i8] c"ptr "
@.d132 = private constant [0 x i8] c""
@.d133 = private constant [4 x i8] c"ptr "
@.d134 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d135 = private constant [3 x i8] c", 0"
@.d136 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d137 = private constant [3 x i8] c", 1"
@.d138 = private constant [4 x i8] c"ptr "
@.d139 = private constant [6 x i8] c", ptr "
@.d140 = private constant [1 x i8] c" "
@.d141 = private constant [0 x i8] c""
@.d142 = private constant [4 x i8] c"void"
@.d143 = private constant [10 x i8] c"call void "
@.d144 = private constant [1 x i8] c"("
@.d145 = private constant [1 x i8] c")"
@.d146 = private constant [5 x i8] c"call "
@.d147 = private constant [1 x i8] c" "
@.d148 = private constant [1 x i8] c"("
@.d149 = private constant [1 x i8] c")"
@.d150 = private constant [11 x i8] c"unreachable"
@.d151 = private constant [0 x i8] c""
@.d152 = private constant [13 x i8] c"extractvalue "
@.d153 = private constant [1 x i8] c" "
@.d154 = private constant [3 x i8] c", 1"
@.d155 = private constant [13 x i8] c"extractvalue "
@.d156 = private constant [1 x i8] c" "
@.d157 = private constant [3 x i8] c", 0"
@.d158 = private constant [3 x i8] c"i32"
@.d159 = private constant [0 x i8] c""
@.d160 = private constant [12 x i8] c"icmp ne i32 "
@.d161 = private constant [3 x i8] c", 0"
@.d162 = private constant [2 x i8] c"ok"
@.d163 = private constant [6 x i8] c"br i1 "
@.d164 = private constant [9 x i8] c", label %"
@.d165 = private constant [9 x i8] c", label %"
@.d166 = private constant [0 x i8] c""
@.d167 = private constant [0 x i8] c""
@.d168 = private constant [10 x i8] c"br label %"
@.d169 = private constant [4 x i8] c"true"
@.d170 = private constant [5 x i8] c"false"
@.d171 = private constant [2 x i8] c"%k"
@.d172 = private constant [1 x i8] c"_"
@.d173 = private constant [2 x i8] c"  "
@.d174 = private constant [13 x i8] c"h = lshr i32 "
@.d175 = private constant [7 x i8] c", 16\0A  "
@.d176 = private constant [15 x i8] c" = icmp eq i32 "
@.d177 = private constant [3 x i8] c"h, "
@.d178 = private constant [1 x i8] c"\0A"
@.d179 = private constant [2 x i8] c"  "
@.d180 = private constant [15 x i8] c" = icmp eq i32 "
@.d181 = private constant [2 x i8] c", "
@.d182 = private constant [1 x i8] c"\0A"
@.d183 = private constant [2 x i8] c"  "
@.d184 = private constant [10 x i8] c"o = or i1 "
@.d185 = private constant [2 x i8] c", "
@.d186 = private constant [1 x i8] c"\0A"
@.d187 = private constant [1 x i8] c"o"
@.d188 = private constant [8 x i8] c"  br i1 "
@.d189 = private constant [13 x i8] c", label %take"
@.d190 = private constant [13 x i8] c", label %pass"
@.d191 = private constant [5 x i8] c"\0Atake"
@.d192 = private constant [2 x i8] c":\0A"
@.d193 = private constant [5 x i8] c"  %hv"
@.d194 = private constant [28 x i8] c" = load { ptr, ptr }, ptr %f"
@.d195 = private constant [1 x i8] c"\0A"
@.d196 = private constant [5 x i8] c"  %hc"
@.d197 = private constant [32 x i8] c" = extractvalue { ptr, ptr } %hv"
@.d198 = private constant [9 x i8] c", 0\0A  %he"
@.d199 = private constant [32 x i8] c" = extractvalue { ptr, ptr } %hv"
@.d200 = private constant [4 x i8] c", 1\0A"
@.d201 = private constant [7 x i8] c"ptr %he"
@.d202 = private constant [5 x i8] c"  %ho"
@.d203 = private constant [10 x i8] c" = alloca "
@.d204 = private constant [1 x i8] c"\0A"
@.d205 = private constant [9 x i8] c", ptr %ho"
@.d206 = private constant [18 x i8] c"__olang_prog_scope"
@.d207 = private constant [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr"
@.d208 = private constant [5 x i8] c"  %hs"
@.d209 = private constant [1 x i8] c"_"
@.d210 = private constant [37 x i8] c" = load ptr, ptr @__olang_prog_scope\0A"
@.d211 = private constant [9 x i8] c", ptr %hs"
@.d212 = private constant [1 x i8] c"_"
@.d213 = private constant [0 x i8] c""
@.d214 = private constant [4 x i8] c"void"
@.d215 = private constant [15 x i8] c"  call void %hc"
@.d216 = private constant [1 x i8] c"("
@.d217 = private constant [2 x i8] c")\0A"
@.d218 = private constant [5 x i8] c"  %hr"
@.d219 = private constant [8 x i8] c" = call "
@.d220 = private constant [4 x i8] c" %hc"
@.d221 = private constant [1 x i8] c"("
@.d222 = private constant [2 x i8] c")\0A"
@.d223 = private constant [3 x i8] c"%hr"
@.d224 = private constant [5 x i8] c"  %hl"
@.d225 = private constant [8 x i8] c" = load "
@.d226 = private constant [9 x i8] c", ptr %ho"
@.d227 = private constant [1 x i8] c"\0A"
@.d228 = private constant [3 x i8] c"%hl"
@.d229 = private constant [0 x i8] c""
@.d230 = private constant [5 x i8] c"  %hd"
@.d231 = private constant [19 x i8] c" = load ptr, ptr %f"
@.d232 = private constant [9 x i8] c"\0A  store "
@.d233 = private constant [1 x i8] c" "
@.d234 = private constant [9 x i8] c", ptr %hd"
@.d235 = private constant [1 x i8] c"\0A"
@.d236 = private constant [5 x i8] c"  %hd"
@.d237 = private constant [1 x i8] c"_"
@.d238 = private constant [19 x i8] c" = load ptr, ptr %f"
@.d239 = private constant [1 x i8] c"\0A"
@.d240 = private constant [5 x i8] c"  %hx"
@.d241 = private constant [1 x i8] c"_"
@.d242 = private constant [16 x i8] c" = extractvalue "
@.d243 = private constant [1 x i8] c" "
@.d244 = private constant [2 x i8] c", "
@.d245 = private constant [1 x i8] c"\0A"
@.d246 = private constant [8 x i8] c"  store "
@.d247 = private constant [4 x i8] c" %hx"
@.d248 = private constant [1 x i8] c"_"
@.d249 = private constant [9 x i8] c", ptr %hd"
@.d250 = private constant [1 x i8] c"_"
@.d251 = private constant [1 x i8] c"\0A"
@.d252 = private constant [1 x i8] c"c"
@.d253 = private constant [19 x i8] c"  ret ptr null\0Apass"
@.d254 = private constant [2 x i8] c":\0A"
@.d255 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d256 = private constant [3 x i8] c", 0"
@.d257 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d258 = private constant [3 x i8] c", 1"
@.d259 = private constant [8 x i8] c"mul i64 "
@.d260 = private constant [2 x i8] c", "
@.d261 = private constant [19 x i8] c"__olang_scope_alloc"
@.d262 = private constant [34 x i8] c"call ptr @__olang_scope_alloc(ptr "
@.d263 = private constant [6 x i8] c", i64 "
@.d264 = private constant [1 x i8] c")"
@.d265 = private constant [21 x i8] c"llvm.memcpy.p0.p0.i64"
@.d266 = private constant [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)"
@.d267 = private constant [37 x i8] c"call void @llvm.memcpy.p0.p0.i64(ptr "
@.d268 = private constant [6 x i8] c", ptr "
@.d269 = private constant [6 x i8] c", i64 "
@.d270 = private constant [11 x i8] c", i1 false)"
@.d271 = private constant [32 x i8] c"getelementptr { i64, ptr }, ptr "
@.d272 = private constant [14 x i8] c", i32 0, i32 1"
@.d273 = private constant [3 x i8] c"ptr"
@.d274 = private constant [51 x i8] c"a C callback that is no export fn named at the call"
@.d275 = private constant [4 x i8] c"null"
@.d276 = private constant [3 x i8] c"add"
@.d277 = private constant [3 x i8] c"sub"
@.d278 = private constant [3 x i8] c"mul"
@.d279 = private constant [1 x i8] c"u"
@.d280 = private constant [1 x i8] c"s"
@.d281 = private constant [5 x i8] c"llvm."
@.d282 = private constant [16 x i8] c".with.overflow.i"
@.d283 = private constant [2 x i8] c"{ "
@.d284 = private constant [8 x i8] c", i1 } @"
@.d285 = private constant [1 x i8] c"("
@.d286 = private constant [2 x i8] c", "
@.d287 = private constant [1 x i8] c")"
@.d288 = private constant [7 x i8] c"call { "
@.d289 = private constant [8 x i8] c", i1 } @"
@.d290 = private constant [1 x i8] c"("
@.d291 = private constant [1 x i8] c" "
@.d292 = private constant [2 x i8] c", "
@.d293 = private constant [1 x i8] c" "
@.d294 = private constant [1 x i8] c")"
@.d295 = private constant [15 x i8] c"extractvalue { "
@.d296 = private constant [7 x i8] c", i1 } "
@.d297 = private constant [3 x i8] c", 1"
@.d298 = private constant [5 x i8] c"false"
@.d299 = private constant [20 x i8] c"-9223372036854775808"
@.d300 = private constant [1 x i8] c"-"
@.d301 = private constant [0 x i8] c""
@.d302 = private constant [8 x i8] c"icmp eq "
@.d303 = private constant [1 x i8] c" "
@.d304 = private constant [2 x i8] c", "
@.d305 = private constant [8 x i8] c"icmp eq "
@.d306 = private constant [1 x i8] c" "
@.d307 = private constant [4 x i8] c", -1"
@.d308 = private constant [7 x i8] c"and i1 "
@.d309 = private constant [2 x i8] c", "
@.d310 = private constant [8 x i8] c"icmp ne "
@.d311 = private constant [1 x i8] c" "
@.d312 = private constant [3 x i8] c", 0"
@.d313 = private constant [19 x i8] c"9223372036854775808"
@.d314 = private constant [8 x i8] c"icmp eq "
@.d315 = private constant [1 x i8] c" "
@.d316 = private constant [3 x i8] c", -"
@.d317 = private constant [6 x i8] c"fpext "
@.d318 = private constant [1 x i8] c" "
@.d319 = private constant [10 x i8] c" to double"
@.d320 = private constant [0 x i8] c""
@.d321 = private constant [0 x i8] c""
@.d322 = private constant [16 x i8] c"fcmp ogt double "
@.d323 = private constant [6 x i8] c", -1.0"
@.d324 = private constant [16 x i8] c"fcmp olt double "
@.d325 = private constant [2 x i8] c", "
@.d326 = private constant [16 x i8] c"fcmp oge double "
@.d327 = private constant [2 x i8] c", "
@.d328 = private constant [16 x i8] c"fcmp ogt double "
@.d329 = private constant [2 x i8] c", "
@.d330 = private constant [16 x i8] c"fcmp olt double "
@.d331 = private constant [2 x i8] c", "
@.d332 = private constant [7 x i8] c"and i1 "
@.d333 = private constant [2 x i8] c", "
@.d334 = private constant [7 x i8] c"xor i1 "
@.d335 = private constant [6 x i8] c", true"
@.d336 = private constant [8 x i8] c"icmp ne "
@.d337 = private constant [1 x i8] c" "
@.d338 = private constant [2 x i8] c", "
@.d339 = private constant [0 x i8] c""
@.d340 = private constant [9 x i8] c"icmp slt "
@.d341 = private constant [1 x i8] c" "
@.d342 = private constant [3 x i8] c", 0"
@.d343 = private constant [9 x i8] c"icmp slt "
@.d344 = private constant [1 x i8] c" "
@.d345 = private constant [3 x i8] c", 0"
@.d346 = private constant [6 x i8] c"or i1 "
@.d347 = private constant [2 x i8] c", "
@.d348 = private constant [20 x i8] c"an overflow test of "
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d531 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d531 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d532 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d532 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d533 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d533 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d534 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d534 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d535 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d535 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d536 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d536 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d537 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d537 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d538 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d538 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d539 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d539 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d540 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d540 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d541 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d541 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d542 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d542 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d543 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d543 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d544 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d544 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d545 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d545 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d546 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d546 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d547 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d547 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d548 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d548 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d549 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d549 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d550 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d550 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d551 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d551 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d552 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d552 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d553 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d553 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d554 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d554 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr @.d555 }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr @.d555 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d556 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d556 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr @.d557 }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr @.d557 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr @.d558 }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr @.d558 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr @.d559 }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr @.d559 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr @.d560 }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr @.d560 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 19, ptr @.d561 }, 1
  %t66 = extractvalue { i64, ptr } { i64 19, ptr @.d561 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 20, ptr @.d562 }, 1
  %t68 = extractvalue { i64, ptr } { i64 20, ptr @.d562 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 15, ptr @.d563 }, 1
  %t70 = extractvalue { i64, ptr } { i64 15, ptr @.d563 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 17, ptr @.d564 }, 1
  %t72 = extractvalue { i64, ptr } { i64 17, ptr @.d564 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 18, ptr @.d565 }, 1
  %t74 = extractvalue { i64, ptr } { i64 18, ptr @.d565 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 15, ptr @.d566 }, 1
  %t76 = extractvalue { i64, ptr } { i64 15, ptr @.d566 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 12, ptr @.d567 }, 1
  %t78 = extractvalue { i64, ptr } { i64 12, ptr @.d567 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 14, ptr @.d568 }, 1
  %t80 = extractvalue { i64, ptr } { i64 14, ptr @.d568 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 18, ptr @.d569 }, 1
  %t82 = extractvalue { i64, ptr } { i64 18, ptr @.d569 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 12, ptr @.d570 }, 1
  %t84 = extractvalue { i64, ptr } { i64 12, ptr @.d570 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d349 = private constant [5 x i8] c"false"
@.d350 = private constant [14 x i8] c"getelementptr "
@.d351 = private constant [6 x i8] c", ptr "
@.d352 = private constant [6 x i8] c", i64 "
@.d353 = private constant [8 x i8] c"sub i64 "
@.d354 = private constant [2 x i8] c", "
@.d355 = private constant [2 x i8] c"bs"
@.d356 = private constant [1 x i8] c"%"
@.d357 = private constant [2 x i8] c"  "
@.d358 = private constant [49 x i8] c" = call ptr @__olang_scope_alloc_a(ptr %big, i64 "
@.d359 = private constant [6 x i8] c", i64 "
@.d360 = private constant [2 x i8] c")\0A"
@.d361 = private constant [2 x i8] c"%s"
@.d362 = private constant [0 x i8] c""
@.d363 = private constant [0 x i8] c""
@.d364 = private constant [1 x i8] c"@"
@.d365 = private constant [1 x i8] c"@"
@.d366 = private constant [24 x i8] c"a task calling an extern"
@.d367 = private constant [29 x i8] c"a task calling through an any"
@.d368 = private constant [12 x i8] c"{ ptr, ptr }"
@.d369 = private constant [0 x i8] c""
@.d370 = private constant [3 x i8] c"ptr"
@.d371 = private constant [4 x i8] c"null"
@.d372 = private constant [15 x i8] c"__olang_standin"
@.d373 = private constant [25 x i8] c"ptr @__olang_standin(ptr)"
@.d374 = private constant [30 x i8] c"call ptr @__olang_standin(ptr "
@.d375 = private constant [1 x i8] c")"
@.d376 = private constant [3 x i8] c"ptr"
@.d377 = private constant [12 x i8] c"{ ptr, ptr }"
@.d378 = private constant [3 x i8] c"ptr"
@.d379 = private constant [4 x i8] c"null"
@.d380 = private constant [15 x i8] c"__olang_standin"
@.d381 = private constant [25 x i8] c"ptr @__olang_standin(ptr)"
@.d382 = private constant [30 x i8] c"call ptr @__olang_standin(ptr "
@.d383 = private constant [1 x i8] c")"
@.d384 = private constant [3 x i8] c"ptr"
@.d385 = private constant [2 x i8] c"{ "
@.d386 = private constant [2 x i8] c", "
@.d387 = private constant [2 x i8] c"i8"
@.d388 = private constant [2 x i8] c" }"
@.d389 = private constant [21 x i8] c"__olang_scope_alloc_a"
@.d390 = private constant [14 x i8] c"getelementptr "
@.d391 = private constant [17 x i8] c", ptr null, i32 1"
@.d392 = private constant [13 x i8] c"ptrtoint ptr "
@.d393 = private constant [7 x i8] c" to i64"
@.d394 = private constant [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr "
@.d395 = private constant [6 x i8] c", i64 "
@.d396 = private constant [8 x i8] c", i64 8)"
@.d397 = private constant [14 x i8] c"getelementptr "
@.d398 = private constant [6 x i8] c", ptr "
@.d399 = private constant [13 x i8] c", i32 0, i32 "
@.d400 = private constant [0 x i8] c""
@.d401 = private constant [0 x i8] c""
@.d402 = private constant [0 x i8] c""
@.d403 = private constant [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr "
@.d404 = private constant [16 x i8] c", i64 32, i64 8)"
@.d405 = private constant [4 x i8] c"null"
@.d406 = private constant [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr "
@.d407 = private constant [16 x i8] c", i64 16, i64 8)"
@.d408 = private constant [3 x i8] c"ptr"
@.d409 = private constant [0 x i8] c""
@.d410 = private constant [32 x i8] c"getelementptr { ptr, ptr }, ptr "
@.d411 = private constant [14 x i8] c", i32 0, i32 1"
@.d412 = private constant [3 x i8] c"ptr"
@.d413 = private constant [0 x i8] c""
@.d414 = private constant [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr "
@.d415 = private constant [14 x i8] c", i32 0, i32 2"
@.d416 = private constant [3 x i8] c"ptr"
@.d417 = private constant [0 x i8] c""
@.d418 = private constant [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr "
@.d419 = private constant [14 x i8] c", i32 0, i32 1"
@.d420 = private constant [3 x i8] c"i64"
@.d421 = private constant [1 x i8] c"0"
@.d422 = private constant [0 x i8] c""
@.d423 = private constant [42 x i8] c"getelementptr { ptr, i64, ptr, i64 }, ptr "
@.d424 = private constant [14 x i8] c", i32 0, i32 3"
@.d425 = private constant [3 x i8] c"i64"
@.d426 = private constant [1 x i8] c"0"
@.d427 = private constant [0 x i8] c""
@.d428 = private constant [18 x i8] c"__olang_worker_get"
@.d429 = private constant [25 x i8] c"ptr @__olang_worker_get()"
@.d430 = private constant [20 x i8] c"__olang_worker_start"
@.d431 = private constant [46 x i8] c"void @__olang_worker_start(ptr, ptr, ptr, ptr)"
@.d432 = private constant [30 x i8] c"call ptr @__olang_worker_get()"
@.d433 = private constant [36 x i8] c"call void @__olang_worker_start(ptr "
@.d434 = private constant [7 x i8] c", ptr @"
@.d435 = private constant [6 x i8] c", ptr "
@.d436 = private constant [6 x i8] c", ptr "
@.d437 = private constant [1 x i8] c")"
@.d438 = private constant [3 x i8] c"%jh"
@.d439 = private constant [3 x i8] c"ptr"
@.d440 = private constant [0 x i8] c""
@.d441 = private constant [3 x i8] c"ptr"
@.d442 = private constant [0 x i8] c""
@.d443 = private constant [3 x i8] c"%jh"
@.d444 = private constant [3 x i8] c"ptr"
@.d445 = private constant [0 x i8] c""
@.d446 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d447 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d448 = private constant [3 x i8] c"%tf"
@.d449 = private constant [1 x i8] c"_"
@.d450 = private constant [2 x i8] c"tf"
@.d451 = private constant [1 x i8] c"_"
@.d452 = private constant [2 x i8] c"  "
@.d453 = private constant [20 x i8] c"d = load ptr, ptr %f"
@.d454 = private constant [3 x i8] c"\0A  "
@.d455 = private constant [27 x i8] c"v = load { i64, ptr }, ptr "
@.d456 = private constant [2 x i8] c"d\0A"
@.d457 = private constant [2 x i8] c"  "
@.d458 = private constant [30 x i8] c"n = extractvalue { i64, ptr } "
@.d459 = private constant [7 x i8] c"v, 0\0A  "
@.d460 = private constant [30 x i8] c"p = extractvalue { i64, ptr } "
@.d461 = private constant [5 x i8] c"v, 1\0A"
@.d462 = private constant [2 x i8] c"  "
@.d463 = private constant [35 x i8] c"on = extractvalue { i64, ptr } %old"
@.d464 = private constant [6 x i8] c", 0\0A  "
@.d465 = private constant [35 x i8] c"op = extractvalue { i64, ptr } %old"
@.d466 = private constant [4 x i8] c", 1\0A"
@.d467 = private constant [2 x i8] c"  "
@.d468 = private constant [12 x i8] c"b = mul i64 "
@.d469 = private constant [3 x i8] c"n, "
@.d470 = private constant [3 x i8] c"\0A  "
@.d471 = private constant [16 x i8] c"s = icmp eq i64 "
@.d472 = private constant [3 x i8] c"n, "
@.d473 = private constant [3 x i8] c"on\0A"
@.d474 = private constant [8 x i8] c"  br i1 "
@.d475 = private constant [10 x i8] c"s, label %"
@.d476 = private constant [10 x i8] c"i, label %"
@.d477 = private constant [2 x i8] c"f\0A"
@.d478 = private constant [3 x i8] c"i:\0A"
@.d479 = private constant [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr "
@.d480 = private constant [8 x i8] c"op, ptr "
@.d481 = private constant [7 x i8] c"p, i64 "
@.d482 = private constant [13 x i8] c"b, i1 false)\0A"
@.d483 = private constant [25 x i8] c"  store { i64, ptr } %old"
@.d484 = private constant [6 x i8] c", ptr "
@.d485 = private constant [14 x i8] c"d\0A  br label %"
@.d486 = private constant [2 x i8] c"e\0A"
@.d487 = private constant [3 x i8] c"f:\0A"
@.d488 = private constant [19 x i8] c"__olang_scope_alloc"
@.d489 = private constant [18 x i8] c"__olang_prog_scope"
@.d490 = private constant [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr"
@.d491 = private constant [2 x i8] c"  "
@.d492 = private constant [20 x i8] c"c = load ptr, ptr %f"
@.d493 = private constant [3 x i8] c"\0A  "
@.d494 = private constant [16 x i8] c"z = icmp eq ptr "
@.d495 = private constant [8 x i8] c"c, null\0A"
@.d496 = private constant [2 x i8] c"  "
@.d497 = private constant [40 x i8] c"g = load ptr, ptr @__olang_prog_scope\0A  "
@.d498 = private constant [14 x i8] c"w = select i1 "
@.d499 = private constant [7 x i8] c"z, ptr "
@.d500 = private constant [7 x i8] c"g, ptr "
@.d501 = private constant [2 x i8] c"c\0A"
@.d502 = private constant [2 x i8] c"  "
@.d503 = private constant [38 x i8] c"q = call ptr @__olang_scope_alloc(ptr "
@.d504 = private constant [7 x i8] c"w, i64 "
@.d505 = private constant [3 x i8] c"b)\0A"
@.d506 = private constant [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr "
@.d507 = private constant [7 x i8] c"q, ptr "
@.d508 = private constant [7 x i8] c"p, i64 "
@.d509 = private constant [13 x i8] c"b, i1 false)\0A"
@.d510 = private constant [2 x i8] c"  "
@.d511 = private constant [40 x i8] c"x = insertvalue { i64, ptr } undef, i64 "
@.d512 = private constant [5 x i8] c"n, 0\0A"
@.d513 = private constant [2 x i8] c"  "
@.d514 = private constant [29 x i8] c"y = insertvalue { i64, ptr } "
@.d515 = private constant [7 x i8] c"x, ptr "
@.d516 = private constant [26 x i8] c"q, 1\0A  store { i64, ptr } "
@.d517 = private constant [7 x i8] c"y, ptr "
@.d518 = private constant [2 x i8] c"d\0A"
@.d519 = private constant [12 x i8] c"  br label %"
@.d520 = private constant [2 x i8] c"e\0A"
@.d521 = private constant [3 x i8] c"e:\0A"
@.d522 = private constant [2 x i8] c"  "
@.d523 = private constant [0 x i8] c""
@.d524 = private constant [5 x i8] c"call "
@.d525 = private constant [6 x i8] c"trunc "
@.d526 = private constant [1 x i8] c" "
@.d527 = private constant [4 x i8] c" to "
@.d528 = private constant [5 x i8] c"zext "
@.d529 = private constant [1 x i8] c" "
@.d530 = private constant [4 x i8] c" to "
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d531 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d532 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d533 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d534 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d535 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d536 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d537 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d538 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d539 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d540 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d541 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d542 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d543 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d544 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d545 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d546 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d547 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d548 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d549 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d550 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d551 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d552 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d553 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d554 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d555 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d556 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d557 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d558 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d559 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d560 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d561 = private unnamed_addr constant [19 x i8] c"PrimOp.LeadingZeros"
@.d562 = private unnamed_addr constant [20 x i8] c"PrimOp.TrailingZeros"
@.d563 = private unnamed_addr constant [15 x i8] c"PrimOp.PopCount"
@.d564 = private unnamed_addr constant [17 x i8] c"PrimOp.RotateLeft"
@.d565 = private unnamed_addr constant [18 x i8] c"PrimOp.RotateRight"
@.d566 = private unnamed_addr constant [15 x i8] c"PrimOp.ByteSwap"
@.d567 = private unnamed_addr constant [12 x i8] c"PrimOp.Holds"
@.d568 = private unnamed_addr constant [14 x i8] c"PrimOp.AnyMake"
@.d569 = private unnamed_addr constant [18 x i8] c"PrimOp.AnyInstance"
@.d570 = private unnamed_addr constant [12 x i8] c"PrimOp.AnyIs"
@G_2ecompiler_2femit_2ePartSizeDev = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b7cf39b9bc6342b8_b5524b9e4a088564 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_bd540bd6a40c6889_fa12f95675f29f55 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i1 %a2, i64 %a3, i64 %a4, ptr %a5, i64 %a6, ptr %a7, i64 %a8)
declare %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Object" %a1)
@olang_loc_e19c419b1337c5fa_618f10f3ec8a7f5e = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_903aaa7827cdea7b_7e0f2a3cd8c84bdf = external constant [0 x i8]
@olang_loc_913058ce5338c700_ff17fcf7b48c01a4 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
@olang_loc_1327b3efebd3a791_482154403c367095 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignatureText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4ceab00ffc5fe877_bbdeb91fb78880cb = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2854570d7fadf599_61afc1034d008305 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9506350913203bfc_41d6488afcc367c0 = external constant [0 x i8]
@olang_loc_2a2725b2da5e1bad_47abef39162bd051 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98184d77b87c9296_c4a7a562026735ba = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_aa85ef0c362238c9_b248055339837d6d = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathInexact = external constant <{ ptr }>
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2femit_2efnTypeOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ff468ede8d2dad5_ce6794a5e99bfc39 = external constant [0 x i8]
@olang_loc_fd5758dba8282ae8_cbed788f914882ac = external constant [0 x i8]
@olang_loc_a549d449f3dfe0fc_20c0e66cb00bd9e8 = external constant [0 x i8]
declare %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3a6ac4f3bb1dc0ad_502f03c6a68bc9b9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7729a42c6cf896d9_c9c75da2e4237ced = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_17fafaf8ddeba01b_252e647ba0a345f = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4e101a65701de364_bb0ca6f6f49ef738 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7181fb99348382a8_4bd06d378e143a0c = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d166383632e6ec4e_5cd1ec2f29a4b0f2 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1, { i64, ptr } %a2, i32 %a3)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_9199a3ab2b5d08f_bd3a4c654376a573 = external constant [0 x i8]
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4 = external constant [0 x i8]
@olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757 = external constant [0 x i8]
@olang_loc_dde810cb192bdc32_ece13dbcfe1403b6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c0167577194c5569_3f3b475069b70a4d = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c = external constant [0 x i8]
@olang_loc_d4e74db3ab2eecf_2f1d311192c757bb = external constant [0 x i8]
@olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a = external constant [0 x i8]
@olang_loc_3cc845cddd6e7d45_72b333e08cb265d1 = external constant [0 x i8]
@olang_loc_ed841b109784c94_6cdd8d327349fd40 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7d1301c542cf69c7_2a1b7d2f181cc69b = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3)
@olang_loc_9185a77390ef7566_ed985a49c11fac9a = external constant [0 x i8]
@olang_loc_b58edc65c6718b49_26c0578031dccca5 = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %a0)
@olang_loc_e0bde991406b3b8f_e6287fb3b91b7a9b = external constant [0 x i8]
@olang_loc_a90a878cc09c574e_a9a55cce621e609a = external constant [0 x i8]
declare %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9287686e475a7dbe_ea834ed677e35522 = external constant [0 x i8]
@olang_loc_45f21d64bb841654_8b47099e9550bca0 = external constant [0 x i8]
@olang_loc_d9d0b2b7ed8bee73_863b180db322a137 = external constant [0 x i8]
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, i1 %a3, { i64, ptr } %a4, i32 %a5, i64 %a6, %"compiler/mir:Task" %a7, i32 %a8, { i64, ptr } %a9)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %v0)
@G_2ecompiler_2femit_2etbaaField = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\3D\00\00\00\00\00\00\00\3E\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\41\00\00\00\00\00\00\00\42\00\00\00\00\00\00\00\43\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
declare void @compiler_2femit_2ePartSize_2einit()
declare void @compiler_2femit_2eHomeShared_2einit()
declare void @compiler_2femit_2eHomeLocal_2einit()
declare void @compiler_2femit_2eHomeInst_2einit()
declare void @compiler_2femit_2eHomeLoc_2einit()
declare void @compiler_2femit_2etbaaName_2einit()
declare void @compiler_2femit_2etbaaElem_2einit()
declare void @compiler_2femit_2etbaaTree_2einit()
declare void @compiler_2femit_2emathExact_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
