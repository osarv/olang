; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:cDecls" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [8 x i64] } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:Case" = type { i64, i32 }
define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eHeader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/emit:cDecls"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca %"compiler/emit:cDecls"
  %l37 = alloca %"std/prelude/text:StringBuilder"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i64
  %l54 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"std/prelude/text:StringBuilder"
  %l94 = alloca i64
  %l97 = alloca i64
  %l99 = alloca i64
  %l104 = alloca { i64, ptr }
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca { i64, ptr }
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l129 = alloca i64
  %l133 = alloca i64
  %l135 = alloca i64
  %l141 = alloca i32
  %l153 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca { i64, ptr }
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l190 = alloca i32
  %l192 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l215 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t10 = alloca %"compiler/emit:cDecls", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v1, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l35
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t9, ptr %l4, !tbaa !27
  call void @compiler_2femit_3acDecls_2ector(ptr %t10, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t10, i64 136, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l36, i64 136, i1 false)
  %t11 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l37
  br label %bb3
bb3:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l37
  store %"std/prelude/text:StringBuilder" %t12, ptr %l6
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %s1, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l39
  br label %bb4
bb4:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t17 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  store ptr %t17, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l8, !tbaa !24
  store i64 %t19, ptr %l41, !tbaa !24
  %t20 = load ptr, ptr %l7, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t20)
  store i64 %t22, ptr %l43
  br label %bb6
bb6:
  %t23 = load i64, ptr %l41, !tbaa !24
  %t24 = load i64, ptr %l43, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l7, !tbaa !29
  %t30 = load i64, ptr %l8, !tbaa !24
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l48
  br label %bb10
bb10:
  %t34 = load i64, ptr %l48, !tbaa !24
  store i64 %t34, ptr %l9, !tbaa !24
  store i64 -1, ptr %l10, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:Emitter", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/lower:Lowerer", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = load i64, ptr %l9, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t41, i64 %t43)
  store ptr %t46, ptr %l54
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l54, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 1
  %t50 = load { i64, [2 x i64] }, ptr %t49
  store { i64, [2 x i64] } %t50, ptr %l11
  %t52 = load { i64, [2 x i64] }, ptr %l11
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t58 = getelementptr { i64 }, ptr %t57, i32 0, i32 0
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l12, !tbaa !24
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:Emitter", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l12, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l63
  br label %bb15
bb15:
  %t69 = load i64, ptr %l63, !tbaa !24
  store i64 %t69, ptr %l10, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e4a7c1511235e6a9_9511e73f4ca5cc95)
  unreachable
bb21:
  store ptr %l6, ptr %l64, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l65, !tbaa !29
  %t71 = load i64, ptr %l10, !tbaa !24
  store i64 %t71, ptr %l66, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:Emitter", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/lower:Lowerer", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t78, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = load ptr, ptr %l65, !tbaa !29
  %t89 = load i64, ptr %l66, !tbaa !24
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecEntryDecl(ptr %v0, ptr %s0, ptr %s2, ptr %t88, i64 %t89, i32 %t87, ptr %l5)
  store { i64, ptr } %t92, ptr %l76
  br label %bb23
bb23:
  %t93 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t100, { i64, ptr } %t99)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb5
bb26:
  call void @__olang_scope_close(ptr %s1)
  %t106 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t106, ptr %l80
  br label %bb27
bb27:
  %t107 = load %"std/prelude/text:StringBuilder", ptr %l80
  store %"std/prelude/text:StringBuilder" %t107, ptr %l13
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t114 = extractvalue { i64, ptr } %t108, 1
  %t115 = extractvalue { i64, ptr } %t108, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t121 = extractvalue { i64, ptr } %t109, 1
  %t122 = extractvalue { i64, ptr } %t109, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %a2, 1
  %t129 = extractvalue { i64, ptr } %a2, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t111, i64 %t112)
  %t135 = getelementptr i8, ptr %t134, i64 %t112
  call void @olang_textcopy(ptr %t135, ptr %t114, i64 %t115)
  %t136 = getelementptr i8, ptr %t135, i64 %t115
  call void @olang_textcopy(ptr %t136, ptr %t117, i64 %t118)
  %t137 = getelementptr i8, ptr %t136, i64 %t118
  call void @olang_textcopy(ptr %t137, ptr %t121, i64 %t122)
  %t138 = getelementptr i8, ptr %t137, i64 %t122
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  call void @olang_textcopy(ptr %t139, ptr %t128, i64 %t129)
  %t140 = getelementptr i8, ptr %t139, i64 %t129
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t134, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t149)
  br label %bb28
bb28:
  %t152 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t154 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t157 = extractvalue { i64, ptr } %t152, 1
  %t158 = extractvalue { i64, ptr } %t152, 0
  %t159 = add i64 %t155, %t158
  %t160 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t164 = extractvalue { i64, ptr } %t153, 1
  %t165 = extractvalue { i64, ptr } %t153, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t154, i64 %t155)
  %t171 = getelementptr i8, ptr %t170, i64 %t155
  call void @olang_textcopy(ptr %t171, ptr %t157, i64 %t158)
  %t172 = getelementptr i8, ptr %t171, i64 %t158
  call void @olang_textcopy(ptr %t172, ptr %t160, i64 %t161)
  %t173 = getelementptr i8, ptr %t172, i64 %t161
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t170, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t183)
  br label %bb29
bb29:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb30
bb30:
  %t187 = getelementptr %"compiler/emit:cDecls", ptr %l5, i32 0, i32 0
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t187)
  store i64 %t189, ptr %l94
  br label %bb31
bb31:
  %t190 = load i64, ptr %l94, !tbaa !24
  %t191 = icmp sgt i64 %t190, 0
  br i1 %t191, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t193 = getelementptr %"compiler/emit:cDecls", ptr %l5, i32 0, i32 0
  store ptr %t193, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb33:
  br label %bb44
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t195 = load i64, ptr %l15, !tbaa !24
  store i64 %t195, ptr %l97, !tbaa !24
  %t196 = load ptr, ptr %l14, !tbaa !29
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t196)
  store i64 %t198, ptr %l99
  br label %bb35
bb35:
  %t199 = load i64, ptr %l97, !tbaa !24
  %t200 = load i64, ptr %l99, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s10)
  br label %bb42
bb37:
  br label %bb38
bb38:
  %t205 = load ptr, ptr %l14, !tbaa !29
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t205, i64 %t206)
  store { i64, ptr } %t209, ptr %l104
  br label %bb39
bb39:
  %t210 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t210, ptr %l16, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t213 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t216 = extractvalue { i64, ptr } %t211, 1
  %t217 = extractvalue { i64, ptr } %t211, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t223 = extractvalue { i64, ptr } %t212, 1
  %t224 = extractvalue { i64, ptr } %t212, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t213, i64 %t214)
  %t230 = getelementptr i8, ptr %t229, i64 %t214
  call void @olang_textcopy(ptr %t230, ptr %t216, i64 %t217)
  %t231 = getelementptr i8, ptr %t230, i64 %t217
  call void @olang_textcopy(ptr %t231, ptr %t219, i64 %t220)
  %t232 = getelementptr i8, ptr %t231, i64 %t220
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t233, ptr %t226, i64 %t227)
  %t234 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t229, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = extractvalue { i64, ptr } %t235, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l13, { i64, ptr } %t242)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s10)
  br label %bb41
bb41:
  %t245 = load i64, ptr %l15, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l15, !tbaa !24
  br label %bb34
bb42:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb44:
  %t250 = getelementptr %"compiler/emit:cDecls", ptr %l5, i32 0, i32 1
  store ptr %t250, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  %t252 = load i64, ptr %l18, !tbaa !24
  store i64 %t252, ptr %l114, !tbaa !24
  %t253 = load ptr, ptr %l17, !tbaa !29
  %t255 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t253)
  store i64 %t255, ptr %l116
  br label %bb46
bb46:
  %t256 = load i64, ptr %l114, !tbaa !24
  %t257 = load i64, ptr %l116, !tbaa !24
  %t258 = icmp slt i64 %t256, %t257
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  br label %bb49
bb49:
  %t262 = load ptr, ptr %l17, !tbaa !29
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t262, i64 %t263)
  store { i64, ptr } %t266, ptr %l121
  br label %bb50
bb50:
  %t267 = load { i64, ptr }, ptr %l121, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t267)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t271 = load i64, ptr %l18, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l18, !tbaa !24
  br label %bb45
bb53:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %s0, ptr %t275)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l127
  br label %bb54
bb54:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l20
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l20)
  store i64 %t280, ptr %l129
  br label %bb55
bb55:
  %t281 = load i64, ptr %l129, !tbaa !24
  %t282 = icmp sgt i64 %t281, 0
  br i1 %t282, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s16
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l13, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb58
bb57:
  br label %bb90
bb58:
  store ptr %l20, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb59
bb59:
  %t286 = load i64, ptr %l22, !tbaa !24
  store i64 %t286, ptr %l133, !tbaa !24
  %t287 = load ptr, ptr %l21, !tbaa !29
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t287)
  store i64 %t289, ptr %l135
  br label %bb60
bb60:
  %t290 = load i64, ptr %l133, !tbaa !24
  %t291 = load i64, ptr %l135, !tbaa !24
  %t292 = icmp slt i64 %t290, %t291
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb61, label %bb62
bb61:
  br label %bb88
bb62:
  br label %bb63
bb63:
  %t296 = load i64, ptr %l22, !tbaa !24
  store i64 %t296, ptr %l23, !tbaa !24
  %t298 = load ptr, ptr %l21, !tbaa !29
  %t299 = load i64, ptr %l22, !tbaa !24
  %t302 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t298, i64 %t299)
  store i32 %t302, ptr %l141
  br label %bb64
bb64:
  %t303 = load i32, ptr %l141, !tbaa !23
  store i32 %t303, ptr %l24, !tbaa !23
  %t304 = load i32, ptr %l24, !tbaa !23
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t308 = icmp eq i32 %t304, %t305
  br i1 %t308, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s19
  %t310 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t311 = load i64, ptr %l23, !tbaa !24
  %t313 = add i64 %t311, 1
  %t315 = shl i64 %t313, 16
  %t316 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t319 = extractvalue { i64, ptr } %t310, 1
  %t320 = extractvalue { i64, ptr } %t310, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t326 = call i64 @__olang_fmt_i64(ptr null, i64 %t315)
  %t327 = add i64 %t324, %t326
  %t328 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t316, i64 %t317)
  %t332 = getelementptr i8, ptr %t331, i64 %t317
  call void @olang_textcopy(ptr %t332, ptr %t319, i64 %t320)
  %t333 = getelementptr i8, ptr %t332, i64 %t320
  call void @olang_textcopy(ptr %t333, ptr %t322, i64 %t323)
  %t334 = getelementptr i8, ptr %t333, i64 %t323
  %t335 = call i64 @__olang_fmt_i64(ptr %t334, i64 %t315)
  %t336 = getelementptr i8, ptr %t334, i64 %t326
  call void @olang_textcopy(ptr %t336, ptr %t328, i64 %t329)
  %t337 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t331, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = extractvalue { i64, ptr } %t338, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %l13, { i64, ptr } %t345)
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s19)
  br label %bb87
bb68:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/emit:Emitter", ptr %t348, i32 0, i32 0
  %t351 = load ptr, ptr %t350, !tbaa !29
  store ptr %t351, ptr %l153, !tbaa !29
  %t352 = load ptr, ptr %l3, !tbaa !29
  %t353 = load i32, ptr %l24, !tbaa !23
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l156
  br label %bb69
bb69:
  %t357 = load ptr, ptr %l153, !tbaa !29
  %t358 = load i32, ptr %l156, !tbaa !23
  %t359 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t357, i32 %t358)
  store { i64, ptr } %t359, ptr %l157
  br label %bb70
bb70:
  %t360 = load { i64, ptr }, ptr %l157, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t363 = extractvalue { i64, ptr } %t360, 0
  store i64 %t363, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t365 = load i64, ptr %l27, !tbaa !24
  %t366 = load i64, ptr %l26, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb71, label %bb72
bb71:
  %t371 = load i64, ptr %l28, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb76
bb73:
  %t375 = load i64, ptr %l27, !tbaa !24
  %t376 = load i64, ptr %l26, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l28, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l28, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l166, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb75
bb75:
  %t391 = load i64, ptr %l166, !tbaa !24
  store i64 %t391, ptr %l163, !tbaa !24
  br label %bb76
bb76:
  %t392 = load i64, ptr %l163, !tbaa !24
  store i64 %t392, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t393 = load i64, ptr %l30, !tbaa !24
  %t394 = load i64, ptr %l29, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s22)
  br label %bb86
bb79:
  br label %bb80
bb80:
  %t401 = load i64, ptr %l26, !tbaa !24
  %t402 = load i64, ptr %l30, !tbaa !24
  %t403 = load i64, ptr %l28, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l31, !tbaa !24
  store ptr %l13, ptr %l184, !tbaa !29
  %t411 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t411, ptr %l185, !tbaa !27
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/emit:Emitter", ptr %t412, i32 0, i32 0
  %t415 = load ptr, ptr %t414, !tbaa !29
  store ptr %t415, ptr %l187, !tbaa !29
  %t416 = load ptr, ptr %l3, !tbaa !29
  %t417 = load i32, ptr %l24, !tbaa !23
  %t420 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t416, i32 %t417)
  store i32 %t420, ptr %l190
  br label %bb81
bb81:
  %t421 = load i64, ptr %l31, !tbaa !24
  %t422 = load ptr, ptr %l187, !tbaa !29
  %t423 = load i32, ptr %l190, !tbaa !23
  %t425 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s22, ptr %t422, i32 %t423, i64 %t421)
  store { i64, ptr } %t425, ptr %l192
  br label %bb82
bb82:
  %t426 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 0
  %t428 = extractvalue { i64, ptr } %t426, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  %t434 = call { i64, ptr } @compiler_2femit_2ecWordName(ptr %s22, ptr %s22, { i64, ptr } %t432)
  store { i64, ptr } %t434, ptr %l194
  br label %bb83
bb83:
  %t435 = load i64, ptr %l23, !tbaa !24
  %t437 = add i64 %t435, 1
  %t439 = shl i64 %t437, 16
  %t440 = load i64, ptr %l31, !tbaa !24
  %t443 = or i64 %t439, %t440
  %t444 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t446 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 1
  %t448 = extractvalue { i64, ptr } %t446, 0
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 1
  %t455 = extractvalue { i64, ptr } %t453, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t459 = add i64 %t456, %t458
  %t461 = call i64 @__olang_fmt_i64(ptr null, i64 %t443)
  %t462 = add i64 %t459, %t461
  %t463 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t444, i64 %t445)
  %t467 = getelementptr i8, ptr %t466, i64 %t445
  call void @olang_textcopy(ptr %t467, ptr %t447, i64 %t448)
  %t468 = getelementptr i8, ptr %t467, i64 %t448
  call void @olang_textcopy(ptr %t468, ptr %t450, i64 %t451)
  %t469 = getelementptr i8, ptr %t468, i64 %t451
  call void @olang_textcopy(ptr %t469, ptr %t454, i64 %t455)
  %t470 = getelementptr i8, ptr %t469, i64 %t455
  call void @olang_textcopy(ptr %t470, ptr %t457, i64 %t458)
  %t471 = getelementptr i8, ptr %t470, i64 %t458
  %t472 = call i64 @__olang_fmt_i64(ptr %t471, i64 %t443)
  %t473 = getelementptr i8, ptr %t471, i64 %t461
  call void @olang_textcopy(ptr %t473, ptr %t463, i64 %t464)
  %t474 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t466, 1
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = extractvalue { i64, ptr } %t475, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  %t483 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %t483, { i64, ptr } %t482)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s22)
  br label %bb85
bb85:
  %t485 = load i64, ptr %l30, !tbaa !24
  %t487 = add i64 %t485, 1
  store i64 %t487, ptr %l30, !tbaa !24
  br label %bb77
bb86:
  br label %bb87
bb87:
  %t489 = load i64, ptr %l22, !tbaa !24
  %t491 = add i64 %t489, 1
  store i64 %t491, ptr %l22, !tbaa !24
  br label %bb59
bb88:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s16)
  br label %bb90
bb90:
  store ptr %l13, ptr %l207, !tbaa !29
  %t495 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t495, ptr %l209
  br label %bb91
bb91:
  %t496 = load ptr, ptr %l207, !tbaa !29
  %t497 = load { i64, ptr }, ptr %l209, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t496, { i64, ptr } %t497)
  br label %bb92
bb92:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l13, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb93
bb93:
  %t500 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l13)
  store { i64, ptr } %t500, ptr %l212
  br label %bb94
bb94:
  %t501 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t501, ptr %l213, !tbaa !27
  %t502 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l214, !tbaa !24
  %t504 = load i64, ptr %l214, !tbaa !24
  %t505 = mul i64 %t504, 1
  %t506 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t505)
  %t507 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t506, 1
  store { i64, ptr } %t508, ptr %l215, !tbaa !27
  %t509 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = load i64, ptr %l214, !tbaa !24
  %t514 = mul i64 %t513, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t510, ptr %t512, i64 %t514, i1 false)
  %t515 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t515, ptr %l213, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t516 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t516, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eadaptKey(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t12, i32 %a2)
  store { i64, ptr } %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t24, i64 %t25)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t38)
  store { i64, ptr } %t40, ptr %l13
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 65
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l15
  br label %bb6
bb6:
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp eq i64 %t26, %t27
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l24
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l4
  %t23 = load { i64, [2 x i64] }, ptr %l4
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %t35, i64 %t36)
  store { i64, ptr } %t39, ptr %l34
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t41, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  br label %bb66
bb6:
  %t47 = load { i64, [2 x i64] }, ptr %l4
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb7, label %bb8
bb7:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { i32, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l6, !tbaa !23
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t57 = getelementptr { i32, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t60, i32 %t61)
  store { i64, ptr } %t64, ptr %l42
  br label %bb10
bb10:
  %t65 = load i32, ptr %l7, !tbaa !23
  %t67 = icmp eq i32 %t65, 0
  br i1 %t67, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb14
bb12:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %s3, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l48
  br label %bb13
bb13:
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  br label %bb14
bb14:
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t97, i64 %t98)
  %t107 = getelementptr i8, ptr %t106, i64 %t98
  call void @olang_textcopy(ptr %t107, ptr %t99, i64 %t100)
  %t108 = getelementptr i8, ptr %t107, i64 %t100
  call void @olang_textcopy(ptr %t108, ptr %t103, i64 %t104)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t117)
  store { i64, ptr } %t119, ptr %l53
  br label %bb15
bb15:
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb16:
  %t121 = load { i64, [2 x i64] }, ptr %l4
  %t123 = extractvalue { i64, [2 x i64] } %t121, 0
  %t124 = icmp eq i64 %t123, 3
  br i1 %t124, label %bb17, label %bb18
bb17:
  %t126 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t127 = getelementptr { i32 }, ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t131 = load i32, ptr %l8, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l59
  br label %bb20
bb20:
  %t135 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t136, i64 %t137)
  %t142 = getelementptr i8, ptr %t141, i64 %t137
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t151)
  store { i64, ptr } %t153, ptr %l62
  br label %bb21
bb21:
  %t154 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t154, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb22:
  %t155 = load { i64, [2 x i64] }, ptr %l4
  %t157 = extractvalue { i64, [2 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 4
  br i1 %t158, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t160 = load i64, ptr %l1, !tbaa !24
  %t161 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t164 = call i64 @__olang_fmt_i64(ptr null, i64 %t160)
  %t165 = add i64 %t162, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t161, i64 %t162)
  %t167 = getelementptr i8, ptr %t166, i64 %t162
  %t168 = call i64 @__olang_fmt_i64(ptr %t167, i64 %t160)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  store { i64, ptr } %t170, ptr %l27, !tbaa !27
  br label %bb66
bb26:
  %t172 = load { i64, [2 x i64] }, ptr %l4
  %t174 = extractvalue { i64, [2 x i64] } %t172, 0
  %t175 = icmp eq i64 %t174, 5
  br i1 %t175, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %t177, i64 %t178)
  store { i64, ptr } %t181, ptr %l71
  br label %bb30
bb30:
  %t182 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t182, ptr %l27, !tbaa !27
  br label %bb66
bb31:
  %t183 = load { i64, [2 x i64] }, ptr %l4
  %t185 = extractvalue { i64, [2 x i64] } %t183, 0
  %t186 = icmp eq i64 %t185, 6
  br i1 %t186, label %bb32, label %bb33
bb32:
  %t188 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t189 = getelementptr { i64, i32 }, ptr %t188, i32 0, i32 0
  %t190 = load i64, ptr %t189
  store i64 %t190, ptr %l9, !tbaa !24
  %t192 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t193 = getelementptr { i64, i32 }, ptr %t192, i32 0, i32 1
  %t194 = load i32, ptr %t193
  store i32 %t194, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/emit:Emitter", ptr %t196, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 10
  %t205 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t204, i64 %t205)
  store ptr %t208, ptr %l81
  br label %bb35
bb35:
  %t209 = load ptr, ptr %l81, !tbaa !29
  %t211 = getelementptr %"compiler/load:Module", ptr %t209, i32 0, i32 2
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l83, !tbaa !27
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l10, !tbaa !23
  %t217 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t217, ptr %l86
  br label %bb36
bb36:
  %t218 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t224 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t219, i64 %t220)
  %t232 = getelementptr i8, ptr %t231, i64 %t220
  call void @olang_textcopy(ptr %t232, ptr %t221, i64 %t222)
  %t233 = getelementptr i8, ptr %t232, i64 %t222
  call void @olang_textcopy(ptr %t233, ptr %t225, i64 %t226)
  %t234 = getelementptr i8, ptr %t233, i64 %t226
  call void @olang_textcopy(ptr %t234, ptr %t228, i64 %t229)
  %t235 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t231, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t243)
  store { i64, ptr } %t245, ptr %l89
  br label %bb37
bb37:
  %t246 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t246, ptr %l27, !tbaa !27
  br label %bb66
bb38:
  %t247 = load { i64, [2 x i64] }, ptr %l4
  %t249 = extractvalue { i64, [2 x i64] } %t247, 0
  %t250 = icmp eq i64 %t249, 2
  br i1 %t250, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t252 = load i64, ptr %l1, !tbaa !24
  %t253 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t256 = call i64 @__olang_fmt_i64(ptr null, i64 %t252)
  %t257 = add i64 %t254, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = getelementptr i8, ptr %t258, i64 %t254
  %t260 = call i64 @__olang_fmt_i64(ptr %t259, i64 %t252)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  store { i64, ptr } %t262, ptr %l27, !tbaa !27
  br label %bb66
bb42:
  %t264 = load { i64, [2 x i64] }, ptr %l4
  %t266 = extractvalue { i64, [2 x i64] } %t264, 0
  %t267 = icmp eq i64 %t266, 7
  br i1 %t267, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t269 = load i64, ptr %l1, !tbaa !24
  %t270 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t273 = call i64 @__olang_fmt_i64(ptr null, i64 %t269)
  %t274 = add i64 %t271, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t270, i64 %t271)
  %t276 = getelementptr i8, ptr %t275, i64 %t271
  %t277 = call i64 @__olang_fmt_i64(ptr %t276, i64 %t269)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t275, 1
  store { i64, ptr } %t279, ptr %l27, !tbaa !27
  br label %bb66
bb46:
  %t281 = load { i64, [2 x i64] }, ptr %l4
  %t283 = extractvalue { i64, [2 x i64] } %t281, 0
  %t284 = icmp eq i64 %t283, 8
  br i1 %t284, label %bb47, label %bb48
bb47:
  %t286 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t287 = getelementptr { i32, i32, i64 }, ptr %t286, i32 0, i32 0
  %t288 = load i32, ptr %t287
  store i32 %t288, ptr %l11, !tbaa !23
  %t290 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t291 = getelementptr { i32, i32, i64 }, ptr %t290, i32 0, i32 1
  %t292 = load i32, ptr %t291, !range !{i32 0, i32 1}
  store i32 %t292, ptr %l12
  %t294 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t295 = getelementptr { i32, i32, i64 }, ptr %t294, i32 0, i32 2
  %t296 = load i64, ptr %t295
  store i64 %t296, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l11, !tbaa !23
  %t301 = sext i32 %t299 to i64
  %t304 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s17, ptr %t298, i64 %t301)
  store { i64, ptr } %t304, ptr %l106
  br label %bb50
bb50:
  %t305 = load i32, ptr %l12, !range !{i32 0, i32 1}
  store i32 %t305, ptr %l107
  %t306 = load i64, ptr %l13, !tbaa !24
  store i64 %t306, ptr %l108, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t307 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  call void @__olang_sb_put(ptr %s18, ptr %t308, i64 %t309)
  %t310 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t310, i64 %t311)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %s18, ptr %l107, i64 0)
  br label %bb51
bb51:
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t313, i64 %t314)
  %t315 = load i64, ptr %l108, !tbaa !24
  %t316 = call ptr @__olang_sb_room(ptr %s18, i64 24)
  %t317 = call i64 @__olang_fmt_i64(ptr %t316, i64 %t315)
  call void @__olang_sb_add(ptr %s18, i64 %t317)
  %t318 = load ptr, ptr %s18
  %t319 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t320 = load i64, ptr %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t318, i64 %t320)
  %t322 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l110, !tbaa !27
  %t324 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t325 = load ptr, ptr %t324
  %t326 = icmp ne ptr %t325, null
  br i1 %t326, label %sbgrew.327, label %sbdone.328
sbgrew.327:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.328
sbdone.328:
  %t329 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t335)
  store { i64, ptr } %t337, ptr %l112
  br label %bb52
bb52:
  %t338 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t338, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb66
bb53:
  %t339 = load { i64, [2 x i64] }, ptr %l4
  %t341 = extractvalue { i64, [2 x i64] } %t339, 0
  %t342 = icmp eq i64 %t341, 9
  br i1 %t342, label %bb54, label %bb55
bb54:
  %t344 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t345 = getelementptr { i64, i64 }, ptr %t344, i32 0, i32 0
  %t346 = load i64, ptr %t345
  store i64 %t346, ptr %l14, !tbaa !24
  %t348 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t349 = getelementptr { i64, i64 }, ptr %t348, i32 0, i32 1
  %t350 = load i64, ptr %t349
  store i64 %t350, ptr %l15, !tbaa !24
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i64, ptr %l14, !tbaa !24
  %t356 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s19, ptr %t352, i64 %t353)
  store { i64, ptr } %t356, ptr %l119
  br label %bb57
bb57:
  %t357 = load i64, ptr %l15, !tbaa !24
  %t358 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t359 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t360 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 1
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t363 = add i64 %t359, %t362
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t366 = add i64 %t363, %t365
  %t368 = call i64 @__olang_fmt_i64(ptr null, i64 %t357)
  %t369 = add i64 %t366, %t368
  %t370 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t369)
  call void @olang_textcopy(ptr %t370, ptr %t358, i64 %t359)
  %t371 = getelementptr i8, ptr %t370, i64 %t359
  call void @olang_textcopy(ptr %t371, ptr %t361, i64 %t362)
  %t372 = getelementptr i8, ptr %t371, i64 %t362
  call void @olang_textcopy(ptr %t372, ptr %t364, i64 %t365)
  %t373 = getelementptr i8, ptr %t372, i64 %t365
  %t374 = call i64 @__olang_fmt_i64(ptr %t373, i64 %t357)
  %t375 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t370, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  %t385 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t383)
  store { i64, ptr } %t385, ptr %l123
  br label %bb58
bb58:
  %t386 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t386, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb66
bb59:
  %t387 = load { i64, [2 x i64] }, ptr %l4
  %t389 = extractvalue { i64, [2 x i64] } %t387, 0
  %t390 = icmp eq i64 %t389, 10
  br i1 %t390, label %bb60, label %bb61
bb60:
  %t392 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t393 = getelementptr { i32, i64 }, ptr %t392, i32 0, i32 0
  %t394 = load i32, ptr %t393
  store i32 %t394, ptr %l16, !tbaa !23
  %t396 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t397 = getelementptr { i32, i64 }, ptr %t396, i32 0, i32 1
  %t398 = load i64, ptr %t397
  store i64 %t398, ptr %l17, !tbaa !24
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s21
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i32, ptr %l16, !tbaa !23
  %t404 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s21, ptr %t400, i32 %t401)
  store { i64, ptr } %t404, ptr %l130
  br label %bb63
bb63:
  %t405 = load i64, ptr %l17, !tbaa !24
  %t406 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t407 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t408 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = add i64 %t407, %t410
  %t412 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t414 = add i64 %t411, %t413
  %t416 = call i64 @__olang_fmt_i64(ptr null, i64 %t405)
  %t417 = add i64 %t414, %t416
  %t418 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t417)
  call void @olang_textcopy(ptr %t418, ptr %t406, i64 %t407)
  %t419 = getelementptr i8, ptr %t418, i64 %t407
  call void @olang_textcopy(ptr %t419, ptr %t409, i64 %t410)
  %t420 = getelementptr i8, ptr %t419, i64 %t410
  call void @olang_textcopy(ptr %t420, ptr %t412, i64 %t413)
  %t421 = getelementptr i8, ptr %t420, i64 %t413
  %t422 = call i64 @__olang_fmt_i64(ptr %t421, i64 %t405)
  %t423 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t418, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = extractvalue { i64, ptr } %t424, 1
  %t428 = mul i64 %t426, 1
  %t429 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t428)
  call void @llvm.memcpy.p0.p0.i64(ptr %t429, ptr %t427, i64 %t428, i1 false)
  %t430 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  %t433 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t431)
  store { i64, ptr } %t433, ptr %l134
  br label %bb64
bb64:
  %t434 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t434, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_de1fe604fb5e87cf_ff4728625cff78d3)
  unreachable
bb66:
  %t435 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t435, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/cabi:Way"
  %l8 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l76 = alloca %"compiler/cabi:Way"
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l5, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 %a3, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l19, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load ptr, ptr %l21, !tbaa !29
  %t27 = getelementptr %"compiler/cabi:Regs", ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = sub i64 %t28, 2
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = getelementptr %"compiler/cabi:Regs", ptr %t32, i32 0, i32 0
  store i64 %t30, ptr %t33, !tbaa !24
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l27, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l30
  br label %bb9
bb9:
  %t55 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t57 = trunc i64 21 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t62 = getelementptr %"compiler/cabi:Regs", ptr %t61, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = sub i64 %t63, 1
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Regs", ptr %t67, i32 0, i32 0
  store i64 %t65, ptr %t68, !tbaa !24
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t69, ptr %l37, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l38, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l39, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l42
  br label %bb13
bb13:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb14, label %bb15
bb14:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l46
  br label %bb16
bb15:
  %t96 = load i32, ptr %l5, !tbaa !23
  store i32 %t96, ptr %l43, !tbaa !23
  br label %bb17
bb16:
  %t98 = load i32, ptr %l46, !tbaa !23
  store i32 %t98, ptr %l43, !tbaa !23
  br label %bb17
bb17:
  %t99 = load i32, ptr %l43, !tbaa !23
  store i32 %t99, ptr %l6, !tbaa !23
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t101 = load i32, ptr %l5, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l50
  br label %bb18
bb18:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb20:
  %t106 = load ptr, ptr %l4, !tbaa !29
  store ptr %t106, ptr %l52, !tbaa !29
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  %t115 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t117 = trunc i64 19 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l51, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l59, !tbaa !29
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = getelementptr %"compiler/cabi:Regs", ptr %t122, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = sub i64 %t124, 1
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = getelementptr %"compiler/cabi:Regs", ptr %t128, i32 0, i32 0
  store i64 %t126, ptr %t129, !tbaa !24
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t130, ptr %l63, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l64, !tbaa !24
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l65, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l64, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l69
  br label %bb27
bb27:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/emit:Emitter", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/emit:Emitter", ptr %t158, i32 0, i32 46
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t162 = load i32, ptr %l1, !tbaa !23
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t168 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t157, { i64, ptr } %t161, i32 %t162, ptr %t163)
  store %"compiler/cabi:Way" %t168, ptr %l76
  br label %bb28
bb28:
  %t169 = load %"compiler/cabi:Way", ptr %l76
  store %"compiler/cabi:Way" %t169, ptr %l7
  %t170 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 0
  %t171 = load i32, ptr %t170, !range !{i32 0, i32 5}
  store i32 %t171, ptr %l8
  %t173 = load i32, ptr %l8, !range !{i32 0, i32 5}
  %t175 = trunc i64 0 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l1, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s4, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l83
  br label %bb32
bb32:
  %t183 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t184, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t186, ptr %l85
  br label %bb33
bb33:
  %t187 = load i1, ptr %l85, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb34, label %bb35
bb34:
  %t190 = getelementptr %"compiler/cabi:Way", ptr %l7, i32 0, i32 4
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t195 = extractvalue { i64, ptr } %t191, 1
  %t196 = extractvalue { i64, ptr } %t191, 0
  %t197 = add i64 %t193, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = getelementptr i8, ptr %t198, i64 %t193
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l87, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb36
bb36:
  %t210 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = add i64 %t212, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t211, i64 %t212)
  %t218 = getelementptr i8, ptr %t217, i64 %t212
  call void @olang_textcopy(ptr %t218, ptr %t214, i64 %t215)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t217, 1
  store { i64, ptr } %t220, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb37:
  %t222 = load i32, ptr %l8, !range !{i32 0, i32 5}
  %t224 = trunc i64 1 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t228 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t228, ptr %l95
  br label %bb41
bb41:
  %t229 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t229, ptr %l78, !tbaa !27
  br label %bb54
bb42:
  %t230 = load i32, ptr %l8, !range !{i32 0, i32 5}
  %t232 = trunc i64 2 to i32
  %t233 = icmp eq i32 %t230, %t232
  br i1 %t233, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb49
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l1, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s8, ptr %t235, i32 %t236)
  store { i64, ptr } %t239, ptr %l100
  br label %bb46
bb46:
  %t240 = load ptr, ptr %l4, !tbaa !29
  %t241 = load i32, ptr %l1, !tbaa !23
  %t244 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t240, i32 %t241)
  store i64 %t244, ptr %l103
  br label %bb47
bb47:
  %t245 = load i64, ptr %l103, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t245, i64 8)
  store i64 %t246, ptr %l104
  br label %bb48
bb48:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = load i64, ptr %l104, !tbaa !24
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t256)
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t247, i64 %t248)
  %t260 = getelementptr i8, ptr %t259, i64 %t248
  call void @olang_textcopy(ptr %t260, ptr %t250, i64 %t251)
  %t261 = getelementptr i8, ptr %t260, i64 %t251
  call void @olang_textcopy(ptr %t261, ptr %t253, i64 %t254)
  %t262 = getelementptr i8, ptr %t261, i64 %t254
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t256)
  %t264 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t259, 1
  store { i64, ptr } %t265, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l106, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t267, ptr %l78, !tbaa !27
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2854570d7fadf599_61afc1034d008305)
  unreachable
bb54:
  %t269 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l108, !tbaa !24
  %t271 = load i64, ptr %l108, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l109, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l108, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t282, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 62
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 62
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l13
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t20 = load i64, ptr %l13, !tbaa !24
  store i64 %t20, ptr %l9, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l9, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l16
  br label %bb9
bb9:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 62
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29, i64 %t30)
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l27
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb13, label %ok.47, !prof !99
ok.47:
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  br label %bb15
bb13:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l25, !tbaa !27
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l34, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb16
bb16:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l38
  br label %bb17
bb17:
  %t71 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t71, i64 %t72)
  %t88 = getelementptr i8, ptr %t87, i64 %t72
  call void @olang_textcopy(ptr %t88, ptr %t74, i64 %t75)
  %t89 = getelementptr i8, ptr %t88, i64 %t75
  call void @olang_textcopy(ptr %t89, ptr %t77, i64 %t78)
  %t90 = getelementptr i8, ptr %t89, i64 %t78
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t87, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l33, !tbaa !29
  %t102 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t101, i64 %t102, { i64, ptr } %t100)
  br label %bb18
bb18:
  %t104 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgGenFile(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 60
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 60
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 60
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i32
  %l83 = alloca i64
  %l92 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca i64
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l115 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i32
  %l143 = alloca i32
  %l148 = alloca i32
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca i32
  %l163 = alloca i32
  %l164 = alloca i64
  %l166 = alloca i64
  %l174 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca i64
  %l179 = alloca { i64, ptr }
  %l192 = alloca i64
  %l196 = alloca i1
  %l199 = alloca i64
  %l205 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca i32
  %l210 = alloca i32
  %l213 = alloca i32
  %l214 = alloca i64
  %l216 = alloca i64
  %l222 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca i64
  %l230 = alloca i64
  %l232 = alloca i64
  %l233 = alloca ptr
  %l234 = alloca i64
  %l235 = alloca ptr
  %l238 = alloca i32
  %l239 = alloca i64
  %l252 = alloca i1
  %l255 = alloca i1
  %l258 = alloca i1
  %l259 = alloca ptr
  %l262 = alloca i32
  %l263 = alloca i32
  %l268 = alloca i64
  %l274 = alloca ptr
  %l278 = alloca i32
  %l281 = alloca i32
  %l284 = alloca i32
  %l285 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l294 = alloca %"std/prelude/text:StringBuilder"
  %l300 = alloca i64
  %l303 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca i1
  %l328 = alloca { i64, ptr }
  %l331 = alloca i64
  %l335 = alloca i64
  %l337 = alloca i64
  %l338 = alloca ptr
  %l339 = alloca i64
  %l342 = alloca { i64, ptr }
  %l343 = alloca i64
  %l345 = alloca { i64, ptr }
  %l348 = alloca i64
  %l365 = alloca i64
  %l366 = alloca ptr
  %l367 = alloca i64
  %l369 = alloca { i64, ptr }
  %l372 = alloca ptr
  %l373 = alloca i64
  %l376 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l386 = alloca i1
  %l389 = alloca i1
  %l390 = alloca ptr
  %l393 = alloca i32
  %l394 = alloca i32
  %l399 = alloca i64
  %l407 = alloca { i64, ptr }
  %l410 = alloca { i64, ptr }
  %l414 = alloca ptr
  %l417 = alloca i32
  %l420 = alloca i32
  %l423 = alloca i32
  %l424 = alloca { i64, ptr }
  %l425 = alloca %"std/prelude/text:StringBuilder"
  %l431 = alloca i64
  %l434 = alloca i64
  %l453 = alloca i64
  %l457 = alloca i1
  %l462 = alloca { i64, ptr }
  %l464 = alloca { i64, ptr }
  %l467 = alloca { i64, ptr }
  %l471 = alloca ptr
  %l472 = alloca i64
  %l474 = alloca { i64, ptr }
  %l488 = alloca i64
  %l489 = alloca ptr
  %l490 = alloca i64
  %l492 = alloca { i64, ptr }
  %l497 = alloca i1
  %l500 = alloca i64
  %l503 = alloca i64
  %l504 = alloca ptr
  %l506 = alloca i32
  %l508 = alloca i32
  %l510 = alloca i32
  %l511 = alloca i64
  %l512 = alloca ptr
  %l513 = alloca i64
  %l516 = alloca { i64, ptr }
  %l518 = alloca { i64, ptr }
  %l520 = alloca i64
  %l530 = alloca i64
  %l533 = alloca i64
  %l535 = alloca i64
  %l541 = alloca ptr
  %l542 = alloca i64
  %l543 = alloca ptr
  %l545 = alloca i32
  %l546 = alloca i64
  %l553 = alloca i64
  %l555 = alloca i64
  %l557 = alloca i64
  %l576 = alloca ptr
  %l577 = alloca i64
  %l580 = alloca { i64, ptr }
  %l582 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l57
  br label %bb1
bb1:
  %t11 = load i32, ptr %l57, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t16 = icmp sge i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = icmp sle i32 %t18, 14
  store i1 %t20, ptr %l61, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l61, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l67
  br label %bb7
bb7:
  %t28 = load i32, ptr %l67, !range !{i32 0, i32 33}
  %t30 = trunc i64 31 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l64, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l64, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 63
  %t37 = load i32, ptr %l3, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t36, i64 %t39)
  store i1 %t42, ptr %l74
  br label %bb11
bb10:
  br label %bb46
bb11:
  %t43 = load i1, ptr %l74, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:Emitter", ptr %t44, i32 0, i32 63
  %t47 = load i32, ptr %l3, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t52 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t49)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l81
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb15, label %ok.56, !prof !99
ok.56:
  store i64 %t53, ptr %l80
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t57 = load i64, ptr %l80, !tbaa !24
  store i64 %t57, ptr %l75, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t58 = load i64, ptr %l75, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l83
  br label %bb19
bb19:
  %t62 = load i64, ptr %l83, !tbaa !24
  store i64 %t62, ptr %l4, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/emit:Emitter", ptr %t63, i32 0, i32 63
  %t66 = load i32, ptr %l3, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t69 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t65, i64 %t68, i64 %t69)
  br label %bb20
bb20:
  %t73 = load i32, ptr %l3, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb31
bb22:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l95
  br label %bb23
bb23:
  %t84 = load i1, ptr %l95, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb30
bb25:
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l99
  br label %bb26
bb26:
  %t90 = load i1, ptr %l99, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t91, ptr %l96, !tbaa !27
  br label %bb30
bb30:
  %t92 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t92, ptr %l92, !tbaa !27
  br label %bb31
bb31:
  %t93 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t93, ptr %l5, !tbaa !27
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l103
  br label %bb32
bb32:
  %t99 = load i64, ptr %l103, !tbaa !24
  %t100 = icmp eq i64 %t99, 8
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t102, i32 %t103)
  store i1 %t106, ptr %l108
  br label %bb35
bb34:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb36
bb35:
  %t107 = load i1, ptr %l108, !tbaa !21
  store i1 %t107, ptr %l105, !tbaa !21
  br label %bb36
bb36:
  %t108 = load i1, ptr %l105, !tbaa !21
  br i1 %t108, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t109 = load i32, ptr %l3, !tbaa !23
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb40, label %bb41
bb40:
  store i64 8, ptr %l112, !tbaa !24
  br label %bb43
bb41:
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t115, i32 %t116)
  store i64 %t119, ptr %l115
  br label %bb42
bb42:
  %t120 = load i64, ptr %l115, !tbaa !24
  %t121 = add i64 %t120, 7
  %t123 = sdiv i64 %t121, 8
  %t125 = mul i64 %t123, 8
  store i64 %t125, ptr %l112, !tbaa !24
  br label %bb43
bb43:
  %t127 = load i64, ptr %l112, !tbaa !24
  store i64 %t127, ptr %l6, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l119, !tbaa !29
  %t129 = load i64, ptr %l4, !tbaa !24
  store i64 %t129, ptr %l120, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t131 = load i32, ptr %l3, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l123
  br label %bb44
bb44:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t148 = add i64 %t145, %t147
  %t149 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t136, 1
  %t154 = extractvalue { i64, ptr } %t136, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t137, i64 %t138)
  %t160 = getelementptr i8, ptr %t159, i64 %t138
  call void @olang_textcopy(ptr %t160, ptr %t140, i64 %t141)
  %t161 = getelementptr i8, ptr %t160, i64 %t141
  call void @olang_textcopy(ptr %t161, ptr %t143, i64 %t144)
  %t162 = getelementptr i8, ptr %t161, i64 %t144
  %t163 = call i64 @__olang_fmt_i64(ptr %t162, i64 %t135)
  %t164 = getelementptr i8, ptr %t162, i64 %t147
  call void @olang_textcopy(ptr %t164, ptr %t149, i64 %t150)
  %t165 = getelementptr i8, ptr %t164, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t159, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t176 = load ptr, ptr %l119, !tbaa !29
  %t177 = load i64, ptr %l120, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t176, i64 %t177, { i64, ptr } %t175)
  br label %bb45
bb45:
  %t179 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t179, ptr %rv
  br label %ret
bb46:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %t181, i32 0, i32 64
  %t184 = load i32, ptr %l3, !tbaa !23
  %t186 = sext i32 %t184 to i64
  %t189 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t183, i64 %t186)
  store i1 %t189, ptr %l133
  br label %bb47
bb47:
  %t190 = load i1, ptr %l133, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %t191, i32 0, i32 64
  %t194 = load i32, ptr %l3, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t199 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t193, i64 %t196)
  %t200 = extractvalue { i32, i64 } %t199, 1
  %t201 = extractvalue { i32, i64 } %t199, 0
  store i32 %t201, ptr %l140
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb51, label %ok.203, !prof !99
ok.203:
  store i64 %t200, ptr %l139
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t204 = load i64, ptr %l139, !tbaa !24
  store i64 %t204, ptr %l134, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l134, !tbaa !24
  br label %bb53
bb53:
  %t205 = load i64, ptr %l134, !tbaa !24
  store i64 %t205, ptr %rv
  br label %ret
bb54:
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t207 = load i32, ptr %l3, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l143
  br label %bb55
bb55:
  %t211 = load i32, ptr %l143, !range !{i32 0, i32 33}
  store i32 %t211, ptr %l7
  %t212 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t214 = trunc i64 20 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l148
  br label %bb58
bb57:
  br label %bb75
bb58:
  %t222 = load i32, ptr %l148, !tbaa !23
  store i32 %t222, ptr %l8, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l3, !tbaa !23
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s6, ptr %t223, i32 %t224)
  store { i64, ptr } %t227, ptr %l151
  br label %bb59
bb59:
  %t228 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t234, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t236, ptr %l153
  br label %bb60
bb60:
  %t237 = load i1, ptr %l153, !tbaa !21
  %t238 = xor i1 %t237, true
  br i1 %t238, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l155, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  store i32 %t241, ptr %l156, !tbaa !23
  %t242 = load ptr, ptr %l2, !tbaa !29
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s7, ptr %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i32 %t244, ptr %l158
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t245 = load ptr, ptr %l2, !tbaa !29
  store ptr %t245, ptr %l159, !tbaa !29
  %t246 = load ptr, ptr %l2, !tbaa !29
  %t247 = load i32, ptr %l8, !tbaa !23
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t246, i32 %t247)
  store i32 %t250, ptr %l162
  br label %bb64
bb64:
  %t251 = load ptr, ptr %l159, !tbaa !29
  %t252 = load i32, ptr %l162, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t251, i32 %t252)
  store i32 %t253, ptr %l163
  br label %bb65
bb65:
  %t254 = load ptr, ptr %l155, !tbaa !29
  %t255 = load i32, ptr %l156, !tbaa !23
  %t256 = load i32, ptr %l158, !tbaa !23
  %t257 = load i32, ptr %l163, !tbaa !23
  %t258 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s7, ptr %s7, ptr %t254, i32 %t255, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, i32 %t256, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d65, i32 0, i32 1) }, i32 %t257)
  store i64 %t258, ptr %l164
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  %t259 = load i64, ptr %l164, !tbaa !24
  store i64 %t259, ptr %rv
  br label %ret
bb67:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t260)
  store i64 %t262, ptr %l166
  br label %bb68
bb68:
  %t263 = load i64, ptr %l166, !tbaa !24
  store i64 %t263, ptr %l9, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/emit:Emitter", ptr %t264, i32 0, i32 64
  %t267 = load i32, ptr %l3, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t266, i64 %t269, i64 %t270)
  br label %bb69
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l8, !tbaa !23
  %t278 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t274, i32 %t275)
  store i64 %t278, ptr %l174
  br label %bb70
bb70:
  %t279 = load i64, ptr %l174, !tbaa !24
  store i64 %t279, ptr %l10, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l175, !tbaa !29
  %t281 = load i64, ptr %l9, !tbaa !24
  store i64 %t281, ptr %l176, !tbaa !24
  %t282 = load i64, ptr %l10, !tbaa !24
  %t284 = icmp sge i64 %t282, 0
  br i1 %t284, label %bb71, label %bb72
bb71:
  %t286 = load i64, ptr %l10, !tbaa !24
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t290 = call i64 @__olang_fmt_i64(ptr null, i64 %t286)
  %t291 = add i64 %t288, %t290
  %t292 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t287, i64 %t288)
  %t293 = getelementptr i8, ptr %t292, i64 %t288
  %t294 = call i64 @__olang_fmt_i64(ptr %t293, i64 %t286)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t292, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  store { i64, ptr } %t303, ptr %l179, !tbaa !27
  br label %bb73
bb72:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l179, !tbaa !27
  br label %bb73
bb73:
  %t305 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t307 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t314 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t305, i64 %t306)
  %t315 = getelementptr i8, ptr %t314, i64 %t306
  call void @olang_textcopy(ptr %t315, ptr %t308, i64 %t309)
  %t316 = getelementptr i8, ptr %t315, i64 %t309
  call void @olang_textcopy(ptr %t316, ptr %t311, i64 %t312)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t314, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = extractvalue { i64, ptr } %t318, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t326 = load ptr, ptr %l175, !tbaa !29
  %t327 = load i64, ptr %l176, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s6, ptr %t326, i64 %t327, { i64, ptr } %t325)
  br label %bb74
bb74:
  %t329 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t329, ptr %rv
  br label %ret
bb75:
  %t331 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t333 = trunc i64 21 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l3, !tbaa !23
  %t338 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t339 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t344 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s10, ptr %s10, ptr %t336, i32 %t337, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d70, i32 0, i32 1) }, i32 %t338, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, i32 %t339)
  store i64 %t344, ptr %l192
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t345 = load i64, ptr %l192, !tbaa !24
  store i64 %t345, ptr %rv
  br label %ret
bb79:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/emit:Emitter", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t350 = load i32, ptr %l3, !tbaa !23
  %t353 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t349, i32 %t350)
  store i1 %t353, ptr %l196
  br label %bb80
bb80:
  %t354 = load ptr, ptr %l2, !tbaa !29
  %t355 = load i32, ptr %l3, !tbaa !23
  %t358 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t354, i32 %t355)
  store i64 %t358, ptr %l199
  br label %bb81
bb81:
  %t359 = load i64, ptr %l199, !tbaa !24
  %t360 = mul i64 %t359, 8
  store i64 %t360, ptr %l11, !tbaa !24
  %t362 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t364 = trunc i64 19 to i32
  %t365 = icmp eq i32 %t362, %t364
  br i1 %t365, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i32, ptr %l3, !tbaa !23
  %t371 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t367, i32 %t368)
  store i32 %t371, ptr %l205
  br label %bb84
bb83:
  br label %bb104
bb84:
  %t372 = load i32, ptr %l205, !tbaa !23
  %t373 = icmp eq i32 %t372, 0
  br i1 %t373, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s12
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l207, !tbaa !29
  %t376 = load i32, ptr %l3, !tbaa !23
  store i32 %t376, ptr %l208, !tbaa !23
  %t377 = load ptr, ptr %l2, !tbaa !29
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s12, ptr %t377, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i32 %t379, ptr %l210
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t381 = load i32, ptr %l3, !tbaa !23
  %t384 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t380, i32 %t381)
  store i32 %t384, ptr %l213
  br label %bb88
bb88:
  %t385 = load ptr, ptr %l207, !tbaa !29
  %t386 = load i32, ptr %l208, !tbaa !23
  %t387 = load i32, ptr %l210, !tbaa !23
  %t388 = load i32, ptr %l213, !tbaa !23
  %t389 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s12, ptr %s12, ptr %t385, i32 %t386, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, i32 %t387, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d74, i32 0, i32 1) }, i32 %t388)
  store i64 %t389, ptr %l214
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  %t390 = load i64, ptr %l214, !tbaa !24
  store i64 %t390, ptr %rv
  br label %ret
bb90:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l216
  br label %bb91
bb91:
  %t394 = load i64, ptr %l216, !tbaa !24
  store i64 %t394, ptr %l12, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/emit:Emitter", ptr %t395, i32 0, i32 64
  %t398 = load i32, ptr %l3, !tbaa !23
  %t400 = sext i32 %t398 to i64
  %t401 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t397, i64 %t400, i64 %t401)
  br label %bb92
bb92:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l222, !tbaa !29
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t407 = load i32, ptr %l3, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l225
  br label %bb93
bb93:
  %t411 = load ptr, ptr %l222, !tbaa !29
  %t412 = load i32, ptr %l225, !tbaa !23
  %t413 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t411, i32 %t412)
  store i64 %t413, ptr %l226
  br label %bb94
bb94:
  %t414 = load i64, ptr %l226, !tbaa !24
  store i64 %t414, ptr %l13, !tbaa !24
  %t415 = load i64, ptr %l13, !tbaa !24
  %t417 = icmp slt i64 %t415, 0
  br i1 %t417, label %bb95, label %bb96
bb95:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t419)
  store i64 %t421, ptr %l230
  br label %bb97
bb96:
  br label %bb98
bb97:
  %t422 = load i64, ptr %l230, !tbaa !24
  store i64 %t422, ptr %l13, !tbaa !24
  br label %bb98
bb98:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t423)
  store i64 %t425, ptr %l232
  br label %bb99
bb99:
  %t426 = load i64, ptr %l232, !tbaa !24
  store i64 %t426, ptr %l14, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l233, !tbaa !29
  %t428 = load i64, ptr %l14, !tbaa !24
  store i64 %t428, ptr %l234, !tbaa !24
  %t429 = load ptr, ptr %l2, !tbaa !29
  store ptr %t429, ptr %l235, !tbaa !29
  %t430 = load ptr, ptr %l2, !tbaa !29
  %t431 = load i32, ptr %l3, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l238
  br label %bb100
bb100:
  %t435 = load ptr, ptr %l235, !tbaa !29
  %t436 = load i32, ptr %l238, !tbaa !23
  %t437 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t435, i32 %t436)
  store i64 %t437, ptr %l239
  br label %bb101
bb101:
  %t438 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t440 = load i64, ptr %l239, !tbaa !24
  %t441 = call i64 @__olang_fmt_i64(ptr null, i64 %t440)
  %t442 = add i64 %t439, %t441
  %t443 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t446 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t445)
  call void @olang_textcopy(ptr %t446, ptr %t438, i64 %t439)
  %t447 = getelementptr i8, ptr %t446, i64 %t439
  %t448 = call i64 @__olang_fmt_i64(ptr %t447, i64 %t440)
  %t449 = getelementptr i8, ptr %t447, i64 %t441
  call void @olang_textcopy(ptr %t449, ptr %t443, i64 %t444)
  %t450 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t446, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = extractvalue { i64, ptr } %t451, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t459 = load ptr, ptr %l233, !tbaa !29
  %t460 = load i64, ptr %l234, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t459, i64 %t460, { i64, ptr } %t458)
  br label %bb102
bb102:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load i64, ptr %l12, !tbaa !24
  %t464 = load i64, ptr %l13, !tbaa !24
  %t465 = load i64, ptr %l11, !tbaa !24
  %t466 = load i64, ptr %l14, !tbaa !24
  %t467 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t464)
  %t471 = add i64 %t468, %t470
  %t472 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t476 = call i64 @__olang_fmt_i64(ptr null, i64 %t465)
  %t477 = add i64 %t474, %t476
  %t478 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t479 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t480 = add i64 %t477, %t479
  %t482 = call i64 @__olang_fmt_i64(ptr null, i64 %t466)
  %t483 = add i64 %t480, %t482
  %t484 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t467, i64 %t468)
  %t488 = getelementptr i8, ptr %t487, i64 %t468
  %t489 = call i64 @__olang_fmt_i64(ptr %t488, i64 %t464)
  %t490 = getelementptr i8, ptr %t488, i64 %t470
  call void @olang_textcopy(ptr %t490, ptr %t472, i64 %t473)
  %t491 = getelementptr i8, ptr %t490, i64 %t473
  %t492 = call i64 @__olang_fmt_i64(ptr %t491, i64 %t465)
  %t493 = getelementptr i8, ptr %t491, i64 %t476
  call void @olang_textcopy(ptr %t493, ptr %t478, i64 %t479)
  %t494 = getelementptr i8, ptr %t493, i64 %t479
  %t495 = call i64 @__olang_fmt_i64(ptr %t494, i64 %t466)
  %t496 = getelementptr i8, ptr %t494, i64 %t482
  call void @olang_textcopy(ptr %t496, ptr %t484, i64 %t485)
  %t497 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t487, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = extractvalue { i64, ptr } %t498, 1
  %t502 = mul i64 %t500, 1
  %t503 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t502)
  call void @llvm.memcpy.p0.p0.i64(ptr %t503, ptr %t501, i64 %t502, i1 false)
  %t504 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t503, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t462, i64 %t463, { i64, ptr } %t505)
  br label %bb103
bb103:
  %t509 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  store i64 %t509, ptr %rv
  br label %ret
bb104:
  %t511 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t513 = trunc i64 22 to i32
  %t514 = icmp eq i32 %t511, %t513
  br i1 %t514, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb107
bb106:
  %t516 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t518 = trunc i64 23 to i32
  %t519 = icmp eq i32 %t516, %t518
  store i1 %t519, ptr %l252, !tbaa !21
  br label %bb107
bb107:
  %t521 = load i1, ptr %l252, !tbaa !21
  br i1 %t521, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb115
bb109:
  %t522 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t524 = trunc i64 18 to i32
  %t525 = icmp eq i32 %t522, %t524
  br i1 %t525, label %bb110, label %bb111
bb110:
  %t527 = load ptr, ptr %l2, !tbaa !29
  store ptr %t527, ptr %l259, !tbaa !29
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t529 = load i32, ptr %l3, !tbaa !23
  %t532 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t528, i32 %t529)
  store i32 %t532, ptr %l262
  br label %bb112
bb111:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb114
bb112:
  %t533 = load ptr, ptr %l259, !tbaa !29
  %t534 = load i32, ptr %l262, !tbaa !23
  %t535 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t533, i32 %t534)
  store i32 %t535, ptr %l263
  br label %bb113
bb113:
  %t536 = load i32, ptr %l263, !range !{i32 0, i32 6}
  %t538 = trunc i64 0 to i32
  %t539 = icmp eq i32 %t536, %t538
  store i1 %t539, ptr %l258, !tbaa !21
  br label %bb114
bb114:
  %t541 = load i1, ptr %l258, !tbaa !21
  store i1 %t541, ptr %l255, !tbaa !21
  br label %bb115
bb115:
  %t542 = load i1, ptr %l255, !tbaa !21
  br i1 %t542, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s16
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t545)
  store i64 %t547, ptr %l268
  br label %bb118
bb117:
  br label %bb162
bb118:
  %t548 = load i64, ptr %l268, !tbaa !24
  store i64 %t548, ptr %l16, !tbaa !24
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/emit:Emitter", ptr %t549, i32 0, i32 64
  %t552 = load i32, ptr %l3, !tbaa !23
  %t554 = sext i32 %t552 to i64
  %t555 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t551, i64 %t554, i64 %t555)
  br label %bb119
bb119:
  %t559 = load ptr, ptr %l2, !tbaa !29
  store ptr %t559, ptr %l274, !tbaa !29
  %t560 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t562 = trunc i64 18 to i32
  %t563 = icmp eq i32 %t560, %t562
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb120, label %bb121
bb120:
  %t567 = load ptr, ptr %l2, !tbaa !29
  %t568 = load i32, ptr %l3, !tbaa !23
  %t571 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t567, i32 %t568)
  store i32 %t571, ptr %l281
  br label %bb122
bb121:
  %t572 = load ptr, ptr %l2, !tbaa !29
  %t573 = load i32, ptr %l3, !tbaa !23
  %t576 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t572, i32 %t573)
  store i32 %t576, ptr %l284
  br label %bb123
bb122:
  %t577 = load i32, ptr %l281, !tbaa !23
  store i32 %t577, ptr %l278, !tbaa !23
  br label %bb124
bb123:
  %t578 = load i32, ptr %l284, !tbaa !23
  store i32 %t578, ptr %l278, !tbaa !23
  br label %bb124
bb124:
  %t579 = load ptr, ptr %l274, !tbaa !29
  %t580 = load i32, ptr %l278, !tbaa !23
  %t581 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t579, i32 %t580)
  store { i64, ptr } %t581, ptr %l285
  br label %bb125
bb125:
  %t582 = load { i64, ptr }, ptr %l285, !tbaa !27
  store { i64, ptr } %t582, ptr %l17, !tbaa !27
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load i32, ptr %l3, !tbaa !23
  %t585 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t591 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %s16, ptr %t583, i32 %t584, i64 %t587)
  store { i64, ptr } %t591, ptr %l290
  br label %bb126
bb126:
  %t592 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t592, ptr %l18, !tbaa !27
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t594 = load i32, ptr %l3, !tbaa !23
  %t597 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s16, ptr %t593, i32 %t594)
  store { i64, ptr } %t597, ptr %l293
  br label %bb127
bb127:
  %t598 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t598, ptr %l19, !tbaa !27
  %t599 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s16)
  store %"std/prelude/text:StringBuilder" %t599, ptr %l294
  br label %bb128
bb128:
  %t600 = load %"std/prelude/text:StringBuilder", ptr %l294
  store %"std/prelude/text:StringBuilder" %t600, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  %t601 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  store i64 %t603, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t605 = load i64, ptr %l22, !tbaa !24
  %t606 = load i64, ptr %l21, !tbaa !24
  %t609 = icmp sgt i64 %t605, %t606
  br i1 %t609, label %bb129, label %bb130
bb129:
  %t611 = load i64, ptr %l23, !tbaa !24
  %t613 = icmp sgt i64 %t611, 0
  br i1 %t613, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l300, !tbaa !24
  br label %bb134
bb131:
  %t615 = load i64, ptr %l22, !tbaa !24
  %t616 = load i64, ptr %l21, !tbaa !24
  %t619 = sub i64 %t615, %t616
  %t620 = load i64, ptr %l23, !tbaa !24
  %t623 = add i64 %t619, %t620
  %t625 = sub i64 %t623, 1
  %t626 = load i64, ptr %l23, !tbaa !24
  %t629 = sdiv i64 %t625, %t626
  store i64 %t629, ptr %l303, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l303, !tbaa !24
  br label %bb133
bb133:
  %t631 = load i64, ptr %l303, !tbaa !24
  store i64 %t631, ptr %l300, !tbaa !24
  br label %bb134
bb134:
  %t632 = load i64, ptr %l300, !tbaa !24
  store i64 %t632, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb135
bb135:
  store %olang.scope zeroinitializer, ptr %s18
  %t633 = load i64, ptr %l25, !tbaa !24
  %t634 = load i64, ptr %l24, !tbaa !24
  %t637 = icmp slt i64 %t633, %t634
  %t639 = xor i1 %t637, true
  br i1 %t639, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb137:
  br label %bb138
bb138:
  %t641 = load i64, ptr %l21, !tbaa !24
  %t642 = load i64, ptr %l25, !tbaa !24
  %t643 = load i64, ptr %l23, !tbaa !24
  %t646 = mul i64 %t642, %t643
  %t649 = add i64 %t641, %t646
  store i64 %t649, ptr %l26, !tbaa !24
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/emit:Emitter", ptr %t651, i32 0, i32 0
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t655, ptr %l323, !tbaa !27
  %t656 = load i64, ptr %l26, !tbaa !24
  %t658 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr i32, ptr %t659, i64 %t656
  %t661 = load i32, ptr %t660, !tbaa !33
  %t664 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t654, i32 %t661)
  store i1 %t664, ptr %l326
  br label %bb139
bb139:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t666, ptr %l328, !tbaa !27
  %t667 = load i64, ptr %l26, !tbaa !24
  %t669 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr i32, ptr %t670, i64 %t667
  %t672 = load i32, ptr %t671, !tbaa !33
  %t675 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t665, i32 %t672)
  store i64 %t675, ptr %l331
  br label %bb140
bb140:
  %t676 = load i64, ptr %l331, !tbaa !24
  store i64 %t676, ptr %l27, !tbaa !24
  %t677 = load i64, ptr %l27, !tbaa !24
  %t679 = icmp slt i64 %t677, 0
  br i1 %t679, label %bb141, label %bb142
bb141:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t681)
  store i64 %t683, ptr %l335
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t684 = load i64, ptr %l335, !tbaa !24
  store i64 %t684, ptr %l27, !tbaa !24
  br label %bb144
bb144:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t685)
  store i64 %t687, ptr %l337
  br label %bb145
bb145:
  %t688 = load i64, ptr %l337, !tbaa !24
  store i64 %t688, ptr %l28, !tbaa !24
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l338, !tbaa !29
  %t690 = load i64, ptr %l28, !tbaa !24
  store i64 %t690, ptr %l339, !tbaa !24
  %t691 = load i64, ptr %l26, !tbaa !24
  %t693 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t694 = load ptr, ptr %t693, !tbaa !27
  %t695 = getelementptr { i64, ptr }, ptr %t694, i64 %t691
  %t696 = load { i64, ptr }, ptr %t695, !tbaa !37
  %t698 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s18, { i64, ptr } %t696)
  store { i64, ptr } %t698, ptr %l342
  br label %bb146
bb146:
  %t699 = load i64, ptr %l27, !tbaa !24
  store i64 %t699, ptr %l343, !tbaa !24
  %t700 = load ptr, ptr %l2, !tbaa !29
  %t701 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t701, ptr %l345, !tbaa !27
  %t702 = load i64, ptr %l26, !tbaa !24
  %t704 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !27
  %t706 = getelementptr i32, ptr %t705, i64 %t702
  %t707 = load i32, ptr %t706, !tbaa !33
  %t710 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t700, i32 %t707)
  store i64 %t710, ptr %l348
  br label %bb147
bb147:
  %t711 = load i64, ptr %l348, !tbaa !24
  %t712 = mul i64 %t711, 8
  %t713 = load i64, ptr %l26, !tbaa !24
  %t715 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !27
  %t717 = getelementptr i64, ptr %t716, i64 %t713
  %t718 = load i64, ptr %t717, !tbaa !34
  %t720 = mul i64 %t718, 8
  %t721 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t723 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t723, 1
  %t725 = extractvalue { i64, ptr } %t723, 0
  %t726 = add i64 %t722, %t725
  %t727 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t728 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t729 = add i64 %t726, %t728
  %t730 = load i64, ptr %l343, !tbaa !24
  %t731 = call i64 @__olang_fmt_i64(ptr null, i64 %t730)
  %t732 = add i64 %t729, %t731
  %t733 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t735 = add i64 %t732, %t734
  %t737 = call i64 @__olang_fmt_i64(ptr null, i64 %t712)
  %t738 = add i64 %t735, %t737
  %t739 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t741 = add i64 %t738, %t740
  %t743 = call i64 @__olang_fmt_i64(ptr null, i64 %t720)
  %t744 = add i64 %t741, %t743
  %t745 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t721, i64 %t722)
  %t749 = getelementptr i8, ptr %t748, i64 %t722
  call void @olang_textcopy(ptr %t749, ptr %t724, i64 %t725)
  %t750 = getelementptr i8, ptr %t749, i64 %t725
  call void @olang_textcopy(ptr %t750, ptr %t727, i64 %t728)
  %t751 = getelementptr i8, ptr %t750, i64 %t728
  %t752 = call i64 @__olang_fmt_i64(ptr %t751, i64 %t730)
  %t753 = getelementptr i8, ptr %t751, i64 %t731
  call void @olang_textcopy(ptr %t753, ptr %t733, i64 %t734)
  %t754 = getelementptr i8, ptr %t753, i64 %t734
  %t755 = call i64 @__olang_fmt_i64(ptr %t754, i64 %t712)
  %t756 = getelementptr i8, ptr %t754, i64 %t737
  call void @olang_textcopy(ptr %t756, ptr %t739, i64 %t740)
  %t757 = getelementptr i8, ptr %t756, i64 %t740
  %t758 = call i64 @__olang_fmt_i64(ptr %t757, i64 %t720)
  %t759 = getelementptr i8, ptr %t757, i64 %t743
  call void @olang_textcopy(ptr %t759, ptr %t745, i64 %t746)
  %t760 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t748, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = extractvalue { i64, ptr } %t761, 1
  %t765 = mul i64 %t763, 1
  %t766 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t765)
  call void @llvm.memcpy.p0.p0.i64(ptr %t766, ptr %t764, i64 %t765, i1 false)
  %t767 = insertvalue { i64, ptr } undef, i64 %t763, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  %t769 = load ptr, ptr %l338, !tbaa !29
  %t770 = load i64, ptr %l339, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s18, ptr %t769, i64 %t770, { i64, ptr } %t768)
  br label %bb148
bb148:
  %t772 = load i64, ptr %l26, !tbaa !24
  %t774 = icmp sgt i64 %t772, 0
  br i1 %t774, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s21, ptr %l20, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb152:
  %t777 = load i64, ptr %l28, !tbaa !24
  %t778 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t779 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t781 = call i64 @__olang_fmt_i64(ptr null, i64 %t777)
  %t782 = add i64 %t779, %t781
  %t783 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t782)
  call void @olang_textcopy(ptr %t783, ptr %t778, i64 %t779)
  %t784 = getelementptr i8, ptr %t783, i64 %t779
  %t785 = call i64 @__olang_fmt_i64(ptr %t784, i64 %t777)
  %t786 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t783, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s18, ptr %l20, { i64, ptr } %t794)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s18)
  br label %bb154
bb154:
  %t797 = load i64, ptr %l25, !tbaa !24
  %t799 = add i64 %t797, 1
  store i64 %t799, ptr %l25, !tbaa !24
  br label %bb135
bb155:
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t801)
  store i64 %t803, ptr %l365
  br label %bb156
bb156:
  %t804 = load i64, ptr %l365, !tbaa !24
  store i64 %t804, ptr %l29, !tbaa !24
  %t805 = load ptr, ptr %l0, !tbaa !29
  store ptr %t805, ptr %l366, !tbaa !29
  %t806 = load i64, ptr %l29, !tbaa !24
  store i64 %t806, ptr %l367, !tbaa !24
  %t808 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s16, ptr %s16, ptr %l20)
  store { i64, ptr } %t808, ptr %l369
  br label %bb157
bb157:
  %t809 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t811 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t811, 1
  %t813 = extractvalue { i64, ptr } %t811, 0
  %t814 = add i64 %t810, %t813
  %t815 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t816 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t817 = add i64 %t814, %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t809, i64 %t810)
  %t819 = getelementptr i8, ptr %t818, i64 %t810
  call void @olang_textcopy(ptr %t819, ptr %t812, i64 %t813)
  %t820 = getelementptr i8, ptr %t819, i64 %t813
  call void @olang_textcopy(ptr %t820, ptr %t815, i64 %t816)
  %t821 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t822 = insertvalue { i64, ptr } %t821, ptr %t818, 1
  %t824 = extractvalue { i64, ptr } %t822, 0
  %t825 = extractvalue { i64, ptr } %t822, 1
  %t826 = mul i64 %t824, 1
  %t827 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t826)
  call void @llvm.memcpy.p0.p0.i64(ptr %t827, ptr %t825, i64 %t826, i1 false)
  %t828 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t827, 1
  %t830 = load ptr, ptr %l366, !tbaa !29
  %t831 = load i64, ptr %l367, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t830, i64 %t831, { i64, ptr } %t829)
  br label %bb158
bb158:
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l372, !tbaa !29
  %t834 = load i64, ptr %l16, !tbaa !24
  store i64 %t834, ptr %l373, !tbaa !24
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load i32, ptr %l3, !tbaa !23
  %t839 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s16, ptr %t835, i32 %t836)
  store { i64, ptr } %t839, ptr %l376
  br label %bb159
bb159:
  %t840 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 0
  %t842 = extractvalue { i64, ptr } %t840, 1
  %t843 = mul i64 %t841, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t844, ptr %t842, i64 %t843, i1 false)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  %t848 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s16, { i64, ptr } %t846)
  store { i64, ptr } %t848, ptr %l378
  br label %bb160
bb160:
  %t849 = load i64, ptr %l11, !tbaa !24
  %t850 = load i64, ptr %l29, !tbaa !24
  %t851 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t852 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t853 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t854 = extractvalue { i64, ptr } %t853, 1
  %t855 = extractvalue { i64, ptr } %t853, 0
  %t856 = add i64 %t852, %t855
  %t857 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t858 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t859 = add i64 %t856, %t858
  %t861 = call i64 @__olang_fmt_i64(ptr null, i64 %t849)
  %t862 = add i64 %t859, %t861
  %t863 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t865 = add i64 %t862, %t864
  %t867 = call i64 @__olang_fmt_i64(ptr null, i64 %t850)
  %t868 = add i64 %t865, %t867
  %t869 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t870 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t871 = add i64 %t868, %t870
  %t872 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t871)
  call void @olang_textcopy(ptr %t872, ptr %t851, i64 %t852)
  %t873 = getelementptr i8, ptr %t872, i64 %t852
  call void @olang_textcopy(ptr %t873, ptr %t854, i64 %t855)
  %t874 = getelementptr i8, ptr %t873, i64 %t855
  call void @olang_textcopy(ptr %t874, ptr %t857, i64 %t858)
  %t875 = getelementptr i8, ptr %t874, i64 %t858
  %t876 = call i64 @__olang_fmt_i64(ptr %t875, i64 %t849)
  %t877 = getelementptr i8, ptr %t875, i64 %t861
  call void @olang_textcopy(ptr %t877, ptr %t863, i64 %t864)
  %t878 = getelementptr i8, ptr %t877, i64 %t864
  %t879 = call i64 @__olang_fmt_i64(ptr %t878, i64 %t850)
  %t880 = getelementptr i8, ptr %t878, i64 %t867
  call void @olang_textcopy(ptr %t880, ptr %t869, i64 %t870)
  %t881 = insertvalue { i64, ptr } undef, i64 %t871, 0
  %t882 = insertvalue { i64, ptr } %t881, ptr %t872, 1
  %t884 = extractvalue { i64, ptr } %t882, 0
  %t885 = extractvalue { i64, ptr } %t882, 1
  %t886 = mul i64 %t884, 1
  %t887 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t886)
  call void @llvm.memcpy.p0.p0.i64(ptr %t887, ptr %t885, i64 %t886, i1 false)
  %t888 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  %t890 = load ptr, ptr %l372, !tbaa !29
  %t891 = load i64, ptr %l373, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t890, i64 %t891, { i64, ptr } %t889)
  br label %bb161
bb161:
  %t893 = load i64, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  store i64 %t893, ptr %rv
  br label %ret
bb162:
  %t895 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t897 = trunc i64 24 to i32
  %t898 = icmp eq i32 %t895, %t897
  br i1 %t898, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l386, !tbaa !21
  br label %bb170
bb164:
  %t900 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t902 = trunc i64 18 to i32
  %t903 = icmp eq i32 %t900, %t902
  br i1 %t903, label %bb165, label %bb166
bb165:
  %t905 = load ptr, ptr %l2, !tbaa !29
  store ptr %t905, ptr %l390, !tbaa !29
  %t906 = load ptr, ptr %l2, !tbaa !29
  %t907 = load i32, ptr %l3, !tbaa !23
  %t910 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t906, i32 %t907)
  store i32 %t910, ptr %l393
  br label %bb167
bb166:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb169
bb167:
  %t911 = load ptr, ptr %l390, !tbaa !29
  %t912 = load i32, ptr %l393, !tbaa !23
  %t913 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t911, i32 %t912)
  store i32 %t913, ptr %l394
  br label %bb168
bb168:
  %t914 = load i32, ptr %l394, !range !{i32 0, i32 6}
  %t916 = trunc i64 1 to i32
  %t917 = icmp eq i32 %t914, %t916
  store i1 %t917, ptr %l389, !tbaa !21
  br label %bb169
bb169:
  %t919 = load i1, ptr %l389, !tbaa !21
  store i1 %t919, ptr %l386, !tbaa !21
  br label %bb170
bb170:
  %t920 = load i1, ptr %l386, !tbaa !21
  br i1 %t920, label %bb171, label %bb172
bb171:
  store %olang.scope zeroinitializer, ptr %s26
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t925 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t923)
  store i64 %t925, ptr %l399
  br label %bb173
bb172:
  br label %bb256
bb173:
  %t926 = load i64, ptr %l399, !tbaa !24
  store i64 %t926, ptr %l31, !tbaa !24
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t929 = getelementptr %"compiler/emit:Emitter", ptr %t927, i32 0, i32 64
  %t930 = load i32, ptr %l3, !tbaa !23
  %t932 = sext i32 %t930 to i64
  %t933 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t929, i64 %t932, i64 %t933)
  br label %bb174
bb174:
  %t937 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t939 = trunc i64 18 to i32
  %t940 = icmp eq i32 %t937, %t939
  br i1 %t940, label %bb175, label %bb176
bb175:
  %t942 = load ptr, ptr %l2, !tbaa !29
  %t943 = load i32, ptr %l3, !tbaa !23
  %t946 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t942, i32 %t943)
  store { i64, ptr } %t946, ptr %l410
  br label %bb177
bb176:
  %t947 = icmp sge i64 0, 0
  br i1 %t947, label %bb178, label %bb179
bb177:
  %t949 = load { i64, ptr }, ptr %l410, !tbaa !27
  store { i64, ptr } %t949, ptr %l407, !tbaa !27
  br label %bb182
bb178:
  %t950 = icmp sle i64 0, 2305843009213693951
  br i1 %t950, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb180:
  %t952 = mul i64 0, 4
  %t953 = insertvalue { i64, ptr } undef, i64 0, 0
  %t954 = insertvalue { i64, ptr } %t953, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t954, ptr %l407, !tbaa !27
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb182:
  %t956 = load { i64, ptr }, ptr %l407, !tbaa !27
  store { i64, ptr } %t956, ptr %l32, !tbaa !27
  %t957 = load ptr, ptr %l2, !tbaa !29
  store ptr %t957, ptr %l414, !tbaa !29
  %t958 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t960 = trunc i64 24 to i32
  %t961 = icmp eq i32 %t958, %t960
  br i1 %t961, label %bb183, label %bb184
bb183:
  %t963 = load ptr, ptr %l2, !tbaa !29
  %t964 = load i32, ptr %l3, !tbaa !23
  %t967 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t963, i32 %t964)
  store i32 %t967, ptr %l420
  br label %bb185
bb184:
  %t968 = load ptr, ptr %l2, !tbaa !29
  %t969 = load i32, ptr %l3, !tbaa !23
  %t972 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t968, i32 %t969)
  store i32 %t972, ptr %l423
  br label %bb186
bb185:
  %t973 = load i32, ptr %l420, !tbaa !23
  store i32 %t973, ptr %l417, !tbaa !23
  br label %bb187
bb186:
  %t974 = load i32, ptr %l423, !tbaa !23
  store i32 %t974, ptr %l417, !tbaa !23
  br label %bb187
bb187:
  %t975 = load ptr, ptr %l414, !tbaa !29
  %t976 = load i32, ptr %l417, !tbaa !23
  %t977 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t975, i32 %t976)
  store { i64, ptr } %t977, ptr %l424
  br label %bb188
bb188:
  %t978 = load { i64, ptr }, ptr %l424, !tbaa !27
  store { i64, ptr } %t978, ptr %l33, !tbaa !27
  %t979 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s26)
  store %"std/prelude/text:StringBuilder" %t979, ptr %l425
  br label %bb189
bb189:
  %t980 = load %"std/prelude/text:StringBuilder", ptr %l425
  store %"std/prelude/text:StringBuilder" %t980, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  %t981 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t983 = extractvalue { i64, ptr } %t981, 0
  store i64 %t983, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t985 = load i64, ptr %l36, !tbaa !24
  %t986 = load i64, ptr %l35, !tbaa !24
  %t989 = icmp sgt i64 %t985, %t986
  br i1 %t989, label %bb190, label %bb191
bb190:
  %t991 = load i64, ptr %l37, !tbaa !24
  %t993 = icmp sgt i64 %t991, 0
  br i1 %t993, label %bb192, label %bb193
bb191:
  store i64 0, ptr %l431, !tbaa !24
  br label %bb195
bb192:
  %t995 = load i64, ptr %l36, !tbaa !24
  %t996 = load i64, ptr %l35, !tbaa !24
  %t999 = sub i64 %t995, %t996
  %t1000 = load i64, ptr %l37, !tbaa !24
  %t1003 = add i64 %t999, %t1000
  %t1005 = sub i64 %t1003, 1
  %t1006 = load i64, ptr %l37, !tbaa !24
  %t1009 = sdiv i64 %t1005, %t1006
  store i64 %t1009, ptr %l434, !tbaa !24
  br label %bb194
bb193:
  store i64 0, ptr %l434, !tbaa !24
  br label %bb194
bb194:
  %t1011 = load i64, ptr %l434, !tbaa !24
  store i64 %t1011, ptr %l431, !tbaa !24
  br label %bb195
bb195:
  %t1012 = load i64, ptr %l431, !tbaa !24
  store i64 %t1012, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb196
bb196:
  store %olang.scope zeroinitializer, ptr %s28
  %t1013 = load i64, ptr %l39, !tbaa !24
  %t1014 = load i64, ptr %l38, !tbaa !24
  %t1017 = icmp slt i64 %t1013, %t1014
  %t1019 = xor i1 %t1017, true
  br i1 %t1019, label %bb197, label %bb198
bb197:
  call void @__olang_scope_close(ptr %s28)
  br label %bb216
bb198:
  br label %bb199
bb199:
  %t1021 = load i64, ptr %l35, !tbaa !24
  %t1022 = load i64, ptr %l39, !tbaa !24
  %t1023 = load i64, ptr %l37, !tbaa !24
  %t1026 = mul i64 %t1022, %t1023
  %t1029 = add i64 %t1021, %t1026
  store i64 %t1029, ptr %l40, !tbaa !24
  %t1031 = load ptr, ptr %l0, !tbaa !29
  %t1033 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1031)
  store i64 %t1033, ptr %l453
  br label %bb200
bb200:
  %t1034 = load i64, ptr %l453, !tbaa !24
  store i64 %t1034, ptr %l41, !tbaa !24
  %t1035 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1037 = extractvalue { i64, ptr } %t1035, 0
  %t1039 = icmp sgt i64 %t1037, 0
  br i1 %t1039, label %bb201, label %bb202
bb201:
  %t1041 = load i64, ptr %l40, !tbaa !24
  %t1042 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1044 = extractvalue { i64, ptr } %t1042, 0
  %t1047 = icmp slt i64 %t1041, %t1044
  store i1 %t1047, ptr %l457, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb203
bb203:
  %t1049 = load i1, ptr %l457, !tbaa !21
  br i1 %t1049, label %bb204, label %bb205
bb204:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1051 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1051, ptr %l464, !tbaa !27
  %t1052 = load i64, ptr %l40, !tbaa !24
  %t1054 = getelementptr { i64, ptr }, ptr %l464, i32 0, i32 1
  %t1055 = load ptr, ptr %t1054, !tbaa !27
  %t1056 = getelementptr i32, ptr %t1055, i64 %t1052
  %t1057 = load i32, ptr %t1056, !tbaa !33
  %t1060 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t1050, i32 %t1057)
  store { i64, ptr } %t1060, ptr %l467
  br label %bb206
bb205:
  %t1061 = load i64, ptr %l40, !tbaa !24
  %t1063 = call i64 @__olang_fmt_i64(ptr null, i64 %t1061)
  %t1064 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1063)
  %t1065 = call i64 @__olang_fmt_i64(ptr %t1064, i64 %t1061)
  %t1066 = insertvalue { i64, ptr } undef, i64 %t1063, 0
  %t1067 = insertvalue { i64, ptr } %t1066, ptr %t1064, 1
  %t1069 = extractvalue { i64, ptr } %t1067, 0
  %t1070 = extractvalue { i64, ptr } %t1067, 1
  %t1071 = mul i64 %t1069, 1
  %t1072 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1071)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1072, ptr %t1070, i64 %t1071, i1 false)
  %t1073 = insertvalue { i64, ptr } undef, i64 %t1069, 0
  %t1074 = insertvalue { i64, ptr } %t1073, ptr %t1072, 1
  store { i64, ptr } %t1074, ptr %l462, !tbaa !27
  br label %bb207
bb206:
  %t1076 = load { i64, ptr }, ptr %l467, !tbaa !27
  store { i64, ptr } %t1076, ptr %l462, !tbaa !27
  br label %bb207
bb207:
  %t1077 = load { i64, ptr }, ptr %l462, !tbaa !27
  %t1078 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1078, ptr %l471, !tbaa !29
  %t1079 = load i64, ptr %l41, !tbaa !24
  store i64 %t1079, ptr %l472, !tbaa !24
  %t1082 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %s28, { i64, ptr } %t1077)
  store { i64, ptr } %t1082, ptr %l474
  br label %bb208
bb208:
  %t1083 = load i64, ptr %l40, !tbaa !24
  %t1084 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1085 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1086 = load { i64, ptr }, ptr %l474, !tbaa !27
  %t1087 = extractvalue { i64, ptr } %t1086, 1
  %t1088 = extractvalue { i64, ptr } %t1086, 0
  %t1089 = add i64 %t1085, %t1088
  %t1090 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1091 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1092 = add i64 %t1089, %t1091
  %t1094 = call i64 @__olang_fmt_i64(ptr null, i64 %t1083)
  %t1095 = add i64 %t1092, %t1094
  %t1096 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1097 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1098 = add i64 %t1095, %t1097
  %t1099 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1098)
  call void @olang_textcopy(ptr %t1099, ptr %t1084, i64 %t1085)
  %t1100 = getelementptr i8, ptr %t1099, i64 %t1085
  call void @olang_textcopy(ptr %t1100, ptr %t1087, i64 %t1088)
  %t1101 = getelementptr i8, ptr %t1100, i64 %t1088
  call void @olang_textcopy(ptr %t1101, ptr %t1090, i64 %t1091)
  %t1102 = getelementptr i8, ptr %t1101, i64 %t1091
  %t1103 = call i64 @__olang_fmt_i64(ptr %t1102, i64 %t1083)
  %t1104 = getelementptr i8, ptr %t1102, i64 %t1094
  call void @olang_textcopy(ptr %t1104, ptr %t1096, i64 %t1097)
  %t1105 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1106 = insertvalue { i64, ptr } %t1105, ptr %t1099, 1
  %t1108 = extractvalue { i64, ptr } %t1106, 0
  %t1109 = extractvalue { i64, ptr } %t1106, 1
  %t1110 = mul i64 %t1108, 1
  %t1111 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1111, ptr %t1109, i64 %t1110, i1 false)
  %t1112 = insertvalue { i64, ptr } undef, i64 %t1108, 0
  %t1113 = insertvalue { i64, ptr } %t1112, ptr %t1111, 1
  %t1114 = load ptr, ptr %l471, !tbaa !29
  %t1115 = load i64, ptr %l472, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s28, ptr %t1114, i64 %t1115, { i64, ptr } %t1113)
  br label %bb209
bb209:
  %t1117 = load i64, ptr %l40, !tbaa !24
  %t1119 = icmp sgt i64 %t1117, 0
  br i1 %t1119, label %bb210, label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s31
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s31, ptr %l34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb212
bb211:
  br label %bb213
bb212:
  call void @__olang_scope_close(ptr %s31)
  br label %bb213
bb213:
  %t1122 = load i64, ptr %l41, !tbaa !24
  %t1123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t1126 = call i64 @__olang_fmt_i64(ptr null, i64 %t1122)
  %t1127 = add i64 %t1124, %t1126
  %t1128 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1127)
  call void @olang_textcopy(ptr %t1128, ptr %t1123, i64 %t1124)
  %t1129 = getelementptr i8, ptr %t1128, i64 %t1124
  %t1130 = call i64 @__olang_fmt_i64(ptr %t1129, i64 %t1122)
  %t1131 = insertvalue { i64, ptr } undef, i64 %t1127, 0
  %t1132 = insertvalue { i64, ptr } %t1131, ptr %t1128, 1
  %t1134 = extractvalue { i64, ptr } %t1132, 0
  %t1135 = extractvalue { i64, ptr } %t1132, 1
  %t1136 = mul i64 %t1134, 1
  %t1137 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1137, ptr %t1135, i64 %t1136, i1 false)
  %t1138 = insertvalue { i64, ptr } undef, i64 %t1134, 0
  %t1139 = insertvalue { i64, ptr } %t1138, ptr %t1137, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s28, ptr %l34, { i64, ptr } %t1139)
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s28)
  br label %bb215
bb215:
  %t1142 = load i64, ptr %l39, !tbaa !24
  %t1144 = add i64 %t1142, 1
  store i64 %t1144, ptr %l39, !tbaa !24
  br label %bb196
bb216:
  %t1146 = load ptr, ptr %l0, !tbaa !29
  %t1148 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1146)
  store i64 %t1148, ptr %l488
  br label %bb217
bb217:
  %t1149 = load i64, ptr %l488, !tbaa !24
  store i64 %t1149, ptr %l43, !tbaa !24
  %t1150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1150, ptr %l489, !tbaa !29
  %t1151 = load i64, ptr %l43, !tbaa !24
  store i64 %t1151, ptr %l490, !tbaa !24
  %t1153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s26, ptr %s26, ptr %l34)
  store { i64, ptr } %t1153, ptr %l492
  br label %bb218
bb218:
  %t1154 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t1155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t1156 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t1157 = extractvalue { i64, ptr } %t1156, 1
  %t1158 = extractvalue { i64, ptr } %t1156, 0
  %t1159 = add i64 %t1155, %t1158
  %t1160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t1162 = add i64 %t1159, %t1161
  %t1163 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1162)
  call void @olang_textcopy(ptr %t1163, ptr %t1154, i64 %t1155)
  %t1164 = getelementptr i8, ptr %t1163, i64 %t1155
  call void @olang_textcopy(ptr %t1164, ptr %t1157, i64 %t1158)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1158
  call void @olang_textcopy(ptr %t1165, ptr %t1160, i64 %t1161)
  %t1166 = insertvalue { i64, ptr } undef, i64 %t1162, 0
  %t1167 = insertvalue { i64, ptr } %t1166, ptr %t1163, 1
  %t1169 = extractvalue { i64, ptr } %t1167, 0
  %t1170 = extractvalue { i64, ptr } %t1167, 1
  %t1171 = mul i64 %t1169, 1
  %t1172 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1172, ptr %t1170, i64 %t1171, i1 false)
  %t1173 = insertvalue { i64, ptr } undef, i64 %t1169, 0
  %t1174 = insertvalue { i64, ptr } %t1173, ptr %t1172, 1
  %t1175 = load ptr, ptr %l489, !tbaa !29
  %t1176 = load i64, ptr %l490, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1175, i64 %t1176, { i64, ptr } %t1174)
  br label %bb219
bb219:
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1179 = load i32, ptr %l3, !tbaa !23
  %t1182 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t1178, i32 %t1179)
  store i1 %t1182, ptr %l497
  br label %bb220
bb220:
  %t1183 = load i1, ptr %l497, !tbaa !21
  store i1 %t1183, ptr %l44, !tbaa !21
  %t1184 = load i1, ptr %l44, !tbaa !21
  %t1186 = xor i1 %t1184, true
  br i1 %t1186, label %bb221, label %bb222
bb221:
  %t1188 = load i64, ptr %l31, !tbaa !24
  store i64 %t1188, ptr %l500, !tbaa !24
  br label %bb224
bb222:
  %t1190 = load ptr, ptr %l0, !tbaa !29
  %t1192 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1190)
  store i64 %t1192, ptr %l503
  br label %bb223
bb223:
  %t1193 = load i64, ptr %l503, !tbaa !24
  store i64 %t1193, ptr %l500, !tbaa !24
  br label %bb224
bb224:
  %t1194 = load i64, ptr %l500, !tbaa !24
  store i64 %t1194, ptr %l45, !tbaa !24
  %t1195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1195, ptr %l504, !tbaa !29
  %t1196 = load i1, ptr %l44, !tbaa !21
  br i1 %t1196, label %bb225, label %bb226
bb225:
  %t1198 = load ptr, ptr %l2, !tbaa !29
  %t1200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1198, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i32 %t1200, ptr %l508
  br label %bb227
bb226:
  %t1201 = load ptr, ptr %l2, !tbaa !29
  %t1203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1201, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i32 %t1203, ptr %l510
  br label %bb228
bb227:
  %t1204 = load i32, ptr %l508, !tbaa !23
  store i32 %t1204, ptr %l506, !tbaa !23
  br label %bb229
bb228:
  %t1205 = load i32, ptr %l510, !tbaa !23
  store i32 %t1205, ptr %l506, !tbaa !23
  br label %bb229
bb229:
  %t1206 = load ptr, ptr %l504, !tbaa !29
  %t1207 = load i32, ptr %l506, !tbaa !23
  %t1208 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1206, i32 %t1207)
  store i64 %t1208, ptr %l511
  br label %bb230
bb230:
  %t1209 = load i64, ptr %l511, !tbaa !24
  store i64 %t1209, ptr %l46, !tbaa !24
  %t1210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1210, ptr %l512, !tbaa !29
  %t1211 = load i64, ptr %l45, !tbaa !24
  store i64 %t1211, ptr %l513, !tbaa !24
  %t1212 = load ptr, ptr %l0, !tbaa !29
  %t1213 = load i32, ptr %l3, !tbaa !23
  %t1216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1212, i32 %t1213)
  store { i64, ptr } %t1216, ptr %l516
  br label %bb231
bb231:
  %t1217 = load { i64, ptr }, ptr %l516, !tbaa !27
  %t1218 = extractvalue { i64, ptr } %t1217, 0
  %t1219 = extractvalue { i64, ptr } %t1217, 1
  %t1220 = mul i64 %t1218, 1
  %t1221 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1221, ptr %t1219, i64 %t1220, i1 false)
  %t1222 = insertvalue { i64, ptr } undef, i64 %t1218, 0
  %t1223 = insertvalue { i64, ptr } %t1222, ptr %t1221, 1
  %t1225 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1223)
  store { i64, ptr } %t1225, ptr %l518
  br label %bb232
bb232:
  %t1226 = load i1, ptr %l44, !tbaa !21
  br i1 %t1226, label %bb233, label %bb234
bb233:
  store i64 64, ptr %l520, !tbaa !24
  br label %bb235
bb234:
  store i64 32, ptr %l520, !tbaa !24
  br label %bb235
bb235:
  %t1228 = load i64, ptr %l46, !tbaa !24
  %t1229 = load i64, ptr %l43, !tbaa !24
  %t1230 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t1231 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t1232 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1233 = extractvalue { i64, ptr } %t1232, 1
  %t1234 = extractvalue { i64, ptr } %t1232, 0
  %t1235 = add i64 %t1231, %t1234
  %t1236 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t1237 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t1238 = add i64 %t1235, %t1237
  %t1239 = load i64, ptr %l520, !tbaa !24
  %t1240 = call i64 @__olang_fmt_i64(ptr null, i64 %t1239)
  %t1241 = add i64 %t1238, %t1240
  %t1242 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t1243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t1244 = add i64 %t1241, %t1243
  %t1246 = call i64 @__olang_fmt_i64(ptr null, i64 %t1228)
  %t1247 = add i64 %t1244, %t1246
  %t1248 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t1249 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t1250 = add i64 %t1247, %t1249
  %t1252 = call i64 @__olang_fmt_i64(ptr null, i64 %t1229)
  %t1253 = add i64 %t1250, %t1252
  %t1254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t1255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t1256 = add i64 %t1253, %t1255
  %t1257 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1256)
  call void @olang_textcopy(ptr %t1257, ptr %t1230, i64 %t1231)
  %t1258 = getelementptr i8, ptr %t1257, i64 %t1231
  call void @olang_textcopy(ptr %t1258, ptr %t1233, i64 %t1234)
  %t1259 = getelementptr i8, ptr %t1258, i64 %t1234
  call void @olang_textcopy(ptr %t1259, ptr %t1236, i64 %t1237)
  %t1260 = getelementptr i8, ptr %t1259, i64 %t1237
  %t1261 = call i64 @__olang_fmt_i64(ptr %t1260, i64 %t1239)
  %t1262 = getelementptr i8, ptr %t1260, i64 %t1240
  call void @olang_textcopy(ptr %t1262, ptr %t1242, i64 %t1243)
  %t1263 = getelementptr i8, ptr %t1262, i64 %t1243
  %t1264 = call i64 @__olang_fmt_i64(ptr %t1263, i64 %t1228)
  %t1265 = getelementptr i8, ptr %t1263, i64 %t1246
  call void @olang_textcopy(ptr %t1265, ptr %t1248, i64 %t1249)
  %t1266 = getelementptr i8, ptr %t1265, i64 %t1249
  %t1267 = call i64 @__olang_fmt_i64(ptr %t1266, i64 %t1229)
  %t1268 = getelementptr i8, ptr %t1266, i64 %t1252
  call void @olang_textcopy(ptr %t1268, ptr %t1254, i64 %t1255)
  %t1269 = insertvalue { i64, ptr } undef, i64 %t1256, 0
  %t1270 = insertvalue { i64, ptr } %t1269, ptr %t1257, 1
  %t1272 = extractvalue { i64, ptr } %t1270, 0
  %t1273 = extractvalue { i64, ptr } %t1270, 1
  %t1274 = mul i64 %t1272, 1
  %t1275 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1275, ptr %t1273, i64 %t1274, i1 false)
  %t1276 = insertvalue { i64, ptr } undef, i64 %t1272, 0
  %t1277 = insertvalue { i64, ptr } %t1276, ptr %t1275, 1
  %t1278 = load ptr, ptr %l512, !tbaa !29
  %t1279 = load i64, ptr %l513, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1278, i64 %t1279, { i64, ptr } %t1277)
  br label %bb236
bb236:
  %t1281 = load i1, ptr %l44, !tbaa !21
  %t1283 = xor i1 %t1281, true
  br i1 %t1283, label %bb237, label %bb238
bb237:
  %t1285 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1285, ptr %rv
  br label %ret
bb238:
  br label %bb239
bb239:
  %t1287 = load ptr, ptr %l2, !tbaa !29
  %t1288 = load i32, ptr %l3, !tbaa !23
  %t1291 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1287, i32 %t1288)
  store i64 %t1291, ptr %l530
  br label %bb240
bb240:
  %t1292 = load i64, ptr %l530, !tbaa !24
  %t1293 = sdiv i64 %t1292, 8
  store i64 %t1293, ptr %l47, !tbaa !24
  %t1295 = load ptr, ptr %l0, !tbaa !29
  %t1297 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1295)
  store i64 %t1297, ptr %l533
  br label %bb241
bb241:
  %t1298 = load i64, ptr %l533, !tbaa !24
  store i64 %t1298, ptr %l48, !tbaa !24
  %t1299 = load ptr, ptr %l0, !tbaa !29
  %t1301 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1299)
  store i64 %t1301, ptr %l535
  br label %bb242
bb242:
  %t1302 = load i64, ptr %l535, !tbaa !24
  store i64 %t1302, ptr %l49, !tbaa !24
  %t1303 = load ptr, ptr %l0, !tbaa !29
  %t1304 = load i64, ptr %l49, !tbaa !24
  %t1305 = load i64, ptr %l47, !tbaa !24
  %t1306 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t1307 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t1309 = call i64 @__olang_fmt_i64(ptr null, i64 %t1305)
  %t1310 = add i64 %t1307, %t1309
  %t1311 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t1312 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t1313 = add i64 %t1310, %t1312
  %t1314 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1313)
  call void @olang_textcopy(ptr %t1314, ptr %t1306, i64 %t1307)
  %t1315 = getelementptr i8, ptr %t1314, i64 %t1307
  %t1316 = call i64 @__olang_fmt_i64(ptr %t1315, i64 %t1305)
  %t1317 = getelementptr i8, ptr %t1315, i64 %t1309
  call void @olang_textcopy(ptr %t1317, ptr %t1311, i64 %t1312)
  %t1318 = insertvalue { i64, ptr } undef, i64 %t1313, 0
  %t1319 = insertvalue { i64, ptr } %t1318, ptr %t1314, 1
  %t1321 = extractvalue { i64, ptr } %t1319, 0
  %t1322 = extractvalue { i64, ptr } %t1319, 1
  %t1323 = mul i64 %t1321, 1
  %t1324 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1324, ptr %t1322, i64 %t1323, i1 false)
  %t1325 = insertvalue { i64, ptr } undef, i64 %t1321, 0
  %t1326 = insertvalue { i64, ptr } %t1325, ptr %t1324, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1303, i64 %t1304, { i64, ptr } %t1326)
  br label %bb243
bb243:
  %t1330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1330, ptr %l541, !tbaa !29
  %t1331 = load i64, ptr %l48, !tbaa !24
  store i64 %t1331, ptr %l542, !tbaa !24
  %t1332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1332, ptr %l543, !tbaa !29
  %t1333 = load ptr, ptr %l2, !tbaa !29
  %t1335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1333, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i32 %t1335, ptr %l545
  br label %bb244
bb244:
  %t1336 = load ptr, ptr %l543, !tbaa !29
  %t1337 = load i32, ptr %l545, !tbaa !23
  %t1338 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1336, i32 %t1337)
  store i64 %t1338, ptr %l546
  br label %bb245
bb245:
  %t1339 = load i64, ptr %l47, !tbaa !24
  %t1341 = mul i64 %t1339, 64
  %t1342 = load i64, ptr %l49, !tbaa !24
  %t1343 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t1344 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t1345 = load i64, ptr %l546, !tbaa !24
  %t1346 = call i64 @__olang_fmt_i64(ptr null, i64 %t1345)
  %t1347 = add i64 %t1344, %t1346
  %t1348 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t1349 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t1350 = add i64 %t1347, %t1349
  %t1352 = call i64 @__olang_fmt_i64(ptr null, i64 %t1341)
  %t1353 = add i64 %t1350, %t1352
  %t1354 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t1355 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t1356 = add i64 %t1353, %t1355
  %t1358 = call i64 @__olang_fmt_i64(ptr null, i64 %t1342)
  %t1359 = add i64 %t1356, %t1358
  %t1360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t1361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t1362 = add i64 %t1359, %t1361
  %t1363 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1362)
  call void @olang_textcopy(ptr %t1363, ptr %t1343, i64 %t1344)
  %t1364 = getelementptr i8, ptr %t1363, i64 %t1344
  %t1365 = call i64 @__olang_fmt_i64(ptr %t1364, i64 %t1345)
  %t1366 = getelementptr i8, ptr %t1364, i64 %t1346
  call void @olang_textcopy(ptr %t1366, ptr %t1348, i64 %t1349)
  %t1367 = getelementptr i8, ptr %t1366, i64 %t1349
  %t1368 = call i64 @__olang_fmt_i64(ptr %t1367, i64 %t1341)
  %t1369 = getelementptr i8, ptr %t1367, i64 %t1352
  call void @olang_textcopy(ptr %t1369, ptr %t1354, i64 %t1355)
  %t1370 = getelementptr i8, ptr %t1369, i64 %t1355
  %t1371 = call i64 @__olang_fmt_i64(ptr %t1370, i64 %t1342)
  %t1372 = getelementptr i8, ptr %t1370, i64 %t1358
  call void @olang_textcopy(ptr %t1372, ptr %t1360, i64 %t1361)
  %t1373 = insertvalue { i64, ptr } undef, i64 %t1362, 0
  %t1374 = insertvalue { i64, ptr } %t1373, ptr %t1363, 1
  %t1376 = extractvalue { i64, ptr } %t1374, 0
  %t1377 = extractvalue { i64, ptr } %t1374, 1
  %t1378 = mul i64 %t1376, 1
  %t1379 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1379, ptr %t1377, i64 %t1378, i1 false)
  %t1380 = insertvalue { i64, ptr } undef, i64 %t1376, 0
  %t1381 = insertvalue { i64, ptr } %t1380, ptr %t1379, 1
  %t1382 = load ptr, ptr %l541, !tbaa !29
  %t1383 = load i64, ptr %l542, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1382, i64 %t1383, { i64, ptr } %t1381)
  br label %bb246
bb246:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  %t1387 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1385)
  store i64 %t1387, ptr %l553
  br label %bb247
bb247:
  %t1388 = load i64, ptr %l553, !tbaa !24
  store i64 %t1388, ptr %l50, !tbaa !24
  %t1389 = load ptr, ptr %l0, !tbaa !29
  %t1391 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1389)
  store i64 %t1391, ptr %l555
  br label %bb248
bb248:
  %t1392 = load i64, ptr %l555, !tbaa !24
  store i64 %t1392, ptr %l51, !tbaa !24
  %t1393 = load ptr, ptr %l0, !tbaa !29
  %t1395 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1393)
  store i64 %t1395, ptr %l557
  br label %bb249
bb249:
  %t1396 = load i64, ptr %l557, !tbaa !24
  store i64 %t1396, ptr %l52, !tbaa !24
  %t1397 = load ptr, ptr %l0, !tbaa !29
  %t1398 = load i64, ptr %l50, !tbaa !24
  %t1399 = load i64, ptr %l45, !tbaa !24
  %t1400 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t1401 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t1403 = call i64 @__olang_fmt_i64(ptr null, i64 %t1399)
  %t1404 = add i64 %t1401, %t1403
  %t1405 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t1406 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t1407 = add i64 %t1404, %t1406
  %t1408 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1407)
  call void @olang_textcopy(ptr %t1408, ptr %t1400, i64 %t1401)
  %t1409 = getelementptr i8, ptr %t1408, i64 %t1401
  %t1410 = call i64 @__olang_fmt_i64(ptr %t1409, i64 %t1399)
  %t1411 = getelementptr i8, ptr %t1409, i64 %t1403
  call void @olang_textcopy(ptr %t1411, ptr %t1405, i64 %t1406)
  %t1412 = insertvalue { i64, ptr } undef, i64 %t1407, 0
  %t1413 = insertvalue { i64, ptr } %t1412, ptr %t1408, 1
  %t1415 = extractvalue { i64, ptr } %t1413, 0
  %t1416 = extractvalue { i64, ptr } %t1413, 1
  %t1417 = mul i64 %t1415, 1
  %t1418 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1417)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1418, ptr %t1416, i64 %t1417, i1 false)
  %t1419 = insertvalue { i64, ptr } undef, i64 %t1415, 0
  %t1420 = insertvalue { i64, ptr } %t1419, ptr %t1418, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1397, i64 %t1398, { i64, ptr } %t1420)
  br label %bb250
bb250:
  %t1424 = load ptr, ptr %l0, !tbaa !29
  %t1425 = load i64, ptr %l51, !tbaa !24
  %t1426 = load i64, ptr %l48, !tbaa !24
  %t1427 = load i64, ptr %l47, !tbaa !24
  %t1429 = mul i64 %t1427, 64
  %t1430 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t1431 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t1433 = call i64 @__olang_fmt_i64(ptr null, i64 %t1426)
  %t1434 = add i64 %t1431, %t1433
  %t1435 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t1436 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t1437 = add i64 %t1434, %t1436
  %t1439 = call i64 @__olang_fmt_i64(ptr null, i64 %t1429)
  %t1440 = add i64 %t1437, %t1439
  %t1441 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t1442 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t1443 = add i64 %t1440, %t1442
  %t1444 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1443)
  call void @olang_textcopy(ptr %t1444, ptr %t1430, i64 %t1431)
  %t1445 = getelementptr i8, ptr %t1444, i64 %t1431
  %t1446 = call i64 @__olang_fmt_i64(ptr %t1445, i64 %t1426)
  %t1447 = getelementptr i8, ptr %t1445, i64 %t1433
  call void @olang_textcopy(ptr %t1447, ptr %t1435, i64 %t1436)
  %t1448 = getelementptr i8, ptr %t1447, i64 %t1436
  %t1449 = call i64 @__olang_fmt_i64(ptr %t1448, i64 %t1429)
  %t1450 = getelementptr i8, ptr %t1448, i64 %t1439
  call void @olang_textcopy(ptr %t1450, ptr %t1441, i64 %t1442)
  %t1451 = insertvalue { i64, ptr } undef, i64 %t1443, 0
  %t1452 = insertvalue { i64, ptr } %t1451, ptr %t1444, 1
  %t1454 = extractvalue { i64, ptr } %t1452, 0
  %t1455 = extractvalue { i64, ptr } %t1452, 1
  %t1456 = mul i64 %t1454, 1
  %t1457 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1457, ptr %t1455, i64 %t1456, i1 false)
  %t1458 = insertvalue { i64, ptr } undef, i64 %t1454, 0
  %t1459 = insertvalue { i64, ptr } %t1458, ptr %t1457, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1424, i64 %t1425, { i64, ptr } %t1459)
  br label %bb251
bb251:
  %t1463 = load ptr, ptr %l0, !tbaa !29
  %t1464 = load i64, ptr %l52, !tbaa !24
  %t1465 = load i64, ptr %l50, !tbaa !24
  %t1466 = load i64, ptr %l51, !tbaa !24
  %t1467 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t1468 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t1470 = call i64 @__olang_fmt_i64(ptr null, i64 %t1465)
  %t1471 = add i64 %t1468, %t1470
  %t1472 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t1473 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t1474 = add i64 %t1471, %t1473
  %t1476 = call i64 @__olang_fmt_i64(ptr null, i64 %t1466)
  %t1477 = add i64 %t1474, %t1476
  %t1478 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t1479 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t1480 = add i64 %t1477, %t1479
  %t1481 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1480)
  call void @olang_textcopy(ptr %t1481, ptr %t1467, i64 %t1468)
  %t1482 = getelementptr i8, ptr %t1481, i64 %t1468
  %t1483 = call i64 @__olang_fmt_i64(ptr %t1482, i64 %t1465)
  %t1484 = getelementptr i8, ptr %t1482, i64 %t1470
  call void @olang_textcopy(ptr %t1484, ptr %t1472, i64 %t1473)
  %t1485 = getelementptr i8, ptr %t1484, i64 %t1473
  %t1486 = call i64 @__olang_fmt_i64(ptr %t1485, i64 %t1466)
  %t1487 = getelementptr i8, ptr %t1485, i64 %t1476
  call void @olang_textcopy(ptr %t1487, ptr %t1478, i64 %t1479)
  %t1488 = insertvalue { i64, ptr } undef, i64 %t1480, 0
  %t1489 = insertvalue { i64, ptr } %t1488, ptr %t1481, 1
  %t1491 = extractvalue { i64, ptr } %t1489, 0
  %t1492 = extractvalue { i64, ptr } %t1489, 1
  %t1493 = mul i64 %t1491, 1
  %t1494 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1493)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1494, ptr %t1492, i64 %t1493, i1 false)
  %t1495 = insertvalue { i64, ptr } undef, i64 %t1491, 0
  %t1496 = insertvalue { i64, ptr } %t1495, ptr %t1494, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1463, i64 %t1464, { i64, ptr } %t1496)
  br label %bb252
bb252:
  %t1500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1500, ptr %l576, !tbaa !29
  %t1501 = load i64, ptr %l31, !tbaa !24
  store i64 %t1501, ptr %l577, !tbaa !24
  %t1502 = load ptr, ptr %l0, !tbaa !29
  %t1503 = load i32, ptr %l3, !tbaa !23
  %t1506 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1502, i32 %t1503)
  store { i64, ptr } %t1506, ptr %l580
  br label %bb253
bb253:
  %t1507 = load { i64, ptr }, ptr %l580, !tbaa !27
  %t1508 = extractvalue { i64, ptr } %t1507, 0
  %t1509 = extractvalue { i64, ptr } %t1507, 1
  %t1510 = mul i64 %t1508, 1
  %t1511 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1511, ptr %t1509, i64 %t1510, i1 false)
  %t1512 = insertvalue { i64, ptr } undef, i64 %t1508, 0
  %t1513 = insertvalue { i64, ptr } %t1512, ptr %t1511, 1
  %t1515 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1513)
  store { i64, ptr } %t1515, ptr %l582
  br label %bb254
bb254:
  %t1516 = load i64, ptr %l11, !tbaa !24
  %t1517 = load i64, ptr %l52, !tbaa !24
  %t1518 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t1519 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t1520 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t1521 = extractvalue { i64, ptr } %t1520, 1
  %t1522 = extractvalue { i64, ptr } %t1520, 0
  %t1523 = add i64 %t1519, %t1522
  %t1524 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t1525 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t1526 = add i64 %t1523, %t1525
  %t1528 = call i64 @__olang_fmt_i64(ptr null, i64 %t1516)
  %t1529 = add i64 %t1526, %t1528
  %t1530 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t1531 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t1532 = add i64 %t1529, %t1531
  %t1534 = call i64 @__olang_fmt_i64(ptr null, i64 %t1517)
  %t1535 = add i64 %t1532, %t1534
  %t1536 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t1537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t1538 = add i64 %t1535, %t1537
  %t1539 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1538)
  call void @olang_textcopy(ptr %t1539, ptr %t1518, i64 %t1519)
  %t1540 = getelementptr i8, ptr %t1539, i64 %t1519
  call void @olang_textcopy(ptr %t1540, ptr %t1521, i64 %t1522)
  %t1541 = getelementptr i8, ptr %t1540, i64 %t1522
  call void @olang_textcopy(ptr %t1541, ptr %t1524, i64 %t1525)
  %t1542 = getelementptr i8, ptr %t1541, i64 %t1525
  %t1543 = call i64 @__olang_fmt_i64(ptr %t1542, i64 %t1516)
  %t1544 = getelementptr i8, ptr %t1542, i64 %t1528
  call void @olang_textcopy(ptr %t1544, ptr %t1530, i64 %t1531)
  %t1545 = getelementptr i8, ptr %t1544, i64 %t1531
  %t1546 = call i64 @__olang_fmt_i64(ptr %t1545, i64 %t1517)
  %t1547 = getelementptr i8, ptr %t1545, i64 %t1534
  call void @olang_textcopy(ptr %t1547, ptr %t1536, i64 %t1537)
  %t1548 = insertvalue { i64, ptr } undef, i64 %t1538, 0
  %t1549 = insertvalue { i64, ptr } %t1548, ptr %t1539, 1
  %t1551 = extractvalue { i64, ptr } %t1549, 0
  %t1552 = extractvalue { i64, ptr } %t1549, 1
  %t1553 = mul i64 %t1551, 1
  %t1554 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1554, ptr %t1552, i64 %t1553, i1 false)
  %t1555 = insertvalue { i64, ptr } undef, i64 %t1551, 0
  %t1556 = insertvalue { i64, ptr } %t1555, ptr %t1554, 1
  %t1557 = load ptr, ptr %l576, !tbaa !29
  %t1558 = load i64, ptr %l577, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1557, i64 %t1558, { i64, ptr } %t1556)
  br label %bb255
bb255:
  %t1560 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1560, ptr %rv
  br label %ret
bb256:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t6 = extractvalue { i64, ptr } %a2, 1
  %t7 = extractvalue { i64, ptr } %a2, 0
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = extractvalue { i64, ptr } %t14, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %a1, i64 %t3, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/eval:Image"
  %l45 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l74 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i32
  %l78 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i32
  %l84 = alloca i1
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l109 = alloca %"compiler/eval:Blob"
  %l111 = alloca %"compiler/eval:Blob"
  %l113 = alloca i64
  %l115 = alloca i1
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l129 = alloca { i64, ptr }
  %l131 = alloca i64
  %l142 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t292 = alloca %"compiler/eval:Blob", align 8
  %t294 = alloca %"compiler/eval:Blob", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %s0, ptr %t1, i64 %t2, i32 %t3)
  store { i64, ptr } %t7, ptr %l17
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l20
  br label %bb2
bb2:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i64 %t33, ptr %l26
  br label %bb6
bb6:
  %t34 = load i64, ptr %l26, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 45
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l33
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i1, ptr %l33, !tbaa !21
  store i1 %t46, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l29, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 45
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H95f86c29c688efeac83a664cabcff622(ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, ptr } %t54, 1
  %t56 = extractvalue { i32, ptr } %t54, 0
  store i32 %t56, ptr %l39
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb14, label %ok.58, !prof !99
ok.58:
  store ptr %t55, ptr %l38
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s14
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s14, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l142
  br label %bb74
bb13:
  %t64 = load ptr, ptr %l38, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t65 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
  store %"compiler/eval:Image" %t65, ptr %l40
  br label %bb16
bb16:
  %t66 = load %"compiler/eval:Image", ptr %l40
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/eval:Image" %t66, ptr %t67
  store ptr %t67, ptr %l34, !tbaa !29
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l34, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %s0, ptr %v0, ptr %s3, ptr %t70, { i64, ptr } %t71, ptr %t72)
  store { i64, ptr } %t76, ptr %l45
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t77, ptr %l7, !tbaa !27
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr %"compiler/eval:Image", ptr %t78, i32 0, i32 2
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load i32, ptr %l3, !tbaa !23
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t87 = icmp ne i32 %t83, %t84
  br i1 %t87, label %bb21, label %bb22
bb20:
  br label %bb30
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s4, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l54
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l51, !tbaa !27
  br label %bb24
bb23:
  %t94 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  br label %bb24
bb24:
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t105, ptr %l57
  br label %bb25
bb25:
  %t106 = load i1, ptr %l57, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb26, label %bb27
bb26:
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t114 = extractvalue { i64, ptr } %t109, 1
  %t115 = extractvalue { i64, ptr } %t109, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t121 = extractvalue { i64, ptr } %t110, 1
  %t122 = extractvalue { i64, ptr } %t110, 0
  %t123 = add i64 %t119, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t111, i64 %t112)
  %t125 = getelementptr i8, ptr %t124, i64 %t112
  call void @olang_textcopy(ptr %t125, ptr %t114, i64 %t115)
  %t126 = getelementptr i8, ptr %t125, i64 %t115
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t121, i64 %t122)
  %t128 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t124, 1
  store { i64, ptr } %t129, ptr %l59, !tbaa !27
  br label %bb28
bb27:
  %t131 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t135 = extractvalue { i64, ptr } %t131, 1
  %t136 = extractvalue { i64, ptr } %t131, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  call void @olang_textcopy(ptr %t143, ptr %t138, i64 %t139)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  store { i64, ptr } %t145, ptr %l59, !tbaa !27
  br label %bb28
bb28:
  %t147 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t150 = load i64, ptr %l1, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t147, 1
  %t155 = extractvalue { i64, ptr } %t147, 0
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t154, i64 %t155)
  %t160 = getelementptr i8, ptr %t159, i64 %t155
  call void @olang_textcopy(ptr %t160, ptr %t156, i64 %t157)
  %t161 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } %t162, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s3, ptr %s4, ptr %t148, { i64, ptr } %t149, i64 %t150, { i64, ptr } %t151, { i64, ptr } %t169)
  br label %bb29
bb29:
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t179 = extractvalue { i64, ptr } %t175, 1
  %t180 = extractvalue { i64, ptr } %t175, 0
  %t181 = add i64 %t177, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = getelementptr i8, ptr %t182, i64 %t177
  call void @olang_textcopy(ptr %t183, ptr %t179, i64 %t180)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t185, ptr %rv
  br label %ret
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t189 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t187, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d138, i32 0, i32 1) })
  %t190 = extractvalue { i32, i64 } %t189, 1
  %t191 = extractvalue { i32, i64 } %t189, 0
  store i32 %t191, ptr %l77
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb32, label %ok.193, !prof !99
ok.193:
  store i64 %t190, ptr %l76
  br label %bb31
bb31:
  %t194 = load i64, ptr %l76, !tbaa !24
  store i64 %t194, ptr %l74, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l74, !tbaa !24
  br label %bb34
bb34:
  %t195 = load i64, ptr %l74, !tbaa !24
  store i64 %t195, ptr %l10, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t196, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) })
  %t199 = extractvalue { i32, i64 } %t198, 1
  %t200 = extractvalue { i32, i64 } %t198, 0
  store i32 %t200, ptr %l81
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb36, label %ok.202, !prof !99
ok.202:
  store i64 %t199, ptr %l80
  br label %bb35
bb35:
  %t203 = load i64, ptr %l80, !tbaa !24
  store i64 %t203, ptr %l78, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l78, !tbaa !24
  br label %bb38
bb38:
  %t204 = load i64, ptr %l78, !tbaa !24
  store i64 %t204, ptr %l11, !tbaa !24
  %t205 = load i64, ptr %l10, !tbaa !24
  %t207 = icmp sge i64 %t205, 0
  br i1 %t207, label %bb39, label %bb40
bb39:
  %t209 = load i64, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l10, !tbaa !24
  %t213 = icmp sgt i64 %t209, %t210
  store i1 %t213, ptr %l84, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb41
bb41:
  %t215 = load i1, ptr %l84, !tbaa !21
  br i1 %t215, label %bb42, label %bb43
bb42:
  %t216 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t216, ptr %l89, !tbaa !27
  %t217 = load i64, ptr %l10, !tbaa !24
  %t219 = add i64 %t217, 12
  store i64 %t219, ptr %l91, !tbaa !24
  %t220 = load i64, ptr %l11, !tbaa !24
  %t222 = add i64 %t220, 2
  store i64 %t222, ptr %l93, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l94, !tbaa !24
  %t225 = load i64, ptr %l91, !tbaa !24
  %t226 = icmp sge i64 %t225, 0
  br i1 %t226, label %bb44, label %bb45
bb43:
  %t228 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t232 = extractvalue { i64, ptr } %t228, 1
  %t233 = extractvalue { i64, ptr } %t228, 0
  %t234 = add i64 %t230, %t233
  %t235 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t238 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t229, i64 %t230)
  %t239 = getelementptr i8, ptr %t238, i64 %t230
  call void @olang_textcopy(ptr %t239, ptr %t232, i64 %t233)
  %t240 = getelementptr i8, ptr %t239, i64 %t233
  call void @olang_textcopy(ptr %t240, ptr %t235, i64 %t236)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t238, 1
  store { i64, ptr } %t242, ptr %l88, !tbaa !27
  br label %bb50
bb44:
  %t244 = load i64, ptr %l91, !tbaa !24
  %t245 = load i64, ptr %l93, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb46:
  %t248 = load i64, ptr %l93, !tbaa !24
  %t249 = load i64, ptr %l94, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb48:
  %t252 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = load i64, ptr %l91, !tbaa !24
  %t255 = load i64, ptr %l93, !tbaa !24
  %t256 = getelementptr i8, ptr %t253, i64 %t254
  %t257 = sub i64 %t255, %t254
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t262 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = add i64 %t261, %t264
  %t266 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t270 = extractvalue { i64, ptr } %t259, 1
  %t271 = extractvalue { i64, ptr } %t259, 0
  %t272 = add i64 %t268, %t271
  %t273 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t272)
  call void @olang_textcopy(ptr %t273, ptr %t260, i64 %t261)
  %t274 = getelementptr i8, ptr %t273, i64 %t261
  call void @olang_textcopy(ptr %t274, ptr %t263, i64 %t264)
  %t275 = getelementptr i8, ptr %t274, i64 %t264
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t270, i64 %t271)
  %t277 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t273, 1
  store { i64, ptr } %t278, ptr %l88, !tbaa !27
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb50:
  %t280 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t280, ptr %l12, !tbaa !27
  %t281 = load ptr, ptr %l6, !tbaa !29
  %t283 = getelementptr %"compiler/eval:Image", ptr %t281, i32 0, i32 0
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %t283)
  store i64 %t285, ptr %l104
  br label %bb51
bb51:
  %t286 = load i64, ptr %l104, !tbaa !24
  %t287 = icmp eq i64 %t286, 1
  br i1 %t287, label %bb52, label %bb53
bb52:
  %t289 = load ptr, ptr %l6, !tbaa !29
  %t291 = getelementptr %"compiler/eval:Image", ptr %t289, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %t292, ptr %v0, ptr %v0, ptr %t291, i64 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t292, i64 272, i1 false)
  br label %bb54
bb53:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb57
bb54:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2feval_3aBlob(ptr %t294, ptr %v0, ptr %l109)
  call void @llvm.memmove.p0.p0.i64(ptr %l111, ptr %t294, i64 272, i1 false)
  br label %bb55
bb55:
  %t296 = getelementptr %"compiler/eval:Blob", ptr %l111, i32 0, i32 3
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t296)
  store i64 %t298, ptr %l113
  br label %bb56
bb56:
  %t299 = load i64, ptr %l113, !tbaa !24
  %t300 = icmp eq i64 %t299, 0
  store i1 %t300, ptr %l106, !tbaa !21
  br label %bb57
bb57:
  %t302 = load i1, ptr %l106, !tbaa !21
  br i1 %t302, label %bb58, label %bb59
bb58:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t305 = icmp sge i64 %t303, 0
  store i1 %t305, ptr %l115, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t307 = load i1, ptr %l115, !tbaa !21
  br i1 %t307, label %bb61, label %bb62
bb61:
  %t308 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t308, ptr %l118, !tbaa !27
  %t309 = load i64, ptr %l10, !tbaa !24
  %t311 = add i64 %t309, 12
  store i64 %t311, ptr %l120, !tbaa !24
  %t312 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t316 = sub i64 %t314, 1
  store i64 %t316, ptr %l123, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l124, !tbaa !24
  %t319 = load i64, ptr %l120, !tbaa !24
  %t320 = icmp sge i64 %t319, 0
  br i1 %t320, label %bb63, label %bb64
bb62:
  br label %bb72
bb63:
  %t322 = load i64, ptr %l120, !tbaa !24
  %t323 = load i64, ptr %l123, !tbaa !24
  %t324 = icmp sle i64 %t322, %t323
  br i1 %t324, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb65:
  %t326 = load i64, ptr %l123, !tbaa !24
  %t327 = load i64, ptr %l124, !tbaa !24
  %t328 = icmp sle i64 %t326, %t327
  br i1 %t328, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb67:
  %t330 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = load i64, ptr %l120, !tbaa !24
  %t333 = load i64, ptr %l123, !tbaa !24
  %t334 = getelementptr i8, ptr %t331, i64 %t332
  %t335 = sub i64 %t333, %t332
  %t336 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t334, 1
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t340 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t348 = extractvalue { i64, ptr } %t337, 1
  %t349 = extractvalue { i64, ptr } %t337, 0
  %t350 = add i64 %t346, %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t338, i64 %t339)
  %t352 = getelementptr i8, ptr %t351, i64 %t339
  call void @olang_textcopy(ptr %t352, ptr %t341, i64 %t342)
  %t353 = getelementptr i8, ptr %t352, i64 %t342
  call void @olang_textcopy(ptr %t353, ptr %t344, i64 %t345)
  %t354 = getelementptr i8, ptr %t353, i64 %t345
  call void @olang_textcopy(ptr %t354, ptr %t348, i64 %t349)
  %t355 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t351, 1
  store { i64, ptr } %t356, ptr %l129, !tbaa !27
  %t357 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t359 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l131, !tbaa !24
  %t362 = load i64, ptr %l131, !tbaa !24
  %t363 = icmp eq i64 %t358, %t362
  br i1 %t363, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb69:
  %t365 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l131, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  br label %bb71
bb70:
  %t371 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t371, ptr %l12, !tbaa !27
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t374 = load i64, ptr %l1, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t376, 1
  %t379 = extractvalue { i64, ptr } %t376, 0
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t382)
  call void @olang_textcopy(ptr %t383, ptr %t378, i64 %t379)
  %t384 = getelementptr i8, ptr %t383, i64 %t379
  call void @olang_textcopy(ptr %t384, ptr %t380, i64 %t381)
  %t385 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t383, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = extractvalue { i64, ptr } %t386, 1
  %t390 = mul i64 %t388, 1
  %t391 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %t372, { i64, ptr } %t373, i64 %t374, { i64, ptr } %t375, { i64, ptr } %t393)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s3)
  br label %bb76
bb74:
  %t399 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t399, ptr %l13, !tbaa !27
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t402 = load i64, ptr %l1, !tbaa !24
  %t403 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t404 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t405 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t408 = extractvalue { i64, ptr } %t403, 1
  %t409 = extractvalue { i64, ptr } %t403, 0
  %t410 = add i64 %t406, %t409
  %t411 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t412 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t413 = add i64 %t410, %t412
  %t415 = extractvalue { i64, ptr } %t404, 1
  %t416 = extractvalue { i64, ptr } %t404, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t421 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t420)
  call void @olang_textcopy(ptr %t421, ptr %t405, i64 %t406)
  %t422 = getelementptr i8, ptr %t421, i64 %t406
  call void @olang_textcopy(ptr %t422, ptr %t408, i64 %t409)
  %t423 = getelementptr i8, ptr %t422, i64 %t409
  call void @olang_textcopy(ptr %t423, ptr %t411, i64 %t412)
  %t424 = getelementptr i8, ptr %t423, i64 %t412
  call void @olang_textcopy(ptr %t424, ptr %t415, i64 %t416)
  %t425 = getelementptr i8, ptr %t424, i64 %t416
  call void @olang_textcopy(ptr %t425, ptr %t418, i64 %t419)
  %t426 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t421, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = extractvalue { i64, ptr } %t427, 1
  %t431 = mul i64 %t429, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t432, ptr %t430, i64 %t431, i1 false)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  %t435 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t436 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t437 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t440 = extractvalue { i64, ptr } %t435, 1
  %t441 = extractvalue { i64, ptr } %t435, 0
  %t442 = add i64 %t438, %t441
  %t443 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t447 = extractvalue { i64, ptr } %t436, 1
  %t448 = extractvalue { i64, ptr } %t436, 0
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t437, i64 %t438)
  %t454 = getelementptr i8, ptr %t453, i64 %t438
  call void @olang_textcopy(ptr %t454, ptr %t440, i64 %t441)
  %t455 = getelementptr i8, ptr %t454, i64 %t441
  call void @olang_textcopy(ptr %t455, ptr %t443, i64 %t444)
  %t456 = getelementptr i8, ptr %t455, i64 %t444
  call void @olang_textcopy(ptr %t456, ptr %t447, i64 %t448)
  %t457 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t457, ptr %t450, i64 %t451)
  %t458 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t453, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = extractvalue { i64, ptr } %t459, 1
  %t463 = mul i64 %t461, 1
  %t464 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t464, ptr %t462, i64 %t463, i1 false)
  %t465 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s14, ptr %s14, ptr %t400, { i64, ptr } %t401, i64 %t402, { i64, ptr } %t434, { i64, ptr } %t466)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb76:
  %t472 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t473 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t474 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t476 = extractvalue { i64, ptr } %t472, 1
  %t477 = extractvalue { i64, ptr } %t472, 0
  %t478 = add i64 %t474, %t477
  %t479 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t478)
  call void @olang_textcopy(ptr %t479, ptr %t473, i64 %t474)
  %t480 = getelementptr i8, ptr %t479, i64 %t474
  call void @olang_textcopy(ptr %t480, ptr %t476, i64 %t477)
  %t481 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t479, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t482, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l37 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb3
bb3:
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb31
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l20
  br label %bb7
bb7:
  %t21 = load i64, ptr %l20, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 46
  store ptr %t27, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l7, !tbaa !24
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l31
  br label %bb13
bb13:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:Emitter", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/lower:Lowerer", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t53)
  store ptr %t56, ptr %l37
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l37, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 1
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l9
  %t62 = load { i64, [2 x i64] }, ptr %l9
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 6
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t68 = getelementptr { i64, i32 }, ptr %t67, i32 0, i32 0
  %t69 = load i64, ptr %t68
  store i64 %t69, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %lp2
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t77, i64 %t78)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851)
  unreachable
bb27:
  br label %bb28
bb28:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  br label %bb30
bb30:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb2
bb31:
  %t89 = load ptr, ptr %lp2
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t89
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 76
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t4, i64 %a1)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l8
  br label %bb2
bb2:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i8
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l32 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l49 = alloca i32
  %l53 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l99 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l151 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l167 = alloca i1
  %l169 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store { i64, ptr } %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t6, i32 %t7)
  br label %bb1
bb1:
  %t10 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t10, ptr %l31
  br label %bb2
bb2:
  %t11 = load %"std/prelude/text:StringBuilder", ptr %l31
  store %"std/prelude/text:StringBuilder" %t11, ptr %l9
  store ptr %l9, ptr %l32, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t14, ptr %l34
  br label %bb3
bb3:
  %t15 = load i1, ptr %l34, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d155, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l35, !tbaa !27
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l41
  br label %bb7
bb7:
  %t45 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t56 = extractvalue { i64, ptr } %a3, 1
  %t57 = extractvalue { i64, ptr } %a3, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t62, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb8
bb8:
  store i1 true, ptr %l10, !tbaa !21
  br i1 %a5, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l9, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l8, !tbaa !29
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l49
  br label %bb13
bb13:
  %t86 = load i32, ptr %l49, !tbaa !23
  store i32 %t86, ptr %l11, !tbaa !23
  %t87 = load i32, ptr %l11, !tbaa !23
  %t88 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t91 = icmp ne i32 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i32, ptr %l11, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t97 = icmp ne i32 %t93, %t94
  store i1 %t97, ptr %l53, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t99 = load i1, ptr %l53, !tbaa !21
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t101 = load i32, ptr %l11, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l60
  br label %bb19
bb18:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb20
bb19:
  %t105 = load i1, ptr %l60, !tbaa !21
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l57, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load i1, ptr %l10, !tbaa !21
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb23, label %bb24
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l9, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb27
bb27:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  store i64 0, ptr %l12, !tbaa !24
  store i64 %a4, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb34
bb31:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l72, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l72, !tbaa !24
  store i64 %t141, ptr %l69, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l69, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb37:
  br label %bb38
bb38:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l17, !tbaa !24
  %t161 = load i1, ptr %l10, !tbaa !21
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb42:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t170 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t167, i64 %t168)
  %t173 = getelementptr i8, ptr %t172, i64 %t168
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t166)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l9, { i64, ptr } %t183)
  br label %bb43
bb43:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l16, !tbaa !24
  br label %bb35
bb45:
  %t190 = load ptr, ptr %l8, !tbaa !29
  store ptr %t190, ptr %l99, !tbaa !29
  %t191 = load ptr, ptr %l8, !tbaa !29
  %t192 = load i32, ptr %l2, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l102
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l99, !tbaa !29
  %t197 = load i32, ptr %l102, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t196, i32 %t197)
  store { i64, ptr } %t198, ptr %l103
  br label %bb47
bb47:
  %t199 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t199, ptr %l18, !tbaa !27
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t200, i32 %t201)
  store { i64, ptr } %t204, ptr %l106
  br label %bb48
bb48:
  %t205 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t205, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t210 = load i64, ptr %l21, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb49, label %bb50
bb49:
  %t216 = load i64, ptr %l22, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb54
bb51:
  %t220 = load i64, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l20, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l22, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l22, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l115, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb53
bb53:
  %t236 = load i64, ptr %l115, !tbaa !24
  store i64 %t236, ptr %l112, !tbaa !24
  br label %bb54
bb54:
  %t237 = load i64, ptr %l112, !tbaa !24
  store i64 %t237, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb55
bb55:
  %t238 = load i64, ptr %l24, !tbaa !24
  %t239 = load i64, ptr %l23, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb56, label %bb57
bb56:
  br label %bb81
bb57:
  br label %bb58
bb58:
  %t246 = load i64, ptr %l20, !tbaa !24
  %t247 = load i64, ptr %l24, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l25, !tbaa !24
  %t256 = load i1, ptr %l10, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  store i1 false, ptr %l10, !tbaa !21
  %t261 = load i64, ptr %l25, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i8, ptr %t264, i64 %t261
  %t266 = load i8, ptr %t265, !tbaa !32
  store i8 %t266, ptr %l26, !tbaa !22
  %t268 = load i8, ptr %l26, !tbaa !22
  %t270 = icmp eq i8 %t268, 109
  br i1 %t270, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  store %olang.scope zeroinitializer, ptr %s14
  %t272 = load i64, ptr %l25, !tbaa !24
  %t273 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t276 = call i64 @__olang_fmt_i64(ptr null, i64 %t272)
  %t277 = add i64 %t274, %t276
  %t278 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t277)
  call void @olang_textcopy(ptr %t278, ptr %t273, i64 %t274)
  %t279 = getelementptr i8, ptr %t278, i64 %t274
  %t280 = call i64 @__olang_fmt_i64(ptr %t279, i64 %t272)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t278, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = extractvalue { i64, ptr } %t282, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l9, { i64, ptr } %t289)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb67:
  %t292 = load i8, ptr %l26, !tbaa !22
  %t294 = icmp eq i8 %t292, 115
  br i1 %t294, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t296 = load i64, ptr %l25, !tbaa !24
  %t297 = load i64, ptr %l25, !tbaa !24
  %t298 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t301 = call i64 @__olang_fmt_i64(ptr null, i64 %t296)
  %t302 = add i64 %t299, %t301
  %t303 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t307 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t308 = add i64 %t305, %t307
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t298, i64 %t299)
  %t313 = getelementptr i8, ptr %t312, i64 %t299
  %t314 = call i64 @__olang_fmt_i64(ptr %t313, i64 %t296)
  %t315 = getelementptr i8, ptr %t313, i64 %t301
  call void @olang_textcopy(ptr %t315, ptr %t303, i64 %t304)
  %t316 = getelementptr i8, ptr %t315, i64 %t304
  %t317 = call i64 @__olang_fmt_i64(ptr %t316, i64 %t297)
  %t318 = getelementptr i8, ptr %t316, i64 %t307
  call void @olang_textcopy(ptr %t318, ptr %t309, i64 %t310)
  %t319 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t312, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l9, { i64, ptr } %t327)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l9, ptr %l151, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t331, ptr %l153, !tbaa !27
  %t332 = load i64, ptr %l25, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i32, ptr %t335, i64 %t332
  %t337 = load i32, ptr %t336, !tbaa !33
  %t340 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s18, ptr %t330, i32 %t337)
  store { i64, ptr } %t340, ptr %l156
  br label %bb76
bb76:
  %t341 = load i64, ptr %l25, !tbaa !24
  %t342 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t349 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t350 = add i64 %t347, %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t343, i64 %t344)
  %t352 = getelementptr i8, ptr %t351, i64 %t344
  call void @olang_textcopy(ptr %t352, ptr %t345, i64 %t346)
  %t353 = getelementptr i8, ptr %t352, i64 %t346
  %t354 = call i64 @__olang_fmt_i64(ptr %t353, i64 %t341)
  %t355 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t351, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = extractvalue { i64, ptr } %t356, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t364 = load ptr, ptr %l151, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t364, { i64, ptr } %t363)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_32ecc2f0b2e54909_486ad1b7ea10ca75)
  unreachable
bb79:
  br label %bb80
bb80:
  %t366 = load i64, ptr %l24, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l24, !tbaa !24
  br label %bb55
bb81:
  store ptr %l9, ptr %l162, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t370, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t372, ptr %l164
  br label %bb82
bb82:
  %t373 = load i1, ptr %l164, !tbaa !21
  br i1 %t373, label %bb83, label %bb84
bb83:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb90
bb84:
  %t374 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t376 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t374, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store i1 %t376, ptr %l167
  br label %bb85
bb85:
  %t377 = load i1, ptr %l167, !tbaa !21
  %t378 = xor i1 %t377, true
  br i1 %t378, label %bb86, label %bb87
bb86:
  %t380 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t380, ptr %l169, !tbaa !27
  br label %bb89
bb87:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t386 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2einlining(ptr %v0, ptr %v3, ptr %t382, { i64, [2 x i64] } %a1)
  store { i64, ptr } %t386, ptr %l173
  br label %bb88
bb88:
  %t387 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 0
  %t389 = extractvalue { i64, ptr } %t387, 1
  %t390 = mul i64 %t388, 1
  %t391 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  store { i64, ptr } %t393, ptr %l169, !tbaa !27
  br label %bb89
bb89:
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t397 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t398, i64 %t399)
  %t406 = getelementptr i8, ptr %t405, i64 %t399
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  store { i64, ptr } %t415, ptr %l165, !tbaa !27
  br label %bb90
bb90:
  %t417 = load ptr, ptr %l162, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l165, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t417, { i64, ptr } %t418)
  br label %bb91
bb91:
  %t420 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l9)
  store { i64, ptr } %t420, ptr %l178
  br label %bb92
bb92:
  %t421 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t421, ptr %l179, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t422, 0
  store i64 %t423, ptr %l180, !tbaa !24
  %t424 = load i64, ptr %l180, !tbaa !24
  %t425 = mul i64 %t424, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t425)
  %t427 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  store { i64, ptr } %t428, ptr %l181, !tbaa !27
  %t429 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = load i64, ptr %l180, !tbaa !24
  %t434 = mul i64 %t433, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t430, ptr %t432, i64 %t434, i1 false)
  %t435 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t435, ptr %l179, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t436 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t436, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  %t31 = extractvalue { i64, [2 x i64] } %t27, 0
  %t32 = icmp eq i64 %t31, 6
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_616c6f643d0ce9fd_dfe523617d4699c1)
  unreachable
bb13:
  %t34 = load i1, ptr %l17, !tbaa !21
  store i1 %t34, ptr %l4, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b37ed008d0080fcc_cc9019489ebc5a30)
  unreachable
bb19:
  %t35 = load i1, ptr %l4, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 0
  store i64 %t10, ptr %l18, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l19, !tbaa !24
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 0, %t15
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb3:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb5:
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = getelementptr i8, ptr %t23, i64 0
  %t26 = sub i64 %t24, 0
  %t27 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %t31, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t30)
  store i1 %t34, ptr %l26
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb7:
  %t35 = load i1, ptr %l26, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store i1 %t40, ptr %l30
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l35, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb16:
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb18:
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l34, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  store i1 true, ptr %l5, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %t69, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t68)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l43
  br label %bb21
bb21:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d177, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load ptr, ptr %l3, !tbaa !29
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l52
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i32, ptr %l52, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t101, i32 %t102)
  store { i64, ptr } %t103, ptr %l53
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i1, ptr %l5, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i32 13, ptr %l55
  br label %bb29
bb28:
  store i32 14, ptr %l55
  br label %bb29
bb29:
  %t109 = load i32, ptr %l55, !range !{i32 0, i32 33}
  store i32 %t109, ptr %l8
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp ne i64 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l66
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l66, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l67
  br label %bb33
bb33:
  %t127 = load i32, ptr %l8, !range !{i32 0, i32 33}
  store i32 %t127, ptr %l69
  %t130 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l67, ptr %l69)
  store i1 %t130, ptr %l71
  br label %bb34
bb34:
  %t131 = load i1, ptr %l71, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t135, ptr %l74, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l75, !tbaa !24
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l75, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t149, ptr %l74, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l11, !tbaa !24
  br label %bb39
bb39:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb40, label %bb41
bb40:
  br label %bb49
bb41:
  br label %bb42
bb42:
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t171)
  store i32 %t177, ptr %l89
  br label %bb43
bb43:
  %t178 = load i32, ptr %l8, !range !{i32 0, i32 33}
  store i32 %t178, ptr %l91
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l89, ptr %l91)
  store i1 %t181, ptr %l93
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l95, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t185, ptr %l96, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l97, !tbaa !24
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = mul i64 %t188, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l98, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l97, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t199, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t200 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb39
bb49:
  %t205 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t205, ptr %l101, !tbaa !27
  %t206 = load i1, ptr %l5, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d180, i32 0, i32 1) }, ptr %l103, !tbaa !27
  br label %bb52
bb51:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, ptr %l103, !tbaa !27
  br label %bb52
bb52:
  %t208 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t210 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t217 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t208, i64 %t209)
  %t222 = getelementptr i8, ptr %t221, i64 %t209
  call void @olang_textcopy(ptr %t222, ptr %t211, i64 %t212)
  %t223 = getelementptr i8, ptr %t222, i64 %t212
  call void @olang_textcopy(ptr %t223, ptr %t214, i64 %t215)
  %t224 = getelementptr i8, ptr %t223, i64 %t215
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t221, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l2 = alloca i32
  %l9 = alloca i64
  %rv = alloca i64
  %t7 = alloca { i64, [7 x i64] }, align 8
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [7 x i64] }, ptr %t7, i32 0, i32 0
  store i64 0, ptr %t8
  %t10 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %a1, 0
  %t12 = insertvalue { { i64, [2 x i64] }, i32 } %t10, i32 %t6, 1
  %t13 = getelementptr { i64, [7 x i64] }, ptr %t7, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t12, ptr %t13
  %t14 = load { i64, [7 x i64] }, ptr %t7
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t4, { i64, [7 x i64] } %t14, i32 %t15)
  store i64 %t19, ptr %l9
  br label %bb1
bb1:
  %t20 = load i64, ptr %l9, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i1
  %l67 = alloca i64
  %l70 = alloca i64
  %l88 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l30, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l30, !tbaa !24
  store i64 %t42, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l27, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load ptr, ptr %l3, !tbaa !29
  store ptr %t62, ptr %l48, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 %t65
  %t70 = load i32, ptr %t69, !tbaa !33
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t63, i32 %t70)
  store i32 %t73, ptr %l53
  br label %bb12
bb12:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t74, i32 %a2)
  store i32 %t78, ptr %l56
  br label %bb13
bb13:
  %t79 = load ptr, ptr %l48, !tbaa !29
  %t80 = load i32, ptr %l53, !tbaa !23
  %t81 = load i32, ptr %l56, !tbaa !23
  %t82 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t79, i32 %t80, i32 %t81)
  store i1 %t82, ptr %l57
  br label %bb14
bb14:
  %t83 = load i1, ptr %l57, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb8
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t102 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb25
bb22:
  %t106 = load i64, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = sub i64 %t106, %t107
  %t111 = load i64, ptr %l13, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sub i64 %t114, 1
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = sdiv i64 %t116, %t117
  store i64 %t120, ptr %l70, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb24
bb24:
  %t122 = load i64, ptr %l70, !tbaa !24
  store i64 %t122, ptr %l67, !tbaa !24
  br label %bb25
bb25:
  %t123 = load i64, ptr %l67, !tbaa !24
  store i64 %t123, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  store i64 %t140, ptr %l16, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l88, !tbaa !27
  %t143 = load i64, ptr %l16, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t152 = icmp eq i32 %t148, %t149
  br i1 %t152, label %bb30, label %bb31
bb30:
  %t154 = load i64, ptr %l16, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t158 = load i64, ptr %l15, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l15, !tbaa !24
  br label %bb26
bb34:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereusing(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/emit:Reused"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca i1
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i1
  %l73 = alloca i64
  %l78 = alloca { i64, ptr }
  %l96 = alloca i64
  %l98 = alloca i64
  %l104 = alloca %"compiler/emit:Reused"
  %l106 = alloca %"compiler/emit:Reused"
  %l113 = alloca i1
  %l117 = alloca i1
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, [2 x i64] }
  %l131 = alloca { i64, [2 x i64] }
  %l132 = alloca i32
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t95 = alloca { i64, [2 x i64] }, align 8
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t189 = alloca %"compiler/emit:Reused", align 8
  %t192 = alloca %"compiler/emit:Reused", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 68
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l27
  br label %bb2
bb2:
  %t10 = load i64, ptr %l27, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 39
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l29, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l29, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %lp1
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t19
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fmir_3aFnKey_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %l33
  br label %bb9
bb9:
  %t23 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:Emitter", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/lower:Lowerer", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l37
  br label %bb10
bb10:
  %t33 = load i64, ptr %l37, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb16
bb13:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l44, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l44, !tbaa !24
  store i64 %t60, ptr %l41, !tbaa !24
  br label %bb16
bb16:
  %t61 = load i64, ptr %l41, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:Emitter", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l65
  br label %bb21
bb21:
  %t88 = load i1, ptr %l65, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = trunc i64 %t91 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 0, ptr %t96
  %t98 = insertvalue { i32 } undef, i32 %t93, 0
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 1
  store { i32 } %t98, ptr %t99
  %t100 = load { i64, [2 x i64] }, ptr %t95
  store { i64, [2 x i64] } %t100, ptr %l9
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, [2 x i64] }, ptr %l9
  %t106 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t102, { i64, [2 x i64] } %t103)
  store i64 %t106, ptr %l73
  br label %bb25
bb25:
  %t107 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t108 = load i64, ptr %l73, !tbaa !24
  %t110 = icmp ne i64 %t108, %t107
  br i1 %t110, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, [2 x i64] }, ptr %l9
  %t116 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s3, ptr %t112, { i64, [2 x i64] } %t113)
  store { i64, ptr } %t116, ptr %l78
  br label %bb29
bb29:
  %t117 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t117, ptr %l10, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = getelementptr i8, ptr %t125, i64 %t121
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load i64, ptr %l8, !tbaa !24
  %t138 = trunc i64 %t136 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 1, ptr %t141
  %t143 = insertvalue { i32 } undef, i32 %t138, 0
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 1
  store { i32 } %t143, ptr %t144
  %t145 = load { i64, [2 x i64] }, ptr %t140
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H113622d1f8bf95ca2a74cd371898add0(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t135, { i64, [2 x i64] } %t145)
  br label %bb30
bb30:
  %t149 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = extractvalue { i64, ptr } %t149, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load { i64, [2 x i64] }, ptr %l9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H113622d1f8bf95ca2a74cd371898add0(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t162, { i64, [2 x i64] } %t163)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l7, !tbaa !24
  br label %bb17
bb33:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/emit:Emitter", ptr %t171, i32 0, i32 68
  store ptr %t173, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t175 = load i64, ptr %l12, !tbaa !24
  store i64 %t175, ptr %l96, !tbaa !24
  %t176 = load ptr, ptr %l11, !tbaa !29
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l98
  br label %bb35
bb35:
  %t179 = load i64, ptr %l96, !tbaa !24
  %t180 = load i64, ptr %l98, !tbaa !24
  %t181 = icmp slt i64 %t179, %t180
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s10)
  br label %bb76
bb37:
  br label %bb38
bb38:
  %t185 = load i64, ptr %l12, !tbaa !24
  store i64 %t185, ptr %l13, !tbaa !24
  %t187 = load ptr, ptr %l11, !tbaa !29
  %t188 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %t189, ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  call void @llvm.memmove.p0.p0.i64(ptr %l104, ptr %t189, i64 160, i1 false)
  br label %bb39
bb39:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2femit_3aReused(ptr %t192, ptr %v0, ptr %l104)
  call void @llvm.memmove.p0.p0.i64(ptr %l106, ptr %t192, i64 160, i1 false)
  br label %bb40
bb40:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l106, i64 160, i1 false)
  %t194 = getelementptr %"compiler/emit:Reused", ptr %l14, i32 0, i32 0
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/emit:Emitter", ptr %t196, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 12
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = icmp eq i64 %t195, %t205
  br i1 %t208, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb44
bb42:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/emit:Emitter", ptr %t210, i32 0, i32 69
  %t213 = getelementptr %"compiler/emit:Reused", ptr %l14, i32 0, i32 0
  %t214 = load i64, ptr %t213, !tbaa !24
  %t217 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t212, i64 %t214)
  store i1 %t217, ptr %l117
  br label %bb43
bb43:
  %t218 = load i1, ptr %l117, !tbaa !21
  store i1 %t218, ptr %l113, !tbaa !21
  br label %bb44
bb44:
  %t219 = load i1, ptr %l113, !tbaa !21
  br i1 %t219, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb46:
  br label %bb47
bb47:
  %t220 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, ptr %l118
  br label %bb48
bb48:
  %t221 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l15
  store i1 true, ptr %l16, !tbaa !21
  %t222 = getelementptr %"compiler/emit:Reused", ptr %l14, i32 0, i32 6
  store ptr %t222, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb49
bb49:
  %t224 = load i64, ptr %l18, !tbaa !24
  store i64 %t224, ptr %l120, !tbaa !24
  %t225 = load ptr, ptr %l17, !tbaa !29
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t225)
  store i64 %t227, ptr %l122
  br label %bb50
bb50:
  %t228 = load i64, ptr %l120, !tbaa !24
  %t229 = load i64, ptr %l122, !tbaa !24
  %t230 = icmp slt i64 %t228, %t229
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb51, label %bb52
bb51:
  br label %bb61
bb52:
  br label %bb53
bb53:
  %t234 = load ptr, ptr %l17, !tbaa !29
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t234, i64 %t235)
  store { i64, ptr } %t238, ptr %l127
  br label %bb54
bb54:
  %t239 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t243 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hc46d619d13eb72fb3404dc4d54e1aab7(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t239)
  %t244 = extractvalue { i32, { i64, [2 x i64] } } %t243, 1
  %t245 = extractvalue { i32, { i64, [2 x i64] } } %t243, 0
  store i32 %t245, ptr %l132
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb56, label %ok.247, !prof !99
ok.247:
  store { i64, [2 x i64] } %t244, ptr %l131
  br label %bb55
bb55:
  %t248 = load { i64, [2 x i64] }, ptr %l131
  store { i64, [2 x i64] } %t248, ptr %l128
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l16, !tbaa !21
  br label %bb61
bb58:
  %t249 = load { i64, [2 x i64] }, ptr %l128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %s10, ptr %l15, { i64, [2 x i64] } %t249)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t253 = load i64, ptr %l18, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l18, !tbaa !24
  br label %bb49
bb61:
  %t257 = load i1, ptr %l16, !tbaa !21
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb63:
  br label %bb64
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/emit:Emitter", ptr %t261, i32 0, i32 69
  %t264 = getelementptr %"compiler/emit:Reused", ptr %l14, i32 0, i32 0
  %t265 = load i64, ptr %t264, !tbaa !24
  %t266 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t263, i64 %t265, i64 %t266)
  br label %bb65
bb65:
  store ptr %l15, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb66
bb66:
  %t271 = load i64, ptr %l22, !tbaa !24
  store i64 %t271, ptr %l144, !tbaa !24
  %t272 = load ptr, ptr %l21, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s10, ptr %t272)
  store i64 %t274, ptr %l146
  br label %bb67
bb67:
  %t275 = load i64, ptr %l144, !tbaa !24
  %t276 = load i64, ptr %l146, !tbaa !24
  %t277 = icmp slt i64 %t275, %t276
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb68, label %bb69
bb68:
  br label %bb74
bb69:
  br label %bb70
bb70:
  %t281 = load ptr, ptr %l21, !tbaa !29
  %t282 = load i64, ptr %l22, !tbaa !24
  %t285 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %s10, ptr %t281, i64 %t282)
  store { i64, [2 x i64] } %t285, ptr %l151
  br label %bb71
bb71:
  %t286 = load { i64, [2 x i64] }, ptr %l151
  %t287 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %t287, { i64, [2 x i64] } %t286)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l22, !tbaa !24
  br label %bb66
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb75:
  %t295 = load i64, ptr %l12, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l12, !tbaa !24
  br label %bb34
bb76:
  %t299 = load ptr, ptr %lp1
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t299
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l13 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %t15, i64 %t18)
  store { i64, ptr } %t21, ptr %l20
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  br label %bb43
bb5:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 3
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 5}
  store i32 %t30, ptr %l4
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 5}
  store i32 %t36, ptr %l25
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l28
  br label %bb9
bb9:
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l28, !tbaa !23
  %t45 = icmp eq i32 %t43, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l34
  br label %bb12
bb11:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s2, ptr %t52, i32 %t53)
  store { i64, ptr } %t56, ptr %l37
  br label %bb13
bb12:
  %t57 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t57, ptr %l31, !tbaa !27
  br label %bb14
bb13:
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t59, i64 %t60)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s3, ptr %l25, i64 0)
  br label %bb15
bb15:
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t62, i64 %t63)
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s3, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s3
  %t68 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t67, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %sbgrew.76, label %sbdone.77
sbgrew.76:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.77
sbdone.77:
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l41
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t87, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb17:
  %t88 = load { i64, [2 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [2 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l6, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s4, ptr %t97, i64 %t100)
  store { i64, ptr } %t103, ptr %l48
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t105, i64 %t106)
  %t111 = getelementptr i8, ptr %t110, i64 %t106
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb22:
  %t115 = load { i64, [2 x i64] }, ptr %l1
  %t117 = extractvalue { i64, [2 x i64] } %t115, 0
  %t118 = icmp eq i64 %t117, 2
  br i1 %t118, label %bb23, label %bb24
bb23:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { i32 }, ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l7, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l7, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s6, ptr %t124, i64 %t127)
  store { i64, ptr } %t130, ptr %l56
  br label %bb26
bb26:
  %t131 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = getelementptr i8, ptr %t137, i64 %t133
  call void @olang_textcopy(ptr %t138, ptr %t134, i64 %t135)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb27:
  %t142 = load { i64, [2 x i64] }, ptr %l1
  %t144 = extractvalue { i64, [2 x i64] } %t142, 0
  %t145 = icmp eq i64 %t144, 4
  br i1 %t145, label %bb28, label %bb29
bb28:
  %t147 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i64 }, ptr %t147, i32 0, i32 0
  %t149 = load i64, ptr %t148
  store i64 %t149, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/emit:Emitter", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/load:Loader", ptr %t157, i32 0, i32 10
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t159, i64 %t160)
  store ptr %t163, ptr %l66
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l66, !tbaa !29
  %t166 = getelementptr %"compiler/load:Module", ptr %t164, i32 0, i32 2
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t167, 1
  %t172 = extractvalue { i64, ptr } %t167, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  call void @olang_textcopy(ptr %t175, ptr %t171, i64 %t172)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t186 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t184)
  store { i64, ptr } %t186, ptr %l71
  br label %bb32
bb32:
  %t187 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t187, ptr %l13, !tbaa !27
  br label %bb43
bb33:
  %t188 = load { i64, [2 x i64] }, ptr %l1
  %t190 = extractvalue { i64, [2 x i64] } %t188, 0
  %t191 = icmp eq i64 %t190, 5
  br i1 %t191, label %bb34, label %bb35
bb34:
  %t193 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t194 = getelementptr { i64, i1 }, ptr %t193, i32 0, i32 0
  %t195 = load i64, ptr %t194
  store i64 %t195, ptr %l9, !tbaa !24
  %t197 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t198 = getelementptr { i64, i1 }, ptr %t197, i32 0, i32 1
  %t199 = load i1, ptr %t198
  store i1 %t199, ptr %l10, !tbaa !21
  br label %bb36
bb35:
  br label %bb42
bb36:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i1, ptr %l10, !tbaa !21
  br i1 %t201, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb39
bb39:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s10, ptr %t203, i64 %t204)
  store { i64, ptr } %t207, ptr %l80
  br label %bb40
bb40:
  %t208 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t217 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t208, i64 %t209)
  %t222 = getelementptr i8, ptr %t221, i64 %t209
  call void @olang_textcopy(ptr %t222, ptr %t211, i64 %t212)
  %t223 = getelementptr i8, ptr %t222, i64 %t212
  call void @olang_textcopy(ptr %t223, ptr %t214, i64 %t215)
  %t224 = getelementptr i8, ptr %t223, i64 %t215
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t221, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t235 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t233)
  store { i64, ptr } %t235, ptr %l83
  br label %bb41
bb41:
  %t236 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t236, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_325a0aca37049b03_8faf0435ed6a0227)
  unreachable
bb43:
  %t237 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t237, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 47
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/generic:AnyTable", ptr %t13, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t12, i32 %t16)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/generic:AnyTable", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t20, i32 %t24)
  store { i64, ptr } %t27, ptr %l15
  br label %bb3
bb3:
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t29, i64 %t30)
  %t39 = getelementptr i8, ptr %t38, i64 %t30
  call void @olang_textcopy(ptr %t39, ptr %t31, i64 %t32)
  %t40 = getelementptr i8, ptr %t39, i64 %t32
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l58 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 72
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l18
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l17
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l13, !tbaa !27
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t16, ptr %l20
  br label %bb5
bb5:
  %t17 = load i1, ptr %l20, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t28, ptr %l24
  br label %bb9
bb9:
  %t29 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/lower:Lowerer", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l28
  br label %bb10
bb10:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb16
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l32, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l32, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb46
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t92, i64 %t94)
  store ptr %t97, ptr %l58
  br label %bb21
bb21:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 1
  %t101 = load { i64, [2 x i64] }, ptr %t100
  %t105 = extractvalue { i64, [2 x i64] } %t101, 0
  %t106 = icmp eq i64 %t105, 5
  br i1 %t106, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb39
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %s5, ptr %t108, i64 %t109)
  store { i64, ptr } %t112, ptr %l65
  br label %bb25
bb25:
  %t113 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t121 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s5, { i64, ptr } %t119)
  store i64 %t121, ptr %l67
  br label %bb26
bb26:
  %t122 = load i64, ptr %l67, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l3, i64 %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l72
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb28, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l71
  br label %bb27
bb27:
  %t131 = load i64, ptr %l71, !tbaa !24
  store i64 %t131, ptr %l68, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l68, !tbaa !24
  br label %bb30
bb30:
  %t132 = load i64, ptr %l68, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = add i64 %t134, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %l3, i64 %t133, i64 %t136)
  br label %bb31
bb31:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/emit:Emitter", ptr %t140, i32 0, i32 72
  store ptr %t142, ptr %l78, !tbaa !29
  %t143 = load i64, ptr %l9, !tbaa !24
  store i64 %t143, ptr %l79, !tbaa !24
  %t144 = load i64, ptr %l11, !tbaa !24
  store i64 %t144, ptr %l81, !tbaa !65
  %t146 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t147 = extractvalue { i32, i64 } %t146, 1
  %t148 = extractvalue { i32, i64 } %t146, 0
  store i32 %t148, ptr %l83
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb33, label %ok.150, !prof !99
ok.150:
  store i64 %t147, ptr %l82
  br label %bb32
bb32:
  %t151 = load i64, ptr %l81, !tbaa !65
  %t152 = load i64, ptr %l82, !tbaa !24
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s5, i64 %t151, i64 %t152)
  store { i64, ptr } %t153, ptr %l84
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_d645e5ac48fafc6b_b6d88d5997c962c7)
  unreachable
bb34:
  %t154 = load i64, ptr %l12, !tbaa !24
  %t156 = icmp eq i64 %t154, 0
  br i1 %t156, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb37
bb36:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t162 = call i64 @__olang_fmt_i64(ptr null, i64 %t158)
  %t163 = add i64 %t160, %t162
  %t164 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t159, i64 %t160)
  %t165 = getelementptr i8, ptr %t164, i64 %t160
  %t166 = call i64 @__olang_fmt_i64(ptr %t165, i64 %t158)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t164, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l87, !tbaa !27
  br label %bb37
bb37:
  %t177 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t179 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t177, i64 %t178)
  %t188 = getelementptr i8, ptr %t187, i64 %t178
  call void @olang_textcopy(ptr %t188, ptr %t180, i64 %t181)
  %t189 = getelementptr i8, ptr %t188, i64 %t181
  call void @olang_textcopy(ptr %t189, ptr %t184, i64 %t185)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t187, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } %t191, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  %t199 = load ptr, ptr %l78, !tbaa !29
  %t200 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t199, i64 %t200, { i64, ptr } %t198)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_708cde11eb66cdaa_cb4b3307e5e96e66)
  unreachable
bb44:
  br label %bb45
bb45:
  %t202 = load i64, ptr %l8, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l8, !tbaa !24
  br label %bb17
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/emit:Emitter", ptr %t206, i32 0, i32 72
  %t209 = load i64, ptr %l1, !tbaa !24
  %t212 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %t208, i64 %t209)
  %t213 = extractvalue { i32, { i64, ptr } } %t212, 1
  %t214 = extractvalue { i32, { i64, ptr } } %t212, 0
  store i32 %t214, ptr %l100
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb48, label %ok.216, !prof !99
ok.216:
  store { i64, ptr } %t213, ptr %l99
  br label %bb47
bb47:
  %t217 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t217, ptr %l95, !tbaa !27
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  %t218 = load i64, ptr %l1, !tbaa !24
  %t219 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t222 = call i64 @__olang_fmt_i64(ptr null, i64 %t218)
  %t223 = add i64 %t220, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t219, i64 %t220)
  %t225 = getelementptr i8, ptr %t224, i64 %t220
  %t226 = call i64 @__olang_fmt_i64(ptr %t225, i64 %t218)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t224, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = extractvalue { i64, ptr } %t228, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l95, !tbaa !27
  br label %bb50
bb50:
  %t237 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t237, ptr %l104, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  store i64 %t239, ptr %l105, !tbaa !24
  %t240 = load i64, ptr %l105, !tbaa !24
  %t241 = mul i64 %t240, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t241)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l106, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = load i64, ptr %l105, !tbaa !24
  %t250 = mul i64 %t249, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t246, ptr %t248, i64 %t250, i1 false)
  %t251 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t251, ptr %l104, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t252 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t252, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/types:Table", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = extractvalue { i64, ptr } %a3, 1
  %t12 = extractvalue { i64, ptr } %a3, 0
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  call void @olang_textcopy(ptr %t17, ptr %t13, i64 %t14)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t22, ptr %l15
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i1, ptr %l5, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t28, ptr %l21
  %t29 = load i32, ptr %l2, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load i1, ptr %l5, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i64 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb6
bb6:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = load { i64, [2 x i64] }, ptr %l21
  %t49 = load i32, ptr %l22, !tbaa !23
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load i1, ptr %l25, !tbaa !21
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t47, { i64, [2 x i64] } %t48, i32 %t49, { i64, ptr } %t50, i64 %t51, i1 %t52, { i64, ptr } %t46, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d202, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l31
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %a6, { i64, ptr } %t57)
  store { i64, ptr } %t61, ptr %l35
  br label %bb8
bb8:
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t63, i64 %t64)
  %t70 = getelementptr i8, ptr %t69, i64 %t64
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load ptr, ptr %l14, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l15
  %t82 = load i32, ptr %l16, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t84 = load i64, ptr %l18, !tbaa !24
  %t85 = load i1, ptr %l19, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t80, { i64, [2 x i64] } %t81, i32 %t82, { i64, ptr } %t83, i64 %t84, i1 %t85, { i64, ptr } %t79)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t13 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t4, i64 %a1, i64 %t9)
  store { i64, ptr } %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) })
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l14
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb3, label %ok.21, !prof !99
ok.21:
  store i64 %t18, ptr %l13
  br label %bb2
bb2:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l11, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb8, label %bb9
bb7:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l17, !tbaa !27
  br label %bb14
bb8:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = icmp sle i64 0, %t41
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb10:
  %t44 = load i64, ptr %l18, !tbaa !24
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb12:
  %t48 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l18, !tbaa !24
  %t51 = getelementptr i8, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = extractvalue { i64, ptr } %t54, 0
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t56, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l17, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4e101a65701de364_bb0ca6f6f49ef738)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l19 = alloca %"compiler/emit:fnEm"
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca { i64, [2 x i64] }
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca { i64, [2 x i64] }
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l145 = alloca i1
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca { i64, [2 x i64] }
  %l161 = alloca i32
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca i1
  %l166 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i1
  %t12 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a6, 1
  %t4 = extractvalue { i64, ptr } %a6, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_3afnEm_2ector(ptr %t12, ptr %v0, ptr %v1, ptr %v0, ptr %t9, ptr %t10, { i64, [2 x i64] } %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t12, i64 960, i1 false)
  br label %bb1
bb1:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 960, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l19, i64 960, i1 false)
  store ptr %t16, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr %"compiler/emit:fnEm", ptr %t18, i32 0, i32 7
  store i64 %t19, ptr %t22, !tbaa !24
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = load i1, ptr %l5, !tbaa !21
  %t27 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 12
  store i1 %t24, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l9, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 25
  %t32 = load i1, ptr %t31, !tbaa !21
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t28, i32 0, i32 28
  store i1 %t32, ptr %t35, !tbaa !21
  %t36 = load ptr, ptr %l9, !tbaa !29
  %t37 = load i1, ptr %l7, !tbaa !21
  %t40 = getelementptr %"compiler/emit:fnEm", ptr %t36, i32 0, i32 30
  store i1 %t37, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 24
  store i1 false, ptr %t43, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l32
  br label %bb2
bb2:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t48 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %t48)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %t50)
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 24
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s3, ptr %t57, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l38, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t60, ptr %l39
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/mir:Fn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l41, !tbaa !23
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t65, ptr %l42, !tbaa !27
  %t66 = load i64, ptr %l4, !tbaa !24
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i1, ptr %l5, !tbaa !21
  store i1 %t67, ptr %l44, !tbaa !21
  %t68 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t68, ptr %l45, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s3, ptr %v2, ptr %s3, ptr %t69, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d205, i32 0, i32 1) }, { i64, ptr } %t70)
  store { i64, ptr } %t73, ptr %l48
  br label %bb11
bb11:
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t75, i64 %t76)
  %t82 = getelementptr i8, ptr %t81, i64 %t76
  call void @olang_textcopy(ptr %t82, ptr %t78, i64 %t79)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l38, !tbaa !29
  %t93 = load { i64, [2 x i64] }, ptr %l39
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t96 = load i64, ptr %l43, !tbaa !24
  %t97 = load i1, ptr %l44, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s3, ptr %t92, { i64, [2 x i64] } %t93, i32 %t94, { i64, ptr } %t95, i64 %t96, i1 %t97, { i64, ptr } %t91)
  br label %bb12
bb12:
  %t99 = load i1, ptr %l7, !tbaa !21
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [2 x i64] }, ptr %l1
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/mir:Fn", ptr %t105, i32 0, i32 1
  %t108 = load i32, ptr %t107, !tbaa !23
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = load i64, ptr %l4, !tbaa !24
  %t111 = load i1, ptr %l5, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v2, ptr %s5, ptr %t103, { i64, [2 x i64] } %t104, i32 %t108, { i64, ptr } %t109, i64 %t110, i1 %t111, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t119 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t119, ptr %l61
  br label %bb18
bb18:
  %t120 = load %"std/prelude/text:StringBuilder", ptr %l61
  store %"std/prelude/text:StringBuilder" %t120, ptr %l10
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = getelementptr %"compiler/emit:fnEm", ptr %t121, i32 0, i32 28
  %t124 = load i1, ptr %t123, !tbaa !21
  br i1 %t124, label %bb19, label %bb20
bb19:
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t127 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t130 = extractvalue { i64, ptr } %t126, 1
  %t131 = extractvalue { i64, ptr } %t126, 0
  %t132 = add i64 %t128, %t131
  %t133 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = getelementptr i8, ptr %t136, i64 %t128
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = getelementptr i8, ptr %t137, i64 %t131
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t136, 1
  store { i64, ptr } %t140, ptr %l65, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l67, !tbaa !24
  %t146 = load i64, ptr %l67, !tbaa !24
  %t147 = icmp eq i64 %t142, %t146
  br i1 %t147, label %bb21, label %bb22
bb20:
  br label %bb24
bb21:
  %t149 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l67, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  br label %bb23
bb22:
  %t155 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t155, ptr %l8, !tbaa !27
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t156 = load ptr, ptr %l9, !tbaa !29
  %t158 = getelementptr %"compiler/emit:fnEm", ptr %t156, i32 0, i32 18
  %t159 = load i64, ptr %t158, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  br i1 %t161, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l10, ptr %l72, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = sub i64 %t165, 2
  store i64 %t167, ptr %l75, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l76, !tbaa !24
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb27, label %bb28
bb26:
  %t172 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t172)
  br label %bb35
bb27:
  %t175 = load i64, ptr %l75, !tbaa !24
  %t176 = icmp sle i64 0, %t175
  br i1 %t176, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb29:
  %t178 = load i64, ptr %l75, !tbaa !24
  %t179 = load i64, ptr %l76, !tbaa !24
  %t180 = icmp sle i64 %t178, %t179
  br i1 %t180, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb31:
  %t182 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l75, !tbaa !24
  %t185 = getelementptr i8, ptr %t183, i64 0
  %t186 = sub i64 %t184, 0
  %t187 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t185, 1
  %t189 = load ptr, ptr %l72, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t189, { i64, ptr } %t188)
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8de51998cc7658b0_11d2469cc10d3f54)
  unreachable
bb33:
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t193 = getelementptr %"compiler/emit:fnEm", ptr %t191, i32 0, i32 18
  %t194 = load i64, ptr %t193, !tbaa !24
  %t195 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t194)
  %t199 = add i64 %t196, %t198
  %t200 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t195, i64 %t196)
  %t204 = getelementptr i8, ptr %t203, i64 %t196
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t194)
  %t206 = getelementptr i8, ptr %t204, i64 %t198
  call void @olang_textcopy(ptr %t206, ptr %t200, i64 %t201)
  %t207 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t203, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = extractvalue { i64, ptr } %t208, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l10, { i64, ptr } %t215)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d211, i32 0, i32 1) })
  br label %bb37
bb37:
  store ptr %l10, ptr %l89, !tbaa !29
  %t219 = load ptr, ptr %l9, !tbaa !29
  %t221 = getelementptr %"compiler/emit:fnEm", ptr %t219, i32 0, i32 3
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t221)
  store { i64, ptr } %t223, ptr %l92
  br label %bb38
bb38:
  %t224 = load ptr, ptr %l89, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l92, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t224, { i64, ptr } %t225)
  br label %bb39
bb39:
  store ptr %l10, ptr %l93, !tbaa !29
  %t226 = load ptr, ptr %l9, !tbaa !29
  %t228 = getelementptr %"compiler/emit:fnEm", ptr %t226, i32 0, i32 4
  %t230 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t228)
  store { i64, ptr } %t230, ptr %l96
  br label %bb40
bb40:
  %t231 = load ptr, ptr %l93, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l96, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t231, { i64, ptr } %t232)
  br label %bb41
bb41:
  %t233 = load ptr, ptr %l9, !tbaa !29
  %t235 = getelementptr %"compiler/emit:fnEm", ptr %t233, i32 0, i32 18
  %t236 = load i64, ptr %t235, !tbaa !24
  %t238 = icmp sge i64 %t236, 0
  br i1 %t238, label %bb42, label %bb43
bb42:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/emit:Emitter", ptr %t240, i32 0, i32 5
  %t243 = load i1, ptr %t242, !tbaa !21
  store i1 %t243, ptr %l100, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb44
bb44:
  %t245 = load i1, ptr %l100, !tbaa !21
  br i1 %t245, label %bb45, label %bb46
bb45:
  %t246 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %s0, ptr %t246, ptr %l10)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d212, i32 0, i32 1) })
  br label %bb49
bb49:
  store ptr %l10, ptr %l106, !tbaa !29
  %t250 = load ptr, ptr %l9, !tbaa !29
  %t252 = getelementptr %"compiler/emit:fnEm", ptr %t250, i32 0, i32 5
  %t254 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t252)
  store { i64, ptr } %t254, ptr %l109
  br label %bb50
bb50:
  %t255 = load ptr, ptr %l106, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l109, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t255, { i64, ptr } %t256)
  br label %bb51
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) })
  br label %bb52
bb52:
  store ptr %l10, ptr %l111, !tbaa !29
  %t258 = load ptr, ptr %l9, !tbaa !29
  %t260 = getelementptr %"compiler/emit:fnEm", ptr %t258, i32 0, i32 21
  %t262 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t260)
  store { i64, ptr } %t262, ptr %l114
  br label %bb53
bb53:
  %t263 = load ptr, ptr %l111, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t263, { i64, ptr } %t264)
  br label %bb54
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb55
bb55:
  %t266 = load ptr, ptr %l9, !tbaa !29
  %t268 = getelementptr %"compiler/emit:fnEm", ptr %t266, i32 0, i32 28
  %t269 = load i1, ptr %t268, !tbaa !21
  br i1 %t269, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s12
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, [2 x i64] }, ptr %l1
  %t273 = load ptr, ptr %l2, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t275 = load i64, ptr %l4, !tbaa !24
  %t276 = load ptr, ptr %l9, !tbaa !29
  %t278 = getelementptr %"compiler/emit:fnEm", ptr %t276, i32 0, i32 29
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t286 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %s12, ptr %t271, { i64, [2 x i64] } %t272, ptr %t273, { i64, ptr } %t274, i64 %t275, { i64, ptr } %t279, i1 false)
  store { i64, ptr } %t286, ptr %l125
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t287 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t287, ptr %l11, !tbaa !27
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load { i64, [2 x i64] }, ptr %l1
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t291 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t292 = load i64, ptr %l4, !tbaa !24
  %t293 = load ptr, ptr %l9, !tbaa !29
  %t295 = getelementptr %"compiler/emit:fnEm", ptr %t293, i32 0, i32 29
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  %t303 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %s12, ptr %t288, { i64, [2 x i64] } %t289, ptr %t290, { i64, ptr } %t291, i64 %t292, { i64, ptr } %t296, i1 true)
  store { i64, ptr } %t303, ptr %l133
  br label %bb59
bb59:
  %t304 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t304, ptr %l12, !tbaa !27
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t307 = load ptr, ptr %l9, !tbaa !29
  %t309 = getelementptr %"compiler/emit:fnEm", ptr %t307, i32 0, i32 29
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t314 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v2, ptr %v0, ptr %s12, ptr %t305, { i64, ptr } %t306, { i64, ptr } %t310)
  store { i64, ptr } %t314, ptr %l138
  br label %bb60
bb60:
  %t315 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t315, ptr %l13, !tbaa !27
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l139, !tbaa !29
  %t317 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t317, ptr %l140
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/mir:Fn", ptr %t318, i32 0, i32 1
  %t321 = load i32, ptr %t320, !tbaa !23
  store i32 %t321, ptr %l142, !tbaa !23
  %t322 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t322, ptr %l143, !tbaa !27
  %t323 = load i64, ptr %l4, !tbaa !24
  store i64 %t323, ptr %l144, !tbaa !24
  %t324 = load i1, ptr %l5, !tbaa !21
  store i1 %t324, ptr %l145, !tbaa !21
  %t325 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t325, ptr %l146, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t326, ptr %l147, !tbaa !27
  %t328 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s12, ptr %l10)
  store { i64, ptr } %t328, ptr %l149
  br label %bb61
bb61:
  %t329 = load ptr, ptr %l2, !tbaa !29
  %t331 = getelementptr %"compiler/mir:Fn", ptr %t329, i32 0, i32 7
  %t333 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t331)
  store i64 %t333, ptr %l152
  br label %bb62
bb62:
  %t334 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t335 = load i64, ptr %l152, !tbaa !24
  %t336 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %s12, ptr %s12, { i64, ptr } %t334, i64 %t335)
  store { i64, ptr } %t336, ptr %l153
  br label %bb63
bb63:
  %t337 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = add i64 %t340, %t343
  %t345 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t348 = add i64 %t344, %t347
  %t350 = extractvalue { i64, ptr } %t337, 1
  %t351 = extractvalue { i64, ptr } %t337, 0
  %t352 = add i64 %t348, %t351
  %t353 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t352)
  call void @olang_textcopy(ptr %t353, ptr %t339, i64 %t340)
  %t354 = getelementptr i8, ptr %t353, i64 %t340
  call void @olang_textcopy(ptr %t354, ptr %t342, i64 %t343)
  %t355 = getelementptr i8, ptr %t354, i64 %t343
  call void @olang_textcopy(ptr %t355, ptr %t346, i64 %t347)
  %t356 = getelementptr i8, ptr %t355, i64 %t347
  call void @olang_textcopy(ptr %t356, ptr %t350, i64 %t351)
  %t357 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t353, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } %t358, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t366 = load ptr, ptr %l139, !tbaa !29
  %t367 = load { i64, [2 x i64] }, ptr %l140
  %t368 = load i32, ptr %l142, !tbaa !23
  %t369 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t370 = load i64, ptr %l144, !tbaa !24
  %t371 = load i1, ptr %l145, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s12, ptr %t366, { i64, [2 x i64] } %t367, i32 %t368, { i64, ptr } %t369, i64 %t370, i1 %t371, { i64, ptr } %t365)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb65:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l158, !tbaa !29
  %t375 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t375, ptr %l159
  %t376 = load ptr, ptr %l2, !tbaa !29
  %t378 = getelementptr %"compiler/mir:Fn", ptr %t376, i32 0, i32 1
  %t379 = load i32, ptr %t378, !tbaa !23
  store i32 %t379, ptr %l161, !tbaa !23
  %t380 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t380, ptr %l162, !tbaa !27
  %t381 = load i64, ptr %l4, !tbaa !24
  store i64 %t381, ptr %l163, !tbaa !24
  %t382 = load i1, ptr %l5, !tbaa !21
  store i1 %t382, ptr %l164, !tbaa !21
  %t384 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t384, ptr %l166
  br label %bb66
bb66:
  %t385 = load ptr, ptr %l2, !tbaa !29
  %t387 = getelementptr %"compiler/mir:Fn", ptr %t385, i32 0, i32 7
  %t389 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t387)
  store i64 %t389, ptr %l169
  br label %bb67
bb67:
  %t390 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t391 = load i64, ptr %l169, !tbaa !24
  %t392 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %s0, ptr %s0, { i64, ptr } %t390, i64 %t391)
  store { i64, ptr } %t392, ptr %l170
  br label %bb68
bb68:
  %t393 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  %t395 = extractvalue { i64, ptr } %t393, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l158, !tbaa !29
  %t401 = load { i64, [2 x i64] }, ptr %l159
  %t402 = load i32, ptr %l161, !tbaa !23
  %t403 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t404 = load i64, ptr %l163, !tbaa !24
  %t405 = load i1, ptr %l164, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v2, ptr %s0, ptr %t400, { i64, [2 x i64] } %t401, i32 %t402, { i64, ptr } %t403, i64 %t404, i1 %t405, { i64, ptr } %t399)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaggregate(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l41 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca i32
  %l109 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t289 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l20
  br label %bb1
bb1:
  %t14 = load i32, ptr %l20, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l23
  br label %bb2
bb2:
  %t20 = load i32, ptr %l23, !range !{i32 0, i32 33}
  store i32 %t20, ptr %l6
  %t21 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t23 = trunc i64 24 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb4:
  %t26 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t28 = trunc i64 18 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l33
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb7:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l34
  br label %bb8
bb8:
  %t40 = load i32, ptr %l34, !range !{i32 0, i32 6}
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l29, !tbaa !21
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l41
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t57 = load i1, ptr %l41, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t60)
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l47
  br label %bb17
bb17:
  %t73 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t73, ptr %l8, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s1, ptr %s1, ptr %t74, { i64, ptr } %t75, i64 8)
  store { i64, ptr } %t78, ptr %l50
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t80, { i64, ptr } %t81, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d214, i32 0, i32 1) }, { i64, ptr } %t82, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t90 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t89)
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %t87)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t107 = extractvalue { i64, ptr } %t102, 1
  %t108 = extractvalue { i64, ptr } %t102, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t114 = extractvalue { i64, ptr } %t103, 1
  %t115 = extractvalue { i64, ptr } %t103, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t110, i64 %t111)
  %t123 = getelementptr i8, ptr %t122, i64 %t111
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t120, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t136 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t101, { i64, ptr } %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb20
bb20:
  %t137 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l54, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t144, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, { i64, ptr } %t145, { i64, ptr } %t143, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb21
bb21:
  %t147 = load ptr, ptr %l4, !tbaa !29
  store ptr %t147, ptr %l65, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l5, !tbaa !23
  %t152 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l68
  br label %bb22
bb22:
  %t153 = load ptr, ptr %l65, !tbaa !29
  %t154 = load i32, ptr %l68, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l69
  br label %bb23
bb23:
  %t156 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l10, !tbaa !23
  %t164 = load i32, ptr %l10, !tbaa !23
  %t166 = icmp ne i32 %t164, 0
  br i1 %t166, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l75, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l76, !tbaa !23
  %t170 = load ptr, ptr %l4, !tbaa !29
  store ptr %t170, ptr %l77, !tbaa !29
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t172 = load i32, ptr %l10, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l80
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t176 = load ptr, ptr %l77, !tbaa !29
  %t177 = load i32, ptr %l80, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t178, ptr %l81
  br label %bb27
bb27:
  %t179 = load %"compiler/mir:Range", ptr %l3
  %t180 = load ptr, ptr %l75, !tbaa !29
  %t181 = load i32, ptr %l76, !tbaa !23
  %t182 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %s6, ptr %t180, i32 %t181, { i64, ptr } %t182, %"compiler/mir:Range" %t179)
  store { i64, ptr } %t184, ptr %l83
  br label %bb28
bb28:
  %t185 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l10, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l87
  br label %bb29
bb29:
  %t192 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l88, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t199, ptr %l89, !tbaa !27
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t206 = extractvalue { i64, ptr } %t201, 1
  %t207 = extractvalue { i64, ptr } %t201, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t213 = extractvalue { i64, ptr } %t202, 1
  %t214 = extractvalue { i64, ptr } %t202, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t203, i64 %t204)
  %t220 = getelementptr i8, ptr %t219, i64 %t204
  call void @olang_textcopy(ptr %t220, ptr %t206, i64 %t207)
  %t221 = getelementptr i8, ptr %t220, i64 %t207
  call void @olang_textcopy(ptr %t221, ptr %t209, i64 %t210)
  %t222 = getelementptr i8, ptr %t221, i64 %t210
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t219, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t235 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s6, ptr %s6, ptr %t200, { i64, ptr } %t232)
  store { i64, ptr } %t235, ptr %l95
  br label %bb30
bb30:
  %t236 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t243 = load ptr, ptr %l84, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %t243, { i64, ptr } %t244, { i64, ptr } %t245, { i64, ptr } %t242, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t253 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %v1, ptr %v1, ptr %t247, { i64, ptr } %t248, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t253, ptr %l100
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s1)
  %t254 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t254, ptr %rv
  br label %ret
bb34:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l5, !tbaa !23
  %t259 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t259, ptr %l103
  br label %bb35
bb35:
  %t260 = load i32, ptr %l103, !tbaa !23
  store i32 %t260, ptr %l12, !tbaa !23
  %t261 = load i32, ptr %l12, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  br i1 %t265, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l12, !tbaa !23
  %t271 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t267, i32 %t268)
  store i64 %t271, ptr %l109
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t272 = load i64, ptr %l109, !tbaa !24
  store i64 %t272, ptr %l110, !tbaa !24
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t275 = load i32, ptr %l12, !tbaa !23
  %t278 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l113
  br label %bb39
bb39:
  %t279 = load i64, ptr %l110, !tbaa !24
  %t280 = icmp sge i64 %t279, 0
  br i1 %t280, label %bb40, label %bb41
bb40:
  %t282 = load i64, ptr %l110, !tbaa !24
  %t283 = icmp sle i64 %t282, 2305843009213693951
  br i1 %t283, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb42:
  %t285 = load i64, ptr %l110, !tbaa !24
  %t286 = mul i64 %t285, 4
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  %t288 = load i32, ptr %l113, !tbaa !23
  store i64 0, ptr %t289
  br label %fill.290
fill.290:
  %t293 = load i64, ptr %t289
  %t294 = icmp slt i64 %t293, %t285
  br i1 %t294, label %fillb.291, label %filld.292
fillb.291:
  %t295 = getelementptr i32, ptr %t287, i64 %t293
  store i32 %t288, ptr %t295
  %t296 = add i64 %t293, 1
  store i64 %t296, ptr %t289
  br label %fill.290
filld.292:
  %t297 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t287, 1
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l12, !tbaa !23
  %t303 = load %"compiler/mir:Range", ptr %l3
  %t308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %s8, ptr %v1, ptr %t300, i32 %t301, { i64, ptr } %t298, %"compiler/mir:Range" %t303)
  store { i64, ptr } %t308, ptr %l121
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7181fb99348382a8_4bd06d378e143a0c)
  unreachable
bb44:
  call void @__olang_scope_close(ptr %s8)
  %t309 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
bb45:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l122, !tbaa !29
  %t311 = load i32, ptr %l5, !tbaa !23
  store i32 %t311, ptr %l123, !tbaa !23
  %t312 = load ptr, ptr %l4, !tbaa !29
  store ptr %t312, ptr %l124, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l5, !tbaa !23
  %t317 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t313, i32 %t314)
  store i32 %t317, ptr %l127
  br label %bb46
bb46:
  %t318 = load ptr, ptr %l124, !tbaa !29
  %t319 = load i32, ptr %l127, !tbaa !23
  %t320 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t318, i32 %t319)
  store { i64, ptr } %t320, ptr %l128
  br label %bb47
bb47:
  %t321 = load %"compiler/mir:Range", ptr %l3
  %t322 = load ptr, ptr %l122, !tbaa !29
  %t323 = load i32, ptr %l123, !tbaa !23
  %t324 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v0, ptr %v1, ptr %t322, i32 %t323, { i64, ptr } %t324, %"compiler/mir:Range" %t321)
  store { i64, ptr } %t326, ptr %l130
  br label %bb48
bb48:
  %t327 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t327, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [1 x i64] }, ptr %l1
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t1, { i64, [1 x i64] } %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t9, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t20 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v2, ptr %v3, ptr %t14, { i64, ptr } %t15, i64 %t16)
  store { i64, ptr } %t20, ptr %l15
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d225, i32 0, i32 1) })
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l1
  %t32 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s0, ptr %t28, { i64, [1 x i64] } %t29)
  store { i64, ptr } %t32, ptr %l21
  br label %bb11
bb11:
  store { i64, ptr } %a2, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp sgt i64 %t34, 8
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  br label %bb14
bb13:
  store i64 8, ptr %l25, !tbaa !24
  br label %bb14
bb14:
  %t40 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t40, i64 %t41)
  %t63 = getelementptr i8, ptr %t62, i64 %t41
  call void @olang_textcopy(ptr %t63, ptr %t43, i64 %t44)
  %t64 = getelementptr i8, ptr %t63, i64 %t44
  call void @olang_textcopy(ptr %t64, ptr %t46, i64 %t47)
  %t65 = getelementptr i8, ptr %t64, i64 %t47
  call void @olang_textcopy(ptr %t65, ptr %t50, i64 %t51)
  %t66 = getelementptr i8, ptr %t65, i64 %t51
  call void @olang_textcopy(ptr %t66, ptr %t53, i64 %t54)
  %t67 = getelementptr i8, ptr %t66, i64 %t54
  %t68 = call i64 @__olang_fmt_i64(ptr %t67, i64 %t56)
  %t69 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t69, ptr %t59, i64 %t60)
  %t70 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t62, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load ptr, ptr %l18, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t79, { i64, ptr } %t78)
  store { i64, ptr } %t81, ptr %l29
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i32
  %lp7 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb5
bb4:
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l20, !tbaa !23
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t30, i32 %t29)
  store i32 %t34, ptr %l24
  br label %bb7
bb7:
  %t35 = load i32, ptr %l24, !tbaa !23
  store i32 %t35, ptr %l6, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l31
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t47 = load i1, ptr %l31, !tbaa !21
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l34
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t54 = load i1, ptr %l34, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t62, i32 %t63)
  store i64 %t66, ptr %l39
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t68)
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t73, 0
  %t76 = insertvalue { { i64, ptr }, { i64, ptr } } %t74, { i64, ptr } %t72, 1
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb18:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v2, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l45
  br label %bb19
bb19:
  %t84 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v2, ptr %v2, ptr %t91, { i64, ptr } %t90, i64 0)
  store { i64, ptr } %t93, ptr %l47
  br label %bb20
bb20:
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t94, ptr %lp7
  %t95 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t96 = load ptr, ptr %lp7
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l48, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l6, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l51
  br label %bb21
bb21:
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = load ptr, ptr %lp7
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t113 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %v1, ptr %v2, ptr %s1, ptr %t113, { i64, ptr } %t109, { i64, ptr } %t110, { i64, ptr } %t112, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb22
bb22:
  %t117 = load ptr, ptr %lp7
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l55, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t123, ptr %l58
  br label %bb23
bb23:
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t124)
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  %t127 = call i64 @__olang_fmt_i64(ptr %t126, i64 %t124)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t130 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t131 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t130, 0
  %t133 = insertvalue { { i64, ptr }, { i64, ptr } } %t131, { i64, ptr } %t129, 1
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr } } %t133, ptr %rv
  br label %ret
bb24:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t140 = extractvalue { i64, ptr } %t136, 1
  %t141 = extractvalue { i64, ptr } %t136, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = getelementptr i8, ptr %t147, i64 %t141
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t160 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t135, { i64, ptr } %t157)
  store { i64, ptr } %t160, ptr %l65
  br label %bb25
bb25:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t163 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t166 = extractvalue { i64, ptr } %t162, 1
  %t167 = extractvalue { i64, ptr } %t162, 0
  %t168 = add i64 %t164, %t167
  %t169 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t166, i64 %t167)
  %t174 = getelementptr i8, ptr %t173, i64 %t167
  call void @olang_textcopy(ptr %t174, ptr %t169, i64 %t170)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t186 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t161, { i64, ptr } %t183)
  store { i64, ptr } %t186, ptr %l70
  br label %bb26
bb26:
  %t187 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t188 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t187, 0
  %t189 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t190 = insertvalue { { i64, ptr }, { i64, ptr } } %t188, { i64, ptr } %t189, 1
  store { { i64, ptr }, { i64, ptr } } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t16 = trunc i64 24 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb4
bb3:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l17
  br label %bb5
bb4:
  %t29 = load i32, ptr %l14, !tbaa !23
  store i32 %t29, ptr %l11, !tbaa !23
  br label %bb6
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l11, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l11, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i8
  %l13 = alloca %"compiler/mir:Range"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i64
  %l28 = alloca { i64, [1 x i64] }
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca i32
  %l40 = alloca i32
  %l66 = alloca i8
  %l70 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/text:StringBuilder"
  %l116 = alloca i32
  %l119 = alloca i32
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i32
  %l155 = alloca i32
  %l156 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l169 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 19
  %t9 = sext i32 %a2 to i64
  %t12 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t6, i64 %t9)
  store { i64, [1 x i64] } %t12, ptr %l28
  br label %bb1
bb1:
  %t13 = load { i64, [1 x i64] }, ptr %l28
  store { i64, [1 x i64] } %t13, ptr %l3
  %t14 = load { i64, [1 x i64] }, ptr %l3
  %t16 = extractvalue { i64, [1 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t20 = getelementptr { %"compiler/mir:Range" }, ptr %t19, i32 0, i32 0
  %t21 = load %"compiler/mir:Range", ptr %t20
  store %"compiler/mir:Range" %t21, ptr %l4
  br label %bb4
bb3:
  br label %bb36
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t23, ptr %l32
  br label %bb5
bb5:
  %t24 = load %"std/prelude/text:StringBuilder", ptr %l32
  store %"std/prelude/text:StringBuilder" %t24, ptr %l5
  store i32 0, ptr %l6, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  store i32 1, ptr %l8, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr %l8, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l37, !tbaa !23
  br label %bb11
bb8:
  %t38 = load i32, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l8, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l8, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l40, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l40, !tbaa !23
  br label %bb10
bb10:
  %t54 = load i32, ptr %l40, !tbaa !23
  store i32 %t54, ptr %l37, !tbaa !23
  br label %bb11
bb11:
  %t55 = load i32, ptr %l37, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  store i32 0, ptr %l10, !tbaa !23
  br label %bb12
bb12:
  %t56 = load i32, ptr %l10, !tbaa !23
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  br label %bb34
bb14:
  br label %bb15
bb15:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr %l10, !tbaa !23
  %t66 = load i32, ptr %l8, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:fnEm", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 21
  %t80 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = sext i32 %t72 to i64
  %t89 = add i64 %t83, %t86
  %t92 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t79, i64 %t89)
  store i8 %t92, ptr %l66
  br label %bb16
bb16:
  %t93 = load i8, ptr %l66, !tbaa !22
  store i8 %t93, ptr %l12, !tbaa !22
  %t94 = load i8, ptr %l12, !tbaa !22
  %t97 = icmp eq i8 %t94, 34
  br i1 %t97, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb19
bb18:
  %t99 = load i8, ptr %l12, !tbaa !22
  %t102 = icmp eq i8 %t99, 92
  store i1 %t102, ptr %l70, !tbaa !21
  br label %bb19
bb19:
  %t104 = load i1, ptr %l70, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb22
bb21:
  %t105 = load i8, ptr %l12, !tbaa !22
  %t107 = icmp ult i8 %t105, 32
  store i1 %t107, ptr %l74, !tbaa !21
  br label %bb22
bb22:
  %t109 = load i1, ptr %l74, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb25
bb24:
  %t110 = load i8, ptr %l12, !tbaa !22
  %t112 = icmp ugt i8 %t110, 126
  store i1 %t112, ptr %l77, !tbaa !21
  br label %bb25
bb25:
  %t114 = load i1, ptr %l77, !tbaa !21
  br i1 %t114, label %bb26, label %bb27
bb26:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l5, i8 92)
  br label %bb28
bb27:
  %t116 = load i8, ptr %l12, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l5, i8 %t116)
  br label %bb31
bb28:
  %t120 = load i8, ptr %l12, !tbaa !22
  %t122 = lshr i8 %t120, 4
  %t124 = zext i8 %t122 to i64
  %t126 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l5, i8 %t129)
  br label %bb29
bb29:
  %t132 = load i8, ptr %l12, !tbaa !22
  %t134 = and i8 %t132, 15
  %t136 = zext i8 %t134 to i64
  %t138 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i8, ptr %t139, i64 %t136
  %t141 = load i8, ptr %t140, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l5, i8 %t141)
  br label %bb30
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t144 = load i32, ptr %l10, !tbaa !23
  %t146 = add i32 %t144, 1
  store i32 %t146, ptr %l10, !tbaa !23
  br label %bb12
bb34:
  %t148 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t149 = load i32, ptr %t148, !tbaa !23
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t153 = sext i32 %t149 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t150, i64 %t151)
  %t160 = getelementptr i8, ptr %t159, i64 %t151
  %t161 = call i64 @__olang_fmt_i64(ptr %t160, i64 %t153)
  %t162 = getelementptr i8, ptr %t160, i64 %t154
  call void @olang_textcopy(ptr %t162, ptr %t156, i64 %t157)
  %t163 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t159, 1
  store { i64, ptr } %t164, ptr %l97, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %s1, ptr %l5)
  store { i64, ptr } %t166, ptr %l99
  br label %bb35
bb35:
  %t167 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t169 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t167, i64 %t168)
  %t177 = getelementptr i8, ptr %t176, i64 %t168
  call void @olang_textcopy(ptr %t177, ptr %t170, i64 %t171)
  %t178 = getelementptr i8, ptr %t177, i64 %t171
  call void @olang_textcopy(ptr %t178, ptr %t173, i64 %t174)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t176, 1
  %t181 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t182 = load i32, ptr %t181, !tbaa !23
  %t184 = sext i32 %t182 to i64
  %t185 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t186 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t185, 0
  %t188 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t186, { i64, ptr } %t180, 1
  %t190 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t188, i64 %t184, 2
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr }, i64 } %t190, ptr %rv
  br label %ret
bb36:
  %t192 = load { i64, [1 x i64] }, ptr %l3
  %t194 = extractvalue { i64, [1 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 2
  br i1 %t195, label %bb37, label %bb38
bb37:
  %t197 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t198 = getelementptr { %"compiler/mir:Range" }, ptr %t197, i32 0, i32 0
  %t199 = load %"compiler/mir:Range", ptr %t198
  store %"compiler/mir:Range" %t199, ptr %l13
  br label %bb39
bb38:
  br label %bb65
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s9, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l109
  br label %bb40
bb40:
  %t206 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t206, ptr %l14, !tbaa !27
  %t207 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t207, ptr %l110
  br label %bb41
bb41:
  %t208 = load %"std/prelude/text:StringBuilder", ptr %l110
  store %"std/prelude/text:StringBuilder" %t208, ptr %l15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l15, i8 91)
  br label %bb42
bb42:
  store i32 0, ptr %l16, !tbaa !23
  %t210 = getelementptr %"compiler/mir:Range", ptr %l13, i32 0, i32 1
  %t211 = load i32, ptr %t210, !tbaa !23
  store i32 %t211, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t213 = load i32, ptr %l17, !tbaa !23
  %t214 = load i32, ptr %l16, !tbaa !23
  %t217 = icmp sgt i32 %t213, %t214
  br i1 %t217, label %bb43, label %bb44
bb43:
  %t219 = load i32, ptr %l18, !tbaa !23
  %t221 = icmp sgt i32 %t219, 0
  br i1 %t221, label %bb45, label %bb46
bb44:
  store i32 0, ptr %l116, !tbaa !23
  br label %bb48
bb45:
  %t223 = load i32, ptr %l17, !tbaa !23
  %t224 = load i32, ptr %l16, !tbaa !23
  %t227 = sub i32 %t223, %t224
  %t228 = load i32, ptr %l18, !tbaa !23
  %t231 = add i32 %t227, %t228
  %t233 = sub i32 %t231, 1
  %t234 = load i32, ptr %l18, !tbaa !23
  %t237 = sdiv i32 %t233, %t234
  store i32 %t237, ptr %l119, !tbaa !23
  br label %bb47
bb46:
  store i32 0, ptr %l119, !tbaa !23
  br label %bb47
bb47:
  %t239 = load i32, ptr %l119, !tbaa !23
  store i32 %t239, ptr %l116, !tbaa !23
  br label %bb48
bb48:
  %t240 = load i32, ptr %l116, !tbaa !23
  store i32 %t240, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t241 = load i32, ptr %l20, !tbaa !23
  %t242 = load i32, ptr %l19, !tbaa !23
  %t245 = icmp slt i32 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb51:
  br label %bb52
bb52:
  %t249 = load i32, ptr %l16, !tbaa !23
  %t250 = load i32, ptr %l20, !tbaa !23
  %t251 = load i32, ptr %l18, !tbaa !23
  %t254 = mul i32 %t250, %t251
  %t257 = add i32 %t249, %t254
  store i32 %t257, ptr %l21, !tbaa !23
  %t259 = load i32, ptr %l21, !tbaa !23
  %t261 = icmp sgt i32 %t259, 0
  br i1 %t261, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s12, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d237, i32 0, i32 1) })
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb56
bb56:
  %t264 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = extractvalue { i64, ptr } %t264, 0
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t266, i64 %t267)
  %t272 = getelementptr i8, ptr %t271, i64 %t267
  call void @olang_textcopy(ptr %t272, ptr %t268, i64 %t269)
  %t273 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t271, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t277 = extractvalue { i64, ptr } %t274, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s11, ptr %l15, { i64, ptr } %t281)
  br label %bb57
bb57:
  store ptr %l15, ptr %l144, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l145, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  store i32 %t285, ptr %l146, !tbaa !23
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/emit:fnEm", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/mir:Fn", ptr %t289, i32 0, i32 20
  %t292 = getelementptr %"compiler/mir:Range", ptr %l13, i32 0, i32 0
  %t293 = load i32, ptr %t292, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t296 = load i32, ptr %l21, !tbaa !23
  %t298 = sext i32 %t296 to i64
  %t301 = add i64 %t295, %t298
  %t304 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t291, i64 %t301)
  store i32 %t304, ptr %l155
  br label %bb58
bb58:
  %t305 = load ptr, ptr %l145, !tbaa !29
  %t306 = load i32, ptr %l146, !tbaa !23
  %t307 = load i32, ptr %l155, !tbaa !23
  %t308 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %s11, ptr %t305, i32 %t306, i32 %t307)
  store { i64, ptr } %t308, ptr %l156
  br label %bb59
bb59:
  %t309 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = extractvalue { i64, ptr } %t309, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %l144, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s11, ptr %t316, { i64, ptr } %t315)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb61:
  %t318 = load i32, ptr %l20, !tbaa !23
  %t320 = add i32 %t318, 1
  store i32 %t320, ptr %l20, !tbaa !23
  br label %bb49
bb62:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l15, i8 93)
  br label %bb63
bb63:
  %t323 = getelementptr %"compiler/mir:Range", ptr %l13, i32 0, i32 1
  %t324 = load i32, ptr %t323, !tbaa !23
  %t325 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t329 = sext i32 %t324 to i64
  %t330 = call i64 @__olang_fmt_i64(ptr null, i64 %t329)
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t336 = extractvalue { i64, ptr } %t325, 1
  %t337 = extractvalue { i64, ptr } %t325, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t326, i64 %t327)
  %t343 = getelementptr i8, ptr %t342, i64 %t327
  %t344 = call i64 @__olang_fmt_i64(ptr %t343, i64 %t329)
  %t345 = getelementptr i8, ptr %t343, i64 %t330
  call void @olang_textcopy(ptr %t345, ptr %t332, i64 %t333)
  %t346 = getelementptr i8, ptr %t345, i64 %t333
  call void @olang_textcopy(ptr %t346, ptr %t336, i64 %t337)
  %t347 = getelementptr i8, ptr %t346, i64 %t337
  call void @olang_textcopy(ptr %t347, ptr %t339, i64 %t340)
  %t348 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t342, 1
  store { i64, ptr } %t349, ptr %l163, !tbaa !27
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %v1, ptr %l15)
  store { i64, ptr } %t351, ptr %l165
  br label %bb64
bb64:
  %t352 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t353 = getelementptr %"compiler/mir:Range", ptr %l13, i32 0, i32 1
  %t354 = load i32, ptr %t353, !tbaa !23
  %t356 = sext i32 %t354 to i64
  %t357 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t358 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t357, 0
  %t360 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t358, { i64, ptr } %t352, 1
  %t362 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t360, i64 %t356, 2
  store { { i64, ptr }, { i64, ptr }, i64 } %t362, ptr %l169
  %t363 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l169, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  store { i64, ptr } %t364, ptr %l170, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 0
  store i64 %t366, ptr %l171, !tbaa !24
  %t367 = load i64, ptr %l171, !tbaa !24
  %t368 = mul i64 %t367, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  %t370 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  store { i64, ptr } %t371, ptr %l172, !tbaa !27
  %t372 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = load i64, ptr %l171, !tbaa !24
  %t377 = mul i64 %t376, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t373, ptr %t375, i64 %t377, i1 false)
  %t378 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t379 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l169, i32 0, i32 1
  store { i64, ptr } %t378, ptr %t379, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  %t380 = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %l169
  store { { i64, ptr }, { i64, ptr }, i64 } %t380, ptr %rv
  br label %ret
bb65:
  %t381 = load { i64, [1 x i64] }, ptr %l3
  %t383 = extractvalue { i64, [1 x i64] } %t381, 0
  %t384 = icmp eq i64 %t383, 0
  br i1 %t384, label %bb66, label %bb67
bb66:
  %t386 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t387 = getelementptr { i64 }, ptr %t386, i32 0, i32 0
  %t388 = load i64, ptr %t387
  store i64 %t388, ptr %l22, !tbaa !24
  br label %bb68
bb67:
  br label %bb71
bb68:
  store %olang.scope zeroinitializer, ptr %s16
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s16, ptr %t390, i32 %t391)
  store { i64, ptr } %t394, ptr %l178
  br label %bb69
bb69:
  %t395 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t396, i64 %t397)
  %t399 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  store { i64, ptr } %t400, ptr %l179, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/emit:fnEm", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t405 = load i32, ptr %l1, !tbaa !23
  %t406 = load i64, ptr %l22, !tbaa !24
  %t410 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %t404, i32 %t405, i64 %t406)
  store { i64, ptr } %t410, ptr %l184
  br label %bb70
bb70:
  %t411 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t412 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t411, 0
  %t413 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t414 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t412, { i64, ptr } %t413, 1
  %t415 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t414, i64 1, 2
  call void @__olang_scope_close(ptr %s16)
  store { { i64, ptr }, { i64, ptr }, i64 } %t415, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_617f1f302e56ab61_28fb076f83c3eed5)
  unreachable
ret:
  %rr = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportNamed(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, [21 x i64] }
  %l16 = alloca %"compiler/mir:Lvalue"
  %l17 = alloca { i64, [15 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l62 = alloca ptr
  %l65 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, [21 x i64] }
  %l73 = alloca { i64, [21 x i64] }
  %l79 = alloca i1
  %l83 = alloca i1
  %l98 = alloca ptr
  %l105 = alloca ptr
  %l108 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 -1, ptr %l2, !tbaa !23
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb13
bb3:
  %t10 = getelementptr %"compiler/mir:Lvalue", ptr %l3, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l4
  %t13 = load { i64, [2 x i64] }, ptr %l4
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l5, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757)
  unreachable
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_dde810cb192bdc32_ece13dbcfe1403b6)
  unreachable
bb18:
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/mir:Fn", ptr %t27, i32 0, i32 9
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l33
  br label %bb19
bb19:
  %t32 = load i64, ptr %l33, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb20, label %bb21
bb20:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb25
bb22:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l40, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb24
bb24:
  %t59 = load i64, ptr %l40, !tbaa !24
  store i64 %t59, ptr %l37, !tbaa !24
  br label %bb25
bb25:
  %t60 = load i64, ptr %l37, !tbaa !24
  store i64 %t60, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb27, label %bb28
bb27:
  br label %bb87
bb28:
  br label %bb29
bb29:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:fnEm", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/mir:Fn", ptr %t82, i32 0, i32 9
  %t88 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t84, i64 %t77)
  store ptr %t88, ptr %l62
  br label %bb30
bb30:
  %t89 = load ptr, ptr %l62, !tbaa !29
  %t92 = getelementptr %"compiler/mir:BasicBlock", ptr %t89, i32 0, i32 0
  store ptr %t92, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t94 = load i64, ptr %l14, !tbaa !24
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load ptr, ptr %l13, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l67
  br label %bb32
bb32:
  %t98 = load i64, ptr %l65, !tbaa !24
  %t99 = load i64, ptr %l67, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb33, label %bb34
bb33:
  br label %bb85
bb34:
  br label %bb35
bb35:
  %t104 = load ptr, ptr %l13, !tbaa !29
  %t105 = load i64, ptr %l14, !tbaa !24
  %t108 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t104, i64 %t105)
  store { i64, [21 x i64] } %t108, ptr %l72
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l72, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %l15, i64 176, i1 false)
  %t109 = load { i64, [21 x i64] }, ptr %l73
  %t110 = extractvalue { i64, [21 x i64] } %t109, 0
  %t111 = icmp eq i64 %t110, 0
  br i1 %t111, label %bb37, label %bb38
bb37:
  %t113 = getelementptr { i64, [21 x i64] }, ptr %l15, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t113, i32 0, i32 1
  %t115 = load %"compiler/mir:Lvalue", ptr %t114
  store %"compiler/mir:Lvalue" %t115, ptr %l16
  %t117 = getelementptr { i64, [21 x i64] }, ptr %l15, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t117, i32 0, i32 2
  %t119 = load { i64, [15 x i64] }, ptr %t118
  store { i64, [15 x i64] } %t119, ptr %l17
  br label %bb39
bb38:
  br label %bb78
bb39:
  %t121 = getelementptr %"compiler/mir:Lvalue", ptr %l16, i32 0, i32 1
  %t122 = getelementptr %"compiler/mir:Range", ptr %t121, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = icmp ne i32 %t123, 0
  br i1 %t125, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb43
bb41:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/mir:Lvalue", ptr %l16
  %t129 = load i32, ptr %l2, !tbaa !23
  %t133 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t127, %"compiler/mir:Lvalue" %t128, i32 %t129)
  store i1 %t133, ptr %l83
  br label %bb42
bb42:
  %t134 = load i1, ptr %l83, !tbaa !21
  %t135 = xor i1 %t134, true
  store i1 %t135, ptr %l79, !tbaa !21
  br label %bb43
bb43:
  %t137 = load i1, ptr %l79, !tbaa !21
  br i1 %t137, label %bb44, label %bb45
bb44:
  br label %bb84
bb45:
  br label %bb46
bb46:
  %t138 = load { i64, [15 x i64] }, ptr %l17
  %t140 = extractvalue { i64, [15 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 10
  br i1 %t141, label %bb47, label %bb48
bb47:
  %t143 = getelementptr { i64, [15 x i64] }, ptr %l17, i32 0, i32 1
  %t144 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t143, i32 0, i32 0
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l18
  br label %bb49
bb48:
  br label %bb72
bb49:
  %t147 = load { i64, [2 x i64] }, ptr %l18
  %t149 = extractvalue { i64, [2 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 0
  br i1 %t150, label %bb50, label %bb51
bb50:
  %t152 = getelementptr { i64, [2 x i64] }, ptr %l18, i32 0, i32 1
  %t153 = getelementptr { i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l19, !tbaa !23
  br label %bb52
bb51:
  br label %bb66
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/emit:fnEm", ptr %t156, i32 0, i32 0
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/emit:Emitter", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/lower:Lowerer", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = load i32, ptr %l19, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t172 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t165, i64 %t169)
  store ptr %t172, ptr %l98
  br label %bb53
bb53:
  %t173 = load ptr, ptr %l98, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Body", ptr %t173, i32 0, i32 1
  %t176 = load { i64, [2 x i64] }, ptr %t175
  store { i64, [2 x i64] } %t176, ptr %l20
  %t178 = load { i64, [2 x i64] }, ptr %l20
  %t180 = extractvalue { i64, [2 x i64] } %t178, 0
  %t181 = icmp eq i64 %t180, 0
  br i1 %t181, label %bb54, label %bb55
bb54:
  %t183 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t184 = getelementptr { i64 }, ptr %t183, i32 0, i32 0
  %t185 = load i64, ptr %t184
  store i64 %t185, ptr %l21, !tbaa !24
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/emit:fnEm", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  store ptr %t190, ptr %l105, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/emit:fnEm", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/emit:Emitter", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l108, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/emit:fnEm", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load i64, ptr %l21, !tbaa !24
  %t208 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t204, i64 %t205)
  store i64 %t208, ptr %l113
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l108, !tbaa !29
  %t210 = load i64, ptr %l113, !tbaa !24
  %t211 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t209, i64 %t210)
  store ptr %t211, ptr %l114
  br label %bb58
bb58:
  %t212 = load ptr, ptr %l114, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Func", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %t214, !tbaa !23
  %t216 = load ptr, ptr %l105, !tbaa !29
  %t218 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t216, i32 %t215)
  store { i64, ptr } %t218, ptr %l117
  br label %bb59
bb59:
  %t219 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t220, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t224, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_c0167577194c5569_3f3b475069b70a4d)
  unreachable
bb65:
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c)
  unreachable
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_d4e74db3ab2eecf_2f1d311192c757bb)
  unreachable
bb77:
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a)
  unreachable
bb83:
  br label %bb84
bb84:
  %t226 = load i64, ptr %l14, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l14, !tbaa !24
  br label %bb31
bb85:
  br label %bb86
bb86:
  %t230 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l10, !tbaa !24
  br label %bb26
bb87:
  %t234 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s0, ptr %t234, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d242, i32 0, i32 1) })
  br label %bb88
bb88:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d243, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t236, ptr %l125, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l126, !tbaa !24
  %t239 = load i64, ptr %l126, !tbaa !24
  %t240 = mul i64 %t239, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l127, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l126, !tbaa !24
  %t249 = mul i64 %t248, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t250, ptr %l125, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t251 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t251, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, ptr }, i32 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { { i64, ptr }, i32 }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l47 = alloca %"compiler/mir:Lvalue"
  %l48 = alloca i32
  %l49 = alloca { { i64, ptr }, i32 }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i32
  %l80 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca { i64, [4 x i64] }
  %l122 = alloca ptr
  %l125 = alloca { i64, [4 x i64] }
  %l127 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, [4 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { { i64, ptr }, i32 }
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l215 = alloca i64
  %l218 = alloca i64
  %l236 = alloca ptr
  %l237 = alloca ptr
  %l241 = alloca { i64, [4 x i64] }
  %l243 = alloca { i64, ptr }
  %l249 = alloca { { i64, ptr }, i32 }
  %l255 = alloca i64
  %l258 = alloca i64
  %l282 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l301 = alloca i32
  %l302 = alloca i32
  %l306 = alloca i1
  %l310 = alloca i1
  %l315 = alloca ptr
  %l318 = alloca i32
  %l319 = alloca i32
  %l322 = alloca i1
  %l323 = alloca ptr
  %l326 = alloca i32
  %l327 = alloca i1
  %l332 = alloca i64
  %l334 = alloca i1
  %l337 = alloca i32
  %l343 = alloca { { i64, ptr }, i32 }
  %l347 = alloca { { i64, ptr }, i32 }
  %l351 = alloca ptr
  %l352 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l356 = alloca i64
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  %t18 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t19 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t18, i32 0, i32 2
  %t20 = load %"compiler/mir:Range", ptr %t19
  store %"compiler/mir:Range" %t20, ptr %l6
  br label %bb3
bb2:
  br label %bb98
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l5, !tbaa !23
  %t26 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l62
  br label %bb4
bb4:
  %t27 = load i32, ptr %l62, !tbaa !23
  store i32 %t27, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l7, !tbaa !23
  %t38 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l69
  br label %bb7
bb7:
  %t39 = load i1, ptr %l69, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l66, !tbaa !21
  br label %bb8
bb8:
  %t42 = load i1, ptr %l66, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb12
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l74
  br label %bb11
bb11:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l74, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  store i1 %t51, ptr %l71, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l71, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l80
  br label %bb16
bb16:
  %t60 = load i64, ptr %l80, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sle i64 %t61, 16
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l86
  br label %bb20
bb20:
  %t71 = load i32, ptr %l86, !tbaa !23
  store i32 %t71, ptr %l9, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l89
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l92
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb28
bb25:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l100, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l100, !tbaa !24
  store i64 %t112, ptr %l97, !tbaa !24
  br label %bb28
bb28:
  %t113 = load i64, ptr %l97, !tbaa !24
  store i64 %t113, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/mir:Range", ptr %l6
  %t138 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t132, %"compiler/mir:Range" %t133, i64 %t130)
  store { i64, [4 x i64] } %t138, ptr %l121
  br label %bb33
bb33:
  store ptr %l121, ptr %l122, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/mir:Range", ptr %l6
  %t143 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t139, %"compiler/mir:Range" %t140, i64 0)
  store { i64, [4 x i64] } %t143, ptr %l125
  br label %bb34
bb34:
  %t144 = load ptr, ptr %l122, !tbaa !29
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %t144, ptr %l125)
  store i1 %t146, ptr %l127
  br label %bb35
bb35:
  %t147 = load i1, ptr %l127, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l17, !tbaa !24
  br label %bb29
bb40:
  %t154 = load i1, ptr %l12, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l132, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr %l6
  %t161 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t157, %"compiler/mir:Range" %t158, i64 0)
  store { i64, [4 x i64] } %t161, ptr %l135
  br label %bb43
bb42:
  br label %bb65
bb43:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l132, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l135
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s8, ptr %t163, { i64, [4 x i64] } %t164, i32 %t162)
  store { i64, ptr } %t166, ptr %l137
  br label %bb44
bb44:
  %t167 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t167, ptr %l19, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"compiler/mir:Lvalue", ptr %l1
  %t172 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s8, ptr %t168, %"compiler/mir:Lvalue" %t169)
  store { { i64, ptr }, i32 } %t172, ptr %l140
  br label %bb45
bb45:
  %t173 = load { { i64, ptr }, i32 }, ptr %l140
  store { { i64, ptr }, i32 } %t173, ptr %l20
  %t174 = getelementptr { { i64, ptr }, i32 }, ptr %l20, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l21, !tbaa !27
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t177, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d244, i32 0, i32 1) })
  store { i64, ptr } %t179, ptr %l143
  br label %bb46
bb46:
  %t180 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t180, ptr %l22, !tbaa !27
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t181, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d245, i32 0, i32 1) })
  store { i64, ptr } %t183, ptr %l145
  br label %bb47
bb47:
  %t184 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t184, ptr %l23, !tbaa !27
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t185, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d246, i32 0, i32 1) })
  store { i64, ptr } %t187, ptr %l147
  br label %bb48
bb48:
  %t188 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t188, ptr %l24, !tbaa !27
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t189, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) })
  store { i64, ptr } %t191, ptr %l149
  br label %bb49
bb49:
  %t192 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t192, ptr %l25, !tbaa !27
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t195 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t198 = extractvalue { i64, ptr } %t194, 1
  %t199 = extractvalue { i64, ptr } %t194, 0
  %t200 = add i64 %t196, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t195, i64 %t196)
  %t202 = getelementptr i8, ptr %t201, i64 %t196
  call void @olang_textcopy(ptr %t202, ptr %t198, i64 %t199)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t201, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t193, { i64, ptr } %t211)
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t214, { i64, ptr } %t215)
  br label %bb51
bb51:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t220 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t223 = extractvalue { i64, ptr } %t219, 1
  %t224 = extractvalue { i64, ptr } %t219, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t220, i64 %t221)
  %t227 = getelementptr i8, ptr %t226, i64 %t221
  call void @olang_textcopy(ptr %t227, ptr %t223, i64 %t224)
  %t228 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t218, { i64, ptr } %t236)
  br label %bb52
bb52:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t239, { i64, ptr } %t240)
  br label %bb53
bb53:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t243)
  store { i64, ptr } %t245, ptr %l163
  br label %bb54
bb54:
  %t246 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t246, ptr %l26, !tbaa !27
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t247)
  store { i64, ptr } %t249, ptr %l165
  br label %bb55
bb55:
  %t250 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t250, ptr %l27, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t252, 1
  %t258 = extractvalue { i64, ptr } %t252, 0
  %t259 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t263 = extractvalue { i64, ptr } %t253, 1
  %t264 = extractvalue { i64, ptr } %t253, 0
  %t265 = add i64 %t261, %t264
  %t266 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t270 = extractvalue { i64, ptr } %t254, 1
  %t271 = extractvalue { i64, ptr } %t254, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t277 = extractvalue { i64, ptr } %t255, 1
  %t278 = extractvalue { i64, ptr } %t255, 0
  %t279 = add i64 %t275, %t278
  %t280 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t257, i64 %t258)
  %t284 = getelementptr i8, ptr %t283, i64 %t258
  call void @olang_textcopy(ptr %t284, ptr %t259, i64 %t260)
  %t285 = getelementptr i8, ptr %t284, i64 %t260
  call void @olang_textcopy(ptr %t285, ptr %t263, i64 %t264)
  %t286 = getelementptr i8, ptr %t285, i64 %t264
  call void @olang_textcopy(ptr %t286, ptr %t266, i64 %t267)
  %t287 = getelementptr i8, ptr %t286, i64 %t267
  call void @olang_textcopy(ptr %t287, ptr %t270, i64 %t271)
  %t288 = getelementptr i8, ptr %t287, i64 %t271
  call void @olang_textcopy(ptr %t288, ptr %t273, i64 %t274)
  %t289 = getelementptr i8, ptr %t288, i64 %t274
  call void @olang_textcopy(ptr %t289, ptr %t277, i64 %t278)
  %t290 = getelementptr i8, ptr %t289, i64 %t278
  call void @olang_textcopy(ptr %t290, ptr %t280, i64 %t281)
  %t291 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t283, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t251, { i64, ptr } %t299)
  br label %bb56
bb56:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t304 = load i64, ptr %l8, !tbaa !24
  %t305 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t308 = extractvalue { i64, ptr } %t303, 1
  %t309 = extractvalue { i64, ptr } %t303, 0
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t315 = call i64 @__olang_fmt_i64(ptr null, i64 %t304)
  %t316 = add i64 %t313, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t305, i64 %t306)
  %t318 = getelementptr i8, ptr %t317, i64 %t306
  call void @olang_textcopy(ptr %t318, ptr %t308, i64 %t309)
  %t319 = getelementptr i8, ptr %t318, i64 %t309
  call void @olang_textcopy(ptr %t319, ptr %t311, i64 %t312)
  %t320 = getelementptr i8, ptr %t319, i64 %t312
  %t321 = call i64 @__olang_fmt_i64(ptr %t320, i64 %t304)
  %t322 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t317, 1
  %t325 = extractvalue { i64, ptr } %t323, 0
  %t326 = extractvalue { i64, ptr } %t323, 1
  %t327 = mul i64 %t325, 1
  %t328 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t327)
  call void @llvm.memcpy.p0.p0.i64(ptr %t328, ptr %t326, i64 %t327, i1 false)
  %t329 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t302, { i64, ptr } %t330)
  store { i64, ptr } %t333, ptr %l178
  br label %bb57
bb57:
  %t334 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t339 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t342 = extractvalue { i64, ptr } %t334, 1
  %t343 = extractvalue { i64, ptr } %t334, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t349 = extractvalue { i64, ptr } %t337, 1
  %t350 = extractvalue { i64, ptr } %t337, 0
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t356 = extractvalue { i64, ptr } %t338, 1
  %t357 = extractvalue { i64, ptr } %t338, 0
  %t358 = add i64 %t354, %t357
  %t359 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t358)
  call void @olang_textcopy(ptr %t359, ptr %t339, i64 %t340)
  %t360 = getelementptr i8, ptr %t359, i64 %t340
  call void @olang_textcopy(ptr %t360, ptr %t342, i64 %t343)
  %t361 = getelementptr i8, ptr %t360, i64 %t343
  call void @olang_textcopy(ptr %t361, ptr %t345, i64 %t346)
  %t362 = getelementptr i8, ptr %t361, i64 %t346
  call void @olang_textcopy(ptr %t362, ptr %t349, i64 %t350)
  %t363 = getelementptr i8, ptr %t362, i64 %t350
  call void @olang_textcopy(ptr %t363, ptr %t352, i64 %t353)
  %t364 = getelementptr i8, ptr %t363, i64 %t353
  call void @olang_textcopy(ptr %t364, ptr %t356, i64 %t357)
  %t365 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t359, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = extractvalue { i64, ptr } %t366, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t335, { i64, ptr } %t373)
  br label %bb58
bb58:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t376, { i64, ptr } %t377)
  br label %bb59
bb59:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t382 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t383 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t384 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t387 = extractvalue { i64, ptr } %t381, 1
  %t388 = extractvalue { i64, ptr } %t381, 0
  %t389 = add i64 %t385, %t388
  %t390 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t392 = add i64 %t389, %t391
  %t394 = extractvalue { i64, ptr } %t382, 1
  %t395 = extractvalue { i64, ptr } %t382, 0
  %t396 = add i64 %t392, %t395
  %t397 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t401 = extractvalue { i64, ptr } %t383, 1
  %t402 = extractvalue { i64, ptr } %t383, 0
  %t403 = add i64 %t399, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t384, i64 %t385)
  %t405 = getelementptr i8, ptr %t404, i64 %t385
  call void @olang_textcopy(ptr %t405, ptr %t387, i64 %t388)
  %t406 = getelementptr i8, ptr %t405, i64 %t388
  call void @olang_textcopy(ptr %t406, ptr %t390, i64 %t391)
  %t407 = getelementptr i8, ptr %t406, i64 %t391
  call void @olang_textcopy(ptr %t407, ptr %t394, i64 %t395)
  %t408 = getelementptr i8, ptr %t407, i64 %t395
  call void @olang_textcopy(ptr %t408, ptr %t397, i64 %t398)
  %t409 = getelementptr i8, ptr %t408, i64 %t398
  call void @olang_textcopy(ptr %t409, ptr %t401, i64 %t402)
  %t410 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t404, 1
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t414 = extractvalue { i64, ptr } %t411, 1
  %t415 = mul i64 %t413, 1
  %t416 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t415)
  call void @llvm.memcpy.p0.p0.i64(ptr %t416, ptr %t414, i64 %t415, i1 false)
  %t417 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t416, 1
  %t421 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t380, { i64, ptr } %t418)
  store { i64, ptr } %t421, ptr %l193
  br label %bb60
bb60:
  %t422 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s8, ptr %s8, ptr %s8, ptr %t423, { i64, ptr } %t424, { i64, ptr } %t425, { i64, ptr } %t422, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb61
bb61:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t433 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t432, 1
  %t436 = extractvalue { i64, ptr } %t432, 0
  %t437 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t439 = add i64 %t436, %t438
  %t441 = extractvalue { i64, ptr } %t433, 1
  %t442 = extractvalue { i64, ptr } %t433, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t447 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t446)
  call void @olang_textcopy(ptr %t447, ptr %t435, i64 %t436)
  %t448 = getelementptr i8, ptr %t447, i64 %t436
  call void @olang_textcopy(ptr %t448, ptr %t437, i64 %t438)
  %t449 = getelementptr i8, ptr %t448, i64 %t438
  call void @olang_textcopy(ptr %t449, ptr %t441, i64 %t442)
  %t450 = getelementptr i8, ptr %t449, i64 %t442
  call void @olang_textcopy(ptr %t450, ptr %t444, i64 %t445)
  %t451 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t447, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } %t452, 1
  %t456 = mul i64 %t454, 1
  %t457 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t457, ptr %t455, i64 %t456, i1 false)
  %t458 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t431, { i64, ptr } %t459)
  br label %bb62
bb62:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t464 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t467 = extractvalue { i64, ptr } %t463, 1
  %t468 = extractvalue { i64, ptr } %t463, 0
  %t469 = add i64 %t465, %t468
  %t470 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t469)
  call void @olang_textcopy(ptr %t470, ptr %t464, i64 %t465)
  %t471 = getelementptr i8, ptr %t470, i64 %t465
  call void @olang_textcopy(ptr %t471, ptr %t467, i64 %t468)
  %t472 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t470, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = extractvalue { i64, ptr } %t473, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t462, { i64, ptr } %t480)
  br label %bb63
bb63:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t483, { i64, ptr } %t484)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb65:
  %t488 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t488, ptr %l210
  br label %bb66
bb66:
  %t489 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l210
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t489, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t490 = load i64, ptr %l8, !tbaa !24
  store i64 %t490, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t492 = load i64, ptr %l32, !tbaa !24
  %t493 = load i64, ptr %l31, !tbaa !24
  %t496 = icmp sgt i64 %t492, %t493
  br i1 %t496, label %bb67, label %bb68
bb67:
  %t498 = load i64, ptr %l33, !tbaa !24
  %t500 = icmp sgt i64 %t498, 0
  br i1 %t500, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb72
bb69:
  %t502 = load i64, ptr %l32, !tbaa !24
  %t503 = load i64, ptr %l31, !tbaa !24
  %t506 = sub i64 %t502, %t503
  %t507 = load i64, ptr %l33, !tbaa !24
  %t510 = add i64 %t506, %t507
  %t512 = sub i64 %t510, 1
  %t513 = load i64, ptr %l33, !tbaa !24
  %t516 = sdiv i64 %t512, %t513
  store i64 %t516, ptr %l218, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb71
bb71:
  %t518 = load i64, ptr %l218, !tbaa !24
  store i64 %t518, ptr %l215, !tbaa !24
  br label %bb72
bb72:
  %t519 = load i64, ptr %l215, !tbaa !24
  store i64 %t519, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb73
bb73:
  %t520 = load i64, ptr %l35, !tbaa !24
  %t521 = load i64, ptr %l34, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb74, label %bb75
bb74:
  br label %bb81
bb75:
  br label %bb76
bb76:
  %t528 = load i64, ptr %l31, !tbaa !24
  %t529 = load i64, ptr %l35, !tbaa !24
  %t530 = load i64, ptr %l33, !tbaa !24
  %t533 = mul i64 %t529, %t530
  %t536 = add i64 %t528, %t533
  store ptr %l30, ptr %l236, !tbaa !29
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l237, !tbaa !29
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load %"compiler/mir:Range", ptr %l6
  %t545 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t539, %"compiler/mir:Range" %t540, i64 %t536)
  store { i64, [4 x i64] } %t545, ptr %l241
  br label %bb77
bb77:
  %t546 = load i32, ptr %l9, !tbaa !23
  %t547 = load ptr, ptr %l237, !tbaa !29
  %t548 = load { i64, [4 x i64] }, ptr %l241
  %t550 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t547, { i64, [4 x i64] } %t548, i32 %t546)
  store { i64, ptr } %t550, ptr %l243
  br label %bb78
bb78:
  %t551 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 0
  %t553 = extractvalue { i64, ptr } %t551, 1
  %t554 = mul i64 %t552, 1
  %t555 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t555, ptr %t553, i64 %t554, i1 false)
  %t556 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  %t558 = load ptr, ptr %l236, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s1, ptr %s1, ptr %t558, { i64, ptr } %t557)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t560 = load i64, ptr %l35, !tbaa !24
  %t562 = add i64 %t560, 1
  store i64 %t562, ptr %l35, !tbaa !24
  br label %bb73
bb81:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load %"compiler/mir:Lvalue", ptr %l1
  %t568 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t564, %"compiler/mir:Lvalue" %t565)
  store { { i64, ptr }, i32 } %t568, ptr %l249
  br label %bb82
bb82:
  %t569 = load { { i64, ptr }, i32 }, ptr %l249
  store { { i64, ptr }, i32 } %t569, ptr %l37
  %t570 = getelementptr { { i64, ptr }, i32 }, ptr %l37, i32 0, i32 0
  %t571 = load { i64, ptr }, ptr %t570, !tbaa !27
  store { i64, ptr } %t571, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t573 = load i64, ptr %l8, !tbaa !24
  store i64 %t573, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t575 = load i64, ptr %l40, !tbaa !24
  %t576 = load i64, ptr %l39, !tbaa !24
  %t579 = icmp sgt i64 %t575, %t576
  br i1 %t579, label %bb83, label %bb84
bb83:
  %t581 = load i64, ptr %l41, !tbaa !24
  %t583 = icmp sgt i64 %t581, 0
  br i1 %t583, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb88
bb85:
  %t585 = load i64, ptr %l40, !tbaa !24
  %t586 = load i64, ptr %l39, !tbaa !24
  %t589 = sub i64 %t585, %t586
  %t590 = load i64, ptr %l41, !tbaa !24
  %t593 = add i64 %t589, %t590
  %t595 = sub i64 %t593, 1
  %t596 = load i64, ptr %l41, !tbaa !24
  %t599 = sdiv i64 %t595, %t596
  store i64 %t599, ptr %l258, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l258, !tbaa !24
  br label %bb87
bb87:
  %t601 = load i64, ptr %l258, !tbaa !24
  store i64 %t601, ptr %l255, !tbaa !24
  br label %bb88
bb88:
  %t602 = load i64, ptr %l255, !tbaa !24
  store i64 %t602, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t603 = load i64, ptr %l43, !tbaa !24
  %t604 = load i64, ptr %l42, !tbaa !24
  %t607 = icmp slt i64 %t603, %t604
  %t609 = xor i1 %t607, true
  br i1 %t609, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb91:
  br label %bb92
bb92:
  %t611 = load i64, ptr %l39, !tbaa !24
  %t612 = load i64, ptr %l43, !tbaa !24
  %t613 = load i64, ptr %l41, !tbaa !24
  %t616 = mul i64 %t612, %t613
  %t619 = add i64 %t611, %t616
  store i64 %t619, ptr %l44, !tbaa !24
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t624 = load i64, ptr %l44, !tbaa !24
  %t625 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t626 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t628 = extractvalue { i64, ptr } %t622, 1
  %t629 = extractvalue { i64, ptr } %t622, 0
  %t630 = add i64 %t626, %t629
  %t631 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t632 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t633 = add i64 %t630, %t632
  %t635 = extractvalue { i64, ptr } %t623, 1
  %t636 = extractvalue { i64, ptr } %t623, 0
  %t637 = add i64 %t633, %t636
  %t638 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t639 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t640 = add i64 %t637, %t639
  %t642 = call i64 @__olang_fmt_i64(ptr null, i64 %t624)
  %t643 = add i64 %t640, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t625, i64 %t626)
  %t645 = getelementptr i8, ptr %t644, i64 %t626
  call void @olang_textcopy(ptr %t645, ptr %t628, i64 %t629)
  %t646 = getelementptr i8, ptr %t645, i64 %t629
  call void @olang_textcopy(ptr %t646, ptr %t631, i64 %t632)
  %t647 = getelementptr i8, ptr %t646, i64 %t632
  call void @olang_textcopy(ptr %t647, ptr %t635, i64 %t636)
  %t648 = getelementptr i8, ptr %t647, i64 %t636
  call void @olang_textcopy(ptr %t648, ptr %t638, i64 %t639)
  %t649 = getelementptr i8, ptr %t648, i64 %t639
  %t650 = call i64 @__olang_fmt_i64(ptr %t649, i64 %t624)
  %t651 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t644, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = extractvalue { i64, ptr } %t652, 1
  %t656 = mul i64 %t654, 1
  %t657 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t656)
  call void @llvm.memcpy.p0.p0.i64(ptr %t657, ptr %t655, i64 %t656, i1 false)
  %t658 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  %t662 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t621, { i64, ptr } %t659)
  store { i64, ptr } %t662, ptr %l282
  br label %bb93
bb93:
  %t663 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t663, ptr %l45, !tbaa !27
  %t664 = load ptr, ptr %l0, !tbaa !29
  store ptr %t664, ptr %l283, !tbaa !29
  %t665 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t665, ptr %l284, !tbaa !27
  %t666 = load i64, ptr %l44, !tbaa !24
  %t669 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s1, ptr %s1, ptr %l30, i64 %t666)
  store { i64, ptr } %t669, ptr %l287
  br label %bb94
bb94:
  %t670 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t671 = load ptr, ptr %l283, !tbaa !29
  %t672 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t673 = load { i64, ptr }, ptr %l287, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s21, ptr %s21, ptr %t671, { i64, ptr } %t672, { i64, ptr } %t673, { i64, ptr } %t670, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  %t675 = load i64, ptr %l43, !tbaa !24
  %t677 = add i64 %t675, 1
  store i64 %t677, ptr %l43, !tbaa !24
  br label %bb89
bb97:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb98:
  %t680 = load { i64, [15 x i64] }, ptr %l3
  %t682 = extractvalue { i64, [15 x i64] } %t680, 0
  %t683 = icmp eq i64 %t682, 0
  br i1 %t683, label %bb99, label %bb100
bb99:
  %t685 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t686 = getelementptr { { i64, [4 x i64] } }, ptr %t685, i32 0, i32 0
  %t687 = load { i64, [4 x i64] }, ptr %t686
  store { i64, [4 x i64] } %t687, ptr %l46
  br label %bb101
bb100:
  br label %bb144
bb101:
  %t689 = load { i64, [4 x i64] }, ptr %l46
  %t691 = extractvalue { i64, [4 x i64] } %t689, 0
  %t692 = icmp eq i64 %t691, 1
  br i1 %t692, label %bb102, label %bb103
bb102:
  %t694 = getelementptr { i64, [4 x i64] }, ptr %l46, i32 0, i32 1
  %t695 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t694, i32 0, i32 0
  %t696 = load %"compiler/mir:Lvalue", ptr %t695
  store %"compiler/mir:Lvalue" %t696, ptr %l47
  br label %bb104
bb103:
  br label %bb139
bb104:
  store %olang.scope zeroinitializer, ptr %s25
  %t698 = load ptr, ptr %l4, !tbaa !29
  store ptr %t698, ptr %l298, !tbaa !29
  %t699 = load ptr, ptr %l4, !tbaa !29
  %t700 = load i32, ptr %l2, !tbaa !23
  %t703 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t699, i32 %t700)
  store i32 %t703, ptr %l301
  br label %bb105
bb105:
  %t704 = load ptr, ptr %l298, !tbaa !29
  %t705 = load i32, ptr %l301, !tbaa !23
  %t706 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t704, i32 %t705)
  store i32 %t706, ptr %l302
  br label %bb106
bb106:
  %t707 = load i32, ptr %l302, !range !{i32 0, i32 33}
  store i32 %t707, ptr %l48
  %t708 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t710 = trunc i64 19 to i32
  %t711 = icmp eq i32 %t708, %t710
  %t713 = xor i1 %t711, true
  br i1 %t713, label %bb107, label %bb108
bb107:
  %t715 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t717 = trunc i64 18 to i32
  %t718 = icmp eq i32 %t715, %t717
  %t720 = xor i1 %t718, true
  store i1 %t720, ptr %l306, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l306, !tbaa !21
  br label %bb109
bb109:
  %t722 = load i1, ptr %l306, !tbaa !21
  br i1 %t722, label %bb110, label %bb111
bb110:
  %t723 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t725 = trunc i64 24 to i32
  %t726 = icmp eq i32 %t723, %t725
  %t728 = xor i1 %t726, true
  store i1 %t728, ptr %l310, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb112
bb112:
  %t730 = load i1, ptr %l310, !tbaa !21
  br i1 %t730, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t732 = load ptr, ptr %l4, !tbaa !29
  store ptr %t732, ptr %l315, !tbaa !29
  %t733 = load ptr, ptr %l4, !tbaa !29
  %t734 = load i32, ptr %l2, !tbaa !23
  %t737 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t733, i32 %t734)
  store i32 %t737, ptr %l318
  br label %bb116
bb116:
  %t738 = load ptr, ptr %l315, !tbaa !29
  %t739 = load i32, ptr %l318, !tbaa !23
  %t740 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t738, i32 %t739)
  store i32 %t740, ptr %l319
  br label %bb117
bb117:
  %t741 = load i32, ptr %l319, !range !{i32 0, i32 33}
  %t743 = trunc i64 19 to i32
  %t744 = icmp eq i32 %t741, %t743
  br i1 %t744, label %bb118, label %bb119
bb118:
  %t746 = load ptr, ptr %l0, !tbaa !29
  store ptr %t746, ptr %l323, !tbaa !29
  %t747 = load ptr, ptr %l4, !tbaa !29
  %t748 = load i32, ptr %l2, !tbaa !23
  %t751 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t747, i32 %t748)
  store i32 %t751, ptr %l326
  br label %bb120
bb119:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb122
bb120:
  %t752 = load ptr, ptr %l323, !tbaa !29
  %t753 = load i32, ptr %l326, !tbaa !23
  %t754 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t752, i32 %t753)
  store i1 %t754, ptr %l327
  br label %bb121
bb121:
  %t755 = load i1, ptr %l327, !tbaa !21
  %t756 = xor i1 %t755, true
  store i1 %t756, ptr %l322, !tbaa !21
  br label %bb122
bb122:
  %t758 = load i1, ptr %l322, !tbaa !21
  br i1 %t758, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load i32, ptr %l2, !tbaa !23
  %t764 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t760, i32 %t761)
  store i64 %t764, ptr %l332
  br label %bb126
bb126:
  %t765 = load i64, ptr %l332, !tbaa !24
  %t766 = icmp sle i64 %t765, 128
  br i1 %t766, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l334, !tbaa !21
  br label %bb130
bb128:
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t769 = load %"compiler/mir:Lvalue", ptr %l47
  %t772 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t768, %"compiler/mir:Lvalue" %t769)
  store i32 %t772, ptr %l337
  br label %bb129
bb129:
  %t773 = load i32, ptr %l2, !tbaa !23
  %t774 = load i32, ptr %l337, !tbaa !23
  %t776 = icmp ne i32 %t774, %t773
  store i1 %t776, ptr %l334, !tbaa !21
  br label %bb130
bb130:
  %t778 = load i1, ptr %l334, !tbaa !21
  br i1 %t778, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load %"compiler/mir:Lvalue", ptr %l47
  %t784 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t780, %"compiler/mir:Lvalue" %t781)
  store { { i64, ptr }, i32 } %t784, ptr %l343
  br label %bb134
bb134:
  %t785 = load { { i64, ptr }, i32 }, ptr %l343
  store { { i64, ptr }, i32 } %t785, ptr %l49
  %t786 = getelementptr { { i64, ptr }, i32 }, ptr %l49, i32 0, i32 0
  %t787 = load { i64, ptr }, ptr %t786, !tbaa !27
  store { i64, ptr } %t787, ptr %l50, !tbaa !27
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load %"compiler/mir:Lvalue", ptr %l1
  %t793 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t789, %"compiler/mir:Lvalue" %t790)
  store { { i64, ptr }, i32 } %t793, ptr %l347
  br label %bb135
bb135:
  %t794 = load { { i64, ptr }, i32 }, ptr %l347
  store { { i64, ptr }, i32 } %t794, ptr %l51
  %t795 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t796 = load { i64, ptr }, ptr %t795, !tbaa !27
  store { i64, ptr } %t796, ptr %l52, !tbaa !27
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/emit:fnEm", ptr %t798, i32 0, i32 0
  %t801 = load ptr, ptr %t800, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s25, ptr %s25, ptr %t801, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d267, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d268, i32 0, i32 1) })
  br label %bb136
bb136:
  %t803 = load ptr, ptr %l0, !tbaa !29
  store ptr %t803, ptr %l351, !tbaa !29
  %t804 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t804, ptr %l352, !tbaa !27
  %t805 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t805, ptr %l353, !tbaa !27
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load i32, ptr %l2, !tbaa !23
  %t810 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t806, i32 %t807)
  store i64 %t810, ptr %l356
  br label %bb137
bb137:
  %t811 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t813 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t813, 1
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t816 = add i64 %t812, %t815
  %t817 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t818 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t819 = add i64 %t816, %t818
  %t820 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 1
  %t822 = extractvalue { i64, ptr } %t820, 0
  %t823 = add i64 %t819, %t822
  %t824 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t825 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t826 = add i64 %t823, %t825
  %t827 = load i64, ptr %l356, !tbaa !24
  %t828 = call i64 @__olang_fmt_i64(ptr null, i64 %t827)
  %t829 = add i64 %t826, %t828
  %t830 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t831 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t832 = add i64 %t829, %t831
  %t833 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t832)
  call void @olang_textcopy(ptr %t833, ptr %t811, i64 %t812)
  %t834 = getelementptr i8, ptr %t833, i64 %t812
  call void @olang_textcopy(ptr %t834, ptr %t814, i64 %t815)
  %t835 = getelementptr i8, ptr %t834, i64 %t815
  call void @olang_textcopy(ptr %t835, ptr %t817, i64 %t818)
  %t836 = getelementptr i8, ptr %t835, i64 %t818
  call void @olang_textcopy(ptr %t836, ptr %t821, i64 %t822)
  %t837 = getelementptr i8, ptr %t836, i64 %t822
  call void @olang_textcopy(ptr %t837, ptr %t824, i64 %t825)
  %t838 = getelementptr i8, ptr %t837, i64 %t825
  %t839 = call i64 @__olang_fmt_i64(ptr %t838, i64 %t827)
  %t840 = getelementptr i8, ptr %t838, i64 %t828
  call void @olang_textcopy(ptr %t840, ptr %t830, i64 %t831)
  %t841 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t833, 1
  %t844 = extractvalue { i64, ptr } %t842, 0
  %t845 = extractvalue { i64, ptr } %t842, 1
  %t846 = mul i64 %t844, 1
  %t847 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t846)
  call void @llvm.memcpy.p0.p0.i64(ptr %t847, ptr %t845, i64 %t846, i1 false)
  %t848 = insertvalue { i64, ptr } undef, i64 %t844, 0
  %t849 = insertvalue { i64, ptr } %t848, ptr %t847, 1
  %t850 = load ptr, ptr %l351, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t850, { i64, ptr } %t849)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br i1 true, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  call void @__olang_check_failed(ptr @olang_loc_9357034ceffa49e9_ad514f9345461395)
  unreachable
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store i1 false, ptr %rv
  br label %ret
bb148:
  call void @__olang_check_failed(ptr @olang_loc_1dffb4089bad5318_6447f84abd9ba4a4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindWalks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [7 x i64] }
  %l12 = alloca { i64, [2 x i64] }
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l18 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l55 = alloca i32
  %l60 = alloca i32
  %l65 = alloca %"compiler/mir:Call"
  %l67 = alloca i1
  %l74 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l87 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l88 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l90 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l91 = alloca i32
  %l93 = alloca i1
  %l96 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l100 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l101 = alloca i32
  %l103 = alloca i1
  %l109 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l110 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l112 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l113 = alloca i32
  %l115 = alloca i1
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l1, !tbaa !29
  %t14 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t14, ptr %l24
  br label %bb4
bb4:
  %t15 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/mir:Fn", ptr %t16, i32 0, i32 27
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l27
  br label %bb5
bb5:
  %t21 = load i64, ptr %l27, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l34, !tbaa !24
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l31, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  br label %bb38
bb14:
  br label %bb15
bb15:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/mir:Fn", ptr %t68, i32 0, i32 27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l55
  br label %bb16
bb16:
  %t75 = load i32, ptr %l55, !tbaa !23
  %t76 = sext i32 %t75 to i64
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 28
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t84, ptr %l60
  br label %bb17
bb17:
  %t85 = load i32, ptr %l60, !tbaa !23
  %t86 = sext i32 %t85 to i64
  store i64 %t86, ptr %l10, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/mir:Fn", ptr %t88, i32 0, i32 14
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/mir:Call" %t94, ptr %l65
  br label %bb18
bb18:
  %t95 = getelementptr %"compiler/mir:Call", ptr %l65, i32 0, i32 0
  %t96 = load { i64, [7 x i64] }, ptr %t95
  store { i64, [7 x i64] } %t96, ptr %l11
  %t98 = load { i64, [7 x i64] }, ptr %l11
  %t100 = extractvalue { i64, [7 x i64] } %t98, 0
  %t101 = icmp eq i64 %t100, 0
  br i1 %t101, label %bb19, label %bb20
bb19:
  %t103 = getelementptr { i64, [7 x i64] }, ptr %l11, i32 0, i32 1
  %t104 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t103, i32 0, i32 0
  %t105 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t105, ptr %l12
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/emit:fnEm", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load { i64, [2 x i64] }, ptr %l12
  %t114 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t110, { i64, [2 x i64] } %t111)
  store i1 %t114, ptr %l74
  br label %bb22
bb22:
  %t115 = load i1, ptr %l74, !tbaa !21
  store i1 %t115, ptr %l67, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_81868432e93876af_31517217ac874813)
  unreachable
bb28:
  %t116 = load i1, ptr %l67, !tbaa !21
  %t119 = xor i1 %t116, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  store ptr %l2, ptr %l77, !tbaa !29
  %t121 = load i64, ptr %l10, !tbaa !24
  store i64 %t121, ptr %l78, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l2, i64 %t122)
  store i1 %t125, ptr %l81
  br label %bb32
bb32:
  %t126 = load i1, ptr %l81, !tbaa !21
  br i1 %t126, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %l82, !tbaa !24
  br label %bb35
bb34:
  %t127 = load i64, ptr %l9, !tbaa !24
  store i64 %t127, ptr %l82, !tbaa !24
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l77, !tbaa !29
  %t130 = load i64, ptr %l78, !tbaa !24
  %t131 = load i64, ptr %l82, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t129, i64 %t130, i64 %t131)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb12
bb38:
  %t137 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %s0, ptr %s0, ptr %l2)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t137, ptr %l87
  br label %bb39
bb39:
  %t138 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l87
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t138, ptr %l14
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t140 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %s0, ptr %l14)
  %t141 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t140, 1
  %t142 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t140, 0
  store i32 %t142, ptr %l91
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb42, label %ok.144, !prof !99
ok.144:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t141, ptr %l90
  br label %bb41
bb41:
  %t145 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l90
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t145, ptr %l88
  br label %bb44
bb42:
  %t146 = load i32, ptr %l91, !tbaa !23
  %t147 = ashr i32 %t146, 16
  %t149 = icmp eq i32 %t147, 1
  store i1 %t149, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb44:
  %t150 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l88
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t150, ptr %l15
  %t151 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 1
  %t152 = load i64, ptr %t151, !tbaa !24
  %t154 = icmp slt i64 %t152, 0
  br i1 %t154, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb46:
  br label %bb47
bb47:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 0
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 1
  %t160 = load i64, ptr %t159, !tbaa !24
  %t164 = call { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkFlow(ptr %v0, ptr %s9, ptr %t156, i64 %t158, i64 %t160)
  %t165 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t164, 1
  %t166 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t164, 0
  store i32 %t166, ptr %l101
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb49, label %ok.168, !prof !99
ok.168:
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t165, ptr %l100
  br label %bb48
bb48:
  %t169 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l100
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t169, ptr %l96
  br label %bb51
bb49:
  %t170 = load i32, ptr %l101, !tbaa !23
  %t171 = ashr i32 %t170, 16
  %t173 = icmp eq i32 %t171, 1
  store i1 %t173, ptr %l103, !tbaa !21
  br label %bb50
bb50:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb51:
  %t174 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l96
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t174, ptr %l16
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/emit:fnEm", ptr %t175, i32 0, i32 31
  %t178 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l15, i32 0, i32 1
  %t181 = load i64, ptr %t180, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t177, i64 %t179, i64 %t181)
  br label %bb52
bb52:
  %t186 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %s9, ptr %s9, ptr %l16)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t186, ptr %l109
  br label %bb53
bb53:
  %t187 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l109
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t187, ptr %l17
  br label %bb54
bb54:
  %t189 = call { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %s9, ptr %l17)
  %t190 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t189, 1
  %t191 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t189, 0
  store i32 %t191, ptr %l113
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb56, label %ok.193, !prof !99
ok.193:
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t190, ptr %l112
  br label %bb55
bb55:
  %t194 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l112
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t194, ptr %l110
  br label %bb58
bb56:
  %t195 = load i32, ptr %l113, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  store i1 %t198, ptr %l115, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  br label %bb61
bb58:
  %t199 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l110
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t199, ptr %l18
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/emit:fnEm", ptr %t200, i32 0, i32 32
  %t203 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l18, i32 0, i32 0
  %t204 = load i64, ptr %t203, !tbaa !24
  %t205 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l18, i32 0, i32 1
  %t206 = load i1, ptr %t205, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t202, i64 %t204, i1 %t206)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb54
bb61:
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb62:
  br label %bb40
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { { i64, ptr }, i32 }
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { { i64, ptr }, i32 }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { { i64, ptr }, i32 }
  %l25 = alloca { { i64, ptr }, i32 }
  %l38 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i32
  %l59 = alloca i1
  %l62 = alloca { { i64, ptr }, i32 }
  %l71 = alloca { i64, ptr }
  %l78 = alloca { { i64, ptr }, i32 }
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = load { i64, [4 x i64] }, ptr %t15
  store { i64, [4 x i64] } %t16, ptr %l5
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/mir:Lvalue", ptr %l1
  %t22 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t18, %"compiler/mir:Lvalue" %t19)
  store { { i64, ptr }, i32 } %t22, ptr %l25
  br label %bb4
bb4:
  %t23 = load { { i64, ptr }, i32 }, ptr %l25
  store { { i64, ptr }, i32 } %t23, ptr %l6
  %t24 = getelementptr { { i64, ptr }, i32 }, ptr %l6, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t30 = load { i64, [4 x i64] }, ptr %l5
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s1, ptr %s1, ptr %t27, { i64, ptr } %t25, i32 %t29, { i64, [4 x i64] } %t30, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d273, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t36 = load { i64, [15 x i64] }, ptr %l3
  %t38 = extractvalue { i64, [15 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 6
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t42 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t41, i32 0, i32 0
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l8, !tbaa !23
  %t45 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t46 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t45, i32 0, i32 2
  %t47 = load %"compiler/mir:Range", ptr %t46
  store %"compiler/mir:Range" %t47, ptr %l9
  br label %bb9
bb8:
  br label %bb34
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t50 = load i32, ptr %l8, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l38
  br label %bb10
bb10:
  %t54 = load i32, ptr %l38, !tbaa !23
  store i32 %t54, ptr %l10, !tbaa !23
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load i32, ptr %l10, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l41
  br label %bb11
bb11:
  %t60 = load i32, ptr %l41, !range !{i32 0, i32 33}
  store i32 %t60, ptr %l11
  %t61 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t63 = trunc i64 24 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb19
bb13:
  %t66 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t68 = trunc i64 18 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l4, !tbaa !29
  store ptr %t71, ptr %l48, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i32, ptr %l10, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l51
  br label %bb16
bb15:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb18
bb16:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load i32, ptr %l51, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t79, ptr %l52
  br label %bb17
bb17:
  %t80 = load i32, ptr %l52, !range !{i32 0, i32 6}
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/mir:Lvalue", ptr %l1
  %t90 = load %"compiler/mir:Range", ptr %l9
  %t94 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %t88, %"compiler/mir:Lvalue" %t89, %"compiler/mir:Range" %t90)
  store i1 %t94, ptr %l59
  br label %bb23
bb23:
  %t95 = load i1, ptr %l59, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/mir:Lvalue", ptr %l1
  %t100 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s4, ptr %t96, %"compiler/mir:Lvalue" %t97)
  store { { i64, ptr }, i32 } %t100, ptr %l62
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t101 = load { { i64, ptr }, i32 }, ptr %l62
  store { { i64, ptr }, i32 } %t101, ptr %l12
  %t102 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l2, !tbaa !23
  %t108 = load %"compiler/mir:Range", ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %s4, ptr %t105, { i64, ptr } %t103, i32 %t107, %"compiler/mir:Range" %t108)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l2, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t118, ptr %l71
  br label %bb29
bb29:
  %t119 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t119, ptr %l14, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t122 = load i32, ptr %l2, !tbaa !23
  %t123 = load %"compiler/mir:Range", ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %s2, ptr %t120, { i64, ptr } %t121, i32 %t122, %"compiler/mir:Range" %t123)
  br label %bb30
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/mir:Lvalue", ptr %l1
  %t132 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s2, ptr %t128, %"compiler/mir:Lvalue" %t129)
  store { { i64, ptr }, i32 } %t132, ptr %l78
  br label %bb31
bb31:
  %t133 = load { { i64, ptr }, i32 }, ptr %l78
  store { { i64, ptr }, i32 } %t133, ptr %l15
  %t134 = getelementptr { { i64, ptr }, i32 }, ptr %l15, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l80, !tbaa !29
  store { i64, ptr } %t135, ptr %l81, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t139, ptr %l82, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l2, !tbaa !23
  %t144 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t140, i32 %t141)
  store i64 %t144, ptr %l85
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t148 = load i64, ptr %l85, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s2, ptr %s2, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, i64 %t148)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1c84b7c0e51a2751_bb90751f2238f075)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = extractvalue { i64, ptr } %t9, 0
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a1, 1
  %t19 = extractvalue { i64, ptr } %a1, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t12, i64 %t13)
  %t22 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t22, ptr %t14, i64 %t15)
  %t23 = getelementptr i8, ptr %t22, i64 %t15
  call void @olang_textcopy(ptr %t23, ptr %t18, i64 %t19)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } %t32)
  br label %bb2
bb2:
  %t35 = load ptr, ptr %lp2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca %"compiler/mir:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 7
  %t9 = sext i32 %a1 to i64
  %t12 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t6, i64 %t9)
  store %"compiler/mir:Local" %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/mir:Local", ptr %l7, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l12 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store i1 %t16, ptr %l12
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t19, 1
  %t24 = extractvalue { i64, ptr } %t19, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t18, { i64, ptr } %t40)
  store { i64, ptr } %t43, ptr %l17
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l18, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:fnEm", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/emit:Emitter", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t52, i32 %t53)
  store { i64, ptr } %t56, ptr %l23
  br label %bb11
bb11:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t57, i64 %t58)
  %t64 = getelementptr i8, ptr %t63, i64 %t58
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t61)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t74 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } %t73)
  br label %bb12
bb12:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d280, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t76, ptr %l27, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l28, !tbaa !24
  %t79 = load i64, ptr %l28, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l29, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l28, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t90, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t6 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %a1, 1
  %t10 = extractvalue { i64, ptr } %a1, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a2, 1
  %t17 = extractvalue { i64, ptr } %a2, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a3, 1
  %t24 = extractvalue { i64, ptr } %a3, 0
  %t25 = add i64 %t21, %t24
  %t27 = extractvalue { i64, ptr } %a4, 1
  %t28 = extractvalue { i64, ptr } %a4, 0
  %t29 = add i64 %t25, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t6, i64 %t7)
  %t31 = getelementptr i8, ptr %t30, i64 %t7
  call void @olang_textcopy(ptr %t31, ptr %t9, i64 %t10)
  %t32 = getelementptr i8, ptr %t31, i64 %t10
  call void @olang_textcopy(ptr %t32, ptr %t12, i64 %t13)
  %t33 = getelementptr i8, ptr %t32, i64 %t13
  call void @olang_textcopy(ptr %t33, ptr %t16, i64 %t17)
  %t34 = getelementptr i8, ptr %t33, i64 %t17
  call void @olang_textcopy(ptr %t34, ptr %t19, i64 %t20)
  %t35 = getelementptr i8, ptr %t34, i64 %t20
  call void @olang_textcopy(ptr %t35, ptr %t23, i64 %t24)
  %t36 = getelementptr i8, ptr %t35, i64 %t24
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t30, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t45)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskEnds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/mir:Task"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l61 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l78 = alloca { i64, [4 x i64] }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Task" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d285, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t24, ptr %t17, i64 %t18)
  %t25 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t35, ptr %s0, ptr %t11, { i64, ptr } %t12, { i64, ptr } %t34)
  br label %bb5
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t39 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t40 = getelementptr %"compiler/mir:Range", ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb6, label %bb7
bb6:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb8:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l36, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb10
bb10:
  %t71 = load i64, ptr %l36, !tbaa !24
  store i64 %t71, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb14:
  br label %bb15
bb15:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/mir:Fn", ptr %t94, i32 0, i32 11
  %t97 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t98 = getelementptr %"compiler/mir:Range", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t108 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t96, i64 %t105)
  store { i64, [4 x i64] } %t108, ptr %l61
  br label %bb16
bb16:
  %t109 = load { i64, [4 x i64] }, ptr %l61
  store { i64, [4 x i64] } %t109, ptr %l13
  %t110 = load { i64, [4 x i64] }, ptr %l13
  %t112 = extractvalue { i64, [4 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 2
  br i1 %t113, label %bb17, label %bb18
bb17:
  %t115 = getelementptr { i64, [4 x i64] }, ptr %l13, i32 0, i32 1
  %t116 = getelementptr { i32, i64 }, ptr %t115, i32 0, i32 1
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t119 = load i64, ptr %l14, !tbaa !24
  store i64 %t119, ptr %l12, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef)
  unreachable
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d288, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l68, !tbaa !24
  %t124 = load i64, ptr %l68, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l69, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l68, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t135, ptr %l15, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:fnEm", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/mir:Fn", ptr %t139, i32 0, i32 11
  %t142 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t143 = getelementptr %"compiler/mir:Range", ptr %t142, i32 0, i32 0
  %t144 = load i32, ptr %t143, !tbaa !23
  %t146 = sext i32 %t144 to i64
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = add i64 %t150, 1
  %t155 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t141, i64 %t152)
  store { i64, [4 x i64] } %t155, ptr %l78
  br label %bb26
bb26:
  %t156 = load { i64, [4 x i64] }, ptr %l78
  store { i64, [4 x i64] } %t156, ptr %l16
  %t157 = load { i64, [4 x i64] }, ptr %l16
  %t159 = extractvalue { i64, [4 x i64] } %t157, 0
  %t160 = icmp eq i64 %t159, 3
  br i1 %t160, label %bb27, label %bb28
bb27:
  %t162 = getelementptr { i64, [4 x i64] }, ptr %l16, i32 0, i32 1
  %t163 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t162, i32 0, i32 1
  %t164 = load i32, ptr %t163
  store i32 %t164, ptr %l17, !tbaa !23
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l17, !tbaa !23
  %t170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s3, ptr %t166, i32 %t167)
  store { i64, ptr } %t170, ptr %l84
  br label %bb30
bb30:
  %t171 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l86, !tbaa !24
  %t176 = load i64, ptr %l86, !tbaa !24
  %t177 = icmp eq i64 %t172, %t176
  br i1 %t177, label %bb31, label %bb32
bb31:
  %t179 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = load i64, ptr %l86, !tbaa !24
  %t184 = mul i64 %t183, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t180, ptr %t182, i64 %t184, i1 false)
  br label %bb33
bb32:
  %t185 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t185, ptr %l15, !tbaa !27
  br label %bb33
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_625291c18633ca8a_b2d4e63a7cb7312e)
  unreachable
bb39:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = load i64, ptr %l12, !tbaa !24
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l11, !tbaa !24
  %t192 = load i64, ptr %l11, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t197 = call i64 @__olang_fmt_i64(ptr null, i64 %t187)
  %t198 = add i64 %t195, %t197
  %t199 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %a2, 1
  %t204 = extractvalue { i64, ptr } %a2, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t210 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t211 = add i64 %t208, %t210
  %t212 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t216 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t217 = add i64 %t214, %t216
  %t218 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t223 = add i64 %t220, %t222
  %t224 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t228 = call i64 @__olang_fmt_i64(ptr null, i64 %t192)
  %t229 = add i64 %t226, %t228
  %t230 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t193)
  %t235 = add i64 %t232, %t234
  %t236 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t194, i64 %t195)
  %t240 = getelementptr i8, ptr %t239, i64 %t195
  %t241 = call i64 @__olang_fmt_i64(ptr %t240, i64 %t187)
  %t242 = getelementptr i8, ptr %t240, i64 %t197
  call void @olang_textcopy(ptr %t242, ptr %t199, i64 %t200)
  %t243 = getelementptr i8, ptr %t242, i64 %t200
  call void @olang_textcopy(ptr %t243, ptr %t203, i64 %t204)
  %t244 = getelementptr i8, ptr %t243, i64 %t204
  call void @olang_textcopy(ptr %t244, ptr %t206, i64 %t207)
  %t245 = getelementptr i8, ptr %t244, i64 %t207
  %t246 = call i64 @__olang_fmt_i64(ptr %t245, i64 %t189)
  %t247 = getelementptr i8, ptr %t245, i64 %t210
  call void @olang_textcopy(ptr %t247, ptr %t212, i64 %t213)
  %t248 = getelementptr i8, ptr %t247, i64 %t213
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t190)
  %t250 = getelementptr i8, ptr %t248, i64 %t216
  call void @olang_textcopy(ptr %t250, ptr %t218, i64 %t219)
  %t251 = getelementptr i8, ptr %t250, i64 %t219
  %t252 = call i64 @__olang_fmt_i64(ptr %t251, i64 %t191)
  %t253 = getelementptr i8, ptr %t251, i64 %t222
  call void @olang_textcopy(ptr %t253, ptr %t224, i64 %t225)
  %t254 = getelementptr i8, ptr %t253, i64 %t225
  %t255 = call i64 @__olang_fmt_i64(ptr %t254, i64 %t192)
  %t256 = getelementptr i8, ptr %t254, i64 %t228
  call void @olang_textcopy(ptr %t256, ptr %t230, i64 %t231)
  %t257 = getelementptr i8, ptr %t256, i64 %t231
  %t258 = call i64 @__olang_fmt_i64(ptr %t257, i64 %t193)
  %t259 = getelementptr i8, ptr %t257, i64 %t234
  call void @olang_textcopy(ptr %t259, ptr %t236, i64 %t237)
  %t260 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t239, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t186, { i64, ptr } %t268)
  br label %bb40
bb40:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l98, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t272, ptr %l99, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t275 = load %"compiler/source:Span", ptr %t274
  %t276 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  call void @olang_textcopy(ptr %t287, ptr %t280, i64 %t281)
  %t288 = getelementptr i8, ptr %t287, i64 %t281
  call void @olang_textcopy(ptr %t288, ptr %t283, i64 %t284)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t301 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s3, ptr %s3, ptr %t273, %"compiler/source:Span" %t275, { i64, ptr } %t297)
  store { i64, ptr } %t301, ptr %l105
  br label %bb41
bb41:
  %t302 = load i64, ptr %l11, !tbaa !24
  %t303 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t305 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = add i64 %t311, %t314
  %t316 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t318 = add i64 %t315, %t317
  %t320 = call i64 @__olang_fmt_i64(ptr null, i64 %t302)
  %t321 = add i64 %t318, %t320
  %t322 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t303, i64 %t304)
  %t326 = getelementptr i8, ptr %t325, i64 %t304
  call void @olang_textcopy(ptr %t326, ptr %t306, i64 %t307)
  %t327 = getelementptr i8, ptr %t326, i64 %t307
  call void @olang_textcopy(ptr %t327, ptr %t309, i64 %t310)
  %t328 = getelementptr i8, ptr %t327, i64 %t310
  call void @olang_textcopy(ptr %t328, ptr %t313, i64 %t314)
  %t329 = getelementptr i8, ptr %t328, i64 %t314
  call void @olang_textcopy(ptr %t329, ptr %t316, i64 %t317)
  %t330 = getelementptr i8, ptr %t329, i64 %t317
  %t331 = call i64 @__olang_fmt_i64(ptr %t330, i64 %t302)
  %t332 = getelementptr i8, ptr %t330, i64 %t320
  call void @olang_textcopy(ptr %t332, ptr %t322, i64 %t323)
  %t333 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t325, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = extractvalue { i64, ptr } %t334, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t342, { i64, ptr } %t341)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t344 = load i64, ptr %l10, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l10, !tbaa !24
  br label %bb12
bb44:
  %t348 = load ptr, ptr %l1, !tbaa !29
  store ptr %t348, ptr %l111, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t349, ptr %l112, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t352 = load %"compiler/source:Span", ptr %t351
  %t355 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %t350, %"compiler/source:Span" %t352, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d303, i32 0, i32 1) })
  store { i64, ptr } %t355, ptr %l115
  br label %bb45
bb45:
  %t356 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t358 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t362, i64 %t363)
  %t375 = getelementptr i8, ptr %t374, i64 %t363
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = getelementptr i8, ptr %t375, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t386, { i64, ptr } %t385)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etrampoline(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, i1 %a3, { i64, ptr } %a4, i32 %a5, i64 %a6, %"compiler/mir:Task" %a7, i32 %a8, { i64, ptr } %a9) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Task"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i8
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca %"std/prelude/text:StringBuilder"
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l118 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca { i64, ptr }
  %l133 = alloca %"std/prelude/text:StringBuilder"
  %l139 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca i32
  %l153 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i1
  %l162 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l176 = alloca i64
  %l179 = alloca i64
  %l233 = alloca i64
  %l236 = alloca i64
  %l258 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca ptr
  %l311 = alloca i32
  %l312 = alloca { i64, ptr }
  %l316 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l324 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l332 = alloca i64
  %l333 = alloca { i64, ptr }
  %l335 = alloca { i64, ptr }
  %l336 = alloca { i64, ptr }
  %l338 = alloca i64
  %l340 = alloca i64
  %l341 = alloca { i64, ptr }
  %l345 = alloca i1
  %l354 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %l357 = alloca i64
  %l359 = alloca i64
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l364 = alloca i64
  %l366 = alloca i64
  %l367 = alloca { i64, ptr }
  %l370 = alloca i1
  %l374 = alloca { i64, ptr }
  %l376 = alloca i1
  %l412 = alloca ptr
  %l413 = alloca ptr
  %l414 = alloca { i64, ptr }
  %l417 = alloca i32
  %l419 = alloca { i64, ptr }
  %l426 = alloca i1
  %l428 = alloca i1
  %l441 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca i64
  %l448 = alloca i64
  %l451 = alloca ptr
  %l452 = alloca ptr
  %l455 = alloca i32
  %l456 = alloca i32
  %l457 = alloca { i64, ptr }
  %l462 = alloca i64
  %l465 = alloca i64
  %l485 = alloca { i64, ptr }
  %l488 = alloca i1
  %l496 = alloca ptr
  %l497 = alloca i64
  %l500 = alloca { i64, ptr }
  %l504 = alloca ptr
  %l505 = alloca i64
  %l506 = alloca i64
  %l508 = alloca { i64, ptr }
  %l511 = alloca i64
  %l518 = alloca ptr
  %l519 = alloca i64
  %l522 = alloca { i64, ptr }
  %l526 = alloca ptr
  %l527 = alloca ptr
  %l530 = alloca i32
  %l531 = alloca i32
  %l532 = alloca { i64, ptr }
  %l537 = alloca i64
  %l540 = alloca i64
  %l565 = alloca ptr
  %l566 = alloca i64
  %l569 = alloca { i64, ptr }
  %l574 = alloca ptr
  %l576 = alloca { i64, ptr }
  %l579 = alloca { i64, ptr }
  %l597 = alloca ptr
  %l598 = alloca { i64, ptr }
  %l599 = alloca i64
  %l601 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i32 %a5, ptr %l5
  store i64 %a6, ptr %l6
  store %"compiler/mir:Task" %a7, ptr %l7
  store { i64, ptr } %a9, ptr %l9
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l10, !tbaa !29
  %t6 = load ptr, ptr %l10, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l11, !tbaa !29
  %t11 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 25
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t24 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t20)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t31, ptr %lp13
  %t33 = load ptr, ptr %lp13
  store { i64, ptr } %t30, ptr %t33, !tbaa !27
  %t34 = load ptr, ptr %l10, !tbaa !29
  store ptr %t34, ptr %l75, !tbaa !29
  %t35 = load ptr, ptr %l75, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t35, i32 0, i32 25
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = add i64 %t37, 1
  %t41 = load ptr, ptr %l75, !tbaa !29
  %t42 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 25
  store i64 %t39, ptr %t42, !tbaa !24
  %t43 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t43, ptr %l78
  br label %bb1
bb1:
  %t44 = load %"std/prelude/text:StringBuilder", ptr %l78
  store %"std/prelude/text:StringBuilder" %t44, ptr %l14
  %t45 = load ptr, ptr %lp13
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t50 = extractvalue { i64, ptr } %t46, 1
  %t51 = extractvalue { i64, ptr } %t46, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t50, i64 %t51)
  %t58 = getelementptr i8, ptr %t57, i64 %t51
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t56, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = extractvalue { i64, ptr } %t60, 1
  %t64 = mul i64 %t62, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t65, ptr %t63, i64 %t64, i1 false)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t67)
  br label %bb2
bb2:
  store i64 0, ptr %l15, !tbaa !24
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %l2)
  store i64 %t71, ptr %l84
  br label %bb3
bb3:
  %t72 = load i64, ptr %l84, !tbaa !24
  store i64 %t72, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t73 = load i64, ptr %l16, !tbaa !24
  %t74 = load i64, ptr %l15, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb4, label %bb5
bb4:
  %t79 = load i64, ptr %l17, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb9
bb6:
  %t83 = load i64, ptr %l16, !tbaa !24
  %t84 = load i64, ptr %l15, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l17, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l17, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l91, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb8
bb8:
  %t99 = load i64, ptr %l91, !tbaa !24
  store i64 %t99, ptr %l88, !tbaa !24
  br label %bb9
bb9:
  %t100 = load i64, ptr %l88, !tbaa !24
  store i64 %t100, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load i64, ptr %l19, !tbaa !24
  %t102 = load i64, ptr %l18, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l19, !tbaa !24
  %t111 = load i64, ptr %l17, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l20, !tbaa !24
  %t119 = load i64, ptr %l20, !tbaa !24
  %t121 = load i64, ptr %l20, !tbaa !24
  %t122 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t126 = add i64 %t123, %t125
  %t127 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t131 = extractvalue { i64, ptr } %a1, 1
  %t132 = extractvalue { i64, ptr } %a1, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t139 = add i64 %t136, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t122, i64 %t123)
  %t144 = getelementptr i8, ptr %t143, i64 %t123
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t119)
  %t146 = getelementptr i8, ptr %t144, i64 %t125
  call void @olang_textcopy(ptr %t146, ptr %t127, i64 %t128)
  %t147 = getelementptr i8, ptr %t146, i64 %t128
  call void @olang_textcopy(ptr %t147, ptr %t131, i64 %t132)
  %t148 = getelementptr i8, ptr %t147, i64 %t132
  call void @olang_textcopy(ptr %t148, ptr %t134, i64 %t135)
  %t149 = getelementptr i8, ptr %t148, i64 %t135
  %t150 = call i64 @__olang_fmt_i64(ptr %t149, i64 %t121)
  %t151 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t151, ptr %t140, i64 %t141)
  %t152 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t143, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l14, { i64, ptr } %t160)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t163 = load i64, ptr %l19, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l19, !tbaa !24
  br label %bb10
bb16:
  %t167 = load i1, ptr %l3, !tbaa !21
  br i1 %t167, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l118, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb19
bb19:
  %t169 = load ptr, ptr %l11, !tbaa !29
  store ptr %t169, ptr %l119, !tbaa !29
  %t170 = load ptr, ptr %l11, !tbaa !29
  %t171 = load i32, ptr %l5, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l122
  br label %bb20
bb20:
  %t175 = load ptr, ptr %l119, !tbaa !29
  %t176 = load i32, ptr %l122, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t175, i32 %t176)
  store { i64, ptr } %t177, ptr %l123
  br label %bb21
bb21:
  %t178 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = load i64, ptr %l118, !tbaa !24
  %t182 = add i64 %t180, %t179
  %t183 = load i64, ptr %l6, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load %"compiler/mir:Task", ptr %l7
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskOld(ptr %v0, ptr %s0, ptr %t188, ptr %l14, %"compiler/mir:Task" %t189, i64 %t186)
  br label %bb22
bb22:
  store i64 0, ptr %l22, !tbaa !24
  store { i64, ptr } %a4, ptr %l23, !tbaa !27
  %t197 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t197, ptr %l133
  br label %bb23
bb23:
  %t198 = load %"std/prelude/text:StringBuilder", ptr %l133
  store %"std/prelude/text:StringBuilder" %t198, ptr %l24
  store i1 true, ptr %l25, !tbaa !21
  %t199 = load i1, ptr %l3, !tbaa !21
  br i1 %t199, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l14, { i64, ptr } { i64 121, ptr getelementptr inbounds (<{ i64, [121 x i8] }>, ptr @.d314, i32 0, i32 1) })
  br label %bb26
bb25:
  br label %bb28
bb26:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d315, i32 0, i32 1) }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l24, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d316, i32 0, i32 1) })
  br label %bb27
bb27:
  store i1 false, ptr %l25, !tbaa !21
  store i64 1, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  %t203 = load ptr, ptr %l10, !tbaa !29
  %t204 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t203, i32 %t204)
  br label %bb29
bb29:
  %t207 = load ptr, ptr %l11, !tbaa !29
  store ptr %t207, ptr %l139, !tbaa !29
  %t208 = load ptr, ptr %l11, !tbaa !29
  %t209 = load i32, ptr %l5, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l142
  br label %bb30
bb30:
  %t213 = load ptr, ptr %l139, !tbaa !29
  %t214 = load i32, ptr %l142, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t215, ptr %l143
  br label %bb31
bb31:
  %t216 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t216, ptr %l26, !tbaa !27
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t218 = load i32, ptr %l5, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l146
  br label %bb32
bb32:
  %t222 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t222, ptr %l27, !tbaa !27
  %t223 = load ptr, ptr %l11, !tbaa !29
  %t224 = load i32, ptr %l5, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l149
  br label %bb33
bb33:
  %t228 = load i32, ptr %l149, !tbaa !23
  store i32 %t228, ptr %l28, !tbaa !23
  %t229 = load i32, ptr %l28, !tbaa !23
  %t230 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t233 = icmp ne i32 %t229, %t230
  br i1 %t233, label %bb34, label %bb35
bb34:
  %t235 = load i32, ptr %l28, !tbaa !23
  %t236 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t239 = icmp ne i32 %t235, %t236
  store i1 %t239, ptr %l153, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb36
bb36:
  %t241 = load i1, ptr %l153, !tbaa !21
  br i1 %t241, label %bb37, label %bb38
bb37:
  %t242 = load ptr, ptr %l11, !tbaa !29
  %t243 = load i32, ptr %l28, !tbaa !23
  %t246 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t242, i32 %t243)
  store i1 %t246, ptr %l160
  br label %bb39
bb38:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb40
bb39:
  %t247 = load i1, ptr %l160, !tbaa !21
  store i1 %t247, ptr %l157, !tbaa !21
  br label %bb40
bb40:
  %t248 = load i1, ptr %l157, !tbaa !21
  store i1 %t248, ptr %l29, !tbaa !21
  %t249 = load i1, ptr %l29, !tbaa !21
  br i1 %t249, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l14, ptr %l162, !tbaa !29
  %t251 = load ptr, ptr %l10, !tbaa !29
  %t252 = load i32, ptr %l28, !tbaa !23
  %t255 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s8, ptr %t251, i32 %t252)
  store { i64, ptr } %t255, ptr %l165
  br label %bb43
bb42:
  br label %bb50
bb43:
  %t256 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t258 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t256, i64 %t257)
  %t266 = getelementptr i8, ptr %t265, i64 %t257
  call void @olang_textcopy(ptr %t266, ptr %t259, i64 %t260)
  %t267 = getelementptr i8, ptr %t266, i64 %t260
  call void @olang_textcopy(ptr %t267, ptr %t262, i64 %t263)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t265, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = extractvalue { i64, ptr } %t269, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t277 = load ptr, ptr %l162, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t277, { i64, ptr } %t276)
  br label %bb44
bb44:
  %t279 = load i1, ptr %l25, !tbaa !21
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d319, i32 0, i32 1) })
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l24, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d320, i32 0, i32 1) })
  br label %bb49
bb49:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  store i64 0, ptr %l30, !tbaa !24
  %t285 = load i64, ptr %l6, !tbaa !24
  store i64 %t285, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t287 = load i64, ptr %l31, !tbaa !24
  %t288 = load i64, ptr %l30, !tbaa !24
  %t291 = icmp sgt i64 %t287, %t288
  br i1 %t291, label %bb51, label %bb52
bb51:
  %t293 = load i64, ptr %l32, !tbaa !24
  %t295 = icmp sgt i64 %t293, 0
  br i1 %t295, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb56
bb53:
  %t297 = load i64, ptr %l31, !tbaa !24
  %t298 = load i64, ptr %l30, !tbaa !24
  %t301 = sub i64 %t297, %t298
  %t302 = load i64, ptr %l32, !tbaa !24
  %t305 = add i64 %t301, %t302
  %t307 = sub i64 %t305, 1
  %t308 = load i64, ptr %l32, !tbaa !24
  %t311 = sdiv i64 %t307, %t308
  store i64 %t311, ptr %l179, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb55
bb55:
  %t313 = load i64, ptr %l179, !tbaa !24
  store i64 %t313, ptr %l176, !tbaa !24
  br label %bb56
bb56:
  %t314 = load i64, ptr %l176, !tbaa !24
  store i64 %t314, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t315 = load i64, ptr %l34, !tbaa !24
  %t316 = load i64, ptr %l33, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb70
bb59:
  br label %bb60
bb60:
  %t323 = load i64, ptr %l30, !tbaa !24
  %t324 = load i64, ptr %l34, !tbaa !24
  %t325 = load i64, ptr %l32, !tbaa !24
  %t328 = mul i64 %t324, %t325
  %t331 = add i64 %t323, %t328
  store i64 %t331, ptr %l35, !tbaa !24
  %t333 = load i64, ptr %l22, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t339 = add i64 %t333, %t336
  %t340 = load i64, ptr %l35, !tbaa !24
  %t343 = add i64 %t339, %t340
  %t345 = load i64, ptr %l35, !tbaa !24
  %t347 = load i64, ptr %l35, !tbaa !24
  %t348 = load i64, ptr %l35, !tbaa !24
  %t349 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t350 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t352 = call i64 @__olang_fmt_i64(ptr null, i64 %t345)
  %t353 = add i64 %t350, %t352
  %t354 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t358 = call i64 @__olang_fmt_i64(ptr null, i64 %t343)
  %t359 = add i64 %t356, %t358
  %t360 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t362 = add i64 %t359, %t361
  %t364 = call i64 @__olang_fmt_i64(ptr null, i64 %t347)
  %t365 = add i64 %t362, %t364
  %t366 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t368 = add i64 %t365, %t367
  %t370 = call i64 @__olang_fmt_i64(ptr null, i64 %t348)
  %t371 = add i64 %t368, %t370
  %t372 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t374 = add i64 %t371, %t373
  %t375 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t374)
  call void @olang_textcopy(ptr %t375, ptr %t349, i64 %t350)
  %t376 = getelementptr i8, ptr %t375, i64 %t350
  %t377 = call i64 @__olang_fmt_i64(ptr %t376, i64 %t345)
  %t378 = getelementptr i8, ptr %t376, i64 %t352
  call void @olang_textcopy(ptr %t378, ptr %t354, i64 %t355)
  %t379 = getelementptr i8, ptr %t378, i64 %t355
  %t380 = call i64 @__olang_fmt_i64(ptr %t379, i64 %t343)
  %t381 = getelementptr i8, ptr %t379, i64 %t358
  call void @olang_textcopy(ptr %t381, ptr %t360, i64 %t361)
  %t382 = getelementptr i8, ptr %t381, i64 %t361
  %t383 = call i64 @__olang_fmt_i64(ptr %t382, i64 %t347)
  %t384 = getelementptr i8, ptr %t382, i64 %t364
  call void @olang_textcopy(ptr %t384, ptr %t366, i64 %t367)
  %t385 = getelementptr i8, ptr %t384, i64 %t367
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t348)
  %t387 = getelementptr i8, ptr %t385, i64 %t370
  call void @olang_textcopy(ptr %t387, ptr %t372, i64 %t373)
  %t388 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t375, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l14, { i64, ptr } %t396)
  br label %bb61
bb61:
  %t399 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s12, ptr %s12, ptr %t399, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d326, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d327, i32 0, i32 1) })
  br label %bb62
bb62:
  %t401 = load i64, ptr %l35, !tbaa !24
  %t402 = load i64, ptr %l35, !tbaa !24
  %t403 = load i64, ptr %l35, !tbaa !24
  %t404 = load i64, ptr %l35, !tbaa !24
  %t405 = load i64, ptr %l35, !tbaa !24
  %t406 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t407 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t409 = call i64 @__olang_fmt_i64(ptr null, i64 %t401)
  %t410 = add i64 %t407, %t409
  %t411 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t412 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t413 = add i64 %t410, %t412
  %t415 = call i64 @__olang_fmt_i64(ptr null, i64 %t402)
  %t416 = add i64 %t413, %t415
  %t417 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t419 = add i64 %t416, %t418
  %t421 = call i64 @__olang_fmt_i64(ptr null, i64 %t403)
  %t422 = add i64 %t419, %t421
  %t423 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t425 = add i64 %t422, %t424
  %t427 = call i64 @__olang_fmt_i64(ptr null, i64 %t404)
  %t428 = add i64 %t425, %t427
  %t429 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t431 = add i64 %t428, %t430
  %t433 = call i64 @__olang_fmt_i64(ptr null, i64 %t405)
  %t434 = add i64 %t431, %t433
  %t435 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t437 = add i64 %t434, %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t406, i64 %t407)
  %t439 = getelementptr i8, ptr %t438, i64 %t407
  %t440 = call i64 @__olang_fmt_i64(ptr %t439, i64 %t401)
  %t441 = getelementptr i8, ptr %t439, i64 %t409
  call void @olang_textcopy(ptr %t441, ptr %t411, i64 %t412)
  %t442 = getelementptr i8, ptr %t441, i64 %t412
  %t443 = call i64 @__olang_fmt_i64(ptr %t442, i64 %t402)
  %t444 = getelementptr i8, ptr %t442, i64 %t415
  call void @olang_textcopy(ptr %t444, ptr %t417, i64 %t418)
  %t445 = getelementptr i8, ptr %t444, i64 %t418
  %t446 = call i64 @__olang_fmt_i64(ptr %t445, i64 %t403)
  %t447 = getelementptr i8, ptr %t445, i64 %t421
  call void @olang_textcopy(ptr %t447, ptr %t423, i64 %t424)
  %t448 = getelementptr i8, ptr %t447, i64 %t424
  %t449 = call i64 @__olang_fmt_i64(ptr %t448, i64 %t404)
  %t450 = getelementptr i8, ptr %t448, i64 %t427
  call void @olang_textcopy(ptr %t450, ptr %t429, i64 %t430)
  %t451 = getelementptr i8, ptr %t450, i64 %t430
  %t452 = call i64 @__olang_fmt_i64(ptr %t451, i64 %t405)
  %t453 = getelementptr i8, ptr %t451, i64 %t433
  call void @olang_textcopy(ptr %t453, ptr %t435, i64 %t436)
  %t454 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t438, 1
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t458 = extractvalue { i64, ptr } %t455, 1
  %t459 = mul i64 %t457, 1
  %t460 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t460, ptr %t458, i64 %t459, i1 false)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t460, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l14, { i64, ptr } %t462)
  br label %bb63
bb63:
  %t465 = load i1, ptr %l25, !tbaa !21
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d334, i32 0, i32 1) })
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  %t470 = load i64, ptr %l35, !tbaa !24
  %t471 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t474 = call i64 @__olang_fmt_i64(ptr null, i64 %t470)
  %t475 = add i64 %t472, %t474
  %t476 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t475)
  call void @olang_textcopy(ptr %t476, ptr %t471, i64 %t472)
  %t477 = getelementptr i8, ptr %t476, i64 %t472
  %t478 = call i64 @__olang_fmt_i64(ptr %t477, i64 %t470)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t476, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = extractvalue { i64, ptr } %t480, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l24, { i64, ptr } %t487)
  br label %bb68
bb68:
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb69:
  %t490 = load i64, ptr %l34, !tbaa !24
  %t492 = add i64 %t490, 1
  store i64 %t492, ptr %l34, !tbaa !24
  br label %bb57
bb70:
  store i64 0, ptr %l37, !tbaa !24
  %t494 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t494, 0
  store i64 %t496, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t498 = load i64, ptr %l38, !tbaa !24
  %t499 = load i64, ptr %l37, !tbaa !24
  %t502 = icmp sgt i64 %t498, %t499
  br i1 %t502, label %bb71, label %bb72
bb71:
  %t504 = load i64, ptr %l39, !tbaa !24
  %t506 = icmp sgt i64 %t504, 0
  br i1 %t506, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l233, !tbaa !24
  br label %bb76
bb73:
  %t508 = load i64, ptr %l38, !tbaa !24
  %t509 = load i64, ptr %l37, !tbaa !24
  %t512 = sub i64 %t508, %t509
  %t513 = load i64, ptr %l39, !tbaa !24
  %t516 = add i64 %t512, %t513
  %t518 = sub i64 %t516, 1
  %t519 = load i64, ptr %l39, !tbaa !24
  %t522 = sdiv i64 %t518, %t519
  store i64 %t522, ptr %l236, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb75
bb75:
  %t524 = load i64, ptr %l236, !tbaa !24
  store i64 %t524, ptr %l233, !tbaa !24
  br label %bb76
bb76:
  %t525 = load i64, ptr %l233, !tbaa !24
  store i64 %t525, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s19
  %t526 = load i64, ptr %l41, !tbaa !24
  %t527 = load i64, ptr %l40, !tbaa !24
  %t530 = icmp slt i64 %t526, %t527
  %t532 = xor i1 %t530, true
  br i1 %t532, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s19)
  br label %bb106
bb79:
  br label %bb80
bb80:
  %t534 = load i64, ptr %l37, !tbaa !24
  %t535 = load i64, ptr %l41, !tbaa !24
  %t536 = load i64, ptr %l39, !tbaa !24
  %t539 = mul i64 %t535, %t536
  %t542 = add i64 %t534, %t539
  store i64 %t542, ptr %l42, !tbaa !24
  %t544 = load i64, ptr %l22, !tbaa !24
  %t545 = load i64, ptr %l42, !tbaa !24
  %t548 = add i64 %t544, %t545
  store i64 %t548, ptr %l43, !tbaa !24
  %t550 = load ptr, ptr %l10, !tbaa !29
  %t551 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t551, ptr %l258, !tbaa !27
  %t552 = load i64, ptr %l42, !tbaa !24
  %t554 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr i32, ptr %t555, i64 %t552
  %t557 = load i32, ptr %t556, !tbaa !33
  %t560 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s19, ptr %t550, i32 %t557)
  store { i64, ptr } %t560, ptr %l261
  br label %bb81
bb81:
  %t561 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t561, ptr %l44, !tbaa !27
  %t562 = load i1, ptr %l25, !tbaa !21
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d336, i32 0, i32 1) })
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s20)
  br label %bb85
bb85:
  store i1 false, ptr %l25, !tbaa !21
  %t567 = load i64, ptr %l42, !tbaa !24
  %t569 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !27
  %t571 = getelementptr i8, ptr %t570, i64 %t567
  %t572 = load i8, ptr %t571, !tbaa !32
  store i8 %t572, ptr %l45, !tbaa !22
  %t574 = load i8, ptr %l45, !tbaa !22
  %t576 = icmp eq i8 %t574, 109
  br i1 %t576, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb90
bb88:
  store %olang.scope zeroinitializer, ptr %s21
  %t578 = load i64, ptr %l43, !tbaa !24
  %t579 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t582 = call i64 @__olang_fmt_i64(ptr null, i64 %t578)
  %t583 = add i64 %t580, %t582
  %t584 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t583)
  call void @olang_textcopy(ptr %t584, ptr %t579, i64 %t580)
  %t585 = getelementptr i8, ptr %t584, i64 %t580
  %t586 = call i64 @__olang_fmt_i64(ptr %t585, i64 %t578)
  %t587 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t584, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = extractvalue { i64, ptr } %t588, 1
  %t592 = mul i64 %t590, 1
  %t593 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t592)
  call void @llvm.memcpy.p0.p0.i64(ptr %t593, ptr %t591, i64 %t592, i1 false)
  %t594 = insertvalue { i64, ptr } undef, i64 %t590, 0
  %t595 = insertvalue { i64, ptr } %t594, ptr %t593, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %l24, { i64, ptr } %t595)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb90:
  %t598 = load i8, ptr %l45, !tbaa !22
  %t600 = icmp eq i8 %t598, 115
  br i1 %t600, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb97
bb93:
  store %olang.scope zeroinitializer, ptr %s23
  %t602 = load i64, ptr %l42, !tbaa !24
  %t603 = load i64, ptr %l43, !tbaa !24
  %t604 = load i64, ptr %l42, !tbaa !24
  %t605 = load i64, ptr %l42, !tbaa !24
  %t606 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t607 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t609 = call i64 @__olang_fmt_i64(ptr null, i64 %t602)
  %t610 = add i64 %t607, %t609
  %t611 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t612 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t613 = add i64 %t610, %t612
  %t615 = call i64 @__olang_fmt_i64(ptr null, i64 %t603)
  %t616 = add i64 %t613, %t615
  %t617 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t618 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t619 = add i64 %t616, %t618
  %t621 = call i64 @__olang_fmt_i64(ptr null, i64 %t604)
  %t622 = add i64 %t619, %t621
  %t623 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t624 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t625 = add i64 %t622, %t624
  %t627 = call i64 @__olang_fmt_i64(ptr null, i64 %t605)
  %t628 = add i64 %t625, %t627
  %t629 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t630 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t631 = add i64 %t628, %t630
  %t632 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t631)
  call void @olang_textcopy(ptr %t632, ptr %t606, i64 %t607)
  %t633 = getelementptr i8, ptr %t632, i64 %t607
  %t634 = call i64 @__olang_fmt_i64(ptr %t633, i64 %t602)
  %t635 = getelementptr i8, ptr %t633, i64 %t609
  call void @olang_textcopy(ptr %t635, ptr %t611, i64 %t612)
  %t636 = getelementptr i8, ptr %t635, i64 %t612
  %t637 = call i64 @__olang_fmt_i64(ptr %t636, i64 %t603)
  %t638 = getelementptr i8, ptr %t636, i64 %t615
  call void @olang_textcopy(ptr %t638, ptr %t617, i64 %t618)
  %t639 = getelementptr i8, ptr %t638, i64 %t618
  %t640 = call i64 @__olang_fmt_i64(ptr %t639, i64 %t604)
  %t641 = getelementptr i8, ptr %t639, i64 %t621
  call void @olang_textcopy(ptr %t641, ptr %t623, i64 %t624)
  %t642 = getelementptr i8, ptr %t641, i64 %t624
  %t643 = call i64 @__olang_fmt_i64(ptr %t642, i64 %t605)
  %t644 = getelementptr i8, ptr %t642, i64 %t627
  call void @olang_textcopy(ptr %t644, ptr %t629, i64 %t630)
  %t645 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t632, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = extractvalue { i64, ptr } %t646, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l14, { i64, ptr } %t653)
  br label %bb94
bb94:
  %t656 = load i64, ptr %l42, !tbaa !24
  %t657 = load i64, ptr %l42, !tbaa !24
  %t658 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t661 = call i64 @__olang_fmt_i64(ptr null, i64 %t656)
  %t662 = add i64 %t659, %t661
  %t663 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t664 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t665 = add i64 %t662, %t664
  %t667 = call i64 @__olang_fmt_i64(ptr null, i64 %t657)
  %t668 = add i64 %t665, %t667
  %t669 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t670 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t671 = add i64 %t668, %t670
  %t672 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t671)
  call void @olang_textcopy(ptr %t672, ptr %t658, i64 %t659)
  %t673 = getelementptr i8, ptr %t672, i64 %t659
  %t674 = call i64 @__olang_fmt_i64(ptr %t673, i64 %t656)
  %t675 = getelementptr i8, ptr %t673, i64 %t661
  call void @olang_textcopy(ptr %t675, ptr %t663, i64 %t664)
  %t676 = getelementptr i8, ptr %t675, i64 %t664
  %t677 = call i64 @__olang_fmt_i64(ptr %t676, i64 %t657)
  %t678 = getelementptr i8, ptr %t676, i64 %t667
  call void @olang_textcopy(ptr %t678, ptr %t669, i64 %t670)
  %t679 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t672, 1
  %t682 = extractvalue { i64, ptr } %t680, 0
  %t683 = extractvalue { i64, ptr } %t680, 1
  %t684 = mul i64 %t682, 1
  %t685 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t684)
  call void @llvm.memcpy.p0.p0.i64(ptr %t685, ptr %t683, i64 %t684, i1 false)
  %t686 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t687 = insertvalue { i64, ptr } %t686, ptr %t685, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l14, { i64, ptr } %t687)
  br label %bb95
bb95:
  %t690 = load i64, ptr %l42, !tbaa !24
  %t691 = load i64, ptr %l42, !tbaa !24
  %t692 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t693 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t695 = call i64 @__olang_fmt_i64(ptr null, i64 %t690)
  %t696 = add i64 %t693, %t695
  %t697 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t701 = call i64 @__olang_fmt_i64(ptr null, i64 %t691)
  %t702 = add i64 %t699, %t701
  %t703 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t702)
  call void @olang_textcopy(ptr %t703, ptr %t692, i64 %t693)
  %t704 = getelementptr i8, ptr %t703, i64 %t693
  %t705 = call i64 @__olang_fmt_i64(ptr %t704, i64 %t690)
  %t706 = getelementptr i8, ptr %t704, i64 %t695
  call void @olang_textcopy(ptr %t706, ptr %t697, i64 %t698)
  %t707 = getelementptr i8, ptr %t706, i64 %t698
  %t708 = call i64 @__olang_fmt_i64(ptr %t707, i64 %t691)
  %t709 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t703, 1
  %t712 = extractvalue { i64, ptr } %t710, 0
  %t713 = extractvalue { i64, ptr } %t710, 1
  %t714 = mul i64 %t712, 1
  %t715 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t715, ptr %t713, i64 %t714, i1 false)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l24, { i64, ptr } %t717)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  store %olang.scope zeroinitializer, ptr %s27
  %t720 = load i64, ptr %l42, !tbaa !24
  %t721 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t722 = load i64, ptr %l43, !tbaa !24
  %t723 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t724 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t726 = call i64 @__olang_fmt_i64(ptr null, i64 %t720)
  %t727 = add i64 %t724, %t726
  %t728 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t730 = add i64 %t727, %t729
  %t732 = extractvalue { i64, ptr } %t721, 1
  %t733 = extractvalue { i64, ptr } %t721, 0
  %t734 = add i64 %t730, %t733
  %t735 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t736 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t737 = add i64 %t734, %t736
  %t739 = call i64 @__olang_fmt_i64(ptr null, i64 %t722)
  %t740 = add i64 %t737, %t739
  %t741 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t743 = add i64 %t740, %t742
  %t744 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t743)
  call void @olang_textcopy(ptr %t744, ptr %t723, i64 %t724)
  %t745 = getelementptr i8, ptr %t744, i64 %t724
  %t746 = call i64 @__olang_fmt_i64(ptr %t745, i64 %t720)
  %t747 = getelementptr i8, ptr %t745, i64 %t726
  call void @olang_textcopy(ptr %t747, ptr %t728, i64 %t729)
  %t748 = getelementptr i8, ptr %t747, i64 %t729
  call void @olang_textcopy(ptr %t748, ptr %t732, i64 %t733)
  %t749 = getelementptr i8, ptr %t748, i64 %t733
  call void @olang_textcopy(ptr %t749, ptr %t735, i64 %t736)
  %t750 = getelementptr i8, ptr %t749, i64 %t736
  %t751 = call i64 @__olang_fmt_i64(ptr %t750, i64 %t722)
  %t752 = getelementptr i8, ptr %t750, i64 %t739
  call void @olang_textcopy(ptr %t752, ptr %t741, i64 %t742)
  %t753 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t744, 1
  %t756 = extractvalue { i64, ptr } %t754, 0
  %t757 = extractvalue { i64, ptr } %t754, 1
  %t758 = mul i64 %t756, 1
  %t759 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t758)
  call void @llvm.memcpy.p0.p0.i64(ptr %t759, ptr %t757, i64 %t758, i1 false)
  %t760 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t759, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l14, { i64, ptr } %t761)
  br label %bb101
bb101:
  %t764 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t765 = load i64, ptr %l42, !tbaa !24
  %t767 = extractvalue { i64, ptr } %t764, 1
  %t768 = extractvalue { i64, ptr } %t764, 0
  %t769 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t773 = call i64 @__olang_fmt_i64(ptr null, i64 %t765)
  %t774 = add i64 %t771, %t773
  %t775 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t774)
  call void @olang_textcopy(ptr %t775, ptr %t767, i64 %t768)
  %t776 = getelementptr i8, ptr %t775, i64 %t768
  call void @olang_textcopy(ptr %t776, ptr %t769, i64 %t770)
  %t777 = getelementptr i8, ptr %t776, i64 %t770
  %t778 = call i64 @__olang_fmt_i64(ptr %t777, i64 %t765)
  %t779 = insertvalue { i64, ptr } undef, i64 %t774, 0
  %t780 = insertvalue { i64, ptr } %t779, ptr %t775, 1
  %t782 = extractvalue { i64, ptr } %t780, 0
  %t783 = extractvalue { i64, ptr } %t780, 1
  %t784 = mul i64 %t782, 1
  %t785 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t784)
  call void @llvm.memcpy.p0.p0.i64(ptr %t785, ptr %t783, i64 %t784, i1 false)
  %t786 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t785, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l24, { i64, ptr } %t787)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s27)
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_7b5945deb51ea5cf_9b8856c6d1bef1b3)
  unreachable
bb104:
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb105:
  %t790 = load i64, ptr %l41, !tbaa !24
  %t792 = add i64 %t790, 1
  store i64 %t792, ptr %l41, !tbaa !24
  br label %bb77
bb106:
  %t794 = load ptr, ptr %l11, !tbaa !29
  %t795 = load i32, ptr %l5, !tbaa !23
  %t798 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t794, i32 %t795)
  store { i64, ptr } %t798, ptr %l307
  br label %bb107
bb107:
  %t799 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t799, ptr %l46, !tbaa !27
  %t800 = load ptr, ptr %l11, !tbaa !29
  store ptr %t800, ptr %l308, !tbaa !29
  %t801 = load ptr, ptr %l11, !tbaa !29
  %t802 = load i32, ptr %l5, !tbaa !23
  %t805 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t801, i32 %t802)
  store i32 %t805, ptr %l311
  br label %bb108
bb108:
  %t806 = load ptr, ptr %l308, !tbaa !29
  %t807 = load i32, ptr %l311, !tbaa !23
  %t808 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t806, i32 %t807)
  store { i64, ptr } %t808, ptr %l312
  br label %bb109
bb109:
  %t809 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t809, 0
  %t812 = icmp sgt i64 %t810, 0
  store i1 %t812, ptr %l47, !tbaa !21
  %t814 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t816 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t814, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d353, i32 0, i32 1) })
  store i1 %t816, ptr %l316
  br label %bb110
bb110:
  %t817 = load i1, ptr %l316, !tbaa !21
  br i1 %t817, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s31
  store ptr %l14, ptr %l317, !tbaa !29
  %t818 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t818, ptr %l318, !tbaa !27
  %t820 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s31, ptr %l24)
  store { i64, ptr } %t820, ptr %l320
  br label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l14, ptr %l323, !tbaa !29
  %t821 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t821, ptr %l324, !tbaa !27
  %t822 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t822, ptr %l325, !tbaa !27
  %t824 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s33, ptr %l24)
  store { i64, ptr } %t824, ptr %l327
  br label %bb115
bb113:
  %t825 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t826 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t827 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t827, 1
  %t829 = extractvalue { i64, ptr } %t827, 0
  %t830 = add i64 %t826, %t829
  %t831 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t832 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t833 = add i64 %t830, %t832
  %t834 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t834, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = add i64 %t833, %t836
  %t838 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t839 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t840 = add i64 %t837, %t839
  %t841 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t840)
  call void @olang_textcopy(ptr %t841, ptr %t825, i64 %t826)
  %t842 = getelementptr i8, ptr %t841, i64 %t826
  call void @olang_textcopy(ptr %t842, ptr %t828, i64 %t829)
  %t843 = getelementptr i8, ptr %t842, i64 %t829
  call void @olang_textcopy(ptr %t843, ptr %t831, i64 %t832)
  %t844 = getelementptr i8, ptr %t843, i64 %t832
  call void @olang_textcopy(ptr %t844, ptr %t835, i64 %t836)
  %t845 = getelementptr i8, ptr %t844, i64 %t836
  call void @olang_textcopy(ptr %t845, ptr %t838, i64 %t839)
  %t846 = insertvalue { i64, ptr } undef, i64 %t840, 0
  %t847 = insertvalue { i64, ptr } %t846, ptr %t841, 1
  %t849 = extractvalue { i64, ptr } %t847, 0
  %t850 = extractvalue { i64, ptr } %t847, 1
  %t851 = mul i64 %t849, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t851)
  call void @llvm.memcpy.p0.p0.i64(ptr %t852, ptr %t850, i64 %t851, i1 false)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  %t855 = load ptr, ptr %l317, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %t855, { i64, ptr } %t854)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s31)
  br label %bb117
bb115:
  %t857 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t858 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t859 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t859, 1
  %t861 = extractvalue { i64, ptr } %t859, 0
  %t862 = add i64 %t858, %t861
  %t863 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t865 = add i64 %t862, %t864
  %t866 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = add i64 %t865, %t868
  %t870 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t871 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t872 = add i64 %t869, %t871
  %t873 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t874 = extractvalue { i64, ptr } %t873, 1
  %t875 = extractvalue { i64, ptr } %t873, 0
  %t876 = add i64 %t872, %t875
  %t877 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t878 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t879 = add i64 %t876, %t878
  %t880 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t879)
  call void @olang_textcopy(ptr %t880, ptr %t857, i64 %t858)
  %t881 = getelementptr i8, ptr %t880, i64 %t858
  call void @olang_textcopy(ptr %t881, ptr %t860, i64 %t861)
  %t882 = getelementptr i8, ptr %t881, i64 %t861
  call void @olang_textcopy(ptr %t882, ptr %t863, i64 %t864)
  %t883 = getelementptr i8, ptr %t882, i64 %t864
  call void @olang_textcopy(ptr %t883, ptr %t867, i64 %t868)
  %t884 = getelementptr i8, ptr %t883, i64 %t868
  call void @olang_textcopy(ptr %t884, ptr %t870, i64 %t871)
  %t885 = getelementptr i8, ptr %t884, i64 %t871
  call void @olang_textcopy(ptr %t885, ptr %t874, i64 %t875)
  %t886 = getelementptr i8, ptr %t885, i64 %t875
  call void @olang_textcopy(ptr %t886, ptr %t877, i64 %t878)
  %t887 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t888 = insertvalue { i64, ptr } %t887, ptr %t880, 1
  %t890 = extractvalue { i64, ptr } %t888, 0
  %t891 = extractvalue { i64, ptr } %t888, 1
  %t892 = mul i64 %t890, 1
  %t893 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t892)
  call void @llvm.memcpy.p0.p0.i64(ptr %t893, ptr %t891, i64 %t892, i1 false)
  %t894 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t893, 1
  %t896 = load ptr, ptr %l323, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %t896, { i64, ptr } %t895)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s33)
  br label %bb117
bb117:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d361, i32 0, i32 1) }, ptr %l330, !tbaa !27
  %t898 = load { i64, ptr }, ptr %l330, !tbaa !27
  store { i64, ptr } %t898, ptr %l331, !tbaa !27
  %t899 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t900 = extractvalue { i64, ptr } %t899, 0
  store i64 %t900, ptr %l332, !tbaa !24
  %t901 = load i64, ptr %l332, !tbaa !24
  %t902 = mul i64 %t901, 1
  %t903 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t902)
  %t904 = insertvalue { i64, ptr } undef, i64 %t901, 0
  %t905 = insertvalue { i64, ptr } %t904, ptr %t903, 1
  store { i64, ptr } %t905, ptr %l333, !tbaa !27
  %t906 = getelementptr { i64, ptr }, ptr %l333, i32 0, i32 1
  %t907 = load ptr, ptr %t906, !tbaa !27
  %t908 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t909 = load ptr, ptr %t908, !tbaa !27
  %t910 = load i64, ptr %l332, !tbaa !24
  %t911 = mul i64 %t910, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t907, ptr %t909, i64 %t911, i1 false)
  %t912 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t912, ptr %l48, !tbaa !27
  %t913 = load i1, ptr %l29, !tbaa !21
  br i1 %t913, label %bb118, label %bb119
bb118:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d362, i32 0, i32 1) }, ptr %l335, !tbaa !27
  %t915 = load { i64, ptr }, ptr %l335, !tbaa !27
  store { i64, ptr } %t915, ptr %l336, !tbaa !27
  %t916 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t917 = extractvalue { i64, ptr } %t916, 0
  %t918 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t919 = extractvalue { i64, ptr } %t918, 0
  store i64 %t919, ptr %l338, !tbaa !24
  %t921 = load i64, ptr %l338, !tbaa !24
  %t922 = icmp eq i64 %t917, %t921
  br i1 %t922, label %bb120, label %bb121
bb119:
  %t924 = load i32, ptr %l28, !tbaa !23
  %t925 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t928 = icmp ne i32 %t924, %t925
  br i1 %t928, label %bb123, label %bb124
bb120:
  %t930 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t931 = load ptr, ptr %t930, !tbaa !27
  %t932 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t933 = load ptr, ptr %t932, !tbaa !27
  %t934 = load i64, ptr %l338, !tbaa !24
  %t935 = mul i64 %t934, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t931, ptr %t933, i64 %t935, i1 false)
  br label %bb122
bb121:
  %t936 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 0
  store i64 %t937, ptr %l340, !tbaa !24
  %t938 = load i64, ptr %l340, !tbaa !24
  %t939 = mul i64 %t938, 1
  %t940 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t939)
  %t941 = insertvalue { i64, ptr } undef, i64 %t938, 0
  %t942 = insertvalue { i64, ptr } %t941, ptr %t940, 1
  store { i64, ptr } %t942, ptr %l341, !tbaa !27
  %t943 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t944 = load ptr, ptr %t943, !tbaa !27
  %t945 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t946 = load ptr, ptr %t945, !tbaa !27
  %t947 = load i64, ptr %l340, !tbaa !24
  %t948 = mul i64 %t947, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t944, ptr %t946, i64 %t948, i1 false)
  %t949 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t949, ptr %l48, !tbaa !27
  br label %bb122
bb122:
  br label %bb139
bb123:
  %t950 = load i32, ptr %l28, !tbaa !23
  %t951 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t954 = icmp ne i32 %t950, %t951
  store i1 %t954, ptr %l345, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb125
bb125:
  %t956 = load i1, ptr %l345, !tbaa !21
  br i1 %t956, label %bb126, label %bb127
bb126:
  %t957 = load i1, ptr %l47, !tbaa !21
  br i1 %t957, label %bb128, label %bb129
bb127:
  br label %bb138
bb128:
  store %olang.scope zeroinitializer, ptr %s38
  %t959 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t960 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t961 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t963 = extractvalue { i64, ptr } %t959, 1
  %t964 = extractvalue { i64, ptr } %t959, 0
  %t965 = add i64 %t961, %t964
  %t966 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t967 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t968 = add i64 %t965, %t967
  %t969 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t968)
  call void @olang_textcopy(ptr %t969, ptr %t960, i64 %t961)
  %t970 = getelementptr i8, ptr %t969, i64 %t961
  call void @olang_textcopy(ptr %t970, ptr %t963, i64 %t964)
  %t971 = getelementptr i8, ptr %t970, i64 %t964
  call void @olang_textcopy(ptr %t971, ptr %t966, i64 %t967)
  %t972 = insertvalue { i64, ptr } undef, i64 %t968, 0
  %t973 = insertvalue { i64, ptr } %t972, ptr %t969, 1
  %t975 = extractvalue { i64, ptr } %t973, 0
  %t976 = extractvalue { i64, ptr } %t973, 1
  %t977 = mul i64 %t975, 1
  %t978 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t977)
  call void @llvm.memcpy.p0.p0.i64(ptr %t978, ptr %t976, i64 %t977, i1 false)
  %t979 = insertvalue { i64, ptr } undef, i64 %t975, 0
  %t980 = insertvalue { i64, ptr } %t979, ptr %t978, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s38, ptr %l14, { i64, ptr } %t980)
  br label %bb130
bb129:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d365, i32 0, i32 1) }, ptr %l361, !tbaa !27
  %t983 = load { i64, ptr }, ptr %l361, !tbaa !27
  store { i64, ptr } %t983, ptr %l362, !tbaa !27
  %t984 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t985 = extractvalue { i64, ptr } %t984, 0
  %t986 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t987 = extractvalue { i64, ptr } %t986, 0
  store i64 %t987, ptr %l364, !tbaa !24
  %t989 = load i64, ptr %l364, !tbaa !24
  %t990 = icmp eq i64 %t985, %t989
  br i1 %t990, label %bb134, label %bb135
bb130:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d366, i32 0, i32 1) }, ptr %l354, !tbaa !27
  %t992 = load { i64, ptr }, ptr %l354, !tbaa !27
  store { i64, ptr } %t992, ptr %l355, !tbaa !27
  %t993 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t993, 0
  %t995 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t996 = extractvalue { i64, ptr } %t995, 0
  store i64 %t996, ptr %l357, !tbaa !24
  %t998 = load i64, ptr %l357, !tbaa !24
  %t999 = icmp eq i64 %t994, %t998
  br i1 %t999, label %bb131, label %bb132
bb131:
  %t1001 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t1004 = load ptr, ptr %t1003, !tbaa !27
  %t1005 = load i64, ptr %l357, !tbaa !24
  %t1006 = mul i64 %t1005, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1002, ptr %t1004, i64 %t1006, i1 false)
  br label %bb133
bb132:
  %t1007 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t1008 = extractvalue { i64, ptr } %t1007, 0
  store i64 %t1008, ptr %l359, !tbaa !24
  %t1009 = load i64, ptr %l359, !tbaa !24
  %t1010 = mul i64 %t1009, 1
  %t1011 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1010)
  %t1012 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1013 = insertvalue { i64, ptr } %t1012, ptr %t1011, 1
  store { i64, ptr } %t1013, ptr %l360, !tbaa !27
  %t1014 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t1015 = load ptr, ptr %t1014, !tbaa !27
  %t1016 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t1017 = load ptr, ptr %t1016, !tbaa !27
  %t1018 = load i64, ptr %l359, !tbaa !24
  %t1019 = mul i64 %t1018, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1015, ptr %t1017, i64 %t1019, i1 false)
  %t1020 = load { i64, ptr }, ptr %l360, !tbaa !27
  store { i64, ptr } %t1020, ptr %l48, !tbaa !27
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s38)
  br label %bb137
bb134:
  %t1021 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t1022 = load ptr, ptr %t1021, !tbaa !27
  %t1023 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t1024 = load ptr, ptr %t1023, !tbaa !27
  %t1025 = load i64, ptr %l364, !tbaa !24
  %t1026 = mul i64 %t1025, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1022, ptr %t1024, i64 %t1026, i1 false)
  br label %bb136
bb135:
  %t1027 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t1028 = extractvalue { i64, ptr } %t1027, 0
  store i64 %t1028, ptr %l366, !tbaa !24
  %t1029 = load i64, ptr %l366, !tbaa !24
  %t1030 = mul i64 %t1029, 1
  %t1031 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1030)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1029, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1031, 1
  store { i64, ptr } %t1033, ptr %l367, !tbaa !27
  %t1034 = getelementptr { i64, ptr }, ptr %l367, i32 0, i32 1
  %t1035 = load ptr, ptr %t1034, !tbaa !27
  %t1036 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t1037 = load ptr, ptr %t1036, !tbaa !27
  %t1038 = load i64, ptr %l366, !tbaa !24
  %t1039 = mul i64 %t1038, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1035, ptr %t1037, i64 %t1039, i1 false)
  %t1040 = load { i64, ptr }, ptr %l367, !tbaa !27
  store { i64, ptr } %t1040, ptr %l48, !tbaa !27
  br label %bb136
bb136:
  br label %bb137
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t1041 = load i1, ptr %l47, !tbaa !21
  br i1 %t1041, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s41
  %t1043 = load i1, ptr %l29, !tbaa !21
  br i1 %t1043, label %bb142, label %bb143
bb141:
  br label %bb163
bb142:
  store i1 true, ptr %l370, !tbaa !21
  br label %bb144
bb143:
  %t1045 = load i32, ptr %l28, !tbaa !23
  %t1046 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1049 = icmp eq i32 %t1045, %t1046
  store i1 %t1049, ptr %l370, !tbaa !21
  br label %bb144
bb144:
  %t1051 = load i1, ptr %l370, !tbaa !21
  br i1 %t1051, label %bb145, label %bb146
bb145:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d367, i32 0, i32 1) }, ptr %l374, !tbaa !27
  br label %bb147
bb146:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d368, i32 0, i32 1) }, ptr %l374, !tbaa !27
  br label %bb147
bb147:
  %t1052 = load { i64, ptr }, ptr %l374, !tbaa !27
  store { i64, ptr } %t1052, ptr %l49, !tbaa !27
  %t1053 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1054 = load ptr, ptr @__olang_prog_scope
  %t1056 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t1054, ptr %s41, { i64, ptr } %t1053, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d369, i32 0, i32 1) })
  store i1 %t1056, ptr %l376
  br label %bb148
bb148:
  %t1057 = load i1, ptr %l376, !tbaa !21
  br i1 %t1057, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s42
  %t1058 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t1059 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t1060 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t1062 = extractvalue { i64, ptr } %t1058, 1
  %t1063 = extractvalue { i64, ptr } %t1058, 0
  %t1064 = add i64 %t1060, %t1063
  %t1065 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t1066 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t1067 = add i64 %t1064, %t1066
  %t1068 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1067)
  call void @olang_textcopy(ptr %t1068, ptr %t1059, i64 %t1060)
  %t1069 = getelementptr i8, ptr %t1068, i64 %t1060
  call void @olang_textcopy(ptr %t1069, ptr %t1062, i64 %t1063)
  %t1070 = getelementptr i8, ptr %t1069, i64 %t1063
  call void @olang_textcopy(ptr %t1070, ptr %t1065, i64 %t1066)
  %t1071 = insertvalue { i64, ptr } undef, i64 %t1067, 0
  %t1072 = insertvalue { i64, ptr } %t1071, ptr %t1068, 1
  %t1074 = extractvalue { i64, ptr } %t1072, 0
  %t1075 = extractvalue { i64, ptr } %t1072, 1
  %t1076 = mul i64 %t1074, 1
  %t1077 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1076)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1077, ptr %t1075, i64 %t1076, i1 false)
  %t1078 = insertvalue { i64, ptr } undef, i64 %t1074, 0
  %t1079 = insertvalue { i64, ptr } %t1078, ptr %t1077, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s42, ptr %l14, { i64, ptr } %t1079)
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s42)
  br label %bb152
bb152:
  %t1082 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1083 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t1084 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t1086 = extractvalue { i64, ptr } %t1082, 1
  %t1087 = extractvalue { i64, ptr } %t1082, 0
  %t1088 = add i64 %t1084, %t1087
  %t1089 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t1090 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t1091 = add i64 %t1088, %t1090
  %t1092 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1091)
  call void @olang_textcopy(ptr %t1092, ptr %t1083, i64 %t1084)
  %t1093 = getelementptr i8, ptr %t1092, i64 %t1084
  call void @olang_textcopy(ptr %t1093, ptr %t1086, i64 %t1087)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1087
  call void @olang_textcopy(ptr %t1094, ptr %t1089, i64 %t1090)
  %t1095 = insertvalue { i64, ptr } undef, i64 %t1091, 0
  %t1096 = insertvalue { i64, ptr } %t1095, ptr %t1092, 1
  %t1098 = extractvalue { i64, ptr } %t1096, 0
  %t1099 = extractvalue { i64, ptr } %t1096, 1
  %t1100 = mul i64 %t1098, 1
  %t1101 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1101, ptr %t1099, i64 %t1100, i1 false)
  %t1102 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1103 = insertvalue { i64, ptr } %t1102, ptr %t1101, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %l14, { i64, ptr } %t1103)
  br label %bb153
bb153:
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1107 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1108 = load %"compiler/mir:Task", ptr %l7
  %t1109 = load i32, ptr %l5, !tbaa !23
  %t1110 = load i64, ptr %l22, !tbaa !24
  %t1111 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1113 = extractvalue { i64, ptr } %t1111, 0
  %t1116 = add i64 %t1110, %t1113
  %t1117 = load i64, ptr %l6, !tbaa !24
  %t1120 = add i64 %t1116, %t1117
  %t1121 = load i64, ptr %l12, !tbaa !24
  %t1124 = add i64 %t1120, %t1121
  %t1125 = load i64, ptr %l22, !tbaa !24
  %t1126 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1128 = extractvalue { i64, ptr } %t1126, 0
  %t1131 = add i64 %t1125, %t1128
  %t1132 = load i64, ptr %l6, !tbaa !24
  %t1135 = add i64 %t1131, %t1132
  %t1136 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t1137 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %s0, ptr %t1137, ptr %v4, ptr %t1106, ptr %l14, { i64, ptr } %t1107, %"compiler/mir:Task" %t1108, i32 %t1109, i64 %t1124, i64 %t1135, { i64, ptr } %t1136)
  br label %bb154
bb154:
  %t1146 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 5
  %t1147 = getelementptr %"compiler/mir:Range", ptr %t1146, i32 0, i32 1
  %t1148 = load i32, ptr %t1147, !tbaa !23
  %t1150 = icmp sgt i32 %t1148, 0
  br i1 %t1150, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s45
  %t1152 = load ptr, ptr %l0, !tbaa !29
  %t1153 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1154 = load %"compiler/mir:Task", ptr %l7
  %t1155 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskEnds(ptr %v0, ptr %s0, ptr %t1155, ptr %t1152, ptr %l14, { i64, ptr } %t1153, %"compiler/mir:Task" %t1154)
  br label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s46
  %t1160 = load ptr, ptr %l10, !tbaa !29
  store ptr %t1160, ptr %l412, !tbaa !29
  store ptr %l14, ptr %l413, !tbaa !29
  %t1161 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t1161, ptr %l414, !tbaa !27
  %t1162 = load ptr, ptr %l11, !tbaa !29
  %t1163 = load i32, ptr %l5, !tbaa !23
  %t1166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1162, i32 %t1163)
  store i32 %t1166, ptr %l417
  br label %bb159
bb157:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s45, ptr %l14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d374, i32 0, i32 1) })
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s45)
  br label %bb162
bb159:
  %t1169 = load ptr, ptr @__olang_prog_scope
  %t1170 = load ptr, ptr %l412, !tbaa !29
  %t1171 = load ptr, ptr %l413, !tbaa !29
  %t1172 = load { i64, ptr }, ptr %l414, !tbaa !27
  %t1173 = load i32, ptr %l417, !tbaa !23
  %t1175 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %s0, ptr %t1169, ptr %s46, ptr %t1170, ptr %t1171, { i64, ptr } %t1172, i32 %t1173, i32 %a8)
  store { i64, ptr } %t1175, ptr %l419
  br label %bb160
bb160:
  %t1176 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t1178 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t1179 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t1181 = extractvalue { i64, ptr } %t1176, 1
  %t1182 = extractvalue { i64, ptr } %t1176, 0
  %t1183 = add i64 %t1179, %t1182
  %t1184 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t1185 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t1186 = add i64 %t1183, %t1185
  %t1187 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1186)
  call void @olang_textcopy(ptr %t1187, ptr %t1178, i64 %t1179)
  %t1188 = getelementptr i8, ptr %t1187, i64 %t1179
  call void @olang_textcopy(ptr %t1188, ptr %t1181, i64 %t1182)
  %t1189 = getelementptr i8, ptr %t1188, i64 %t1182
  call void @olang_textcopy(ptr %t1189, ptr %t1184, i64 %t1185)
  %t1190 = insertvalue { i64, ptr } undef, i64 %t1186, 0
  %t1191 = insertvalue { i64, ptr } %t1190, ptr %t1187, 1
  %t1193 = extractvalue { i64, ptr } %t1191, 0
  %t1194 = extractvalue { i64, ptr } %t1191, 1
  %t1195 = mul i64 %t1193, 1
  %t1196 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1196, ptr %t1194, i64 %t1195, i1 false)
  %t1197 = insertvalue { i64, ptr } undef, i64 %t1193, 0
  %t1198 = insertvalue { i64, ptr } %t1197, ptr %t1196, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s46, ptr %l14, { i64, ptr } %t1198)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s46)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s41)
  br label %bb163
bb163:
  %t1201 = load i64, ptr %l12, !tbaa !24
  %t1203 = icmp sgt i64 %t1201, 0
  br i1 %t1203, label %bb164, label %bb165
bb164:
  %t1205 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1205, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d377, i32 0, i32 1) })
  store i1 %t1207, ptr %l428
  br label %bb166
bb165:
  store i1 false, ptr %l426, !tbaa !21
  br label %bb167
bb166:
  %t1208 = load i1, ptr %l428, !tbaa !21
  %t1209 = xor i1 %t1208, true
  store i1 %t1209, ptr %l426, !tbaa !21
  br label %bb167
bb167:
  %t1211 = load i1, ptr %l426, !tbaa !21
  br i1 %t1211, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s48
  %t1212 = load i64, ptr %l22, !tbaa !24
  %t1213 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1215 = extractvalue { i64, ptr } %t1213, 0
  %t1218 = add i64 %t1212, %t1215
  %t1219 = load i64, ptr %l6, !tbaa !24
  %t1222 = add i64 %t1218, %t1219
  store i64 %t1222, ptr %l51, !tbaa !24
  %t1224 = load i1, ptr %l29, !tbaa !21
  br i1 %t1224, label %bb170, label %bb171
bb169:
  br label %bb227
bb170:
  store %olang.scope zeroinitializer, ptr %s49
  %t1226 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s49, ptr %s49, ptr %t1226, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d378, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d379, i32 0, i32 1) })
  br label %bb172
bb171:
  %t1228 = load i64, ptr %l12, !tbaa !24
  %t1230 = icmp eq i64 %t1228, 1
  br i1 %t1230, label %bb200, label %bb201
bb172:
  %t1232 = load ptr, ptr %l10, !tbaa !29
  %t1234 = getelementptr %"compiler/emit:Emitter", ptr %t1232, i32 0, i32 0
  %t1235 = load ptr, ptr %t1234, !tbaa !29
  %t1236 = load i32, ptr %l28, !tbaa !23
  %t1239 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t1235, i32 %t1236)
  store i1 %t1239, ptr %l441
  br label %bb173
bb173:
  %t1240 = load i64, ptr %l12, !tbaa !24
  %t1242 = icmp eq i64 %t1240, 1
  br i1 %t1242, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s50
  store ptr %l14, ptr %l444, !tbaa !29
  %t1244 = load i64, ptr %l51, !tbaa !24
  store i64 %t1244, ptr %l445, !tbaa !24
  %t1245 = load ptr, ptr %l11, !tbaa !29
  %t1246 = load i32, ptr %l28, !tbaa !23
  %t1249 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1245, i32 %t1246)
  store i64 %t1249, ptr %l448
  br label %bb176
bb175:
  %t1250 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1250, ptr %l451, !tbaa !29
  %t1251 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1251, ptr %l452, !tbaa !29
  %t1252 = load ptr, ptr %l11, !tbaa !29
  %t1253 = load i32, ptr %l28, !tbaa !23
  %t1256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1252, i32 %t1253)
  store i32 %t1256, ptr %l455
  br label %bb178
bb176:
  %t1257 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t1258 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t1259 = load i64, ptr %l445, !tbaa !24
  %t1260 = call i64 @__olang_fmt_i64(ptr null, i64 %t1259)
  %t1261 = add i64 %t1258, %t1260
  %t1262 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t1263 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t1264 = add i64 %t1261, %t1263
  %t1265 = load i64, ptr %l448, !tbaa !24
  %t1266 = call i64 @__olang_fmt_i64(ptr null, i64 %t1265)
  %t1267 = add i64 %t1264, %t1266
  %t1268 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t1269 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t1270 = add i64 %t1267, %t1269
  %t1271 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1270)
  call void @olang_textcopy(ptr %t1271, ptr %t1257, i64 %t1258)
  %t1272 = getelementptr i8, ptr %t1271, i64 %t1258
  %t1273 = call i64 @__olang_fmt_i64(ptr %t1272, i64 %t1259)
  %t1274 = getelementptr i8, ptr %t1272, i64 %t1260
  call void @olang_textcopy(ptr %t1274, ptr %t1262, i64 %t1263)
  %t1275 = getelementptr i8, ptr %t1274, i64 %t1263
  %t1276 = call i64 @__olang_fmt_i64(ptr %t1275, i64 %t1265)
  %t1277 = getelementptr i8, ptr %t1275, i64 %t1266
  call void @olang_textcopy(ptr %t1277, ptr %t1268, i64 %t1269)
  %t1278 = insertvalue { i64, ptr } undef, i64 %t1270, 0
  %t1279 = insertvalue { i64, ptr } %t1278, ptr %t1271, 1
  %t1281 = extractvalue { i64, ptr } %t1279, 0
  %t1282 = extractvalue { i64, ptr } %t1279, 1
  %t1283 = mul i64 %t1281, 1
  %t1284 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1284, ptr %t1282, i64 %t1283, i1 false)
  %t1285 = insertvalue { i64, ptr } undef, i64 %t1281, 0
  %t1286 = insertvalue { i64, ptr } %t1285, ptr %t1284, 1
  %t1287 = load ptr, ptr %l444, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s50, ptr %t1287, { i64, ptr } %t1286)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s50)
  br label %bb199
bb178:
  %t1289 = load ptr, ptr %l452, !tbaa !29
  %t1290 = load i32, ptr %l455, !tbaa !23
  %t1291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1289, i32 %t1290)
  store i32 %t1291, ptr %l456
  br label %bb179
bb179:
  %t1292 = load ptr, ptr %l451, !tbaa !29
  %t1293 = load i32, ptr %l456, !tbaa !23
  %t1294 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1292, i32 %t1293)
  store { i64, ptr } %t1294, ptr %l457
  br label %bb180
bb180:
  %t1295 = load { i64, ptr }, ptr %l457, !tbaa !27
  store { i64, ptr } %t1295, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  %t1296 = load i64, ptr %l12, !tbaa !24
  store i64 %t1296, ptr %l54, !tbaa !24
  store i64 1, ptr %l55, !tbaa !24
  %t1298 = load i64, ptr %l54, !tbaa !24
  %t1299 = load i64, ptr %l53, !tbaa !24
  %t1302 = icmp sgt i64 %t1298, %t1299
  br i1 %t1302, label %bb181, label %bb182
bb181:
  %t1304 = load i64, ptr %l55, !tbaa !24
  %t1306 = icmp sgt i64 %t1304, 0
  br i1 %t1306, label %bb183, label %bb184
bb182:
  store i64 0, ptr %l462, !tbaa !24
  br label %bb186
bb183:
  %t1308 = load i64, ptr %l54, !tbaa !24
  %t1309 = load i64, ptr %l53, !tbaa !24
  %t1312 = sub i64 %t1308, %t1309
  %t1313 = load i64, ptr %l55, !tbaa !24
  %t1316 = add i64 %t1312, %t1313
  %t1318 = sub i64 %t1316, 1
  %t1319 = load i64, ptr %l55, !tbaa !24
  %t1322 = sdiv i64 %t1318, %t1319
  store i64 %t1322, ptr %l465, !tbaa !24
  br label %bb185
bb184:
  store i64 0, ptr %l465, !tbaa !24
  br label %bb185
bb185:
  %t1324 = load i64, ptr %l465, !tbaa !24
  store i64 %t1324, ptr %l462, !tbaa !24
  br label %bb186
bb186:
  %t1325 = load i64, ptr %l462, !tbaa !24
  store i64 %t1325, ptr %l56, !tbaa !24
  store i64 0, ptr %l57, !tbaa !24
  br label %bb187
bb187:
  store %olang.scope zeroinitializer, ptr %s54
  %t1326 = load i64, ptr %l57, !tbaa !24
  %t1327 = load i64, ptr %l56, !tbaa !24
  %t1330 = icmp slt i64 %t1326, %t1327
  %t1332 = xor i1 %t1330, true
  br i1 %t1332, label %bb188, label %bb189
bb188:
  call void @__olang_scope_close(ptr %s54)
  br label %bb198
bb189:
  br label %bb190
bb190:
  %t1334 = load i64, ptr %l53, !tbaa !24
  %t1335 = load i64, ptr %l57, !tbaa !24
  %t1336 = load i64, ptr %l55, !tbaa !24
  %t1339 = mul i64 %t1335, %t1336
  %t1342 = add i64 %t1334, %t1339
  store i64 %t1342, ptr %l58, !tbaa !24
  %t1344 = load ptr, ptr %l10, !tbaa !29
  %t1346 = getelementptr %"compiler/emit:Emitter", ptr %t1344, i32 0, i32 0
  %t1347 = load ptr, ptr %t1346, !tbaa !29
  %t1348 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1348, ptr %l485, !tbaa !27
  %t1349 = load i64, ptr %l58, !tbaa !24
  %t1351 = getelementptr { i64, ptr }, ptr %l485, i32 0, i32 1
  %t1352 = load ptr, ptr %t1351, !tbaa !27
  %t1353 = getelementptr i32, ptr %t1352, i64 %t1349
  %t1354 = load i32, ptr %t1353, !tbaa !33
  %t1357 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t1347, i32 %t1354)
  store i1 %t1357, ptr %l488
  br label %bb191
bb191:
  %t1358 = load i64, ptr %l58, !tbaa !24
  %t1359 = load i64, ptr %l51, !tbaa !24
  %t1360 = load i64, ptr %l58, !tbaa !24
  %t1363 = add i64 %t1359, %t1360
  %t1364 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t1365 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t1367 = call i64 @__olang_fmt_i64(ptr null, i64 %t1358)
  %t1368 = add i64 %t1365, %t1367
  %t1369 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t1370 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t1371 = add i64 %t1368, %t1370
  %t1373 = call i64 @__olang_fmt_i64(ptr null, i64 %t1363)
  %t1374 = add i64 %t1371, %t1373
  %t1375 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t1376 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t1377 = add i64 %t1374, %t1376
  %t1378 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1377)
  call void @olang_textcopy(ptr %t1378, ptr %t1364, i64 %t1365)
  %t1379 = getelementptr i8, ptr %t1378, i64 %t1365
  %t1380 = call i64 @__olang_fmt_i64(ptr %t1379, i64 %t1358)
  %t1381 = getelementptr i8, ptr %t1379, i64 %t1367
  call void @olang_textcopy(ptr %t1381, ptr %t1369, i64 %t1370)
  %t1382 = getelementptr i8, ptr %t1381, i64 %t1370
  %t1383 = call i64 @__olang_fmt_i64(ptr %t1382, i64 %t1363)
  %t1384 = getelementptr i8, ptr %t1382, i64 %t1373
  call void @olang_textcopy(ptr %t1384, ptr %t1375, i64 %t1376)
  %t1385 = insertvalue { i64, ptr } undef, i64 %t1377, 0
  %t1386 = insertvalue { i64, ptr } %t1385, ptr %t1378, 1
  %t1388 = extractvalue { i64, ptr } %t1386, 0
  %t1389 = extractvalue { i64, ptr } %t1386, 1
  %t1390 = mul i64 %t1388, 1
  %t1391 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1391, ptr %t1389, i64 %t1390, i1 false)
  %t1392 = insertvalue { i64, ptr } undef, i64 %t1388, 0
  %t1393 = insertvalue { i64, ptr } %t1392, ptr %t1391, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s54, ptr %l14, { i64, ptr } %t1393)
  br label %bb192
bb192:
  store ptr %l14, ptr %l496, !tbaa !29
  %t1396 = load i64, ptr %l58, !tbaa !24
  store i64 %t1396, ptr %l497, !tbaa !24
  %t1397 = load ptr, ptr %l10, !tbaa !29
  %t1398 = load i32, ptr %l28, !tbaa !23
  %t1401 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s54, ptr %t1397, i32 %t1398)
  store { i64, ptr } %t1401, ptr %l500
  br label %bb193
bb193:
  %t1402 = load i64, ptr %l58, !tbaa !24
  %t1403 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t1404 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t1405 = load i64, ptr %l497, !tbaa !24
  %t1406 = call i64 @__olang_fmt_i64(ptr null, i64 %t1405)
  %t1407 = add i64 %t1404, %t1406
  %t1408 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t1409 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t1410 = add i64 %t1407, %t1409
  %t1411 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t1412 = extractvalue { i64, ptr } %t1411, 1
  %t1413 = extractvalue { i64, ptr } %t1411, 0
  %t1414 = add i64 %t1410, %t1413
  %t1415 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t1416 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t1417 = add i64 %t1414, %t1416
  %t1419 = call i64 @__olang_fmt_i64(ptr null, i64 %t1402)
  %t1420 = add i64 %t1417, %t1419
  %t1421 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t1422 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t1423 = add i64 %t1420, %t1422
  %t1424 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1423)
  call void @olang_textcopy(ptr %t1424, ptr %t1403, i64 %t1404)
  %t1425 = getelementptr i8, ptr %t1424, i64 %t1404
  %t1426 = call i64 @__olang_fmt_i64(ptr %t1425, i64 %t1405)
  %t1427 = getelementptr i8, ptr %t1425, i64 %t1406
  call void @olang_textcopy(ptr %t1427, ptr %t1408, i64 %t1409)
  %t1428 = getelementptr i8, ptr %t1427, i64 %t1409
  call void @olang_textcopy(ptr %t1428, ptr %t1412, i64 %t1413)
  %t1429 = getelementptr i8, ptr %t1428, i64 %t1413
  call void @olang_textcopy(ptr %t1429, ptr %t1415, i64 %t1416)
  %t1430 = getelementptr i8, ptr %t1429, i64 %t1416
  %t1431 = call i64 @__olang_fmt_i64(ptr %t1430, i64 %t1402)
  %t1432 = getelementptr i8, ptr %t1430, i64 %t1419
  call void @olang_textcopy(ptr %t1432, ptr %t1421, i64 %t1422)
  %t1433 = insertvalue { i64, ptr } undef, i64 %t1423, 0
  %t1434 = insertvalue { i64, ptr } %t1433, ptr %t1424, 1
  %t1436 = extractvalue { i64, ptr } %t1434, 0
  %t1437 = extractvalue { i64, ptr } %t1434, 1
  %t1438 = mul i64 %t1436, 1
  %t1439 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1439, ptr %t1437, i64 %t1438, i1 false)
  %t1440 = insertvalue { i64, ptr } undef, i64 %t1436, 0
  %t1441 = insertvalue { i64, ptr } %t1440, ptr %t1439, 1
  %t1442 = load ptr, ptr %l496, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s54, ptr %t1442, { i64, ptr } %t1441)
  br label %bb194
bb194:
  store ptr %l14, ptr %l504, !tbaa !29
  %t1444 = load i64, ptr %l58, !tbaa !24
  store i64 %t1444, ptr %l505, !tbaa !24
  %t1445 = load i64, ptr %l58, !tbaa !24
  store i64 %t1445, ptr %l506, !tbaa !24
  %t1446 = load ptr, ptr %l11, !tbaa !29
  %t1447 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t1447, ptr %l508, !tbaa !27
  %t1448 = load i64, ptr %l58, !tbaa !24
  %t1450 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1451 = load ptr, ptr %t1450, !tbaa !27
  %t1452 = getelementptr i32, ptr %t1451, i64 %t1448
  %t1453 = load i32, ptr %t1452, !tbaa !33
  %t1456 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1446, i32 %t1453)
  store i64 %t1456, ptr %l511
  br label %bb195
bb195:
  %t1457 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t1458 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t1459 = load i64, ptr %l505, !tbaa !24
  %t1460 = call i64 @__olang_fmt_i64(ptr null, i64 %t1459)
  %t1461 = add i64 %t1458, %t1460
  %t1462 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t1463 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t1464 = add i64 %t1461, %t1463
  %t1465 = load i64, ptr %l506, !tbaa !24
  %t1466 = call i64 @__olang_fmt_i64(ptr null, i64 %t1465)
  %t1467 = add i64 %t1464, %t1466
  %t1468 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t1469 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t1470 = add i64 %t1467, %t1469
  %t1471 = load i64, ptr %l511, !tbaa !24
  %t1472 = call i64 @__olang_fmt_i64(ptr null, i64 %t1471)
  %t1473 = add i64 %t1470, %t1472
  %t1474 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t1475 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t1476 = add i64 %t1473, %t1475
  %t1477 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1476)
  call void @olang_textcopy(ptr %t1477, ptr %t1457, i64 %t1458)
  %t1478 = getelementptr i8, ptr %t1477, i64 %t1458
  %t1479 = call i64 @__olang_fmt_i64(ptr %t1478, i64 %t1459)
  %t1480 = getelementptr i8, ptr %t1478, i64 %t1460
  call void @olang_textcopy(ptr %t1480, ptr %t1462, i64 %t1463)
  %t1481 = getelementptr i8, ptr %t1480, i64 %t1463
  %t1482 = call i64 @__olang_fmt_i64(ptr %t1481, i64 %t1465)
  %t1483 = getelementptr i8, ptr %t1481, i64 %t1466
  call void @olang_textcopy(ptr %t1483, ptr %t1468, i64 %t1469)
  %t1484 = getelementptr i8, ptr %t1483, i64 %t1469
  %t1485 = call i64 @__olang_fmt_i64(ptr %t1484, i64 %t1471)
  %t1486 = getelementptr i8, ptr %t1484, i64 %t1472
  call void @olang_textcopy(ptr %t1486, ptr %t1474, i64 %t1475)
  %t1487 = insertvalue { i64, ptr } undef, i64 %t1476, 0
  %t1488 = insertvalue { i64, ptr } %t1487, ptr %t1477, 1
  %t1490 = extractvalue { i64, ptr } %t1488, 0
  %t1491 = extractvalue { i64, ptr } %t1488, 1
  %t1492 = mul i64 %t1490, 1
  %t1493 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1493, ptr %t1491, i64 %t1492, i1 false)
  %t1494 = insertvalue { i64, ptr } undef, i64 %t1490, 0
  %t1495 = insertvalue { i64, ptr } %t1494, ptr %t1493, 1
  %t1496 = load ptr, ptr %l504, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s54, ptr %t1496, { i64, ptr } %t1495)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s54)
  br label %bb197
bb197:
  %t1498 = load i64, ptr %l57, !tbaa !24
  %t1500 = add i64 %t1498, 1
  store i64 %t1500, ptr %l57, !tbaa !24
  br label %bb187
bb198:
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s49)
  br label %bb225
bb200:
  store %olang.scope zeroinitializer, ptr %s60
  store ptr %l14, ptr %l518, !tbaa !29
  %t1502 = load i64, ptr %l51, !tbaa !24
  store i64 %t1502, ptr %l519, !tbaa !24
  %t1503 = load ptr, ptr %l10, !tbaa !29
  %t1504 = load i32, ptr %l28, !tbaa !23
  %t1507 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s60, ptr %t1503, i32 %t1504)
  store { i64, ptr } %t1507, ptr %l522
  br label %bb202
bb201:
  %t1508 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1508, ptr %l526, !tbaa !29
  %t1509 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1509, ptr %l527, !tbaa !29
  %t1510 = load ptr, ptr %l11, !tbaa !29
  %t1511 = load i32, ptr %l28, !tbaa !23
  %t1514 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1510, i32 %t1511)
  store i32 %t1514, ptr %l530
  br label %bb204
bb202:
  %t1515 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1516 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t1517 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t1518 = load i64, ptr %l519, !tbaa !24
  %t1519 = call i64 @__olang_fmt_i64(ptr null, i64 %t1518)
  %t1520 = add i64 %t1517, %t1519
  %t1521 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t1522 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t1523 = add i64 %t1520, %t1522
  %t1524 = load { i64, ptr }, ptr %l522, !tbaa !27
  %t1525 = extractvalue { i64, ptr } %t1524, 1
  %t1526 = extractvalue { i64, ptr } %t1524, 0
  %t1527 = add i64 %t1523, %t1526
  %t1528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t1529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t1530 = add i64 %t1527, %t1529
  %t1532 = extractvalue { i64, ptr } %t1515, 1
  %t1533 = extractvalue { i64, ptr } %t1515, 0
  %t1534 = add i64 %t1530, %t1533
  %t1535 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t1536 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t1537 = add i64 %t1534, %t1536
  %t1538 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1537)
  call void @olang_textcopy(ptr %t1538, ptr %t1516, i64 %t1517)
  %t1539 = getelementptr i8, ptr %t1538, i64 %t1517
  %t1540 = call i64 @__olang_fmt_i64(ptr %t1539, i64 %t1518)
  %t1541 = getelementptr i8, ptr %t1539, i64 %t1519
  call void @olang_textcopy(ptr %t1541, ptr %t1521, i64 %t1522)
  %t1542 = getelementptr i8, ptr %t1541, i64 %t1522
  call void @olang_textcopy(ptr %t1542, ptr %t1525, i64 %t1526)
  %t1543 = getelementptr i8, ptr %t1542, i64 %t1526
  call void @olang_textcopy(ptr %t1543, ptr %t1528, i64 %t1529)
  %t1544 = getelementptr i8, ptr %t1543, i64 %t1529
  call void @olang_textcopy(ptr %t1544, ptr %t1532, i64 %t1533)
  %t1545 = getelementptr i8, ptr %t1544, i64 %t1533
  call void @olang_textcopy(ptr %t1545, ptr %t1535, i64 %t1536)
  %t1546 = insertvalue { i64, ptr } undef, i64 %t1537, 0
  %t1547 = insertvalue { i64, ptr } %t1546, ptr %t1538, 1
  %t1549 = extractvalue { i64, ptr } %t1547, 0
  %t1550 = extractvalue { i64, ptr } %t1547, 1
  %t1551 = mul i64 %t1549, 1
  %t1552 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1551)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1552, ptr %t1550, i64 %t1551, i1 false)
  %t1553 = insertvalue { i64, ptr } undef, i64 %t1549, 0
  %t1554 = insertvalue { i64, ptr } %t1553, ptr %t1552, 1
  %t1555 = load ptr, ptr %l518, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s60, ptr %t1555, { i64, ptr } %t1554)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s60)
  br label %bb224
bb204:
  %t1557 = load ptr, ptr %l527, !tbaa !29
  %t1558 = load i32, ptr %l530, !tbaa !23
  %t1559 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1557, i32 %t1558)
  store i32 %t1559, ptr %l531
  br label %bb205
bb205:
  %t1560 = load ptr, ptr %l526, !tbaa !29
  %t1561 = load i32, ptr %l531, !tbaa !23
  %t1562 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1560, i32 %t1561)
  store { i64, ptr } %t1562, ptr %l532
  br label %bb206
bb206:
  %t1563 = load { i64, ptr }, ptr %l532, !tbaa !27
  store { i64, ptr } %t1563, ptr %l59, !tbaa !27
  store i64 0, ptr %l60, !tbaa !24
  %t1564 = load i64, ptr %l12, !tbaa !24
  store i64 %t1564, ptr %l61, !tbaa !24
  store i64 1, ptr %l62, !tbaa !24
  %t1566 = load i64, ptr %l61, !tbaa !24
  %t1567 = load i64, ptr %l60, !tbaa !24
  %t1570 = icmp sgt i64 %t1566, %t1567
  br i1 %t1570, label %bb207, label %bb208
bb207:
  %t1572 = load i64, ptr %l62, !tbaa !24
  %t1574 = icmp sgt i64 %t1572, 0
  br i1 %t1574, label %bb209, label %bb210
bb208:
  store i64 0, ptr %l537, !tbaa !24
  br label %bb212
bb209:
  %t1576 = load i64, ptr %l61, !tbaa !24
  %t1577 = load i64, ptr %l60, !tbaa !24
  %t1580 = sub i64 %t1576, %t1577
  %t1581 = load i64, ptr %l62, !tbaa !24
  %t1584 = add i64 %t1580, %t1581
  %t1586 = sub i64 %t1584, 1
  %t1587 = load i64, ptr %l62, !tbaa !24
  %t1590 = sdiv i64 %t1586, %t1587
  store i64 %t1590, ptr %l540, !tbaa !24
  br label %bb211
bb210:
  store i64 0, ptr %l540, !tbaa !24
  br label %bb211
bb211:
  %t1592 = load i64, ptr %l540, !tbaa !24
  store i64 %t1592, ptr %l537, !tbaa !24
  br label %bb212
bb212:
  %t1593 = load i64, ptr %l537, !tbaa !24
  store i64 %t1593, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb213
bb213:
  store %olang.scope zeroinitializer, ptr %s64
  %t1594 = load i64, ptr %l64, !tbaa !24
  %t1595 = load i64, ptr %l63, !tbaa !24
  %t1598 = icmp slt i64 %t1594, %t1595
  %t1600 = xor i1 %t1598, true
  br i1 %t1600, label %bb214, label %bb215
bb214:
  call void @__olang_scope_close(ptr %s64)
  br label %bb223
bb215:
  br label %bb216
bb216:
  %t1602 = load i64, ptr %l60, !tbaa !24
  %t1603 = load i64, ptr %l64, !tbaa !24
  %t1604 = load i64, ptr %l62, !tbaa !24
  %t1607 = mul i64 %t1603, %t1604
  %t1610 = add i64 %t1602, %t1607
  store i64 %t1610, ptr %l65, !tbaa !24
  %t1612 = load i64, ptr %l65, !tbaa !24
  %t1613 = load i64, ptr %l51, !tbaa !24
  %t1614 = load i64, ptr %l65, !tbaa !24
  %t1617 = add i64 %t1613, %t1614
  %t1618 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t1619 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t1621 = call i64 @__olang_fmt_i64(ptr null, i64 %t1612)
  %t1622 = add i64 %t1619, %t1621
  %t1623 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t1624 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t1625 = add i64 %t1622, %t1624
  %t1627 = call i64 @__olang_fmt_i64(ptr null, i64 %t1617)
  %t1628 = add i64 %t1625, %t1627
  %t1629 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t1630 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t1631 = add i64 %t1628, %t1630
  %t1632 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1631)
  call void @olang_textcopy(ptr %t1632, ptr %t1618, i64 %t1619)
  %t1633 = getelementptr i8, ptr %t1632, i64 %t1619
  %t1634 = call i64 @__olang_fmt_i64(ptr %t1633, i64 %t1612)
  %t1635 = getelementptr i8, ptr %t1633, i64 %t1621
  call void @olang_textcopy(ptr %t1635, ptr %t1623, i64 %t1624)
  %t1636 = getelementptr i8, ptr %t1635, i64 %t1624
  %t1637 = call i64 @__olang_fmt_i64(ptr %t1636, i64 %t1617)
  %t1638 = getelementptr i8, ptr %t1636, i64 %t1627
  call void @olang_textcopy(ptr %t1638, ptr %t1629, i64 %t1630)
  %t1639 = insertvalue { i64, ptr } undef, i64 %t1631, 0
  %t1640 = insertvalue { i64, ptr } %t1639, ptr %t1632, 1
  %t1642 = extractvalue { i64, ptr } %t1640, 0
  %t1643 = extractvalue { i64, ptr } %t1640, 1
  %t1644 = mul i64 %t1642, 1
  %t1645 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1645, ptr %t1643, i64 %t1644, i1 false)
  %t1646 = insertvalue { i64, ptr } undef, i64 %t1642, 0
  %t1647 = insertvalue { i64, ptr } %t1646, ptr %t1645, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s64, ptr %l14, { i64, ptr } %t1647)
  br label %bb217
bb217:
  store ptr %l14, ptr %l565, !tbaa !29
  %t1650 = load i64, ptr %l65, !tbaa !24
  store i64 %t1650, ptr %l566, !tbaa !24
  %t1651 = load ptr, ptr %l10, !tbaa !29
  %t1652 = load i32, ptr %l28, !tbaa !23
  %t1655 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s64, ptr %t1651, i32 %t1652)
  store { i64, ptr } %t1655, ptr %l569
  br label %bb218
bb218:
  %t1656 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1657 = load i64, ptr %l65, !tbaa !24
  %t1658 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t1659 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t1660 = load i64, ptr %l566, !tbaa !24
  %t1661 = call i64 @__olang_fmt_i64(ptr null, i64 %t1660)
  %t1662 = add i64 %t1659, %t1661
  %t1663 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t1664 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t1665 = add i64 %t1662, %t1664
  %t1666 = load { i64, ptr }, ptr %l569, !tbaa !27
  %t1667 = extractvalue { i64, ptr } %t1666, 1
  %t1668 = extractvalue { i64, ptr } %t1666, 0
  %t1669 = add i64 %t1665, %t1668
  %t1670 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t1671 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t1672 = add i64 %t1669, %t1671
  %t1674 = extractvalue { i64, ptr } %t1656, 1
  %t1675 = extractvalue { i64, ptr } %t1656, 0
  %t1676 = add i64 %t1672, %t1675
  %t1677 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t1678 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t1679 = add i64 %t1676, %t1678
  %t1681 = call i64 @__olang_fmt_i64(ptr null, i64 %t1657)
  %t1682 = add i64 %t1679, %t1681
  %t1683 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t1684 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t1685 = add i64 %t1682, %t1684
  %t1686 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1685)
  call void @olang_textcopy(ptr %t1686, ptr %t1658, i64 %t1659)
  %t1687 = getelementptr i8, ptr %t1686, i64 %t1659
  %t1688 = call i64 @__olang_fmt_i64(ptr %t1687, i64 %t1660)
  %t1689 = getelementptr i8, ptr %t1687, i64 %t1661
  call void @olang_textcopy(ptr %t1689, ptr %t1663, i64 %t1664)
  %t1690 = getelementptr i8, ptr %t1689, i64 %t1664
  call void @olang_textcopy(ptr %t1690, ptr %t1667, i64 %t1668)
  %t1691 = getelementptr i8, ptr %t1690, i64 %t1668
  call void @olang_textcopy(ptr %t1691, ptr %t1670, i64 %t1671)
  %t1692 = getelementptr i8, ptr %t1691, i64 %t1671
  call void @olang_textcopy(ptr %t1692, ptr %t1674, i64 %t1675)
  %t1693 = getelementptr i8, ptr %t1692, i64 %t1675
  call void @olang_textcopy(ptr %t1693, ptr %t1677, i64 %t1678)
  %t1694 = getelementptr i8, ptr %t1693, i64 %t1678
  %t1695 = call i64 @__olang_fmt_i64(ptr %t1694, i64 %t1657)
  %t1696 = getelementptr i8, ptr %t1694, i64 %t1681
  call void @olang_textcopy(ptr %t1696, ptr %t1683, i64 %t1684)
  %t1697 = insertvalue { i64, ptr } undef, i64 %t1685, 0
  %t1698 = insertvalue { i64, ptr } %t1697, ptr %t1686, 1
  %t1700 = extractvalue { i64, ptr } %t1698, 0
  %t1701 = extractvalue { i64, ptr } %t1698, 1
  %t1702 = mul i64 %t1700, 1
  %t1703 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1702)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1703, ptr %t1701, i64 %t1702, i1 false)
  %t1704 = insertvalue { i64, ptr } undef, i64 %t1700, 0
  %t1705 = insertvalue { i64, ptr } %t1704, ptr %t1703, 1
  %t1706 = load ptr, ptr %l565, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s64, ptr %t1706, { i64, ptr } %t1705)
  br label %bb219
bb219:
  store ptr %l14, ptr %l574, !tbaa !29
  %t1708 = load ptr, ptr %l10, !tbaa !29
  %t1709 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t1709, ptr %l576, !tbaa !27
  %t1710 = load i64, ptr %l65, !tbaa !24
  %t1712 = getelementptr { i64, ptr }, ptr %l576, i32 0, i32 1
  %t1713 = load ptr, ptr %t1712, !tbaa !27
  %t1714 = getelementptr i32, ptr %t1713, i64 %t1710
  %t1715 = load i32, ptr %t1714, !tbaa !33
  %t1718 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s64, ptr %t1708, i32 %t1715)
  store { i64, ptr } %t1718, ptr %l579
  br label %bb220
bb220:
  %t1719 = load i64, ptr %l65, !tbaa !24
  %t1720 = load i64, ptr %l65, !tbaa !24
  %t1721 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t1722 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t1723 = load { i64, ptr }, ptr %l579, !tbaa !27
  %t1724 = extractvalue { i64, ptr } %t1723, 1
  %t1725 = extractvalue { i64, ptr } %t1723, 0
  %t1726 = add i64 %t1722, %t1725
  %t1727 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t1728 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t1729 = add i64 %t1726, %t1728
  %t1731 = call i64 @__olang_fmt_i64(ptr null, i64 %t1719)
  %t1732 = add i64 %t1729, %t1731
  %t1733 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t1734 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t1735 = add i64 %t1732, %t1734
  %t1737 = call i64 @__olang_fmt_i64(ptr null, i64 %t1720)
  %t1738 = add i64 %t1735, %t1737
  %t1739 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t1740 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t1741 = add i64 %t1738, %t1740
  %t1742 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1741)
  call void @olang_textcopy(ptr %t1742, ptr %t1721, i64 %t1722)
  %t1743 = getelementptr i8, ptr %t1742, i64 %t1722
  call void @olang_textcopy(ptr %t1743, ptr %t1724, i64 %t1725)
  %t1744 = getelementptr i8, ptr %t1743, i64 %t1725
  call void @olang_textcopy(ptr %t1744, ptr %t1727, i64 %t1728)
  %t1745 = getelementptr i8, ptr %t1744, i64 %t1728
  %t1746 = call i64 @__olang_fmt_i64(ptr %t1745, i64 %t1719)
  %t1747 = getelementptr i8, ptr %t1745, i64 %t1731
  call void @olang_textcopy(ptr %t1747, ptr %t1733, i64 %t1734)
  %t1748 = getelementptr i8, ptr %t1747, i64 %t1734
  %t1749 = call i64 @__olang_fmt_i64(ptr %t1748, i64 %t1720)
  %t1750 = getelementptr i8, ptr %t1748, i64 %t1737
  call void @olang_textcopy(ptr %t1750, ptr %t1739, i64 %t1740)
  %t1751 = insertvalue { i64, ptr } undef, i64 %t1741, 0
  %t1752 = insertvalue { i64, ptr } %t1751, ptr %t1742, 1
  %t1754 = extractvalue { i64, ptr } %t1752, 0
  %t1755 = extractvalue { i64, ptr } %t1752, 1
  %t1756 = mul i64 %t1754, 1
  %t1757 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1757, ptr %t1755, i64 %t1756, i1 false)
  %t1758 = insertvalue { i64, ptr } undef, i64 %t1754, 0
  %t1759 = insertvalue { i64, ptr } %t1758, ptr %t1757, 1
  %t1760 = load ptr, ptr %l574, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s64, ptr %t1760, { i64, ptr } %t1759)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s64)
  br label %bb222
bb222:
  %t1762 = load i64, ptr %l64, !tbaa !24
  %t1764 = add i64 %t1762, 1
  store i64 %t1764, ptr %l64, !tbaa !24
  br label %bb213
bb223:
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t1766 = load ptr, ptr %l0, !tbaa !29
  %t1767 = load %"compiler/mir:Task", ptr %l7
  %t1768 = load i64, ptr %l22, !tbaa !24
  %t1769 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1771 = extractvalue { i64, ptr } %t1769, 0
  %t1774 = add i64 %t1768, %t1771
  %t1775 = load i64, ptr %l6, !tbaa !24
  %t1778 = add i64 %t1774, %t1775
  %t1779 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %s0, ptr %v4, ptr %s48, ptr %t1766, ptr %l14, %"compiler/mir:Task" %t1767, i64 %t1778, { i64, ptr } %t1779, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d410, i32 0, i32 1) })
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s48)
  br label %bb227
bb227:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d411, i32 0, i32 1) })
  br label %bb228
bb228:
  %t1786 = load ptr, ptr %l10, !tbaa !29
  store ptr %t1786, ptr %l597, !tbaa !29
  %t1787 = load ptr, ptr %lp13
  %t1788 = load { i64, ptr }, ptr %t1787, !tbaa !27
  store { i64, ptr } %t1788, ptr %l598, !tbaa !27
  %t1789 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  store i64 %t1789, ptr %l599, !tbaa !24
  %t1791 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l14)
  store { i64, ptr } %t1791, ptr %l601
  br label %bb229
bb229:
  %t1792 = load ptr, ptr %l597, !tbaa !29
  %t1793 = load { i64, ptr }, ptr %l598, !tbaa !27
  %t1794 = load i64, ptr %l599, !tbaa !24
  %t1795 = load { i64, ptr }, ptr %l601, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v5, ptr %s0, ptr %s0, ptr %t1792, { i64, ptr } %t1793, i64 %t1794, { i64, ptr } %t1795, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb230
bb230:
  %t1796 = load ptr, ptr %lp13
  %t1797 = load { i64, ptr }, ptr %t1796, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1797, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkFlow(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, [21 x i64] }
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, [8 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca %"compiler/mir:Range"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l45 = alloca i32
  %l46 = alloca %"compiler/mir:Call"
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca %"compiler/mir:Range"
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l57 = alloca { i64, [1 x i64] }
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l77 = alloca i64
  %l80 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l145 = alloca ptr
  %l148 = alloca i64
  %l152 = alloca i64
  %l155 = alloca i64
  %l176 = alloca { i64, [21 x i64] }
  %l177 = alloca { i64, [21 x i64] }
  %l184 = alloca { i64, [21 x i64] }
  %l196 = alloca ptr
  %l200 = alloca i64
  %l205 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca i32
  %l235 = alloca i32
  %l253 = alloca ptr
  %l261 = alloca %"compiler/mir:Case"
  %l276 = alloca %"compiler/mir:Call"
  %l294 = alloca i1
  %l333 = alloca i32
  %l336 = alloca i32
  %l361 = alloca { i64, [1 x i64] }
  %l369 = alloca i1
  %l375 = alloca ptr
  %l378 = alloca i64
  %l389 = alloca i64
  %l391 = alloca i64
  %l396 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
  %t22 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l66
  br label %bb1
bb1:
  %t11 = load i64, ptr %l66, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l67, !tbaa !24
  %t13 = load i64, ptr %l67, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l67, !tbaa !24
  %t17 = icmp sle i64 %t16, 1152921504606846975
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6e037ff8088c42f2_1018a41289232aae)
  unreachable
bb4:
  %t19 = load i64, ptr %l67, !tbaa !24
  %t20 = mul i64 %t19, 8
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  store i64 0, ptr %t22
  br label %fill.23
fill.23:
  %t26 = load i64, ptr %t22
  %t27 = icmp slt i64 %t26, %t19
  br i1 %t27, label %fillb.24, label %filld.25
fillb.24:
  %t28 = getelementptr i64, ptr %t21, i64 %t26
  store i64 -1, ptr %t28
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %t22
  br label %fill.23
filld.25:
  %t30 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t21, 1
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i64, ptr %t34, i64 0
  store i64 0, ptr %t35, !tbaa !34
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l71
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6e037ff8088c42f2_1018a41289232aae)
  unreachable
bb6:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 0)
  br label %bb7
bb7:
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l73
  br label %bb8
bb8:
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store ptr %t40, ptr %lp7
  %t41 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l73
  %t42 = load ptr, ptr %lp7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %t42
  store i64 0, ptr %l8, !tbaa !24
  store i64 2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb14
bb11:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l80, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l80, !tbaa !24
  store i64 %t69, ptr %l77, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l77, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  br label %bb214
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l13, !tbaa !24
  %t91 = icmp eq i64 %t89, 1
  br i1 %t91, label %bb19, label %bb20
bb19:
  store i64 0, ptr %l14, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  store i64 %t93, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t95 = load i64, ptr %l15, !tbaa !24
  %t96 = load i64, ptr %l14, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb21, label %bb22
bb20:
  br label %bb37
bb21:
  %t101 = load i64, ptr %l16, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb26
bb23:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l16, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l107, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb25
bb25:
  %t121 = load i64, ptr %l107, !tbaa !24
  store i64 %t121, ptr %l104, !tbaa !24
  br label %bb26
bb26:
  %t122 = load i64, ptr %l104, !tbaa !24
  store i64 %t122, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  %t123 = load i64, ptr %l18, !tbaa !24
  %t124 = load i64, ptr %l17, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb28, label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l18, !tbaa !24
  %t133 = load i64, ptr %l16, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l19, !tbaa !24
  %t141 = load i64, ptr %l19, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i64, ptr %t144, i64 %t141
  %t146 = load i64, ptr %t145, !tbaa !34
  %t148 = icmp sge i64 %t146, 0
  br i1 %t148, label %bb31, label %bb32
bb31:
  %t150 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t150)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t153 = load i64, ptr %l18, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l18, !tbaa !24
  br label %bb27
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t158, ptr %l133
  br label %bb39
bb39:
  %t159 = load i64, ptr %l133, !tbaa !24
  %t160 = icmp sgt i64 %t159, 0
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb212
bb41:
  br label %bb42
bb42:
  %t165 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l6)
  %t166 = extractvalue { i32, i64 } %t165, 1
  %t167 = extractvalue { i32, i64 } %t165, 0
  store i32 %t167, ptr %l139
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb44, label %ok.169, !prof !99
ok.169:
  store i64 %t166, ptr %l138
  br label %bb43
bb43:
  %t170 = load i64, ptr %l138, !tbaa !24
  store i64 %t170, ptr %l136, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_1085358c18365730_69fd93bfc7477ec4)
  unreachable
bb46:
  %t171 = load i64, ptr %l136, !tbaa !24
  store i64 %t171, ptr %l20, !tbaa !24
  %t172 = load i64, ptr %l20, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i64, ptr %t175, i64 %t172
  %t177 = load i64, ptr %t176, !tbaa !34
  store i64 %t177, ptr %l21, !tbaa !24
  %t179 = load ptr, ptr %l3, !tbaa !29
  %t181 = getelementptr %"compiler/mir:Fn", ptr %t179, i32 0, i32 9
  %t182 = load i64, ptr %l20, !tbaa !24
  %t185 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t181, i64 %t182)
  store ptr %t185, ptr %l145
  br label %bb47
bb47:
  %t186 = load ptr, ptr %l145, !tbaa !29
  store ptr %t186, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  %t187 = load ptr, ptr %l22, !tbaa !29
  %t189 = getelementptr %"compiler/mir:BasicBlock", ptr %t187, i32 0, i32 0
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l148
  br label %bb48
bb48:
  %t192 = load i64, ptr %l148, !tbaa !24
  store i64 %t192, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t193 = load i64, ptr %l24, !tbaa !24
  %t194 = load i64, ptr %l23, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = load i64, ptr %l25, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb54
bb51:
  %t203 = load i64, ptr %l24, !tbaa !24
  %t204 = load i64, ptr %l23, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l25, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l25, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l155, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb53
bb53:
  %t219 = load i64, ptr %l155, !tbaa !24
  store i64 %t219, ptr %l152, !tbaa !24
  br label %bb54
bb54:
  %t220 = load i64, ptr %l152, !tbaa !24
  store i64 %t220, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb55
bb55:
  %t221 = load i64, ptr %l27, !tbaa !24
  %t222 = load i64, ptr %l26, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb56, label %bb57
bb56:
  br label %bb88
bb57:
  br label %bb58
bb58:
  %t229 = load i64, ptr %l23, !tbaa !24
  %t230 = load i64, ptr %l27, !tbaa !24
  %t231 = load i64, ptr %l25, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l28, !tbaa !24
  %t239 = load ptr, ptr %l22, !tbaa !29
  %t241 = getelementptr %"compiler/mir:BasicBlock", ptr %t239, i32 0, i32 0
  %t242 = load i64, ptr %l28, !tbaa !24
  %t245 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t241, i64 %t242)
  store { i64, [21 x i64] } %t245, ptr %l176
  br label %bb59
bb59:
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %l176, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l177, ptr %l29, i64 176, i1 false)
  %t246 = load { i64, [21 x i64] }, ptr %l177
  %t247 = extractvalue { i64, [21 x i64] } %t246, 0
  %t248 = icmp eq i64 %t247, 3
  br i1 %t248, label %bb60, label %bb61
bb60:
  %t250 = getelementptr { i64, [21 x i64] }, ptr %l29, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32 }, ptr %t250, i32 0, i32 1
  %t252 = load i32, ptr %t251
  store i32 %t252, ptr %l30, !tbaa !23
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t254 = load i32, ptr %l30, !tbaa !23
  %t256 = sext i32 %t254 to i64
  %t257 = load i64, ptr %l1, !tbaa !24
  %t260 = icmp eq i64 %t256, %t257
  br i1 %t260, label %bb63, label %bb64
bb63:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb86
bb66:
  call void @llvm.memmove.p0.p0.i64(ptr %l184, ptr %l29, i64 176, i1 false)
  %t262 = load { i64, [21 x i64] }, ptr %l184
  %t263 = extractvalue { i64, [21 x i64] } %t262, 0
  %t264 = icmp eq i64 %t263, 4
  br i1 %t264, label %bb67, label %bb68
bb67:
  %t266 = getelementptr { i64, [21 x i64] }, ptr %l29, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32 }, ptr %t266, i32 0, i32 1
  %t268 = load i32, ptr %t267
  store i32 %t268, ptr %l31, !tbaa !23
  br label %bb69
bb68:
  br label %bb81
bb69:
  %t270 = load i32, ptr %l31, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t273 = load i64, ptr %l1, !tbaa !24
  %t276 = icmp eq i64 %t272, %t273
  br i1 %t276, label %bb70, label %bb71
bb70:
  %t278 = load i64, ptr %l13, !tbaa !24
  %t280 = icmp eq i64 %t278, 1
  br i1 %t280, label %bb72, label %bb73
bb71:
  br label %bb80
bb72:
  %t282 = load i64, ptr %l21, !tbaa !24
  %t284 = icmp eq i64 %t282, 2
  br i1 %t284, label %bb74, label %bb75
bb73:
  br label %bb79
bb74:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t287 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t287, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t288 = load ptr, ptr %lp7
  store ptr %t288, ptr %l196, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i64, ptr %l20, !tbaa !24
  %t291 = load i64, ptr %l28, !tbaa !24
  %t295 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t289, i64 %t290, i64 %t291)
  store i64 %t295, ptr %l200
  br label %bb77
bb77:
  %t296 = load i64, ptr %l21, !tbaa !24
  %t298 = icmp eq i64 %t296, 1
  %t299 = load ptr, ptr %l196, !tbaa !29
  %t300 = load i64, ptr %l200, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t299, i64 %t300, i1 %t298)
  br label %bb78
bb78:
  br label %bb79
bb79:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb80
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_eebd0c438d14e76b_644c9cf9ab14a5ff)
  unreachable
bb86:
  br label %bb87
bb87:
  %t302 = load i64, ptr %l27, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l27, !tbaa !24
  br label %bb55
bb88:
  %t306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l205
  br label %bb89
bb89:
  %t307 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l205
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l32
  %t308 = load ptr, ptr %l22, !tbaa !29
  %t310 = getelementptr %"compiler/mir:BasicBlock", ptr %t308, i32 0, i32 1
  %t311 = load { i64, [8 x i64] }, ptr %t310
  store { i64, [8 x i64] } %t311, ptr %l33
  %t313 = load { i64, [8 x i64] }, ptr %l33
  %t315 = extractvalue { i64, [8 x i64] } %t313, 0
  %t316 = icmp eq i64 %t315, 1
  br i1 %t316, label %bb90, label %bb91
bb90:
  %t318 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t319 = getelementptr { i32 }, ptr %t318, i32 0, i32 0
  %t320 = load i32, ptr %t319
  store i32 %t320, ptr %l34, !tbaa !23
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t322 = load i32, ptr %l34, !tbaa !23
  %t324 = sext i32 %t322 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t324)
  br label %bb93
bb93:
  br label %bb198
bb94:
  %t327 = load { i64, [8 x i64] }, ptr %l33
  %t329 = extractvalue { i64, [8 x i64] } %t327, 0
  %t330 = icmp eq i64 %t329, 2
  br i1 %t330, label %bb95, label %bb96
bb95:
  %t332 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t333 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t332, i32 0, i32 1
  %t334 = load i32, ptr %t333
  store i32 %t334, ptr %l35, !tbaa !23
  %t336 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t337 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t336, i32 0, i32 2
  %t338 = load i32, ptr %t337
  store i32 %t338, ptr %l36, !tbaa !23
  br label %bb97
bb96:
  br label %bb100
bb97:
  %t340 = load i32, ptr %l35, !tbaa !23
  %t342 = sext i32 %t340 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t342)
  br label %bb98
bb98:
  %t345 = load i32, ptr %l36, !tbaa !23
  %t347 = sext i32 %t345 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t347)
  br label %bb99
bb99:
  br label %bb198
bb100:
  %t350 = load { i64, [8 x i64] }, ptr %l33
  %t352 = extractvalue { i64, [8 x i64] } %t350, 0
  %t353 = icmp eq i64 %t352, 3
  br i1 %t353, label %bb101, label %bb102
bb101:
  %t355 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t356 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t355, i32 0, i32 1
  %t357 = load %"compiler/mir:Range", ptr %t356
  store %"compiler/mir:Range" %t357, ptr %l37
  %t359 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t360 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t359, i32 0, i32 2
  %t361 = load i32, ptr %t360
  store i32 %t361, ptr %l38, !tbaa !23
  br label %bb103
bb102:
  br label %bb119
bb103:
  store i32 0, ptr %l39, !tbaa !23
  %t363 = getelementptr %"compiler/mir:Range", ptr %l37, i32 0, i32 1
  %t364 = load i32, ptr %t363, !tbaa !23
  store i32 %t364, ptr %l40, !tbaa !23
  store i32 1, ptr %l41, !tbaa !23
  %t366 = load i32, ptr %l40, !tbaa !23
  %t367 = load i32, ptr %l39, !tbaa !23
  %t370 = icmp sgt i32 %t366, %t367
  br i1 %t370, label %bb104, label %bb105
bb104:
  %t372 = load i32, ptr %l41, !tbaa !23
  %t374 = icmp sgt i32 %t372, 0
  br i1 %t374, label %bb106, label %bb107
bb105:
  store i32 0, ptr %l232, !tbaa !23
  br label %bb109
bb106:
  %t376 = load i32, ptr %l40, !tbaa !23
  %t377 = load i32, ptr %l39, !tbaa !23
  %t380 = sub i32 %t376, %t377
  %t381 = load i32, ptr %l41, !tbaa !23
  %t384 = add i32 %t380, %t381
  %t386 = sub i32 %t384, 1
  %t387 = load i32, ptr %l41, !tbaa !23
  %t390 = sdiv i32 %t386, %t387
  store i32 %t390, ptr %l235, !tbaa !23
  br label %bb108
bb107:
  store i32 0, ptr %l235, !tbaa !23
  br label %bb108
bb108:
  %t392 = load i32, ptr %l235, !tbaa !23
  store i32 %t392, ptr %l232, !tbaa !23
  br label %bb109
bb109:
  %t393 = load i32, ptr %l232, !tbaa !23
  store i32 %t393, ptr %l42, !tbaa !23
  store i32 0, ptr %l43, !tbaa !23
  br label %bb110
bb110:
  %t394 = load i32, ptr %l43, !tbaa !23
  %t395 = load i32, ptr %l42, !tbaa !23
  %t398 = icmp slt i32 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb111, label %bb112
bb111:
  br label %bb117
bb112:
  br label %bb113
bb113:
  %t402 = load i32, ptr %l39, !tbaa !23
  %t403 = load i32, ptr %l43, !tbaa !23
  %t404 = load i32, ptr %l41, !tbaa !23
  %t407 = mul i32 %t403, %t404
  %t410 = add i32 %t402, %t407
  store ptr %l32, ptr %l253, !tbaa !29
  %t412 = load ptr, ptr %l3, !tbaa !29
  %t414 = getelementptr %"compiler/mir:Fn", ptr %t412, i32 0, i32 15
  %t415 = getelementptr %"compiler/mir:Range", ptr %l37, i32 0, i32 0
  %t416 = load i32, ptr %t415, !tbaa !23
  %t418 = sext i32 %t416 to i64
  %t421 = sext i32 %t410 to i64
  %t424 = add i64 %t418, %t421
  %t427 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t414, i64 %t424)
  store %"compiler/mir:Case" %t427, ptr %l261
  br label %bb114
bb114:
  %t428 = getelementptr %"compiler/mir:Case", ptr %l261, i32 0, i32 1
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = sext i32 %t429 to i64
  %t432 = load ptr, ptr %l253, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %t432, i64 %t431)
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t434 = load i32, ptr %l43, !tbaa !23
  %t436 = add i32 %t434, 1
  store i32 %t436, ptr %l43, !tbaa !23
  br label %bb110
bb117:
  %t438 = load i32, ptr %l38, !tbaa !23
  %t440 = sext i32 %t438 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t440)
  br label %bb118
bb118:
  br label %bb198
bb119:
  %t443 = load { i64, [8 x i64] }, ptr %l33
  %t445 = extractvalue { i64, [8 x i64] } %t443, 0
  %t446 = icmp eq i64 %t445, 4
  br i1 %t446, label %bb120, label %bb121
bb120:
  %t448 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t449 = getelementptr { %"compiler/source:Span", i32 }, ptr %t448, i32 0, i32 1
  %t450 = load i32, ptr %t449
  store i32 %t450, ptr %l45, !tbaa !23
  br label %bb122
bb121:
  br label %bb146
bb122:
  %t452 = load ptr, ptr %l3, !tbaa !29
  %t454 = getelementptr %"compiler/mir:Fn", ptr %t452, i32 0, i32 14
  %t455 = load i32, ptr %l45, !tbaa !23
  %t457 = sext i32 %t455 to i64
  %t460 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t454, i64 %t457)
  store %"compiler/mir:Call" %t460, ptr %l276
  br label %bb123
bb123:
  %t461 = load %"compiler/mir:Call", ptr %l276
  store %"compiler/mir:Call" %t461, ptr %l46
  %t462 = load i32, ptr %l45, !tbaa !23
  %t464 = sext i32 %t462 to i64
  %t468 = icmp eq i64 %t464, %a2
  br i1 %t468, label %bb124, label %bb125
bb124:
  %t470 = load i64, ptr %l21, !tbaa !24
  %t472 = icmp ne i64 %t470, 0
  br i1 %t472, label %bb126, label %bb127
bb125:
  br label %bb140
bb126:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t475 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t475, ptr %rv
  br label %ret
bb127:
  br label %bb128
bb128:
  %t476 = load i64, ptr %l13, !tbaa !24
  %t478 = icmp eq i64 %t476, 0
  br i1 %t478, label %bb129, label %bb130
bb129:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t482 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 5
  %t483 = load i32, ptr %t482, !tbaa !23
  %t485 = sext i32 %t483 to i64
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %s0, ptr %s0, ptr %t480, { i64, ptr } %t481, i64 %t485, i64 1, ptr %l6)
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb132
bb132:
  %t490 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 7
  %t491 = load i32, ptr %t490, !tbaa !23
  %t492 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t495 = icmp ne i32 %t491, %t492
  br i1 %t495, label %bb133, label %bb134
bb133:
  %t497 = load i64, ptr %l13, !tbaa !24
  %t499 = icmp eq i64 %t497, 0
  store i1 %t499, ptr %l294, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l294, !tbaa !21
  br label %bb135
bb135:
  %t501 = load i1, ptr %l294, !tbaa !21
  br i1 %t501, label %bb136, label %bb137
bb136:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t504 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 7
  %t505 = load i32, ptr %t504, !tbaa !23
  %t507 = sext i32 %t505 to i64
  %t508 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %s0, ptr %s0, ptr %t502, { i64, ptr } %t503, i64 %t507, i64 %t508, ptr %l6)
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s8)
  br label %bb211
bb140:
  %t514 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 5
  %t515 = load i32, ptr %t514, !tbaa !23
  %t517 = sext i32 %t515 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t517)
  br label %bb141
bb141:
  %t520 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 7
  %t521 = load i32, ptr %t520, !tbaa !23
  %t522 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t525 = icmp ne i32 %t521, %t522
  br i1 %t525, label %bb142, label %bb143
bb142:
  %t527 = getelementptr %"compiler/mir:Call", ptr %l46, i32 0, i32 7
  %t528 = load i32, ptr %t527, !tbaa !23
  %t530 = sext i32 %t528 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t530)
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  br label %bb198
bb146:
  %t533 = load { i64, [8 x i64] }, ptr %l33
  %t535 = extractvalue { i64, [8 x i64] } %t533, 0
  %t536 = icmp eq i64 %t535, 8
  br i1 %t536, label %bb147, label %bb148
bb147:
  %t538 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t539 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t538, i32 0, i32 2
  %t540 = load i32, ptr %t539
  store i32 %t540, ptr %l47, !tbaa !23
  %t542 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t543 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t542, i32 0, i32 4
  %t544 = load i32, ptr %t543
  store i32 %t544, ptr %l48, !tbaa !23
  br label %bb149
bb148:
  br label %bb155
bb149:
  %t546 = load i32, ptr %l47, !tbaa !23
  %t548 = sext i32 %t546 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t548)
  br label %bb150
bb150:
  %t551 = load i32, ptr %l48, !tbaa !23
  %t552 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t555 = icmp ne i32 %t551, %t552
  br i1 %t555, label %bb151, label %bb152
bb151:
  %t557 = load i32, ptr %l48, !tbaa !23
  %t559 = sext i32 %t557 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t559)
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb154
bb154:
  br label %bb198
bb155:
  %t562 = load { i64, [8 x i64] }, ptr %l33
  %t564 = extractvalue { i64, [8 x i64] } %t562, 0
  %t565 = icmp eq i64 %t564, 11
  br i1 %t565, label %bb156, label %bb157
bb156:
  %t567 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t567, i32 0, i32 2
  %t569 = load i32, ptr %t568
  store i32 %t569, ptr %l49, !tbaa !23
  %t571 = getelementptr { i64, [8 x i64] }, ptr %l33, i32 0, i32 1
  %t572 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t571, i32 0, i32 3
  %t573 = load %"compiler/mir:Range", ptr %t572
  store %"compiler/mir:Range" %t573, ptr %l50
  br label %bb158
bb157:
  br label %bb193
bb158:
  store i32 0, ptr %l51, !tbaa !23
  %t575 = getelementptr %"compiler/mir:Range", ptr %l50, i32 0, i32 1
  %t576 = load i32, ptr %t575, !tbaa !23
  store i32 %t576, ptr %l52, !tbaa !23
  store i32 1, ptr %l53, !tbaa !23
  %t578 = load i32, ptr %l52, !tbaa !23
  %t579 = load i32, ptr %l51, !tbaa !23
  %t582 = icmp sgt i32 %t578, %t579
  br i1 %t582, label %bb159, label %bb160
bb159:
  %t584 = load i32, ptr %l53, !tbaa !23
  %t586 = icmp sgt i32 %t584, 0
  br i1 %t586, label %bb161, label %bb162
bb160:
  store i32 0, ptr %l333, !tbaa !23
  br label %bb164
bb161:
  %t588 = load i32, ptr %l52, !tbaa !23
  %t589 = load i32, ptr %l51, !tbaa !23
  %t592 = sub i32 %t588, %t589
  %t593 = load i32, ptr %l53, !tbaa !23
  %t596 = add i32 %t592, %t593
  %t598 = sub i32 %t596, 1
  %t599 = load i32, ptr %l53, !tbaa !23
  %t602 = sdiv i32 %t598, %t599
  store i32 %t602, ptr %l336, !tbaa !23
  br label %bb163
bb162:
  store i32 0, ptr %l336, !tbaa !23
  br label %bb163
bb163:
  %t604 = load i32, ptr %l336, !tbaa !23
  store i32 %t604, ptr %l333, !tbaa !23
  br label %bb164
bb164:
  %t605 = load i32, ptr %l333, !tbaa !23
  store i32 %t605, ptr %l54, !tbaa !23
  store i32 0, ptr %l55, !tbaa !23
  br label %bb165
bb165:
  %t606 = load i32, ptr %l55, !tbaa !23
  %t607 = load i32, ptr %l54, !tbaa !23
  %t610 = icmp slt i32 %t606, %t607
  %t612 = xor i1 %t610, true
  br i1 %t612, label %bb166, label %bb167
bb166:
  br label %bb191
bb167:
  br label %bb168
bb168:
  %t614 = load i32, ptr %l51, !tbaa !23
  %t615 = load i32, ptr %l55, !tbaa !23
  %t616 = load i32, ptr %l53, !tbaa !23
  %t619 = mul i32 %t615, %t616
  %t622 = add i32 %t614, %t619
  %t624 = load ptr, ptr %l3, !tbaa !29
  %t626 = getelementptr %"compiler/mir:Fn", ptr %t624, i32 0, i32 12
  %t627 = getelementptr %"compiler/mir:Range", ptr %l50, i32 0, i32 0
  %t628 = load i32, ptr %t627, !tbaa !23
  %t630 = sext i32 %t628 to i64
  %t633 = sext i32 %t622 to i64
  %t636 = add i64 %t630, %t633
  %t639 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t626, i64 %t636)
  store { i64, [1 x i64] } %t639, ptr %l361
  br label %bb169
bb169:
  %t640 = load { i64, [1 x i64] }, ptr %l361
  store { i64, [1 x i64] } %t640, ptr %l57
  %t641 = load { i64, [1 x i64] }, ptr %l57
  %t643 = extractvalue { i64, [1 x i64] } %t641, 0
  %t644 = icmp eq i64 %t643, 0
  br i1 %t644, label %bb170, label %bb171
bb170:
  %t646 = getelementptr { i64, [1 x i64] }, ptr %l57, i32 0, i32 1
  %t647 = getelementptr { i32 }, ptr %t646, i32 0, i32 0
  %t648 = load i32, ptr %t647
  store i32 %t648, ptr %l58, !tbaa !23
  br label %bb172
bb171:
  br label %bb184
bb172:
  %t650 = load i32, ptr %l58, !tbaa !23
  %t652 = sext i32 %t650 to i64
  %t653 = load i64, ptr %l1, !tbaa !24
  %t656 = icmp eq i64 %t652, %t653
  br i1 %t656, label %bb173, label %bb174
bb173:
  %t658 = load i64, ptr %l13, !tbaa !24
  %t660 = icmp eq i64 %t658, 1
  store i1 %t660, ptr %l369, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb175
bb175:
  %t662 = load i1, ptr %l369, !tbaa !21
  br i1 %t662, label %bb176, label %bb177
bb176:
  %t663 = load i64, ptr %l21, !tbaa !24
  %t665 = icmp eq i64 %t663, 2
  br i1 %t665, label %bb178, label %bb179
bb177:
  br label %bb183
bb178:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t668 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t668, ptr %rv
  br label %ret
bb179:
  br label %bb180
bb180:
  %t669 = load ptr, ptr %lp7
  store ptr %t669, ptr %l375, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i64, ptr %l20, !tbaa !24
  %t674 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t670, i64 %t671, i64 -1)
  store i64 %t674, ptr %l378
  br label %bb181
bb181:
  %t675 = load i64, ptr %l21, !tbaa !24
  %t677 = icmp eq i64 %t675, 1
  %t678 = load ptr, ptr %l375, !tbaa !29
  %t679 = load i64, ptr %l378, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t678, i64 %t679, i1 %t677)
  br label %bb182
bb182:
  br label %bb183
bb183:
  br label %bb189
bb184:
  br i1 true, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @olang_loc_890404a92f80b8aa_6c292d1ce7c26ffe)
  unreachable
bb189:
  br label %bb190
bb190:
  %t681 = load i32, ptr %l55, !tbaa !23
  %t683 = add i32 %t681, 1
  store i32 %t683, ptr %l55, !tbaa !23
  br label %bb165
bb191:
  %t685 = load i32, ptr %l49, !tbaa !23
  %t687 = sext i32 %t685 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l32, i64 %t687)
  br label %bb192
bb192:
  br label %bb198
bb193:
  br i1 true, label %bb194, label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_6060a7068f6090fd_51500cf142c637d9)
  unreachable
bb198:
  %t690 = load i64, ptr %l13, !tbaa !24
  %t692 = icmp eq i64 %t690, 0
  br i1 %t692, label %bb199, label %bb200
bb199:
  store ptr %l32, ptr %l59, !tbaa !29
  store i64 0, ptr %l60, !tbaa !24
  br label %bb201
bb200:
  br label %bb210
bb201:
  %t695 = load i64, ptr %l60, !tbaa !24
  store i64 %t695, ptr %l389, !tbaa !24
  %t696 = load ptr, ptr %l59, !tbaa !29
  %t698 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s8, ptr %t696)
  store i64 %t698, ptr %l391
  br label %bb202
bb202:
  %t699 = load i64, ptr %l389, !tbaa !24
  %t700 = load i64, ptr %l391, !tbaa !24
  %t701 = icmp slt i64 %t699, %t700
  %t703 = xor i1 %t701, true
  br i1 %t703, label %bb203, label %bb204
bb203:
  br label %bb209
bb204:
  br label %bb205
bb205:
  %t705 = load ptr, ptr %l59, !tbaa !29
  %t706 = load i64, ptr %l60, !tbaa !24
  %t709 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s8, ptr %t705, i64 %t706)
  store i64 %t709, ptr %l396
  br label %bb206
bb206:
  %t710 = load i64, ptr %l396, !tbaa !24
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t714 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %s0, ptr %s0, ptr %t711, { i64, ptr } %t712, i64 %t710, i64 %t714, ptr %l6)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t720 = load i64, ptr %l60, !tbaa !24
  %t722 = add i64 %t720, 1
  store i64 %t722, ptr %l60, !tbaa !24
  br label %bb201
bb209:
  br label %bb210
bb210:
  call void @__olang_scope_close(ptr %s8)
  br label %bb211
bb211:
  br label %bb38
bb212:
  br label %bb213
bb213:
  %t724 = load i64, ptr %l12, !tbaa !24
  %t726 = add i64 %t724, 1
  store i64 %t726, ptr %l12, !tbaa !24
  br label %bb15
bb214:
  %t728 = load ptr, ptr %lp7
  %t729 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t728
  call void @__olang_scope_close(ptr %s0)
  %t731 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t729, 1
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t731, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }, ptr %rv
  ret { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { { i64, ptr }, { i64, ptr } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { { i64, ptr }, { i64, ptr } }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l45 = alloca { { i64, ptr }, { i64, ptr } }
  %l61 = alloca { { i64, ptr }, { i64, ptr } }
  %l78 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l112 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l137 = alloca i1
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l165 = alloca i32
  %l176 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l185 = alloca i64
  %l191 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, [4 x i64] }, ptr %l3
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t9, { i64, [4 x i64] } %t10)
  store i32 %t13, ptr %l35
  br label %bb1
bb1:
  %t14 = load i32, ptr %l35, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l3
  %t17 = load i32, ptr %l5, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t15, { i64, [4 x i64] } %t16, i32 %t17)
  store { i64, ptr } %t21, ptr %l39
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t25 = trunc i64 0 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = load i32, ptr %l5, !tbaa !23
  %t34 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %s0, ptr %s1, ptr %t28, { i64, ptr } %t29, i32 %t30)
  store { { i64, ptr }, { i64, ptr } } %t34, ptr %l45
  br label %bb6
bb6:
  %t35 = load { { i64, ptr }, { i64, ptr } }, ptr %l45
  store { { i64, ptr }, { i64, ptr } } %t35, ptr %l7
  %t36 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l8, !tbaa !27
  %t39 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l9, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/emit:fnEm", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s1, ptr %t45, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d412, i32 0, i32 1) })
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t51 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t54 = extractvalue { i64, ptr } %t48, 1
  %t55 = extractvalue { i64, ptr } %t48, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d414, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d414, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = extractvalue { i64, ptr } %t49, 1
  %t62 = extractvalue { i64, ptr } %t49, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t68 = extractvalue { i64, ptr } %t50, 1
  %t69 = extractvalue { i64, ptr } %t50, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t51, i64 %t52)
  %t75 = getelementptr i8, ptr %t74, i64 %t52
  call void @olang_textcopy(ptr %t75, ptr %t54, i64 %t55)
  %t76 = getelementptr i8, ptr %t75, i64 %t55
  call void @olang_textcopy(ptr %t76, ptr %t57, i64 %t58)
  %t77 = getelementptr i8, ptr %t76, i64 %t58
  call void @olang_textcopy(ptr %t77, ptr %t61, i64 %t62)
  %t78 = getelementptr i8, ptr %t77, i64 %t62
  call void @olang_textcopy(ptr %t78, ptr %t64, i64 %t65)
  %t79 = getelementptr i8, ptr %t78, i64 %t65
  call void @olang_textcopy(ptr %t79, ptr %t68, i64 %t69)
  %t80 = getelementptr i8, ptr %t79, i64 %t69
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t74, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s1, ptr %t47, { i64, ptr } %t89)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb101
bb9:
  %t92 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t94 = trunc i64 1 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = load i32, ptr %l5, !tbaa !23
  %t103 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %s0, ptr %s3, ptr %t97, { i64, ptr } %t98, i32 %t99)
  store { { i64, ptr }, { i64, ptr } } %t103, ptr %l61
  br label %bb13
bb13:
  %t104 = load { { i64, ptr }, { i64, ptr } }, ptr %l61
  store { { i64, ptr }, { i64, ptr } } %t104, ptr %l10
  %t105 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l10, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %s3, ptr %s3, ptr %t111, { i64, ptr } %t112, { i64, ptr } %t106, { i64, ptr } %t109, i64 34)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb101
bb15:
  %t119 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t121 = trunc i64 2 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb24
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/emit:fnEm", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s4, ptr %t127, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d417, i32 0, i32 1) })
  br label %bb19
bb19:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/emit:fnEm", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s4, ptr %t132, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d418, i32 0, i32 1) })
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t136 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t139 = extractvalue { i64, ptr } %t135, 1
  %t140 = extractvalue { i64, ptr } %t135, 0
  %t141 = add i64 %t137, %t140
  %t142 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t136, i64 %t137)
  %t146 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t146, ptr %t139, i64 %t140)
  %t147 = getelementptr i8, ptr %t146, i64 %t140
  call void @olang_textcopy(ptr %t147, ptr %t142, i64 %t143)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t159 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %t134, { i64, ptr } %t156)
  store { i64, ptr } %t159, ptr %l78
  br label %bb21
bb21:
  %t160 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s4, ptr %s0, ptr %s4, ptr %s4, ptr %t161, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, { i64, ptr } %t162, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb22
bb22:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t169 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t172 = extractvalue { i64, ptr } %t168, 1
  %t173 = extractvalue { i64, ptr } %t168, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t169, i64 %t170)
  %t179 = getelementptr i8, ptr %t178, i64 %t170
  call void @olang_textcopy(ptr %t179, ptr %t172, i64 %t173)
  %t180 = getelementptr i8, ptr %t179, i64 %t173
  call void @olang_textcopy(ptr %t180, ptr %t175, i64 %t176)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t178, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s4, ptr %t167, { i64, ptr } %t189)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb101
bb24:
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t194 = trunc i64 3 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb31
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s7, ptr %s7, ptr %t197, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d424, i32 0, i32 1) }, i64 0)
  store { i64, ptr } %t199, ptr %l89
  br label %bb28
bb28:
  %t200 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t200, ptr %l14, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s7, ptr %s0, ptr %s7, ptr %s7, ptr %t201, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d425, i32 0, i32 1) }, { i64, ptr } %t202, { i64, ptr } %t203, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb29
bb29:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %s7, ptr %s7, ptr %t207, { i64, ptr } %t208, { i64, ptr } %t209, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d426, i32 0, i32 1) }, i64 39)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb101
bb31:
  %t213 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t215 = trunc i64 4 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  %t218 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t220 = trunc i64 5 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb62
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/emit:fnEm", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s8, ptr %t226, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d427, i32 0, i32 1) })
  br label %bb37
bb37:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/emit:fnEm", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s8, ptr %t231, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d428, i32 0, i32 1) })
  br label %bb38
bb38:
  %t233 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t235 = trunc i64 5 to i32
  %t236 = icmp eq i32 %t233, %t235
  store i1 %t236, ptr %l15, !tbaa !21
  %t238 = load ptr, ptr %l4, !tbaa !29
  store ptr %t238, ptr %l106, !tbaa !29
  %t239 = load ptr, ptr %l4, !tbaa !29
  %t240 = load i32, ptr %l5, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l109
  br label %bb39
bb39:
  %t244 = load ptr, ptr %l106, !tbaa !29
  %t245 = load i32, ptr %l109, !tbaa !23
  %t246 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t244, i32 %t245)
  store i64 %t246, ptr %l110
  br label %bb40
bb40:
  %t247 = load i64, ptr %l110, !tbaa !24
  %t248 = icmp sgt i64 %t247, 64
  br i1 %t248, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d429, i32 0, i32 1) }, ptr %l112, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d430, i32 0, i32 1) }, ptr %l112, !tbaa !27
  br label %bb43
bb43:
  %t250 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t250, ptr %l16, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t253 = load i32, ptr %l5, !tbaa !23
  %t254 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t255 = load i1, ptr %l15, !tbaa !21
  %t256 = load ptr, ptr @__olang_prog_scope
  %t262 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eextend(ptr %v0, ptr %s0, ptr %t256, ptr %s8, ptr %t251, { i64, ptr } %t252, i32 %t253, { i64, ptr } %t254, i1 %t255)
  store { i64, ptr } %t262, ptr %l118
  br label %bb44
bb44:
  %t263 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t263, ptr %l17, !tbaa !27
  %t264 = load i1, ptr %l15, !tbaa !21
  br i1 %t264, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d431, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d432, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb47
bb47:
  %t266 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t266, ptr %l121, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t267, 0
  store i64 %t270, ptr %l124, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l125, !tbaa !24
  %t273 = icmp sge i64 1, 0
  br i1 %t273, label %bb48, label %bb49
bb48:
  %t275 = load i64, ptr %l124, !tbaa !24
  %t276 = icmp sle i64 1, %t275
  br i1 %t276, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_843b4d3d5fe86d0c_7c8978725a4736a0)
  unreachable
bb50:
  %t278 = load i64, ptr %l124, !tbaa !24
  %t279 = load i64, ptr %l125, !tbaa !24
  %t280 = icmp sle i64 %t278, %t279
  br i1 %t280, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_843b4d3d5fe86d0c_7c8978725a4736a0)
  unreachable
bb52:
  %t282 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l124, !tbaa !24
  %t285 = getelementptr i8, ptr %t283, i64 1
  %t286 = sub i64 %t284, 1
  %t287 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t285, 1
  %t289 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t293 = extractvalue { i64, ptr } %t288, 1
  %t294 = extractvalue { i64, ptr } %t288, 0
  %t295 = add i64 %t291, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t290, i64 %t291)
  %t297 = getelementptr i8, ptr %t296, i64 %t291
  call void @olang_textcopy(ptr %t297, ptr %t293, i64 %t294)
  %t298 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t296, 1
  store { i64, ptr } %t299, ptr %l18, !tbaa !27
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/emit:fnEm", ptr %t301, i32 0, i32 0
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s8, ptr %t304, { i64, ptr } %t305)
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_843b4d3d5fe86d0c_7c8978725a4736a0)
  unreachable
bb54:
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l134, !tbaa !29
  %t309 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t309, ptr %l135, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t311 = load ptr, ptr @__olang_prog_scope
  %t313 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t311, ptr %s8, { i64, ptr } %t310, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d433, i32 0, i32 1) })
  store i1 %t313, ptr %l137
  br label %bb55
bb55:
  %t314 = load i1, ptr %l137, !tbaa !21
  br i1 %t314, label %bb56, label %bb57
bb56:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d434, i32 0, i32 1) }, ptr %l138, !tbaa !27
  br label %bb58
bb57:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d435, i32 0, i32 1) }, ptr %l138, !tbaa !27
  br label %bb58
bb58:
  %t315 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t317 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = add i64 %t316, %t319
  %t321 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t323 = add i64 %t320, %t322
  %t324 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t315, i64 %t316)
  %t332 = getelementptr i8, ptr %t331, i64 %t316
  call void @olang_textcopy(ptr %t332, ptr %t318, i64 %t319)
  %t333 = getelementptr i8, ptr %t332, i64 %t319
  call void @olang_textcopy(ptr %t333, ptr %t321, i64 %t322)
  %t334 = getelementptr i8, ptr %t333, i64 %t322
  call void @olang_textcopy(ptr %t334, ptr %t325, i64 %t326)
  %t335 = getelementptr i8, ptr %t334, i64 %t326
  call void @olang_textcopy(ptr %t335, ptr %t328, i64 %t329)
  %t336 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t331, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t345 = load ptr, ptr %l134, !tbaa !29
  %t347 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t345, { i64, ptr } %t344)
  store { i64, ptr } %t347, ptr %l141
  br label %bb59
bb59:
  %t348 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t354 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t357 = extractvalue { i64, ptr } %t350, 1
  %t358 = extractvalue { i64, ptr } %t350, 0
  %t359 = add i64 %t355, %t358
  %t360 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t362 = add i64 %t359, %t361
  %t364 = extractvalue { i64, ptr } %t348, 1
  %t365 = extractvalue { i64, ptr } %t348, 0
  %t366 = add i64 %t362, %t365
  %t367 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t369 = add i64 %t366, %t368
  %t371 = extractvalue { i64, ptr } %t352, 1
  %t372 = extractvalue { i64, ptr } %t352, 0
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t378 = extractvalue { i64, ptr } %t353, 1
  %t379 = extractvalue { i64, ptr } %t353, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t354, i64 %t355)
  %t385 = getelementptr i8, ptr %t384, i64 %t355
  call void @olang_textcopy(ptr %t385, ptr %t357, i64 %t358)
  %t386 = getelementptr i8, ptr %t385, i64 %t358
  call void @olang_textcopy(ptr %t386, ptr %t360, i64 %t361)
  %t387 = getelementptr i8, ptr %t386, i64 %t361
  call void @olang_textcopy(ptr %t387, ptr %t364, i64 %t365)
  %t388 = getelementptr i8, ptr %t387, i64 %t365
  call void @olang_textcopy(ptr %t388, ptr %t367, i64 %t368)
  %t389 = getelementptr i8, ptr %t388, i64 %t368
  call void @olang_textcopy(ptr %t389, ptr %t371, i64 %t372)
  %t390 = getelementptr i8, ptr %t389, i64 %t372
  call void @olang_textcopy(ptr %t390, ptr %t374, i64 %t375)
  %t391 = getelementptr i8, ptr %t390, i64 %t375
  call void @olang_textcopy(ptr %t391, ptr %t378, i64 %t379)
  %t392 = getelementptr i8, ptr %t391, i64 %t379
  call void @olang_textcopy(ptr %t392, ptr %t381, i64 %t382)
  %t393 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t384, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t404 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t349, { i64, ptr } %t401)
  store { i64, ptr } %t404, ptr %l149
  br label %bb60
bb60:
  %t405 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t409 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t410 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t412 = extractvalue { i64, ptr } %t407, 1
  %t413 = extractvalue { i64, ptr } %t407, 0
  %t414 = add i64 %t410, %t413
  %t415 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t416 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t417 = add i64 %t414, %t416
  %t419 = extractvalue { i64, ptr } %t405, 1
  %t420 = extractvalue { i64, ptr } %t405, 0
  %t421 = add i64 %t417, %t420
  %t422 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t424 = add i64 %t421, %t423
  %t425 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t409, i64 %t410)
  %t426 = getelementptr i8, ptr %t425, i64 %t410
  call void @olang_textcopy(ptr %t426, ptr %t412, i64 %t413)
  %t427 = getelementptr i8, ptr %t426, i64 %t413
  call void @olang_textcopy(ptr %t427, ptr %t415, i64 %t416)
  %t428 = getelementptr i8, ptr %t427, i64 %t416
  call void @olang_textcopy(ptr %t428, ptr %t419, i64 %t420)
  %t429 = getelementptr i8, ptr %t428, i64 %t420
  call void @olang_textcopy(ptr %t429, ptr %t422, i64 %t423)
  %t430 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t425, 1
  %t433 = extractvalue { i64, ptr } %t431, 0
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t406, { i64, ptr } %t438)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  br label %bb101
bb62:
  %t441 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t443 = trunc i64 6 to i32
  %t444 = icmp eq i32 %t441, %t443
  br i1 %t444, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb90
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/emit:fnEm", ptr %t446, i32 0, i32 0
  %t449 = load ptr, ptr %t448, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s13, ptr %t449, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d447, i32 0, i32 1) })
  br label %bb66
bb66:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/emit:fnEm", ptr %t451, i32 0, i32 0
  %t454 = load ptr, ptr %t453, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s13, ptr %t454, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d448, i32 0, i32 1) })
  br label %bb67
bb67:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/emit:fnEm", ptr %t456, i32 0, i32 0
  %t459 = load ptr, ptr %t458, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s13, ptr %t459, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d449, i32 0, i32 1) })
  br label %bb68
bb68:
  %t461 = load ptr, ptr %l4, !tbaa !29
  %t462 = load i32, ptr %l5, !tbaa !23
  %t465 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t461, i32 %t462)
  store i32 %t465, ptr %l165
  br label %bb69
bb69:
  %t466 = load i32, ptr %l165, !tbaa !23
  store i32 %t466, ptr %l21, !tbaa !23
  store i64 0, ptr %l22, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 1
  %t470 = extractvalue { i64, ptr } %t467, 0
  %t471 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t470)
  call void @olang_textcopy(ptr %t471, ptr %t469, i64 %t470)
  %t472 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  store { i64, ptr } %t473, ptr %l23, !tbaa !27
  %t475 = load i32, ptr %l21, !tbaa !23
  %t477 = icmp eq i32 %t475, 13
  br i1 %t477, label %bb70, label %bb71
bb70:
  store i64 1, ptr %l22, !tbaa !24
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t479 = load i32, ptr %l21, !tbaa !23
  %t481 = icmp eq i32 %t479, 11
  br i1 %t481, label %bb73, label %bb74
bb73:
  store i64 2, ptr %l22, !tbaa !24
  br label %bb75
bb74:
  br label %bb75
bb75:
  %t483 = load i32, ptr %l21, !tbaa !23
  %t485 = icmp eq i32 %t483, 12
  br i1 %t485, label %bb76, label %bb77
bb76:
  store i64 3, ptr %l22, !tbaa !24
  br label %bb78
bb77:
  br label %bb78
bb78:
  %t487 = load i64, ptr %l22, !tbaa !24
  %t489 = icmp ne i64 %t487, 0
  br i1 %t489, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l176, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l21, !tbaa !23
  %t496 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s18, ptr %t492, i32 %t493)
  store { i64, ptr } %t496, ptr %l179
  br label %bb81
bb80:
  br label %bb86
bb81:
  %t497 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t498 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t500 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t500, 1
  %t502 = extractvalue { i64, ptr } %t500, 0
  %t503 = add i64 %t499, %t502
  %t504 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t508 = extractvalue { i64, ptr } %t497, 1
  %t509 = extractvalue { i64, ptr } %t497, 0
  %t510 = add i64 %t506, %t509
  %t511 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t513 = add i64 %t510, %t512
  %t514 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t513)
  call void @olang_textcopy(ptr %t514, ptr %t498, i64 %t499)
  %t515 = getelementptr i8, ptr %t514, i64 %t499
  call void @olang_textcopy(ptr %t515, ptr %t501, i64 %t502)
  %t516 = getelementptr i8, ptr %t515, i64 %t502
  call void @olang_textcopy(ptr %t516, ptr %t504, i64 %t505)
  %t517 = getelementptr i8, ptr %t516, i64 %t505
  call void @olang_textcopy(ptr %t517, ptr %t508, i64 %t509)
  %t518 = getelementptr i8, ptr %t517, i64 %t509
  call void @olang_textcopy(ptr %t518, ptr %t511, i64 %t512)
  %t519 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t514, 1
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t523 = extractvalue { i64, ptr } %t520, 1
  %t524 = mul i64 %t522, 1
  %t525 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t525, ptr %t523, i64 %t524, i1 false)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t528 = load ptr, ptr %l176, !tbaa !29
  %t530 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s13, ptr %s13, ptr %t528, { i64, ptr } %t527)
  store { i64, ptr } %t530, ptr %l183
  br label %bb82
bb82:
  %t531 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  %t533 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t533, 0
  store i64 %t534, ptr %l185, !tbaa !24
  %t536 = load i64, ptr %l185, !tbaa !24
  %t537 = icmp eq i64 %t532, %t536
  br i1 %t537, label %bb83, label %bb84
bb83:
  %t539 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = load i64, ptr %l185, !tbaa !24
  %t544 = mul i64 %t543, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t540, ptr %t542, i64 %t544, i1 false)
  br label %bb85
bb84:
  %t545 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t545, ptr %l23, !tbaa !27
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb86
bb86:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t548 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t551 = extractvalue { i64, ptr } %t547, 1
  %t552 = extractvalue { i64, ptr } %t547, 0
  %t553 = add i64 %t549, %t552
  %t554 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t555 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t556 = add i64 %t553, %t555
  %t557 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t556)
  call void @olang_textcopy(ptr %t557, ptr %t548, i64 %t549)
  %t558 = getelementptr i8, ptr %t557, i64 %t549
  call void @olang_textcopy(ptr %t558, ptr %t551, i64 %t552)
  %t559 = getelementptr i8, ptr %t558, i64 %t552
  call void @olang_textcopy(ptr %t559, ptr %t554, i64 %t555)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t557, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = extractvalue { i64, ptr } %t561, 1
  %t565 = mul i64 %t563, 1
  %t566 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t565)
  call void @llvm.memcpy.p0.p0.i64(ptr %t566, ptr %t564, i64 %t565, i1 false)
  %t567 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t566, 1
  %t571 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s13, ptr %s13, ptr %t546, { i64, ptr } %t568)
  store { i64, ptr } %t571, ptr %l191
  br label %bb87
bb87:
  %t572 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t576 = load i64, ptr %l22, !tbaa !24
  %t577 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t580 = extractvalue { i64, ptr } %t572, 1
  %t581 = extractvalue { i64, ptr } %t572, 0
  %t582 = add i64 %t578, %t581
  %t583 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t585 = add i64 %t582, %t584
  %t587 = extractvalue { i64, ptr } %t575, 1
  %t588 = extractvalue { i64, ptr } %t575, 0
  %t589 = add i64 %t585, %t588
  %t590 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t591 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t592 = add i64 %t589, %t591
  %t594 = call i64 @__olang_fmt_i64(ptr null, i64 %t576)
  %t595 = add i64 %t592, %t594
  %t596 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t598 = add i64 %t595, %t597
  %t599 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t598)
  call void @olang_textcopy(ptr %t599, ptr %t577, i64 %t578)
  %t600 = getelementptr i8, ptr %t599, i64 %t578
  call void @olang_textcopy(ptr %t600, ptr %t580, i64 %t581)
  %t601 = getelementptr i8, ptr %t600, i64 %t581
  call void @olang_textcopy(ptr %t601, ptr %t583, i64 %t584)
  %t602 = getelementptr i8, ptr %t601, i64 %t584
  call void @olang_textcopy(ptr %t602, ptr %t587, i64 %t588)
  %t603 = getelementptr i8, ptr %t602, i64 %t588
  call void @olang_textcopy(ptr %t603, ptr %t590, i64 %t591)
  %t604 = getelementptr i8, ptr %t603, i64 %t591
  %t605 = call i64 @__olang_fmt_i64(ptr %t604, i64 %t576)
  %t606 = getelementptr i8, ptr %t604, i64 %t594
  call void @olang_textcopy(ptr %t606, ptr %t596, i64 %t597)
  %t607 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t599, 1
  %t610 = extractvalue { i64, ptr } %t608, 0
  %t611 = extractvalue { i64, ptr } %t608, 1
  %t612 = mul i64 %t610, 1
  %t613 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t612)
  call void @llvm.memcpy.p0.p0.i64(ptr %t613, ptr %t611, i64 %t612, i1 false)
  %t614 = insertvalue { i64, ptr } undef, i64 %t610, 0
  %t615 = insertvalue { i64, ptr } %t614, ptr %t613, 1
  %t618 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s13, ptr %s13, ptr %t573, { i64, ptr } %t615)
  store { i64, ptr } %t618, ptr %l198
  br label %bb88
bb88:
  %t619 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t623 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t624 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t626 = extractvalue { i64, ptr } %t621, 1
  %t627 = extractvalue { i64, ptr } %t621, 0
  %t628 = add i64 %t624, %t627
  %t629 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t630 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t631 = add i64 %t628, %t630
  %t633 = extractvalue { i64, ptr } %t619, 1
  %t634 = extractvalue { i64, ptr } %t619, 0
  %t635 = add i64 %t631, %t634
  %t636 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t638 = add i64 %t635, %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t638)
  call void @olang_textcopy(ptr %t639, ptr %t623, i64 %t624)
  %t640 = getelementptr i8, ptr %t639, i64 %t624
  call void @olang_textcopy(ptr %t640, ptr %t626, i64 %t627)
  %t641 = getelementptr i8, ptr %t640, i64 %t627
  call void @olang_textcopy(ptr %t641, ptr %t629, i64 %t630)
  %t642 = getelementptr i8, ptr %t641, i64 %t630
  call void @olang_textcopy(ptr %t642, ptr %t633, i64 %t634)
  %t643 = getelementptr i8, ptr %t642, i64 %t634
  call void @olang_textcopy(ptr %t643, ptr %t636, i64 %t637)
  %t644 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t639, 1
  %t647 = extractvalue { i64, ptr } %t645, 0
  %t648 = extractvalue { i64, ptr } %t645, 1
  %t649 = mul i64 %t647, 1
  %t650 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t649)
  call void @llvm.memcpy.p0.p0.i64(ptr %t650, ptr %t648, i64 %t649, i1 false)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t650, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s13, ptr %t620, { i64, ptr } %t652)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s13)
  br label %bb101
bb90:
  %t655 = load i32, ptr %l2, !range !{i32 0, i32 8}
  %t657 = trunc i64 7 to i32
  %t658 = icmp eq i32 %t655, %t657
  br i1 %t658, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb100
bb93:
  store %olang.scope zeroinitializer, ptr %s23
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = getelementptr %"compiler/emit:fnEm", ptr %t660, i32 0, i32 0
  %t663 = load ptr, ptr %t662, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s23, ptr %t663, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d462, i32 0, i32 1) })
  br label %bb94
bb94:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/emit:fnEm", ptr %t665, i32 0, i32 0
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t670 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s23, ptr %s23, ptr %t668, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d463, i32 0, i32 1) })
  store { i64, ptr } %t670, ptr %l210
  br label %bb95
bb95:
  %t671 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t671, ptr %l26, !tbaa !27
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = getelementptr %"compiler/emit:fnEm", ptr %t672, i32 0, i32 0
  %t675 = load ptr, ptr %t674, !tbaa !29
  %t677 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s23, ptr %s23, ptr %t675, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d464, i32 0, i32 1) })
  store { i64, ptr } %t677, ptr %l213
  br label %bb96
bb96:
  %t678 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t681 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t683 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t684 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t686 = extractvalue { i64, ptr } %t680, 1
  %t687 = extractvalue { i64, ptr } %t680, 0
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t690 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t691 = add i64 %t688, %t690
  %t693 = extractvalue { i64, ptr } %t681, 1
  %t694 = extractvalue { i64, ptr } %t681, 0
  %t695 = add i64 %t691, %t694
  %t696 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t698 = add i64 %t695, %t697
  %t700 = extractvalue { i64, ptr } %t678, 1
  %t701 = extractvalue { i64, ptr } %t678, 0
  %t702 = add i64 %t698, %t701
  %t703 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t702)
  call void @olang_textcopy(ptr %t703, ptr %t683, i64 %t684)
  %t704 = getelementptr i8, ptr %t703, i64 %t684
  call void @olang_textcopy(ptr %t704, ptr %t686, i64 %t687)
  %t705 = getelementptr i8, ptr %t704, i64 %t687
  call void @olang_textcopy(ptr %t705, ptr %t689, i64 %t690)
  %t706 = getelementptr i8, ptr %t705, i64 %t690
  call void @olang_textcopy(ptr %t706, ptr %t693, i64 %t694)
  %t707 = getelementptr i8, ptr %t706, i64 %t694
  call void @olang_textcopy(ptr %t707, ptr %t696, i64 %t697)
  %t708 = getelementptr i8, ptr %t707, i64 %t697
  call void @olang_textcopy(ptr %t708, ptr %t700, i64 %t701)
  %t709 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t703, 1
  %t712 = extractvalue { i64, ptr } %t710, 0
  %t713 = extractvalue { i64, ptr } %t710, 1
  %t714 = mul i64 %t712, 1
  %t715 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t715, ptr %t713, i64 %t714, i1 false)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  %t720 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s23, ptr %s23, ptr %t679, { i64, ptr } %t717)
  store { i64, ptr } %t720, ptr %l220
  br label %bb97
bb97:
  %t721 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t721, ptr %l28, !tbaa !27
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t724 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t725 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t727 = extractvalue { i64, ptr } %t723, 1
  %t728 = extractvalue { i64, ptr } %t723, 0
  %t729 = add i64 %t725, %t728
  %t730 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t731 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t732 = add i64 %t729, %t731
  %t733 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t732)
  call void @olang_textcopy(ptr %t733, ptr %t724, i64 %t725)
  %t734 = getelementptr i8, ptr %t733, i64 %t725
  call void @olang_textcopy(ptr %t734, ptr %t727, i64 %t728)
  %t735 = getelementptr i8, ptr %t734, i64 %t728
  call void @olang_textcopy(ptr %t735, ptr %t730, i64 %t731)
  %t736 = insertvalue { i64, ptr } undef, i64 %t732, 0
  %t737 = insertvalue { i64, ptr } %t736, ptr %t733, 1
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t740 = extractvalue { i64, ptr } %t737, 1
  %t741 = mul i64 %t739, 1
  %t742 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t741)
  call void @llvm.memcpy.p0.p0.i64(ptr %t742, ptr %t740, i64 %t741, i1 false)
  %t743 = insertvalue { i64, ptr } undef, i64 %t739, 0
  %t744 = insertvalue { i64, ptr } %t743, ptr %t742, 1
  %t747 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s23, ptr %s23, ptr %t722, { i64, ptr } %t744)
  store { i64, ptr } %t747, ptr %l225
  br label %bb98
bb98:
  %t748 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t751 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t753 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t754 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t756 = extractvalue { i64, ptr } %t750, 1
  %t757 = extractvalue { i64, ptr } %t750, 0
  %t758 = add i64 %t754, %t757
  %t759 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t760 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t761 = add i64 %t758, %t760
  %t763 = extractvalue { i64, ptr } %t751, 1
  %t764 = extractvalue { i64, ptr } %t751, 0
  %t765 = add i64 %t761, %t764
  %t766 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d471, i32 0, i32 1) }, 1
  %t767 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d471, i32 0, i32 1) }, 0
  %t768 = add i64 %t765, %t767
  %t770 = extractvalue { i64, ptr } %t748, 1
  %t771 = extractvalue { i64, ptr } %t748, 0
  %t772 = add i64 %t768, %t771
  %t773 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t774 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t775 = add i64 %t772, %t774
  %t776 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t775)
  call void @olang_textcopy(ptr %t776, ptr %t753, i64 %t754)
  %t777 = getelementptr i8, ptr %t776, i64 %t754
  call void @olang_textcopy(ptr %t777, ptr %t756, i64 %t757)
  %t778 = getelementptr i8, ptr %t777, i64 %t757
  call void @olang_textcopy(ptr %t778, ptr %t759, i64 %t760)
  %t779 = getelementptr i8, ptr %t778, i64 %t760
  call void @olang_textcopy(ptr %t779, ptr %t763, i64 %t764)
  %t780 = getelementptr i8, ptr %t779, i64 %t764
  call void @olang_textcopy(ptr %t780, ptr %t766, i64 %t767)
  %t781 = getelementptr i8, ptr %t780, i64 %t767
  call void @olang_textcopy(ptr %t781, ptr %t770, i64 %t771)
  %t782 = getelementptr i8, ptr %t781, i64 %t771
  call void @olang_textcopy(ptr %t782, ptr %t773, i64 %t774)
  %t783 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t784 = insertvalue { i64, ptr } %t783, ptr %t776, 1
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t787 = extractvalue { i64, ptr } %t784, 1
  %t788 = mul i64 %t786, 1
  %t789 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t788)
  call void @llvm.memcpy.p0.p0.i64(ptr %t789, ptr %t787, i64 %t788, i1 false)
  %t790 = insertvalue { i64, ptr } undef, i64 %t786, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t789, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s23, ptr %t749, { i64, ptr } %t791)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s23)
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e171e8330ea33f7a_82d9a571b3024c8e)
  unreachable
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca i8
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb27
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 34
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = icmp eq i8 %t29, 92
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp ult i8 %t34, 32
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t43 = icmp ugt i8 %t40, 126
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb17
bb16:
  %t47 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t47)
  br label %bb24
bb17:
  store ptr %l1, ptr %l31, !tbaa !29
  %t50 = load i8, ptr %l5, !tbaa !22
  store i8 %t50, ptr %l33, !tbaa !22
  %t52 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 16)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l35
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb19, label %ok.56, !prof !99
ok.56:
  store i64 %t53, ptr %l34
  br label %bb18
bb18:
  %t57 = load i8, ptr %l33, !tbaa !22
  %t58 = load i64, ptr %l34, !tbaa !24
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s3, i8 %t57, i64 %t58)
  store { i64, ptr } %t59, ptr %l36
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b05c5d37656b7ecf_b2cabd35ece02ebb)
  unreachable
bb20:
  %t60 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s3, ptr %s3, { i64, ptr } %t66, i64 2, i8 48)
  store { i64, ptr } %t68, ptr %l38
  br label %bb21
bb21:
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %s3, ptr %s3, { i64, ptr } %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb22
bb22:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t85 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t85, { i64, ptr } %t84)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb2
bb27:
  %t92 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t92, ptr %l47
  br label %bb28
bb28:
  %t93 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t93, ptr %l48, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l49, !tbaa !24
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l50, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t107, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2efuzzCorpus(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d473, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v1, ptr %s1, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l10
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb8:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l15, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l16, !tbaa !24
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb11, label %bb12
bb10:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l22, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb17, label %bb18
bb11:
  %t43 = icmp sle i64 0, 1
  br i1 %t43, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb13:
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = icmp sle i64 1, %t45
  br i1 %t46, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb15:
  %t48 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 0
  %t51 = sub i64 1, 0
  %t52 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  store { i64, ptr } %t53, ptr %l14, !tbaa !27
  br label %bb23
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb17:
  %t55 = load i64, ptr %l22, !tbaa !24
  %t56 = icmp sle i64 0, %t55
  br i1 %t56, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb19:
  %t58 = load i64, ptr %l22, !tbaa !24
  %t59 = load i64, ptr %l23, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb21:
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l22, !tbaa !24
  %t65 = getelementptr i8, ptr %t63, i64 0
  %t66 = sub i64 %t64, 0
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  store { i64, ptr } %t68, ptr %l14, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2)
  unreachable
bb23:
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v1, ptr %s0, { i64, ptr } %t70)
  store { i64, ptr } %t72, ptr %l29
  br label %bb24
bb24:
  %t73 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t76, i64 %t77)
  %t85 = getelementptr i8, ptr %t84, i64 %t77
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2femit_2emathExactTable(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t4 = load ptr, ptr %lp0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t6 = insertvalue [7 x { i64, ptr }] %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t7 = insertvalue [7 x { i64, ptr }] %t6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d478, i32 0, i32 1) }, 2
  %t8 = insertvalue [7 x { i64, ptr }] %t7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d479, i32 0, i32 1) }, 3
  %t9 = insertvalue [7 x { i64, ptr }] %t8, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d480, i32 0, i32 1) }, 4
  %t10 = insertvalue [7 x { i64, ptr }] %t9, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d481, i32 0, i32 1) }, 5
  %t11 = insertvalue [7 x { i64, ptr }] %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d482, i32 0, i32 1) }, 6
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 112, i64 8)
  store [7 x { i64, ptr }] %t11, ptr %t13
  store ptr %t13, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l1
  store i64 7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr [7 x { i64, ptr }], ptr %t26, i64 0, i64 %t27
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  %t33 = load ptr, ptr %lp0
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %t35, ptr %t33, { i64, ptr } %t31, i64 1)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l2, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %lp0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t42, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d483, i32 0, i32 1) }, i64 2)
  br label %bb9
bb9:
  %t44 = load ptr, ptr %lp0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d484, i32 0, i32 1) }, i64 3)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %lp0
  %t47 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l50 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l118 = alloca i1
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb94
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l4, !tbaa !22
  %t25 = load i8, ptr %l4, !tbaa !22
  %t27 = icmp eq i8 %t25, 34
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  %t33 = load i8, ptr %l4, !tbaa !22
  %t35 = icmp eq i8 %t33, 59
  br i1 %t35, label %bb17, label %bb18
bb8:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l26, !tbaa !27
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 %t44
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp ne i8 %t49, 34
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t53 = load i1, ptr %l25, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l3, !tbaa !24
  br label %bb92
bb17:
  br label %bb19
bb18:
  %t64 = load i8, ptr %l4, !tbaa !22
  %t66 = icmp eq i8 %t64, 37
  br i1 %t66, label %bb28, label %bb29
bb19:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l41, !tbaa !27
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t75
  %t80 = load i8, ptr %t79, !tbaa !32
  %t82 = icmp ne i8 %t80, 10
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l40, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb19
bb27:
  br label %bb91
bb28:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = add i64 %t91, 1
  %t94 = load i64, ptr %l2, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l50, !tbaa !21
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l56, !tbaa !27
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = add i64 %t101, 1
  %t105 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i8, ptr %t106, i64 %t103
  %t108 = load i8, ptr %t107, !tbaa !32
  %t110 = icmp eq i8 %t108, 34
  store i1 %t110, ptr %l55, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb33
bb33:
  %t112 = load i1, ptr %l55, !tbaa !21
  br i1 %t112, label %bb34, label %bb35
bb34:
  %t113 = load i64, ptr %l3, !tbaa !24
  %t115 = add i64 %t113, 2
  store i64 %t115, ptr %l5, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  store i64 %t117, ptr %l3, !tbaa !24
  br label %bb36
bb35:
  %t119 = load i8, ptr %l4, !tbaa !22
  %t121 = icmp eq i8 %t119, 64
  br i1 %t121, label %bb48, label %bb49
bb36:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t124 = load i64, ptr %l2, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t129, ptr %l68, !tbaa !27
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t130
  %t135 = load i8, ptr %t134, !tbaa !32
  %t137 = icmp ne i8 %t135, 34
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb39
bb39:
  %t139 = load i1, ptr %l67, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t142 = load i64, ptr %l3, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb36
bb44:
  %t146 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t146, i64 1)
  br label %bb45
bb45:
  %t148 = load ptr, ptr %lp1
  %t149 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t148, i64 %t149)
  br label %bb46
bb46:
  %t152 = load ptr, ptr %lp1
  %t153 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t152, i64 %t153)
  br label %bb47
bb47:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l3, !tbaa !24
  br label %bb90
bb48:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l6, !tbaa !24
  store i64 %t164, ptr %l3, !tbaa !24
  br label %bb50
bb49:
  %t166 = load i8, ptr %l4, !tbaa !22
  %t168 = icmp eq i8 %t166, 33
  br i1 %t168, label %bb66, label %bb67
bb50:
  %t170 = load i64, ptr %l3, !tbaa !24
  %t171 = load i64, ptr %l2, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  br i1 %t174, label %bb51, label %bb52
bb51:
  %t176 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t176, ptr %l91, !tbaa !27
  %t177 = load i64, ptr %l3, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 %t177
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = call i1 @compiler_2femit_2esymbolChar(i8 %t182)
  store i1 %t184, ptr %l94
  br label %bb53
bb52:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb54
bb53:
  %t185 = load i1, ptr %l94, !tbaa !21
  store i1 %t185, ptr %l90, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l90, !tbaa !21
  %t187 = xor i1 %t186, true
  br i1 %t187, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l3, !tbaa !24
  br label %bb58
bb58:
  br label %bb50
bb59:
  %t193 = load i64, ptr %l3, !tbaa !24
  %t194 = load i64, ptr %l6, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb60, label %bb61
bb60:
  %t199 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t199, i64 0)
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t201 = load ptr, ptr %lp1
  %t202 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t201, i64 %t202)
  br label %bb63
bb63:
  %t205 = load ptr, ptr %lp1
  %t206 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t205, i64 %t206)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb89
bb66:
  %t209 = load i64, ptr %l3, !tbaa !24
  %t211 = add i64 %t209, 1
  %t212 = load i64, ptr %l2, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  store i1 %t215, ptr %l108, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb68
bb68:
  %t217 = load i1, ptr %l108, !tbaa !21
  br i1 %t217, label %bb69, label %bb70
bb69:
  %t218 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t218, ptr %l114, !tbaa !27
  %t219 = load i64, ptr %l3, !tbaa !24
  %t221 = add i64 %t219, 1
  %t223 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i8, ptr %t224, i64 %t221
  %t226 = load i8, ptr %t225, !tbaa !32
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t226)
  store i1 %t228, ptr %l118
  br label %bb71
bb70:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb72
bb71:
  %t229 = load i1, ptr %l118, !tbaa !21
  store i1 %t229, ptr %l113, !tbaa !21
  br label %bb72
bb72:
  %t230 = load i1, ptr %l113, !tbaa !21
  br i1 %t230, label %bb73, label %bb74
bb73:
  %t231 = load i64, ptr %l3, !tbaa !24
  store i64 %t231, ptr %l7, !tbaa !24
  %t233 = load i64, ptr %l3, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l3, !tbaa !24
  br label %bb75
bb74:
  %t237 = load i64, ptr %l3, !tbaa !24
  %t239 = add i64 %t237, 1
  store i64 %t239, ptr %l3, !tbaa !24
  br label %bb88
bb75:
  %t241 = load i64, ptr %l3, !tbaa !24
  %t242 = load i64, ptr %l2, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  br i1 %t245, label %bb76, label %bb77
bb76:
  %t247 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t247, ptr %l126, !tbaa !27
  %t248 = load i64, ptr %l3, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i8, ptr %t251, i64 %t248
  %t253 = load i8, ptr %t252, !tbaa !32
  %t255 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t253)
  store i1 %t255, ptr %l129
  br label %bb78
bb77:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb79
bb78:
  %t256 = load i1, ptr %l129, !tbaa !21
  store i1 %t256, ptr %l125, !tbaa !21
  br label %bb79
bb79:
  %t257 = load i1, ptr %l125, !tbaa !21
  %t258 = xor i1 %t257, true
  br i1 %t258, label %bb80, label %bb81
bb80:
  br label %bb84
bb81:
  br label %bb82
bb82:
  %t260 = load i64, ptr %l3, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l3, !tbaa !24
  br label %bb83
bb83:
  br label %bb75
bb84:
  %t264 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t264, i64 2)
  br label %bb85
bb85:
  %t266 = load ptr, ptr %lp1
  %t267 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t266, i64 %t267)
  br label %bb86
bb86:
  %t270 = load ptr, ptr %lp1
  %t271 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t270, i64 %t271)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb2
bb94:
  %t274 = load ptr, ptr %lp1
  %t275 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t274
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2femit_2etempNumber(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sge i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 116
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = add i64 %t23, 2
  %t27 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t30)
  store i1 %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l1, !tbaa !24
  %t40 = add i64 %t38, 2
  store i64 %t40, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t54)
  store i1 %t56, ptr %l32
  br label %bb14
bb13:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb15
bb14:
  %t57 = load i1, ptr %l32, !tbaa !21
  store i1 %t57, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l28, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t61, 10
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l36, !tbaa !27
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i64
  %t75 = add i64 %t63, %t72
  %t76 = zext i8 48 to i64
  %t79 = sub i64 %t75, %t76
  store i64 %t79, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  br label %bb11
bb20:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l49, !tbaa !27
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t92
  %t97 = load i8, ptr %t96, !tbaa !32
  %t99 = call i1 @compiler_2femit_2esymbolChar(i8 %t97)
  store i1 %t99, ptr %l52
  br label %bb23
bb22:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb24
bb23:
  %t100 = load i1, ptr %l52, !tbaa !21
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  store i64 -1, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t103 = load i64, ptr %l4, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_3acDecls_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"compiler/emit:cDecls"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l4
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l5
  br label %bb3
bb3:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t7 = getelementptr %"compiler/emit:cDecls", ptr %l6, i32 0, i32 0
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t7
  %t9 = getelementptr %"compiler/emit:cDecls", ptr %l6, i32 0, i32 1
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t9
  %t11 = getelementptr %"compiler/emit:cDecls", ptr %l6, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l52 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l57 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l58 = alloca %"compiler/emit:fnEm"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store ptr %a1, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } %a2, ptr %l5
  %t7 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l43
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  %t9 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l44
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t10, ptr %l7
  %t11 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l45
  br label %bb3
bb3:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t12, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  store i1 false, ptr %l17, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d485, i32 0, i32 1) }, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t15 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l47
  br label %bb4
bb4:
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l20
  store i64 -1, ptr %l21, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d486, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l48
  br label %bb5
bb5:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %l23
  %t19 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l49
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l49
  store %"std/prelude/text:StringBuilder" %t20, ptr %l24
  %t21 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t21, ptr %l50
  br label %bb7
bb7:
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %l25
  store i1 false, ptr %l26, !tbaa !21
  %t23 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l51
  br label %bb8
bb8:
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l51
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l27
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l52
  br label %bb9
bb9:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l52
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %l28
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l53
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l29
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l54
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l30
  store i1 false, ptr %l31, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d487, i32 0, i32 1) }, ptr %l32, !tbaa !27
  store i1 false, ptr %l33, !tbaa !21
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l55
  br label %bb12
bb12:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l34
  %t33 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l56
  br label %bb13
bb13:
  %t34 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l35
  %t35 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l57
  br label %bb14
bb14:
  %t36 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l57
  %t37 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 0
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %t37, !tbaa !29
  %t39 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 1
  %t40 = load ptr, ptr %l4, !tbaa !29
  store ptr %t40, ptr %t39, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 2
  %t42 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t42, ptr %t41
  %t43 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 3
  %t44 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t44, ptr %t43
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 4
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t46, ptr %t45
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 5
  %t48 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t48, ptr %t47
  %t49 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 6
  %t50 = load i64, ptr %l9, !tbaa !24
  store i64 %t50, ptr %t49, !tbaa !24
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 7
  %t52 = load i64, ptr %l10, !tbaa !24
  store i64 %t52, ptr %t51, !tbaa !24
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 8
  %t54 = load i64, ptr %l11, !tbaa !24
  store i64 %t54, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 9
  %t56 = load i32, ptr %l12, !tbaa !23
  store i32 %t56, ptr %t55, !tbaa !23
  %t57 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 10
  %t58 = load i1, ptr %l13, !tbaa !21
  store i1 %t58, ptr %t57, !tbaa !21
  %t59 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 11
  %t60 = load i1, ptr %l14, !tbaa !21
  store i1 %t60, ptr %t59, !tbaa !21
  %t61 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 12
  %t62 = load i1, ptr %l15, !tbaa !21
  store i1 %t62, ptr %t61, !tbaa !21
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 13
  %t64 = load i1, ptr %l16, !tbaa !21
  store i1 %t64, ptr %t63, !tbaa !21
  %t65 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 14
  %t66 = load i1, ptr %l17, !tbaa !21
  store i1 %t66, ptr %t65, !tbaa !21
  %t67 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 15
  %t68 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t68, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 16
  %t70 = load i64, ptr %l19, !tbaa !24
  store i64 %t70, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 17
  %t72 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %t71
  %t73 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 18
  %t74 = load i64, ptr %l21, !tbaa !24
  store i64 %t74, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 19
  %t76 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t76, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 20
  %t78 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t78, ptr %t77
  %t79 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 21
  %t80 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t80, ptr %t79
  %t81 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 22
  %t82 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t82, ptr %t81
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 23
  %t84 = load i1, ptr %l26, !tbaa !21
  store i1 %t84, ptr %t83, !tbaa !21
  %t85 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 24
  %t86 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t86, ptr %t85
  %t87 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 25
  %t88 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %t87
  %t89 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 26
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t89
  %t91 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 27
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %t91
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 28
  %t94 = load i1, ptr %l31, !tbaa !21
  store i1 %t94, ptr %t93, !tbaa !21
  %t95 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 29
  %t96 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t96, ptr %t95, !tbaa !27
  %t97 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 30
  %t98 = load i1, ptr %l33, !tbaa !21
  store i1 %t98, ptr %t97, !tbaa !21
  %t99 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 31
  %t100 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t100, ptr %t99
  %t101 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 32
  %t102 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t102, ptr %t101
  %t103 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t36, ptr %t103
  %t105 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 34
  store i64 0, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 35
  store i64 0, ptr %t107, !tbaa !24
  %t109 = getelementptr %"compiler/emit:fnEm", ptr %l58, i32 0, i32 36
  store i64 -1, ptr %t109, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l58, i64 960, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"/* " }>, align 8
@.d1 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c".h - the C interface of lib" }>, align 8
@.d2 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c".so, written by \22olang build -library " }>, align 8
@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\22. */\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"#ifndef " }>, align 8
@.d5 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"_H\0A#define " }>, align 8
@.d6 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"_H\0A\0A#include <stdbool.h>\0A#include <stdint.h>\0A\0A" }>, align 8
@.d7 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"#ifdef __cplusplus\0Aextern \22C\22 {\0A#endif\0A\0A" }>, align 8
@.d8 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typedef struct " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c";\0A" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"/* what an entry declaring errors returns: 0, or one of these */\0A" }>, align 8
@.d13 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"#define " }>, align 8
@.d14 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"_ERROR ((int32_t)" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"#define " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" ((int32_t)" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d21 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"\0A#ifdef __cplusplus\0A}\0A#endif\0A\0A#endif\0A" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
declare void @__olang_ert_req_clear()
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".ctor" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d28 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_lambda_" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d31 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_case_" }>, align 8
@.d32 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_cond_" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d33 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".contract." }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 1}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d35 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.slot." }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d37 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang.traitslot." }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr, ptr" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr byval(" }>, align 8
@.d46 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d49 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"!DIFile(filename: \22" }>, align 8
@.d50 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"\22, directory: \22" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22)" }>, align 8
@.d52 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"!DIFile(filename: \22<generated>\22, directory: \22\22)" }>, align 8
@.d53 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"DW_ATE_boolean" }>, align 8
@.d54 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"DW_ATE_float" }>, align 8
@.d55 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"DW_ATE_unsigned" }>, align 8
@.d56 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"DW_ATE_signed" }>, align 8
@.d57 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"DW_ATE_unsigned_char" }>, align 8
@.d58 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"!DIBasicType(name: \22" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d60 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", encoding: " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d63 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d65 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d68 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: " }>, align 8
@.d69 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", size: 64)" }>, align 8
@.d70 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d74 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d75 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d77 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d78 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d79 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d81 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d82 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d83 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d84 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", offset: " }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d90 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d91 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d92 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d94 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!DIEnumerator(name: \22" }>, align 8
@.d95 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22, value: " }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d99 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d102 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d103 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"!DICompositeType(tag: DW_TAG_enumeration_type, name: \22" }>, align 8
@.d104 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d105 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", baseType: !" }>, align 8
@.d106 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d108 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d109 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d110 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d111 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d112 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d113 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d115 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22case\22, baseType: !" }>, align 8
@.d116 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", size: 64, offset: 0)" }>, align 8
@.d117 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22payload\22, baseType: !" }>, align 8
@.d118 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d119 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", offset: 64)" }>, align 8
@.d120 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"!{!" }>, align 8
@.d121 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d123 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d124 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d125 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d130 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d133 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = external global " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d135 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external global i8" }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d138 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = constant " }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}>" }>, align 8
@.d140 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d141 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external global i8" }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d143 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external constant " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2feval_3aBlob(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/eval:Blob"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 272, i1 false)
  %t2 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 0
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 4
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 6
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 7
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 8
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 9
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d145 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = available_externally constant " }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d148 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = global " }>, align 8
@.d149 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" zeroinitializer\0A" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d151 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = external global " }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d154 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"declare" }>, align 8
@.d155 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d156 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d159 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d160 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %env" }>, align 8
@.d161 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d162 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %out" }>, align 8
@.d163 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d164 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %v" }>, align 8
@.d165 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d166 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %a" }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %a" }>, align 8
@.d168 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"c, ptr %a" }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d170 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %a" }>, align 8
@.d171 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"declare" }>, align 8
@.d172 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d175 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" #0 {\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d177 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d181 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"64" }>, align 8
@.d182 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"llvm." }>, align 8
@.d183 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".f" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d184 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2femit_3aReused(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/emit:Reused"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 6
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/emit:Reused", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

@.d185 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang." }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 5}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
ret:
  ret void
}

@.d186 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d187 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d188 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"_copied" }>, align 8
@.d189 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.init." }>, align 8
@.d190 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".top" }>, align 8
@.d191 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d192 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang.anyrender" }>, align 8
@.d193 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d194 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d195 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d198 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d199 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_test_" }>, align 8
@.d200 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_test_" }>, align 8
@.d201 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d202 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d203 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d204 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d205 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not emitted" }>, align 8
@.d206 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not emitted" }>, align 8
@.d207 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"define internal ptr @" }>, align 8
@.d208 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c".coro(ptr %env, ptr %home) presplitcoroutine alwaysinline #0 {\0A" }>, align 8
@.d209 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" !dbg !" }>, align 8
@.d210 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" {\0A" }>, align 8
@.d211 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"entry:\0A" }>, align 8
@.d212 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  br label %start\0A" }>, align 8
@.d213 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d214 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d215 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d216 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d217 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d218 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d219 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d220 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d221 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d222 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d225 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_scope_alloc_a" }>, align 8
@.d226 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr " }>, align 8
@.d227 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d228 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d229 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d230 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d231 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d232 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d234 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d235 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c\22" }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d237 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d238 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d239 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d240 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d241 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d242 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a C callback that is no export fn named at the call" }>, align 8
@.d243 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l8 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 4}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 4}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb16
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb16
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t11, i32 0, i32 0
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t15 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t14, i32 0, i32 0
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aLvalue(ptr %t12, ptr %t15)
  store i1 %t18, ptr %l8
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t21 = getelementptr { i32, i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t29 = icmp eq i32 %t22, %t26
  br i1 %t29, label %bb9, label %bb1
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t37 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t41 = icmp eq i32 %t34, %t38
  br i1 %t41, label %bb11, label %bb1
bb7:
  %t43 = load i1, ptr %l8, !tbaa !21
  br i1 %t43, label %bb8, label %bb1
bb8:
  br label %bb3
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t46 = getelementptr { i32, i64 }, ptr %t45, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i32, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t54 = icmp eq i64 %t47, %t51
  br i1 %t54, label %bb10, label %bb1
bb10:
  br label %bb3
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  %t66 = icmp eq i32 %t59, %t63
  br i1 %t66, label %bb12, label %bb1
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t69, i32 0, i32 2
  %t71 = load i64, ptr %t70
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74
  %t78 = icmp eq i64 %t71, %t75
  br i1 %t78, label %bb13, label %bb1
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t81, i32 0, i32 3
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 3
  %t88 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t82, ptr %t85)
  store i1 %t88, ptr %l26
  br label %bb14
bb14:
  %t89 = load i1, ptr %l26, !tbaa !21
  br i1 %t89, label %bb15, label %bb1
bb15:
  br label %bb3
bb16:
  %t90 = load i1, ptr %l2, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d244 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d245 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d246 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d247 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fill" }>, align 8
@.d248 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d249 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d250 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = phi i64 [ 0, %" }>, align 8
@.d251 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ], [ " }>, align 8
@.d252 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d253 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d254 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d255 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d256 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d257 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d258 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d259 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d260 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d261 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = add i64 " }>, align 8
@.d262 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d263 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d264 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d265 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d266 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d267 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d268 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d269 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d270 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d271 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d272 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d273 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d274 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d275 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d276 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d277 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d278 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d279 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the object of a " }>, align 8
@.d280 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d281 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"store " }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d283 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d284 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_bang_failed" }>, align 8
@.d285 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bang_failed_plain" }>, align 8
@.d286 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d287 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d288 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d289 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %bq" }>, align 8
@.d290 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d291 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d292 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"\0A  br i1 %bq" }>, align 8
@.d293 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %bang" }>, align 8
@.d294 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", label %bnext" }>, align 8
@.d295 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Abang" }>, align 8
@.d296 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d297 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d298 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d299 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d300 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d301 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c")\0A  unreachable\0Abnext" }>, align 8
@.d302 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d303 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c": unhandled error\0A" }>, align 8
@.d304 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d305 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d306 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c")\0A  unreachable\0A" }>, align 8
@.d307 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang_task" }>, align 8
@.d308 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"define internal ptr @" }>, align 8
@.d309 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"(ptr %env) #0 {\0Aentry:\0A" }>, align 8
@.d310 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %f" }>, align 8
@.d311 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = getelementptr " }>, align 8
@.d312 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", ptr %env, i32 0, i32 " }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d314 = private constant <{ i64, [121 x i8] }> <{ i64 0, [121 x i8] c"  %fv = load { ptr, ptr }, ptr %f0\0A  %code = extractvalue { ptr, ptr } %fv, 0\0A  %fenv = extractvalue { ptr, ptr } %fv, 1\0A" }>, align 8
@.d315 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"%code" }>, align 8
@.d316 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr %fenv" }>, align 8
@.d317 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  %out = alloca " }>, align 8
@.d318 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d319 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d320 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %out" }>, align 8
@.d321 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %sc" }>, align 8
@.d322 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d323 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0A  %sn" }>, align 8
@.d324 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" = icmp eq ptr %sc" }>, align 8
@.d325 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", null\0A" }>, align 8
@.d326 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d327 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d328 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %sg" }>, align 8
@.d329 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" = load ptr, ptr @__olang_prog_scope\0A  %ss" }>, align 8
@.d330 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = select i1 %sn" }>, align 8
@.d331 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %sg" }>, align 8
@.d332 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %sc" }>, align 8
@.d333 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d334 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d335 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"ptr %ss" }>, align 8
@.d336 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d337 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %f" }>, align 8
@.d338 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %a" }>, align 8
@.d339 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" = load { ptr, ptr }, ptr %f" }>, align 8
@.d340 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0A  %ac" }>, align 8
@.d341 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" = extractvalue { ptr, ptr } %a" }>, align 8
@.d342 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 0\0A" }>, align 8
@.d343 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %ae" }>, align 8
@.d344 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" = extractvalue { ptr, ptr } %a" }>, align 8
@.d345 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d346 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"ptr %ac" }>, align 8
@.d347 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ae" }>, align 8
@.d348 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %a" }>, align 8
@.d349 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d350 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %f" }>, align 8
@.d351 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d352 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %a" }>, align 8
@.d353 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d354 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  call void " }>, align 8
@.d355 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d356 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d357 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  %r = call " }>, align 8
@.d358 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d359 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d360 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d361 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d362 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%out" }>, align 8
@.d363 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"  %v = extractvalue " }>, align 8
@.d364 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" %r, 1\0A" }>, align 8
@.d365 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%r" }>, align 8
@.d366 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%v" }>, align 8
@.d367 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%r" }>, align 8
@.d368 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%c" }>, align 8
@.d369 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%c" }>, align 8
@.d370 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"  %c = extractvalue " }>, align 8
@.d371 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" %r, 0\0A" }>, align 8
@.d372 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"  %bad = icmp ne i32 " }>, align 8
@.d373 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c", 0\0A  br i1 %bad, label %fail, label %ok\0Afail:\0A" }>, align 8
@.d374 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ok:\0A" }>, align 8
@.d375 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"  %rc64 = zext i32 " }>, align 8
@.d376 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c" to i64\0A  %rp = inttoptr i64 %rc64 to ptr\0A  ret ptr %rp\0Aok:\0A" }>, align 8
@.d377 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d378 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d379 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d380 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"  %d0 = load ptr, ptr %f" }>, align 8
@.d381 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"\0A  call void @llvm.memmove.p0.p0.i64(ptr %d0, ptr %out, i64 " }>, align 8
@.d382 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", i1 false)\0A" }>, align 8
@.d383 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %d" }>, align 8
@.d384 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d385 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d386 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %o" }>, align 8
@.d387 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = getelementptr " }>, align 8
@.d388 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", ptr %out, i32 0, i32 " }>, align 8
@.d389 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d390 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr %d" }>, align 8
@.d391 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %o" }>, align 8
@.d392 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d393 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", i1 false)\0A" }>, align 8
@.d394 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"  %d0 = load ptr, ptr %f" }>, align 8
@.d395 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A  store " }>, align 8
@.d396 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d397 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %d0\0A" }>, align 8
@.d398 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %d" }>, align 8
@.d399 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d400 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d401 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %x" }>, align 8
@.d402 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = extractvalue " }>, align 8
@.d403 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d404 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d405 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d406 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  store " }>, align 8
@.d407 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %x" }>, align 8
@.d408 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", ptr %d" }>, align 8
@.d409 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d410 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d411 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  ret ptr null\0A}\0A\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d412 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_put" }>, align 8
@.d413 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_put(ptr " }>, align 8
@.d414 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d415 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d416 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d417 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_room" }>, align 8
@.d418 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_add" }>, align 8
@.d419 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_sb_room(ptr " }>, align 8
@.d420 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 1)" }>, align 8
@.d421 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d422 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_add(ptr " }>, align 8
@.d423 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 1)" }>, align 8
@.d424 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d425 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d426 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d427 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_room" }>, align 8
@.d428 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_add" }>, align 8
@.d429 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i128" }>, align 8
@.d430 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d431 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"__olang_fmt_u" }>, align 8
@.d432 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"__olang_fmt_i" }>, align 8
@.d433 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i128" }>, align 8
@.d434 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"48" }>, align 8
@.d435 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"24" }>, align 8
@.d436 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_sb_room(ptr " }>, align 8
@.d437 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d438 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d439 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call i64 @" }>, align 8
@.d440 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d441 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d442 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d443 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d444 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_add(ptr " }>, align 8
@.d445 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d446 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d447 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_room" }>, align 8
@.d448 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_add" }>, align 8
@.d449 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_fmt_float" }>, align 8
@.d450 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fpext " }>, align 8
@.d451 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d452 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to double" }>, align 8
@.d453 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_sb_room(ptr " }>, align 8
@.d454 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", i64 48)" }>, align 8
@.d455 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call i64 @__olang_fmt_float(ptr " }>, align 8
@.d456 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c", i64 48, double " }>, align 8
@.d457 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d458 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d459 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_add(ptr " }>, align 8
@.d460 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d461 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d462 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_put" }>, align 8
@.d463 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d464 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d465 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d466 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d467 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d468 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i64 4, i64 5" }>, align 8
@.d469 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_put(ptr " }>, align 8
@.d470 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d471 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d472 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d473 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d474 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"testdata/fuzz/" }>, align 8
@.d475 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"/testdata/fuzz/" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d476 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sqrt" }>, align 8
@.d477 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"floor" }>, align 8
@.d478 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ceil" }>, align 8
@.d479 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"trunc" }>, align 8
@.d480 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"round" }>, align 8
@.d481 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"roundeven" }>, align 8
@.d482 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fabs" }>, align 8
@.d483 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"copysign" }>, align 8
@.d484 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fma" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d485 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d486 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d487 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d488 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ContractKind.Req" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d489 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HelperKind.Render" }>, align 8
@.d490 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"HelperKind.Equal" }>, align 8
@.d491 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Hash" }>, align 8
@.d492 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Zero" }>, align 8
@.d493 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Copy" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aLvalue(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Lvalue", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Lvalue", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Lvalue", ptr %t9, i32 0, i32 1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Lvalue", ptr %t11, i32 0, i32 1
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %t10, ptr %t12)
  store i1 %t15, ptr %l8
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb1
bb5:
  br label %bb6
bb6:
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 3}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 3}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb6, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb7, label %bb1
bb6:
  br label %bb3
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32, i32 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb8, label %bb1
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  %t56 = icmp eq i32 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/mir:Range", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Range", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4a7c1511235e6a9_9511e73f4ca5cc95 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecEntryDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, ptr %a3)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecWordName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_de1fe604fb5e87cf_ff4728625cff78d3 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2854570d7fadf599_61afc1034d008305 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_649f734ddce51468_b7eb8be07e4dd31c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H95f86c29c688efeac83a664cabcff622(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_67352ecb15e68ba0_c3979b973b302ad4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_32ecc2f0b2e54909_486ad1b7ea10ca75 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2einlining(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_616c6f643d0ce9fd_dfe523617d4699c1 = external constant [0 x i8]
@olang_loc_b37ed008d0080fcc_cc9019489ebc5a30 = external constant [0 x i8]
@olang_loc_e68028fa4f0f457e_ac0c180900ac4e62 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathExact = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H113622d1f8bf95ca2a74cd371898add0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hc46d619d13eb72fb3404dc4d54e1aab7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_325a0aca37049b03_8faf0435ed6a0227 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_d645e5ac48fafc6b_b6d88d5997c962c7 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_708cde11eb66cdaa_cb4b3307e5e96e66 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4e101a65701de364_bb0ca6f6f49ef738 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_8de51998cc7658b0_11d2469cc10d3f54 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, { i64, ptr } %a5, i1 %a6)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2efoldSlots(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7181fb99348382a8_4bd06d378e143a0c = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2femit_2ehexDigits = external constant <{ [8 x i8], ptr }>
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_617f1f302e56ab61_28fb076f83c3eed5 = external constant [0 x i8]
@olang_loc_ad86a063ee4785b3_cfd7ee8512ee9757 = external constant [0 x i8]
@olang_loc_dde810cb192bdc32_ece13dbcfe1403b6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c0167577194c5569_3f3b475069b70a4d = external constant [0 x i8]
@olang_loc_4abf2632c4ff5e98_8ea9033cf4a0221c = external constant [0 x i8]
@olang_loc_d4e74db3ab2eecf_2f1d311192c757bb = external constant [0 x i8]
@olang_loc_dc3064ee227cbe8e_efaeea0978edcb3a = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_9357034ceffa49e9_ad514f9345461395 = external constant [0 x i8]
@olang_loc_1dffb4089bad5318_6447f84abd9ba4a4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_81868432e93876af_31517217ac874813 = external constant [0 x i8]
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, %"compiler/mir:Range" %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_1c84b7c0e51a2751_bb90751f2238f075 = external constant [0 x i8]
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_625291c18633ca8a_b2d4e63a7cb7312e = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskOld(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3)
@olang_loc_7b5945deb51ea5cf_9b8856c6d1bef1b3 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3, i32 %a4, i64 %a5, i64 %a6, { i64, ptr } %a7)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i32 %a4)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_6e037ff8088c42f2_1018a41289232aae = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_1085358c18365730_69fd93bfc7477ec4 = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_eebd0c438d14e76b_644c9cf9ab14a5ff = external constant [0 x i8]
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, ptr %a4)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_890404a92f80b8aa_6c292d1ce7c26ffe = external constant [0 x i8]
@olang_loc_6060a7068f6090fd_51500cf142c637d9 = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eextend(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4)
@olang_loc_843b4d3d5fe86d0c_7c8978725a4736a0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_e171e8330ea33f7a_82d9a571b3024c8e = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_b05c5d37656b7ecf_b2cabd35ece02ebb = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8432ee6ea571e3a6_71b81f3ed515f9b2 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
