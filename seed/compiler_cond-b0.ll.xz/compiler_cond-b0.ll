; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/diagmsg:Msg", i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cond:Scope" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
define dso_local %"compiler/cond:Value" @compiler_2fcond_2eValue_2edeclaredKind(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l8 = alloca %"compiler/cond:Value"
  %l10 = alloca i1
  %l12 = alloca %"compiler/cond:Value"
  %l14 = alloca i1
  %l16 = alloca %"compiler/cond:Value"
  %l18 = alloca i1
  %l20 = alloca %"compiler/cond:Value"
  %l22 = alloca i1
  %l24 = alloca %"compiler/cond:Value"
  %l26 = alloca i1
  %l28 = alloca %"compiler/cond:Value"
  %l30 = alloca i1
  %l32 = alloca %"compiler/cond:Value"
  %l34 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l39 = alloca %"compiler/cond:Value"
  %l41 = alloca i1
  %l43 = alloca %"compiler/cond:Value"
  %l45 = alloca i1
  %l47 = alloca %"compiler/cond:Value"
  %l49 = alloca i1
  %l51 = alloca %"compiler/cond:Value"
  %l53 = alloca i1
  %l55 = alloca %"compiler/cond:Value"
  %l57 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t6 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 8, i1 false)
  store %"compiler/cond:Value" %t6, ptr %l4
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t7, ptr %rv
  br label %ret
bb5:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t10, ptr %l6
  br label %bb6
bb6:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb7, label %bb8
bb7:
  %t13 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 16, i1 false)
  store %"compiler/cond:Value" %t13, ptr %l8
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/cond:Value", ptr %l8
  store %"compiler/cond:Value" %t14, ptr %rv
  br label %ret
bb10:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t17, ptr %l10
  br label %bb11
bb11:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb12, label %bb13
bb12:
  %t20 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 32, i1 false)
  store %"compiler/cond:Value" %t20, ptr %l12
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/cond:Value", ptr %l12
  store %"compiler/cond:Value" %t21, ptr %rv
  br label %ret
bb15:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t24, ptr %l14
  br label %bb16
bb16:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb17, label %bb18
bb17:
  %t27 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 64, i1 false)
  store %"compiler/cond:Value" %t27, ptr %l16
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/cond:Value", ptr %l16
  store %"compiler/cond:Value" %t28, ptr %rv
  br label %ret
bb20:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb21
bb21:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb22, label %bb23
bb22:
  %t34 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 8, i1 true)
  store %"compiler/cond:Value" %t34, ptr %l20
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/cond:Value", ptr %l20
  store %"compiler/cond:Value" %t35, ptr %rv
  br label %ret
bb25:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t38, ptr %l22
  br label %bb26
bb26:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb27, label %bb28
bb27:
  %t41 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 16, i1 true)
  store %"compiler/cond:Value" %t41, ptr %l24
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t42, ptr %rv
  br label %ret
bb30:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t45, ptr %l26
  br label %bb31
bb31:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb32, label %bb33
bb32:
  %t48 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 32, i1 true)
  store %"compiler/cond:Value" %t48, ptr %l28
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load %"compiler/cond:Value", ptr %l28
  store %"compiler/cond:Value" %t49, ptr %rv
  br label %ret
bb35:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t52, ptr %l30
  br label %bb36
bb36:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb37, label %bb38
bb37:
  %t55 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 64, i1 true)
  store %"compiler/cond:Value" %t55, ptr %l32
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t56 = load %"compiler/cond:Value", ptr %l32
  store %"compiler/cond:Value" %t56, ptr %rv
  br label %ret
bb40:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t59, ptr %l34
  br label %bb41
bb41:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb45
bb43:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t63, ptr %l37
  br label %bb44
bb44:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %l35, !tbaa !21
  br label %bb45
bb45:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb46, label %bb47
bb46:
  %t67 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 3, i64 16, i1 false)
  store %"compiler/cond:Value" %t67, ptr %l39
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load %"compiler/cond:Value", ptr %l39
  store %"compiler/cond:Value" %t68, ptr %rv
  br label %ret
bb49:
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t71, ptr %l41
  br label %bb50
bb50:
  %t72 = load i1, ptr %l41, !tbaa !21
  br i1 %t72, label %bb51, label %bb52
bb51:
  %t74 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 3, i64 32, i1 false)
  store %"compiler/cond:Value" %t74, ptr %l43
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load %"compiler/cond:Value", ptr %l43
  store %"compiler/cond:Value" %t75, ptr %rv
  br label %ret
bb54:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t78, ptr %l45
  br label %bb55
bb55:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb56, label %bb57
bb56:
  %t81 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 3, i64 64, i1 false)
  store %"compiler/cond:Value" %t81, ptr %l47
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load %"compiler/cond:Value", ptr %l47
  store %"compiler/cond:Value" %t82, ptr %rv
  br label %ret
bb59:
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t83, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t85, ptr %l49
  br label %bb60
bb60:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb61, label %bb62
bb61:
  %t88 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 1, i64 0, i1 false)
  store %"compiler/cond:Value" %t88, ptr %l51
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load %"compiler/cond:Value", ptr %l51
  store %"compiler/cond:Value" %t89, ptr %rv
  br label %ret
bb64:
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t90, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t92, ptr %l53
  br label %bb65
bb65:
  %t93 = load i1, ptr %l53, !tbaa !21
  br i1 %t93, label %bb66, label %bb67
bb66:
  %t95 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 4, i64 0, i1 false)
  store %"compiler/cond:Value" %t95, ptr %l55
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load %"compiler/cond:Value", ptr %l55
  store %"compiler/cond:Value" %t96, ptr %rv
  br label %ret
bb69:
  %t98 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t98, ptr %l57
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/cond:Value", ptr %l57
  store %"compiler/cond:Value" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i32 @compiler_2fcond_2ebadDefine(ptr %v0, ptr %v1, ptr %a0, %"compiler/diagmsg:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/diagmsg:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca i32
  %l3 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  store i32 %t2, ptr %l1
  %t4 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t6 = trunc i64 1 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t11 = trunc i64 4 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb25
bb6:
  %t14 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t16 = trunc i64 3 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t19 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 64
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb25
bb10:
  %t24 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t26 = trunc i64 2 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t29 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb14, label %bb15
bb14:
  %t32 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = icmp eq i64 %t33, 64
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb19
bb15:
  %t37 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = icmp eq i64 %t38, 32
  br i1 %t40, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb18
bb17:
  %t42 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 64
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l20, !tbaa !21
  store i1 %t47, ptr %l15, !tbaa !21
  br label %bb19
bb19:
  %t48 = load i1, ptr %l15, !tbaa !21
  store i1 %t48, ptr %l3, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a57e25c843e3c84f_6f669dc60e0f5ddb)
  unreachable
bb25:
  %t49 = load i1, ptr %l3, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i32
  %l76 = alloca ptr
  %l78 = alloca %"compiler/diagmsg:Msg"
  %l79 = alloca i32
  %l81 = alloca ptr
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i32
  %l87 = alloca ptr
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i32
  %l93 = alloca ptr
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l97 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca %"compiler/diagmsg:Msg"
  %l103 = alloca i32
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t1, i8 61)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l10
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2f3f750ce3a7cf22_a8bd497d0b471fc6)
  unreachable
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2f3f750ce3a7cf22_a8bd497d0b471fc6)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2f3f750ce3a7cf22_a8bd497d0b471fc6)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l27, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l30, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l41, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l27, !tbaa !24
  %t71 = load i64, ptr %l30, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb15:
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l27, !tbaa !24
  %t81 = load i64, ptr %l30, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l24, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb19:
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = load i64, ptr %l41, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb21:
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = load i64, ptr %l42, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l38, !tbaa !24
  %t98 = load i64, ptr %l41, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l24, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4bc53af292f25c9f_867e818f05a97a3)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t104, ptr %l5, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2edefine(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t106)
  store i32 %t109, ptr %l49
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb27, label %ok.111, !prof !99
ok.111:
  br label %bb26
bb26:
  br label %bb84
bb27:
  %t112 = load i32, ptr %l49, !tbaa !23
  %t113 = icmp eq i32 %t112, 65536
  br i1 %t113, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  %t115 = load i32, ptr %l49, !tbaa !23
  %t116 = icmp eq i32 %t115, 65537
  br i1 %t116, label %bb31, label %bb32
bb30:
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l59, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t121 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v1, ptr %v2, { i64, ptr } %t119)
  store %"compiler/diagmsg:Msg" %t121, ptr %l61
  br label %bb52
bb31:
  br label %bb33
bb32:
  %t122 = load i32, ptr %l49, !tbaa !23
  %t123 = icmp eq i32 %t122, 65538
  br i1 %t123, label %bb34, label %bb35
bb33:
  %t125 = load ptr, ptr %l2, !tbaa !29
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t130 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t126, { i64, ptr } %t127)
  store %"compiler/diagmsg:Msg" %t130, ptr %l67
  br label %bb56
bb34:
  br label %bb36
bb35:
  %t131 = load i32, ptr %l49, !tbaa !23
  %t132 = icmp eq i32 %t131, 65539
  br i1 %t132, label %bb37, label %bb38
bb36:
  %t134 = load ptr, ptr %l2, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t139 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t135, { i64, ptr } %t136)
  store %"compiler/diagmsg:Msg" %t139, ptr %l73
  br label %bb60
bb37:
  br label %bb39
bb38:
  %t140 = load i32, ptr %l49, !tbaa !23
  %t141 = icmp eq i32 %t140, 65540
  br i1 %t141, label %bb40, label %bb41
bb39:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l76, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t146 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v1, ptr %v2, { i64, ptr } %t144)
  store %"compiler/diagmsg:Msg" %t146, ptr %l78
  br label %bb64
bb40:
  br label %bb42
bb41:
  %t147 = load i32, ptr %l49, !tbaa !23
  %t148 = icmp eq i32 %t147, 65541
  br i1 %t148, label %bb43, label %bb44
bb42:
  %t150 = load ptr, ptr %l2, !tbaa !29
  store ptr %t150, ptr %l81, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t151, { i64, ptr } %t152)
  store %"compiler/diagmsg:Msg" %t155, ptr %l84
  br label %bb68
bb43:
  br label %bb45
bb44:
  %t156 = load i32, ptr %l49, !tbaa !23
  %t157 = icmp eq i32 %t156, 65542
  br i1 %t157, label %bb46, label %bb47
bb45:
  %t159 = load ptr, ptr %l2, !tbaa !29
  store ptr %t159, ptr %l87, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t160, { i64, ptr } %t161)
  store %"compiler/diagmsg:Msg" %t164, ptr %l90
  br label %bb72
bb46:
  br label %bb48
bb47:
  %t165 = load i32, ptr %l49, !tbaa !23
  %t166 = icmp eq i32 %t165, 65543
  br i1 %t166, label %bb49, label %bb50
bb48:
  %t168 = load ptr, ptr %l2, !tbaa !29
  store ptr %t168, ptr %l93, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t169, { i64, ptr } %t170)
  store %"compiler/diagmsg:Msg" %t173, ptr %l96
  br label %bb76
bb49:
  br label %bb51
bb50:
  %t174 = load i32, ptr %l49, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 0, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  store i32 %t182, ptr %rv
  br label %ret
bb51:
  %t184 = load ptr, ptr %l2, !tbaa !29
  store ptr %t184, ptr %l99, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t185, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t189, ptr %l102
  br label %bb80
bb52:
  %t190 = load ptr, ptr %l59, !tbaa !29
  %t191 = load %"compiler/diagmsg:Msg", ptr %l61
  %t192 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t190, %"compiler/diagmsg:Msg" %t191)
  store i32 %t192, ptr %l62
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb54, label %ok.194, !prof !99
ok.194:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t195 = load i32, ptr %l62, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  store i32 %t203, ptr %rv
  br label %ret
bb55:
  br label %bb84
bb56:
  %t205 = load ptr, ptr %l64, !tbaa !29
  %t206 = load %"compiler/diagmsg:Msg", ptr %l67
  %t207 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t205, %"compiler/diagmsg:Msg" %t206)
  store i32 %t207, ptr %l68
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb58, label %ok.209, !prof !99
ok.209:
  br label %bb57
bb57:
  br label %bb59
bb58:
  %t210 = load i32, ptr %l68, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  store i32 %t218, ptr %rv
  br label %ret
bb59:
  br label %bb84
bb60:
  %t220 = load ptr, ptr %l70, !tbaa !29
  %t221 = load %"compiler/diagmsg:Msg", ptr %l73
  %t222 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t220, %"compiler/diagmsg:Msg" %t221)
  store i32 %t222, ptr %l74
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb62, label %ok.224, !prof !99
ok.224:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t225 = load i32, ptr %l74, !tbaa !23
  %t226 = lshr i32 %t225, 16
  %t227 = and i32 %t225, 65535
  %t228 = icmp eq i32 %t226, 1
  %t229 = select i1 %t228, i32 1, i32 0
  %t230 = icmp eq i32 %t225, 0
  %t231 = shl i32 %t229, 16
  %t232 = or i32 %t231, %t227
  %t233 = select i1 %t230, i32 0, i32 %t232
  store i32 %t233, ptr %rv
  br label %ret
bb63:
  br label %bb84
bb64:
  %t235 = load ptr, ptr %l76, !tbaa !29
  %t236 = load %"compiler/diagmsg:Msg", ptr %l78
  %t237 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t235, %"compiler/diagmsg:Msg" %t236)
  store i32 %t237, ptr %l79
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb66, label %ok.239, !prof !99
ok.239:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t240 = load i32, ptr %l79, !tbaa !23
  %t241 = lshr i32 %t240, 16
  %t242 = and i32 %t240, 65535
  %t243 = icmp eq i32 %t241, 1
  %t244 = select i1 %t243, i32 1, i32 0
  %t245 = icmp eq i32 %t240, 0
  %t246 = shl i32 %t244, 16
  %t247 = or i32 %t246, %t242
  %t248 = select i1 %t245, i32 0, i32 %t247
  store i32 %t248, ptr %rv
  br label %ret
bb67:
  br label %bb84
bb68:
  %t250 = load ptr, ptr %l81, !tbaa !29
  %t251 = load %"compiler/diagmsg:Msg", ptr %l84
  %t252 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t250, %"compiler/diagmsg:Msg" %t251)
  store i32 %t252, ptr %l85
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb70, label %ok.254, !prof !99
ok.254:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t255 = load i32, ptr %l85, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  store i32 %t263, ptr %rv
  br label %ret
bb71:
  br label %bb84
bb72:
  %t265 = load ptr, ptr %l87, !tbaa !29
  %t266 = load %"compiler/diagmsg:Msg", ptr %l90
  %t267 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t265, %"compiler/diagmsg:Msg" %t266)
  store i32 %t267, ptr %l91
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb74, label %ok.269, !prof !99
ok.269:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t270 = load i32, ptr %l91, !tbaa !23
  %t271 = lshr i32 %t270, 16
  %t272 = and i32 %t270, 65535
  %t273 = icmp eq i32 %t271, 1
  %t274 = select i1 %t273, i32 1, i32 0
  %t275 = icmp eq i32 %t270, 0
  %t276 = shl i32 %t274, 16
  %t277 = or i32 %t276, %t272
  %t278 = select i1 %t275, i32 0, i32 %t277
  store i32 %t278, ptr %rv
  br label %ret
bb75:
  br label %bb84
bb76:
  %t280 = load ptr, ptr %l93, !tbaa !29
  %t281 = load %"compiler/diagmsg:Msg", ptr %l96
  %t282 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t280, %"compiler/diagmsg:Msg" %t281)
  store i32 %t282, ptr %l97
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb78, label %ok.284, !prof !99
ok.284:
  br label %bb77
bb77:
  br label %bb79
bb78:
  %t285 = load i32, ptr %l97, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  store i32 %t293, ptr %rv
  br label %ret
bb79:
  br label %bb84
bb80:
  %t295 = load ptr, ptr %l99, !tbaa !29
  %t296 = load %"compiler/diagmsg:Msg", ptr %l102
  %t297 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %v2, ptr %t295, %"compiler/diagmsg:Msg" %t296)
  store i32 %t297, ptr %l103
  %t298 = icmp ne i32 %t297, 0
  br i1 %t298, label %bb82, label %ok.299, !prof !99
ok.299:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t300 = load i32, ptr %l103, !tbaa !23
  %t301 = lshr i32 %t300, 16
  %t302 = and i32 %t300, 65535
  %t303 = icmp eq i32 %t301, 1
  %t304 = select i1 %t303, i32 1, i32 0
  %t305 = icmp eq i32 %t300, 0
  %t306 = shl i32 %t304, 16
  %t307 = or i32 %t306, %t302
  %t308 = select i1 %t305, i32 0, i32 %t307
  store i32 %t308, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/cond:Value"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l41 = alloca %"compiler/cond:Value"
  %l44 = alloca i1
  %l45 = alloca i64
  %l48 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/cond:Value"
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l73 = alloca i1
  %l75 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/cond:Consts", ptr %t3, i32 0, i32 0
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/cond:Consts", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t57, i64 %t58)
  store %"compiler/cond:Value" %t61, ptr %l41
  br label %bb13
bb13:
  %t62 = load %"compiler/cond:Value", ptr %l41
  store %"compiler/cond:Value" %t62, ptr %l8
  %t63 = getelementptr %"compiler/cond:Value", ptr %l8, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 5}
  %t66 = trunc i64 4 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = getelementptr %"compiler/cond:Value", ptr %l8, i32 0, i32 3
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l45, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/cond:Consts", ptr %t71, i32 0, i32 6
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l48
  br label %bb16
bb15:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  %t76 = load i64, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l48, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  store i1 %t78, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l44, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/cond:Consts", ptr %t81, i32 0, i32 6
  %t84 = getelementptr %"compiler/cond:Value", ptr %l8, i32 0, i32 3
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t83, i64 %t85)
  store { i64, ptr } %t88, ptr %l54
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l50, !tbaa !27
  br label %bb21
bb20:
  %t89 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t89, ptr %l50, !tbaa !27
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t90, ptr %l9, !tbaa !27
  store ptr %l1, ptr %l55, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/cond:Consts", ptr %t91, i32 0, i32 0
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t93, i64 %t94)
  store { i64, ptr } %t97, ptr %l59
  br label %bb22
bb22:
  %t98 = load %"compiler/cond:Value", ptr %l8
  store %"compiler/cond:Value" %t98, ptr %l60
  %t99 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t99, ptr %l61, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/cond:Consts", ptr %t100, i32 0, i32 5
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l65
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/cond:Consts", ptr %t107, i32 0, i32 4
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t109, i64 %t110)
  store i1 %t113, ptr %l69
  br label %bb24
bb24:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/cond:Consts", ptr %t114, i32 0, i32 3
  %t117 = load i64, ptr %l7, !tbaa !24
  %t120 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t116, i64 %t117)
  store i1 %t120, ptr %l73
  br label %bb25
bb25:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t121 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  call void @__olang_sb_put(ptr %s3, ptr %t122, i64 %t123)
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t124, i64 %t125)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fcond_3aValue(ptr %s3, ptr %l60, i64 0)
  br label %bb26
bb26:
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t127, i64 %t128)
  %t129 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  call void @__olang_sb_put(ptr %s3, ptr %t130, i64 %t131)
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t132, i64 %t133)
  %t134 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  call void @__olang_sb_put(ptr %s3, ptr %t135, i64 %t136)
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t137, i64 %t138)
  %t139 = load i1, ptr %l69, !tbaa !21
  %t140 = select i1 %t139, ptr @.c17, ptr @.c18
  %t141 = select i1 %t139, i64 4, i64 5
  call void @__olang_sb_put(ptr %s3, ptr %t140, i64 %t141)
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t142, i64 %t143)
  %t144 = load i1, ptr %l73, !tbaa !21
  %t145 = select i1 %t144, ptr @.c17, ptr @.c18
  %t146 = select i1 %t144, i64 4, i64 5
  call void @__olang_sb_put(ptr %s3, ptr %t145, i64 %t146)
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t147, i64 %t148)
  %t149 = load ptr, ptr %s3
  %t150 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t151 = load i64, ptr %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t149, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l75, !tbaa !27
  %t155 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t156 = load ptr, ptr %t155
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %sbgrew.158, label %sbdone.159
sbgrew.158:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.159
sbdone.159:
  %t160 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t161 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t161, { i64, ptr } %t160)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t169 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t169, ptr %l81
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t170 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t170, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2edefine(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/cond:Value"
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l45 = alloca i1
  %l48 = alloca %"compiler/cond:Value"
  %l51 = alloca %"compiler/cond:Value"
  %l52 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t1, i8 61)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 65536, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l15, !tbaa !24
  %t16 = icmp sge i64 0, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = icmp sle i64 0, %t18
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4ddddffe7822a0c2_24314aefc1643326)
  unreachable
bb7:
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4ddddffe7822a0c2_24314aefc1643326)
  unreachable
bb9:
  %t25 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = getelementptr i8, ptr %t26, i64 0
  %t29 = sub i64 %t27, 0
  %t30 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l22, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t37, 0
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4ddddffe7822a0c2_24314aefc1643326)
  unreachable
bb11:
  %t46 = load i64, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e3c5df648a43e2bf_f2e642f3433cb83)
  unreachable
bb13:
  %t50 = load i64, ptr %l25, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = icmp sle i64 %t50, %t51
  br i1 %t52, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e3c5df648a43e2bf_f2e642f3433cb83)
  unreachable
bb15:
  %t54 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = getelementptr i8, ptr %t55, i64 %t56
  %t59 = sub i64 %t57, %t56
  %t60 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  store { i64, ptr } %t61, ptr %l4, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @compiler_2fcond_2eisName(ptr %v1, { i64, ptr } %t63)
  store i1 %t65, ptr %l32
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e3c5df648a43e2bf_f2e642f3433cb83)
  unreachable
bb17:
  %t66 = load i1, ptr %l32, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb18, label %bb19
bb18:
  store i32 65537, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t70, { i64, ptr } %t71)
  %t75 = extractvalue { i32, i64 } %t74, 1
  %t76 = extractvalue { i32, i64 } %t74, 0
  store i32 %t76, ptr %l39
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb22, label %ok.78, !prof !99
ok.78:
  store i64 %t75, ptr %l38
  br label %bb21
bb21:
  %t79 = load i64, ptr %l38, !tbaa !24
  store i64 %t79, ptr %l35, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb24
bb24:
  %t80 = load i64, ptr %l35, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = icmp sge i64 %t81, 0
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/cond:Consts", ptr %t85, i32 0, i32 2
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t91, ptr %l45
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t92 = load i1, ptr %l45, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  store i32 65539, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i32 65538, ptr %rv
  br label %ret
bb31:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t99 = call { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eliteral(ptr %v0, ptr %v1, ptr %t95, { i64, ptr } %t96)
  %t100 = extractvalue { i32, %"compiler/cond:Value" } %t99, 1
  %t101 = extractvalue { i32, %"compiler/cond:Value" } %t99, 0
  store i32 %t101, ptr %l52
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb33, label %ok.103, !prof !99
ok.103:
  store %"compiler/cond:Value" %t100, ptr %l51
  br label %bb32
bb32:
  %t104 = load %"compiler/cond:Value", ptr %l51
  store %"compiler/cond:Value" %t104, ptr %l48
  br label %bb34
bb33:
  %t105 = load i32, ptr %l52, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %rv
  br label %ret
bb34:
  %t115 = load %"compiler/cond:Value", ptr %l48
  store %"compiler/cond:Value" %t115, ptr %l6
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t118 = load %"compiler/cond:Value", ptr %l6
  %t119 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 6
  %t120 = load i1, ptr %t119, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v1, ptr %t116, { i64, ptr } %t117, %"compiler/cond:Value" %t118, i1 false, i1 %t120, i1 true)
  br label %bb35
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/cond:Consts", ptr %t125, i32 0, i32 5
  store ptr %t127, ptr %l59, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/cond:Consts", ptr %t128, i32 0, i32 5
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l62
  br label %bb36
bb36:
  %t133 = load i64, ptr %l62, !tbaa !24
  %t134 = sub i64 %t133, 1
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t136 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %t136, i64 %t134, { i64, ptr } %t135)
  br label %bb37
bb37:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eliteral(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"compiler/scan:Tokens"
  %l7 = alloca i32
  %l8 = alloca double
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca %"compiler/cond:Value"
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l45 = alloca %"compiler/cond:Value"
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l97 = alloca %"compiler/scan:Tokens"
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l117 = alloca i32
  %l118 = alloca { i64, ptr }
  %l124 = alloca i1
  %l130 = alloca i32
  %l133 = alloca i64
  %l134 = alloca %"compiler/cond:Value"
  %l137 = alloca double
  %l139 = alloca { i64, ptr }
  %l141 = alloca double
  %l142 = alloca i32
  %l149 = alloca i32
  %l151 = alloca double
  %l155 = alloca %"compiler/cond:Value"
  %l156 = alloca i64
  %l157 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca i32
  %l160 = alloca i64
  %l161 = alloca i32
  %l166 = alloca i32
  %l168 = alloca i64
  %l173 = alloca %"compiler/cond:Value"
  %l184 = alloca %"compiler/cond:Value"
  %l191 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/cond:Value" }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i1, ptr %l12, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t7, ptr %l15
  br label %bb4
bb4:
  %t8 = load i1, ptr %l15, !tbaa !21
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t12, ptr %l17
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t13 = load i1, ptr %l17, !tbaa !21
  %t14 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t13)
  store %"compiler/cond:Value" %t14, ptr %l18
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load %"compiler/cond:Value", ptr %l18
  %t16 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t15, 1
  store { i32, %"compiler/cond:Value" } %t16, ptr %rv
  br label %ret
bb10:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp sge i64 %t19, 2
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l23, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 0
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = icmp eq i8 %t27, 34
  store i1 %t29, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l27, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = sub i64 %t35, 1
  %t39 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp eq i8 %t42, 34
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 4, ptr %l33
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l34, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l35, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = sub i64 %t51, 1
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l39, !tbaa !24
  %t56 = icmp sge i64 1, 0
  br i1 %t56, label %bb19, label %bb20
bb18:
  br label %bb27
bb19:
  %t58 = load i64, ptr %l38, !tbaa !24
  %t59 = icmp sle i64 1, %t58
  br i1 %t59, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5ac00ef93c3b70de_d182aac4a1481962)
  unreachable
bb21:
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5ac00ef93c3b70de_d182aac4a1481962)
  unreachable
bb23:
  %t65 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = getelementptr i8, ptr %t66, i64 1
  %t69 = sub i64 %t67, 1
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t72 = load ptr, ptr %l34, !tbaa !29
  %t74 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t72, { i64, ptr } %t71)
  store i64 %t74, ptr %l44
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5ac00ef93c3b70de_d182aac4a1481962)
  unreachable
bb25:
  %t75 = load i32, ptr %l33, !range !{i32 0, i32 5}
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 %t75, i64 0, double 0x0000000000000000, i64 %t76, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t77, ptr %l45
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t78 = load %"compiler/cond:Value", ptr %l45
  %t79 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t78, 1
  store { i32, %"compiler/cond:Value" } %t79, ptr %rv
  br label %ret
bb27:
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l50, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 0
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = icmp eq i8 %t90, 45
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l49, !tbaa !21
  store i1 %t94, ptr %l2, !tbaa !21
  %t95 = load i1, ptr %l2, !tbaa !21
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t98, 0
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = icmp sge i64 1, 0
  br i1 %t104, label %bb33, label %bb34
bb32:
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %l64, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t107, 0
  store i64 %t110, ptr %l67, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l68, !tbaa !24
  %t113 = icmp sge i64 0, 0
  br i1 %t113, label %bb39, label %bb40
bb33:
  %t115 = load i64, ptr %l58, !tbaa !24
  %t116 = icmp sle i64 1, %t115
  br i1 %t116, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb35:
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = icmp sle i64 %t118, %t119
  br i1 %t120, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb37:
  %t122 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = getelementptr i8, ptr %t123, i64 1
  %t126 = sub i64 %t124, 1
  %t127 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  store { i64, ptr } %t128, ptr %l54, !tbaa !27
  br label %bb45
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb39:
  %t130 = load i64, ptr %l67, !tbaa !24
  %t131 = icmp sle i64 0, %t130
  br i1 %t131, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb41:
  %t133 = load i64, ptr %l67, !tbaa !24
  %t134 = load i64, ptr %l68, !tbaa !24
  %t135 = icmp sle i64 %t133, %t134
  br i1 %t135, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb43:
  %t137 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l67, !tbaa !24
  %t140 = getelementptr i8, ptr %t138, i64 0
  %t141 = sub i64 %t139, 0
  %t142 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  store { i64, ptr } %t143, ptr %l54, !tbaa !27
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_b6b1b2abf04569db_4e32416677f050df)
  unreachable
bb45:
  %t145 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t145, ptr %l3, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = icmp sge i64 %t148, 2
  br i1 %t150, label %bb46, label %bb47
bb46:
  %t152 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t152, ptr %l77, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 0
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = icmp eq i8 %t156, 48
  store i1 %t158, ptr %l76, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb48
bb48:
  %t160 = load i1, ptr %l76, !tbaa !21
  br i1 %t160, label %bb49, label %bb50
bb49:
  %t161 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t161, ptr %l81, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i8, ptr %t163, i64 1
  %t165 = load i8, ptr %t164, !tbaa !32
  %t167 = icmp eq i8 %t165, 120
  br i1 %t167, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb60
bb51:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb53
bb52:
  %t169 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t169, ptr %l85, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i8, ptr %t171, i64 1
  %t173 = load i8, ptr %t172, !tbaa !32
  %t175 = icmp eq i8 %t173, 88
  store i1 %t175, ptr %l84, !tbaa !21
  br label %bb53
bb53:
  %t177 = load i1, ptr %l84, !tbaa !21
  br i1 %t177, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb56
bb55:
  %t178 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t178, ptr %l89, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 1
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = icmp eq i8 %t182, 98
  store i1 %t184, ptr %l88, !tbaa !21
  br label %bb56
bb56:
  %t186 = load i1, ptr %l88, !tbaa !21
  br i1 %t186, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb59
bb58:
  %t187 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t187, ptr %l93, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i8, ptr %t189, i64 1
  %t191 = load i8, ptr %t190, !tbaa !32
  %t193 = icmp eq i8 %t191, 66
  store i1 %t193, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t195 = load i1, ptr %l92, !tbaa !21
  store i1 %t195, ptr %l80, !tbaa !21
  br label %bb60
bb60:
  %t196 = load i1, ptr %l80, !tbaa !21
  store i1 %t196, ptr %l4, !tbaa !21
  %t197 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t199 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v1, ptr %s0, { i64, ptr } %t197)
  store %"compiler/scan:Tokens" %t199, ptr %l97
  br label %bb61
bb61:
  %t200 = load %"compiler/scan:Tokens", ptr %l97
  store %"compiler/scan:Tokens" %t200, ptr %l5
  %t201 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp sge i64 %t204, 2
  br i1 %t206, label %bb62, label %bb63
bb62:
  %t208 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 3
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l101, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb64
bb64:
  %t215 = load i1, ptr %l101, !tbaa !21
  br i1 %t215, label %bb65, label %bb66
bb65:
  %t216 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l106, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr %"compiler/token:Token", ptr %t219, i64 0
  %t221 = getelementptr %"compiler/token:Token", ptr %t220, i32 0, i32 2
  %t222 = load i32, ptr %t221, !tbaa !23
  %t224 = icmp eq i32 %t222, 0
  store i1 %t224, ptr %l105, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb67
bb67:
  %t226 = load i1, ptr %l105, !tbaa !21
  br i1 %t226, label %bb68, label %bb69
bb68:
  %t227 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l110, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr %"compiler/token:Token", ptr %t230, i64 0
  %t232 = getelementptr %"compiler/token:Token", ptr %t231, i32 0, i32 3
  %t233 = load i32, ptr %t232, !tbaa !23
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t238 = trunc i64 %t236 to i32
  %t241 = icmp eq i32 %t233, %t238
  store i1 %t241, ptr %l109, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb70
bb70:
  %t243 = load i1, ptr %l109, !tbaa !21
  br i1 %t243, label %bb71, label %bb72
bb71:
  %t246 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l118, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr %"compiler/token:Token", ptr %t249, i64 0
  %t251 = getelementptr %"compiler/token:Token", ptr %t250, i32 0, i32 0
  %t252 = load i32, ptr %t251, !range !{i32 0, i32 116}
  store i32 %t252, ptr %l117
  br label %bb73
bb72:
  store i32 0, ptr %l117
  br label %bb73
bb73:
  %t255 = load i32, ptr %l117, !range !{i32 0, i32 116}
  store i32 %t255, ptr %l7
  %t256 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t258 = trunc i64 2 to i32
  %t259 = icmp eq i32 %t256, %t258
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb74, label %bb75
bb74:
  %t263 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t265 = trunc i64 3 to i32
  %t266 = icmp eq i32 %t263, %t265
  %t268 = xor i1 %t266, true
  store i1 %t268, ptr %l124, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb76
bb76:
  %t270 = load i1, ptr %l124, !tbaa !21
  br i1 %t270, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s3
  %t271 = load i1, ptr %l4, !tbaa !21
  br i1 %t271, label %bb79, label %bb80
bb78:
  br label %bb84
bb79:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t274 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65540, 0
  store { i32, %"compiler/cond:Value" } %t274, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  store i32 4, ptr %l130
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t279 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t275, { i64, ptr } %t276)
  store i64 %t279, ptr %l133
  br label %bb82
bb82:
  %t280 = load i32, ptr %l130, !range !{i32 0, i32 5}
  %t281 = load i64, ptr %l133, !tbaa !24
  %t282 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t280, i64 0, double 0x0000000000000000, i64 %t281, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t282, ptr %l134
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t283 = load %"compiler/cond:Value", ptr %l134
  %t284 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t283, 1
  store { i32, %"compiler/cond:Value" } %t284, ptr %rv
  br label %ret
bb84:
  %t285 = load i32, ptr %l7, !range !{i32 0, i32 116}
  %t287 = trunc i64 3 to i32
  %t288 = icmp eq i32 %t285, %t287
  br i1 %t288, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s5
  %t290 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t292 = call { i64, ptr } @compiler_2fcond_2estripped(ptr %v1, ptr %s5, { i64, ptr } %t290)
  store { i64, ptr } %t292, ptr %l139
  br label %bb87
bb86:
  br label %bb99
bb87:
  %t293 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t295 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s5, { i64, ptr } %t293)
  %t296 = extractvalue { i32, double } %t295, 1
  %t297 = extractvalue { i32, double } %t295, 0
  store i32 %t297, ptr %l142
  %t298 = icmp ne i32 %t297, 0
  br i1 %t298, label %bb89, label %ok.299, !prof !99
ok.299:
  store double %t296, ptr %l141
  br label %bb88
bb88:
  %t300 = load double, ptr %l141, !tbaa !26
  store double %t300, ptr %l137, !tbaa !26
  br label %bb91
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t302 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65543, 0
  store { i32, %"compiler/cond:Value" } %t302, ptr %rv
  br label %ret
bb91:
  %t303 = load double, ptr %l137, !tbaa !26
  store double %t303, ptr %l8, !tbaa !26
  %t304 = load double, ptr %l8, !tbaa !26
  %t305 = load double, ptr %l8, !tbaa !26
  %t308 = fsub double %t304, %t305
  %t310 = fcmp une double %t308, 0x0000000000000000
  br i1 %t310, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t313 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65543, 0
  store { i32, %"compiler/cond:Value" } %t313, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  store i32 3, ptr %l149
  %t314 = load i1, ptr %l2, !tbaa !21
  br i1 %t314, label %bb95, label %bb96
bb95:
  %t316 = load double, ptr %l8, !tbaa !26
  %t318 = fneg double %t316
  store double %t318, ptr %l151, !tbaa !26
  br label %bb97
bb96:
  %t320 = load double, ptr %l8, !tbaa !26
  store double %t320, ptr %l151, !tbaa !26
  br label %bb97
bb97:
  %t322 = load i32, ptr %l149, !range !{i32 0, i32 5}
  %t323 = load double, ptr %l151, !tbaa !26
  %t324 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s5, i32 %t322, i64 0, double %t323, i64 0, i64 64, i1 false, i1 false)
  store %"compiler/cond:Value" %t324, ptr %l155
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t325 = load %"compiler/cond:Value", ptr %l155
  %t326 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t325, 1
  store { i32, %"compiler/cond:Value" } %t326, ptr %rv
  br label %ret
bb99:
  %t327 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t327, ptr %l157, !tbaa !27
  %t328 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 0)
  %t329 = extractvalue { i32, i64 } %t328, 1
  %t330 = extractvalue { i32, i64 } %t328, 0
  store i32 %t330, ptr %l159
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb101, label %ok.332, !prof !99
ok.332:
  store i64 %t329, ptr %l158
  br label %bb100
bb100:
  %t333 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t334 = load i64, ptr %l158, !tbaa !24
  %t335 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v1, { i64, ptr } %t333, i64 %t334)
  %t336 = extractvalue { i32, i64 } %t335, 1
  %t337 = extractvalue { i32, i64 } %t335, 0
  store i32 %t337, ptr %l161
  %t338 = icmp ne i32 %t337, 0
  br i1 %t338, label %bb104, label %ok.339, !prof !99
ok.339:
  store i64 %t336, ptr %l160
  br label %bb103
bb101:
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t341 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65541, 0
  store { i32, %"compiler/cond:Value" } %t341, ptr %rv
  br label %ret
bb103:
  %t342 = load i64, ptr %l160, !tbaa !65
  store i64 %t342, ptr %l156, !tbaa !65
  br label %bb105
bb104:
  br label %bb102
bb105:
  %t343 = load i64, ptr %l156, !tbaa !65
  store i64 %t343, ptr %l9, !tbaa !65
  %t344 = load i1, ptr %l4, !tbaa !21
  br i1 %t344, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s9
  %t346 = load i64, ptr %l9, !tbaa !65
  store i64 %t346, ptr %l10, !tbaa !24
  store i32 2, ptr %l166
  %t349 = load i1, ptr %l2, !tbaa !21
  br i1 %t349, label %bb108, label %bb109
bb107:
  br label %bb112
bb108:
  %t351 = load i64, ptr %l10, !tbaa !24
  %t353 = sub i64 0, %t351
  store i64 %t353, ptr %l168, !tbaa !24
  br label %bb110
bb109:
  %t355 = load i64, ptr %l10, !tbaa !24
  store i64 %t355, ptr %l168, !tbaa !24
  br label %bb110
bb110:
  %t357 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t358 = load i32, ptr %l166, !range !{i32 0, i32 5}
  %t359 = load i64, ptr %l168, !tbaa !24
  %t361 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s9, i32 %t358, i64 %t359, double 0x0000000000000000, i64 0, i64 %t357, i1 false, i1 false)
  store %"compiler/cond:Value" %t361, ptr %l173
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t362 = load %"compiler/cond:Value", ptr %l173
  %t363 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t362, 1
  store { i32, %"compiler/cond:Value" } %t363, ptr %rv
  br label %ret
bb112:
  %t364 = load i1, ptr %l2, !tbaa !21
  br i1 %t364, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s10
  %t366 = load i64, ptr %l9, !tbaa !65
  %t367 = add i64 9223372036854775807, 1
  %t370 = icmp ugt i64 %t366, %t367
  br i1 %t370, label %bb115, label %bb116
bb114:
  br label %bb119
bb115:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t373 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65542, 0
  store { i32, %"compiler/cond:Value" } %t373, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t374 = load i64, ptr %l9, !tbaa !65
  %t377 = sub i64 0, %t374
  %t378 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t382 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s10, i32 2, i64 %t377, double 0x0000000000000000, i64 0, i64 %t378, i1 false, i1 false)
  store %"compiler/cond:Value" %t382, ptr %l184
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t383 = load %"compiler/cond:Value", ptr %l184
  %t384 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t383, 1
  store { i32, %"compiler/cond:Value" } %t384, ptr %rv
  br label %ret
bb119:
  %t385 = load i64, ptr %l9, !tbaa !65
  %t387 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t388 = load i64, ptr %l9, !tbaa !65
  %t390 = icmp ugt i64 %t388, 9223372036854775807
  %t395 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 2, i64 %t385, double 0x0000000000000000, i64 0, i64 %t387, i1 false, i1 %t390)
  store %"compiler/cond:Value" %t395, ptr %l191
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s0)
  %t396 = load %"compiler/cond:Value", ptr %l191
  %t397 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t396, 1
  store { i32, %"compiler/cond:Value" } %t397, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/cond:Value" }, ptr %rv
  ret { i32, %"compiler/cond:Value" } %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t28 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  store i1 %t28, ptr %l19
  br label %bb5
bb5:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2earith(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca double
  %l11 = alloca double
  %l12 = alloca i64
  %l16 = alloca i1
  %l19 = alloca %"compiler/cond:Value"
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca %"compiler/cond:Value"
  %l37 = alloca i1
  %l40 = alloca %"compiler/cond:Value"
  %l43 = alloca %"compiler/cond:Value"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca %"compiler/cond:Value"
  %l62 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l98 = alloca i1
  %l104 = alloca i1
  %l107 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l120 = alloca %"compiler/cond:Value"
  %l123 = alloca i64
  %l131 = alloca i1
  %l132 = alloca i64
  %l135 = alloca i64
  %l139 = alloca i1
  %l143 = alloca %"compiler/cond:Value"
  %l148 = alloca %"compiler/cond:Value"
  %l151 = alloca i1
  %l154 = alloca i1
  %l157 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l166 = alloca %"compiler/diagmsg:Msg"
  %l167 = alloca %"compiler/cond:Value"
  %l172 = alloca double
  %l174 = alloca double
  %l175 = alloca i32
  %l178 = alloca %"compiler/cond:Value"
  %l181 = alloca double
  %l183 = alloca double
  %l184 = alloca i32
  %l187 = alloca %"compiler/cond:Value"
  %l192 = alloca %"compiler/cond:Value"
  %l195 = alloca i1
  %l198 = alloca i64
  %l201 = alloca double
  %l207 = alloca double
  %l213 = alloca double
  %l223 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  store %"compiler/cond:Value" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 5}
  %t10 = trunc i64 0 to i32
  %t11 = icmp eq i32 %t8, %t10
  store i1 %t11, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t14, ptr %l19
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load %"compiler/cond:Value", ptr %l19
  store %"compiler/cond:Value" %t15, ptr %rv
  br label %ret
bb7:
  %t16 = load %"compiler/cond:Value", ptr %l3
  %t18 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t16)
  store i1 %t18, ptr %l21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l21, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb10:
  %t22 = load %"compiler/cond:Value", ptr %l4
  %t24 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t22)
  store i1 %t24, ptr %l25
  br label %bb11
bb11:
  %t25 = load i1, ptr %l25, !tbaa !21
  %t26 = xor i1 %t25, true
  store i1 %t26, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l23, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l28
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s2, ptr %t31, %"compiler/source:Span" %t32)
  store { i64, ptr } %t35, ptr %l31
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t36 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %s2, ptr %v0, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t38, ptr %l33
  br label %bb16
bb16:
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l28
  %t41 = load %"compiler/diagmsg:Msg", ptr %l33
  %t42 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, %"compiler/diagmsg:Msg" %t41)
  store %"compiler/cond:Value" %t42, ptr %l34
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/cond:Value", ptr %l34
  store %"compiler/cond:Value" %t43, ptr %rv
  br label %ret
bb18:
  %t44 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 5}
  %t47 = trunc i64 2 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb19, label %bb20
bb19:
  %t50 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t51 = load i32, ptr %t50, !range !{i32 0, i32 5}
  %t53 = trunc i64 2 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t56 = load i1, ptr %l37, !tbaa !21
  br i1 %t56, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load %"compiler/cond:Value", ptr %l3
  %t58 = load %"compiler/cond:Value", ptr %l4
  %t61 = call { i32, %"compiler/cond:Value" } @compiler_2fcond_2emeet(%"compiler/cond:Value" %t57, %"compiler/cond:Value" %t58)
  %t62 = extractvalue { i32, %"compiler/cond:Value" } %t61, 1
  %t63 = extractvalue { i32, %"compiler/cond:Value" } %t61, 0
  store i32 %t63, ptr %l44
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb25, label %ok.65, !prof !99
ok.65:
  store %"compiler/cond:Value" %t62, ptr %l43
  br label %bb24
bb23:
  br label %bb100
bb24:
  %t66 = load %"compiler/cond:Value", ptr %l43
  store %"compiler/cond:Value" %t66, ptr %l40
  br label %bb30
bb25:
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t68, ptr %l46
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  %t73 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s4, ptr %t69, %"compiler/source:Span" %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb27
bb27:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t76 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %s4, ptr %v0, { i64, ptr } %t74)
  store %"compiler/diagmsg:Msg" %t76, ptr %l51
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l46
  %t79 = load %"compiler/diagmsg:Msg", ptr %l51
  %t80 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/diagmsg:Msg" %t79)
  store %"compiler/cond:Value" %t80, ptr %l52
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load %"compiler/cond:Value", ptr %l52
  store %"compiler/cond:Value" %t81, ptr %rv
  br label %ret
bb30:
  %t82 = load %"compiler/cond:Value", ptr %l40
  store %"compiler/cond:Value" %t82, ptr %l5
  %t83 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 4
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t86 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 5
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  %t89 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t91 = trunc i64 68 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb43
bb33:
  %t94 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  %t100 = add i64 %t95, %t97
  store i64 %t100, ptr %l8, !tbaa !24
  %t102 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb34, label %bb35
bb34:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t108 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t112 = icmp slt i64 %t107, %t109
  store i1 %t112, ptr %l62, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t114 = load i1, ptr %l62, !tbaa !21
  br i1 %t114, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb42
bb38:
  %t115 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t121 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  %t125 = icmp sgt i64 %t120, %t122
  store i1 %t125, ptr %l69, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t127 = load i1, ptr %l69, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t128 = load i1, ptr %l66, !tbaa !21
  store i1 %t128, ptr %l9, !tbaa !21
  br label %bb87
bb43:
  %t129 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t131 = trunc i64 69 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb56
bb46:
  %t134 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t140 = sub i64 %t135, %t137
  store i64 %t140, ptr %l8, !tbaa !24
  %t142 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t143 = load i64, ptr %t142, !tbaa !24
  %t145 = icmp slt i64 %t143, 0
  br i1 %t145, label %bb47, label %bb48
bb47:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = icmp slt i64 %t147, %t149
  store i1 %t152, ptr %l80, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t154 = load i1, ptr %l80, !tbaa !21
  br i1 %t154, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb55
bb51:
  %t155 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t156 = load i64, ptr %t155, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb52, label %bb53
bb52:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t161 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  %t165 = icmp sgt i64 %t160, %t162
  store i1 %t165, ptr %l87, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb54
bb54:
  %t167 = load i1, ptr %l87, !tbaa !21
  store i1 %t167, ptr %l84, !tbaa !21
  br label %bb55
bb55:
  %t168 = load i1, ptr %l84, !tbaa !21
  store i1 %t168, ptr %l9, !tbaa !21
  br label %bb87
bb56:
  %t169 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t171 = trunc i64 70 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t174 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t175 = load i64, ptr %t174, !tbaa !24
  %t176 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  %t180 = mul i64 %t175, %t177
  store i64 %t180, ptr %l8, !tbaa !24
  %t182 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t183 = load i64, ptr %t182, !tbaa !24
  %t185 = icmp ne i64 %t183, 0
  br i1 %t185, label %bb60, label %bb61
bb60:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t188 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  %t192 = sdiv i64 %t187, %t189
  %t193 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t194 = load i64, ptr %t193, !tbaa !24
  %t197 = icmp ne i64 %t192, %t194
  br i1 %t197, label %bb62, label %bb63
bb61:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb68
bb62:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb67
bb63:
  %t199 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t200 = load i64, ptr %t199, !tbaa !24
  %t202 = icmp eq i64 %t200, -1
  br i1 %t202, label %bb64, label %bb65
bb64:
  %t204 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  %t207 = icmp eq i64 %t205, -9223372036854775808
  store i1 %t207, ptr %l107, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb66
bb66:
  %t209 = load i1, ptr %l107, !tbaa !21
  store i1 %t209, ptr %l104, !tbaa !21
  br label %bb67
bb67:
  %t210 = load i1, ptr %l104, !tbaa !21
  store i1 %t210, ptr %l98, !tbaa !21
  br label %bb68
bb68:
  %t211 = load i1, ptr %l98, !tbaa !21
  store i1 %t211, ptr %l9, !tbaa !21
  br label %bb87
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb86
bb72:
  %t212 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t213 = load i64, ptr %t212, !tbaa !24
  %t215 = icmp eq i64 %t213, 0
  br i1 %t215, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb78
bb74:
  %t217 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t218 = load i64, ptr %t217, !tbaa !24
  %t220 = icmp eq i64 %t218, -9223372036854775808
  br i1 %t220, label %bb75, label %bb76
bb75:
  %t222 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = icmp eq i64 %t223, -1
  store i1 %t225, ptr %l115, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb77
bb77:
  %t227 = load i1, ptr %l115, !tbaa !21
  store i1 %t227, ptr %l112, !tbaa !21
  br label %bb78
bb78:
  %t228 = load i1, ptr %l112, !tbaa !21
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t233 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t229, %"compiler/source:Span" %t230)
  store %"compiler/cond:Value" %t233, ptr %l120
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t234 = load %"compiler/cond:Value", ptr %l120
  store %"compiler/cond:Value" %t234, ptr %rv
  br label %ret
bb82:
  %t235 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t237 = trunc i64 72 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb83, label %bb84
bb83:
  %t240 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t241 = load i64, ptr %t240, !tbaa !24
  %t242 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t243 = load i64, ptr %t242, !tbaa !24
  %t246 = sdiv i64 %t241, %t243
  store i64 %t246, ptr %l123, !tbaa !24
  br label %bb85
bb84:
  %t248 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t251 = load i64, ptr %t250, !tbaa !24
  %t254 = srem i64 %t249, %t251
  store i64 %t254, ptr %l123, !tbaa !24
  br label %bb85
bb85:
  %t256 = load i64, ptr %l123, !tbaa !24
  store i64 %t256, ptr %l8, !tbaa !24
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_a5b50ffc6e80595c_88be7d164d57caa8)
  unreachable
bb87:
  %t257 = load i1, ptr %l9, !tbaa !21
  br i1 %t257, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb94
bb89:
  %t259 = load i64, ptr %l8, !tbaa !24
  store i64 %t259, ptr %l132, !tbaa !24
  %t260 = load i64, ptr %l6, !tbaa !24
  %t262 = icmp ne i64 %t260, 0
  br i1 %t262, label %bb90, label %bb91
bb90:
  %t264 = load i64, ptr %l6, !tbaa !24
  store i64 %t264, ptr %l135, !tbaa !24
  br label %bb92
bb91:
  %t266 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t266, ptr %l135, !tbaa !24
  br label %bb92
bb92:
  %t268 = load i1, ptr %l7, !tbaa !21
  %t269 = load i64, ptr %l132, !tbaa !24
  %t270 = load i64, ptr %l135, !tbaa !24
  %t272 = call i1 @compiler_2fcond_2efits(i64 %t269, i64 %t270, i1 %t268)
  store i1 %t272, ptr %l139
  br label %bb93
bb93:
  %t273 = load i1, ptr %l139, !tbaa !21
  %t274 = xor i1 %t273, true
  store i1 %t274, ptr %l131, !tbaa !21
  br label %bb94
bb94:
  %t276 = load i1, ptr %l131, !tbaa !21
  br i1 %t276, label %bb95, label %bb96
bb95:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l1
  %t281 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t277, %"compiler/source:Span" %t278)
  store %"compiler/cond:Value" %t281, ptr %l143
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t282 = load %"compiler/cond:Value", ptr %l143
  store %"compiler/cond:Value" %t282, ptr %rv
  br label %ret
bb98:
  %t283 = load i64, ptr %l8, !tbaa !24
  %t284 = load i64, ptr %l6, !tbaa !24
  %t285 = load i1, ptr %l7, !tbaa !21
  %t290 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 2, i64 %t283, double 0x0000000000000000, i64 0, i64 %t284, i1 %t285, i1 false)
  store %"compiler/cond:Value" %t290, ptr %l148
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t291 = load %"compiler/cond:Value", ptr %l148
  store %"compiler/cond:Value" %t291, ptr %rv
  br label %ret
bb100:
  %t292 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t293 = load i32, ptr %t292, !range !{i32 0, i32 5}
  %t295 = trunc i64 2 to i32
  %t296 = icmp eq i32 %t293, %t295
  br i1 %t296, label %bb101, label %bb102
bb101:
  %t298 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t299 = load i64, ptr %t298, !tbaa !24
  %t301 = icmp ne i64 %t299, 0
  store i1 %t301, ptr %l151, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb103
bb103:
  %t303 = load i1, ptr %l151, !tbaa !21
  br i1 %t303, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb109
bb105:
  %t304 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t305 = load i32, ptr %t304, !range !{i32 0, i32 5}
  %t307 = trunc i64 2 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb106, label %bb107
bb106:
  %t310 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = icmp ne i64 %t311, 0
  store i1 %t313, ptr %l157, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb108
bb108:
  %t315 = load i1, ptr %l157, !tbaa !21
  store i1 %t315, ptr %l154, !tbaa !21
  br label %bb109
bb109:
  %t316 = load i1, ptr %l154, !tbaa !21
  br i1 %t316, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s11
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l160, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t318, ptr %l161
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  %t323 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s11, ptr %t319, %"compiler/source:Span" %t320)
  store { i64, ptr } %t323, ptr %l164
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t324 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t326 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %s11, ptr %v0, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t326, ptr %l166
  br label %bb113
bb113:
  %t327 = load ptr, ptr %l160, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l161
  %t329 = load %"compiler/diagmsg:Msg", ptr %l166
  %t330 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t327, %"compiler/source:Span" %t328, %"compiler/diagmsg:Msg" %t329)
  store %"compiler/cond:Value" %t330, ptr %l167
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t331 = load %"compiler/cond:Value", ptr %l167
  store %"compiler/cond:Value" %t331, ptr %rv
  br label %ret
bb115:
  %t332 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t333 = load double, ptr %t332, !tbaa !26
  store double %t333, ptr %l10, !tbaa !26
  %t335 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t336 = load double, ptr %t335, !tbaa !26
  store double %t336, ptr %l11, !tbaa !26
  %t338 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t339 = load i32, ptr %t338, !range !{i32 0, i32 5}
  %t341 = trunc i64 2 to i32
  %t342 = icmp eq i32 %t339, %t341
  br i1 %t342, label %bb116, label %bb117
bb116:
  %t344 = load %"compiler/cond:Value", ptr %l3
  %t346 = call { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t344)
  %t347 = extractvalue { i32, double } %t346, 1
  %t348 = extractvalue { i32, double } %t346, 0
  store i32 %t348, ptr %l175
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb119, label %ok.350, !prof !99
ok.350:
  store double %t347, ptr %l174
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t351 = load double, ptr %l174, !tbaa !26
  store double %t351, ptr %l172, !tbaa !26
  br label %bb122
bb119:
  br label %bb120
bb120:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t356 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t352, %"compiler/source:Span" %t353)
  store %"compiler/cond:Value" %t356, ptr %l178
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  %t357 = load %"compiler/cond:Value", ptr %l178
  store %"compiler/cond:Value" %t357, ptr %rv
  br label %ret
bb122:
  %t358 = load double, ptr %l172, !tbaa !26
  store double %t358, ptr %l10, !tbaa !26
  br label %bb123
bb123:
  %t359 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t360 = load i32, ptr %t359, !range !{i32 0, i32 5}
  %t362 = trunc i64 2 to i32
  %t363 = icmp eq i32 %t360, %t362
  br i1 %t363, label %bb124, label %bb125
bb124:
  %t365 = load %"compiler/cond:Value", ptr %l4
  %t367 = call { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t365)
  %t368 = extractvalue { i32, double } %t367, 1
  %t369 = extractvalue { i32, double } %t367, 0
  store i32 %t369, ptr %l184
  %t370 = icmp ne i32 %t369, 0
  br i1 %t370, label %bb127, label %ok.371, !prof !99
ok.371:
  store double %t368, ptr %l183
  br label %bb126
bb125:
  br label %bb131
bb126:
  %t372 = load double, ptr %l183, !tbaa !26
  store double %t372, ptr %l181, !tbaa !26
  br label %bb130
bb127:
  br label %bb128
bb128:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load %"compiler/source:Span", ptr %l1
  %t377 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t373, %"compiler/source:Span" %t374)
  store %"compiler/cond:Value" %t377, ptr %l187
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  %t378 = load %"compiler/cond:Value", ptr %l187
  store %"compiler/cond:Value" %t378, ptr %rv
  br label %ret
bb130:
  %t379 = load double, ptr %l181, !tbaa !26
  store double %t379, ptr %l11, !tbaa !26
  br label %bb131
bb131:
  %t380 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t382 = trunc i64 73 to i32
  %t383 = icmp eq i32 %t380, %t382
  br i1 %t383, label %bb132, label %bb133
bb132:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l1
  %t389 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t385, %"compiler/source:Span" %t386)
  store %"compiler/cond:Value" %t389, ptr %l192
  br label %bb134
bb133:
  br label %bb135
bb134:
  call void @__olang_scope_close(ptr %s0)
  %t390 = load %"compiler/cond:Value", ptr %l192
  store %"compiler/cond:Value" %t390, ptr %rv
  br label %ret
bb135:
  %t391 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t392 = load i64, ptr %t391, !tbaa !24
  %t394 = icmp ne i64 %t392, 0
  br i1 %t394, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb138
bb137:
  %t396 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t397 = load i64, ptr %t396, !tbaa !24
  %t399 = icmp ne i64 %t397, 0
  store i1 %t399, ptr %l195, !tbaa !21
  br label %bb138
bb138:
  %t401 = load i1, ptr %l195, !tbaa !21
  br i1 %t401, label %bb139, label %bb140
bb139:
  store i64 64, ptr %l198, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb141
bb141:
  %t402 = load i64, ptr %l198, !tbaa !24
  store i64 %t402, ptr %l12, !tbaa !24
  %t403 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t405 = trunc i64 68 to i32
  %t406 = icmp eq i32 %t403, %t405
  br i1 %t406, label %bb142, label %bb143
bb142:
  %t408 = load double, ptr %l10, !tbaa !26
  %t409 = load double, ptr %l11, !tbaa !26
  %t412 = fadd double %t408, %t409
  store double %t412, ptr %l201, !tbaa !26
  br label %bb150
bb143:
  %t414 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t416 = trunc i64 69 to i32
  %t417 = icmp eq i32 %t414, %t416
  br i1 %t417, label %bb144, label %bb145
bb144:
  %t419 = load double, ptr %l10, !tbaa !26
  %t420 = load double, ptr %l11, !tbaa !26
  %t423 = fsub double %t419, %t420
  store double %t423, ptr %l207, !tbaa !26
  br label %bb149
bb145:
  %t425 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t427 = trunc i64 70 to i32
  %t428 = icmp eq i32 %t425, %t427
  br i1 %t428, label %bb146, label %bb147
bb146:
  %t430 = load double, ptr %l10, !tbaa !26
  %t431 = load double, ptr %l11, !tbaa !26
  %t434 = fmul double %t430, %t431
  store double %t434, ptr %l213, !tbaa !26
  br label %bb148
bb147:
  %t436 = load double, ptr %l10, !tbaa !26
  %t437 = load double, ptr %l11, !tbaa !26
  %t440 = fdiv double %t436, %t437
  store double %t440, ptr %l213, !tbaa !26
  br label %bb148
bb148:
  %t442 = load double, ptr %l213, !tbaa !26
  store double %t442, ptr %l207, !tbaa !26
  br label %bb149
bb149:
  %t443 = load double, ptr %l207, !tbaa !26
  store double %t443, ptr %l201, !tbaa !26
  br label %bb150
bb150:
  %t444 = load double, ptr %l201, !tbaa !26
  %t446 = load i64, ptr %l12, !tbaa !24
  %t450 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 3, i64 0, double %t444, i64 0, i64 %t446, i1 false, i1 false)
  store %"compiler/cond:Value" %t450, ptr %l223
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s0)
  %t451 = load %"compiler/cond:Value", ptr %l223
  store %"compiler/cond:Value" %t451, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/cond:Value" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i1
  %l22 = alloca %"compiler/cond:Value"
  %l29 = alloca %"compiler/cond:Value"
  %l33 = alloca %"compiler/cond:Value"
  %l35 = alloca %"compiler/cond:Value"
  %l43 = alloca %"compiler/cond:Value"
  %l50 = alloca %"compiler/cond:Value"
  %l55 = alloca %"compiler/cond:Value"
  %l59 = alloca %"compiler/cond:Value"
  %l64 = alloca %"compiler/cond:Value"
  %l68 = alloca %"compiler/cond:Value"
  %l71 = alloca i1
  %l74 = alloca %"compiler/cond:Value"
  %l78 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/cond:Value", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/cond:Global", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 5}
  %t19 = trunc i64 2 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp eq i64 %t23, 0
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 5}
  %t30 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t33 = load double, ptr %t32, !tbaa !26
  %t34 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t42 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t29, i64 %t31, double %t33, i64 %t35, i64 %t36, i1 false, i1 false)
  store %"compiler/cond:Value" %t42, ptr %l22
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/cond:Value", ptr %l22
  store %"compiler/cond:Value" %t43, ptr %rv
  br label %ret
bb13:
  %t44 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 5}
  %t47 = trunc i64 3 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t51 = load i32, ptr %t50, !range !{i32 0, i32 5}
  %t52 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t55 = load double, ptr %t54, !tbaa !26
  %t56 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t62 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s4, i32 %t51, i64 %t53, double %t55, i64 %t57, i64 64, i1 false, i1 false)
  store %"compiler/cond:Value" %t62, ptr %l29
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/cond:Value", ptr %l29
  store %"compiler/cond:Value" %t63, ptr %rv
  br label %ret
bb17:
  %t64 = load %"compiler/cond:Value", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t64, ptr %rv
  br label %ret
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/cond:Global", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2edeclaredKind(ptr %v1, { i64, ptr } %t69)
  store %"compiler/cond:Value" %t71, ptr %l33
  br label %bb19
bb19:
  %t72 = load %"compiler/cond:Value", ptr %l33
  store %"compiler/cond:Value" %t72, ptr %l4
  %t73 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 5}
  store i32 %t74, ptr %l5
  %t76 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t78 = trunc i64 2 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  %t83 = load %"compiler/cond:Value", ptr %l3
  %t84 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 5
  %t87 = load i1, ptr %t86, !tbaa !21
  %t93 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eintDeclared(ptr %v0, ptr %t81, %"compiler/source:Span" %t82, %"compiler/cond:Value" %t83, i64 %t85, i1 %t87)
  store %"compiler/cond:Value" %t93, ptr %l43
  br label %bb23
bb23:
  %t94 = load %"compiler/cond:Value", ptr %l43
  store %"compiler/cond:Value" %t94, ptr %l35
  br label %bb57
bb24:
  %t95 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t97 = trunc i64 3 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t102 = load %"compiler/cond:Value", ptr %l3
  %t103 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t104 = load i64, ptr %t103, !tbaa !24
  %t109 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efloatDeclared(ptr %v0, ptr %t100, %"compiler/source:Span" %t101, %"compiler/cond:Value" %t102, i64 %t104)
  store %"compiler/cond:Value" %t109, ptr %l50
  br label %bb28
bb28:
  %t110 = load %"compiler/cond:Value", ptr %l50
  store %"compiler/cond:Value" %t110, ptr %l35
  br label %bb57
bb29:
  %t111 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t113 = trunc i64 1 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t116 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t117 = load i32, ptr %t116, !range !{i32 0, i32 5}
  %t119 = trunc i64 1 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t122, ptr %l55
  br label %bb36
bb34:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l1
  %t128 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t124, %"compiler/source:Span" %t125)
  store %"compiler/cond:Value" %t128, ptr %l59
  br label %bb35
bb35:
  %t129 = load %"compiler/cond:Value", ptr %l59
  store %"compiler/cond:Value" %t129, ptr %l55
  br label %bb36
bb36:
  %t130 = load %"compiler/cond:Value", ptr %l55
  store %"compiler/cond:Value" %t130, ptr %l35
  br label %bb57
bb37:
  %t131 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t133 = trunc i64 4 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb45
bb40:
  %t136 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t137 = load i32, ptr %t136, !range !{i32 0, i32 5}
  %t139 = trunc i64 4 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t142 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t142, ptr %l64
  br label %bb44
bb42:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  %t148 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t144, %"compiler/source:Span" %t145)
  store %"compiler/cond:Value" %t148, ptr %l68
  br label %bb43
bb43:
  %t149 = load %"compiler/cond:Value", ptr %l68
  store %"compiler/cond:Value" %t149, ptr %l64
  br label %bb44
bb44:
  %t150 = load %"compiler/cond:Value", ptr %l64
  store %"compiler/cond:Value" %t150, ptr %l35
  br label %bb57
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t151 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t152 = load i32, ptr %t151, !range !{i32 0, i32 5}
  %t154 = trunc i64 4 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb51
bb50:
  %t157 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t158 = load i32, ptr %t157, !range !{i32 0, i32 5}
  %t160 = trunc i64 1 to i32
  %t161 = icmp eq i32 %t158, %t160
  store i1 %t161, ptr %l71, !tbaa !21
  br label %bb51
bb51:
  %t163 = load i1, ptr %l71, !tbaa !21
  br i1 %t163, label %bb52, label %bb53
bb52:
  %t164 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t164, ptr %l74
  br label %bb55
bb53:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t170 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t166, %"compiler/source:Span" %t167)
  store %"compiler/cond:Value" %t170, ptr %l78
  br label %bb54
bb54:
  %t171 = load %"compiler/cond:Value", ptr %l78
  store %"compiler/cond:Value" %t171, ptr %l74
  br label %bb55
bb55:
  %t172 = load %"compiler/cond:Value", ptr %l74
  store %"compiler/cond:Value" %t172, ptr %l35
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_274101562a710104_e9b847c59a86b198)
  unreachable
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load %"compiler/cond:Value", ptr %l35
  store %"compiler/cond:Value" %t173, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ecompare(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca double
  %l8 = alloca double
  %l11 = alloca i1
  %l17 = alloca %"compiler/cond:Value"
  %l18 = alloca %"compiler/cond:Value"
  %l19 = alloca %"compiler/cond:Value"
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i1
  %l47 = alloca i1
  %l52 = alloca i64
  %l55 = alloca i1
  %l58 = alloca %"compiler/cond:Value"
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca %"compiler/cond:Value"
  %l74 = alloca i64
  %l78 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l101 = alloca %"compiler/diagmsg:Msg"
  %l102 = alloca %"compiler/cond:Value"
  %l107 = alloca double
  %l109 = alloca double
  %l110 = alloca i32
  %l113 = alloca %"compiler/cond:Value"
  %l116 = alloca double
  %l118 = alloca double
  %l119 = alloca i32
  %l122 = alloca %"compiler/cond:Value"
  %l126 = alloca i1
  %l132 = alloca %"compiler/cond:Value"
  %l136 = alloca i64
  %l140 = alloca i64
  %l141 = alloca ptr
  %l142 = alloca %"compiler/source:Span"
  %l145 = alloca { i64, ptr }
  %l147 = alloca %"compiler/diagmsg:Msg"
  %l148 = alloca %"compiler/cond:Value"
  %l149 = alloca %"compiler/cond:Value"
  %l154 = alloca %"compiler/cond:Value"
  %l159 = alloca %"compiler/cond:Value"
  %l164 = alloca %"compiler/cond:Value"
  %l169 = alloca %"compiler/cond:Value"
  %l174 = alloca %"compiler/cond:Value"
  %l177 = alloca %"compiler/cond:Value"
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  store %"compiler/cond:Value" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 5}
  %t10 = trunc i64 0 to i32
  %t11 = icmp eq i32 %t8, %t10
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/cond:Eval", ptr %t14, i32 0, i32 10
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb5:
  br label %bb11
bb6:
  %t21 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 false)
  store %"compiler/cond:Value" %t21, ptr %l18
  br label %bb8
bb7:
  %t22 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t22, ptr %l19
  br label %bb9
bb8:
  %t23 = load %"compiler/cond:Value", ptr %l18
  store %"compiler/cond:Value" %t23, ptr %l17
  br label %bb10
bb9:
  %t24 = load %"compiler/cond:Value", ptr %l19
  store %"compiler/cond:Value" %t24, ptr %l17
  br label %bb10
bb10:
  %t25 = load %"compiler/cond:Value", ptr %l17
  store %"compiler/cond:Value" %t25, ptr %rv
  br label %ret
bb11:
  %t26 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t28 = trunc i64 95 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb14
bb13:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t33 = trunc i64 96 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l22, !tbaa !21
  store i1 %t36, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t37 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 5}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 5}
  %t46 = trunc i64 4 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t50 = load i1, ptr %l5, !tbaa !21
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Eval", ptr %t53, i32 0, i32 12
  %t56 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t55, i64 %t57)
  store { i64, ptr } %t60, ptr %l35
  br label %bb23
bb22:
  %t61 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 5}
  %t64 = trunc i64 1 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb29, label %bb30
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/cond:Eval", ptr %t67, i32 0, i32 12
  %t70 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t69, i64 %t71)
  store { i64, ptr } %t74, ptr %l39
  br label %bb24
bb24:
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t75, { i64, ptr } %t76)
  store i1 %t77, ptr %l40
  br label %bb25
bb25:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb28
bb27:
  store i64 1, ptr %l41, !tbaa !24
  br label %bb28
bb28:
  %t79 = load i64, ptr %l41, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb115
bb29:
  %t80 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80, !range !{i32 0, i32 5}
  %t83 = trunc i64 1 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb31
bb31:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb32, label %bb33
bb32:
  %t87 = load i1, ptr %l5, !tbaa !21
  store i1 %t87, ptr %l47, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb34
bb34:
  %t89 = load i1, ptr %l47, !tbaa !21
  br i1 %t89, label %bb35, label %bb36
bb35:
  %t90 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t96 = icmp eq i64 %t91, %t93
  br i1 %t96, label %bb37, label %bb38
bb36:
  %t98 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 5}
  %t101 = trunc i64 2 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb40, label %bb41
bb37:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb39
bb38:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb39
bb39:
  %t104 = load i64, ptr %l52, !tbaa !24
  store i64 %t104, ptr %l6, !tbaa !24
  br label %bb114
bb40:
  %t105 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t106 = load i32, ptr %t105, !range !{i32 0, i32 5}
  %t108 = trunc i64 2 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l55, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb42
bb42:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb43, label %bb44
bb43:
  %t112 = load %"compiler/cond:Value", ptr %l3
  %t113 = load %"compiler/cond:Value", ptr %l4
  %t116 = call { i32, %"compiler/cond:Value" } @compiler_2fcond_2emeet(%"compiler/cond:Value" %t112, %"compiler/cond:Value" %t113)
  %t117 = extractvalue { i32, %"compiler/cond:Value" } %t116, 1
  %t118 = extractvalue { i32, %"compiler/cond:Value" } %t116, 0
  store i32 %t118, ptr %l62
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb46, label %ok.120, !prof !99
ok.120:
  store %"compiler/cond:Value" %t117, ptr %l61
  br label %bb45
bb44:
  %t121 = load %"compiler/cond:Value", ptr %l3
  %t123 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t121)
  store i1 %t123, ptr %l80
  br label %bb58
bb45:
  %t124 = load %"compiler/cond:Value", ptr %l61
  store %"compiler/cond:Value" %t124, ptr %l58
  br label %bb51
bb46:
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l63, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t126, ptr %l64
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t131 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s7, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t131, ptr %l67
  br label %bb48
bb48:
  %t132 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t134 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %s7, ptr %v0, { i64, ptr } %t132)
  store %"compiler/diagmsg:Msg" %t134, ptr %l69
  br label %bb49
bb49:
  %t135 = load ptr, ptr %l63, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l64
  %t137 = load %"compiler/diagmsg:Msg", ptr %l69
  %t138 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t135, %"compiler/source:Span" %t136, %"compiler/diagmsg:Msg" %t137)
  store %"compiler/cond:Value" %t138, ptr %l70
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  %t139 = load %"compiler/cond:Value", ptr %l70
  store %"compiler/cond:Value" %t139, ptr %rv
  br label %ret
bb51:
  %t140 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t143 = load i64, ptr %t142, !tbaa !24
  %t146 = icmp slt i64 %t141, %t143
  br i1 %t146, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %l74, !tbaa !24
  br label %bb57
bb53:
  %t148 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  %t150 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t154 = icmp sgt i64 %t149, %t151
  br i1 %t154, label %bb54, label %bb55
bb54:
  store i64 1, ptr %l78, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb56
bb56:
  %t156 = load i64, ptr %l78, !tbaa !24
  store i64 %t156, ptr %l74, !tbaa !24
  br label %bb57
bb57:
  %t157 = load i64, ptr %l74, !tbaa !24
  store i64 %t157, ptr %l6, !tbaa !24
  br label %bb113
bb58:
  %t158 = load i1, ptr %l80, !tbaa !21
  br i1 %t158, label %bb59, label %bb60
bb59:
  %t159 = load %"compiler/cond:Value", ptr %l4
  %t161 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t159)
  store i1 %t161, ptr %l83
  br label %bb61
bb60:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb62
bb61:
  %t162 = load i1, ptr %l83, !tbaa !21
  store i1 %t162, ptr %l81, !tbaa !21
  br label %bb62
bb62:
  %t163 = load i1, ptr %l81, !tbaa !21
  br i1 %t163, label %bb63, label %bb64
bb63:
  %t164 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t165 = load i32, ptr %t164, !range !{i32 0, i32 5}
  %t167 = trunc i64 2 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb65, label %bb66
bb64:
  store %olang.scope zeroinitializer, ptr %s16
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l141, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t171, ptr %l142
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l1
  %t176 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s16, ptr %t172, %"compiler/source:Span" %t173)
  store { i64, ptr } %t176, ptr %l145
  br label %bb109
bb65:
  %t177 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t178 = load i64, ptr %t177, !tbaa !24
  %t180 = icmp ne i64 %t178, 0
  store i1 %t180, ptr %l86, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb67
bb67:
  %t182 = load i1, ptr %l86, !tbaa !21
  br i1 %t182, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb73
bb69:
  %t183 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t184 = load i32, ptr %t183, !range !{i32 0, i32 5}
  %t186 = trunc i64 2 to i32
  %t187 = icmp eq i32 %t184, %t186
  br i1 %t187, label %bb70, label %bb71
bb70:
  %t189 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t190 = load i64, ptr %t189, !tbaa !24
  %t192 = icmp ne i64 %t190, 0
  store i1 %t192, ptr %l92, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb72
bb72:
  %t194 = load i1, ptr %l92, !tbaa !21
  store i1 %t194, ptr %l89, !tbaa !21
  br label %bb73
bb73:
  %t195 = load i1, ptr %l89, !tbaa !21
  br i1 %t195, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l95, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t197, ptr %l96
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l1
  %t202 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s10, ptr %t198, %"compiler/source:Span" %t199)
  store { i64, ptr } %t202, ptr %l99
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t203 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t205 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %s10, ptr %v0, { i64, ptr } %t203)
  store %"compiler/diagmsg:Msg" %t205, ptr %l101
  br label %bb77
bb77:
  %t206 = load ptr, ptr %l95, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l96
  %t208 = load %"compiler/diagmsg:Msg", ptr %l101
  %t209 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t206, %"compiler/source:Span" %t207, %"compiler/diagmsg:Msg" %t208)
  store %"compiler/cond:Value" %t209, ptr %l102
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t210 = load %"compiler/cond:Value", ptr %l102
  store %"compiler/cond:Value" %t210, ptr %rv
  br label %ret
bb79:
  %t211 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t212 = load double, ptr %t211, !tbaa !26
  store double %t212, ptr %l7, !tbaa !26
  %t214 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t215 = load double, ptr %t214, !tbaa !26
  store double %t215, ptr %l8, !tbaa !26
  %t217 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t218 = load i32, ptr %t217, !range !{i32 0, i32 5}
  %t220 = trunc i64 2 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb80, label %bb81
bb80:
  %t223 = load %"compiler/cond:Value", ptr %l3
  %t225 = call { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t223)
  %t226 = extractvalue { i32, double } %t225, 1
  %t227 = extractvalue { i32, double } %t225, 0
  store i32 %t227, ptr %l110
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb83, label %ok.229, !prof !99
ok.229:
  store double %t226, ptr %l109
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t230 = load double, ptr %l109, !tbaa !26
  store double %t230, ptr %l107, !tbaa !26
  br label %bb86
bb83:
  br label %bb84
bb84:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l1
  %t235 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store %"compiler/cond:Value" %t235, ptr %l113
  br label %bb85
bb85:
  %t236 = load %"compiler/cond:Value", ptr %l113
  store %"compiler/cond:Value" %t236, ptr %rv
  br label %ret
bb86:
  %t237 = load double, ptr %l107, !tbaa !26
  store double %t237, ptr %l7, !tbaa !26
  br label %bb87
bb87:
  %t238 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t239 = load i32, ptr %t238, !range !{i32 0, i32 5}
  %t241 = trunc i64 2 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb88, label %bb89
bb88:
  %t244 = load %"compiler/cond:Value", ptr %l4
  %t246 = call { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t244)
  %t247 = extractvalue { i32, double } %t246, 1
  %t248 = extractvalue { i32, double } %t246, 0
  store i32 %t248, ptr %l119
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb91, label %ok.250, !prof !99
ok.250:
  store double %t247, ptr %l118
  br label %bb90
bb89:
  br label %bb95
bb90:
  %t251 = load double, ptr %l118, !tbaa !26
  store double %t251, ptr %l116, !tbaa !26
  br label %bb94
bb91:
  br label %bb92
bb92:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  %t256 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t252, %"compiler/source:Span" %t253)
  store %"compiler/cond:Value" %t256, ptr %l122
  br label %bb93
bb93:
  %t257 = load %"compiler/cond:Value", ptr %l122
  store %"compiler/cond:Value" %t257, ptr %rv
  br label %ret
bb94:
  %t258 = load double, ptr %l116, !tbaa !26
  store double %t258, ptr %l8, !tbaa !26
  br label %bb95
bb95:
  %t259 = load double, ptr %l7, !tbaa !26
  %t260 = load double, ptr %l7, !tbaa !26
  %t263 = fcmp une double %t259, %t260
  br i1 %t263, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb98
bb97:
  %t265 = load double, ptr %l8, !tbaa !26
  %t266 = load double, ptr %l8, !tbaa !26
  %t269 = fcmp une double %t265, %t266
  store i1 %t269, ptr %l126, !tbaa !21
  br label %bb98
bb98:
  %t271 = load i1, ptr %l126, !tbaa !21
  br i1 %t271, label %bb99, label %bb100
bb99:
  %t272 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t274 = trunc i64 96 to i32
  %t275 = icmp eq i32 %t272, %t274
  %t277 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t275)
  store %"compiler/cond:Value" %t277, ptr %l132
  br label %bb101
bb100:
  br label %bb102
bb101:
  %t278 = load %"compiler/cond:Value", ptr %l132
  store %"compiler/cond:Value" %t278, ptr %rv
  br label %ret
bb102:
  %t279 = load double, ptr %l7, !tbaa !26
  %t280 = load double, ptr %l8, !tbaa !26
  %t283 = fcmp olt double %t279, %t280
  br i1 %t283, label %bb103, label %bb104
bb103:
  store i64 -1, ptr %l136, !tbaa !24
  br label %bb108
bb104:
  %t285 = load double, ptr %l7, !tbaa !26
  %t286 = load double, ptr %l8, !tbaa !26
  %t289 = fcmp ogt double %t285, %t286
  br i1 %t289, label %bb105, label %bb106
bb105:
  store i64 1, ptr %l140, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb107
bb107:
  %t291 = load i64, ptr %l140, !tbaa !24
  store i64 %t291, ptr %l136, !tbaa !24
  br label %bb108
bb108:
  %t292 = load i64, ptr %l136, !tbaa !24
  store i64 %t292, ptr %l6, !tbaa !24
  br label %bb112
bb109:
  %t293 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t295 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %s16, ptr %v0, { i64, ptr } %t293)
  store %"compiler/diagmsg:Msg" %t295, ptr %l147
  br label %bb110
bb110:
  %t296 = load ptr, ptr %l141, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l142
  %t298 = load %"compiler/diagmsg:Msg", ptr %l147
  %t299 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t296, %"compiler/source:Span" %t297, %"compiler/diagmsg:Msg" %t298)
  store %"compiler/cond:Value" %t299, ptr %l148
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s16)
  %t300 = load %"compiler/cond:Value", ptr %l148
  store %"compiler/cond:Value" %t300, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t301 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t303 = trunc i64 95 to i32
  %t304 = icmp eq i32 %t301, %t303
  br i1 %t304, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t306 = load i64, ptr %l6, !tbaa !24
  %t308 = icmp eq i64 %t306, 0
  %t310 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t308)
  store %"compiler/cond:Value" %t310, ptr %l154
  br label %bb119
bb119:
  %t311 = load %"compiler/cond:Value", ptr %l154
  store %"compiler/cond:Value" %t311, ptr %l149
  br label %bb146
bb120:
  %t312 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t314 = trunc i64 96 to i32
  %t315 = icmp eq i32 %t312, %t314
  br i1 %t315, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t317 = load i64, ptr %l6, !tbaa !24
  %t319 = icmp ne i64 %t317, 0
  %t321 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t319)
  store %"compiler/cond:Value" %t321, ptr %l159
  br label %bb124
bb124:
  %t322 = load %"compiler/cond:Value", ptr %l159
  store %"compiler/cond:Value" %t322, ptr %l149
  br label %bb146
bb125:
  %t323 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t325 = trunc i64 98 to i32
  %t326 = icmp eq i32 %t323, %t325
  br i1 %t326, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t328 = load i64, ptr %l6, !tbaa !24
  %t330 = icmp slt i64 %t328, 0
  %t332 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t330)
  store %"compiler/cond:Value" %t332, ptr %l164
  br label %bb129
bb129:
  %t333 = load %"compiler/cond:Value", ptr %l164
  store %"compiler/cond:Value" %t333, ptr %l149
  br label %bb146
bb130:
  %t334 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t336 = trunc i64 99 to i32
  %t337 = icmp eq i32 %t334, %t336
  br i1 %t337, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t339 = load i64, ptr %l6, !tbaa !24
  %t341 = icmp sle i64 %t339, 0
  %t343 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t341)
  store %"compiler/cond:Value" %t343, ptr %l169
  br label %bb134
bb134:
  %t344 = load %"compiler/cond:Value", ptr %l169
  store %"compiler/cond:Value" %t344, ptr %l149
  br label %bb146
bb135:
  %t345 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t347 = trunc i64 100 to i32
  %t348 = icmp eq i32 %t345, %t347
  br i1 %t348, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t350 = load i64, ptr %l6, !tbaa !24
  %t352 = icmp sgt i64 %t350, 0
  %t354 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t352)
  store %"compiler/cond:Value" %t354, ptr %l174
  br label %bb139
bb139:
  %t355 = load %"compiler/cond:Value", ptr %l174
  store %"compiler/cond:Value" %t355, ptr %l149
  br label %bb146
bb140:
  br i1 true, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb145
bb143:
  %t356 = load i64, ptr %l6, !tbaa !24
  %t358 = icmp sge i64 %t356, 0
  %t360 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t358)
  store %"compiler/cond:Value" %t360, ptr %l177
  br label %bb144
bb144:
  %t361 = load %"compiler/cond:Value", ptr %l177
  store %"compiler/cond:Value" %t361, ptr %l149
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_82ba276e77283333_2c83aa9106e5aedf)
  unreachable
bb146:
  %t362 = load %"compiler/cond:Value", ptr %l149
  store %"compiler/cond:Value" %t362, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l13 = alloca %"compiler/cond:Value"
  %l18 = alloca i1
  %l21 = alloca %"compiler/cond:Value"
  %l24 = alloca %"compiler/cond:Value"
  %l29 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t4, { i64, ptr } %a2)
  %t9 = extractvalue { i32, i64 } %t8, 1
  %t10 = extractvalue { i32, i64 } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb2, label %ok.12, !prof !99
ok.12:
  store i64 %t9, ptr %l9
  br label %bb1
bb1:
  %t13 = load i64, ptr %l9, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t14, %"compiler/source:Span" %t15)
  store %"compiler/cond:Value" %t18, ptr %l13
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load %"compiler/cond:Value", ptr %l13
  store %"compiler/cond:Value" %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Eval", ptr %t21, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/cond:Consts", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t32, %"compiler/source:Span" %t33)
  store %"compiler/cond:Value" %t36, ptr %l21
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/cond:Value", ptr %l21
  store %"compiler/cond:Value" %t37, ptr %rv
  br label %ret
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/cond:Value" %t42, ptr %l24
  br label %bb11
bb11:
  %t43 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t43, ptr %l4
  %t44 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !range !{i32 0, i32 5}
  %t46 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t49 = load double, ptr %t48, !tbaa !26
  %t50 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  %t56 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t45, i64 %t47, double %t49, i64 %t51, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t56, ptr %l29
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load %"compiler/cond:Value", ptr %l29
  store %"compiler/cond:Value" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efloatDeclared(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/cond:Value" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/cond:Value"
  %l8 = alloca %"compiler/cond:Value"
  %l13 = alloca i1
  %l16 = alloca i1
  %l21 = alloca %"compiler/cond:Value"
  %l25 = alloca %"compiler/cond:Value"
  %l31 = alloca %"compiler/cond:Value"
  %l34 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/cond:Value" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = icmp ne i64 %a3, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t9 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t5, %"compiler/source:Span" %t6)
  store %"compiler/cond:Value" %t9, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/cond:Value", ptr %l8
  store %"compiler/cond:Value" %t10, ptr %rv
  br label %ret
bb4:
  %t11 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 5}
  %t14 = trunc i64 2 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp ne i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb9
bb8:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp sgt i64 %t23, 9007199254740992
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb12
bb11:
  %t28 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, -9007199254740992
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store %"compiler/cond:Value" %t38, ptr %l21
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"compiler/cond:Value", ptr %l21
  store %"compiler/cond:Value" %t39, ptr %rv
  br label %ret
bb16:
  %t40 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = sitofp i64 %t41 to double
  %t46 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 3, i64 0, double %t43, i64 0, i64 64, i1 false, i1 false)
  store %"compiler/cond:Value" %t46, ptr %l25
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load %"compiler/cond:Value", ptr %l25
  store %"compiler/cond:Value" %t47, ptr %rv
  br label %ret
bb18:
  %t48 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 5}
  %t51 = trunc i64 3 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  %t60 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t56, %"compiler/source:Span" %t57)
  store %"compiler/cond:Value" %t60, ptr %l31
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/cond:Value", ptr %l31
  store %"compiler/cond:Value" %t61, ptr %rv
  br label %ret
bb22:
  %t62 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 2
  %t63 = load double, ptr %t62, !tbaa !26
  %t66 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 3, i64 0, double %t63, i64 0, i64 64, i1 false, i1 false)
  store %"compiler/cond:Value" %t66, ptr %l34
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load %"compiler/cond:Value", ptr %l34
  store %"compiler/cond:Value" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eglobal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/diagmsg:Msg"
  %l13 = alloca %"compiler/cond:Value"
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l23 = alloca %"compiler/cond:Value"
  %l24 = alloca %"compiler/cond:Value"
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca %"compiler/cond:Value"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca %"compiler/cond:Value"
  %l50 = alloca i1
  %l55 = alloca i1
  %l58 = alloca %"compiler/cond:Value"
  %l63 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l86 = alloca %"compiler/cond:Value"
  %l87 = alloca %"compiler/cond:Value"
  %l104 = alloca ptr
  %l111 = alloca %"compiler/cond:Value"
  %l112 = alloca ptr
  %l135 = alloca ptr
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca i1
  %l149 = alloca %"compiler/cond:Value"
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca %"compiler/diagmsg:Msg"
  %l158 = alloca { i64, ptr }
  %l160 = alloca %"compiler/diagmsg:Msg"
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/diagmsg:Msg"
  %l166 = alloca %"compiler/cond:Value"
  %l169 = alloca %"compiler/cond:Value"
  %l175 = alloca %"compiler/cond:Value"
  %l180 = alloca %"compiler/cond:Value"
  %l185 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i1
  %l191 = alloca i1
  %l201 = alloca %"compiler/cond:Value"
  %l207 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l220 = alloca %"compiler/cond:Value"
  %l224 = alloca %"compiler/cond:Value"
  %l225 = alloca i32
  %l227 = alloca i32
  %l229 = alloca i1
  %l233 = alloca %"compiler/cond:Value"
  %l236 = alloca i1
  %l240 = alloca i1
  %l244 = alloca %"compiler/cond:Value"
  %l251 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 9
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 64
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l28, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t9, ptr %l29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t14 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s1, ptr %t10, %"compiler/source:Span" %t11)
  store { i64, ptr } %t14, ptr %l32
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t17 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondCycle(ptr %s1, ptr %v0, { i64, ptr } %t15)
  store %"compiler/diagmsg:Msg" %t17, ptr %l34
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l28, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l29
  %t20 = load %"compiler/diagmsg:Msg", ptr %l34
  %t21 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t18, %"compiler/source:Span" %t19, %"compiler/diagmsg:Msg" %t20)
  store %"compiler/cond:Value" %t21, ptr %l35
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load %"compiler/cond:Value", ptr %l35
  store %"compiler/cond:Value" %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Global", ptr %t23, i32 0, i32 2
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l38, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l39
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31)
  store { i64, ptr } %t34, ptr %l42
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t35 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondMutable(ptr %s2, ptr %v0, { i64, ptr } %t35)
  store %"compiler/diagmsg:Msg" %t37, ptr %l44
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l38, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l39
  %t40 = load %"compiler/diagmsg:Msg", ptr %l44
  %t41 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/diagmsg:Msg" %t40, i1 false)
  store %"compiler/cond:Value" %t41, ptr %l45
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/cond:Value", ptr %l45
  store %"compiler/cond:Value" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/cond:Eval", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/cond:Scope", ptr %t46, i32 0, i32 0
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Eval", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/cond:Global", ptr %t57, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t63 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %t56, { i64, ptr } %t60)
  store i1 %t63, ptr %l55
  br label %bb15
bb14:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb16
bb15:
  %t64 = load i1, ptr %l55, !tbaa !21
  store i1 %t64, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t65 = load i1, ptr %l50, !tbaa !21
  store i1 %t65, ptr %l3, !tbaa !21
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/cond:Global", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2edeclaredKind(ptr %v1, { i64, ptr } %t69)
  store %"compiler/cond:Value" %t71, ptr %l58
  br label %bb17
bb17:
  %t72 = load %"compiler/cond:Value", ptr %l58
  store %"compiler/cond:Value" %t72, ptr %l4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/cond:Eval", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/cond:Scope", ptr %t76, i32 0, i32 0
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/cond:Global", ptr %t83, i32 0, i32 3
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t88, ptr %l66
  br label %bb20
bb19:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb21
bb20:
  %t89 = load i1, ptr %l66, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l63, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 5}
  %t96 = trunc i64 0 to i32
  %t97 = icmp eq i32 %t94, %t96
  %t99 = xor i1 %t97, true
  store i1 %t99, ptr %l68, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l68, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t102 = load %"compiler/cond:Value", ptr %l4
  %t104 = call i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %t102)
  store i1 %t104, ptr %l73
  br label %bb27
bb26:
  br label %bb39
bb27:
  %t105 = load i1, ptr %l73, !tbaa !21
  br i1 %t105, label %bb28, label %bb29
bb28:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/cond:Eval", ptr %t106, i32 0, i32 10
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = icmp eq i64 %t109, 0
  br i1 %t111, label %bb30, label %bb31
bb29:
  br label %bb38
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/cond:Eval", ptr %t113, i32 0, i32 11
  store i1 true, ptr %t115, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t116 = load i1, ptr %l3, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l79, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l80
  %t120 = load ptr, ptr %l2, !tbaa !29
  store ptr %t120, ptr %l81, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/cond:Global", ptr %t123, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t130 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %t121, %"compiler/source:Span" %t122, { i64, ptr } %t126)
  store %"compiler/cond:Value" %t130, ptr %l86
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l80
  %t133 = load ptr, ptr %l81, !tbaa !29
  %t134 = load %"compiler/cond:Value", ptr %l86
  %t135 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %t131, %"compiler/source:Span" %t132, ptr %t133, %"compiler/cond:Value" %t134)
  store %"compiler/cond:Value" %t135, ptr %l87
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/cond:Value", ptr %l87
  store %"compiler/cond:Value" %t136, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/cond:Eval", ptr %t137, i32 0, i32 4
  %t140 = load i1, ptr %t139, !tbaa !21
  store i1 %t140, ptr %l5, !tbaa !21
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/cond:Eval", ptr %t142, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  store i1 %t145, ptr %l6, !tbaa !21
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/cond:Eval", ptr %t147, i32 0, i32 6
  %t150 = load i1, ptr %t149, !tbaa !21
  store i1 %t150, ptr %l7, !tbaa !21
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/cond:Eval", ptr %t152, i32 0, i32 7
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l8
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/cond:Eval", ptr %t157, i32 0, i32 8
  %t160 = load %"compiler/diagmsg:Msg", ptr %t159
  store %"compiler/diagmsg:Msg" %t160, ptr %l9
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/cond:Eval", ptr %t162, i32 0, i32 4
  store i1 false, ptr %t166, !tbaa !21
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/cond:Eval", ptr %t167, i32 0, i32 5
  store i1 false, ptr %t171, !tbaa !21
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/cond:Eval", ptr %t172, i32 0, i32 6
  store i1 false, ptr %t176, !tbaa !21
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l104, !tbaa !29
  %t178 = load ptr, ptr %l104, !tbaa !29
  %t179 = getelementptr %"compiler/cond:Eval", ptr %t178, i32 0, i32 9
  %t180 = load i64, ptr %t179, !tbaa !24
  %t183 = add i64 %t180, 1
  %t185 = load ptr, ptr %l104, !tbaa !29
  %t186 = getelementptr %"compiler/cond:Eval", ptr %t185, i32 0, i32 9
  store i64 %t183, ptr %t186, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"compiler/cond:Global", ptr %t188, i32 0, i32 4
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t194 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t187, ptr %t191)
  store %"compiler/cond:Value" %t194, ptr %l111
  br label %bb40
bb40:
  %t195 = load %"compiler/cond:Value", ptr %l111
  store %"compiler/cond:Value" %t195, ptr %l13
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l112, !tbaa !29
  %t197 = load ptr, ptr %l112, !tbaa !29
  %t198 = getelementptr %"compiler/cond:Eval", ptr %t197, i32 0, i32 9
  %t199 = load i64, ptr %t198, !tbaa !24
  %t202 = sub i64 %t199, 1
  %t204 = load ptr, ptr %l112, !tbaa !29
  %t205 = getelementptr %"compiler/cond:Eval", ptr %t204, i32 0, i32 9
  store i64 %t202, ptr %t205, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/cond:Eval", ptr %t206, i32 0, i32 4
  %t209 = load i1, ptr %t208, !tbaa !21
  store i1 %t209, ptr %l14, !tbaa !21
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/cond:Eval", ptr %t211, i32 0, i32 5
  %t214 = load i1, ptr %t213, !tbaa !21
  store i1 %t214, ptr %l15, !tbaa !21
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/cond:Eval", ptr %t216, i32 0, i32 8
  %t219 = load %"compiler/diagmsg:Msg", ptr %t218
  store %"compiler/diagmsg:Msg" %t219, ptr %l16
  %t221 = load i1, ptr %l5, !tbaa !21
  %t223 = load i1, ptr %l6, !tbaa !21
  %t225 = load i1, ptr %l7, !tbaa !21
  %t227 = load %"compiler/source:Span", ptr %l8
  %t229 = load %"compiler/diagmsg:Msg", ptr %l9
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/cond:Eval", ptr %t231, i32 0, i32 4
  store i1 %t221, ptr %t235, !tbaa !21
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/cond:Eval", ptr %t236, i32 0, i32 5
  store i1 %t223, ptr %t240, !tbaa !21
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/cond:Eval", ptr %t241, i32 0, i32 6
  store i1 %t225, ptr %t245, !tbaa !21
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/cond:Eval", ptr %t246, i32 0, i32 7
  store %"compiler/source:Span" %t227, ptr %t250
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l135, !tbaa !29
  %t253 = load ptr, ptr %l135, !tbaa !29
  %t254 = getelementptr %"compiler/cond:Eval", ptr %t253, i32 0, i32 8
  %t255 = load %"compiler/diagmsg:Msg", ptr %t254
  store %"compiler/diagmsg:Msg" %t255, ptr %l137
  %t257 = load ptr, ptr %l135, !tbaa !29
  %t258 = getelementptr %"compiler/cond:Eval", ptr %t257, i32 0, i32 8
  store %"compiler/diagmsg:Msg" %t229, ptr %t258
  %t259 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t259, label %bb41, label %bb42
bb41:
  %t261 = getelementptr %"compiler/diagmsg:Msg", ptr %l137, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261
  %t263 = extractvalue { i64, ptr } %t262, 1
  call void @__olang_region_release(ptr %t263)
  store { i64, ptr } zeroinitializer, ptr %t261
  br label %bb42
bb42:
  %t264 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t264, label %bb43, label %bb44
bb43:
  %t266 = getelementptr %"compiler/diagmsg:Msg", ptr %l137, i32 0, i32 2
  %t267 = load { i64, ptr }, ptr %t266
  %t268 = extractvalue { i64, ptr } %t267, 1
  call void @__olang_region_release(ptr %t268)
  store { i64, ptr } zeroinitializer, ptr %t266
  br label %bb44
bb44:
  %t269 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t269, label %bb45, label %bb46
bb45:
  %t271 = getelementptr %"compiler/diagmsg:Msg", ptr %l137, i32 0, i32 3
  %t272 = load { i64, ptr }, ptr %t271
  %t273 = extractvalue { i64, ptr } %t272, 1
  call void @__olang_region_release(ptr %t273)
  store { i64, ptr } zeroinitializer, ptr %t271
  br label %bb46
bb46:
  %t274 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t274, label %bb47, label %bb48
bb47:
  %t276 = getelementptr %"compiler/diagmsg:Msg", ptr %l137, i32 0, i32 4
  %t277 = load { i64, ptr }, ptr %t276
  %t278 = extractvalue { i64, ptr } %t277, 1
  call void @__olang_region_release(ptr %t278)
  store { i64, ptr } zeroinitializer, ptr %t276
  br label %bb48
bb48:
  %t279 = load i1, ptr %l14, !tbaa !21
  br i1 %t279, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/cond:Eval", ptr %t281, i32 0, i32 4
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb51, label %bb52
bb50:
  br label %bb67
bb51:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb53
bb52:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/cond:Eval", ptr %t286, i32 0, i32 10
  %t289 = load i64, ptr %t288, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  store i1 %t291, ptr %l145, !tbaa !21
  br label %bb53
bb53:
  %t293 = load i1, ptr %l145, !tbaa !21
  br i1 %t293, label %bb54, label %bb55
bb54:
  %t294 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t294, ptr %l149
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t295 = load %"compiler/cond:Value", ptr %l149
  store %"compiler/cond:Value" %t295, ptr %rv
  br label %ret
bb57:
  %t296 = getelementptr %"compiler/diagmsg:Msg", ptr %l16, i32 0, i32 0
  %t297 = load i32, ptr %t296, !range !{i32 0, i32 949}
  %t299 = trunc i64 105 to i32
  %t300 = icmp eq i32 %t297, %t299
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l152, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t303, ptr %l153
  br i1 %t300, label %bb58, label %bb59
bb58:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load %"compiler/source:Span", ptr %l1
  %t310 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s7, ptr %t306, %"compiler/source:Span" %t307)
  store { i64, ptr } %t310, ptr %l158
  br label %bb60
bb59:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l1
  %t315 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s7, ptr %t311, %"compiler/source:Span" %t312)
  store { i64, ptr } %t315, ptr %l163
  br label %bb62
bb60:
  %t316 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t318 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondCycle(ptr %s7, ptr %v0, { i64, ptr } %t316)
  store %"compiler/diagmsg:Msg" %t318, ptr %l160
  br label %bb61
bb61:
  %t319 = load %"compiler/diagmsg:Msg", ptr %l160
  store %"compiler/diagmsg:Msg" %t319, ptr %l155
  br label %bb64
bb62:
  %t320 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t322 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %s7, ptr %v0, { i64, ptr } %t320)
  store %"compiler/diagmsg:Msg" %t322, ptr %l165
  br label %bb63
bb63:
  %t323 = load %"compiler/diagmsg:Msg", ptr %l165
  store %"compiler/diagmsg:Msg" %t323, ptr %l155
  br label %bb64
bb64:
  %t324 = load ptr, ptr %l152, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l153
  %t326 = load %"compiler/diagmsg:Msg", ptr %l155
  %t327 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t324, %"compiler/source:Span" %t325, %"compiler/diagmsg:Msg" %t326)
  store %"compiler/cond:Value" %t327, ptr %l166
  br label %bb65
bb65:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i1, ptr %l15, !tbaa !21
  %t332 = getelementptr %"compiler/cond:Eval", ptr %t328, i32 0, i32 5
  store i1 %t329, ptr %t332, !tbaa !21
  %t333 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t333, ptr %l169
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t334 = load %"compiler/cond:Value", ptr %l169
  store %"compiler/cond:Value" %t334, ptr %rv
  br label %ret
bb67:
  %t335 = load ptr, ptr %l2, !tbaa !29
  %t337 = getelementptr %"compiler/cond:Global", ptr %t335, i32 0, i32 5
  %t338 = load i1, ptr %t337, !tbaa !21
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb68, label %bb69
bb68:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l1
  %t346 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t342, %"compiler/source:Span" %t343)
  store %"compiler/cond:Value" %t346, ptr %l175
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t347 = load %"compiler/cond:Value", ptr %l175
  store %"compiler/cond:Value" %t347, ptr %rv
  br label %ret
bb71:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t351 = load %"compiler/cond:Value", ptr %l13
  %t356 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %t348, %"compiler/source:Span" %t349, ptr %t350, %"compiler/cond:Value" %t351)
  store %"compiler/cond:Value" %t356, ptr %l180
  br label %bb72
bb72:
  %t357 = load %"compiler/cond:Value", ptr %l180
  store %"compiler/cond:Value" %t357, ptr %l23
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/cond:Eval", ptr %t358, i32 0, i32 2
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t363 = getelementptr %"compiler/cond:Scope", ptr %t361, i32 0, i32 0
  %t364 = load i1, ptr %t363, !tbaa !21
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb73, label %bb74
bb73:
  %t368 = load ptr, ptr %l2, !tbaa !29
  %t370 = getelementptr %"compiler/cond:Global", ptr %t368, i32 0, i32 3
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t373 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t371, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t373, ptr %l188
  br label %bb75
bb74:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb76
bb75:
  %t374 = load i1, ptr %l188, !tbaa !21
  store i1 %t374, ptr %l185, !tbaa !21
  br label %bb76
bb76:
  %t375 = load i1, ptr %l185, !tbaa !21
  br i1 %t375, label %bb77, label %bb78
bb77:
  %t376 = load %"compiler/cond:Value", ptr %l23
  %t378 = call i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %t376)
  store i1 %t378, ptr %l191
  br label %bb79
bb78:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb80
bb79:
  %t379 = load i1, ptr %l191, !tbaa !21
  store i1 %t379, ptr %l189, !tbaa !21
  br label %bb80
bb80:
  %t380 = load i1, ptr %l189, !tbaa !21
  br i1 %t380, label %bb81, label %bb82
bb81:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/cond:Eval", ptr %t381, i32 0, i32 10
  %t384 = load i64, ptr %t383, !tbaa !24
  %t386 = icmp eq i64 %t384, 0
  br i1 %t386, label %bb83, label %bb84
bb82:
  br label %bb124
bb83:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/cond:Eval", ptr %t388, i32 0, i32 11
  store i1 true, ptr %t390, !tbaa !21
  br label %bb85
bb84:
  br label %bb85
bb85:
  %t391 = load i1, ptr %l3, !tbaa !21
  br i1 %t391, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  %t395 = load ptr, ptr %l2, !tbaa !29
  %t397 = getelementptr %"compiler/cond:Global", ptr %t395, i32 0, i32 0
  %t398 = load { i64, ptr }, ptr %t397, !tbaa !27
  %t402 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %t393, %"compiler/source:Span" %t394, { i64, ptr } %t398)
  store %"compiler/cond:Value" %t402, ptr %l201
  br label %bb88
bb87:
  br label %bb123
bb88:
  %t403 = load %"compiler/cond:Value", ptr %l201
  store %"compiler/cond:Value" %t403, ptr %l24
  %t404 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 0
  %t405 = load i32, ptr %t404, !range !{i32 0, i32 5}
  %t407 = trunc i64 0 to i32
  %t408 = icmp eq i32 %t405, %t407
  br i1 %t408, label %bb89, label %bb90
bb89:
  %t410 = load %"compiler/cond:Value", ptr %l24
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t410, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t412 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 0
  %t413 = load i32, ptr %t412, !range !{i32 0, i32 5}
  %t415 = trunc i64 3 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb92, label %bb93
bb92:
  %t418 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 0
  %t419 = load i32, ptr %t418, !range !{i32 0, i32 5}
  %t421 = trunc i64 2 to i32
  %t422 = icmp eq i32 %t419, %t421
  store i1 %t422, ptr %l207, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb94
bb94:
  %t424 = load i1, ptr %l207, !tbaa !21
  br i1 %t424, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s14
  %t425 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 4
  %t426 = load i64, ptr %t425, !tbaa !24
  %t428 = icmp eq i64 %t426, 0
  br i1 %t428, label %bb97, label %bb98
bb96:
  br label %bb108
bb97:
  %t430 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 1
  %t431 = load i64, ptr %t430, !tbaa !24
  %t433 = icmp sgt i64 %t431, 9007199254740992
  br i1 %t433, label %bb99, label %bb100
bb98:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb102
bb99:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb101
bb100:
  %t435 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 1
  %t436 = load i64, ptr %t435, !tbaa !24
  %t438 = icmp slt i64 %t436, -9007199254740992
  store i1 %t438, ptr %l215, !tbaa !21
  br label %bb101
bb101:
  %t440 = load i1, ptr %l215, !tbaa !21
  store i1 %t440, ptr %l212, !tbaa !21
  br label %bb102
bb102:
  %t441 = load i1, ptr %l212, !tbaa !21
  br i1 %t441, label %bb103, label %bb104
bb103:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l1
  %t446 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t442, %"compiler/source:Span" %t443)
  store %"compiler/cond:Value" %t446, ptr %l220
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t447 = load %"compiler/cond:Value", ptr %l220
  store %"compiler/cond:Value" %t447, ptr %rv
  br label %ret
bb106:
  %t448 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 1
  %t449 = load i64, ptr %t448, !tbaa !24
  %t451 = sitofp i64 %t449 to double
  %t454 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s14, i32 3, i64 0, double %t451, i64 0, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t454, ptr %l224
  br label %bb107
bb107:
  %t455 = load %"compiler/cond:Value", ptr %l224
  store %"compiler/cond:Value" %t455, ptr %l24
  call void @__olang_scope_close(ptr %s14)
  br label %bb108
bb108:
  %t456 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 0
  %t457 = load i32, ptr %t456, !range !{i32 0, i32 5}
  store i32 %t457, ptr %l225
  %t458 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 0
  %t459 = load i32, ptr %t458, !range !{i32 0, i32 5}
  store i32 %t459, ptr %l227
  %t462 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %l225, ptr %l227)
  store i1 %t462, ptr %l229
  br label %bb109
bb109:
  %t463 = load i1, ptr %l229, !tbaa !21
  %t464 = xor i1 %t463, true
  br i1 %t464, label %bb110, label %bb111
bb110:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load %"compiler/source:Span", ptr %l1
  %t470 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t466, %"compiler/source:Span" %t467)
  store %"compiler/cond:Value" %t470, ptr %l233
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t471 = load %"compiler/cond:Value", ptr %l233
  store %"compiler/cond:Value" %t471, ptr %rv
  br label %ret
bb113:
  %t472 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 0
  %t473 = load i32, ptr %t472, !range !{i32 0, i32 5}
  %t475 = trunc i64 2 to i32
  %t476 = icmp eq i32 %t473, %t475
  br i1 %t476, label %bb114, label %bb115
bb114:
  %t478 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 1
  %t479 = load i64, ptr %t478, !tbaa !24
  %t480 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 4
  %t481 = load i64, ptr %t480, !tbaa !24
  %t482 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 5
  %t483 = load i1, ptr %t482, !tbaa !21
  %t487 = call i1 @compiler_2fcond_2efits(i64 %t479, i64 %t481, i1 %t483)
  store i1 %t487, ptr %l240
  br label %bb116
bb115:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb117
bb116:
  %t488 = load i1, ptr %l240, !tbaa !21
  %t489 = xor i1 %t488, true
  store i1 %t489, ptr %l236, !tbaa !21
  br label %bb117
bb117:
  %t491 = load i1, ptr %l236, !tbaa !21
  br i1 %t491, label %bb118, label %bb119
bb118:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load %"compiler/source:Span", ptr %l1
  %t496 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t492, %"compiler/source:Span" %t493)
  store %"compiler/cond:Value" %t496, ptr %l244
  br label %bb120
bb119:
  br label %bb121
bb120:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t497 = load %"compiler/cond:Value", ptr %l244
  store %"compiler/cond:Value" %t497, ptr %rv
  br label %ret
bb121:
  %t498 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 0
  %t499 = load i32, ptr %t498, !range !{i32 0, i32 5}
  %t500 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 1
  %t501 = load i64, ptr %t500, !tbaa !24
  %t502 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 2
  %t503 = load double, ptr %t502, !tbaa !26
  %t504 = getelementptr %"compiler/cond:Value", ptr %l24, i32 0, i32 3
  %t505 = load i64, ptr %t504, !tbaa !24
  %t506 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 4
  %t507 = load i64, ptr %t506, !tbaa !24
  %t508 = getelementptr %"compiler/cond:Value", ptr %l23, i32 0, i32 5
  %t509 = load i1, ptr %t508, !tbaa !21
  %t516 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s12, i32 %t499, i64 %t501, double %t503, i64 %t505, i64 %t507, i1 %t509, i1 false)
  store %"compiler/cond:Value" %t516, ptr %l251
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t517 = load %"compiler/cond:Value", ptr %l251
  store %"compiler/cond:Value" %t517, ptr %rv
  br label %ret
bb123:
  br label %bb124
bb124:
  %t518 = load %"compiler/cond:Value", ptr %l23
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t518, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eintDeclared(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/cond:Value" %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l16 = alloca %"compiler/cond:Value"
  %l21 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store %"compiler/cond:Value" %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 2 to i32
  %t5 = icmp eq i32 %t2, %t4
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t9 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i1, ptr %l4, !tbaa !21
  %t16 = call i1 @compiler_2fcond_2efits(i64 %t10, i64 %t11, i1 %t12)
  store i1 %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t25 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store %"compiler/cond:Value" %t25, ptr %l16
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load %"compiler/cond:Value", ptr %l16
  store %"compiler/cond:Value" %t26, ptr %rv
  br label %ret
bb8:
  %t27 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i1, ptr %l4, !tbaa !21
  %t35 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 2, i64 %t28, double 0x0000000000000000, i64 0, i64 %t29, i1 %t30, i1 false)
  store %"compiler/cond:Value" %t35, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/cond:Value", ptr %l21
  store %"compiler/cond:Value" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca double
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l21 = alloca i1
  %l22 = alloca %"compiler/cond:Value"
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i32
  %l33 = alloca %"compiler/cond:Value"
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca %"compiler/cond:Value"
  %l61 = alloca %"compiler/cond:Value"
  %l64 = alloca double
  %l66 = alloca { i64, ptr }
  %l68 = alloca double
  %l69 = alloca i32
  %l72 = alloca %"compiler/cond:Value"
  %l79 = alloca %"compiler/cond:Value"
  %l82 = alloca %"compiler/cond:Value"
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca i64
  %l90 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca %"compiler/cond:Value"
  %l96 = alloca %"compiler/cond:Value"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = sext i32 %t6 to i64
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f112bf10a44ab894_cc7246c1c5f7ae68)
  unreachable
bb3:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f112bf10a44ab894_cc7246c1c5f7ae68)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t35 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f112bf10a44ab894_cc7246c1c5f7ae68)
  unreachable
bb7:
  br label %bb9
bb8:
  br label %bb12
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t40, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t42, ptr %l21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l21, !tbaa !21
  %t44 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t43)
  store %"compiler/cond:Value" %t44, ptr %l22
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load %"compiler/cond:Value", ptr %l22
  store %"compiler/cond:Value" %t45, ptr %rv
  br label %ret
bb12:
  %t46 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t48 = trunc i64 2 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb41
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l26, !tbaa !27
  %t52 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l28
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store i64 %t53, ptr %l27
  br label %bb16
bb16:
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t57, i64 %t58)
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l30
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb20, label %ok.63, !prof !99
ok.63:
  store i64 %t60, ptr %l29
  br label %bb19
bb17:
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  %t68 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store %"compiler/cond:Value" %t68, ptr %l33
  br label %bb21
bb19:
  %t69 = load i64, ptr %l29, !tbaa !65
  store i64 %t69, ptr %l25, !tbaa !65
  br label %bb22
bb20:
  br label %bb18
bb21:
  call void @__olang_scope_close(ptr %s2)
  %t70 = load %"compiler/cond:Value", ptr %l33
  store %"compiler/cond:Value" %t70, ptr %rv
  br label %ret
bb22:
  %t71 = load i64, ptr %l25, !tbaa !65
  store i64 %t71, ptr %l4, !tbaa !65
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t76 = icmp sgt i64 %t74, 2
  br i1 %t76, label %bb23, label %bb24
bb23:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t78, ptr %l38, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 0
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = icmp eq i8 %t82, 48
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l42, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 1
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = icmp ne i8 %t91, 46
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 1
  %t100 = load i8, ptr %t99, !tbaa !32
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t100)
  store i1 %t102, ptr %l48
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t103 = load i1, ptr %l48, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l45, !tbaa !21
  %t109 = xor i1 %t106, true
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t111 = load i64, ptr %l4, !tbaa !65
  %t113 = icmp ugt i64 %t111, 9223372036854775807
  store i1 %t113, ptr %l52, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t115 = load i1, ptr %l52, !tbaa !21
  br i1 %t115, label %bb36, label %bb37
bb36:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  %t120 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t116, %"compiler/source:Span" %t117)
  store %"compiler/cond:Value" %t120, ptr %l57
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  %t121 = load %"compiler/cond:Value", ptr %l57
  store %"compiler/cond:Value" %t121, ptr %rv
  br label %ret
bb39:
  %t122 = load i64, ptr %l4, !tbaa !65
  %t126 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 2, i64 %t122, double 0x0000000000000000, i64 0, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t126, ptr %l61
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  %t127 = load %"compiler/cond:Value", ptr %l61
  store %"compiler/cond:Value" %t127, ptr %rv
  br label %ret
bb41:
  %t128 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t130 = trunc i64 3 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb56
bb44:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = call { i64, ptr } @compiler_2fcond_2estripped(ptr %v0, ptr %s5, { i64, ptr } %t133)
  store { i64, ptr } %t135, ptr %l66
  br label %bb45
bb45:
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t138 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s5, { i64, ptr } %t136)
  %t139 = extractvalue { i32, double } %t138, 1
  %t140 = extractvalue { i32, double } %t138, 0
  store i32 %t140, ptr %l69
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb47, label %ok.142, !prof !99
ok.142:
  store double %t139, ptr %l68
  br label %bb46
bb46:
  %t143 = load double, ptr %l68, !tbaa !26
  store double %t143, ptr %l64, !tbaa !26
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  %t148 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t144, %"compiler/source:Span" %t145)
  store %"compiler/cond:Value" %t148, ptr %l72
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  %t149 = load %"compiler/cond:Value", ptr %l72
  store %"compiler/cond:Value" %t149, ptr %rv
  br label %ret
bb50:
  %t150 = load double, ptr %l64, !tbaa !26
  store double %t150, ptr %l6, !tbaa !26
  %t151 = load double, ptr %l6, !tbaa !26
  %t152 = load double, ptr %l6, !tbaa !26
  %t155 = fsub double %t151, %t152
  %t157 = fcmp une double %t155, 0x0000000000000000
  br i1 %t157, label %bb51, label %bb52
bb51:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t163 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t159, %"compiler/source:Span" %t160)
  store %"compiler/cond:Value" %t163, ptr %l79
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s5)
  %t164 = load %"compiler/cond:Value", ptr %l79
  store %"compiler/cond:Value" %t164, ptr %rv
  br label %ret
bb54:
  %t165 = load double, ptr %l6, !tbaa !26
  %t168 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s5, i32 3, i64 0, double %t165, i64 0, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t168, ptr %l82
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s5)
  %t169 = load %"compiler/cond:Value", ptr %l82
  store %"compiler/cond:Value" %t169, ptr %rv
  br label %ret
bb56:
  %t170 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t172 = trunc i64 5 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb65
bb59:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 4, ptr %l85
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l86, !tbaa !29
  %t176 = call ptr @__olang_scope_hold(ptr %v0)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l87, !tbaa !24
  %t178 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t178, label %bb60, label %bb61
bb60:
  %t180 = call ptr @__olang_region_make(ptr %v0)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l87, !tbaa !24
  br label %bb61
bb61:
  %t182 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t183 = load i64, ptr %l87
  %t184 = inttoptr i64 %t183 to ptr
  %t186 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %t184, { i64, ptr } %t182)
  store { i64, ptr } %t186, ptr %l90
  br label %bb62
bb62:
  %t187 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t188 = load i64, ptr %l87
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = extractvalue { i64, ptr } %t187, 0
  %t191 = extractvalue { i64, ptr } %t187, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_held_alloc(ptr %t189, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t196 = load ptr, ptr %l86, !tbaa !29
  %t198 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v0, ptr %t196, { i64, ptr } %t195)
  store i64 %t198, ptr %l92
  br label %bb63
bb63:
  %t199 = load i32, ptr %l85, !range !{i32 0, i32 5}
  %t200 = load i64, ptr %l92, !tbaa !24
  %t201 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s8, i32 %t199, i64 0, double 0x0000000000000000, i64 %t200, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t201, ptr %l93
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  %t202 = load %"compiler/cond:Value", ptr %l93
  store %"compiler/cond:Value" %t202, ptr %rv
  br label %ret
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t207 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t203, %"compiler/source:Span" %t204)
  store %"compiler/cond:Value" %t207, ptr %l96
  br label %bb69
bb69:
  %t208 = load %"compiler/cond:Value", ptr %l96
  store %"compiler/cond:Value" %t208, ptr %rv
  br label %ret
bb70:
  call void @__olang_check_failed(ptr @olang_loc_f4ea2c1e339850b2_91ab7669be26b6c6)
  unreachable
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l180 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l219 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i1
  %l230 = alloca i1
  %l231 = alloca i1
  %l234 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l241 = alloca ptr
  %l242 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l255 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t7 = load ptr, ptr %l27, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 28}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l28, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l35
  br label %bb9
bb9:
  %t26 = load i1, ptr %l35, !tbaa !21
  store i1 %t26, ptr %l26, !tbaa !21
  br label %bb178
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l36, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 28}
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb31
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t43 = load ptr, ptr %l42, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l42, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 28}
  %t49 = icmp eq i64 %t47, 24
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l3, !tbaa !29
  br label %bb31
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l48, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 28}
  %t64 = icmp eq i64 %t62, 26
  store i1 %t64, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l49, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l3, !tbaa !29
  br label %bb31
bb22:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t73 = load ptr, ptr %l54, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l54, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 28}
  %t79 = icmp eq i64 %t77, 3
  store i1 %t79, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l55, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb31
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t88 = load ptr, ptr %l60, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l60, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 28}
  %t94 = icmp eq i64 %t92, 12
  store i1 %t94, ptr %l61, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l61, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l3, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t107 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t107, ptr %l69
  br label %bb32
bb32:
  %t108 = load i1, ptr %l69, !tbaa !21
  store i1 %t108, ptr %l26, !tbaa !21
  br label %bb178
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t110 = load ptr, ptr %l70, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t113 = load ptr, ptr %l70, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 28}
  %t116 = icmp eq i64 %t114, 5
  store i1 %t116, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l71, !tbaa !21
  br i1 %t117, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l4, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t126, i32 0, i32 3
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb38
bb37:
  br label %bb44
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t135 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  store i1 %t135, ptr %l81
  br label %bb39
bb39:
  %t136 = load i1, ptr %l81, !tbaa !21
  br i1 %t136, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb43
bb41:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l5, !tbaa !29
  %t142 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t137, ptr %t138)
  store i1 %t142, ptr %l86
  br label %bb42
bb42:
  %t143 = load i1, ptr %l86, !tbaa !21
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb43
bb43:
  %t144 = load i1, ptr %l82, !tbaa !21
  store i1 %t144, ptr %l26, !tbaa !21
  br label %bb178
bb44:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t146 = load ptr, ptr %l87, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t149 = load ptr, ptr %l87, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 28}
  %t152 = icmp eq i64 %t150, 10
  store i1 %t152, ptr %l88, !tbaa !21
  br label %bb46
bb46:
  %t153 = load i1, ptr %l88, !tbaa !21
  br i1 %t153, label %bb47, label %bb48
bb47:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t156, i32 0, i32 1
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l6, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t162, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163
  store { i64, ptr } %t164, ptr %l7, !tbaa !27
  br label %bb49
bb48:
  br label %bb55
bb49:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t171 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t166, ptr %t167)
  store i1 %t171, ptr %l98
  br label %bb50
bb50:
  %t172 = load i1, ptr %l98, !tbaa !21
  br i1 %t172, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb54
bb52:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t177 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t173, { i64, ptr } %t174)
  store i1 %t177, ptr %l102
  br label %bb53
bb53:
  %t178 = load i1, ptr %l102, !tbaa !21
  store i1 %t178, ptr %l99, !tbaa !21
  br label %bb54
bb54:
  %t179 = load i1, ptr %l99, !tbaa !21
  store i1 %t179, ptr %l26, !tbaa !21
  br label %bb178
bb55:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t181 = load ptr, ptr %l103, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb56, label %bb57
bb56:
  %t184 = load ptr, ptr %l103, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 28}
  %t187 = icmp eq i64 %t185, 13
  store i1 %t187, ptr %l104, !tbaa !21
  br label %bb57
bb57:
  %t188 = load i1, ptr %l104, !tbaa !21
  br i1 %t188, label %bb58, label %bb59
bb58:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t191, i32 0, i32 1
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l8, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t197, i32 0, i32 2
  %t199 = load { i64, ptr }, ptr %t198
  store { i64, ptr } %t199, ptr %l9, !tbaa !27
  br label %bb60
bb59:
  br label %bb66
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l8, !tbaa !29
  %t206 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store i1 %t206, ptr %l114
  br label %bb61
bb61:
  %t207 = load i1, ptr %l114, !tbaa !21
  br i1 %t207, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb65
bb63:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t212 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t208, { i64, ptr } %t209)
  store i1 %t212, ptr %l118
  br label %bb64
bb64:
  %t213 = load i1, ptr %l118, !tbaa !21
  store i1 %t213, ptr %l115, !tbaa !21
  br label %bb65
bb65:
  %t214 = load i1, ptr %l115, !tbaa !21
  store i1 %t214, ptr %l26, !tbaa !21
  br label %bb178
bb66:
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t216 = load ptr, ptr %l119, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb67, label %bb68
bb67:
  %t219 = load ptr, ptr %l119, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 28}
  %t222 = icmp eq i64 %t220, 7
  store i1 %t222, ptr %l120, !tbaa !21
  br label %bb68
bb68:
  %t223 = load i1, ptr %l120, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l10, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l10, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Chain", ptr %t231, i32 0, i32 1
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  %t237 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t230, { i64, ptr } %t234)
  store i1 %t237, ptr %l128
  br label %bb72
bb72:
  %t238 = load i1, ptr %l128, !tbaa !21
  store i1 %t238, ptr %l26, !tbaa !21
  br label %bb178
bb73:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t240 = load ptr, ptr %l129, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb74, label %bb75
bb74:
  %t243 = load ptr, ptr %l129, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 28}
  %t246 = icmp eq i64 %t244, 8
  store i1 %t246, ptr %l130, !tbaa !21
  br label %bb75
bb75:
  %t247 = load i1, ptr %l130, !tbaa !21
  br i1 %t247, label %bb76, label %bb77
bb76:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t250, i32 0, i32 1
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l11, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l12, !tbaa !29
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t262, i32 0, i32 3
  %t264 = load ptr, ptr %t263
  store ptr %t264, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb88
bb78:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l11, !tbaa !29
  %t271 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t266, ptr %t267)
  store i1 %t271, ptr %l142
  br label %bb79
bb79:
  %t272 = load i1, ptr %l142, !tbaa !21
  br i1 %t272, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb83
bb81:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  %t278 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  store i1 %t278, ptr %l147
  br label %bb82
bb82:
  %t279 = load i1, ptr %l147, !tbaa !21
  store i1 %t279, ptr %l143, !tbaa !21
  br label %bb83
bb83:
  %t280 = load i1, ptr %l143, !tbaa !21
  br i1 %t280, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb87
bb85:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l13, !tbaa !29
  %t286 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t281, ptr %t282)
  store i1 %t286, ptr %l152
  br label %bb86
bb86:
  %t287 = load i1, ptr %l152, !tbaa !21
  store i1 %t287, ptr %l148, !tbaa !21
  br label %bb87
bb87:
  %t288 = load i1, ptr %l148, !tbaa !21
  store i1 %t288, ptr %l26, !tbaa !21
  br label %bb178
bb88:
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t290 = load ptr, ptr %l153, !tbaa !29
  %t291 = icmp ne ptr %t290, null
  br i1 %t291, label %bb89, label %bb90
bb89:
  %t293 = load ptr, ptr %l153, !tbaa !29
  %t294 = load i64, ptr %t293, !range !{i64 0, i64 28}
  %t296 = icmp eq i64 %t294, 4
  store i1 %t296, ptr %l154, !tbaa !21
  br label %bb90
bb90:
  %t297 = load i1, ptr %l154, !tbaa !21
  br i1 %t297, label %bb91, label %bb92
bb91:
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t300, i32 0, i32 2
  %t302 = load ptr, ptr %t301
  store ptr %t302, ptr %l14, !tbaa !29
  br label %bb105
bb92:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t305 = load ptr, ptr %l159, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb93, label %bb94
bb93:
  %t308 = load ptr, ptr %l159, !tbaa !29
  %t309 = load i64, ptr %t308, !range !{i64 0, i64 28}
  %t311 = icmp eq i64 %t309, 9
  store i1 %t311, ptr %l160, !tbaa !21
  br label %bb94
bb94:
  %t312 = load i1, ptr %l160, !tbaa !21
  br i1 %t312, label %bb95, label %bb96
bb95:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t315, i32 0, i32 1
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l14, !tbaa !29
  br label %bb105
bb96:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t320 = load ptr, ptr %l165, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb97, label %bb98
bb97:
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 28}
  %t326 = icmp eq i64 %t324, 11
  store i1 %t326, ptr %l166, !tbaa !21
  br label %bb98
bb98:
  %t327 = load i1, ptr %l166, !tbaa !21
  br i1 %t327, label %bb99, label %bb100
bb99:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [4 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t330, i32 0, i32 1
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l14, !tbaa !29
  br label %bb105
bb100:
  %t334 = load ptr, ptr %l1, !tbaa !29
  store ptr %t334, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t335 = load ptr, ptr %l171, !tbaa !29
  %t336 = icmp ne ptr %t335, null
  br i1 %t336, label %bb101, label %bb102
bb101:
  %t338 = load ptr, ptr %l171, !tbaa !29
  %t339 = load i64, ptr %t338, !range !{i64 0, i64 28}
  %t341 = icmp eq i64 %t339, 19
  store i1 %t341, ptr %l172, !tbaa !21
  br label %bb102
bb102:
  %t342 = load i1, ptr %l172, !tbaa !21
  br i1 %t342, label %bb103, label %bb104
bb103:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 1
  %t346 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t345, i32 0, i32 1
  %t347 = load ptr, ptr %t346
  store ptr %t347, ptr %l14, !tbaa !29
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l14, !tbaa !29
  %t354 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t349, ptr %t350)
  store i1 %t354, ptr %l180
  br label %bb106
bb106:
  %t355 = load i1, ptr %l180, !tbaa !21
  store i1 %t355, ptr %l26, !tbaa !21
  br label %bb178
bb107:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t357 = load ptr, ptr %l181, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb108, label %bb109
bb108:
  %t360 = load ptr, ptr %l181, !tbaa !29
  %t361 = load i64, ptr %t360, !range !{i64 0, i64 28}
  %t363 = icmp eq i64 %t361, 6
  store i1 %t363, ptr %l182, !tbaa !21
  br label %bb109
bb109:
  %t364 = load i1, ptr %l182, !tbaa !21
  br i1 %t364, label %bb110, label %bb111
bb110:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t367, i32 0, i32 1
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l15, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l16, !tbaa !29
  br label %bb112
bb111:
  br label %bb118
bb112:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %l15, !tbaa !29
  %t382 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t377, ptr %t378)
  store i1 %t382, ptr %l192
  br label %bb113
bb113:
  %t383 = load i1, ptr %l192, !tbaa !21
  br i1 %t383, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb117
bb115:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l16, !tbaa !29
  %t389 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t384, ptr %t385)
  store i1 %t389, ptr %l197
  br label %bb116
bb116:
  %t390 = load i1, ptr %l197, !tbaa !21
  store i1 %t390, ptr %l193, !tbaa !21
  br label %bb117
bb117:
  %t391 = load i1, ptr %l193, !tbaa !21
  store i1 %t391, ptr %l26, !tbaa !21
  br label %bb178
bb118:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t393 = load ptr, ptr %l198, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb119, label %bb120
bb119:
  %t396 = load ptr, ptr %l198, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 28}
  %t399 = icmp eq i64 %t397, 14
  store i1 %t399, ptr %l199, !tbaa !21
  br label %bb120
bb120:
  %t400 = load i1, ptr %l199, !tbaa !21
  br i1 %t400, label %bb121, label %bb122
bb121:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [4 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t403, i32 0, i32 1
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l17, !tbaa !29
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t409, i32 0, i32 2
  %t411 = load ptr, ptr %t410
  store ptr %t411, ptr %l18, !tbaa !29
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [4 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t415, i32 0, i32 3
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l19, !tbaa !29
  br label %bb123
bb122:
  br label %bb133
bb123:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l17, !tbaa !29
  %t424 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t419, ptr %t420)
  store i1 %t424, ptr %l211
  br label %bb124
bb124:
  %t425 = load i1, ptr %l211, !tbaa !21
  br i1 %t425, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb128
bb126:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l18, !tbaa !29
  %t430 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t426, ptr %t427)
  store i1 %t430, ptr %l215
  br label %bb127
bb127:
  %t431 = load i1, ptr %l215, !tbaa !21
  store i1 %t431, ptr %l212, !tbaa !21
  br label %bb128
bb128:
  %t432 = load i1, ptr %l212, !tbaa !21
  br i1 %t432, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb132
bb130:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l19, !tbaa !29
  %t437 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t433, ptr %t434)
  store i1 %t437, ptr %l219
  br label %bb131
bb131:
  %t438 = load i1, ptr %l219, !tbaa !21
  store i1 %t438, ptr %l216, !tbaa !21
  br label %bb132
bb132:
  %t439 = load i1, ptr %l216, !tbaa !21
  store i1 %t439, ptr %l26, !tbaa !21
  br label %bb178
bb133:
  %t440 = load ptr, ptr %l1, !tbaa !29
  store ptr %t440, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t441 = load ptr, ptr %l220, !tbaa !29
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %bb134, label %bb135
bb134:
  %t444 = load ptr, ptr %l220, !tbaa !29
  %t445 = load i64, ptr %t444, !range !{i64 0, i64 28}
  %t447 = icmp eq i64 %t445, 15
  store i1 %t447, ptr %l221, !tbaa !21
  br label %bb135
bb135:
  %t448 = load i1, ptr %l221, !tbaa !21
  br i1 %t448, label %bb136, label %bb137
bb136:
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t451 = getelementptr { i64, [4 x i64] }, ptr %t449, i32 0, i32 1
  %t452 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t451, i32 0, i32 1
  %t453 = load ptr, ptr %t452
  store ptr %t453, ptr %l20, !tbaa !29
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t457, i32 0, i32 2
  %t459 = load ptr, ptr %t458
  store ptr %t459, ptr %l21, !tbaa !29
  br label %bb138
bb137:
  br label %bb144
bb138:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l20, !tbaa !29
  %t465 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t461, ptr %t462)
  store i1 %t465, ptr %l230
  br label %bb139
bb139:
  %t466 = load i1, ptr %l230, !tbaa !21
  br i1 %t466, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l231, !tbaa !21
  br label %bb143
bb141:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load ptr, ptr %l21, !tbaa !29
  %t471 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t467, ptr %t468)
  store i1 %t471, ptr %l234
  br label %bb142
bb142:
  %t472 = load i1, ptr %l234, !tbaa !21
  store i1 %t472, ptr %l231, !tbaa !21
  br label %bb143
bb143:
  %t473 = load i1, ptr %l231, !tbaa !21
  store i1 %t473, ptr %l26, !tbaa !21
  br label %bb178
bb144:
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t475 = load ptr, ptr %l235, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb145, label %bb146
bb145:
  %t478 = load ptr, ptr %l235, !tbaa !29
  %t479 = load i64, ptr %t478, !range !{i64 0, i64 28}
  %t481 = icmp eq i64 %t479, 16
  store i1 %t481, ptr %l236, !tbaa !21
  br label %bb146
bb146:
  %t482 = load i1, ptr %l236, !tbaa !21
  br i1 %t482, label %bb147, label %bb148
bb147:
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [4 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t485, i32 0, i32 2
  %t487 = load { i64, ptr }, ptr %t486
  store { i64, ptr } %t487, ptr %l22, !tbaa !27
  br label %bb157
bb148:
  %t489 = load ptr, ptr %l1, !tbaa !29
  store ptr %t489, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t490 = load ptr, ptr %l241, !tbaa !29
  %t491 = icmp ne ptr %t490, null
  br i1 %t491, label %bb149, label %bb150
bb149:
  %t493 = load ptr, ptr %l241, !tbaa !29
  %t494 = load i64, ptr %t493, !range !{i64 0, i64 28}
  %t496 = icmp eq i64 %t494, 17
  store i1 %t496, ptr %l242, !tbaa !21
  br label %bb150
bb150:
  %t497 = load i1, ptr %l242, !tbaa !21
  br i1 %t497, label %bb151, label %bb152
bb151:
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t500 = getelementptr { i64, [4 x i64] }, ptr %t498, i32 0, i32 1
  %t501 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t500, i32 0, i32 1
  %t502 = load { i64, ptr }, ptr %t501
  store { i64, ptr } %t502, ptr %l22, !tbaa !27
  br label %bb157
bb152:
  %t504 = load ptr, ptr %l1, !tbaa !29
  store ptr %t504, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t505 = load ptr, ptr %l247, !tbaa !29
  %t506 = icmp ne ptr %t505, null
  br i1 %t506, label %bb153, label %bb154
bb153:
  %t508 = load ptr, ptr %l247, !tbaa !29
  %t509 = load i64, ptr %t508, !range !{i64 0, i64 28}
  %t511 = icmp eq i64 %t509, 27
  store i1 %t511, ptr %l248, !tbaa !21
  br label %bb154
bb154:
  %t512 = load i1, ptr %l248, !tbaa !21
  br i1 %t512, label %bb155, label %bb156
bb155:
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = getelementptr { i64, [4 x i64] }, ptr %t513, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t515, i32 0, i32 1
  %t517 = load { i64, ptr }, ptr %t516
  store { i64, ptr } %t517, ptr %l22, !tbaa !27
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t523 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t519, { i64, ptr } %t520)
  store i1 %t523, ptr %l255
  br label %bb158
bb158:
  %t524 = load i1, ptr %l255, !tbaa !21
  store i1 %t524, ptr %l26, !tbaa !21
  br label %bb178
bb159:
  %t525 = load ptr, ptr %l1, !tbaa !29
  store ptr %t525, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t526 = load ptr, ptr %l256, !tbaa !29
  %t527 = icmp ne ptr %t526, null
  br i1 %t527, label %bb160, label %bb161
bb160:
  %t529 = load ptr, ptr %l256, !tbaa !29
  %t530 = load i64, ptr %t529, !range !{i64 0, i64 28}
  %t532 = icmp eq i64 %t530, 18
  store i1 %t532, ptr %l257, !tbaa !21
  br label %bb161
bb161:
  %t533 = load i1, ptr %l257, !tbaa !21
  br i1 %t533, label %bb162, label %bb163
bb162:
  br label %bb172
bb163:
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t535 = load ptr, ptr %l260, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb164, label %bb165
bb164:
  %t538 = load ptr, ptr %l260, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 28}
  %t541 = icmp eq i64 %t539, 20
  store i1 %t541, ptr %l261, !tbaa !21
  br label %bb165
bb165:
  %t542 = load i1, ptr %l261, !tbaa !21
  br i1 %t542, label %bb166, label %bb167
bb166:
  br label %bb172
bb167:
  %t543 = load ptr, ptr %l1, !tbaa !29
  store ptr %t543, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t544 = load ptr, ptr %l264, !tbaa !29
  %t545 = icmp ne ptr %t544, null
  br i1 %t545, label %bb168, label %bb169
bb168:
  %t547 = load ptr, ptr %l264, !tbaa !29
  %t548 = load i64, ptr %t547, !range !{i64 0, i64 28}
  %t550 = icmp eq i64 %t548, 21
  store i1 %t550, ptr %l265, !tbaa !21
  br label %bb169
bb169:
  %t551 = load i1, ptr %l265, !tbaa !21
  br i1 %t551, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb178
bb173:
  br i1 true, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb177
bb176:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_b9c07b13268e7f30_2a98a88387235e7c)
  unreachable
bb178:
  %t552 = load i1, ptr %l26, !tbaa !21
  store i1 %t552, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l95 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l113 = alloca i1
  %l127 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/cond:Eval", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Eval", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 32
  br i1 %t27, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Eval", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp eq i8 %t38, 9
  store i1 %t40, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l17, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/cond:Eval", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l25, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i8, ptr %t50, i64 %t47
  %t52 = load i8, ptr %t51, !tbaa !32
  %t54 = icmp eq i8 %t52, 10
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t56 = load i1, ptr %l23, !tbaa !21
  br i1 %t56, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/cond:Eval", ptr %t57, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 40
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t70 = load i1, ptr %l29, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t71 = load i1, ptr %l11, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/cond:Eval", ptr %t82, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = icmp slt i64 %t81, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/cond:Eval", ptr %t92, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i8, ptr %t99, i64 %t96
  %t101 = load i8, ptr %t100, !tbaa !32
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t101)
  store i1 %t103, ptr %l50
  br label %bb21
bb20:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb29
bb21:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb25
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/cond:Eval", ptr %t105, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l53, !tbaa !27
  %t109 = load i64, ptr %l3, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t114)
  store i1 %t116, ptr %l56
  br label %bb24
bb24:
  %t117 = load i1, ptr %l56, !tbaa !21
  store i1 %t117, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t118 = load i1, ptr %l51, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb28
bb27:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/cond:Eval", ptr %t119, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l59, !tbaa !27
  %t123 = load i64, ptr %l3, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i8, ptr %t126, i64 %t123
  %t128 = load i8, ptr %t127, !tbaa !32
  %t130 = icmp eq i8 %t128, 95
  store i1 %t130, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t132 = load i1, ptr %l57, !tbaa !21
  store i1 %t132, ptr %l45, !tbaa !21
  br label %bb29
bb29:
  %t133 = load i1, ptr %l45, !tbaa !21
  br i1 %t133, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb49
bb32:
  %t134 = load i64, ptr %l3, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/cond:Eval", ptr %t135, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = icmp slt i64 %t134, %t140
  br i1 %t143, label %bb33, label %bb34
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/cond:Eval", ptr %t145, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t149 = load i64, ptr %l3, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i8, ptr %t152, i64 %t149
  %t154 = load i8, ptr %t153, !tbaa !32
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t154)
  store i1 %t156, ptr %l73
  br label %bb35
bb34:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb43
bb35:
  %t157 = load i1, ptr %l73, !tbaa !21
  br i1 %t157, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb39
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/cond:Eval", ptr %t158, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l76, !tbaa !27
  %t162 = load i64, ptr %l3, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i8, ptr %t165, i64 %t162
  %t167 = load i8, ptr %t166, !tbaa !32
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t167)
  store i1 %t169, ptr %l79
  br label %bb38
bb38:
  %t170 = load i1, ptr %l79, !tbaa !21
  store i1 %t170, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t171 = load i1, ptr %l74, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb42
bb41:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/cond:Eval", ptr %t172, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l82, !tbaa !27
  %t176 = load i64, ptr %l3, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i8, ptr %t179, i64 %t176
  %t181 = load i8, ptr %t180, !tbaa !32
  %t183 = icmp eq i8 %t181, 95
  store i1 %t183, ptr %l80, !tbaa !21
  br label %bb42
bb42:
  %t185 = load i1, ptr %l80, !tbaa !21
  store i1 %t185, ptr %l68, !tbaa !21
  br label %bb43
bb43:
  %t186 = load i1, ptr %l68, !tbaa !21
  %t187 = xor i1 %t186, true
  br i1 %t187, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l3, !tbaa !24
  br label %bb47
bb47:
  br label %bb32
bb48:
  br label %bb71
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t194 = load i64, ptr %l3, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/cond:Eval", ptr %t195, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t203 = icmp slt i64 %t194, %t200
  br i1 %t203, label %bb50, label %bb51
bb50:
  %t205 = load i64, ptr %l3, !tbaa !24
  %t206 = load i64, ptr %l2, !tbaa !24
  %t208 = add i64 %t206, 2
  %t211 = icmp slt i64 %t205, %t208
  store i1 %t211, ptr %l95, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb52
bb52:
  %t213 = load i1, ptr %l95, !tbaa !21
  br i1 %t213, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l101, !tbaa !27
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/cond:Eval", ptr %t214, i32 0, i32 0
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l103, !tbaa !27
  %t218 = load i64, ptr %l3, !tbaa !24
  store i64 %t218, ptr %l104, !tbaa !24
  %t219 = load i64, ptr %l3, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l106, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  store i64 %t223, ptr %l107, !tbaa !24
  %t224 = load i64, ptr %l104, !tbaa !24
  %t225 = icmp sge i64 %t224, 0
  br i1 %t225, label %bb55, label %bb56
bb54:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb62
bb55:
  %t227 = load i64, ptr %l104, !tbaa !24
  %t228 = load i64, ptr %l106, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_eb7ac349c2b76455_935b96b70fca2c61)
  unreachable
bb57:
  %t231 = load i64, ptr %l106, !tbaa !24
  %t232 = load i64, ptr %l107, !tbaa !24
  %t233 = icmp sle i64 %t231, %t232
  br i1 %t233, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_eb7ac349c2b76455_935b96b70fca2c61)
  unreachable
bb59:
  %t235 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = load i64, ptr %l104, !tbaa !24
  %t238 = load i64, ptr %l106, !tbaa !24
  %t239 = getelementptr i8, ptr %t236, i64 %t237
  %t240 = sub i64 %t238, %t237
  %t241 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  %t244 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t246 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s5, ptr %v0, { i64, ptr } %t244, { i64, ptr } %t242)
  store i1 %t246, ptr %l113
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_eb7ac349c2b76455_935b96b70fca2c61)
  unreachable
bb61:
  %t247 = load i1, ptr %l113, !tbaa !21
  store i1 %t247, ptr %l100, !tbaa !21
  br label %bb62
bb62:
  %t248 = load i1, ptr %l100, !tbaa !21
  %t249 = xor i1 %t248, true
  br i1 %t249, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t251 = load i64, ptr %l3, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb66
bb66:
  br label %bb49
bb67:
  %t256 = load i64, ptr %l3, !tbaa !24
  %t257 = load i64, ptr %l2, !tbaa !24
  %t260 = icmp eq i64 %t256, %t257
  br i1 %t260, label %bb68, label %bb69
bb68:
  %t262 = load i64, ptr %l2, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l3, !tbaa !24
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t266 = load i64, ptr %l2, !tbaa !24
  %t268 = trunc i64 %t266 to i32
  %t269 = load i64, ptr %l3, !tbaa !24
  %t271 = trunc i64 %t269 to i32
  %t274 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t268, i32 %t271)
  store %"compiler/source:Span" %t274, ptr %l127
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t275 = load %"compiler/source:Span", ptr %l127
  store %"compiler/source:Span" %t275, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca %"compiler/cond:Value"
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/cond:Value"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/diagmsg:Msg"
  %l32 = alloca %"compiler/cond:Value"
  %l35 = alloca %"compiler/cond:Value"
  %l41 = alloca %"compiler/cond:Value"
  %l44 = alloca %"compiler/cond:Value"
  %l54 = alloca %"compiler/cond:Value"
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l62 = alloca { i64, ptr }
  %l64 = alloca %"compiler/diagmsg:Msg"
  %l65 = alloca %"compiler/cond:Value"
  %l68 = alloca i1
  %l73 = alloca i1
  %l77 = alloca %"compiler/cond:Value"
  %l83 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t7 = trunc i64 48 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i32 3, ptr %l11, !tbaa !23
  br label %bb3
bb2:
  store i32 1, ptr %l11, !tbaa !23
  br label %bb3
bb3:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = add i32 %t10, %t11
  %t13 = load i32, ptr %l7, !tbaa !23
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t13, i32 %t12)
  store %"compiler/source:Span" %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t16, ptr %l4
  %t17 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t19 = trunc i64 48 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t26 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store %"compiler/cond:Value" %t26, ptr %l18
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t27 = load %"compiler/cond:Value", ptr %l18
  store %"compiler/cond:Value" %t27, ptr %l5
  %t28 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 5}
  %t31 = trunc i64 0 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load %"compiler/cond:Value", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t34, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t36 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 5}
  %t39 = trunc i64 1 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t45, ptr %l26
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l4
  %t50 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s3, ptr %t46, %"compiler/source:Span" %t47)
  store { i64, ptr } %t50, ptr %l29
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %s3, ptr %v0, { i64, ptr } %t51)
  store %"compiler/diagmsg:Msg" %t53, ptr %l31
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l26
  %t56 = load %"compiler/diagmsg:Msg", ptr %l31
  %t57 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store %"compiler/cond:Value" %t57, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load %"compiler/cond:Value", ptr %l32
  store %"compiler/cond:Value" %t58, ptr %rv
  br label %ret
bb16:
  %t59 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = icmp eq i64 %t60, 0
  %t64 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t62)
  store %"compiler/cond:Value" %t64, ptr %l35
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"compiler/cond:Value", ptr %l35
  store %"compiler/cond:Value" %t65, ptr %rv
  br label %ret
bb18:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t68 = trunc i64 69 to i32
  %t69 = icmp eq i32 %t66, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l4
  %t77 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t73, %"compiler/source:Span" %t74)
  store %"compiler/cond:Value" %t77, ptr %l41
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load %"compiler/cond:Value", ptr %l41
  store %"compiler/cond:Value" %t78, ptr %rv
  br label %ret
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t83 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store %"compiler/cond:Value" %t83, ptr %l44
  br label %bb23
bb23:
  %t84 = load %"compiler/cond:Value", ptr %l44
  store %"compiler/cond:Value" %t84, ptr %l6
  %t85 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t86 = load i32, ptr %t85, !range !{i32 0, i32 5}
  %t88 = trunc i64 0 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load %"compiler/cond:Value", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 5}
  %t96 = trunc i64 3 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t99 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 2
  %t100 = load double, ptr %t99, !tbaa !26
  %t102 = fneg double %t100
  %t103 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t104 = load i64, ptr %t103, !tbaa !24
  %t108 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s6, i32 3, i64 0, double %t102, i64 0, i64 %t104, i1 false, i1 false)
  store %"compiler/cond:Value" %t108, ptr %l54
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t109 = load %"compiler/cond:Value", ptr %l54
  store %"compiler/cond:Value" %t109, ptr %rv
  br label %ret
bb30:
  %t110 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t111 = load i32, ptr %t110, !range !{i32 0, i32 5}
  %t113 = trunc i64 2 to i32
  %t114 = icmp eq i32 %t111, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l58, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t119, ptr %l59
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l4
  %t124 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s7, ptr %t120, %"compiler/source:Span" %t121)
  store { i64, ptr } %t124, ptr %l62
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t127 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %s7, ptr %v0, { i64, ptr } %t125)
  store %"compiler/diagmsg:Msg" %t127, ptr %l64
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l58, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l59
  %t130 = load %"compiler/diagmsg:Msg", ptr %l64
  %t131 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t128, %"compiler/source:Span" %t129, %"compiler/diagmsg:Msg" %t130)
  store %"compiler/cond:Value" %t131, ptr %l65
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t132 = load %"compiler/cond:Value", ptr %l65
  store %"compiler/cond:Value" %t132, ptr %rv
  br label %ret
bb36:
  %t133 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  %t136 = icmp eq i64 %t134, -9223372036854775808
  br i1 %t136, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb40
bb38:
  %t138 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = sub i64 0, %t139
  %t142 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  %t149 = call i1 @compiler_2fcond_2efits(i64 %t141, i64 %t143, i1 %t145)
  store i1 %t149, ptr %l73
  br label %bb39
bb39:
  %t150 = load i1, ptr %l73, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t153 = load i1, ptr %l68, !tbaa !21
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l4
  %t158 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t154, %"compiler/source:Span" %t155)
  store %"compiler/cond:Value" %t158, ptr %l77
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load %"compiler/cond:Value", ptr %l77
  store %"compiler/cond:Value" %t159, ptr %rv
  br label %ret
bb44:
  %t160 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t161 = load i64, ptr %t160, !tbaa !24
  %t163 = sub i64 0, %t161
  %t164 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 5
  %t167 = load i1, ptr %t166, !tbaa !21
  %t172 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 2, i64 %t163, double 0x0000000000000000, i64 0, i64 %t165, i1 %t167, i1 false)
  store %"compiler/cond:Value" %t172, ptr %l83
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load %"compiler/cond:Value", ptr %l83
  store %"compiler/cond:Value" %t173, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2eisName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l43 = alloca i32
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  store i8 %t30, ptr %l5, !tbaa !22
  %t32 = load i8, ptr %l5, !tbaa !22
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t32)
  store i1 %t34, ptr %l23
  br label %bb8
bb8:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 95
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24, !tbaa !21
  %t43 = xor i1 %t40, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb14:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t49)
  store i1 %t51, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i1, ptr %l34, !tbaa !21
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l32, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %l2, !tbaa !24
  br label %bb4
bb23:
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t69 = call i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %t63, i64 0, i64 %t66)
  store i32 %t69, ptr %l43
  br label %bb24
bb24:
  %t70 = load i32, ptr %l43, !range !{i32 0, i32 116}
  %t72 = trunc i64 1 to i32
  %t73 = icmp eq i32 %t70, %t72
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcond_3aConsts_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"compiler/cond:Consts"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l8, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l8
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l12
  br label %bb6
bb6:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l1
  %t24 = call ptr @__olang_scope_hold(ptr %v0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l13, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e2
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = call ptr @__olang_region_make(ptr %v0)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t30 = load i64, ptr %l13
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l15
  br label %bb9
bb9:
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e2
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l13
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = call ptr @__olang_region_home(ptr %t40)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr null
  call void @__olang_region_settle_in(ptr %t36, ptr %t43)
  br label %bb11
bb11:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l2
  %t45 = call ptr @__olang_scope_hold(ptr %v0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l17, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e3
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = call ptr @__olang_region_make(ptr %v0)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t51 = load i64, ptr %l17
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t52, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l19
  br label %bb14
bb14:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e3
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l17
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t64)
  br label %bb16
bb16:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l3
  %t66 = call ptr @__olang_scope_hold(ptr %v0)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l21, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e4
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = call ptr @__olang_region_make(ptr %v0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l21, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l21
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t73, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l23
  br label %bb19
bb19:
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e4
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load i64, ptr %l21
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t85)
  br label %bb21
bb21:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l4
  %t87 = call ptr @__olang_scope_hold(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l25, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e5
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = call ptr @__olang_region_make(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l25, !tbaa !24
  br label %bb23
bb23:
  %t93 = load i64, ptr %l25
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t94, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l27
  br label %bb24
bb24:
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e5
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load i64, ptr %l25
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t99, ptr %t106)
  br label %bb26
bb26:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l5
  %t108 = call ptr @__olang_scope_hold(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l29, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e6
  br i1 %t110, label %bb27, label %bb28
bb27:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l29, !tbaa !24
  br label %bb28
bb28:
  %t114 = load i64, ptr %l29
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t115, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l31
  br label %bb29
bb29:
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e6
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t119 = load i64, ptr %l29
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr null
  call void @__olang_region_settle_in(ptr %t120, ptr %t127)
  br label %bb31
bb31:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l6
  %t129 = call ptr @__olang_scope_hold(ptr %v0)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l33, !tbaa !24
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e7
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = call ptr @__olang_region_make(ptr %v0)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l33, !tbaa !24
  br label %bb33
bb33:
  %t135 = load i64, ptr %l33
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t136, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l35
  br label %bb34
bb34:
  %t138 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e7
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t140 = load i64, ptr %l33
  %t141 = inttoptr i64 %t140 to ptr
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = call ptr @__olang_region_or(ptr %t144, ptr null)
  %t146 = call ptr @__olang_region_home(ptr %t145)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr null
  call void @__olang_region_settle_in(ptr %t141, ptr %t148)
  br label %bb36
bb36:
  %t149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t150 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 0
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %t150
  %t152 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 1
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %t152
  %t154 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 2
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %t154
  %t156 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 3
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %t156
  %t158 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 4
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %t158
  %t160 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 5
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %t160
  %t162 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 6
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %t162
  %t164 = getelementptr %"compiler/cond:Consts", ptr %l37, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %t164
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l37, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fcond_3aValue(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t1, i64 %t2)
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t3, i64 %t4)
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/cond:Value", ptr %t5, i32 0, i32 0
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fcond_3aValueKind(ptr %v0, ptr %t6, i64 %a1)
  br label %bb1
bb1:
  %t9 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/cond:Value", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t16 = call i64 @__olang_fmt_i64(ptr %t15, i64 %t13)
  call void @__olang_sb_add(ptr %v0, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/cond:Value", ptr %t19, i32 0, i32 2
  %t21 = load double, ptr %t20, !tbaa !26
  %t23 = call ptr @__olang_sb_room(ptr %v0, i64 48)
  %t24 = call i64 @__olang_fmt_float(ptr %t23, i64 48, double %t21, i32 0)
  call void @__olang_sb_add(ptr %v0, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/cond:Value", ptr %t27, i32 0, i32 3
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %t29)
  call void @__olang_sb_add(ptr %v0, i64 %t32)
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/cond:Value", ptr %t35, i32 0, i32 4
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t37)
  call void @__olang_sb_add(ptr %v0, i64 %t40)
  %t41 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/cond:Value", ptr %t43, i32 0, i32 5
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = select i1 %t45, ptr @.c17, ptr @.c18
  %t48 = select i1 %t45, i64 4, i64 5
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  %t49 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/cond:Value", ptr %t51, i32 0, i32 6
  %t53 = load i1, ptr %t52, !tbaa !21
  %t55 = select i1 %t53, ptr @.c17, ptr @.c18
  %t56 = select i1 %t53, i64 4, i64 5
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %ret
ret:
  ret void
}

@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.c17 = private unnamed_addr constant [5 x i8] c"true\00"
@.c18 = private unnamed_addr constant [6 x i8] c"false\00"
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 5}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 5}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"=!<>+-*/%" }>, align 8
@olang_2esole_2ecompiler_2fcond_3aConsts_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fcond_3aConsts_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e7 = weak hidden constant i1 false
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d28 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"cond.Value" }>, align 8
@.d29 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fcond_3aValueKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 5}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
ret:
  ret void
}

@.d30 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
declare i64 @__olang_fmt_float(ptr, i64, double, i32)
@.d31 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d32 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"cond.ValueKind.None" }>, align 8
@.d33 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"cond.ValueKind.Bool" }>, align 8
@.d34 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"cond.ValueKind.Int" }>, align 8
@.d35 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"cond.ValueKind.Float" }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"cond.ValueKind.Text" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@olang_loc_a57e25c843e3c84f_6f669dc60e0f5ddb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_2f3f750ce3a7cf22_a8bd497d0b471fc6 = external constant [0 x i8]
@olang_loc_4bc53af292f25c9f_867e818f05a97a3 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4ddddffe7822a0c2_24314aefc1643326 = external constant [0 x i8]
@olang_loc_e3c5df648a43e2bf_f2e642f3433cb83 = external constant [0 x i8]
declare { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/cond:Value" %a2, i1 %a3, i1 %a4, i1 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a0)
@olang_loc_5ac00ef93c3b70de_d182aac4a1481962 = external constant [0 x i8]
declare i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %v0, i32 %a0, i64 %a1, double %a2, i64 %a3, i64 %a4, i1 %a5, i1 %a6)
@olang_loc_b6b1b2abf04569db_4e32416677f050df = external constant [0 x i8]
declare %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcond_2estripped(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
@G_2ecompiler_2fcond_2eLiteralIntBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
declare i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %a0)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare { i32, %"compiler/cond:Value" } @compiler_2fcond_2emeet(%"compiler/cond:Value" %a0, %"compiler/cond:Value" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_a5b50ffc6e80595c_88be7d164d57caa8 = external constant [0 x i8]
declare i1 @compiler_2fcond_2efits(i64 %a0, i64 %a1, i1 %a2)
declare { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %a0)
@olang_loc_274101562a710104_e9b847c59a86b198 = external constant [0 x i8]
@olang_loc_82ba276e77283333_2c83aa9106e5aedf = external constant [0 x i8]
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2, i1 %a3)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_f112bf10a44ab894_cc7246c1c5f7ae68 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f4ea2c1e339850b2_91ab7669be26b6c6 = external constant [0 x i8]
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b9c07b13268e7f30_2a98a88387235e7c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_eb7ac349c2b76455_935b96b70fca2c61 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
