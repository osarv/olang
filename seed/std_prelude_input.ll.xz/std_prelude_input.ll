; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
%"std/prelude/place:Place" = type { { i64, ptr }, i64, i64 }
@G_2estd_2fprelude_2finput_2estdinBuffer = global %"std/prelude/input:InputBuffer" zeroinitializer
define dso_local i32 @std_2fprelude_2finput_2eI32_2eFd(i32 %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eScanln(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"std/prelude/place:Place" %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/place:Place"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l14 = alloca i32
  %l18 = alloca { i64, ptr }
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store %"std/prelude/place:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load %"std/prelude/place:Place", ptr %l1
  call void @std_2fprelude_2fprint_2ePrint_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %t7, %"std/prelude/place:Place" %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v2)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l8
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb15
bb6:
  %t17 = load i32, ptr %l9, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t22 = load i32, ptr %l9, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 0, i32 0
  %t27 = icmp eq i32 %t23, 2
  %t28 = select i1 %t27, i32 1, i32 %t26
  %t29 = icmp eq i32 %t22, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t24
  %t32 = select i1 %t29, i32 0, i32 %t31
  %t34 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t32, 0
  store { i32, { i64, ptr } } %t34, ptr %rv
  br label %ret
bb9:
  %t35 = load %"std/prelude/place:Place", ptr %l1
  %t37 = call i32 @std_2fprelude_2finput_2ereadRefused(ptr %v1, %"std/prelude/place:Place" %t35)
  store i32 %t37, ptr %l14
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb11, label %ok.39, !prof !99
ok.39:
  br label %bb10
bb10:
  br label %bb14
bb11:
  %t40 = load i32, ptr %l14, !tbaa !23
  %t41 = icmp eq i32 %t40, 65536
  br i1 %t41, label %bb12, label %bb13
bb12:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t43 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t43, i64 %t44)
  %t45 = call ptr @__olang_errpay_top_get()
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t46, i64 %t47)
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t50 = getelementptr { { i64, ptr } }, ptr %t49, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t53, i64 %t54, i8 34)
  %t56 = call ptr @__olang_sb_room(ptr %s3, i64 %t55)
  %t57 = call i64 @__olang_rd_quote(ptr %t56, i64 0, ptr %t53, i64 %t54, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t55)
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t58, i64 %t59)
  %t60 = load ptr, ptr %s3
  %t61 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t62 = load i64, ptr %t61
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call ptr @__olang_scope_alloc(ptr %t63, i64 %t62)
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t62)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l18, !tbaa !27
  %t67 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t68 = load ptr, ptr %t67
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %sbgrew.70, label %sbdone.71
sbgrew.70:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.71
sbdone.71:
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %t73, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_78089c6e05f54348_c44345d44a04efa4, { i64, ptr } %t84, i1 false)
  unreachable
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1c32c25abf9ef178_42417acd44bf71fc)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_75bb22291815a95c_1b64f601cbc646a8)
  unreachable
bb15:
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t85, 1
  store { i32, { i64, ptr } } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAll(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t17, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t20, 1
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAvailable(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @std_2fprelude_2finput_2eStdinBuffered() #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %t1, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  store i1 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i1, ptr %l1, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinBytes(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr @__olang_prog_scope
  %t5 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %t2, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer, i64 %a0)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l5
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l4
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinWord(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fprelude_2finput_2ereadRefused(ptr %v0, %"std/prelude/place:Place" %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/place:Place"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  %t14 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %"std/prelude/place:Place" %a0, ptr %l1
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fprelude_2fplace_3aPlace(ptr %s1, ptr %l1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %s1
  %t4 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t5 = load i64, ptr %t4
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t3, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t10 = load ptr, ptr %t9
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %sbgrew.12, label %sbdone.13
sbgrew.12:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.13
sbdone.13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 0
  store i64 0, ptr %t15
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t16, 0
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  store { { i64, ptr } } %t17, ptr %t18
  %t19 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t19, ptr %l4
  %t20 = call ptr @__olang_errpay_push()
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t25 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2finput_3ainput_24payload(ptr %t23, ptr %l4)
  store { i64, [2 x i64] } %t25, ptr %l7
  br label %bb2
bb2:
  %t26 = load { i64, [2 x i64] }, ptr %l7
  %t27 = load i64, ptr %l5
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_scope_alloc_a(ptr %t28, i64 24, i64 8)
  store { i64, [2 x i64] } %t26, ptr %t29
  call void @__olang_errpay_set(ptr %t29)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l16 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb3, label %ok.5, !prof !99
ok.5:
  br label %bb2
bb2:
  br label %bb7
bb3:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t11 = load i32, ptr %l3, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 0, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb6:
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/input:InputBuffer", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/prelude/input:InputBuffer", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 3
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/prelude/input:InputBuffer", ptr %t39, i32 0, i32 4
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t37, i64 %t27, i64 %t42)
  store { i64, ptr } %t46, ptr %l16
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i32
  %l40 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp eq i64 %t4, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l10
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17, !prof !99
ok.17:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t19, 2
  %t24 = select i1 %t23, i32 2, i32 %t22
  %t25 = icmp eq i32 %t18, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t20
  %t28 = select i1 %t25, i32 0, i32 %t27
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t28, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2ecompleteEnd(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l13
  br label %bb8
bb8:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/prelude/input:InputBuffer", ptr %t36, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp sgt i64 %t35, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"std/prelude/input:InputBuffer", ptr %t44, i32 0, i32 3
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = getelementptr %"std/prelude/input:InputBuffer", ptr %t49, i32 0, i32 3
  store i64 %t50, ptr %t53, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t54, i64 %t47, i64 %t56)
  store { i64, ptr } %t60, ptr %l25
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t61, 1
  store { i32, { i64, ptr } } %t62, ptr %rv
  br label %ret
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t63)
  store i32 %t65, ptr %l27
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb14, label %ok.67, !prof !99
ok.67:
  br label %bb13
bb13:
  br label %bb19
bb14:
  %t68 = load i32, ptr %l27, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 2
  br i1 %t71, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  %t73 = load i32, ptr %l27, !tbaa !23
  %t74 = lshr i32 %t73, 16
  %t75 = and i32 %t73, 65535
  %t76 = icmp eq i32 %t74, 1
  %t77 = select i1 %t76, i32 1, i32 0
  %t78 = icmp eq i32 %t74, 2
  %t79 = select i1 %t78, i32 2, i32 %t77
  %t80 = icmp eq i32 %t73, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t75
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb17:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/prelude/input:InputBuffer", ptr %t86, i32 0, i32 3
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/input:InputBuffer", ptr %t92, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t98 = getelementptr %"std/prelude/input:InputBuffer", ptr %t91, i32 0, i32 3
  store i64 %t95, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/prelude/input:InputBuffer", ptr %t101, i32 0, i32 4
  %t104 = load i64, ptr %t103, !tbaa !24
  %t108 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t99, i64 %t89, i64 %t104)
  store { i64, ptr } %t108, ptr %l40
  br label %bb18
bb18:
  %t109 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t110 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t109, 1
  store { i32, { i64, ptr } } %t110, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sgt i64 %t4, %t8
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l28 = alloca i32
  %l39 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l76 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3985a8c7e5af0b6c_4b8b5d3a34f4de30)
  unreachable
bb6:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %lp2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp slt i64 %t18, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb30
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/prelude/input:InputBuffer", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = icmp eq i64 %t32, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l28
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb13, label %ok.45, !prof !99
ok.45:
  br label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l28, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t47, 2
  %t52 = select i1 %t51, i32 2, i32 %t50
  %t53 = icmp eq i32 %t46, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t48
  %t56 = select i1 %t53, i32 0, i32 %t55
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t56, 0
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/input:InputBuffer", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"std/prelude/input:InputBuffer", ptr %t63, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = sub i64 %t62, %t66
  %t70 = load ptr, ptr %lp2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t80 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t69, i64 %t77)
  store i64 %t80, ptr %l39
  br label %bb16
bb16:
  %t81 = load i64, ptr %l39, !tbaa !24
  store i64 %t81, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  store i64 %t82, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb22
bb19:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l47, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t110 = load i64, ptr %l47, !tbaa !24
  store i64 %t110, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t111 = load i64, ptr %l44, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"std/prelude/input:InputBuffer", ptr %t136, i32 0, i32 3
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t145 = getelementptr %"std/prelude/input:InputBuffer", ptr %t135, i32 0, i32 2
  %t147 = getelementptr { i64, ptr }, ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t143
  %t150 = load i8, ptr %t149, !tbaa !32
  %t152 = load ptr, ptr %lp2
  %t154 = getelementptr { i64, ptr }, ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i8, ptr %t155, i64 %t134
  store i8 %t150, ptr %t156, !tbaa !32
  br label %bb27
bb27:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb23
bb28:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l76, !tbaa !29
  %t162 = load ptr, ptr %l76, !tbaa !29
  %t163 = getelementptr %"std/prelude/input:InputBuffer", ptr %t162, i32 0, i32 3
  %t164 = load i64, ptr %t163, !tbaa !24
  %t165 = load i64, ptr %l4, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = load ptr, ptr %l76, !tbaa !29
  %t171 = getelementptr %"std/prelude/input:InputBuffer", ptr %t170, i32 0, i32 3
  store i64 %t168, ptr %t171, !tbaa !24
  %t172 = load i64, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l4, !tbaa !24
  %t176 = add i64 %t172, %t173
  store i64 %t176, ptr %l3, !tbaa !24
  br label %bb29
bb29:
  br label %bb6
bb30:
  %t178 = load ptr, ptr %lp2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t181 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t179, 1
  store { i32, { i64, ptr } } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l122 = alloca i32
  %l123 = alloca ptr
  %l125 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l141 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca i1
  %l161 = alloca i1
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l173 = alloca i64
  %l178 = alloca { i64, ptr }
  %l185 = alloca i64
  %l188 = alloca i64
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = sub i64 %t4, %t8
  store i64 %t11, ptr %l1, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/input:InputBuffer", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb5:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l38, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l38, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t49 = load i64, ptr %l35, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"std/prelude/input:InputBuffer", ptr %t71, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = getelementptr %"std/prelude/input:InputBuffer", ptr %t70, i32 0, i32 2
  %t82 = getelementptr { i64, ptr }, ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t78
  %t85 = load i8, ptr %t84, !tbaa !32
  %t88 = getelementptr %"std/prelude/input:InputBuffer", ptr %t68, i32 0, i32 2
  %t90 = getelementptr { i64, ptr }, ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t69
  store i8 %t85, ptr %t92, !tbaa !32
  br label %bb13
bb13:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb9
bb14:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/prelude/input:InputBuffer", ptr %t97, i32 0, i32 3
  store i64 0, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t104 = getelementptr %"std/prelude/input:InputBuffer", ptr %t100, i32 0, i32 4
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"std/prelude/input:InputBuffer", ptr %t105, i32 0, i32 4
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"std/prelude/input:InputBuffer", ptr %t109, i32 0, i32 2
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp eq i64 %t108, %t114
  br i1 %t117, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/input:InputBuffer", ptr %t119, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l76, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l77, !tbaa !24
  %t125 = load i64, ptr %l77, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l78, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l77, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l79, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t142 = mul i64 %t140, 2
  store i64 %t142, ptr %l82, !tbaa !24
  %t143 = load i64, ptr %l82, !tbaa !24
  %t144 = icmp sge i64 %t143, 0
  br i1 %t144, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t146 = load i64, ptr %l82, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t153 = load ptr, ptr %l79, !tbaa !29
  %t154 = getelementptr %"std/prelude/input:InputBuffer", ptr %t153, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l87, !tbaa !27
  %t157 = load ptr, ptr %l79, !tbaa !29
  %t158 = getelementptr %"std/prelude/input:InputBuffer", ptr %t157, i32 0, i32 2
  store { i64, ptr } %t150, ptr %t158, !tbaa !27
  %t159 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t159, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9ebb7b2d76e16f9e_f5b8f0b55eb9c682)
  unreachable
bb20:
  %t161 = load { i64, ptr }, ptr %l87
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  call void @__olang_region_release_part(ptr %t163, i64 %t162)
  store { i64, ptr } zeroinitializer, ptr %l87
  br label %bb21
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"std/prelude/input:InputBuffer", ptr %t164, i32 0, i32 4
  %t167 = load i64, ptr %t166, !tbaa !24
  store i64 %t167, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t169 = load i64, ptr %l10, !tbaa !24
  %t170 = load i64, ptr %l9, !tbaa !24
  %t173 = icmp sgt i64 %t169, %t170
  br i1 %t173, label %bb22, label %bb23
bb22:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t177 = icmp sgt i64 %t175, 0
  br i1 %t177, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb27
bb24:
  %t179 = load i64, ptr %l10, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = sub i64 %t179, %t180
  %t184 = load i64, ptr %l11, !tbaa !24
  %t187 = add i64 %t183, %t184
  %t189 = sub i64 %t187, 1
  %t190 = load i64, ptr %l11, !tbaa !24
  %t193 = sdiv i64 %t189, %t190
  store i64 %t193, ptr %l97, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb26
bb26:
  %t195 = load i64, ptr %l97, !tbaa !24
  store i64 %t195, ptr %l94, !tbaa !24
  br label %bb27
bb27:
  %t196 = load i64, ptr %l94, !tbaa !24
  store i64 %t196, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l12, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t205 = load i64, ptr %l9, !tbaa !24
  %t206 = load i64, ptr %l13, !tbaa !24
  %t207 = load i64, ptr %l11, !tbaa !24
  %t210 = mul i64 %t206, %t207
  %t213 = add i64 %t205, %t210
  store i64 %t213, ptr %l14, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l14, !tbaa !24
  %t217 = load i64, ptr %l14, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i8, ptr %t220, i64 %t217
  %t222 = load i8, ptr %t221, !tbaa !32
  %t225 = getelementptr %"std/prelude/input:InputBuffer", ptr %t215, i32 0, i32 2
  %t227 = getelementptr { i64, ptr }, ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i8, ptr %t228, i64 %t216
  store i8 %t222, ptr %t229, !tbaa !32
  br label %bb32
bb32:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb28
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/input:InputBuffer", ptr %t234, i32 0, i32 0
  %t237 = load i32, ptr %t236, !tbaa !23
  store i32 %t237, ptr %l122, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l123, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"std/prelude/input:InputBuffer", ptr %t239, i32 0, i32 4
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l125, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"std/prelude/input:InputBuffer", ptr %t243, i32 0, i32 2
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  store i64 %t248, ptr %l128, !tbaa !24
  %t249 = load ptr, ptr %l123, !tbaa !29
  %t250 = getelementptr %"std/prelude/input:InputBuffer", ptr %t249, i32 0, i32 2
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l129, !tbaa !24
  %t253 = load i64, ptr %l125, !tbaa !24
  %t254 = icmp sge i64 %t253, 0
  br i1 %t254, label %bb35, label %bb36
bb35:
  %t256 = load i64, ptr %l125, !tbaa !24
  %t257 = load i64, ptr %l128, !tbaa !24
  %t258 = icmp sle i64 %t256, %t257
  br i1 %t258, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb37:
  %t260 = load i64, ptr %l128, !tbaa !24
  %t261 = load i64, ptr %l129, !tbaa !24
  %t262 = icmp sle i64 %t260, %t261
  br i1 %t262, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb39:
  %t264 = load ptr, ptr %l123, !tbaa !29
  %t265 = getelementptr %"std/prelude/input:InputBuffer", ptr %t264, i32 0, i32 2
  %t266 = getelementptr { i64, ptr }, ptr %t265, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l125, !tbaa !24
  %t269 = load i64, ptr %l128, !tbaa !24
  %t270 = getelementptr i8, ptr %t267, i64 %t268
  %t271 = sub i64 %t269, %t268
  %t272 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t270, 1
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"std/prelude/input:InputBuffer", ptr %t274, i32 0, i32 2
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"std/prelude/input:InputBuffer", ptr %t280, i32 0, i32 4
  %t283 = load i64, ptr %t282, !tbaa !24
  %t286 = sub i64 %t279, %t283
  %t288 = load i32, ptr %l122, !tbaa !23
  %t290 = extractvalue { i64, ptr } %t273, 1
  %t291 = extractvalue { i64, ptr } %t273, 0
  %t293 = call i64 @read(i32 %t288, ptr %t290, i64 %t286)
  store i64 %t293, ptr %l141
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb41:
  %t294 = load i64, ptr %l141, !tbaa !24
  store i64 %t294, ptr %l15, !tbaa !24
  %t295 = load i64, ptr %l15, !tbaa !24
  %t297 = icmp slt i64 %t295, 0
  br i1 %t297, label %bb42, label %bb43
bb42:
  store i32 65536, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t300 = load i64, ptr %l15, !tbaa !24
  %t302 = icmp eq i64 %t300, 0
  br i1 %t302, label %bb45, label %bb46
bb45:
  store i32 131072, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l148, !tbaa !29
  %t306 = load ptr, ptr %l148, !tbaa !29
  %t307 = getelementptr %"std/prelude/input:InputBuffer", ptr %t306, i32 0, i32 4
  %t308 = load i64, ptr %t307, !tbaa !24
  %t309 = load i64, ptr %l15, !tbaa !24
  %t312 = add i64 %t308, %t309
  %t314 = load ptr, ptr %l148, !tbaa !29
  %t315 = getelementptr %"std/prelude/input:InputBuffer", ptr %t314, i32 0, i32 4
  store i64 %t312, ptr %t315, !tbaa !24
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"std/prelude/input:InputBuffer", ptr %t316, i32 0, i32 1
  %t319 = load i1, ptr %t318, !tbaa !21
  br i1 %t319, label %bb48, label %bb49
bb48:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"std/prelude/input:InputBuffer", ptr %t321, i32 0, i32 4
  %t324 = load i64, ptr %t323, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"std/prelude/input:InputBuffer", ptr %t325, i32 0, i32 2
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t333 = icmp eq i64 %t324, %t330
  store i1 %t333, ptr %l154, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb50
bb50:
  %t335 = load i1, ptr %l154, !tbaa !21
  br i1 %t335, label %bb51, label %bb52
bb51:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"std/prelude/input:InputBuffer", ptr %t336, i32 0, i32 2
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t343 = icmp slt i64 %t341, 65536
  store i1 %t343, ptr %l161, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb53
bb53:
  %t345 = load i1, ptr %l161, !tbaa !21
  br i1 %t345, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"std/prelude/input:InputBuffer", ptr %t346, i32 0, i32 2
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !27
  store { i64, ptr } %t349, ptr %l167, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  store i64 %t351, ptr %l168, !tbaa !24
  %t352 = load i64, ptr %l168, !tbaa !24
  %t353 = mul i64 %t352, 1
  %t354 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l169, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = load i64, ptr %l168, !tbaa !24
  %t362 = mul i64 %t361, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t358, ptr %t360, i64 %t362, i1 false)
  %t363 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t363, ptr %l16, !tbaa !27
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l170, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t369 = mul i64 %t367, 2
  store i64 %t369, ptr %l173, !tbaa !24
  %t370 = load i64, ptr %l173, !tbaa !24
  %t371 = icmp sge i64 %t370, 0
  br i1 %t371, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t373 = load i64, ptr %l173, !tbaa !24
  %t374 = mul i64 %t373, 1
  %t375 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t374)
  %t376 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  %t380 = load ptr, ptr %l170, !tbaa !29
  %t381 = getelementptr %"std/prelude/input:InputBuffer", ptr %t380, i32 0, i32 2
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l178, !tbaa !27
  %t384 = load ptr, ptr %l170, !tbaa !29
  %t385 = getelementptr %"std/prelude/input:InputBuffer", ptr %t384, i32 0, i32 2
  store { i64, ptr } %t377, ptr %t385, !tbaa !27
  %t386 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t386, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_c67b2ccd325ea30_72929b4d00680694)
  unreachable
bb58:
  %t388 = load { i64, ptr }, ptr %l178
  %t389 = extractvalue { i64, ptr } %t388, 0
  %t390 = extractvalue { i64, ptr } %t388, 1
  call void @__olang_region_release_part(ptr %t390, i64 %t389)
  store { i64, ptr } zeroinitializer, ptr %l178
  br label %bb59
bb59:
  store i64 0, ptr %l17, !tbaa !24
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"std/prelude/input:InputBuffer", ptr %t391, i32 0, i32 4
  %t394 = load i64, ptr %t393, !tbaa !24
  store i64 %t394, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t396 = load i64, ptr %l18, !tbaa !24
  %t397 = load i64, ptr %l17, !tbaa !24
  %t400 = icmp sgt i64 %t396, %t397
  br i1 %t400, label %bb60, label %bb61
bb60:
  %t402 = load i64, ptr %l19, !tbaa !24
  %t404 = icmp sgt i64 %t402, 0
  br i1 %t404, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb65
bb62:
  %t406 = load i64, ptr %l18, !tbaa !24
  %t407 = load i64, ptr %l17, !tbaa !24
  %t410 = sub i64 %t406, %t407
  %t411 = load i64, ptr %l19, !tbaa !24
  %t414 = add i64 %t410, %t411
  %t416 = sub i64 %t414, 1
  %t417 = load i64, ptr %l19, !tbaa !24
  %t420 = sdiv i64 %t416, %t417
  store i64 %t420, ptr %l188, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l188, !tbaa !24
  br label %bb64
bb64:
  %t422 = load i64, ptr %l188, !tbaa !24
  store i64 %t422, ptr %l185, !tbaa !24
  br label %bb65
bb65:
  %t423 = load i64, ptr %l185, !tbaa !24
  store i64 %t423, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb66
bb66:
  %t424 = load i64, ptr %l21, !tbaa !24
  %t425 = load i64, ptr %l20, !tbaa !24
  %t428 = icmp slt i64 %t424, %t425
  %t430 = xor i1 %t428, true
  br i1 %t430, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t432 = load i64, ptr %l17, !tbaa !24
  %t433 = load i64, ptr %l21, !tbaa !24
  %t434 = load i64, ptr %l19, !tbaa !24
  %t437 = mul i64 %t433, %t434
  %t440 = add i64 %t432, %t437
  store i64 %t440, ptr %l22, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l22, !tbaa !24
  %t444 = load i64, ptr %l22, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr i8, ptr %t447, i64 %t444
  %t449 = load i8, ptr %t448, !tbaa !32
  %t452 = getelementptr %"std/prelude/input:InputBuffer", ptr %t442, i32 0, i32 2
  %t454 = getelementptr { i64, ptr }, ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr i8, ptr %t455, i64 %t443
  store i8 %t449, ptr %t456, !tbaa !32
  br label %bb70
bb70:
  %t457 = load i64, ptr %l21, !tbaa !24
  %t459 = add i64 %t457, 1
  store i64 %t459, ptr %l21, !tbaa !24
  br label %bb66
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i1
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l74 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca i64
  %l100 = alloca i64
  %l102 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = add i64 %t4, %t5
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/input:InputBuffer", ptr %t10, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr %"std/prelude/input:InputBuffer", ptr %t61, i32 0, i32 2
  %t66 = getelementptr { i64, ptr }, ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 %t62
  %t69 = load i8, ptr %t68, !tbaa !32
  %t72 = icmp eq i8 %t69, 10
  br i1 %t72, label %bb12, label %bb13
bb12:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"std/prelude/input:InputBuffer", ptr %t74, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = add i64 %t80, 1
  %t85 = getelementptr %"std/prelude/input:InputBuffer", ptr %t79, i32 0, i32 3
  store i64 %t82, ptr %t85, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  store i64 %t87, ptr %l51, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  store i64 %t88, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb14, label %bb15
bb13:
  br label %bb21
bb14:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = sub i64 %t96, 1
  %t100 = getelementptr %"std/prelude/input:InputBuffer", ptr %t95, i32 0, i32 2
  %t102 = getelementptr { i64, ptr }, ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i8, ptr %t103, i64 %t98
  %t105 = load i8, ptr %t104, !tbaa !32
  %t108 = icmp eq i8 %t105, 13
  store i1 %t108, ptr %l56, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb16
bb16:
  %t110 = load i1, ptr %l56, !tbaa !21
  br i1 %t110, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l63, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb19
bb19:
  %t111 = load i64, ptr %l52, !tbaa !24
  %t112 = load i64, ptr %l63, !tbaa !24
  %t113 = sub i64 %t111, %t112
  %t114 = load ptr, ptr %l50, !tbaa !29
  %t115 = load i64, ptr %l51, !tbaa !24
  %t117 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t114, i64 %t115, i64 %t113)
  store { i64, ptr } %t117, ptr %l65
  br label %bb20
bb20:
  %t118 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t118, 1
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb8
bb23:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"std/prelude/input:InputBuffer", ptr %t124, i32 0, i32 4
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/prelude/input:InputBuffer", ptr %t128, i32 0, i32 3
  %t131 = load i64, ptr %t130, !tbaa !24
  %t134 = sub i64 %t127, %t131
  store i64 %t134, ptr %l1, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t136)
  store i32 %t138, ptr %l74
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb25, label %ok.140, !prof !99
ok.140:
  br label %bb24
bb24:
  br label %bb36
bb25:
  %t141 = load i32, ptr %l74, !tbaa !23
  %t142 = ashr i32 %t141, 16
  %t144 = icmp eq i32 %t142, 2
  br i1 %t144, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  %t146 = load i32, ptr %l74, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t147, 2
  %t152 = select i1 %t151, i32 2, i32 %t150
  %t153 = icmp eq i32 %t146, 0
  %t154 = shl i32 %t152, 16
  %t155 = or i32 %t154, %t148
  %t156 = select i1 %t153, i32 0, i32 %t155
  %t158 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t156, 0
  store { i32, { i64, ptr } } %t158, ptr %rv
  br label %ret
bb28:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"std/prelude/input:InputBuffer", ptr %t159, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"std/prelude/input:InputBuffer", ptr %t163, i32 0, i32 4
  %t166 = load i64, ptr %t165, !tbaa !24
  %t169 = icmp eq i64 %t162, %t166
  br i1 %t169, label %bb29, label %bb30
bb29:
  %t172 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 131072, 0
  store { i32, { i64, ptr } } %t172, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"std/prelude/input:InputBuffer", ptr %t173, i32 0, i32 3
  %t176 = load i64, ptr %t175, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"std/prelude/input:InputBuffer", ptr %t179, i32 0, i32 4
  %t182 = load i64, ptr %t181, !tbaa !24
  %t185 = getelementptr %"std/prelude/input:InputBuffer", ptr %t178, i32 0, i32 3
  store i64 %t182, ptr %t185, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l89, !tbaa !29
  store i64 %t176, ptr %l90, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"std/prelude/input:InputBuffer", ptr %t188, i32 0, i32 4
  %t191 = load i64, ptr %t190, !tbaa !24
  store i64 %t191, ptr %l92, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"std/prelude/input:InputBuffer", ptr %t193, i32 0, i32 4
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = sub i64 %t196, 1
  %t200 = getelementptr %"std/prelude/input:InputBuffer", ptr %t192, i32 0, i32 2
  %t202 = getelementptr { i64, ptr }, ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i8, ptr %t203, i64 %t198
  %t205 = load i8, ptr %t204, !tbaa !32
  %t208 = icmp eq i8 %t205, 13
  br i1 %t208, label %bb32, label %bb33
bb32:
  store i64 1, ptr %l100, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb34
bb34:
  %t210 = load i64, ptr %l92, !tbaa !24
  %t211 = load i64, ptr %l100, !tbaa !24
  %t212 = sub i64 %t210, %t211
  %t213 = load ptr, ptr %l89, !tbaa !29
  %t214 = load i64, ptr %l90, !tbaa !24
  %t216 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t213, i64 %t214, i64 %t212)
  store { i64, ptr } %t216, ptr %l102
  br label %bb35
bb35:
  %t217 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t218 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t217, 1
  store { i32, { i64, ptr } } %t218, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load i64, ptr %l12, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t14, ptr %lp3
  %t16 = load ptr, ptr %lp3
  store { i64, ptr } %t13, ptr %t16, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9ba75df5616cc8b4_d0585f7fc85a1438)
  unreachable
bb3:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb8
bb5:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l24, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l24, !tbaa !24
  store i64 %t49, ptr %l21, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l21, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l1, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = getelementptr %"std/prelude/input:InputBuffer", ptr %a0, i32 0, i32 2
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t75
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = load ptr, ptr %lp3
  %t86 = getelementptr { i64, ptr }, ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t69
  store i8 %t82, ptr %t88, !tbaa !32
  br label %bb13
bb13:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb9
bb14:
  %t93 = load ptr, ptr %lp3
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l32 = alloca i32
  %l43 = alloca i64
  %l46 = alloca i64
  %l68 = alloca i1
  %l77 = alloca { i64, ptr }
  %l86 = alloca i32
  %l99 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/prelude/input:InputBuffer", ptr %t14, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = getelementptr %"std/prelude/input:InputBuffer", ptr %t13, i32 0, i32 2
  %t21 = getelementptr { i64, ptr }, ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  %t24 = load i8, ptr %t23, !tbaa !32
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %t24)
  store i1 %t27, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t28 = load i1, ptr %l21, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l15, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l23, !tbaa !29
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"std/prelude/input:InputBuffer", ptr %t33, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = add i64 %t35, 1
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = getelementptr %"std/prelude/input:InputBuffer", ptr %t39, i32 0, i32 3
  store i64 %t37, ptr %t40, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/prelude/input:InputBuffer", ptr %t41, i32 0, i32 3
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"std/prelude/input:InputBuffer", ptr %t45, i32 0, i32 4
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = icmp slt i64 %t44, %t48
  br i1 %t51, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l32
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57, !prof !99
ok.57:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t58 = load i32, ptr %l32, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t59, 2
  %t64 = select i1 %t63, i32 2, i32 %t62
  %t65 = icmp eq i32 %t58, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t60
  %t68 = select i1 %t65, i32 0, i32 %t67
  %t70 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t68, 0
  store { i32, { i64, ptr } } %t70, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb1
bb19:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"std/prelude/input:InputBuffer", ptr %t71, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = add i64 %t74, %t75
  store i64 %t78, ptr %l2, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"std/prelude/input:InputBuffer", ptr %t80, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb26
bb23:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l4, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l46, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb25
bb25:
  %t111 = load i64, ptr %l46, !tbaa !24
  store i64 %t111, ptr %l43, !tbaa !24
  br label %bb26
bb26:
  %t112 = load i64, ptr %l43, !tbaa !24
  store i64 %t112, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb27
bb27:
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb28, label %bb29
bb28:
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t121 = load i64, ptr %l2, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l4, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l7, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = getelementptr %"std/prelude/input:InputBuffer", ptr %t131, i32 0, i32 2
  %t136 = getelementptr { i64, ptr }, ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t132
  %t139 = load i8, ptr %t138, !tbaa !32
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %t139)
  store i1 %t142, ptr %l68
  br label %bb31
bb31:
  %t143 = load i1, ptr %l68, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"std/prelude/input:InputBuffer", ptr %t146, i32 0, i32 3
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = getelementptr %"std/prelude/input:InputBuffer", ptr %t151, i32 0, i32 3
  store i64 %t152, ptr %t155, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l7, !tbaa !24
  %t162 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t156, i64 %t149, i64 %t158)
  store { i64, ptr } %t162, ptr %l77
  br label %bb35
bb35:
  %t163 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t164 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t163, 1
  store { i32, { i64, ptr } } %t164, ptr %rv
  br label %ret
bb36:
  %t165 = load i64, ptr %l6, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l6, !tbaa !24
  br label %bb27
bb37:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"std/prelude/input:InputBuffer", ptr %t169, i32 0, i32 4
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"std/prelude/input:InputBuffer", ptr %t173, i32 0, i32 3
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = sub i64 %t172, %t176
  store i64 %t179, ptr %l1, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t181)
  store i32 %t183, ptr %l86
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb39, label %ok.185, !prof !99
ok.185:
  br label %bb38
bb38:
  br label %bb44
bb39:
  %t186 = load i32, ptr %l86, !tbaa !23
  %t187 = ashr i32 %t186, 16
  %t189 = icmp eq i32 %t187, 2
  br i1 %t189, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  %t191 = load i32, ptr %l86, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 1, i32 0
  %t196 = icmp eq i32 %t192, 2
  %t197 = select i1 %t196, i32 2, i32 %t195
  %t198 = icmp eq i32 %t191, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t193
  %t201 = select i1 %t198, i32 0, i32 %t200
  %t203 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t201, 0
  store { i32, { i64, ptr } } %t203, ptr %rv
  br label %ret
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"std/prelude/input:InputBuffer", ptr %t204, i32 0, i32 3
  %t207 = load i64, ptr %t206, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"std/prelude/input:InputBuffer", ptr %t210, i32 0, i32 4
  %t213 = load i64, ptr %t212, !tbaa !24
  %t216 = getelementptr %"std/prelude/input:InputBuffer", ptr %t209, i32 0, i32 3
  store i64 %t213, ptr %t216, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"std/prelude/input:InputBuffer", ptr %t219, i32 0, i32 4
  %t222 = load i64, ptr %t221, !tbaa !24
  %t226 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t217, i64 %t207, i64 %t222)
  store { i64, ptr } %t226, ptr %l99
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t228 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t227, 1
  store { i32, { i64, ptr } } %t228, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb20
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2ecompleteEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l17 = alloca i1
  %l46 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/prelude/input:InputBuffer", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp sgt i64 %t8, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/input:InputBuffer", ptr %t17, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t26 = icmp slt i64 %t24, 4
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 2
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t30
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = zext i8 %t37 to i64
  %t41 = and i64 %t39, 192
  %t43 = icmp eq i64 %t41, 128
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l17, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = sub i64 %t48, 1
  store i64 %t50, ptr %l1, !tbaa !24
  br label %bb11
bb11:
  br label %bb1
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = getelementptr %"std/prelude/input:InputBuffer", ptr %t52, i32 0, i32 2
  %t57 = getelementptr { i64, ptr }, ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t53
  %t60 = load i8, ptr %t59, !tbaa !32
  %t62 = zext i8 %t60 to i64
  store i64 %t62, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  %t66 = and i64 %t64, 224
  %t68 = icmp eq i64 %t66, 192
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t70 = load i64, ptr %l2, !tbaa !24
  %t72 = and i64 %t70, 240
  %t74 = icmp eq i64 %t72, 224
  br i1 %t74, label %bb16, label %bb17
bb16:
  store i64 3, ptr %l3, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = and i64 %t76, 248
  %t80 = icmp eq i64 %t78, 240
  br i1 %t80, label %bb19, label %bb20
bb19:
  store i64 4, ptr %l3, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/input:InputBuffer", ptr %t82, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = sub i64 %t85, %t86
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l1, !tbaa !24
  store i64 %t95, ptr %l46, !tbaa !24
  br label %bb24
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"std/prelude/input:InputBuffer", ptr %t97, i32 0, i32 4
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l46, !tbaa !24
  br label %bb24
bb24:
  %t102 = load i64, ptr %l46, !tbaa !24
  store i64 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2finput_2estdinBuffer_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/input:InputBuffer"
  %l1 = alloca %"std/prelude/input:InputBuffer"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t1, i32 0, i64 4096, i1 true)
  store %"std/prelude/input:InputBuffer" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/input:InputBuffer", ptr @G_2estd_2fprelude_2finput_2estdinBuffer
  store %"std/prelude/input:InputBuffer" %t3, ptr %l1
  %t4 = load %"std/prelude/input:InputBuffer", ptr %l0
  store %"std/prelude/input:InputBuffer" %t4, ptr @G_2estd_2fprelude_2finput_2estdinBuffer
  %t5 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %l1, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  call void @__olang_region_release_part(ptr %t10, i64 %t9)
  store { i64, ptr } zeroinitializer, ptr %t7
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %v0, i32 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i1
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/input:InputBuffer"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l3, !tbaa !23
  store i1 %a2, ptr %l4, !tbaa !21
  %t5 = ptrtoint ptr %v0 to i64
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call ptr @__olang_region_make_part(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 1, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = load i64, ptr %l10
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %t22, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t26, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_762cd1d3020b924b_608d4506c1a78147)
  unreachable
bb8:
  %t28 = load i64, ptr %l10
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = load { i64, ptr }, ptr %l17
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = call ptr @__olang_region_or(ptr %t31, ptr null)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr null
  %t35 = icmp eq ptr %t34, %t29
  call void @__olang_region_settle(ptr %t29, i1 %t35)
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t37 = load i32, ptr %l3, !tbaa !23
  %t38 = insertvalue %"std/prelude/input:InputBuffer" undef, i32 %t37, 0
  %t39 = load i1, ptr %l4, !tbaa !21
  %t40 = insertvalue %"std/prelude/input:InputBuffer" %t38, i1 %t39, 1
  %t42 = insertvalue %"std/prelude/input:InputBuffer" %t40, { i64, ptr } %t36, 2
  %t44 = insertvalue %"std/prelude/input:InputBuffer" %t42, i64 0, 3
  %t46 = insertvalue %"std/prelude/input:InputBuffer" %t44, i64 0, 4
  store %"std/prelude/input:InputBuffer" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/input:InputBuffer", ptr %rv
  ret %"std/prelude/input:InputBuffer" %rr
}

@.d0 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"input.Refused" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
declare ptr @__olang_errpay_top_get()
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_text(ptr, { i64, ptr }, i1) cold noreturn
declare void @__olang_bang_failed_plain(ptr) cold noreturn
declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fprelude_2fplace_3aPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/place:Place", ptr %a0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr @__olang_prog_scope
  %t5 = call { i64, ptr } @std_2fprelude_2fplace_2estd_2fprelude_2fplace_3aPlace_2eStr(ptr %t3, ptr %s1, %"std/prelude/place:Place" %t2)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2finput_3ainput_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 1}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
declare i64 @read(i32, ptr, i64)
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @std_2fprelude_2fprint_2ePrint_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, %"std/prelude/place:Place" %a1)
@olang_loc_78089c6e05f54348_c44345d44a04efa4 = external constant [0 x i8]
@olang_loc_1c32c25abf9ef178_42417acd44bf71fc = external constant [0 x i8]
@olang_loc_75bb22291815a95c_1b64f601cbc646a8 = external constant [0 x i8]
@olang_loc_3985a8c7e5af0b6c_4b8b5d3a34f4de30 = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9ebb7b2d76e16f9e_f5b8f0b55eb9c682 = external constant [0 x i8]
@olang_loc_92977f40bcde603b_fc91076acd0d7977 = external constant [0 x i8]
@olang_loc_c67b2ccd325ea30_72929b4d00680694 = external constant [0 x i8]
@olang_loc_9ba75df5616cc8b4_d0585f7fc85a1438 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %a0)
@olang_loc_762cd1d3020b924b_608d4506c1a78147 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fplace_2estd_2fprelude_2fplace_3aPlace_2eStr(ptr %v0, ptr %v1, %"std/prelude/place:Place" %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
