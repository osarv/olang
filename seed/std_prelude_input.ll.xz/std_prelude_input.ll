; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
@G_2estd_2fprelude_2finput_2estdinBuffer = global %"std/prelude/input:InputBuffer" zeroinitializer
define dso_local i32 @std_2fprelude_2finput_2eI32_2eFd(i32 %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAll(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t17, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t20, 1
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAvailable(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @std_2fprelude_2finput_2eStdinBuffered() #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %t1, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  store i1 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i1, ptr %l1, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinBytes(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr @__olang_prog_scope
  %t5 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %t2, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer, i64 %a0)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l5
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l4
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinWord(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t3 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %t1, ptr %v0, ptr @G_2estd_2fprelude_2finput_2estdinBuffer)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l3
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l2
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAll(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l16 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb3, label %ok.5, !prof !99
ok.5:
  br label %bb2
bb2:
  br label %bb7
bb3:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t11 = load i32, ptr %l3, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 0, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb6:
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/input:InputBuffer", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/prelude/input:InputBuffer", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 3
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/prelude/input:InputBuffer", ptr %t39, i32 0, i32 4
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t37, i64 %t27, i64 %t42)
  store { i64, ptr } %t46, ptr %l16
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i32
  %l40 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp eq i64 %t4, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l10
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17, !prof !99
ok.17:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t19, 2
  %t24 = select i1 %t23, i32 2, i32 %t22
  %t25 = icmp eq i32 %t18, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t20
  %t28 = select i1 %t25, i32 0, i32 %t27
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t28, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2ecompleteEnd(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l13
  br label %bb8
bb8:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/prelude/input:InputBuffer", ptr %t36, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp sgt i64 %t35, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"std/prelude/input:InputBuffer", ptr %t44, i32 0, i32 3
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = getelementptr %"std/prelude/input:InputBuffer", ptr %t49, i32 0, i32 3
  store i64 %t50, ptr %t53, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t54, i64 %t47, i64 %t56)
  store { i64, ptr } %t60, ptr %l25
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t61, 1
  store { i32, { i64, ptr } } %t62, ptr %rv
  br label %ret
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t63)
  store i32 %t65, ptr %l27
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb14, label %ok.67, !prof !99
ok.67:
  br label %bb13
bb13:
  br label %bb19
bb14:
  %t68 = load i32, ptr %l27, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 2
  br i1 %t71, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  %t73 = load i32, ptr %l27, !tbaa !23
  %t74 = lshr i32 %t73, 16
  %t75 = and i32 %t73, 65535
  %t76 = icmp eq i32 %t74, 1
  %t77 = select i1 %t76, i32 1, i32 0
  %t78 = icmp eq i32 %t74, 2
  %t79 = select i1 %t78, i32 2, i32 %t77
  %t80 = icmp eq i32 %t73, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t75
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb17:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/prelude/input:InputBuffer", ptr %t86, i32 0, i32 3
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/input:InputBuffer", ptr %t92, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t98 = getelementptr %"std/prelude/input:InputBuffer", ptr %t91, i32 0, i32 3
  store i64 %t95, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/prelude/input:InputBuffer", ptr %t101, i32 0, i32 4
  %t104 = load i64, ptr %t103, !tbaa !24
  %t108 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t99, i64 %t89, i64 %t104)
  store { i64, ptr } %t108, ptr %l40
  br label %bb18
bb18:
  %t109 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t110 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t109, 1
  store { i32, { i64, ptr } } %t110, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBuffered(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sgt i64 %t4, %t8
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i1
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load i64, ptr %l12, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t14, ptr %lp3
  %t16 = load ptr, ptr %lp3
  store { i64, ptr } %t13, ptr %t16, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9ba75df5616cc8b4_d0585f7fc85a1438)
  unreachable
bb3:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb8
bb5:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l24, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l24, !tbaa !24
  store i64 %t49, ptr %l21, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l21, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = sub i64 %t51, 1
  store i64 %t52, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t53, 2147483648
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  %t59 = and i1 %t54, %t56
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb9
bb9:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l1, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = getelementptr %"std/prelude/input:InputBuffer", ptr %a0, i32 0, i32 2
  %t88 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = load ptr, ptr %lp3
  %t95 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 %t78
  store i8 %t91, ptr %t97, !tbaa !32
  br label %bb13
bb13:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t98, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb9
bb14:
  %t103 = load ptr, ptr %lp3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2ecompleteEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l17 = alloca i1
  %l47 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/prelude/input:InputBuffer", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp sgt i64 %t8, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/input:InputBuffer", ptr %t17, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t26 = icmp slt i64 %t24, 4
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 2
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t30
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = zext i8 %t37 to i64
  %t41 = and i64 %t39, 192
  %t43 = icmp eq i64 %t41, 128
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l17, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t51 = sub i64 %t48, 1
  store i64 %t51, ptr %l1, !tbaa !24
  br label %bb11
bb11:
  br label %bb1
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = getelementptr %"std/prelude/input:InputBuffer", ptr %t53, i32 0, i32 2
  %t58 = getelementptr { i64, ptr }, ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = zext i8 %t61 to i64
  store i64 %t63, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = and i64 %t65, 224
  %t69 = icmp eq i64 %t67, 192
  br i1 %t69, label %bb13, label %bb14
bb13:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t73 = and i64 %t71, 240
  %t75 = icmp eq i64 %t73, 224
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i64 3, ptr %l3, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = and i64 %t77, 248
  %t81 = icmp eq i64 %t79, 240
  br i1 %t81, label %bb19, label %bb20
bb19:
  store i64 4, ptr %l3, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"std/prelude/input:InputBuffer", ptr %t83, i32 0, i32 4
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i64, ptr %l1, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t96 = load i64, ptr %l1, !tbaa !24
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb24
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"std/prelude/input:InputBuffer", ptr %t98, i32 0, i32 4
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l47, !tbaa !24
  br label %bb24
bb24:
  %t103 = load i64, ptr %l47, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2finput_2estdinBuffer_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/input:InputBuffer"
  %l1 = alloca %"std/prelude/input:InputBuffer"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %t1, i32 0, i64 4096, i1 true)
  store %"std/prelude/input:InputBuffer" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/input:InputBuffer", ptr @G_2estd_2fprelude_2finput_2estdinBuffer
  store %"std/prelude/input:InputBuffer" %t3, ptr %l1
  %t4 = load %"std/prelude/input:InputBuffer", ptr %l0
  store %"std/prelude/input:InputBuffer" %t4, ptr @G_2estd_2fprelude_2finput_2estdinBuffer
  %t5 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %l1, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  call void @__olang_region_release_part(ptr %t10, i64 %t9)
  store { i64, ptr } zeroinitializer, ptr %t7
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/input:InputBuffer" @std_2fprelude_2finput_3aInputBuffer_2ector(ptr %v0, i32 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i1
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/input:InputBuffer"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l3, !tbaa !23
  store i1 %a2, ptr %l4, !tbaa !21
  %t5 = call ptr @__olang_scope_hold(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make_part(ptr %v0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 1, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = mul i64 %t20, 1
  %t22 = load i64, ptr %l10
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %t23, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l17, !tbaa !27
  %t27 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t27, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_762cd1d3020b924b_608d4506c1a78147)
  unreachable
bb8:
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t32 = icmp eq i64 %t30, 0
  br i1 %t32, label %bb10, label %bb11
bb9:
  %t34 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = insertvalue %"std/prelude/input:InputBuffer" undef, i32 %t35, 0
  %t37 = load i1, ptr %l4, !tbaa !21
  %t38 = insertvalue %"std/prelude/input:InputBuffer" %t36, i1 %t37, 1
  %t40 = insertvalue %"std/prelude/input:InputBuffer" %t38, { i64, ptr } %t34, 2
  %t42 = insertvalue %"std/prelude/input:InputBuffer" %t40, i64 0, 3
  %t44 = insertvalue %"std/prelude/input:InputBuffer" %t42, i64 0, 4
  store %"std/prelude/input:InputBuffer" %t44, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } zeroinitializer, ptr %l17, !tbaa !27
  br label %bb11
bb11:
  %t46 = load i64, ptr %l10
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = load { i64, ptr }, ptr %l17
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = call ptr @__olang_region_or(ptr %t49, ptr null)
  %t51 = icmp ne ptr %t50, null
  %t52 = select i1 %t51, ptr %t50, ptr null
  call void @__olang_region_settle_in(ptr %t47, ptr %t52)
  br label %bb9
ret:
  %rr = load %"std/prelude/input:InputBuffer", ptr %rv
  ret %"std/prelude/input:InputBuffer" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
@olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %a0)
@olang_loc_9ba75df5616cc8b4_d0585f7fc85a1438 = external constant [0 x i8]
@olang_loc_762cd1d3020b924b_608d4506c1a78147 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
