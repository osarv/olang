; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l116 = alloca i1
  %l117 = alloca i1
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i1
  %l124 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l139 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l147 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca ptr
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca i1
  %l161 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca ptr
  %l165 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i64
  %l168 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/source:Span"
  %l171 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l9
  store i1 false, ptr %l10
  %t2 = load ptr, ptr %l9
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l11
  %t4 = load i1, ptr %l11
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l12
  %t7 = load i64, ptr %l12
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l13
  %t11 = load ptr, ptr %l13
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l14
  %t15 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l15
  store i1 false, ptr %l16
  %t17 = load ptr, ptr %l15
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l17
  %t19 = load i1, ptr %l17
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l18
  %t22 = load i64, ptr %l18
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l16
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l19
  %t26 = load ptr, ptr %l19
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l20
  %t30 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l21
  store i1 false, ptr %l22
  %t32 = load ptr, ptr %l21
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l23
  %t34 = load i1, ptr %l23
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l21
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l24
  %t37 = load i64, ptr %l24
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l25
  %t41 = load ptr, ptr %l25
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l26
  %t45 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l27
  store i1 false, ptr %l28
  %t47 = load ptr, ptr %l27
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l29
  %t49 = load i1, ptr %l29
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l27
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l30
  %t52 = load i64, ptr %l30
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l28
  br label %bb14
bb14:
  %t54 = load i1, ptr %l28
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l31
  %t56 = load ptr, ptr %l31
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l32
  %t60 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0
  store ptr %t61, ptr %l33
  store i1 false, ptr %l34
  %t62 = load ptr, ptr %l33
  %t63 = icmp ne ptr %t62, null
  store i1 %t63, ptr %l35
  %t64 = load i1, ptr %l35
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l33
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l36
  %t67 = load i64, ptr %l36
  %t68 = icmp eq i64 %t67, 4
  store i1 %t68, ptr %l34
  br label %bb18
bb18:
  %t69 = load i1, ptr %l34
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0
  store ptr %t70, ptr %l37
  %t71 = load ptr, ptr %l37
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l38
  %t75 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t75, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l39
  %t77 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t77, ptr %l8
  call void @__olang_scope_close(ptr %s1)
  br label %bb123
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l40
  store i1 false, ptr %l41
  %t79 = load ptr, ptr %l40
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l42
  %t81 = load i1, ptr %l42
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l40
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l43
  %t84 = load i64, ptr %l43
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l41
  br label %bb24
bb24:
  %t86 = load i1, ptr %l41
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l44
  %t88 = load ptr, ptr %l44
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l45
  %t92 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l46
  store i1 false, ptr %l47
  %t94 = load ptr, ptr %l46
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l48
  %t96 = load i1, ptr %l48
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l46
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l49
  %t99 = load i64, ptr %l49
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l47
  br label %bb28
bb28:
  %t101 = load i1, ptr %l47
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l50
  %t103 = load ptr, ptr %l50
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l51
  %t107 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t107, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l52
  store i1 false, ptr %l53
  %t109 = load ptr, ptr %l52
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l54
  %t111 = load i1, ptr %l54
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l52
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l55
  %t114 = load i64, ptr %l55
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l53
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l56
  %t118 = load ptr, ptr %l56
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l57
  %t122 = load %"compiler/source:Span", ptr %l57
  store %"compiler/source:Span" %t122, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0
  store ptr %t123, ptr %l58
  store i1 false, ptr %l59
  %t124 = load ptr, ptr %l58
  %t125 = icmp ne ptr %t124, null
  store i1 %t125, ptr %l60
  %t126 = load i1, ptr %l60
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l58
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l61
  %t129 = load i64, ptr %l61
  %t130 = icmp eq i64 %t129, 8
  store i1 %t130, ptr %l59
  br label %bb36
bb36:
  %t131 = load i1, ptr %l59
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0
  store ptr %t132, ptr %l62
  %t133 = load ptr, ptr %l62
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l63
  %t137 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t137, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s2
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l64
  %t139 = load %"compiler/source:Span", ptr %l64
  store %"compiler/source:Span" %t139, ptr %l8
  call void @__olang_scope_close(ptr %s2)
  br label %bb123
bb40:
  %t140 = load ptr, ptr %l0
  store ptr %t140, ptr %l65
  store i1 false, ptr %l66
  %t141 = load ptr, ptr %l65
  %t142 = icmp ne ptr %t141, null
  store i1 %t142, ptr %l67
  %t143 = load i1, ptr %l67
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l65
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l68
  %t146 = load i64, ptr %l68
  %t147 = icmp eq i64 %t146, 9
  store i1 %t147, ptr %l66
  br label %bb42
bb42:
  %t148 = load i1, ptr %l66
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0
  store ptr %t149, ptr %l69
  %t150 = load ptr, ptr %l69
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l70
  %t154 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t154, ptr %l3
  br label %bb57
bb44:
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l71
  store i1 false, ptr %l72
  %t156 = load ptr, ptr %l71
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l73
  %t158 = load i1, ptr %l73
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l71
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l74
  %t161 = load i64, ptr %l74
  %t162 = icmp eq i64 %t161, 10
  store i1 %t162, ptr %l72
  br label %bb46
bb46:
  %t163 = load i1, ptr %l72
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l75
  %t165 = load ptr, ptr %l75
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l76
  %t169 = load %"compiler/source:Span", ptr %l76
  store %"compiler/source:Span" %t169, ptr %l3
  br label %bb57
bb48:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l77
  store i1 false, ptr %l78
  %t171 = load ptr, ptr %l77
  %t172 = icmp ne ptr %t171, null
  store i1 %t172, ptr %l79
  %t173 = load i1, ptr %l79
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l77
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l80
  %t176 = load i64, ptr %l80
  %t177 = icmp eq i64 %t176, 11
  store i1 %t177, ptr %l78
  br label %bb50
bb50:
  %t178 = load i1, ptr %l78
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0
  store ptr %t179, ptr %l81
  %t180 = load ptr, ptr %l81
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l82
  %t184 = load %"compiler/source:Span", ptr %l82
  store %"compiler/source:Span" %t184, ptr %l3
  br label %bb57
bb52:
  %t185 = load ptr, ptr %l0
  store ptr %t185, ptr %l83
  store i1 false, ptr %l84
  %t186 = load ptr, ptr %l83
  %t187 = icmp ne ptr %t186, null
  store i1 %t187, ptr %l85
  %t188 = load i1, ptr %l85
  br i1 %t188, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l83
  %t190 = load i64, ptr %t189
  store i64 %t190, ptr %l86
  %t191 = load i64, ptr %l86
  %t192 = icmp eq i64 %t191, 12
  store i1 %t192, ptr %l84
  br label %bb54
bb54:
  %t193 = load i1, ptr %l84
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0
  store ptr %t194, ptr %l87
  %t195 = load ptr, ptr %l87
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l88
  %t199 = load %"compiler/source:Span", ptr %l88
  store %"compiler/source:Span" %t199, ptr %l3
  br label %bb57
bb56:
  br label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s3
  %t200 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t200, ptr %l89
  %t201 = load %"compiler/source:Span", ptr %l89
  store %"compiler/source:Span" %t201, ptr %l8
  call void @__olang_scope_close(ptr %s3)
  br label %bb123
bb58:
  %t202 = load ptr, ptr %l0
  store ptr %t202, ptr %l90
  store i1 false, ptr %l91
  %t203 = load ptr, ptr %l90
  %t204 = icmp ne ptr %t203, null
  store i1 %t204, ptr %l92
  %t205 = load i1, ptr %l92
  br i1 %t205, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l90
  %t207 = load i64, ptr %t206
  store i64 %t207, ptr %l93
  %t208 = load i64, ptr %l93
  %t209 = icmp eq i64 %t208, 13
  store i1 %t209, ptr %l91
  br label %bb60
bb60:
  %t210 = load i1, ptr %l91
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0
  store ptr %t211, ptr %l94
  %t212 = load ptr, ptr %l94
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l95
  %t216 = load %"compiler/source:Span", ptr %l95
  store %"compiler/source:Span" %t216, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0
  store ptr %t217, ptr %l96
  store i1 false, ptr %l97
  %t218 = load ptr, ptr %l96
  %t219 = icmp ne ptr %t218, null
  store i1 %t219, ptr %l98
  %t220 = load i1, ptr %l98
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l96
  %t222 = load i64, ptr %t221
  store i64 %t222, ptr %l99
  %t223 = load i64, ptr %l99
  %t224 = icmp eq i64 %t223, 14
  store i1 %t224, ptr %l97
  br label %bb64
bb64:
  %t225 = load i1, ptr %l97
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l100
  %t227 = load ptr, ptr %l100
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l101
  %t231 = load %"compiler/source:Span", ptr %l101
  store %"compiler/source:Span" %t231, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0
  store ptr %t232, ptr %l102
  store i1 false, ptr %l103
  %t233 = load ptr, ptr %l102
  %t234 = icmp ne ptr %t233, null
  store i1 %t234, ptr %l104
  %t235 = load i1, ptr %l104
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l102
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l105
  %t238 = load i64, ptr %l105
  %t239 = icmp eq i64 %t238, 15
  store i1 %t239, ptr %l103
  br label %bb68
bb68:
  %t240 = load i1, ptr %l103
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0
  store ptr %t241, ptr %l106
  %t242 = load ptr, ptr %l106
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l107
  %t246 = load %"compiler/source:Span", ptr %l107
  store %"compiler/source:Span" %t246, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0
  store ptr %t247, ptr %l108
  store i1 false, ptr %l109
  %t248 = load ptr, ptr %l108
  %t249 = icmp ne ptr %t248, null
  store i1 %t249, ptr %l110
  %t250 = load i1, ptr %l110
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l108
  %t252 = load i64, ptr %t251
  store i64 %t252, ptr %l111
  %t253 = load i64, ptr %l111
  %t254 = icmp eq i64 %t253, 16
  store i1 %t254, ptr %l109
  br label %bb72
bb72:
  %t255 = load i1, ptr %l109
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0
  store ptr %t256, ptr %l112
  %t257 = load ptr, ptr %l112
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l113
  %t261 = load %"compiler/source:Span", ptr %l113
  store %"compiler/source:Span" %t261, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s4
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l114
  %t263 = load %"compiler/source:Span", ptr %l114
  store %"compiler/source:Span" %t263, ptr %l8
  call void @__olang_scope_close(ptr %s4)
  br label %bb123
bb76:
  %t264 = load ptr, ptr %l0
  store ptr %t264, ptr %l115
  store i1 false, ptr %l116
  %t265 = load ptr, ptr %l115
  %t266 = icmp ne ptr %t265, null
  store i1 %t266, ptr %l117
  %t267 = load i1, ptr %l117
  br i1 %t267, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l115
  %t269 = load i64, ptr %t268
  store i64 %t269, ptr %l118
  %t270 = load i64, ptr %l118
  %t271 = icmp eq i64 %t270, 17
  store i1 %t271, ptr %l116
  br label %bb78
bb78:
  %t272 = load i1, ptr %l116
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0
  store ptr %t273, ptr %l119
  %t274 = load ptr, ptr %l119
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l120
  %t278 = load %"compiler/source:Span", ptr %l120
  store %"compiler/source:Span" %t278, ptr %l5
  br label %bb93
bb80:
  %t279 = load ptr, ptr %l0
  store ptr %t279, ptr %l121
  store i1 false, ptr %l122
  %t280 = load ptr, ptr %l121
  %t281 = icmp ne ptr %t280, null
  store i1 %t281, ptr %l123
  %t282 = load i1, ptr %l123
  br i1 %t282, label %bb81, label %bb82
bb81:
  %t283 = load ptr, ptr %l121
  %t284 = load i64, ptr %t283
  store i64 %t284, ptr %l124
  %t285 = load i64, ptr %l124
  %t286 = icmp eq i64 %t285, 18
  store i1 %t286, ptr %l122
  br label %bb82
bb82:
  %t287 = load i1, ptr %l122
  br i1 %t287, label %bb83, label %bb84
bb83:
  %t288 = load ptr, ptr %l0
  store ptr %t288, ptr %l125
  %t289 = load ptr, ptr %l125
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t290, i32 0, i32 0
  %t292 = load %"compiler/source:Span", ptr %t291
  store %"compiler/source:Span" %t292, ptr %l126
  %t293 = load %"compiler/source:Span", ptr %l126
  store %"compiler/source:Span" %t293, ptr %l5
  br label %bb93
bb84:
  %t294 = load ptr, ptr %l0
  store ptr %t294, ptr %l127
  store i1 false, ptr %l128
  %t295 = load ptr, ptr %l127
  %t296 = icmp ne ptr %t295, null
  store i1 %t296, ptr %l129
  %t297 = load i1, ptr %l129
  br i1 %t297, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l127
  %t299 = load i64, ptr %t298
  store i64 %t299, ptr %l130
  %t300 = load i64, ptr %l130
  %t301 = icmp eq i64 %t300, 19
  store i1 %t301, ptr %l128
  br label %bb86
bb86:
  %t302 = load i1, ptr %l128
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0
  store ptr %t303, ptr %l131
  %t304 = load ptr, ptr %l131
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l132
  %t308 = load %"compiler/source:Span", ptr %l132
  store %"compiler/source:Span" %t308, ptr %l5
  br label %bb93
bb88:
  %t309 = load ptr, ptr %l0
  store ptr %t309, ptr %l133
  store i1 false, ptr %l134
  %t310 = load ptr, ptr %l133
  %t311 = icmp ne ptr %t310, null
  store i1 %t311, ptr %l135
  %t312 = load i1, ptr %l135
  br i1 %t312, label %bb89, label %bb90
bb89:
  %t313 = load ptr, ptr %l133
  %t314 = load i64, ptr %t313
  store i64 %t314, ptr %l136
  %t315 = load i64, ptr %l136
  %t316 = icmp eq i64 %t315, 20
  store i1 %t316, ptr %l134
  br label %bb90
bb90:
  %t317 = load i1, ptr %l134
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t318 = load ptr, ptr %l0
  store ptr %t318, ptr %l137
  %t319 = load ptr, ptr %l137
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 0
  %t322 = load %"compiler/source:Span", ptr %t321
  store %"compiler/source:Span" %t322, ptr %l138
  %t323 = load %"compiler/source:Span", ptr %l138
  store %"compiler/source:Span" %t323, ptr %l5
  br label %bb93
bb92:
  br label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s5
  %t324 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t324, ptr %l139
  %t325 = load %"compiler/source:Span", ptr %l139
  store %"compiler/source:Span" %t325, ptr %l8
  call void @__olang_scope_close(ptr %s5)
  br label %bb123
bb94:
  %t326 = load ptr, ptr %l0
  store ptr %t326, ptr %l140
  store i1 false, ptr %l141
  %t327 = load ptr, ptr %l140
  %t328 = icmp ne ptr %t327, null
  store i1 %t328, ptr %l142
  %t329 = load i1, ptr %l142
  br i1 %t329, label %bb95, label %bb96
bb95:
  %t330 = load ptr, ptr %l140
  %t331 = load i64, ptr %t330
  store i64 %t331, ptr %l143
  %t332 = load i64, ptr %l143
  %t333 = icmp eq i64 %t332, 21
  store i1 %t333, ptr %l141
  br label %bb96
bb96:
  %t334 = load i1, ptr %l141
  br i1 %t334, label %bb97, label %bb98
bb97:
  %t335 = load ptr, ptr %l0
  store ptr %t335, ptr %l144
  %t336 = load ptr, ptr %l144
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t337, i32 0, i32 0
  %t339 = load %"compiler/source:Span", ptr %t338
  store %"compiler/source:Span" %t339, ptr %l145
  %t340 = load %"compiler/source:Span", ptr %l145
  store %"compiler/source:Span" %t340, ptr %l6
  br label %bb115
bb98:
  %t341 = load ptr, ptr %l0
  store ptr %t341, ptr %l146
  store i1 false, ptr %l147
  %t342 = load ptr, ptr %l146
  %t343 = icmp ne ptr %t342, null
  store i1 %t343, ptr %l148
  %t344 = load i1, ptr %l148
  br i1 %t344, label %bb99, label %bb100
bb99:
  %t345 = load ptr, ptr %l146
  %t346 = load i64, ptr %t345
  store i64 %t346, ptr %l149
  %t347 = load i64, ptr %l149
  %t348 = icmp eq i64 %t347, 22
  store i1 %t348, ptr %l147
  br label %bb100
bb100:
  %t349 = load i1, ptr %l147
  br i1 %t349, label %bb101, label %bb102
bb101:
  %t350 = load ptr, ptr %l0
  store ptr %t350, ptr %l150
  %t351 = load ptr, ptr %l150
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t351, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t352, i32 0, i32 0
  %t354 = load %"compiler/source:Span", ptr %t353
  store %"compiler/source:Span" %t354, ptr %l151
  %t355 = load %"compiler/source:Span", ptr %l151
  store %"compiler/source:Span" %t355, ptr %l6
  br label %bb115
bb102:
  %t356 = load ptr, ptr %l0
  store ptr %t356, ptr %l152
  store i1 false, ptr %l153
  %t357 = load ptr, ptr %l152
  %t358 = icmp ne ptr %t357, null
  store i1 %t358, ptr %l154
  %t359 = load i1, ptr %l154
  br i1 %t359, label %bb103, label %bb104
bb103:
  %t360 = load ptr, ptr %l152
  %t361 = load i64, ptr %t360
  store i64 %t361, ptr %l155
  %t362 = load i64, ptr %l155
  %t363 = icmp eq i64 %t362, 23
  store i1 %t363, ptr %l153
  br label %bb104
bb104:
  %t364 = load i1, ptr %l153
  br i1 %t364, label %bb105, label %bb106
bb105:
  %t365 = load ptr, ptr %l0
  store ptr %t365, ptr %l156
  %t366 = load ptr, ptr %l156
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr }, ptr %t367, i32 0, i32 0
  %t369 = load %"compiler/source:Span", ptr %t368
  store %"compiler/source:Span" %t369, ptr %l157
  %t370 = load %"compiler/source:Span", ptr %l157
  store %"compiler/source:Span" %t370, ptr %l6
  br label %bb115
bb106:
  %t371 = load ptr, ptr %l0
  store ptr %t371, ptr %l158
  store i1 false, ptr %l159
  %t372 = load ptr, ptr %l158
  %t373 = icmp ne ptr %t372, null
  store i1 %t373, ptr %l160
  %t374 = load i1, ptr %l160
  br i1 %t374, label %bb107, label %bb108
bb107:
  %t375 = load ptr, ptr %l158
  %t376 = load i64, ptr %t375
  store i64 %t376, ptr %l161
  %t377 = load i64, ptr %l161
  %t378 = icmp eq i64 %t377, 24
  store i1 %t378, ptr %l159
  br label %bb108
bb108:
  %t379 = load i1, ptr %l159
  br i1 %t379, label %bb109, label %bb110
bb109:
  %t380 = load ptr, ptr %l0
  store ptr %t380, ptr %l162
  %t381 = load ptr, ptr %l162
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t381, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", ptr }, ptr %t382, i32 0, i32 0
  %t384 = load %"compiler/source:Span", ptr %t383
  store %"compiler/source:Span" %t384, ptr %l163
  %t385 = load %"compiler/source:Span", ptr %l163
  store %"compiler/source:Span" %t385, ptr %l6
  br label %bb115
bb110:
  %t386 = load ptr, ptr %l0
  store ptr %t386, ptr %l164
  store i1 false, ptr %l165
  %t387 = load ptr, ptr %l164
  %t388 = icmp ne ptr %t387, null
  store i1 %t388, ptr %l166
  %t389 = load i1, ptr %l166
  br i1 %t389, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l164
  %t391 = load i64, ptr %t390
  store i64 %t391, ptr %l167
  %t392 = load i64, ptr %l167
  %t393 = icmp eq i64 %t392, 25
  store i1 %t393, ptr %l165
  br label %bb112
bb112:
  %t394 = load i1, ptr %l165
  br i1 %t394, label %bb113, label %bb114
bb113:
  %t395 = load ptr, ptr %l0
  store ptr %t395, ptr %l168
  %t396 = load ptr, ptr %l168
  %t397 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t397, i32 0, i32 0
  %t399 = load %"compiler/source:Span", ptr %t398
  store %"compiler/source:Span" %t399, ptr %l169
  %t400 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t400, ptr %l6
  br label %bb115
bb114:
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s6
  %t401 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t401, ptr %l170
  %t402 = load %"compiler/source:Span", ptr %l170
  store %"compiler/source:Span" %t402, ptr %l8
  call void @__olang_scope_close(ptr %s6)
  br label %bb123
bb116:
  %t403 = load ptr, ptr %l0
  store ptr %t403, ptr %l171
  store i1 false, ptr %l172
  %t404 = load ptr, ptr %l171
  %t405 = icmp ne ptr %t404, null
  store i1 %t405, ptr %l173
  %t406 = load i1, ptr %l173
  br i1 %t406, label %bb117, label %bb118
bb117:
  %t407 = load ptr, ptr %l171
  %t408 = load i64, ptr %t407
  store i64 %t408, ptr %l174
  %t409 = load i64, ptr %l174
  %t410 = icmp eq i64 %t409, 26
  store i1 %t410, ptr %l172
  br label %bb118
bb118:
  %t411 = load i1, ptr %l172
  br i1 %t411, label %bb119, label %bb120
bb119:
  %t412 = load ptr, ptr %l0
  store ptr %t412, ptr %l175
  %t413 = load ptr, ptr %l175
  %t414 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span" }, ptr %t414, i32 0, i32 0
  %t416 = load %"compiler/source:Span", ptr %t415
  store %"compiler/source:Span" %t416, ptr %l176
  %t417 = load %"compiler/source:Span", ptr %l176
  store %"compiler/source:Span" %t417, ptr %l7
  br label %bb121
bb120:
  br label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s7
  %t418 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t418, ptr %l177
  %t419 = load %"compiler/source:Span", ptr %l177
  store %"compiler/source:Span" %t419, ptr %l8
  call void @__olang_scope_close(ptr %s7)
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb123:
  call void @__olang_scope_close(ptr %s0)
  %t420 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t420, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  store i1 false, ptr %l5
  %t2 = load ptr, ptr %l4
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l6
  %t4 = load i1, ptr %l6
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l7
  %t7 = load i64, ptr %l7
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l8
  %t11 = load ptr, ptr %l8
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l9
  %t15 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l10
  store i1 false, ptr %l11
  %t17 = load ptr, ptr %l10
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l12
  %t19 = load i1, ptr %l12
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l13
  %t22 = load i64, ptr %l13
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l11
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l14
  %t26 = load ptr, ptr %l14
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l15
  %t30 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l16
  store i1 false, ptr %l17
  %t32 = load ptr, ptr %l16
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l18
  %t34 = load i1, ptr %l18
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l19
  %t37 = load i64, ptr %l19
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l17
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l20
  %t41 = load ptr, ptr %l20
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l21
  %t45 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l22
  store i1 false, ptr %l23
  %t47 = load ptr, ptr %l22
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l24
  %t49 = load i1, ptr %l24
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l25
  %t52 = load i64, ptr %l25
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l23
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l26
  %t56 = load ptr, ptr %l26
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l27
  %t60 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l28
  %t62 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t62, ptr %l3
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l29
  store i1 false, ptr %l30
  %t64 = load ptr, ptr %l29
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l31
  %t66 = load i1, ptr %l31
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l32
  %t69 = load i64, ptr %l32
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l30
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l33
  %t73 = load ptr, ptr %l33
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l34
  %t77 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t77, ptr %l2
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l35
  %t79 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t79, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca ptr
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca ptr
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  store i1 false, ptr %l8
  %t2 = load ptr, ptr %l7
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l9
  %t4 = load i1, ptr %l9
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l10
  %t7 = load i64, ptr %l10
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l11
  %t11 = load ptr, ptr %l11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l12
  %t15 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l13
  store i1 false, ptr %l14
  %t17 = load ptr, ptr %l13
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l15
  %t19 = load i1, ptr %l15
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l16
  %t22 = load i64, ptr %l16
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l17
  %t26 = load ptr, ptr %l17
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l18
  %t30 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l19
  store i1 false, ptr %l20
  %t32 = load ptr, ptr %l19
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l21
  %t34 = load i1, ptr %l21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l22
  %t37 = load i64, ptr %l22
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l23
  %t41 = load ptr, ptr %l23
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l24
  %t45 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l25
  store i1 false, ptr %l26
  %t47 = load ptr, ptr %l25
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l27
  %t49 = load i1, ptr %l27
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l28
  %t52 = load i64, ptr %l28
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l26
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l29
  %t56 = load ptr, ptr %l29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l30
  %t60 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l31
  %t62 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t62, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  br label %bb91
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l32
  store i1 false, ptr %l33
  %t64 = load ptr, ptr %l32
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l34
  %t66 = load i1, ptr %l34
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l35
  %t69 = load i64, ptr %l35
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l33
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l36
  %t73 = load ptr, ptr %l36
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l37
  %t77 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t77, ptr %l2
  br label %bb39
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l38
  store i1 false, ptr %l39
  %t79 = load ptr, ptr %l38
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l40
  %t81 = load i1, ptr %l40
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l41
  %t84 = load i64, ptr %l41
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l39
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l42
  %t88 = load ptr, ptr %l42
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l43
  %t92 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l44
  store i1 false, ptr %l45
  %t94 = load ptr, ptr %l44
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l46
  %t96 = load i1, ptr %l46
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l47
  %t99 = load i64, ptr %l47
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l45
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l48
  %t103 = load ptr, ptr %l48
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l49
  %t107 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t107, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l50
  store i1 false, ptr %l51
  %t109 = load ptr, ptr %l50
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l52
  %t111 = load i1, ptr %l52
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l53
  %t114 = load i64, ptr %l53
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l51
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l54
  %t118 = load ptr, ptr %l54
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l55
  %t122 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t122, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0
  store ptr %t123, ptr %l56
  store i1 false, ptr %l57
  %t124 = load ptr, ptr %l56
  %t125 = icmp ne ptr %t124, null
  store i1 %t125, ptr %l58
  %t126 = load i1, ptr %l58
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l56
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l59
  %t129 = load i64, ptr %l59
  %t130 = icmp eq i64 %t129, 8
  store i1 %t130, ptr %l57
  br label %bb36
bb36:
  %t131 = load i1, ptr %l57
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0
  store ptr %t132, ptr %l60
  %t133 = load ptr, ptr %l60
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l61
  %t137 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t137, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s2
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l62
  %t139 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t139, ptr %l6
  call void @__olang_scope_close(ptr %s2)
  br label %bb91
bb40:
  %t140 = load ptr, ptr %l0
  store ptr %t140, ptr %l63
  store i1 false, ptr %l64
  %t141 = load ptr, ptr %l63
  %t142 = icmp ne ptr %t141, null
  store i1 %t142, ptr %l65
  %t143 = load i1, ptr %l65
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l66
  %t146 = load i64, ptr %l66
  %t147 = icmp eq i64 %t146, 9
  store i1 %t147, ptr %l64
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0
  store ptr %t149, ptr %l67
  %t150 = load ptr, ptr %l67
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l68
  %t154 = load %"compiler/source:Span", ptr %l68
  store %"compiler/source:Span" %t154, ptr %l3
  br label %bb61
bb44:
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l69
  store i1 false, ptr %l70
  %t156 = load ptr, ptr %l69
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l71
  %t158 = load i1, ptr %l71
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l72
  %t161 = load i64, ptr %l72
  %t162 = icmp eq i64 %t161, 10
  store i1 %t162, ptr %l70
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l73
  %t165 = load ptr, ptr %l73
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l74
  %t169 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t169, ptr %l3
  br label %bb61
bb48:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l75
  store i1 false, ptr %l76
  %t171 = load ptr, ptr %l75
  %t172 = icmp ne ptr %t171, null
  store i1 %t172, ptr %l77
  %t173 = load i1, ptr %l77
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l78
  %t176 = load i64, ptr %l78
  %t177 = icmp eq i64 %t176, 11
  store i1 %t177, ptr %l76
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0
  store ptr %t179, ptr %l79
  %t180 = load ptr, ptr %l79
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l80
  %t184 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t184, ptr %l3
  br label %bb61
bb52:
  %t185 = load ptr, ptr %l0
  store ptr %t185, ptr %l81
  store i1 false, ptr %l82
  %t186 = load ptr, ptr %l81
  %t187 = icmp ne ptr %t186, null
  store i1 %t187, ptr %l83
  %t188 = load i1, ptr %l83
  br i1 %t188, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l81
  %t190 = load i64, ptr %t189
  store i64 %t190, ptr %l84
  %t191 = load i64, ptr %l84
  %t192 = icmp eq i64 %t191, 12
  store i1 %t192, ptr %l82
  br label %bb54
bb54:
  %t193 = load i1, ptr %l82
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0
  store ptr %t194, ptr %l85
  %t195 = load ptr, ptr %l85
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l86
  %t199 = load %"compiler/source:Span", ptr %l86
  store %"compiler/source:Span" %t199, ptr %l3
  br label %bb61
bb56:
  %t200 = load ptr, ptr %l0
  store ptr %t200, ptr %l87
  store i1 false, ptr %l88
  %t201 = load ptr, ptr %l87
  %t202 = icmp ne ptr %t201, null
  store i1 %t202, ptr %l89
  %t203 = load i1, ptr %l89
  br i1 %t203, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l87
  %t205 = load i64, ptr %t204
  store i64 %t205, ptr %l90
  %t206 = load i64, ptr %l90
  %t207 = icmp eq i64 %t206, 13
  store i1 %t207, ptr %l88
  br label %bb58
bb58:
  %t208 = load i1, ptr %l88
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0
  store ptr %t209, ptr %l91
  %t210 = load ptr, ptr %l91
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32 }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l92
  %t214 = load %"compiler/source:Span", ptr %l92
  store %"compiler/source:Span" %t214, ptr %l3
  br label %bb61
bb60:
  br label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s3
  %t215 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t215, ptr %l93
  %t216 = load %"compiler/source:Span", ptr %l93
  store %"compiler/source:Span" %t216, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb91
bb62:
  %t217 = load ptr, ptr %l0
  store ptr %t217, ptr %l94
  store i1 false, ptr %l95
  %t218 = load ptr, ptr %l94
  %t219 = icmp ne ptr %t218, null
  store i1 %t219, ptr %l96
  %t220 = load i1, ptr %l96
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94
  %t222 = load i64, ptr %t221
  store i64 %t222, ptr %l97
  %t223 = load i64, ptr %l97
  %t224 = icmp eq i64 %t223, 14
  store i1 %t224, ptr %l95
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l98
  %t227 = load ptr, ptr %l98
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l99
  %t231 = load %"compiler/source:Span", ptr %l99
  store %"compiler/source:Span" %t231, ptr %l4
  br label %bb83
bb66:
  %t232 = load ptr, ptr %l0
  store ptr %t232, ptr %l100
  store i1 false, ptr %l101
  %t233 = load ptr, ptr %l100
  %t234 = icmp ne ptr %t233, null
  store i1 %t234, ptr %l102
  %t235 = load i1, ptr %l102
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l103
  %t238 = load i64, ptr %l103
  %t239 = icmp eq i64 %t238, 15
  store i1 %t239, ptr %l101
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0
  store ptr %t241, ptr %l104
  %t242 = load ptr, ptr %l104
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l105
  %t246 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t246, ptr %l4
  br label %bb83
bb70:
  %t247 = load ptr, ptr %l0
  store ptr %t247, ptr %l106
  store i1 false, ptr %l107
  %t248 = load ptr, ptr %l106
  %t249 = icmp ne ptr %t248, null
  store i1 %t249, ptr %l108
  %t250 = load i1, ptr %l108
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106
  %t252 = load i64, ptr %t251
  store i64 %t252, ptr %l109
  %t253 = load i64, ptr %l109
  %t254 = icmp eq i64 %t253, 16
  store i1 %t254, ptr %l107
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0
  store ptr %t256, ptr %l110
  %t257 = load ptr, ptr %l110
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l111
  %t261 = load %"compiler/source:Span", ptr %l111
  store %"compiler/source:Span" %t261, ptr %l4
  br label %bb83
bb74:
  %t262 = load ptr, ptr %l0
  store ptr %t262, ptr %l112
  store i1 false, ptr %l113
  %t263 = load ptr, ptr %l112
  %t264 = icmp ne ptr %t263, null
  store i1 %t264, ptr %l114
  %t265 = load i1, ptr %l114
  br i1 %t265, label %bb75, label %bb76
bb75:
  %t266 = load ptr, ptr %l112
  %t267 = load i64, ptr %t266
  store i64 %t267, ptr %l115
  %t268 = load i64, ptr %l115
  %t269 = icmp eq i64 %t268, 17
  store i1 %t269, ptr %l113
  br label %bb76
bb76:
  %t270 = load i1, ptr %l113
  br i1 %t270, label %bb77, label %bb78
bb77:
  %t271 = load ptr, ptr %l0
  store ptr %t271, ptr %l116
  %t272 = load ptr, ptr %l116
  %t273 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 0
  %t275 = load %"compiler/source:Span", ptr %t274
  store %"compiler/source:Span" %t275, ptr %l117
  %t276 = load %"compiler/source:Span", ptr %l117
  store %"compiler/source:Span" %t276, ptr %l4
  br label %bb83
bb78:
  %t277 = load ptr, ptr %l0
  store ptr %t277, ptr %l118
  store i1 false, ptr %l119
  %t278 = load ptr, ptr %l118
  %t279 = icmp ne ptr %t278, null
  store i1 %t279, ptr %l120
  %t280 = load i1, ptr %l120
  br i1 %t280, label %bb79, label %bb80
bb79:
  %t281 = load ptr, ptr %l118
  %t282 = load i64, ptr %t281
  store i64 %t282, ptr %l121
  %t283 = load i64, ptr %l121
  %t284 = icmp eq i64 %t283, 18
  store i1 %t284, ptr %l119
  br label %bb80
bb80:
  %t285 = load i1, ptr %l119
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0
  store ptr %t286, ptr %l122
  %t287 = load ptr, ptr %l122
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t287, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 0
  %t290 = load %"compiler/source:Span", ptr %t289
  store %"compiler/source:Span" %t290, ptr %l123
  %t291 = load %"compiler/source:Span", ptr %l123
  store %"compiler/source:Span" %t291, ptr %l4
  br label %bb83
bb82:
  br label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s4
  %t292 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t292, ptr %l124
  %t293 = load %"compiler/source:Span", ptr %l124
  store %"compiler/source:Span" %t293, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb91
bb84:
  %t294 = load ptr, ptr %l0
  store ptr %t294, ptr %l125
  store i1 false, ptr %l126
  %t295 = load ptr, ptr %l125
  %t296 = icmp ne ptr %t295, null
  store i1 %t296, ptr %l127
  %t297 = load i1, ptr %l127
  br i1 %t297, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l125
  %t299 = load i64, ptr %t298
  store i64 %t299, ptr %l128
  %t300 = load i64, ptr %l128
  %t301 = icmp eq i64 %t300, 19
  store i1 %t301, ptr %l126
  br label %bb86
bb86:
  %t302 = load i1, ptr %l126
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0
  store ptr %t303, ptr %l129
  %t304 = load ptr, ptr %l129
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l130
  %t308 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t308, ptr %l5
  br label %bb89
bb88:
  br label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s5
  %t309 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t309, ptr %l131
  %t310 = load %"compiler/source:Span", ptr %l131
  store %"compiler/source:Span" %t310, ptr %l6
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t311 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t311, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  store i1 false, ptr %l5
  %t2 = load ptr, ptr %l4
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l6
  %t4 = load i1, ptr %l6
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l7
  %t7 = load i64, ptr %l7
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l8
  %t11 = load ptr, ptr %l8
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l9
  %t15 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l10
  store i1 false, ptr %l11
  %t17 = load ptr, ptr %l10
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l12
  %t19 = load i1, ptr %l12
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l13
  %t22 = load i64, ptr %l13
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l11
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l14
  %t26 = load ptr, ptr %l14
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l15
  %t30 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l16
  store i1 false, ptr %l17
  %t32 = load ptr, ptr %l16
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l18
  %t34 = load i1, ptr %l18
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l19
  %t37 = load i64, ptr %l19
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l17
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l20
  %t41 = load ptr, ptr %l20
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l21
  %t45 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb13
bb12:
  br label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l22
  %t47 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t47, ptr %l3
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb14:
  %t48 = load ptr, ptr %l0
  store ptr %t48, ptr %l23
  store i1 false, ptr %l24
  %t49 = load ptr, ptr %l23
  %t50 = icmp ne ptr %t49, null
  store i1 %t50, ptr %l25
  %t51 = load i1, ptr %l25
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l23
  %t53 = load i64, ptr %t52
  store i64 %t53, ptr %l26
  %t54 = load i64, ptr %l26
  %t55 = icmp eq i64 %t54, 3
  store i1 %t55, ptr %l24
  br label %bb16
bb16:
  %t56 = load i1, ptr %l24
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0
  store ptr %t57, ptr %l27
  %t58 = load ptr, ptr %l27
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l28
  %t62 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t62, ptr %l2
  br label %bb27
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l29
  store i1 false, ptr %l30
  %t64 = load ptr, ptr %l29
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l31
  %t66 = load i1, ptr %l31
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l32
  %t69 = load i64, ptr %l32
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l30
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l33
  %t73 = load ptr, ptr %l33
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l34
  %t77 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t77, ptr %l2
  br label %bb27
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l35
  store i1 false, ptr %l36
  %t79 = load ptr, ptr %l35
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l37
  %t81 = load i1, ptr %l37
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l38
  %t84 = load i64, ptr %l38
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l36
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l39
  %t88 = load ptr, ptr %l39
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l40
  %t92 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t93 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t93, ptr %l41
  %t94 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t94, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t95, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"compiler/ast:Branch"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Branch"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l6
  %t2 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l4
  %t5 = load i64, ptr %l2
  store i64 %t5, ptr %l8
  %t6 = load i64, ptr %l8
  store i64 %t6, ptr %l5
  %t7 = load %"compiler/source:Span", ptr %l3
  %t8 = insertvalue %"compiler/ast:Branch" undef, %"compiler/source:Span" %t7, 0
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/ast:Branch" %t8, { i64, ptr } %t9, 1
  %t11 = load i64, ptr %l5
  %t12 = insertvalue %"compiler/ast:Branch" %t10, i64 %t11, 2
  store %"compiler/ast:Branch" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:Branch", ptr %l9
  store %"compiler/ast:Branch" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Branch", ptr %rv
  ret %"compiler/ast:Branch" %rr
}

define dso_local %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/ast:CaseDecl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:CaseDecl"
  store %"compiler/source:Span" %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l6
  %t2 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2, ptr %l3
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load %"compiler/source:Span", ptr %l3
  %t8 = insertvalue %"compiler/ast:CaseDecl" undef, %"compiler/source:Span" %t7, 0
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/ast:CaseDecl" %t8, i32 %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:CaseDecl" %t10, { i64, ptr } %t11, 2
  store %"compiler/ast:CaseDecl" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:CaseDecl", ptr %l9
  store %"compiler/ast:CaseDecl" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:CaseDecl", ptr %rv
  ret %"compiler/ast:CaseDecl" %rr
}

define dso_local %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca %"compiler/ast:Case"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Case"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l12
  %t2 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l13
  %t4 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t4, ptr %l7
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l14
  %t6 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t6, ptr %l8
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l15
  %t8 = load ptr, ptr %l15
  store ptr %t8, ptr %l9
  %t9 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t9, ptr %l16
  %t10 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t10, ptr %l10
  %t11 = load ptr, ptr %l5
  store ptr %t11, ptr %l17
  %t12 = load ptr, ptr %l17
  store ptr %t12, ptr %l11
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = insertvalue %"compiler/ast:Case" undef, %"compiler/source:Span" %t13, 0
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue %"compiler/ast:Case" %t14, { i64, ptr } %t15, 1
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/ast:Case" %t16, { i64, ptr } %t17, 2
  %t19 = load ptr, ptr %l9
  %t20 = insertvalue %"compiler/ast:Case" %t18, ptr %t19, 3
  %t21 = load { i64, ptr }, ptr %l10
  %t22 = insertvalue %"compiler/ast:Case" %t20, { i64, ptr } %t21, 4
  %t23 = load ptr, ptr %l11
  %t24 = insertvalue %"compiler/ast:Case" %t22, ptr %t23, 5
  store %"compiler/ast:Case" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:Case", ptr %l18
  store %"compiler/ast:Case" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Case", ptr %rv
  ret %"compiler/ast:Case" %rr
}

define dso_local %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/ast:Catch"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Catch"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l8
  %t2 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t4, ptr %l5
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l10
  %t6 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t6, ptr %l6
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l11
  %t8 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t8, ptr %l7
  %t9 = load %"compiler/source:Span", ptr %l4
  %t10 = insertvalue %"compiler/ast:Catch" undef, %"compiler/source:Span" %t9, 0
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:Catch" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/ast:Catch" %t12, { i64, ptr } %t13, 2
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue %"compiler/ast:Catch" %t14, { i64, ptr } %t15, 3
  store %"compiler/ast:Catch" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/ast:Catch", ptr %l12
  store %"compiler/ast:Catch" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Catch", ptr %rv
  ret %"compiler/ast:Catch" %rr
}

define dso_local %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/ast:Chain"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Chain"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l5
  %t4 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l2
  %t6 = insertvalue %"compiler/ast:Chain" undef, { i64, ptr } %t5, 0
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/ast:Chain" %t6, { i64, ptr } %t7, 1
  store %"compiler/ast:Chain" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/ast:Chain", ptr %l6
  store %"compiler/ast:Chain" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Chain", ptr %rv
  ret %"compiler/ast:Chain" %rr
}

define dso_local %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"compiler/ast:Compr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Compr"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l12
  %t2 = load ptr, ptr %l12
  store ptr %t2, ptr %l6
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l13
  %t4 = load ptr, ptr %l13
  store ptr %t4, ptr %l7
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l14
  %t6 = load i32, ptr %l14
  store i32 %t6, ptr %l8
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l15
  %t8 = load i32, ptr %l15
  store i32 %t8, ptr %l9
  %t9 = load ptr, ptr %l4
  store ptr %t9, ptr %l16
  %t10 = load ptr, ptr %l16
  store ptr %t10, ptr %l10
  %t11 = load ptr, ptr %l5
  store ptr %t11, ptr %l17
  %t12 = load ptr, ptr %l17
  store ptr %t12, ptr %l11
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/ast:Compr" undef, ptr %t13, 0
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:Compr" %t14, ptr %t15, 1
  %t17 = load i32, ptr %l8
  %t18 = insertvalue %"compiler/ast:Compr" %t16, i32 %t17, 2
  %t19 = load i32, ptr %l9
  %t20 = insertvalue %"compiler/ast:Compr" %t18, i32 %t19, 3
  %t21 = load ptr, ptr %l10
  %t22 = insertvalue %"compiler/ast:Compr" %t20, ptr %t21, 4
  %t23 = load ptr, ptr %l11
  %t24 = insertvalue %"compiler/ast:Compr" %t22, ptr %t23, 5
  store %"compiler/ast:Compr" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:Compr", ptr %l18
  store %"compiler/ast:Compr" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Compr", ptr %rv
  ret %"compiler/ast:Compr" %rr
}

define dso_local %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/ast:For3"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:For3"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  store ptr %t2, ptr %l4
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  store ptr %t4, ptr %l5
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l10
  %t6 = load ptr, ptr %l10
  store ptr %t6, ptr %l6
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l11
  %t8 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t8, ptr %l7
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/ast:For3" undef, ptr %t9, 0
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/ast:For3" %t10, ptr %t11, 1
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/ast:For3" %t12, ptr %t13, 2
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue %"compiler/ast:For3" %t14, { i64, ptr } %t15, 3
  store %"compiler/ast:For3" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/ast:For3", ptr %l12
  store %"compiler/ast:For3" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:For3", ptr %rv
  ret %"compiler/ast:For3" %rr
}

define dso_local %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/ast:ForIn"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:ForIn"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l12
  %t2 = load i32, ptr %l12
  store i32 %t2, ptr %l6
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l13
  %t4 = load i32, ptr %l13
  store i32 %t4, ptr %l7
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l14
  %t6 = load ptr, ptr %l14
  store ptr %t6, ptr %l8
  %t7 = load i1, ptr %l3
  store i1 %t7, ptr %l15
  %t8 = load i1, ptr %l15
  store i1 %t8, ptr %l9
  %t9 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t9, ptr %l16
  %t10 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t10, ptr %l10
  %t11 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t11, ptr %l17
  %t12 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t12, ptr %l11
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/ast:ForIn" undef, i32 %t13, 0
  %t15 = load i32, ptr %l7
  %t16 = insertvalue %"compiler/ast:ForIn" %t14, i32 %t15, 1
  %t17 = load ptr, ptr %l8
  %t18 = insertvalue %"compiler/ast:ForIn" %t16, ptr %t17, 2
  %t19 = load i1, ptr %l9
  %t20 = insertvalue %"compiler/ast:ForIn" %t18, i1 %t19, 3
  %t21 = load { i64, ptr }, ptr %l10
  %t22 = insertvalue %"compiler/ast:ForIn" %t20, { i64, ptr } %t21, 4
  %t23 = load { i64, ptr }, ptr %l11
  %t24 = insertvalue %"compiler/ast:ForIn" %t22, { i64, ptr } %t23, 5
  store %"compiler/ast:ForIn" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:ForIn", ptr %l18
  store %"compiler/ast:ForIn" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:ForIn", ptr %rv
  ret %"compiler/ast:ForIn" %rr
}

define dso_local %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/ast:Func"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Func"
  store %"compiler/source:Span" %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l12
  %t2 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t2, ptr %l6
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l13
  %t4 = load ptr, ptr %l13
  store ptr %t4, ptr %l7
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l14
  %t6 = load i32, ptr %l14
  store i32 %t6, ptr %l8
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l15
  %t8 = load ptr, ptr %l15
  store ptr %t8, ptr %l9
  %t9 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t9, ptr %l16
  %t10 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t10, ptr %l10
  %t11 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t11, ptr %l17
  %t12 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t12, ptr %l11
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = insertvalue %"compiler/ast:Func" undef, %"compiler/source:Span" %t13, 0
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:Func" %t14, ptr %t15, 1
  %t17 = load i32, ptr %l8
  %t18 = insertvalue %"compiler/ast:Func" %t16, i32 %t17, 2
  %t19 = load ptr, ptr %l9
  %t20 = insertvalue %"compiler/ast:Func" %t18, ptr %t19, 3
  %t21 = load { i64, ptr }, ptr %l10
  %t22 = insertvalue %"compiler/ast:Func" %t20, { i64, ptr } %t21, 4
  %t23 = load { i64, ptr }, ptr %l11
  %t24 = insertvalue %"compiler/ast:Func" %t22, { i64, ptr } %t23, 5
  store %"compiler/ast:Func" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:Func", ptr %l18
  store %"compiler/ast:Func" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Func", ptr %rv
  ret %"compiler/ast:Func" %rr
}

define dso_local %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/ast:If"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:If"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  store ptr %t4, ptr %l4
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l8
  %t6 = load ptr, ptr %l8
  store ptr %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/ast:If" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/ast:If" %t8, ptr %t9, 1
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/ast:If" %t10, ptr %t11, 2
  store %"compiler/ast:If" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:If", ptr %l9
  store %"compiler/ast:If" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:If", ptr %rv
  ret %"compiler/ast:If" %rr
}

define dso_local %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/ast:JoinS"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:JoinS"
  store i1 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l0
  store i1 %t1, ptr %l6
  %t2 = load i1, ptr %l6
  store i1 %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load i1, ptr %l3
  %t8 = insertvalue %"compiler/ast:JoinS" undef, i1 %t7, 0
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/ast:JoinS" %t8, { i64, ptr } %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:JoinS" %t10, { i64, ptr } %t11, 2
  store %"compiler/ast:JoinS" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:JoinS", ptr %l9
  store %"compiler/ast:JoinS" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:JoinS", ptr %rv
  ret %"compiler/ast:JoinS" %rr
}

define dso_local %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca %"compiler/ast:Match"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Match"
  store %"compiler/source:Span" %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l10
  %t2 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l11
  %t4 = load ptr, ptr %l11
  store ptr %t4, ptr %l6
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l12
  %t6 = load i1, ptr %l12
  store i1 %t6, ptr %l7
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l13
  %t8 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t8, ptr %l8
  %t9 = load ptr, ptr %l4
  store ptr %t9, ptr %l14
  %t10 = load ptr, ptr %l14
  store ptr %t10, ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l5
  %t12 = insertvalue %"compiler/ast:Match" undef, %"compiler/source:Span" %t11, 0
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/ast:Match" %t12, ptr %t13, 1
  %t15 = load i1, ptr %l7
  %t16 = insertvalue %"compiler/ast:Match" %t14, i1 %t15, 2
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/ast:Match" %t16, { i64, ptr } %t17, 3
  %t19 = load ptr, ptr %l9
  %t20 = insertvalue %"compiler/ast:Match" %t18, ptr %t19, 4
  store %"compiler/ast:Match" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/ast:Match", ptr %l15
  store %"compiler/ast:Match" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Match", ptr %rv
  ret %"compiler/ast:Match" %rr
}

define dso_local %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/ast:Multi"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Multi"
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t2, ptr %l3
  %t3 = load i1, ptr %l1
  store i1 %t3, ptr %l7
  %t4 = load i1, ptr %l7
  store i1 %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/ast:Multi" undef, { i64, ptr } %t7, 0
  %t9 = load i1, ptr %l4
  %t10 = insertvalue %"compiler/ast:Multi" %t8, i1 %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:Multi" %t10, { i64, ptr } %t11, 2
  store %"compiler/ast:Multi" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:Multi", ptr %l9
  store %"compiler/ast:Multi" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Multi", ptr %rv
  ret %"compiler/ast:Multi" %rr
}

define dso_local %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/ast:Param"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Param"
  store %"compiler/source:Span" %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l8
  %t2 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t2, ptr %l4
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l9
  %t4 = load i32, ptr %l9
  store i32 %t4, ptr %l5
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l10
  %t6 = load ptr, ptr %l10
  store ptr %t6, ptr %l6
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l11
  %t8 = load ptr, ptr %l11
  store ptr %t8, ptr %l7
  %t9 = load %"compiler/source:Span", ptr %l4
  %t10 = insertvalue %"compiler/ast:Param" undef, %"compiler/source:Span" %t9, 0
  %t11 = load i32, ptr %l5
  %t12 = insertvalue %"compiler/ast:Param" %t10, i32 %t11, 1
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/ast:Param" %t12, ptr %t13, 2
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:Param" %t14, ptr %t15, 3
  store %"compiler/ast:Param" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/ast:Param", ptr %l12
  store %"compiler/ast:Param" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Param", ptr %rv
  ret %"compiler/ast:Param" %rr
}

define dso_local %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/ast:Path"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Path"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l4
  %t2 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l5
  %t4 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t4, ptr %l3
  %t5 = load %"compiler/source:Span", ptr %l2
  %t6 = insertvalue %"compiler/ast:Path" undef, %"compiler/source:Span" %t5, 0
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/ast:Path" %t6, { i64, ptr } %t7, 1
  store %"compiler/ast:Path" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/ast:Path", ptr %l6
  store %"compiler/ast:Path" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Path", ptr %rv
  ret %"compiler/ast:Path" %rr
}

define dso_local %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca %"compiler/ast:Sig"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:Sig"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l10
  %t2 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l11
  %t4 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t4, ptr %l6
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l12
  %t6 = load i1, ptr %l12
  store i1 %t6, ptr %l7
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l13
  %t8 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t8, ptr %l8
  %t9 = load i1, ptr %l4
  store i1 %t9, ptr %l14
  %t10 = load i1, ptr %l14
  store i1 %t10, ptr %l9
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:Sig" undef, { i64, ptr } %t11, 0
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/ast:Sig" %t12, { i64, ptr } %t13, 1
  %t15 = load i1, ptr %l7
  %t16 = insertvalue %"compiler/ast:Sig" %t14, i1 %t15, 2
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/ast:Sig" %t16, { i64, ptr } %t17, 3
  %t19 = load i1, ptr %l9
  %t20 = insertvalue %"compiler/ast:Sig" %t18, i1 %t19, 4
  store %"compiler/ast:Sig" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/ast:Sig", ptr %l15
  store %"compiler/ast:Sig" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Sig", ptr %rv
  ret %"compiler/ast:Sig" %rr
}

define dso_local %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/ast:StructBody"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:StructBody"
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l12
  %t2 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t2, ptr %l6
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l13
  %t4 = load ptr, ptr %l13
  store ptr %t4, ptr %l7
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l14
  %t6 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t6, ptr %l8
  %t7 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t7, ptr %l15
  %t8 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t8, ptr %l9
  %t9 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t9, ptr %l16
  %t10 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t10, ptr %l10
  %t11 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t11, ptr %l17
  %t12 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t12, ptr %l11
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/ast:StructBody" undef, { i64, ptr } %t13, 0
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:StructBody" %t14, ptr %t15, 1
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/ast:StructBody" %t16, { i64, ptr } %t17, 2
  %t19 = load %"compiler/source:Span", ptr %l9
  %t20 = insertvalue %"compiler/ast:StructBody" %t18, %"compiler/source:Span" %t19, 3
  %t21 = load { i64, ptr }, ptr %l10
  %t22 = insertvalue %"compiler/ast:StructBody" %t20, { i64, ptr } %t21, 4
  %t23 = load { i64, ptr }, ptr %l11
  %t24 = insertvalue %"compiler/ast:StructBody" %t22, { i64, ptr } %t23, 5
  store %"compiler/ast:StructBody" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:StructBody", ptr %l18
  store %"compiler/ast:StructBody" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:StructBody", ptr %rv
  ret %"compiler/ast:StructBody" %rr
}

define dso_local %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"compiler/ast:TopBranch"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:TopBranch"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l6
  %t2 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l4
  %t5 = load i64, ptr %l2
  store i64 %t5, ptr %l8
  %t6 = load i64, ptr %l8
  store i64 %t6, ptr %l5
  %t7 = load %"compiler/source:Span", ptr %l3
  %t8 = insertvalue %"compiler/ast:TopBranch" undef, %"compiler/source:Span" %t7, 0
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/ast:TopBranch" %t8, { i64, ptr } %t9, 1
  %t11 = load i64, ptr %l5
  %t12 = insertvalue %"compiler/ast:TopBranch" %t10, i64 %t11, 2
  store %"compiler/ast:TopBranch" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:TopBranch", ptr %l9
  store %"compiler/ast:TopBranch" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopBranch", ptr %rv
  ret %"compiler/ast:TopBranch" %rr
}

define dso_local %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/ast:TopIf"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:TopIf"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  store ptr %t2, ptr %l4
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  store ptr %t4, ptr %l5
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l10
  %t6 = load ptr, ptr %l10
  store ptr %t6, ptr %l6
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l11
  %t8 = load ptr, ptr %l11
  store ptr %t8, ptr %l7
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/ast:TopIf" undef, ptr %t9, 0
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/ast:TopIf" %t10, ptr %t11, 1
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/ast:TopIf" %t12, ptr %t13, 2
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:TopIf" %t14, ptr %t15, 3
  store %"compiler/ast:TopIf" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/ast:TopIf", ptr %l12
  store %"compiler/ast:TopIf" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopIf", ptr %rv
  ret %"compiler/ast:TopIf" %rr
}

define dso_local %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca %"compiler/ast:TypeDecl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:TypeDecl"
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l8
  %t2 = load i32, ptr %l8
  store i32 %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t4, ptr %l5
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l10
  %t6 = load i1, ptr %l10
  store i1 %t6, ptr %l6
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l11
  %t8 = load ptr, ptr %l11
  store ptr %t8, ptr %l7
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/ast:TypeDecl" undef, i32 %t9, 0
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/ast:TypeDecl" %t10, { i64, ptr } %t11, 1
  %t13 = load i1, ptr %l6
  %t14 = insertvalue %"compiler/ast:TypeDecl" %t12, i1 %t13, 2
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/ast:TypeDecl" %t14, ptr %t15, 3
  store %"compiler/ast:TypeDecl" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/ast:TypeDecl", ptr %l12
  store %"compiler/ast:TypeDecl" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeDecl", ptr %rv
  ret %"compiler/ast:TypeDecl" %rr
}

define dso_local %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/ast:TypeParam"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:TypeParam"
  store %"compiler/source:Span" %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l6
  %t2 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t2, ptr %l3
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l4
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l8
  %t6 = load ptr, ptr %l8
  store ptr %t6, ptr %l5
  %t7 = load %"compiler/source:Span", ptr %l3
  %t8 = insertvalue %"compiler/ast:TypeParam" undef, %"compiler/source:Span" %t7, 0
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/ast:TypeParam" %t8, i32 %t9, 1
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/ast:TypeParam" %t10, ptr %t11, 2
  store %"compiler/ast:TypeParam" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/ast:TypeParam", ptr %l9
  store %"compiler/ast:TypeParam" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeParam", ptr %rv
  ret %"compiler/ast:TypeParam" %rr
}

define dso_local %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca %"compiler/ast:VarDecl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/ast:VarDecl"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l12
  %t2 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l13
  %t4 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t4, ptr %l7
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l14
  %t6 = load ptr, ptr %l14
  store ptr %t6, ptr %l8
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l15
  %t8 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t8, ptr %l9
  %t9 = load i1, ptr %l4
  store i1 %t9, ptr %l16
  %t10 = load i1, ptr %l16
  store i1 %t10, ptr %l10
  %t11 = load i1, ptr %l5
  store i1 %t11, ptr %l17
  %t12 = load i1, ptr %l17
  store i1 %t12, ptr %l11
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/ast:VarDecl" undef, { i64, ptr } %t13, 0
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue %"compiler/ast:VarDecl" %t14, { i64, ptr } %t15, 1
  %t17 = load ptr, ptr %l8
  %t18 = insertvalue %"compiler/ast:VarDecl" %t16, ptr %t17, 2
  %t19 = load { i64, ptr }, ptr %l9
  %t20 = insertvalue %"compiler/ast:VarDecl" %t18, { i64, ptr } %t19, 3
  %t21 = load i1, ptr %l10
  %t22 = insertvalue %"compiler/ast:VarDecl" %t20, i1 %t21, 4
  %t23 = load i1, ptr %l11
  %t24 = insertvalue %"compiler/ast:VarDecl" %t22, i1 %t23, 5
  store %"compiler/ast:VarDecl" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/ast:VarDecl", ptr %l18
  store %"compiler/ast:VarDecl" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:VarDecl", ptr %rv
  ret %"compiler/ast:VarDecl" %rr
}

declare void @__olang_scope_close(ptr)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [50 x i8] c"compiler/ast.olang:301: reached unreachable code\0A\00"
@.c1 = private unnamed_addr constant [50 x i8] c"compiler/ast.olang:330: reached unreachable code\0A\00"
@.c2 = private unnamed_addr constant [50 x i8] c"compiler/ast.olang:320: reached unreachable code\0A\00"
@.c3 = private unnamed_addr constant [50 x i8] c"compiler/ast.olang:313: reached unreachable code\0A\00"
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
