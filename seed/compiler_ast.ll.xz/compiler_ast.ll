; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
@G_2ecompiler_2fast_2eNoYield = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
define dso_local %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t34 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t29)
  store %"compiler/source:Span" %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = icmp sge i32 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  %t47 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fast_2eNoYield_2einit() #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %t1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t3, ptr @G_2ecompiler_2fast_2eNoYield
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l8
  br label %bb123
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l46, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l47, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t124 = load ptr, ptr %l58, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l58, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l59, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l8
  br label %bb123
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t141 = load ptr, ptr %l65, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l65, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l66, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb57
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l72, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l72, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb57
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t171 = load ptr, ptr %l77, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l77, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l78, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l78, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb57
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t186 = load ptr, ptr %l83, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l83, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l84, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l84, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t200 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t200, ptr %l8
  br label %bb123
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t203 = load ptr, ptr %l90, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l90, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l91, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l91, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t218 = load ptr, ptr %l96, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l96, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l97, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l97, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t233 = load ptr, ptr %l102, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l102, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l103, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l103, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t248 = load ptr, ptr %l108, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l108, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l109, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l109, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l8
  br label %bb123
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t265 = load ptr, ptr %l115, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l115, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l116, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l116, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb93
bb80:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t280 = load ptr, ptr %l121, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb81, label %bb82
bb81:
  %t283 = load ptr, ptr %l121, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 18
  store i1 %t286, ptr %l122, !tbaa !21
  br label %bb82
bb82:
  %t287 = load i1, ptr %l122, !tbaa !21
  br i1 %t287, label %bb83, label %bb84
bb83:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t290, i32 0, i32 0
  %t292 = load %"compiler/source:Span", ptr %t291
  store %"compiler/source:Span" %t292, ptr %l5
  br label %bb93
bb84:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t295 = load ptr, ptr %l127, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l127, !tbaa !29
  %t299 = load i64, ptr %t298
  %t301 = icmp eq i64 %t299, 19
  store i1 %t301, ptr %l128, !tbaa !21
  br label %bb86
bb86:
  %t302 = load i1, ptr %l128, !tbaa !21
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l5
  br label %bb93
bb88:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t310 = load ptr, ptr %l133, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb89, label %bb90
bb89:
  %t313 = load ptr, ptr %l133, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 20
  store i1 %t316, ptr %l134, !tbaa !21
  br label %bb90
bb90:
  %t317 = load i1, ptr %l134, !tbaa !21
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 0
  %t322 = load %"compiler/source:Span", ptr %t321
  store %"compiler/source:Span" %t322, ptr %l5
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t324 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t324, ptr %l8
  br label %bb123
bb94:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t327 = load ptr, ptr %l140, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb95, label %bb96
bb95:
  %t330 = load ptr, ptr %l140, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 21
  store i1 %t333, ptr %l141, !tbaa !21
  br label %bb96
bb96:
  %t334 = load i1, ptr %l141, !tbaa !21
  br i1 %t334, label %bb97, label %bb98
bb97:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t337, i32 0, i32 0
  %t339 = load %"compiler/source:Span", ptr %t338
  store %"compiler/source:Span" %t339, ptr %l6
  br label %bb115
bb98:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t342 = load ptr, ptr %l146, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb99, label %bb100
bb99:
  %t345 = load ptr, ptr %l146, !tbaa !29
  %t346 = load i64, ptr %t345
  %t348 = icmp eq i64 %t346, 22
  store i1 %t348, ptr %l147, !tbaa !21
  br label %bb100
bb100:
  %t349 = load i1, ptr %l147, !tbaa !21
  br i1 %t349, label %bb101, label %bb102
bb101:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t352, i32 0, i32 0
  %t354 = load %"compiler/source:Span", ptr %t353
  store %"compiler/source:Span" %t354, ptr %l6
  br label %bb115
bb102:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t357 = load ptr, ptr %l152, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb103, label %bb104
bb103:
  %t360 = load ptr, ptr %l152, !tbaa !29
  %t361 = load i64, ptr %t360
  %t363 = icmp eq i64 %t361, 23
  store i1 %t363, ptr %l153, !tbaa !21
  br label %bb104
bb104:
  %t364 = load i1, ptr %l153, !tbaa !21
  br i1 %t364, label %bb105, label %bb106
bb105:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr }, ptr %t367, i32 0, i32 0
  %t369 = load %"compiler/source:Span", ptr %t368
  store %"compiler/source:Span" %t369, ptr %l6
  br label %bb115
bb106:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t372 = load ptr, ptr %l158, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb107, label %bb108
bb107:
  %t375 = load ptr, ptr %l158, !tbaa !29
  %t376 = load i64, ptr %t375
  %t378 = icmp eq i64 %t376, 24
  store i1 %t378, ptr %l159, !tbaa !21
  br label %bb108
bb108:
  %t379 = load i1, ptr %l159, !tbaa !21
  br i1 %t379, label %bb109, label %bb110
bb109:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", ptr }, ptr %t382, i32 0, i32 0
  %t384 = load %"compiler/source:Span", ptr %t383
  store %"compiler/source:Span" %t384, ptr %l6
  br label %bb115
bb110:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t387 = load ptr, ptr %l164, !tbaa !29
  %t388 = icmp ne ptr %t387, null
  br i1 %t388, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l164, !tbaa !29
  %t391 = load i64, ptr %t390
  %t393 = icmp eq i64 %t391, 25
  store i1 %t393, ptr %l165, !tbaa !21
  br label %bb112
bb112:
  %t394 = load i1, ptr %l165, !tbaa !21
  br i1 %t394, label %bb113, label %bb114
bb113:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr { i64, [5 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t397, i32 0, i32 0
  %t399 = load %"compiler/source:Span", ptr %t398
  store %"compiler/source:Span" %t399, ptr %l6
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t401 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t401, ptr %l8
  br label %bb123
bb116:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t404 = load ptr, ptr %l171, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb117, label %bb118
bb117:
  %t407 = load ptr, ptr %l171, !tbaa !29
  %t408 = load i64, ptr %t407
  %t410 = icmp eq i64 %t408, 26
  store i1 %t410, ptr %l172, !tbaa !21
  br label %bb118
bb118:
  %t411 = load i1, ptr %l172, !tbaa !21
  br i1 %t411, label %bb119, label %bb120
bb119:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr { i64, [5 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span" }, ptr %t414, i32 0, i32 0
  %t416 = load %"compiler/source:Span", ptr %t415
  store %"compiler/source:Span" %t416, ptr %l7
  br label %bb121
bb120:
  br label %bb122
bb121:
  %t418 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t418, ptr %l8
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_55eca5e8e4fb6f87_b7588236e57371eb)
  unreachable
bb123:
  %t420 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t420, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb29
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb27
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t93 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t93, ptr %l3
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8f7e387f76106e1a_528835e8df6db77e)
  unreachable
bb29:
  %t95 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t95, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb95
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb39
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l56, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l57, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l6
  br label %bb95
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb61
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb61
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb61
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l81, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l82, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb61
bb56:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t201 = load ptr, ptr %l87, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l87, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 13
  store i1 %t207, ptr %l88, !tbaa !21
  br label %bb58
bb58:
  %t208 = load i1, ptr %l88, !tbaa !21
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l3
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t215 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t215, ptr %l6
  br label %bb95
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb83
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb83
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb83
bb74:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t263 = load ptr, ptr %l112, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb75, label %bb76
bb75:
  %t266 = load ptr, ptr %l112, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 17
  store i1 %t269, ptr %l113, !tbaa !21
  br label %bb76
bb76:
  %t270 = load i1, ptr %l113, !tbaa !21
  br i1 %t270, label %bb77, label %bb78
bb77:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr { i64, [4 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 0
  %t275 = load %"compiler/source:Span", ptr %t274
  store %"compiler/source:Span" %t275, ptr %l4
  br label %bb83
bb78:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t278 = load ptr, ptr %l118, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb79, label %bb80
bb79:
  %t281 = load ptr, ptr %l118, !tbaa !29
  %t282 = load i64, ptr %t281
  %t284 = icmp eq i64 %t282, 18
  store i1 %t284, ptr %l119, !tbaa !21
  br label %bb80
bb80:
  %t285 = load i1, ptr %l119, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t288, i32 0, i32 0
  %t290 = load %"compiler/source:Span", ptr %t289
  store %"compiler/source:Span" %t290, ptr %l4
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t292 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t292, ptr %l6
  br label %bb95
bb84:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t295 = load ptr, ptr %l125, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l125, !tbaa !29
  %t299 = load i64, ptr %t298
  %t301 = icmp eq i64 %t299, 19
  store i1 %t301, ptr %l126, !tbaa !21
  br label %bb86
bb86:
  %t302 = load i1, ptr %l126, !tbaa !21
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr { i64, [4 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l5
  br label %bb93
bb88:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t310 = load ptr, ptr %l131, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb89, label %bb90
bb89:
  %t313 = load ptr, ptr %l131, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 20
  store i1 %t316, ptr %l132, !tbaa !21
  br label %bb90
bb90:
  %t317 = load i1, ptr %l132, !tbaa !21
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 0
  %t322 = load %"compiler/source:Span", ptr %t321
  store %"compiler/source:Span" %t322, ptr %l5
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t324 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t324, ptr %l6
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_2231a09e52c8bb46_65bd70f90f09695a)
  unreachable
bb95:
  %t326 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t326, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l4
  br label %bb35
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l2
  br label %bb27
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t56 = load i1, ptr %l25, !tbaa !21
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l2
  br label %bb27
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l30, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l31, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb27
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l36, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t93 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t93, ptr %l4
  br label %bb35
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t96 = load ptr, ptr %l43, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load ptr, ptr %l43, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l44, !tbaa !21
  br label %bb30
bb30:
  %t103 = load i1, ptr %l44, !tbaa !21
  br i1 %t103, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t106, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l3
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t110 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t110, ptr %l4
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_4ec53bb81943b275_46293089da537299)
  unreachable
bb35:
  %t112 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t112, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca i1
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca ptr
  %l135 = alloca i1
  %l143 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l151 = alloca %"compiler/source:Span"
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca ptr
  %l158 = alloca i1
  %l166 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/source:Span"
  %l173 = alloca %"compiler/source:Span"
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca ptr
  %l176 = alloca i1
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca ptr
  %l184 = alloca i1
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca ptr
  %l192 = alloca i1
  %l201 = alloca %"compiler/source:Span"
  %l203 = alloca %"compiler/source:Span"
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca ptr
  %l206 = alloca i1
  %l212 = alloca %"compiler/source:Span"
  %l213 = alloca ptr
  %l214 = alloca i1
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca ptr
  %l223 = alloca i1
  %l230 = alloca %"compiler/source:Span"
  %l233 = alloca %"compiler/source:Span"
  %l234 = alloca %"compiler/source:Span"
  %l235 = alloca ptr
  %l236 = alloca i1
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca ptr
  %l245 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t8 = load ptr, ptr %l27, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l27, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 20
  store i1 %t14, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l28, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l1
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l26
  br label %bb163
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l34, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t39)
  store %"compiler/source:Span" %t42, ptr %l42
  br label %bb15
bb15:
  %t43 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t43, ptr %l26
  br label %bb163
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t45 = load ptr, ptr %l43, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l43, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t52 = load i1, ptr %l44, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr }, ptr %t55, i32 0, i32 1
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/ast:VarDecl", ptr %t59, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t62)
  store %"compiler/source:Span" %t64, ptr %l51
  br label %bb22
bb22:
  %t65 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t65, ptr %l26
  br label %bb163
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t67 = load ptr, ptr %l52, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb24, label %bb25
bb24:
  %t70 = load ptr, ptr %l52, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 2
  store i1 %t73, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t74 = load i1, ptr %l53, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l4, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Multi", ptr %t81, i32 0, i32 2
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t84)
  store %"compiler/source:Span" %t86, ptr %l60
  br label %bb29
bb29:
  %t87 = load %"compiler/source:Span", ptr %l60
  store %"compiler/source:Span" %t87, ptr %l26
  br label %bb163
bb30:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t89 = load ptr, ptr %l61, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb31, label %bb32
bb31:
  %t92 = load ptr, ptr %l61, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 3
  store i1 %t95, ptr %l62, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l62, !tbaa !21
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l5, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t105, i32 0, i32 3
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l6, !tbaa !29
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t112 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t109)
  store %"compiler/source:Span" %t112, ptr %l71
  br label %bb36
bb36:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t116 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t113)
  store %"compiler/source:Span" %t116, ptr %l74
  br label %bb37
bb37:
  %t117 = load %"compiler/source:Span", ptr %l71
  %t118 = load %"compiler/source:Span", ptr %l74
  %t119 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t117, %"compiler/source:Span" %t118)
  store %"compiler/source:Span" %t119, ptr %l75
  br label %bb38
bb38:
  %t120 = load %"compiler/source:Span", ptr %l75
  store %"compiler/source:Span" %t120, ptr %l26
  br label %bb163
bb39:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t122 = load ptr, ptr %l76, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb40, label %bb41
bb40:
  %t125 = load ptr, ptr %l76, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l77, !tbaa !21
  br label %bb41
bb41:
  %t129 = load i1, ptr %l77, !tbaa !21
  br i1 %t129, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l8, !tbaa !27
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t145 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t142)
  store %"compiler/source:Span" %t145, ptr %l86
  br label %bb45
bb45:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t148 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCatches(ptr %v0, { i64, ptr } %t146)
  store %"compiler/source:Span" %t148, ptr %l88
  br label %bb46
bb46:
  %t149 = load %"compiler/source:Span", ptr %l86
  %t150 = load %"compiler/source:Span", ptr %l88
  %t151 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t149, %"compiler/source:Span" %t150)
  store %"compiler/source:Span" %t151, ptr %l89
  br label %bb47
bb47:
  %t152 = load %"compiler/source:Span", ptr %l89
  store %"compiler/source:Span" %t152, ptr %l26
  br label %bb163
bb48:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t154 = load ptr, ptr %l90, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb49, label %bb50
bb49:
  %t157 = load ptr, ptr %l90, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 5
  store i1 %t160, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t161 = load i1, ptr %l91, !tbaa !21
  br i1 %t161, label %bb51, label %bb52
bb51:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l9, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t168 = load ptr, ptr %l9, !tbaa !29
  %t170 = call %"compiler/source:Span" @compiler_2fast_2eyieldInIf(ptr %v0, ptr %t168)
  store %"compiler/source:Span" %t170, ptr %l97
  br label %bb54
bb54:
  %t171 = load %"compiler/source:Span", ptr %l97
  store %"compiler/source:Span" %t171, ptr %l26
  br label %bb163
bb55:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t173 = load ptr, ptr %l98, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb56, label %bb57
bb56:
  %t176 = load ptr, ptr %l98, !tbaa !29
  %t177 = load i64, ptr %t176
  %t179 = icmp eq i64 %t177, 6
  store i1 %t179, ptr %l99, !tbaa !21
  br label %bb57
bb57:
  %t180 = load i1, ptr %l99, !tbaa !21
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t183, i32 0, i32 1
  %t185 = load { i64, ptr }, ptr %t184
  store { i64, ptr } %t185, ptr %l10, !tbaa !27
  br label %bb64
bb59:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t188 = load ptr, ptr %l104, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb60, label %bb61
bb60:
  %t191 = load ptr, ptr %l104, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 19
  store i1 %t194, ptr %l105, !tbaa !21
  br label %bb61
bb61:
  %t195 = load i1, ptr %l105, !tbaa !21
  br i1 %t195, label %bb62, label %bb63
bb62:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t198, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199
  store { i64, ptr } %t200, ptr %l10, !tbaa !27
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t202 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t202)
  store %"compiler/source:Span" %t204, ptr %l111
  br label %bb65
bb65:
  %t205 = load %"compiler/source:Span", ptr %l111
  store %"compiler/source:Span" %t205, ptr %l26
  br label %bb163
bb66:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t207 = load ptr, ptr %l112, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb67, label %bb68
bb67:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t211 = load i64, ptr %t210
  %t213 = icmp eq i64 %t211, 7
  store i1 %t213, ptr %l113, !tbaa !21
  br label %bb68
bb68:
  %t214 = load i1, ptr %l113, !tbaa !21
  br i1 %t214, label %bb69, label %bb70
bb69:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l11, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t223, i32 0, i32 2
  %t225 = load { i64, ptr }, ptr %t224
  store { i64, ptr } %t225, ptr %l12, !tbaa !27
  br label %bb75
bb70:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb71, label %bb72
bb71:
  %t231 = load ptr, ptr %l120, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 10
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb72
bb72:
  %t235 = load i1, ptr %l121, !tbaa !21
  br i1 %t235, label %bb73, label %bb74
bb73:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t238, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l12, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t244, i32 0, i32 2
  %t246 = load ptr, ptr %t245
  store ptr %t246, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t248 = load ptr, ptr %l11, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t248)
  store %"compiler/source:Span" %t251, ptr %l130
  br label %bb76
bb76:
  %t252 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t254 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t252)
  store %"compiler/source:Span" %t254, ptr %l132
  br label %bb77
bb77:
  %t255 = load %"compiler/source:Span", ptr %l130
  %t256 = load %"compiler/source:Span", ptr %l132
  %t257 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t255, %"compiler/source:Span" %t256)
  store %"compiler/source:Span" %t257, ptr %l133
  br label %bb78
bb78:
  %t258 = load %"compiler/source:Span", ptr %l133
  store %"compiler/source:Span" %t258, ptr %l26
  br label %bb163
bb79:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t260 = load ptr, ptr %l134, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb80, label %bb81
bb80:
  %t263 = load ptr, ptr %l134, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 8
  store i1 %t266, ptr %l135, !tbaa !21
  br label %bb81
bb81:
  %t267 = load i1, ptr %l135, !tbaa !21
  br i1 %t267, label %bb82, label %bb83
bb82:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l13, !tbaa !29
  br label %bb84
bb83:
  br label %bb92
bb84:
  %t274 = load ptr, ptr %l13, !tbaa !29
  %t276 = getelementptr %"compiler/ast:For3", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t280 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t277)
  store %"compiler/source:Span" %t280, ptr %l143
  br label %bb85
bb85:
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t283 = getelementptr %"compiler/ast:For3", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t284)
  store %"compiler/source:Span" %t286, ptr %l146
  br label %bb86
bb86:
  %t287 = load %"compiler/source:Span", ptr %l143
  %t288 = load %"compiler/source:Span", ptr %l146
  %t289 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t287, %"compiler/source:Span" %t288)
  store %"compiler/source:Span" %t289, ptr %l147
  br label %bb87
bb87:
  %t290 = load ptr, ptr %l13, !tbaa !29
  %t292 = getelementptr %"compiler/ast:For3", ptr %t290, i32 0, i32 2
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t296 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t293)
  store %"compiler/source:Span" %t296, ptr %l151
  br label %bb88
bb88:
  %t297 = load ptr, ptr %l13, !tbaa !29
  %t299 = getelementptr %"compiler/ast:For3", ptr %t297, i32 0, i32 3
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  %t302 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t300)
  store %"compiler/source:Span" %t302, ptr %l154
  br label %bb89
bb89:
  %t303 = load %"compiler/source:Span", ptr %l151
  %t304 = load %"compiler/source:Span", ptr %l154
  %t305 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t303, %"compiler/source:Span" %t304)
  store %"compiler/source:Span" %t305, ptr %l155
  br label %bb90
bb90:
  %t306 = load %"compiler/source:Span", ptr %l147
  %t307 = load %"compiler/source:Span", ptr %l155
  %t308 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t306, %"compiler/source:Span" %t307)
  store %"compiler/source:Span" %t308, ptr %l156
  br label %bb91
bb91:
  %t309 = load %"compiler/source:Span", ptr %l156
  store %"compiler/source:Span" %t309, ptr %l26
  br label %bb163
bb92:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t311 = load ptr, ptr %l157, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb93, label %bb94
bb93:
  %t314 = load ptr, ptr %l157, !tbaa !29
  %t315 = load i64, ptr %t314
  %t317 = icmp eq i64 %t315, 9
  store i1 %t317, ptr %l158, !tbaa !21
  br label %bb94
bb94:
  %t318 = load i1, ptr %l158, !tbaa !21
  br i1 %t318, label %bb95, label %bb96
bb95:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr }, ptr %t321, i32 0, i32 1
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb103
bb97:
  %t325 = load ptr, ptr %l14, !tbaa !29
  %t327 = getelementptr %"compiler/ast:ForIn", ptr %t325, i32 0, i32 2
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t331 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t328)
  store %"compiler/source:Span" %t331, ptr %l166
  br label %bb98
bb98:
  %t332 = load ptr, ptr %l14, !tbaa !29
  %t334 = getelementptr %"compiler/ast:ForIn", ptr %t332, i32 0, i32 4
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t337 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t335)
  store %"compiler/source:Span" %t337, ptr %l169
  br label %bb99
bb99:
  %t338 = load %"compiler/source:Span", ptr %l166
  %t339 = load %"compiler/source:Span", ptr %l169
  %t340 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t338, %"compiler/source:Span" %t339)
  store %"compiler/source:Span" %t340, ptr %l170
  br label %bb100
bb100:
  %t341 = load ptr, ptr %l14, !tbaa !29
  %t343 = getelementptr %"compiler/ast:ForIn", ptr %t341, i32 0, i32 5
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t346 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCatches(ptr %v0, { i64, ptr } %t344)
  store %"compiler/source:Span" %t346, ptr %l173
  br label %bb101
bb101:
  %t347 = load %"compiler/source:Span", ptr %l170
  %t348 = load %"compiler/source:Span", ptr %l173
  %t349 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t347, %"compiler/source:Span" %t348)
  store %"compiler/source:Span" %t349, ptr %l174
  br label %bb102
bb102:
  %t350 = load %"compiler/source:Span", ptr %l174
  store %"compiler/source:Span" %t350, ptr %l26
  br label %bb163
bb103:
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t352 = load ptr, ptr %l175, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb104, label %bb105
bb104:
  %t355 = load ptr, ptr %l175, !tbaa !29
  %t356 = load i64, ptr %t355
  %t358 = icmp eq i64 %t356, 11
  store i1 %t358, ptr %l176, !tbaa !21
  br label %bb105
bb105:
  %t359 = load i1, ptr %l176, !tbaa !21
  br i1 %t359, label %bb106, label %bb107
bb106:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", ptr }, ptr %t362, i32 0, i32 1
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l15, !tbaa !29
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t366 = load ptr, ptr %l15, !tbaa !29
  %t368 = call %"compiler/source:Span" @compiler_2fast_2eyieldInMatch(ptr %v0, ptr %t366)
  store %"compiler/source:Span" %t368, ptr %l182
  br label %bb109
bb109:
  %t369 = load %"compiler/source:Span", ptr %l182
  store %"compiler/source:Span" %t369, ptr %l26
  br label %bb163
bb110:
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t371 = load ptr, ptr %l183, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb111, label %bb112
bb111:
  %t374 = load ptr, ptr %l183, !tbaa !29
  %t375 = load i64, ptr %t374
  %t377 = icmp eq i64 %t375, 12
  store i1 %t377, ptr %l184, !tbaa !21
  br label %bb112
bb112:
  %t378 = load i1, ptr %l184, !tbaa !21
  br i1 %t378, label %bb113, label %bb114
bb113:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t381, i32 0, i32 1
  %t383 = load { i64, ptr }, ptr %t382
  store { i64, ptr } %t383, ptr %l16, !tbaa !27
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t385 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t387 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t385)
  store %"compiler/source:Span" %t387, ptr %l190
  br label %bb116
bb116:
  %t388 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t388, ptr %l26
  br label %bb163
bb117:
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t390 = load ptr, ptr %l191, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb118, label %bb119
bb118:
  %t393 = load ptr, ptr %l191, !tbaa !29
  %t394 = load i64, ptr %t393
  %t396 = icmp eq i64 %t394, 14
  store i1 %t396, ptr %l192, !tbaa !21
  br label %bb119
bb119:
  %t397 = load i1, ptr %l192, !tbaa !21
  br i1 %t397, label %bb120, label %bb121
bb120:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l17, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l18, !tbaa !29
  br label %bb122
bb121:
  br label %bb126
bb122:
  %t410 = load ptr, ptr %l17, !tbaa !29
  %t413 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t410)
  store %"compiler/source:Span" %t413, ptr %l201
  br label %bb123
bb123:
  %t414 = load ptr, ptr %l18, !tbaa !29
  %t416 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t414)
  store %"compiler/source:Span" %t416, ptr %l203
  br label %bb124
bb124:
  %t417 = load %"compiler/source:Span", ptr %l201
  %t418 = load %"compiler/source:Span", ptr %l203
  %t419 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t417, %"compiler/source:Span" %t418)
  store %"compiler/source:Span" %t419, ptr %l204
  br label %bb125
bb125:
  %t420 = load %"compiler/source:Span", ptr %l204
  store %"compiler/source:Span" %t420, ptr %l26
  br label %bb163
bb126:
  %t421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t421, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t422 = load ptr, ptr %l205, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  br i1 %t423, label %bb127, label %bb128
bb127:
  %t425 = load ptr, ptr %l205, !tbaa !29
  %t426 = load i64, ptr %t425
  %t428 = icmp eq i64 %t426, 13
  store i1 %t428, ptr %l206, !tbaa !21
  br label %bb128
bb128:
  %t429 = load i1, ptr %l206, !tbaa !21
  br i1 %t429, label %bb129, label %bb130
bb129:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  %t433 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t432, i32 0, i32 2
  %t434 = load ptr, ptr %t433
  store ptr %t434, ptr %l19, !tbaa !29
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t436 = load ptr, ptr %l19, !tbaa !29
  %t438 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t436)
  store %"compiler/source:Span" %t438, ptr %l212
  br label %bb132
bb132:
  %t439 = load %"compiler/source:Span", ptr %l212
  store %"compiler/source:Span" %t439, ptr %l26
  br label %bb163
bb133:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t441 = load ptr, ptr %l213, !tbaa !29
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %bb134, label %bb135
bb134:
  %t444 = load ptr, ptr %l213, !tbaa !29
  %t445 = load i64, ptr %t444
  %t447 = icmp eq i64 %t445, 16
  store i1 %t447, ptr %l214, !tbaa !21
  br label %bb135
bb135:
  %t448 = load i1, ptr %l214, !tbaa !21
  br i1 %t448, label %bb136, label %bb137
bb136:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr { i64, [4 x i64] }, ptr %t449, i32 0, i32 1
  %t452 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t451, i32 0, i32 2
  %t453 = load ptr, ptr %t452
  store ptr %t453, ptr %l20, !tbaa !29
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t455 = load ptr, ptr %l20, !tbaa !29
  %t458 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t455)
  store %"compiler/source:Span" %t458, ptr %l221
  br label %bb139
bb139:
  %t459 = load %"compiler/source:Span", ptr %l221
  store %"compiler/source:Span" %t459, ptr %l26
  br label %bb163
bb140:
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t461 = load ptr, ptr %l222, !tbaa !29
  %t462 = icmp ne ptr %t461, null
  br i1 %t462, label %bb141, label %bb142
bb141:
  %t464 = load ptr, ptr %l222, !tbaa !29
  %t465 = load i64, ptr %t464
  %t467 = icmp eq i64 %t465, 17
  store i1 %t467, ptr %l223, !tbaa !21
  br label %bb142
bb142:
  %t468 = load i1, ptr %l223, !tbaa !21
  br i1 %t468, label %bb143, label %bb144
bb143:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr { i64, [4 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr }, ptr %t471, i32 0, i32 1
  %t473 = load ptr, ptr %t472
  store ptr %t473, ptr %l21, !tbaa !29
  br label %bb145
bb144:
  br label %bb149
bb145:
  %t475 = load ptr, ptr %l21, !tbaa !29
  %t477 = getelementptr %"compiler/ast:JoinS", ptr %t475, i32 0, i32 1
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  %t480 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t478)
  store %"compiler/source:Span" %t480, ptr %l230
  br label %bb146
bb146:
  %t481 = load ptr, ptr %l21, !tbaa !29
  %t483 = getelementptr %"compiler/ast:JoinS", ptr %t481, i32 0, i32 2
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  %t486 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCatches(ptr %v0, { i64, ptr } %t484)
  store %"compiler/source:Span" %t486, ptr %l233
  br label %bb147
bb147:
  %t487 = load %"compiler/source:Span", ptr %l230
  %t488 = load %"compiler/source:Span", ptr %l233
  %t489 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t487, %"compiler/source:Span" %t488)
  store %"compiler/source:Span" %t489, ptr %l234
  br label %bb148
bb148:
  %t490 = load %"compiler/source:Span", ptr %l234
  store %"compiler/source:Span" %t490, ptr %l26
  br label %bb163
bb149:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t492 = load ptr, ptr %l235, !tbaa !29
  %t493 = icmp ne ptr %t492, null
  br i1 %t493, label %bb150, label %bb151
bb150:
  %t495 = load ptr, ptr %l235, !tbaa !29
  %t496 = load i64, ptr %t495
  %t498 = icmp eq i64 %t496, 18
  store i1 %t498, ptr %l236, !tbaa !21
  br label %bb151
bb151:
  %t499 = load i1, ptr %l236, !tbaa !21
  br i1 %t499, label %bb152, label %bb153
bb152:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t502, i32 0, i32 1
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l22, !tbaa !29
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t506 = load ptr, ptr %l22, !tbaa !29
  %t509 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t506)
  store %"compiler/source:Span" %t509, ptr %l243
  br label %bb155
bb155:
  %t510 = load %"compiler/source:Span", ptr %l243
  store %"compiler/source:Span" %t510, ptr %l26
  br label %bb163
bb156:
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t512 = load ptr, ptr %l244, !tbaa !29
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %bb157, label %bb158
bb157:
  %t515 = load ptr, ptr %l244, !tbaa !29
  %t516 = load i64, ptr %t515
  %t518 = icmp eq i64 %t516, 15
  store i1 %t518, ptr %l245, !tbaa !21
  br label %bb158
bb158:
  %t519 = load i1, ptr %l245, !tbaa !21
  br i1 %t519, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb162
bb161:
  %t520 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t520, ptr %l26
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_cfce0b7e4832e85f_3aa2be1abc8ef6db)
  unreachable
bb163:
  %t522 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t522, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInCase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t4)
  store %"compiler/source:Span" %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Case", ptr %t7, i32 0, i32 4
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t10)
  store %"compiler/source:Span" %t12, ptr %l6
  br label %bb2
bb2:
  %t13 = load %"compiler/source:Span", ptr %l3
  %t14 = load %"compiler/source:Span", ptr %l6
  %t15 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t13, %"compiler/source:Span" %t14)
  store %"compiler/source:Span" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Case", ptr %t16, i32 0, i32 5
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l10
  br label %bb4
bb4:
  %t22 = load %"compiler/source:Span", ptr %l7
  %t23 = load %"compiler/source:Span", ptr %l10
  %t24 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t22, %"compiler/source:Span" %t23)
  store %"compiler/source:Span" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInCatches(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Catch", ptr %t31, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t34)
  store %"compiler/source:Span" %t36, ptr %l22
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Catch", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t40)
  store %"compiler/source:Span" %t42, ptr %l25
  br label %bb9
bb9:
  %t43 = load %"compiler/source:Span", ptr %l22
  %t44 = load %"compiler/source:Span", ptr %l25
  %t45 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t43, %"compiler/source:Span" %t44)
  store %"compiler/source:Span" %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t46, ptr %l5
  %t47 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = icmp sge i32 %t48, 0
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t52, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l2, !tbaa !24
  br label %bb4
bb15:
  %t58 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l97 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca ptr
  %l124 = alloca i1
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/source:Span"
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l163 = alloca i1
  %l174 = alloca %"compiler/source:Span"
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca ptr
  %l182 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l208 = alloca i1
  %l217 = alloca %"compiler/source:Span"
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca ptr
  %l222 = alloca i1
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca ptr
  %l230 = alloca i1
  %l238 = alloca %"compiler/source:Span"
  %l242 = alloca %"compiler/source:Span"
  %l243 = alloca %"compiler/source:Span"
  %l246 = alloca %"compiler/source:Span"
  %l247 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t8 = load ptr, ptr %l23, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 2
  store i1 %t14, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l24, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l1, !tbaa !29
  br label %bb20
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t23 = load ptr, ptr %l29, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l29, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l30, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l1, !tbaa !29
  br label %bb20
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t38 = load ptr, ptr %l35, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l35, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 4
  store i1 %t44, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l36, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l1, !tbaa !29
  br label %bb20
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t53 = load ptr, ptr %l41, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l41, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 15
  store i1 %t59, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l42, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l1, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t70 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t67)
  store %"compiler/source:Span" %t70, ptr %l49
  br label %bb21
bb21:
  %t71 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t71, ptr %l22
  br label %bb147
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t73 = load ptr, ptr %l50, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l50, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 9
  store i1 %t79, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l51, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t83, i32 0, i32 1
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l2, !tbaa !29
  br label %bb35
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t88 = load ptr, ptr %l56, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t92 = load i64, ptr %t91
  %t94 = icmp eq i64 %t92, 11
  store i1 %t94, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l57, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l2, !tbaa !29
  br label %bb35
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t103 = load ptr, ptr %l62, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t106 = load ptr, ptr %l62, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 14
  store i1 %t109, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t110 = load i1, ptr %l63, !tbaa !21
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t113, i32 0, i32 1
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l2, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t117)
  store %"compiler/source:Span" %t120, ptr %l70
  br label %bb36
bb36:
  %t121 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t121, ptr %l22
  br label %bb147
bb37:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t123 = load ptr, ptr %l71, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb38, label %bb39
bb38:
  %t126 = load ptr, ptr %l71, !tbaa !29
  %t127 = load i64, ptr %t126
  %t129 = icmp eq i64 %t127, 5
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb39
bb39:
  %t130 = load i1, ptr %l72, !tbaa !21
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t133, i32 0, i32 2
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l3, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t139, i32 0, i32 3
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l4, !tbaa !29
  br label %bb50
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t144 = load ptr, ptr %l79, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t147 = load ptr, ptr %l79, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 6
  store i1 %t150, ptr %l80, !tbaa !21
  br label %bb43
bb43:
  %t151 = load i1, ptr %l80, !tbaa !21
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t154, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l3, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l4, !tbaa !29
  br label %bb50
bb45:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb46, label %bb47
bb46:
  %t168 = load ptr, ptr %l87, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 10
  store i1 %t171, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t172 = load i1, ptr %l88, !tbaa !21
  br i1 %t172, label %bb48, label %bb49
bb48:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l3, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l4, !tbaa !29
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t188 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t185)
  store %"compiler/source:Span" %t188, ptr %l97
  br label %bb51
bb51:
  %t189 = load ptr, ptr %l4, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t189)
  store %"compiler/source:Span" %t192, ptr %l100
  br label %bb52
bb52:
  %t193 = load %"compiler/source:Span", ptr %l97
  %t194 = load %"compiler/source:Span", ptr %l100
  %t195 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t193, %"compiler/source:Span" %t194)
  store %"compiler/source:Span" %t195, ptr %l101
  br label %bb53
bb53:
  %t196 = load %"compiler/source:Span", ptr %l101
  store %"compiler/source:Span" %t196, ptr %l22
  br label %bb147
bb54:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb55, label %bb56
bb55:
  %t201 = load ptr, ptr %l102, !tbaa !29
  %t202 = load i64, ptr %t201
  %t204 = icmp eq i64 %t202, 8
  store i1 %t204, ptr %l103, !tbaa !21
  br label %bb56
bb56:
  %t205 = load i1, ptr %l103, !tbaa !21
  br i1 %t205, label %bb57, label %bb58
bb57:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr { i64, [5 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t208, i32 0, i32 1
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l5, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t214, i32 0, i32 2
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l6, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t220, i32 0, i32 3
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb65
bb59:
  %t224 = load ptr, ptr %l5, !tbaa !29
  %t227 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t224)
  store %"compiler/source:Span" %t227, ptr %l114
  br label %bb60
bb60:
  %t228 = load ptr, ptr %l6, !tbaa !29
  %t231 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t228)
  store %"compiler/source:Span" %t231, ptr %l117
  br label %bb61
bb61:
  %t232 = load %"compiler/source:Span", ptr %l114
  %t233 = load %"compiler/source:Span", ptr %l117
  %t234 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t232, %"compiler/source:Span" %t233)
  store %"compiler/source:Span" %t234, ptr %l118
  br label %bb62
bb62:
  %t235 = load ptr, ptr %l7, !tbaa !29
  %t238 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t235)
  store %"compiler/source:Span" %t238, ptr %l121
  br label %bb63
bb63:
  %t239 = load %"compiler/source:Span", ptr %l118
  %t240 = load %"compiler/source:Span", ptr %l121
  %t241 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t239, %"compiler/source:Span" %t240)
  store %"compiler/source:Span" %t241, ptr %l122
  br label %bb64
bb64:
  %t242 = load %"compiler/source:Span", ptr %l122
  store %"compiler/source:Span" %t242, ptr %l22
  br label %bb147
bb65:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t244 = load ptr, ptr %l123, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t247 = load ptr, ptr %l123, !tbaa !29
  %t248 = load i64, ptr %t247
  %t250 = icmp eq i64 %t248, 7
  store i1 %t250, ptr %l124, !tbaa !21
  br label %bb67
bb67:
  %t251 = load i1, ptr %l124, !tbaa !21
  br i1 %t251, label %bb68, label %bb69
bb68:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", ptr }, ptr %t254, i32 0, i32 1
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l8, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t258 = load ptr, ptr %l8, !tbaa !29
  %t260 = getelementptr %"compiler/ast:Chain", ptr %t258, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t263 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t261)
  store %"compiler/source:Span" %t263, ptr %l131
  br label %bb71
bb71:
  %t264 = load %"compiler/source:Span", ptr %l131
  store %"compiler/source:Span" %t264, ptr %l22
  br label %bb147
bb72:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t266 = load ptr, ptr %l132, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb73, label %bb74
bb73:
  %t269 = load ptr, ptr %l132, !tbaa !29
  %t270 = load i64, ptr %t269
  %t272 = icmp eq i64 %t270, 12
  store i1 %t272, ptr %l133, !tbaa !21
  br label %bb74
bb74:
  %t273 = load i1, ptr %l133, !tbaa !21
  br i1 %t273, label %bb75, label %bb76
bb75:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l9, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t282, i32 0, i32 2
  %t284 = load { i64, ptr }, ptr %t283
  store { i64, ptr } %t284, ptr %l10, !tbaa !27
  br label %bb85
bb76:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t287 = load ptr, ptr %l140, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb77, label %bb78
bb77:
  %t290 = load ptr, ptr %l140, !tbaa !29
  %t291 = load i64, ptr %t290
  %t293 = icmp eq i64 %t291, 13
  store i1 %t293, ptr %l141, !tbaa !21
  br label %bb78
bb78:
  %t294 = load i1, ptr %l141, !tbaa !21
  br i1 %t294, label %bb79, label %bb80
bb79:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l9, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t303, i32 0, i32 3
  %t305 = load { i64, ptr }, ptr %t304
  store { i64, ptr } %t305, ptr %l10, !tbaa !27
  br label %bb85
bb80:
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t308 = load ptr, ptr %l148, !tbaa !29
  %t309 = icmp ne ptr %t308, null
  br i1 %t309, label %bb81, label %bb82
bb81:
  %t311 = load ptr, ptr %l148, !tbaa !29
  %t312 = load i64, ptr %t311
  %t314 = icmp eq i64 %t312, 16
  store i1 %t314, ptr %l149, !tbaa !21
  br label %bb82
bb82:
  %t315 = load i1, ptr %l149, !tbaa !21
  br i1 %t315, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr { i64, [5 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t318, i32 0, i32 1
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l9, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t324, i32 0, i32 2
  %t326 = load { i64, ptr }, ptr %t325
  store { i64, ptr } %t326, ptr %l10, !tbaa !27
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t328 = load ptr, ptr %l9, !tbaa !29
  %t331 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t328)
  store %"compiler/source:Span" %t331, ptr %l158
  br label %bb86
bb86:
  %t332 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t334 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t332)
  store %"compiler/source:Span" %t334, ptr %l160
  br label %bb87
bb87:
  %t335 = load %"compiler/source:Span", ptr %l158
  %t336 = load %"compiler/source:Span", ptr %l160
  %t337 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t335, %"compiler/source:Span" %t336)
  store %"compiler/source:Span" %t337, ptr %l161
  br label %bb88
bb88:
  %t338 = load %"compiler/source:Span", ptr %l161
  store %"compiler/source:Span" %t338, ptr %l22
  br label %bb147
bb89:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t340 = load ptr, ptr %l162, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb90, label %bb91
bb90:
  %t343 = load ptr, ptr %l162, !tbaa !29
  %t344 = load i64, ptr %t343
  %t346 = icmp eq i64 %t344, 17
  store i1 %t346, ptr %l163, !tbaa !21
  br label %bb91
bb91:
  %t347 = load i1, ptr %l163, !tbaa !21
  br i1 %t347, label %bb92, label %bb93
bb92:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l11, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t356, i32 0, i32 2
  %t358 = load ptr, ptr %t357
  store ptr %t358, ptr %l12, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t362, i32 0, i32 3
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l13, !tbaa !29
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t366 = load ptr, ptr %l11, !tbaa !29
  %t369 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t366)
  store %"compiler/source:Span" %t369, ptr %l174
  br label %bb95
bb95:
  %t370 = load ptr, ptr %l12, !tbaa !29
  %t372 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t370)
  store %"compiler/source:Span" %t372, ptr %l176
  br label %bb96
bb96:
  %t373 = load %"compiler/source:Span", ptr %l174
  %t374 = load %"compiler/source:Span", ptr %l176
  %t375 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t373, %"compiler/source:Span" %t374)
  store %"compiler/source:Span" %t375, ptr %l177
  br label %bb97
bb97:
  %t376 = load ptr, ptr %l13, !tbaa !29
  %t378 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l179
  br label %bb98
bb98:
  %t379 = load %"compiler/source:Span", ptr %l177
  %t380 = load %"compiler/source:Span", ptr %l179
  %t381 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t379, %"compiler/source:Span" %t380)
  store %"compiler/source:Span" %t381, ptr %l180
  br label %bb99
bb99:
  %t382 = load %"compiler/source:Span", ptr %l180
  store %"compiler/source:Span" %t382, ptr %l22
  br label %bb147
bb100:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t384 = load ptr, ptr %l181, !tbaa !29
  %t385 = icmp ne ptr %t384, null
  br i1 %t385, label %bb101, label %bb102
bb101:
  %t387 = load ptr, ptr %l181, !tbaa !29
  %t388 = load i64, ptr %t387
  %t390 = icmp eq i64 %t388, 18
  store i1 %t390, ptr %l182, !tbaa !21
  br label %bb102
bb102:
  %t391 = load i1, ptr %l182, !tbaa !21
  br i1 %t391, label %bb103, label %bb104
bb103:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t394, i32 0, i32 2
  %t396 = load { i64, ptr }, ptr %t395
  store { i64, ptr } %t396, ptr %l14, !tbaa !27
  br label %bb117
bb104:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t399 = load ptr, ptr %l187, !tbaa !29
  %t400 = icmp ne ptr %t399, null
  br i1 %t400, label %bb105, label %bb106
bb105:
  %t402 = load ptr, ptr %l187, !tbaa !29
  %t403 = load i64, ptr %t402
  %t405 = icmp eq i64 %t403, 19
  store i1 %t405, ptr %l188, !tbaa !21
  br label %bb106
bb106:
  %t406 = load i1, ptr %l188, !tbaa !21
  br i1 %t406, label %bb107, label %bb108
bb107:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr { i64, [5 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t409, i32 0, i32 1
  %t411 = load { i64, ptr }, ptr %t410
  store { i64, ptr } %t411, ptr %l14, !tbaa !27
  br label %bb117
bb108:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t414 = load ptr, ptr %l193, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb109, label %bb110
bb109:
  %t417 = load ptr, ptr %l193, !tbaa !29
  %t418 = load i64, ptr %t417
  %t420 = icmp eq i64 %t418, 21
  store i1 %t420, ptr %l194, !tbaa !21
  br label %bb110
bb110:
  %t421 = load i1, ptr %l194, !tbaa !21
  br i1 %t421, label %bb111, label %bb112
bb111:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t424, i32 0, i32 1
  %t426 = load { i64, ptr }, ptr %t425
  store { i64, ptr } %t426, ptr %l14, !tbaa !27
  br label %bb117
bb112:
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t429 = load ptr, ptr %l199, !tbaa !29
  %t430 = icmp ne ptr %t429, null
  br i1 %t430, label %bb113, label %bb114
bb113:
  %t432 = load ptr, ptr %l199, !tbaa !29
  %t433 = load i64, ptr %t432
  %t435 = icmp eq i64 %t433, 25
  store i1 %t435, ptr %l200, !tbaa !21
  br label %bb114
bb114:
  %t436 = load i1, ptr %l200, !tbaa !21
  br i1 %t436, label %bb115, label %bb116
bb115:
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr { i64, [5 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t439, i32 0, i32 1
  %t441 = load { i64, ptr }, ptr %t440
  store { i64, ptr } %t441, ptr %l14, !tbaa !27
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t443 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t445 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %t443)
  store %"compiler/source:Span" %t445, ptr %l206
  br label %bb118
bb118:
  %t446 = load %"compiler/source:Span", ptr %l206
  store %"compiler/source:Span" %t446, ptr %l22
  br label %bb147
bb119:
  %t447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t447, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t448 = load ptr, ptr %l207, !tbaa !29
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %bb120, label %bb121
bb120:
  %t451 = load ptr, ptr %l207, !tbaa !29
  %t452 = load i64, ptr %t451
  %t454 = icmp eq i64 %t452, 22
  store i1 %t454, ptr %l208, !tbaa !21
  br label %bb121
bb121:
  %t455 = load i1, ptr %l208, !tbaa !21
  br i1 %t455, label %bb122, label %bb123
bb122:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t458, i32 0, i32 1
  %t460 = load ptr, ptr %t459
  store ptr %t460, ptr %l15, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t464, i32 0, i32 2
  %t466 = load { i64, ptr }, ptr %t465
  store { i64, ptr } %t466, ptr %l16, !tbaa !27
  br label %bb124
bb123:
  br label %bb128
bb124:
  %t468 = load ptr, ptr %l15, !tbaa !29
  %t471 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t468)
  store %"compiler/source:Span" %t471, ptr %l217
  br label %bb125
bb125:
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t474 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCatches(ptr %v0, { i64, ptr } %t472)
  store %"compiler/source:Span" %t474, ptr %l219
  br label %bb126
bb126:
  %t475 = load %"compiler/source:Span", ptr %l217
  %t476 = load %"compiler/source:Span", ptr %l219
  %t477 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t475, %"compiler/source:Span" %t476)
  store %"compiler/source:Span" %t477, ptr %l220
  br label %bb127
bb127:
  %t478 = load %"compiler/source:Span", ptr %l220
  store %"compiler/source:Span" %t478, ptr %l22
  br label %bb147
bb128:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t480 = load ptr, ptr %l221, !tbaa !29
  %t481 = icmp ne ptr %t480, null
  br i1 %t481, label %bb129, label %bb130
bb129:
  %t483 = load ptr, ptr %l221, !tbaa !29
  %t484 = load i64, ptr %t483
  %t486 = icmp eq i64 %t484, 24
  store i1 %t486, ptr %l222, !tbaa !21
  br label %bb130
bb130:
  %t487 = load i1, ptr %l222, !tbaa !21
  br i1 %t487, label %bb131, label %bb132
bb131:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", ptr }, ptr %t490, i32 0, i32 1
  %t492 = load ptr, ptr %t491
  store ptr %t492, ptr %l17, !tbaa !29
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t494 = load ptr, ptr %l17, !tbaa !29
  %t496 = call %"compiler/source:Span" @compiler_2fast_2eyieldInMatch(ptr %v0, ptr %t494)
  store %"compiler/source:Span" %t496, ptr %l228
  br label %bb134
bb134:
  %t497 = load %"compiler/source:Span", ptr %l228
  store %"compiler/source:Span" %t497, ptr %l22
  br label %bb147
bb135:
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t499 = load ptr, ptr %l229, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb136, label %bb137
bb136:
  %t502 = load ptr, ptr %l229, !tbaa !29
  %t503 = load i64, ptr %t502
  %t505 = icmp eq i64 %t503, 20
  store i1 %t505, ptr %l230, !tbaa !21
  br label %bb137
bb137:
  %t506 = load i1, ptr %l230, !tbaa !21
  br i1 %t506, label %bb138, label %bb139
bb138:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", ptr }, ptr %t509, i32 0, i32 1
  %t511 = load ptr, ptr %t510
  store ptr %t511, ptr %l18, !tbaa !29
  br label %bb140
bb139:
  br label %bb146
bb140:
  %t513 = load ptr, ptr %l18, !tbaa !29
  %t515 = getelementptr %"compiler/ast:Compr", ptr %t513, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t519 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t516)
  store %"compiler/source:Span" %t519, ptr %l238
  br label %bb141
bb141:
  %t520 = load ptr, ptr %l18, !tbaa !29
  %t522 = getelementptr %"compiler/ast:Compr", ptr %t520, i32 0, i32 4
  %t523 = load ptr, ptr %t522, !tbaa !29
  %t526 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t523)
  store %"compiler/source:Span" %t526, ptr %l242
  br label %bb142
bb142:
  %t527 = load %"compiler/source:Span", ptr %l238
  %t528 = load %"compiler/source:Span", ptr %l242
  %t529 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t527, %"compiler/source:Span" %t528)
  store %"compiler/source:Span" %t529, ptr %l243
  br label %bb143
bb143:
  %t530 = load ptr, ptr %l18, !tbaa !29
  %t532 = getelementptr %"compiler/ast:Compr", ptr %t530, i32 0, i32 5
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t535 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t533)
  store %"compiler/source:Span" %t535, ptr %l246
  br label %bb144
bb144:
  %t536 = load %"compiler/source:Span", ptr %l243
  %t537 = load %"compiler/source:Span", ptr %l246
  %t538 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t536, %"compiler/source:Span" %t537)
  store %"compiler/source:Span" %t538, ptr %l247
  br label %bb145
bb145:
  %t539 = load %"compiler/source:Span", ptr %l247
  store %"compiler/source:Span" %t539, ptr %l22
  br label %bb147
bb146:
  %t540 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t540, ptr %l22
  br label %bb147
bb147:
  %t542 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t542, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInExprs(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t34 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t29)
  store %"compiler/source:Span" %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = icmp sge i32 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  %t47 = load %"compiler/source:Span", ptr @G_2ecompiler_2fast_2eNoYield
  store %"compiler/source:Span" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInIf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l7 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t4)
  store %"compiler/source:Span" %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t7, ptr %l1
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = icmp slt i32 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/ast:If", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l7, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/ast:If", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f108e027b0d3370b_50be6dc1114317df)
  unreachable
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/ast:If", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Branch", ptr %t33, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t37)
  store %"compiler/source:Span" %t39, ptr %l19
  br label %bb10
bb10:
  %t40 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t40, ptr %l1
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l20
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/ast:If", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2eyieldIn(ptr %v0, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l23
  br label %bb12
bb12:
  %t48 = load %"compiler/source:Span", ptr %l20
  %t49 = load %"compiler/source:Span", ptr %l23
  %t50 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t48, %"compiler/source:Span" %t49)
  store %"compiler/source:Span" %t50, ptr %l24
  br label %bb13
bb13:
  %t51 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t51, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldInMatch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2eyieldInExpr(ptr %v0, ptr %t4)
  store %"compiler/source:Span" %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t8, ptr %l1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l21
  %t37 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCase(ptr %v0, ptr %t32)
  store %"compiler/source:Span" %t37, ptr %l23
  br label %bb6
bb6:
  %t38 = load %"compiler/source:Span", ptr %l21
  %t39 = load %"compiler/source:Span", ptr %l23
  %t40 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t38, %"compiler/source:Span" %t39)
  store %"compiler/source:Span" %t40, ptr %l24
  br label %bb7
bb7:
  %t41 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t41, ptr %l1
  br label %bb8
bb8:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l3, !tbaa !24
  br label %bb2
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Match", ptr %t46, i32 0, i32 4
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t55, ptr %l31
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Match", ptr %t56, i32 0, i32 4
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb12, label %bb13
bb11:
  br label %bb17
bb12:
  call void @__olang_check_failed(ptr @olang_loc_26f44abf4a087cb_1b5420f35f3adcaf)
  unreachable
bb13:
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Match", ptr %t63, i32 0, i32 4
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call %"compiler/source:Span" @compiler_2fast_2eyieldInCase(ptr %v0, ptr %t66)
  store %"compiler/source:Span" %t68, ptr %l37
  br label %bb15
bb15:
  %t69 = load %"compiler/source:Span", ptr %l31
  %t70 = load %"compiler/source:Span", ptr %l37
  %t71 = call %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %t69, %"compiler/source:Span" %t70)
  store %"compiler/source:Span" %t71, ptr %l38
  br label %bb16
bb16:
  %t72 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t72, ptr %l1
  br label %bb17
bb17:
  %t73 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2eyieldOr(%"compiler/source:Span" %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp sge i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t6, ptr %l4
  br label %bb3
bb2:
  store %"compiler/source:Span" %a1, ptr %l4
  br label %bb3
bb3:
  %t10 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:Branch"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:Branch" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:Branch" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:Branch" %t10, i64 %a2, 2
  store %"compiler/ast:Branch" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Branch", ptr %rv
  ret %"compiler/ast:Branch" %rr
}

define dso_local %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:CaseDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:CaseDecl" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/ast:CaseDecl" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/ast:CaseDecl" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/ast:CaseDecl" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/ast:CaseDecl" %t18, ptr %a4, 4
  store %"compiler/ast:CaseDecl" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:CaseDecl", ptr %rv
  ret %"compiler/ast:CaseDecl" %rr
}

define dso_local %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:Case"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:Case" undef, %"compiler/source:Span" %a0, 0
  %t16 = insertvalue %"compiler/ast:Case" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/ast:Case" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/ast:Case" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/ast:Case" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:Case" %t22, ptr %a5, 5
  store %"compiler/ast:Case" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Case", ptr %rv
  ret %"compiler/ast:Case" %rr
}

define dso_local %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %rv = alloca %"compiler/ast:Catch"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/ast:Catch" undef, %"compiler/source:Span" %a0, 0
  %t18 = insertvalue %"compiler/ast:Catch" %t16, { i64, ptr } %a1, 1
  %t20 = insertvalue %"compiler/ast:Catch" %t18, { i64, ptr } %a2, 2
  %t22 = insertvalue %"compiler/ast:Catch" %t20, { i64, ptr } %a3, 3
  %t24 = insertvalue %"compiler/ast:Catch" %t22, i1 %a4, 4
  %t26 = insertvalue %"compiler/ast:Catch" %t24, i32 %a5, 5
  %t28 = insertvalue %"compiler/ast:Catch" %t26, %"compiler/source:Span" %a6, 6
  store %"compiler/ast:Catch" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Catch", ptr %rv
  ret %"compiler/ast:Catch" %rr
}

define dso_local %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/ast:Chain"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/ast:Chain" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/ast:Chain" %t6, { i64, ptr } %a1, 1
  store %"compiler/ast:Chain" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Chain", ptr %rv
  ret %"compiler/ast:Chain" %rr
}

define dso_local %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5, i1 %a6, i64 %a7) #0 {
entry:
  %rv = alloca %"compiler/ast:Compr"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/ast:Compr" undef, ptr %a0, 0
  %t20 = insertvalue %"compiler/ast:Compr" %t18, ptr %a1, 1
  %t22 = insertvalue %"compiler/ast:Compr" %t20, i32 %a2, 2
  %t24 = insertvalue %"compiler/ast:Compr" %t22, i32 %a3, 3
  %t26 = insertvalue %"compiler/ast:Compr" %t24, ptr %a4, 4
  %t28 = insertvalue %"compiler/ast:Compr" %t26, ptr %a5, 5
  %t30 = insertvalue %"compiler/ast:Compr" %t28, i1 %a6, 6
  %t32 = insertvalue %"compiler/ast:Compr" %t30, i64 %a7, 7
  store %"compiler/ast:Compr" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Compr", ptr %rv
  ret %"compiler/ast:Compr" %rr
}

define dso_local %"compiler/ast:ContractBlock" @compiler_2fast_3aContractBlock_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:ContractBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:ContractBlock" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:ContractBlock" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:ContractBlock" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:ContractBlock" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:ContractBlock", ptr %rv
  ret %"compiler/ast:ContractBlock" %rr
}

define dso_local %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:For3"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:For3" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/ast:For3" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/ast:For3" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:For3" %t14, { i64, ptr } %a3, 3
  store %"compiler/ast:For3" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:For3", ptr %rv
  ret %"compiler/ast:For3" %rr
}

define dso_local %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:ForIn"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:ForIn" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/ast:ForIn" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/ast:ForIn" %t16, ptr %a2, 2
  %t20 = insertvalue %"compiler/ast:ForIn" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/ast:ForIn" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:ForIn" %t22, { i64, ptr } %a5, 5
  store %"compiler/ast:ForIn" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:ForIn", ptr %rv
  ret %"compiler/ast:ForIn" %rr
}

define dso_local %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6, i1 %a7) #0 {
entry:
  %rv = alloca %"compiler/ast:Func"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/ast:Func" undef, %"compiler/source:Span" %a0, 0
  %t20 = insertvalue %"compiler/ast:Func" %t18, ptr %a1, 1
  %t22 = insertvalue %"compiler/ast:Func" %t20, i32 %a2, 2
  %t24 = insertvalue %"compiler/ast:Func" %t22, ptr %a3, 3
  %t26 = insertvalue %"compiler/ast:Func" %t24, { i64, ptr } %a4, 4
  %t28 = insertvalue %"compiler/ast:Func" %t26, { i64, ptr } %a5, 5
  %t30 = insertvalue %"compiler/ast:Func" %t28, i1 %a6, 6
  %t32 = insertvalue %"compiler/ast:Func" %t30, i1 %a7, 7
  store %"compiler/ast:Func" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Func", ptr %rv
  ret %"compiler/ast:Func" %rr
}

define dso_local %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/ast:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/ast:If" %t10, ptr %a2, 2
  store %"compiler/ast:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:If", ptr %rv
  ret %"compiler/ast:If" %rr
}

define dso_local %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:JoinS"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:JoinS" undef, i1 %a0, 0
  %t10 = insertvalue %"compiler/ast:JoinS" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:JoinS" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:JoinS" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:JoinS", ptr %rv
  ret %"compiler/ast:JoinS" %rr
}

define dso_local %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:Match" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/ast:Match" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/ast:Match" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/ast:Match" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/ast:Match" %t18, ptr %a4, 4
  store %"compiler/ast:Match" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Match", ptr %rv
  ret %"compiler/ast:Match" %rr
}

define dso_local %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:Multi"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:Multi" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/ast:Multi" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/ast:Multi" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:Multi" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Multi", ptr %rv
  ret %"compiler/ast:Multi" %rr
}

define dso_local %"compiler/ast:Outlives" @compiler_2fast_3aOutlives_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:Outlives"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:Outlives" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:Outlives" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:Outlives" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:Outlives" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Outlives", ptr %rv
  ret %"compiler/ast:Outlives" %rr
}

define dso_local %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:Param"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:Param" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/ast:Param" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/ast:Param" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:Param" %t14, ptr %a3, 3
  store %"compiler/ast:Param" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Param", ptr %rv
  ret %"compiler/ast:Param" %rr
}

define dso_local %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/ast:Path"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/ast:Path" undef, %"compiler/source:Span" %a0, 0
  %t8 = insertvalue %"compiler/ast:Path" %t6, { i64, ptr } %a1, 1
  store %"compiler/ast:Path" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Path", ptr %rv
  ret %"compiler/ast:Path" %rr
}

define dso_local %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, i1 %a6, i1 %a7) #0 {
entry:
  %rv = alloca %"compiler/ast:Sig"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/ast:Sig" undef, { i64, ptr } %a0, 0
  %t20 = insertvalue %"compiler/ast:Sig" %t18, { i64, ptr } %a1, 1
  %t22 = insertvalue %"compiler/ast:Sig" %t20, i1 %a2, 2
  %t24 = insertvalue %"compiler/ast:Sig" %t22, { i64, ptr } %a3, 3
  %t26 = insertvalue %"compiler/ast:Sig" %t24, i1 %a4, 4
  %t28 = insertvalue %"compiler/ast:Sig" %t26, ptr %a5, 5
  %t30 = insertvalue %"compiler/ast:Sig" %t28, i1 %a6, 6
  %t32 = insertvalue %"compiler/ast:Sig" %t30, i1 %a7, 7
  store %"compiler/ast:Sig" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Sig", ptr %rv
  ret %"compiler/ast:Sig" %rr
}

define dso_local %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:StructBody"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:StructBody" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/ast:StructBody" %t14, ptr %a1, 1
  %t18 = insertvalue %"compiler/ast:StructBody" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/ast:StructBody" %t18, %"compiler/source:Span" %a3, 3
  %t22 = insertvalue %"compiler/ast:StructBody" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:StructBody" %t22, { i64, ptr } %a5, 5
  store %"compiler/ast:StructBody" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:StructBody", ptr %rv
  ret %"compiler/ast:StructBody" %rr
}

define dso_local %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:TopBranch"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:TopBranch" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:TopBranch" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:TopBranch" %t10, i64 %a2, 2
  store %"compiler/ast:TopBranch" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopBranch", ptr %rv
  ret %"compiler/ast:TopBranch" %rr
}

define dso_local %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:TopIf"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:TopIf" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/ast:TopIf" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/ast:TopIf" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:TopIf" %t14, ptr %a3, 3
  store %"compiler/ast:TopIf" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopIf", ptr %rv
  ret %"compiler/ast:TopIf" %rr
}

define dso_local %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:TypeDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:TypeDecl" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/ast:TypeDecl" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/ast:TypeDecl" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/ast:TypeDecl" %t14, ptr %a3, 3
  store %"compiler/ast:TypeDecl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeDecl", ptr %rv
  ret %"compiler/ast:TypeDecl" %rr
}

define dso_local %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:TypeParam"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:TypeParam" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/ast:TypeParam" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/ast:TypeParam" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/ast:TypeParam" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/ast:TypeParam" %t18, i1 %a4, 4
  store %"compiler/ast:TypeParam" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeParam", ptr %rv
  ret %"compiler/ast:TypeParam" %rr
}

define dso_local %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:VarDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:VarDecl" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/ast:VarDecl" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/ast:VarDecl" %t16, ptr %a2, 2
  %t20 = insertvalue %"compiler/ast:VarDecl" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/ast:VarDecl" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/ast:VarDecl" %t22, i1 %a5, 5
  store %"compiler/ast:VarDecl" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:VarDecl", ptr %rv
  ret %"compiler/ast:VarDecl" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fast() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fast_2eNoYield_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @__olang_check_failed(ptr)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_55eca5e8e4fb6f87_b7588236e57371eb = external constant [0 x i8]
@olang_loc_8f7e387f76106e1a_528835e8df6db77e = external constant [0 x i8]
@olang_loc_2231a09e52c8bb46_65bd70f90f09695a = external constant [0 x i8]
@olang_loc_4ec53bb81943b275_46293089da537299 = external constant [0 x i8]
@olang_loc_cfce0b7e4832e85f_3aa2be1abc8ef6db = external constant [0 x i8]
@olang_loc_f108e027b0d3370b_50be6dc1114317df = external constant [0 x i8]
@olang_loc_26f44abf4a087cb_1b5420f35f3adcaf = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
