; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l8
  br label %bb123
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l46, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l47, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t124 = load ptr, ptr %l58, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l58, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l59, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l8
  br label %bb123
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t141 = load ptr, ptr %l65, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l65, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l66, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb57
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l72, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l72, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb57
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t171 = load ptr, ptr %l77, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l77, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l78, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l78, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb57
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t186 = load ptr, ptr %l83, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l83, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l84, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l84, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t200 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t200, ptr %l8
  br label %bb123
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t203 = load ptr, ptr %l90, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l90, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l91, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l91, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t218 = load ptr, ptr %l96, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l96, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l97, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l97, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t233 = load ptr, ptr %l102, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l102, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l103, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l103, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t248 = load ptr, ptr %l108, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l108, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l109, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l109, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l8
  br label %bb123
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t265 = load ptr, ptr %l115, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l115, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l116, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l116, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb93
bb80:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t280 = load ptr, ptr %l121, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb81, label %bb82
bb81:
  %t283 = load ptr, ptr %l121, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 18
  store i1 %t286, ptr %l122, !tbaa !21
  br label %bb82
bb82:
  %t287 = load i1, ptr %l122, !tbaa !21
  br i1 %t287, label %bb83, label %bb84
bb83:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t290, i32 0, i32 0
  %t292 = load %"compiler/source:Span", ptr %t291
  store %"compiler/source:Span" %t292, ptr %l5
  br label %bb93
bb84:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t295 = load ptr, ptr %l127, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l127, !tbaa !29
  %t299 = load i64, ptr %t298
  %t301 = icmp eq i64 %t299, 19
  store i1 %t301, ptr %l128, !tbaa !21
  br label %bb86
bb86:
  %t302 = load i1, ptr %l128, !tbaa !21
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l5
  br label %bb93
bb88:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t310 = load ptr, ptr %l133, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb89, label %bb90
bb89:
  %t313 = load ptr, ptr %l133, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 20
  store i1 %t316, ptr %l134, !tbaa !21
  br label %bb90
bb90:
  %t317 = load i1, ptr %l134, !tbaa !21
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 0
  %t322 = load %"compiler/source:Span", ptr %t321
  store %"compiler/source:Span" %t322, ptr %l5
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t324 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t324, ptr %l8
  br label %bb123
bb94:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t327 = load ptr, ptr %l140, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb95, label %bb96
bb95:
  %t330 = load ptr, ptr %l140, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 21
  store i1 %t333, ptr %l141, !tbaa !21
  br label %bb96
bb96:
  %t334 = load i1, ptr %l141, !tbaa !21
  br i1 %t334, label %bb97, label %bb98
bb97:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t337, i32 0, i32 0
  %t339 = load %"compiler/source:Span", ptr %t338
  store %"compiler/source:Span" %t339, ptr %l6
  br label %bb115
bb98:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t342 = load ptr, ptr %l146, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb99, label %bb100
bb99:
  %t345 = load ptr, ptr %l146, !tbaa !29
  %t346 = load i64, ptr %t345
  %t348 = icmp eq i64 %t346, 22
  store i1 %t348, ptr %l147, !tbaa !21
  br label %bb100
bb100:
  %t349 = load i1, ptr %l147, !tbaa !21
  br i1 %t349, label %bb101, label %bb102
bb101:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t352, i32 0, i32 0
  %t354 = load %"compiler/source:Span", ptr %t353
  store %"compiler/source:Span" %t354, ptr %l6
  br label %bb115
bb102:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t357 = load ptr, ptr %l152, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb103, label %bb104
bb103:
  %t360 = load ptr, ptr %l152, !tbaa !29
  %t361 = load i64, ptr %t360
  %t363 = icmp eq i64 %t361, 23
  store i1 %t363, ptr %l153, !tbaa !21
  br label %bb104
bb104:
  %t364 = load i1, ptr %l153, !tbaa !21
  br i1 %t364, label %bb105, label %bb106
bb105:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr }, ptr %t367, i32 0, i32 0
  %t369 = load %"compiler/source:Span", ptr %t368
  store %"compiler/source:Span" %t369, ptr %l6
  br label %bb115
bb106:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t372 = load ptr, ptr %l158, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb107, label %bb108
bb107:
  %t375 = load ptr, ptr %l158, !tbaa !29
  %t376 = load i64, ptr %t375
  %t378 = icmp eq i64 %t376, 24
  store i1 %t378, ptr %l159, !tbaa !21
  br label %bb108
bb108:
  %t379 = load i1, ptr %l159, !tbaa !21
  br i1 %t379, label %bb109, label %bb110
bb109:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", ptr }, ptr %t382, i32 0, i32 0
  %t384 = load %"compiler/source:Span", ptr %t383
  store %"compiler/source:Span" %t384, ptr %l6
  br label %bb115
bb110:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t387 = load ptr, ptr %l164, !tbaa !29
  %t388 = icmp ne ptr %t387, null
  br i1 %t388, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l164, !tbaa !29
  %t391 = load i64, ptr %t390
  %t393 = icmp eq i64 %t391, 25
  store i1 %t393, ptr %l165, !tbaa !21
  br label %bb112
bb112:
  %t394 = load i1, ptr %l165, !tbaa !21
  br i1 %t394, label %bb113, label %bb114
bb113:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr { i64, [5 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t397, i32 0, i32 0
  %t399 = load %"compiler/source:Span", ptr %t398
  store %"compiler/source:Span" %t399, ptr %l6
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t401 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t401, ptr %l8
  br label %bb123
bb116:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t404 = load ptr, ptr %l171, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb117, label %bb118
bb117:
  %t407 = load ptr, ptr %l171, !tbaa !29
  %t408 = load i64, ptr %t407
  %t410 = icmp eq i64 %t408, 26
  store i1 %t410, ptr %l172, !tbaa !21
  br label %bb118
bb118:
  %t411 = load i1, ptr %l172, !tbaa !21
  br i1 %t411, label %bb119, label %bb120
bb119:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr { i64, [5 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span" }, ptr %t414, i32 0, i32 0
  %t416 = load %"compiler/source:Span", ptr %t415
  store %"compiler/source:Span" %t416, ptr %l7
  br label %bb121
bb120:
  br label %bb122
bb121:
  %t418 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t418, ptr %l8
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_55eca5e8e4fb6f87_b7588236e57371eb)
  unreachable
bb123:
  %t420 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t420, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb25
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l3
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8f7e387f76106e1a_528835e8df6db77e)
  unreachable
bb25:
  %t80 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb91
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb39
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb39
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb39
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb39
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l56, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l57, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l6
  br label %bb91
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb61
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb61
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb61
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l81, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l82, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb61
bb56:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t201 = load ptr, ptr %l87, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l87, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 13
  store i1 %t207, ptr %l88, !tbaa !21
  br label %bb58
bb58:
  %t208 = load i1, ptr %l88, !tbaa !21
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l3
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t215 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t215, ptr %l6
  br label %bb91
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb83
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb83
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb83
bb74:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t263 = load ptr, ptr %l112, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb75, label %bb76
bb75:
  %t266 = load ptr, ptr %l112, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 17
  store i1 %t269, ptr %l113, !tbaa !21
  br label %bb76
bb76:
  %t270 = load i1, ptr %l113, !tbaa !21
  br i1 %t270, label %bb77, label %bb78
bb77:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 0
  %t275 = load %"compiler/source:Span", ptr %t274
  store %"compiler/source:Span" %t275, ptr %l4
  br label %bb83
bb78:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t278 = load ptr, ptr %l118, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb79, label %bb80
bb79:
  %t281 = load ptr, ptr %l118, !tbaa !29
  %t282 = load i64, ptr %t281
  %t284 = icmp eq i64 %t282, 18
  store i1 %t284, ptr %l119, !tbaa !21
  br label %bb80
bb80:
  %t285 = load i1, ptr %l119, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 0
  %t290 = load %"compiler/source:Span", ptr %t289
  store %"compiler/source:Span" %t290, ptr %l4
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t292 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t292, ptr %l6
  br label %bb91
bb84:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t295 = load ptr, ptr %l125, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb85, label %bb86
bb85:
  %t298 = load ptr, ptr %l125, !tbaa !29
  %t299 = load i64, ptr %t298
  %t301 = icmp eq i64 %t299, 19
  store i1 %t301, ptr %l126, !tbaa !21
  br label %bb86
bb86:
  %t302 = load i1, ptr %l126, !tbaa !21
  br i1 %t302, label %bb87, label %bb88
bb87:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 0
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l5
  br label %bb89
bb88:
  br label %bb90
bb89:
  %t309 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t309, ptr %l6
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_2231a09e52c8bb46_65bd70f90f09695a)
  unreachable
bb91:
  %t311 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t311, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l3
  br label %bb25
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l2
  br label %bb23
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l24, !tbaa !21
  br label %bb16
bb16:
  %t56 = load i1, ptr %l24, !tbaa !21
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l2
  br label %bb23
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l3
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4ec53bb81943b275_46293089da537299)
  unreachable
bb25:
  %t80 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:Branch"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:Branch" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:Branch" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:Branch" %t10, i64 %a2, 2
  store %"compiler/ast:Branch" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Branch", ptr %rv
  ret %"compiler/ast:Branch" %rr
}

define dso_local %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:CaseDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:CaseDecl" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/ast:CaseDecl" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/ast:CaseDecl" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/ast:CaseDecl" %t14, i1 %a3, 3
  store %"compiler/ast:CaseDecl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:CaseDecl", ptr %rv
  ret %"compiler/ast:CaseDecl" %rr
}

define dso_local %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:Case"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:Case" undef, %"compiler/source:Span" %a0, 0
  %t16 = insertvalue %"compiler/ast:Case" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/ast:Case" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/ast:Case" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/ast:Case" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:Case" %t22, ptr %a5, 5
  store %"compiler/ast:Case" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Case", ptr %rv
  ret %"compiler/ast:Case" %rr
}

define dso_local %"compiler/ast:Catch" @compiler_2fast_3aCatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:Catch"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:Catch" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/ast:Catch" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/ast:Catch" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/ast:Catch" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/ast:Catch" %t18, i1 %a4, 4
  store %"compiler/ast:Catch" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Catch", ptr %rv
  ret %"compiler/ast:Catch" %rr
}

define dso_local %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/ast:Chain"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/ast:Chain" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/ast:Chain" %t6, { i64, ptr } %a1, 1
  store %"compiler/ast:Chain" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Chain", ptr %rv
  ret %"compiler/ast:Chain" %rr
}

define dso_local %"compiler/ast:Compr" @compiler_2fast_3aCompr_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:Compr"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:Compr" undef, ptr %a0, 0
  %t16 = insertvalue %"compiler/ast:Compr" %t14, ptr %a1, 1
  %t18 = insertvalue %"compiler/ast:Compr" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/ast:Compr" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/ast:Compr" %t20, ptr %a4, 4
  %t24 = insertvalue %"compiler/ast:Compr" %t22, ptr %a5, 5
  store %"compiler/ast:Compr" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Compr", ptr %rv
  ret %"compiler/ast:Compr" %rr
}

define dso_local %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:For3"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:For3" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/ast:For3" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/ast:For3" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:For3" %t14, { i64, ptr } %a3, 3
  store %"compiler/ast:For3" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:For3", ptr %rv
  ret %"compiler/ast:For3" %rr
}

define dso_local %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:ForIn"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:ForIn" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/ast:ForIn" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/ast:ForIn" %t16, ptr %a2, 2
  %t20 = insertvalue %"compiler/ast:ForIn" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/ast:ForIn" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:ForIn" %t22, { i64, ptr } %a5, 5
  store %"compiler/ast:ForIn" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:ForIn", ptr %rv
  ret %"compiler/ast:ForIn" %rr
}

define dso_local %"compiler/ast:Func" @compiler_2fast_3aFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, ptr %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6) #0 {
entry:
  %rv = alloca %"compiler/ast:Func"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/ast:Func" undef, %"compiler/source:Span" %a0, 0
  %t18 = insertvalue %"compiler/ast:Func" %t16, ptr %a1, 1
  %t20 = insertvalue %"compiler/ast:Func" %t18, i32 %a2, 2
  %t22 = insertvalue %"compiler/ast:Func" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/ast:Func" %t22, { i64, ptr } %a4, 4
  %t26 = insertvalue %"compiler/ast:Func" %t24, { i64, ptr } %a5, 5
  %t28 = insertvalue %"compiler/ast:Func" %t26, i1 %a6, 6
  store %"compiler/ast:Func" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Func", ptr %rv
  ret %"compiler/ast:Func" %rr
}

define dso_local %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/ast:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/ast:If" %t10, ptr %a2, 2
  store %"compiler/ast:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:If", ptr %rv
  ret %"compiler/ast:If" %rr
}

define dso_local %"compiler/ast:JoinS" @compiler_2fast_3aJoinS_2ector(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:JoinS"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:JoinS" undef, i1 %a0, 0
  %t10 = insertvalue %"compiler/ast:JoinS" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:JoinS" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:JoinS" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:JoinS", ptr %rv
  ret %"compiler/ast:JoinS" %rr
}

define dso_local %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:Match" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/ast:Match" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/ast:Match" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/ast:Match" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/ast:Match" %t18, ptr %a4, 4
  store %"compiler/ast:Match" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Match", ptr %rv
  ret %"compiler/ast:Match" %rr
}

define dso_local %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:Multi"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:Multi" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/ast:Multi" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/ast:Multi" %t10, { i64, ptr } %a2, 2
  store %"compiler/ast:Multi" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Multi", ptr %rv
  ret %"compiler/ast:Multi" %rr
}

define dso_local %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:Param"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:Param" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/ast:Param" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/ast:Param" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:Param" %t14, ptr %a3, 3
  store %"compiler/ast:Param" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Param", ptr %rv
  ret %"compiler/ast:Param" %rr
}

define dso_local %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/ast:Path"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/ast:Path" undef, %"compiler/source:Span" %a0, 0
  %t8 = insertvalue %"compiler/ast:Path" %t6, { i64, ptr } %a1, 1
  store %"compiler/ast:Path" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Path", ptr %rv
  ret %"compiler/ast:Path" %rr
}

define dso_local %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/ast:Sig"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/ast:Sig" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/ast:Sig" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/ast:Sig" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/ast:Sig" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/ast:Sig" %t18, i1 %a4, 4
  store %"compiler/ast:Sig" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:Sig", ptr %rv
  ret %"compiler/ast:Sig" %rr
}

define dso_local %"compiler/ast:StructBody" @compiler_2fast_3aStructBody_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:StructBody"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:StructBody" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/ast:StructBody" %t14, ptr %a1, 1
  %t18 = insertvalue %"compiler/ast:StructBody" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/ast:StructBody" %t18, %"compiler/source:Span" %a3, 3
  %t22 = insertvalue %"compiler/ast:StructBody" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/ast:StructBody" %t22, { i64, ptr } %a5, 5
  store %"compiler/ast:StructBody" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:StructBody", ptr %rv
  ret %"compiler/ast:StructBody" %rr
}

define dso_local %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:TopBranch"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:TopBranch" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:TopBranch" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/ast:TopBranch" %t10, i64 %a2, 2
  store %"compiler/ast:TopBranch" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopBranch", ptr %rv
  ret %"compiler/ast:TopBranch" %rr
}

define dso_local %"compiler/ast:TopIf" @compiler_2fast_3aTopIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:TopIf"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:TopIf" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/ast:TopIf" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/ast:TopIf" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/ast:TopIf" %t14, ptr %a3, 3
  store %"compiler/ast:TopIf" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TopIf", ptr %rv
  ret %"compiler/ast:TopIf" %rr
}

define dso_local %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/ast:TypeDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/ast:TypeDecl" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/ast:TypeDecl" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/ast:TypeDecl" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/ast:TypeDecl" %t14, ptr %a3, 3
  store %"compiler/ast:TypeDecl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeDecl", ptr %rv
  ret %"compiler/ast:TypeDecl" %rr
}

define dso_local %"compiler/ast:TypeParam" @compiler_2fast_3aTypeParam_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, i32 %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/ast:TypeParam"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/ast:TypeParam" undef, %"compiler/source:Span" %a0, 0
  %t10 = insertvalue %"compiler/ast:TypeParam" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/ast:TypeParam" %t10, ptr %a2, 2
  store %"compiler/ast:TypeParam" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:TypeParam", ptr %rv
  ret %"compiler/ast:TypeParam" %rr
}

define dso_local %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/ast:VarDecl"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/ast:VarDecl" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/ast:VarDecl" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/ast:VarDecl" %t16, ptr %a2, 2
  %t20 = insertvalue %"compiler/ast:VarDecl" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/ast:VarDecl" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/ast:VarDecl" %t22, i1 %a5, 5
  store %"compiler/ast:VarDecl" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/ast:VarDecl", ptr %rv
  ret %"compiler/ast:VarDecl" %rr
}

declare void @__olang_check_failed(ptr)
@olang_loc_55eca5e8e4fb6f87_b7588236e57371eb = external constant [0 x i8]
@olang_loc_8f7e387f76106e1a_528835e8df6db77e = external constant [0 x i8]
@olang_loc_2231a09e52c8bb46_65bd70f90f09695a = external constant [0 x i8]
@olang_loc_4ec53bb81943b275_46293089da537299 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
