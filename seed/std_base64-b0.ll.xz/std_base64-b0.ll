; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
define dso_local { i32, { i64, ptr } } @std_2fbase64_2edecodeWith(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l86 = alloca { i64, ptr }
  %l90 = alloca i64
  %l111 = alloca i32
  %l123 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i1, ptr %l1, !tbaa !21
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = srem i64 %t9, 4
  %t13 = icmp ne i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb18
bb3:
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 61
  store i1 %t31, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t34, 1
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l36, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = sub i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = icmp eq i8 %t51, 61
  store i1 %t53, ptr %l35, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l35, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = sub i64 %t56, 1
  store i64 %t59, ptr %l2, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = srem i64 %t61, 4
  %t65 = icmp eq i64 %t63, 1
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t68 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = sdiv i64 %t69, 4
  %t73 = mul i64 %t71, 3
  store i64 %t73, ptr %l50, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  %t76 = srem i64 %t74, 4
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = srem i64 %t80, 4
  %t84 = sub i64 %t82, 1
  store i64 %t84, ptr %l54, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb24
bb24:
  %t86 = load i64, ptr %l50, !tbaa !24
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = add i64 %t86, %t87
  store i64 %t88, ptr %l58, !tbaa !24
  %t89 = load i64, ptr %l58, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = mul i64 %t92, 1
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  store i32 0, ptr %l5, !tbaa !64
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_9d7c8b50488313b1_ded88850fbd45e45)
  unreachable
bb27:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb32
bb29:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l68, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t126 = load i64, ptr %l68, !tbaa !24
  store i64 %t126, ptr %l65, !tbaa !24
  br label %bb32
bb32:
  %t127 = load i64, ptr %l65, !tbaa !24
  store i64 %t127, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb34, label %bb35
bb34:
  br label %bb45
bb35:
  br label %bb36
bb36:
  %t136 = load i64, ptr %l7, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  %t146 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t146, ptr %l86, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  %t152 = load i8, ptr %t151, !tbaa !32
  %t153 = load i1, ptr %l1, !tbaa !21
  %t156 = call i64 @std_2fbase64_2evalueOf(i8 %t152, i1 %t153)
  store i64 %t156, ptr %l90
  br label %bb37
bb37:
  %t157 = load i64, ptr %l90, !tbaa !24
  store i64 %t157, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t160 = icmp slt i64 %t158, 0
  br i1 %t160, label %bb38, label %bb39
bb38:
  %t163 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t163, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t164 = load i32, ptr %l5, !tbaa !64
  %t167 = shl i32 %t164, 6
  %t168 = load i64, ptr %l13, !tbaa !24
  %t170 = trunc i64 %t168 to i32
  %t173 = or i32 %t167, %t170
  store i32 %t173, ptr %l5, !tbaa !64
  %t175 = load i64, ptr %l6, !tbaa !24
  %t178 = add i64 %t175, 6
  store i64 %t178, ptr %l6, !tbaa !24
  %t180 = load i64, ptr %l6, !tbaa !24
  %t182 = icmp sge i64 %t180, 8
  br i1 %t182, label %bb41, label %bb42
bb41:
  %t184 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t184, 8
  store i64 %t187, ptr %l6, !tbaa !24
  %t189 = load i64, ptr %l4, !tbaa !24
  %t190 = load i32, ptr %l5, !tbaa !64
  %t191 = load i64, ptr %l6, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  store i32 %t193, ptr %l111, !tbaa !64
  %t195 = load i32, ptr %l111, !tbaa !64
  %t196 = load i32, ptr %l111, !tbaa !64
  %t197 = lshr i32 %t190, %t196
  %t199 = and i32 %t197, 255
  %t201 = trunc i32 %t199 to i8
  %t204 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i8, ptr %t205, i64 %t189
  store i8 %t201, ptr %t206, !tbaa !32
  %t207 = load i64, ptr %l4, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l4, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l11, !tbaa !24
  br label %bb33
bb45:
  %t217 = load i32, ptr %l5, !tbaa !64
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  store i32 %t220, ptr %l123, !tbaa !64
  %t221 = load i32, ptr %l123, !tbaa !64
  %t222 = load i32, ptr %l123, !tbaa !64
  %t223 = shl i32 1, %t222
  %t225 = sub i32 %t223, 1
  %t228 = and i32 %t217, %t225
  %t230 = icmp ne i32 %t228, 0
  br i1 %t230, label %bb46, label %bb47
bb46:
  %t233 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t233, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t234 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t236 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t234, 1
  store { i32, { i64, ptr } } %t236, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fbase64_2eencodeWith(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l27 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = sdiv i64 %t3, 3
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = srem i64 %t9, 3
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = mul i64 %t13, 4
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l5, !tbaa !24
  store i64 %t21, ptr %l27, !tbaa !24
  %t23 = load i1, ptr %l2, !tbaa !21
  br i1 %t23, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  store i64 4, ptr %l29, !tbaa !24
  br label %bb5
bb4:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l29, !tbaa !24
  %t31 = add i64 %t29, %t30
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  store i64 %t33, ptr %l33, !tbaa !24
  %t34 = load i64, ptr %l33, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l33, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t42, ptr %lp6
  %t44 = load ptr, ptr %lp6
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f1284a202a21fb9_a1ae73835ae6823d)
  unreachable
bb9:
  %t53 = load i64, ptr %l10, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t73 = load i64, ptr %l43, !tbaa !24
  store i64 %t73, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l40, !tbaa !24
  store i64 %t74, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l11, !tbaa !24
  %t76 = sub i64 %t75, 1
  store i64 %t76, ptr %l52, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = icmp slt i64 %t77, 2147483648
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  %t83 = and i1 %t78, %t80
  store i1 %t83, ptr %l55, !tbaa !21
  br label %bb15
bb15:
  %t84 = load i64, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l12, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t100 = add i64 %t92, %t97
  store i64 %t100, ptr %l13, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t102, ptr %l65, !tbaa !27
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = mul i64 3, %t103
  %t107 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t105
  %t110 = load i8, ptr %t109, !tbaa !32
  %t112 = zext i8 %t110 to i32
  %t114 = shl i32 %t112, 16
  %t115 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t115, ptr %l71, !tbaa !27
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = mul i64 3, %t116
  %t120 = add i64 %t118, 1
  %t122 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = zext i8 %t125 to i32
  %t129 = shl i32 %t127, 8
  %t132 = or i32 %t114, %t129
  %t133 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l13, !tbaa !24
  %t136 = mul i64 3, %t134
  %t138 = add i64 %t136, 2
  %t140 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i8, ptr %t141, i64 %t138
  %t143 = load i8, ptr %t142, !tbaa !32
  %t145 = zext i8 %t143 to i32
  %t148 = or i32 %t132, %t145
  store i32 %t148, ptr %l14, !tbaa !64
  %t150 = load i64, ptr %l7, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t151, ptr %l87, !tbaa !27
  %t152 = load i32, ptr %l14, !tbaa !64
  %t154 = lshr i32 %t152, 18
  %t156 = zext i32 %t154 to i64
  %t157 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t156
  %t160 = load i8, ptr %t159, !tbaa !32
  %t162 = load ptr, ptr %lp6
  %t164 = getelementptr { i64, ptr }, ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i8, ptr %t165, i64 %t150
  store i8 %t160, ptr %t166, !tbaa !32
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = add i64 %t167, 1
  %t170 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t170, ptr %l93, !tbaa !27
  %t171 = load i32, ptr %l14, !tbaa !64
  %t173 = lshr i32 %t171, 12
  %t175 = and i32 %t173, 63
  %t177 = zext i32 %t175 to i64
  %t178 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i8, ptr %t179, i64 %t177
  %t181 = load i8, ptr %t180, !tbaa !32
  %t183 = load ptr, ptr %lp6
  %t185 = getelementptr { i64, ptr }, ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t169
  store i8 %t181, ptr %t187, !tbaa !32
  %t188 = load i64, ptr %l7, !tbaa !24
  %t190 = add i64 %t188, 2
  %t191 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t191, ptr %l100, !tbaa !27
  %t192 = load i32, ptr %l14, !tbaa !64
  %t194 = lshr i32 %t192, 6
  %t196 = and i32 %t194, 63
  %t198 = zext i32 %t196 to i64
  %t199 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 %t198
  %t202 = load i8, ptr %t201, !tbaa !32
  %t204 = load ptr, ptr %lp6
  %t206 = getelementptr { i64, ptr }, ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i8, ptr %t207, i64 %t190
  store i8 %t202, ptr %t208, !tbaa !32
  %t209 = load i64, ptr %l7, !tbaa !24
  %t211 = add i64 %t209, 3
  %t212 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t212, ptr %l107, !tbaa !27
  %t213 = load i32, ptr %l14, !tbaa !64
  %t215 = and i32 %t213, 63
  %t217 = zext i32 %t215 to i64
  %t218 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t217
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = load ptr, ptr %lp6
  %t225 = getelementptr { i64, ptr }, ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i8, ptr %t226, i64 %t211
  store i8 %t221, ptr %t227, !tbaa !32
  %t228 = load i64, ptr %l7, !tbaa !24
  %t231 = add i64 %t228, 4
  store i64 %t231, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  %t233 = load i64, ptr %l12, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l12, !tbaa !24
  br label %bb15
bb20:
  %t238 = load i64, ptr %l4, !tbaa !24
  %t240 = icmp sgt i64 %t238, 0
  br i1 %t240, label %bb21, label %bb22
bb21:
  %t242 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t242, ptr %l119, !tbaa !27
  %t243 = load i64, ptr %l3, !tbaa !24
  %t245 = mul i64 3, %t243
  %t247 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i8, ptr %t248, i64 %t245
  %t250 = load i8, ptr %t249, !tbaa !32
  %t252 = zext i8 %t250 to i32
  %t254 = shl i32 %t252, 16
  store i32 %t254, ptr %l15, !tbaa !64
  %t256 = load i64, ptr %l4, !tbaa !24
  %t258 = icmp eq i64 %t256, 2
  br i1 %t258, label %bb23, label %bb24
bb22:
  br label %bb35
bb23:
  %t260 = load i32, ptr %l15, !tbaa !64
  %t262 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t262, ptr %l129, !tbaa !27
  %t263 = load i64, ptr %l3, !tbaa !24
  %t265 = mul i64 3, %t263
  %t267 = add i64 %t265, 1
  %t269 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t267
  %t272 = load i8, ptr %t271, !tbaa !32
  %t274 = zext i8 %t272 to i32
  %t276 = shl i32 %t274, 8
  %t279 = or i32 %t260, %t276
  store i32 %t279, ptr %l15, !tbaa !64
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t281 = load i64, ptr %l7, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t282, ptr %l138, !tbaa !27
  %t283 = load i32, ptr %l15, !tbaa !64
  %t285 = lshr i32 %t283, 18
  %t287 = zext i32 %t285 to i64
  %t288 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr i8, ptr %t289, i64 %t287
  %t291 = load i8, ptr %t290, !tbaa !32
  %t293 = load ptr, ptr %lp6
  %t295 = getelementptr { i64, ptr }, ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i8, ptr %t296, i64 %t281
  store i8 %t291, ptr %t297, !tbaa !32
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = add i64 %t298, 1
  %t301 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t301, ptr %l144, !tbaa !27
  %t302 = load i32, ptr %l15, !tbaa !64
  %t304 = lshr i32 %t302, 12
  %t306 = and i32 %t304, 63
  %t308 = zext i32 %t306 to i64
  %t309 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr i8, ptr %t310, i64 %t308
  %t312 = load i8, ptr %t311, !tbaa !32
  %t314 = load ptr, ptr %lp6
  %t316 = getelementptr { i64, ptr }, ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr i8, ptr %t317, i64 %t300
  store i8 %t312, ptr %t318, !tbaa !32
  %t319 = load i64, ptr %l4, !tbaa !24
  %t321 = icmp eq i64 %t319, 2
  br i1 %t321, label %bb26, label %bb27
bb26:
  %t323 = load i64, ptr %l7, !tbaa !24
  %t325 = add i64 %t323, 2
  %t326 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t326, ptr %l153, !tbaa !27
  %t327 = load i32, ptr %l15, !tbaa !64
  %t329 = lshr i32 %t327, 6
  %t331 = and i32 %t329, 63
  %t333 = zext i32 %t331 to i64
  %t334 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t333
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = load ptr, ptr %lp6
  %t341 = getelementptr { i64, ptr }, ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i8, ptr %t342, i64 %t325
  store i8 %t337, ptr %t343, !tbaa !32
  br label %bb31
bb27:
  %t344 = load i1, ptr %l2, !tbaa !21
  br i1 %t344, label %bb28, label %bb29
bb28:
  %t346 = load i64, ptr %l7, !tbaa !24
  %t348 = add i64 %t346, 2
  %t349 = load ptr, ptr %lp6
  %t351 = getelementptr { i64, ptr }, ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i8, ptr %t352, i64 %t348
  store i8 61, ptr %t353, !tbaa !32
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t354 = load i1, ptr %l2, !tbaa !21
  br i1 %t354, label %bb32, label %bb33
bb32:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t358 = add i64 %t356, 3
  %t359 = load ptr, ptr %lp6
  %t361 = getelementptr { i64, ptr }, ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr i8, ptr %t362, i64 %t358
  store i8 61, ptr %t363, !tbaa !32
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t364 = load ptr, ptr %lp6
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  store { i64, ptr } %t365, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fbase64_2evalueOf(i8 %a0, i1 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i1
  %l4 = alloca i1
  %l12 = alloca i1
  %l21 = alloca i1
  %l28 = alloca i8
  %l30 = alloca i8
  %l33 = alloca i8
  %l35 = alloca i8
  %rv = alloca i64
  store i8 %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 65
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 90
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = sub i8 %t10, 65
  %t14 = zext i8 %t12 to i64
  store i64 %t14, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load i8, ptr %l0, !tbaa !22
  %t18 = icmp uge i8 %t16, 97
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp ule i8 %t20, 122
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = sub i8 %t25, 97
  %t29 = zext i8 %t27 to i64
  %t31 = add i64 %t29, 26
  store i64 %t31, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load i8, ptr %l0, !tbaa !22
  %t35 = icmp uge i8 %t33, 48
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load i8, ptr %l0, !tbaa !22
  %t39 = icmp ule i8 %t37, 57
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load i8, ptr %l0, !tbaa !22
  %t44 = sub i8 %t42, 48
  %t46 = zext i8 %t44 to i64
  %t48 = add i64 %t46, 52
  store i64 %t48, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t50 = load i8, ptr %l0, !tbaa !22
  store i8 %t50, ptr %l28, !tbaa !22
  %t51 = load i1, ptr %l1, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i8 45, ptr %l30, !tbaa !22
  br label %bb21
bb20:
  store i8 43, ptr %l30, !tbaa !22
  br label %bb21
bb21:
  %t53 = load i8, ptr %l28, !tbaa !22
  %t54 = load i8, ptr %l30, !tbaa !22
  %t55 = icmp eq i8 %t53, %t54
  br i1 %t55, label %bb22, label %bb23
bb22:
  store i64 62, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t58 = load i8, ptr %l0, !tbaa !22
  store i8 %t58, ptr %l33, !tbaa !22
  %t59 = load i1, ptr %l1, !tbaa !21
  br i1 %t59, label %bb25, label %bb26
bb25:
  store i8 95, ptr %l35, !tbaa !22
  br label %bb27
bb26:
  store i8 47, ptr %l35, !tbaa !22
  br label %bb27
bb27:
  %t61 = load i8, ptr %l33, !tbaa !22
  %t62 = load i8, ptr %l35, !tbaa !22
  %t63 = icmp eq i8 %t61, %t62
  br i1 %t63, label %bb28, label %bb29
bb28:
  store i64 63, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_9d7c8b50488313b1_ded88850fbd45e45 = external constant [0 x i8]
@olang_loc_3f1284a202a21fb9_a1ae73835ae6823d = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
