; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_78fb4d3249708b2_e3f9318f90ab6b26 = weak_odr constant [53 x i8] c"compiler/msgs.olang:2479: slice bounds out of range\0A\00"
@olang_loc_b5396abf9efe0c5f_c4bc3810cf304de3 = weak_odr constant [53 x i8] c"compiler/msgs.olang:1381: slice bounds out of range\0A\00"
@olang_loc_d2d351cc5daaf8b6_b531c4af6261323a = weak_odr constant [45 x i8] c"compiler/msgs.olang:86: unreachable reached\0A\00"
@olang_loc_d8715251471fb7e5_1e2086cef33ddcd1 = weak_odr constant [53 x i8] c"compiler/msgs.olang:1378: slice bounds out of range\0A\00"
@olang_loc_d93addea5b815da9_e849c161ff4e7de5 = weak_odr constant [51 x i8] c"compiler/msgs.olang:34: array length out of range\0A\00"
@olang_loc_fced1ba34c6512dc_349b310d7afbfd78 = weak_odr constant [51 x i8] c"compiler/msgs.olang:35: array length out of range\0A\00"
