; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_78fb4d3249708b2_e3f9318f90ab6b26 = weak_odr constant [53 x i8] c"compiler/msgs.olang:2111: slice bounds out of range\0A\00"
@olang_loc_d2d351cc5daaf8b6_b531c4af6261323a = weak_odr constant [45 x i8] c"compiler/msgs.olang:40: unreachable reached\0A\00"
