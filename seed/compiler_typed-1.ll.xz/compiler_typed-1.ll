; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i32, i1, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:argRoot" = type { i64, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Nodes" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:wordReader" = type { { i64, ptr }, { ptr, ptr }, i64 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
define dso_local ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 13
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Join", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_98ffd35c6a6991db_b4b9a5fbdbb15627)
  unreachable
bb23:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v0, ptr %v1, ptr %t16)
  store ptr %t18, ptr %l14
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l14, !tbaa !29
  store ptr %t19, ptr %l6, !tbaa !29
  br label %bb47
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 5
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Payload", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = call ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v0, ptr %v1, ptr %t38)
  store ptr %t40, ptr %l23
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l23, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  br label %bb47
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 4
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call i1 @compiler_2ftyped_2einert(ptr %v0, ptr %t60)
  store i1 %t62, ptr %l32
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Elem", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = call ptr @compiler_2ftyped_2eCall_2eQuietRead(ptr %v0, ptr %v1, ptr %t67)
  store ptr %t69, ptr %l36
  br label %bb23
bb22:
  store ptr null, ptr %l33, !tbaa !29
  br label %bb24
bb23:
  %t70 = load ptr, ptr %l36, !tbaa !29
  store ptr %t70, ptr %l33, !tbaa !29
  br label %bb24
bb24:
  %t71 = load ptr, ptr %l33, !tbaa !29
  store ptr %t71, ptr %l6, !tbaa !29
  br label %bb47
bb25:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t76 = load ptr, ptr %l37, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 6
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  %t87 = load ptr, ptr %l4, !tbaa !29
  store ptr %t87, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb31, label %bb32
bb31:
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 6
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb33, label %bb34
bb33:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l43, !tbaa !29
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store ptr null, ptr %l43, !tbaa !29
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_ab97fbd57ee6d83_6d3fb4eb1c4ce94f)
  unreachable
bb41:
  %t105 = load ptr, ptr %l43, !tbaa !29
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_466792cdfa40bc02_3c21a4fe0416b90e)
  unreachable
bb47:
  %t106 = load ptr, ptr %l6, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 6
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l8, !tbaa !29
  br label %bb28
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Promote", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t43, 1
  %t48 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l27
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l27, !tbaa !29
  store ptr %t49, ptr %l8, !tbaa !29
  br label %bb28
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  %t71 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %t65, i64 %t68)
  store ptr %t71, ptr %l37
  br label %bb22
bb22:
  %t72 = load ptr, ptr %l37, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store ptr null, ptr %l8, !tbaa !29
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_22aea6a044f95e17_c10e152cae22b18b)
  unreachable
bb28:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l17
  br label %bb11
bb11:
  %t34 = load i1, ptr %l17, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bf16ba0368763d37_f19ef32b132443ab)
  unreachable
bb17:
  br label %bb30
bb18:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb20
bb20:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb21, label %bb22
bb21:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb24
bb24:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_af65136929bfae16_48f8be4437d6c6ea)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb39
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l17
  br label %bb12
bb12:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l5, !tbaa !21
  br label %bb39
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l26
  br label %bb19
bb19:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %l5, !tbaa !21
  br label %bb39
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l27, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l28, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l35
  br label %bb26
bb26:
  %t72 = load i1, ptr %l35, !tbaa !21
  store i1 %t72, ptr %l5, !tbaa !21
  br label %bb39
bb27:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t77 = load ptr, ptr %l36, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l37, !tbaa !21
  br label %bb29
bb29:
  %t81 = load i1, ptr %l37, !tbaa !21
  br i1 %t81, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l4, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = call i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l43
  br label %bb33
bb33:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l5, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b0232f0aa88d97cf_b0ec20639face60b)
  unreachable
bb39:
  %t92 = load i1, ptr %l5, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2ftyped_2emathNames, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l2
  store i64 31, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = getelementptr [31 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load ptr, ptr @__olang_prog_scope
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t24, { i64, ptr } %t22, { i64, ptr } %t23)
  store i1 %t27, ptr %l20
  br label %bb5
bb5:
  %t28 = load i1, ptr %l20, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  call void @olang_textcopy(ptr %t38, ptr %t34, i64 %t35)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t29, { i64, ptr } %t47)
  store i1 %t50, ptr %l26
  br label %bb8
bb8:
  %t51 = load i1, ptr %l26, !tbaa !21
  store i1 %t51, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t52 = load i1, ptr %l21, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = getelementptr [31 x i64], ptr @G_2ecompiler_2ftyped_2emathArity, i64 0, i64 %t54
  %t57 = load i64, ptr %t56, !tbaa !34
  %t60 = icmp eq i64 %a1, %t57
  store i1 %t60, ptr %l27, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ePartOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 4
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_62af31c5105aaa5b_ddb95177f2bf45e7)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l1, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l6, !tbaa !21
  br label %bb44
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 10
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Slice", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i1 @compiler_2ftyped_2eLocalRooted(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l29
  br label %bb17
bb17:
  %t56 = load i1, ptr %l29, !tbaa !21
  store i1 %t56, ptr %l6, !tbaa !21
  br label %bb44
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 9
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l31, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t68, i32 0, i32 2
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 51}
  store i32 %t70, ptr %l3
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t74, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  br label %bb23
bb22:
  br label %bb32
bb23:
  %t78 = load i32, ptr %l3, !range !{i32 0, i32 51}
  %t80 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t78)
  store i1 %t80, ptr %l39
  br label %bb24
bb24:
  %t81 = load i1, ptr %l39, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t86 = icmp sgt i64 %t84, 0
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l40, !tbaa !21
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l45, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 0
  %t93 = load ptr, ptr %t92, !tbaa !39
  %t95 = call i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %t93)
  store i1 %t95, ptr %l47
  br label %bb30
bb29:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb31
bb30:
  %t96 = load i1, ptr %l47, !tbaa !21
  store i1 %t96, ptr %l44, !tbaa !21
  br label %bb31
bb31:
  %t97 = load i1, ptr %l44, !tbaa !21
  store i1 %t97, ptr %l6, !tbaa !21
  br label %bb44
bb32:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t99 = load ptr, ptr %l48, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l48, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 17
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t106 = load i1, ptr %l49, !tbaa !21
  br i1 %t106, label %bb35, label %bb36
bb35:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = call i1 @compiler_2ftyped_2ePlaceRooted(ptr %v0, ptr %t113)
  store i1 %t115, ptr %l55
  br label %bb38
bb38:
  %t116 = load i1, ptr %l55, !tbaa !21
  store i1 %t116, ptr %l6, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_2b7320a535e51c63_682587c414220c47)
  unreachable
bb44:
  %t117 = load i1, ptr %l6, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load i32, ptr %l13, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 19 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = icmp eq i32 %t23, 0
  store i1 %t24, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 23 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = load i32, ptr %l27, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t66, i32 %t64)
  store i1 %t70, ptr %l40
  br label %bb19
bb19:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ecb034f719e18c1b_985175307bfdc34f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Arm", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l18
  br label %bb4
bb4:
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Arm", ptr %t20, i32 0, i32 4
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Arm", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l33, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Alt", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t59, i32 %t61)
  store i1 %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load i1, ptr %l40, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Alt", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t94 = getelementptr %"compiler/typed:Bind", ptr %t90, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t95, i32 %t97)
  store i1 %t100, ptr %l57
  br label %bb25
bb25:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb21
bb30:
  br label %bb31
bb31:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb13
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2earmsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %t28, i32 %a1)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t28, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l6
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l6
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_6690d985632b6de7_b13460b3c8232d4b)
  unreachable
bb83:
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l3, !tbaa !23
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l3, !tbaa !23
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l3, !tbaa !23
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l3, !tbaa !23
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load i32, ptr %l3, !tbaa !23
  store i32 %t185, ptr %l6, !tbaa !23
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l4, !tbaa !23
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l4, !tbaa !23
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l4, !tbaa !23
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l4, !tbaa !23
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l4, !tbaa !23
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l6, !tbaa !23
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l5, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t279 = load ptr, ptr %l5, !tbaa !29
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120, !tbaa !23
  store i32 %t282, ptr %l6, !tbaa !23
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57)
  unreachable
bb84:
  %t283 = load i32, ptr %l6, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/typed:landState"
  %l3 = alloca %"compiler/typed:landState"
  %l9 = alloca %"compiler/typed:landState"
  %l15 = alloca %"compiler/typed:landState"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:If", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t9)
  store %"compiler/typed:landState" %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load %"compiler/typed:landState", ptr %l9
  store %"compiler/typed:landState" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:If", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t13, ptr %t17)
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t21)
  store %"compiler/typed:landState" %t23, ptr %l15
  br label %bb4
bb4:
  %t24 = load %"compiler/typed:landState", ptr %l15
  store %"compiler/typed:landState" %t24, ptr %l3
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t25, ptr %l2)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:If", ptr %t29, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t28, ptr %t32)
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t35, ptr %l3)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i1
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 15
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i64, ptr %l18, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb56
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l46
  br label %bb12
bb12:
  %t62 = load i1, ptr %l46, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l49, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Landings", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l53
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t75, ptr %l54
  br label %bb16
bb16:
  %t76 = load i1, ptr %l54, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  br label %bb55
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 15
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l59
  br label %bb21
bb21:
  %t87 = load i64, ptr %l59, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb27
bb24:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l66, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb26
bb26:
  %t114 = load i64, ptr %l66, !tbaa !24
  store i64 %t114, ptr %l63, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb29, label %bb30
bb29:
  br label %bb54
bb30:
  br label %bb31
bb31:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l13, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Landings", ptr %t134, i32 0, i32 15
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l87
  br label %bb32
bb32:
  %t141 = load i64, ptr %l87, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  store i64 %t142, ptr %l88, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Landings", ptr %t143, i32 0, i32 15
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l92
  br label %bb33
bb33:
  %t150 = load i64, ptr %l88, !tbaa !24
  %t151 = load i64, ptr %l92, !tbaa !24
  %t152 = icmp eq i64 %t150, %t151
  br i1 %t152, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb37
bb35:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Landings", ptr %t154, i32 0, i32 18
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t156, i64 %t157)
  store i1 %t160, ptr %l98
  br label %bb36
bb36:
  %t161 = load i1, ptr %l98, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l94, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l94, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb40
bb39:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = icmp slt i64 %t165, 0
  store i1 %t167, ptr %l100, !tbaa !21
  br label %bb40
bb40:
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb43
bb42:
  %t170 = load i64, ptr %l14, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Landings", ptr %t171, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t179 = icmp sge i64 %t170, %t176
  store i1 %t179, ptr %l103, !tbaa !21
  br label %bb43
bb43:
  %t181 = load i1, ptr %l103, !tbaa !21
  br i1 %t181, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb46
bb45:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Landings", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l111, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t186
  %t191 = load i1, ptr %t190, !tbaa !31
  %t193 = xor i1 %t191, true
  store i1 %t193, ptr %l109, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l109, !tbaa !21
  br i1 %t195, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  br label %bb49
bb49:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Landings", ptr %t196, i32 0, i32 21
  %t199 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t198, i64 %t199)
  br label %bb50
bb50:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Landings", ptr %t202, i32 0, i32 22
  store ptr %t204, ptr %l119, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Landings", ptr %t205, i32 0, i32 15
  %t208 = load i64, ptr %l7, !tbaa !24
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t208)
  store i64 %t211, ptr %l123
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l119, !tbaa !29
  %t213 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l12, !tbaa !24
  br label %bb28
bb54:
  br label %bb55
bb55:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb8
bb56:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca %"compiler/typed:landState"
  %rv = alloca %"compiler/typed:landState"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 6
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t15, ptr %lp1
  %t17 = load ptr, ptr %lp1
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %lp1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e933c796b27591a8_e869c9717a33729c)
  unreachable
bb3:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l21, !tbaa !24
  store i64 %t49, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l18, !tbaa !24
  store i64 %t50, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 6
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i1, ptr %t77, i64 %t74
  %t79 = load i1, ptr %t78, !tbaa !31
  %t81 = load ptr, ptr %lp1
  %t83 = getelementptr { i64, ptr }, ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i1, ptr %t84, i64 %t69
  store i1 %t79, ptr %t85, !tbaa !31
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb9
bb14:
  %t90 = load ptr, ptr %lp1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 7
  %t95 = load i1, ptr %t94, !tbaa !21
  %t98 = call %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v1, ptr %v1, { i64, ptr } %t91, i1 %t95)
  store %"compiler/typed:landState" %t98, ptr %l49
  br label %bb15
bb15:
  %t99 = load %"compiler/typed:landState", ptr %l49
  store %"compiler/typed:landState" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:landState", ptr %rv
  ret %"compiler/typed:landState" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l38 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l95 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l123 = alloca i64
  %l130 = alloca ptr
  %l134 = alloca i64
  %l136 = alloca ptr
  %l140 = alloca i64
  %l142 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca i1
  %l153 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l182 = alloca i64
  %l189 = alloca ptr
  %l193 = alloca i64
  %l195 = alloca ptr
  %l199 = alloca i64
  %l204 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i64
  %l232 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l26
  br label %bb1
bb1:
  %t8 = load i1, ptr %l26, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:LocalUses", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l31
  br label %bb4
bb4:
  %t16 = load i1, ptr %l31, !tbaa !21
  store i1 %t16, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t20, i64 %t21, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l38
  br label %bb10
bb10:
  %t31 = load i1, ptr %l38, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l45
  br label %bb15
bb15:
  %t45 = load i1, ptr %l45, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb19
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 8
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l50
  br label %bb18
bb18:
  %t53 = load i1, ptr %l50, !tbaa !21
  store i1 %t53, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l46, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 5
  %t58 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:LocalUses", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l57
  br label %bb24
bb24:
  %t68 = load i1, ptr %l57, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb28
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 8
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l62
  br label %bb27
bb27:
  %t76 = load i1, ptr %l62, !tbaa !21
  store i1 %t76, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l58, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l67, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/typed:LocalUses", ptr %t88, i32 0, i32 10
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store ptr %t94, ptr %l71
  br label %bb33
bb33:
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = call ptr @__olang_scope_or(ptr %v1, ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t97 to ptr
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = load ptr, ptr %l71, !tbaa !29
  %t102 = call i1 @compiler_2ftyped_2eRefReadOut(ptr %t99, ptr %v0, ptr %t100, ptr %t101)
  store i1 %t102, ptr %l73
  br label %bb34
bb34:
  %t103 = load i1, ptr %l73, !tbaa !21
  store i1 %t103, ptr %l3, !tbaa !21
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/typed:LocalUses", ptr %t104, i32 0, i32 7
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l77
  br label %bb35
bb35:
  %t111 = load i1, ptr %l77, !tbaa !21
  br i1 %t111, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb39
bb37:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/typed:LocalUses", ptr %t112, i32 0, i32 8
  %t115 = load i64, ptr %l1, !tbaa !24
  %t118 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t114, i64 %t115)
  store i1 %t118, ptr %l82
  br label %bb38
bb38:
  %t119 = load i1, ptr %l82, !tbaa !21
  store i1 %t119, ptr %l78, !tbaa !21
  br label %bb39
bb39:
  %t120 = load i1, ptr %l78, !tbaa !21
  br i1 %t120, label %bb40, label %bb41
bb40:
  %t121 = load i1, ptr %l3, !tbaa !21
  %t123 = xor i1 %t121, true
  store i1 %t123, ptr %l83, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb42
bb42:
  %t125 = load i1, ptr %l83, !tbaa !21
  br i1 %t125, label %bb43, label %bb44
bb43:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/typed:LocalUses", ptr %t126, i32 0, i32 7
  %t129 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t128, i64 %t129, i1 true)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load i64, ptr %l2, !tbaa !24
  %t135 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eviewInto(ptr %v0, ptr %t132, i64 %t133, i64 %t134, i1 %t135)
  br label %bb47
bb47:
  store i64 0, ptr %l4, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/typed:LocalUses", ptr %t140, i32 0, i32 16
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t142)
  store i64 %t144, ptr %l95
  br label %bb48
bb48:
  %t145 = load i64, ptr %l95, !tbaa !24
  store i64 %t145, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load i64, ptr %l4, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb49, label %bb50
bb49:
  %t152 = load i64, ptr %l6, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb54
bb51:
  %t156 = load i64, ptr %l5, !tbaa !24
  %t157 = load i64, ptr %l4, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l6, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l6, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l102, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb53
bb53:
  %t172 = load i64, ptr %l102, !tbaa !24
  store i64 %t172, ptr %l99, !tbaa !24
  br label %bb54
bb54:
  %t173 = load i64, ptr %l99, !tbaa !24
  store i64 %t173, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb55
bb55:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t175 = load i64, ptr %l7, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb56, label %bb57
bb56:
  br label %bb74
bb57:
  br label %bb58
bb58:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t183 = load i64, ptr %l8, !tbaa !24
  %t184 = load i64, ptr %l6, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l9, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/typed:LocalUses", ptr %t192, i32 0, i32 16
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l123
  br label %bb59
bb59:
  %t199 = load i64, ptr %l1, !tbaa !24
  %t200 = load i64, ptr %l123, !tbaa !24
  %t202 = icmp ne i64 %t200, %t199
  br i1 %t202, label %bb60, label %bb61
bb60:
  br label %bb73
bb61:
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:LocalUses", ptr %t204, i32 0, i32 16
  %t207 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  br label %bb63
bb63:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %t210, i32 0, i32 17
  store ptr %t212, ptr %l130, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/typed:LocalUses", ptr %t213, i32 0, i32 17
  %t216 = load i64, ptr %l9, !tbaa !24
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216)
  store i64 %t219, ptr %l134
  br label %bb64
bb64:
  %t220 = load ptr, ptr %l130, !tbaa !29
  %t221 = load i64, ptr %l134, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t220, i64 %t221)
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:LocalUses", ptr %t222, i32 0, i32 18
  store ptr %t224, ptr %l136, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/typed:LocalUses", ptr %t225, i32 0, i32 18
  %t228 = load i64, ptr %l9, !tbaa !24
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t227, i64 %t228)
  store i64 %t231, ptr %l140
  br label %bb66
bb66:
  %t232 = load ptr, ptr %l136, !tbaa !29
  %t233 = load i64, ptr %l140, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t232, i64 %t233)
  br label %bb67
bb67:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/typed:LocalUses", ptr %t234, i32 0, i32 19
  store ptr %t236, ptr %l142, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/typed:LocalUses", ptr %t237, i32 0, i32 19
  %t240 = load i64, ptr %l9, !tbaa !24
  %t243 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t239, i64 %t240)
  store i1 %t243, ptr %l146
  br label %bb68
bb68:
  %t244 = load i1, ptr %l146, !tbaa !21
  br i1 %t244, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb71
bb70:
  %t245 = load i1, ptr %l3, !tbaa !21
  store i1 %t245, ptr %l147, !tbaa !21
  br label %bb71
bb71:
  %t247 = load ptr, ptr %l142, !tbaa !29
  %t248 = load i1, ptr %l147, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t247, i1 %t248)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t249 = load i64, ptr %l8, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l8, !tbaa !24
  br label %bb55
bb74:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/typed:LocalUses", ptr %t253, i32 0, i32 13
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t255)
  store i64 %t257, ptr %l153
  br label %bb75
bb75:
  %t258 = load i64, ptr %l153, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store i64 %t258, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t261 = load i64, ptr %l12, !tbaa !24
  %t262 = load i64, ptr %l11, !tbaa !24
  %t265 = icmp sgt i64 %t261, %t262
  br i1 %t265, label %bb76, label %bb77
bb76:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb81
bb78:
  %t271 = load i64, ptr %l12, !tbaa !24
  %t272 = load i64, ptr %l11, !tbaa !24
  %t275 = sub i64 %t271, %t272
  %t276 = load i64, ptr %l13, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = sub i64 %t279, 1
  %t282 = load i64, ptr %l13, !tbaa !24
  %t285 = sdiv i64 %t281, %t282
  store i64 %t285, ptr %l161, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb80
bb80:
  %t287 = load i64, ptr %l161, !tbaa !24
  store i64 %t287, ptr %l158, !tbaa !24
  br label %bb81
bb81:
  %t288 = load i64, ptr %l158, !tbaa !24
  store i64 %t288, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb82
bb82:
  %t289 = load i64, ptr %l15, !tbaa !24
  %t290 = load i64, ptr %l14, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb83, label %bb84
bb83:
  br label %bb96
bb84:
  br label %bb85
bb85:
  %t297 = load i64, ptr %l11, !tbaa !24
  %t298 = load i64, ptr %l15, !tbaa !24
  %t299 = load i64, ptr %l13, !tbaa !24
  %t302 = mul i64 %t298, %t299
  %t305 = add i64 %t297, %t302
  store i64 %t305, ptr %l16, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/typed:LocalUses", ptr %t307, i32 0, i32 13
  %t310 = load i64, ptr %l16, !tbaa !24
  %t313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t309, i64 %t310)
  store i64 %t313, ptr %l182
  br label %bb86
bb86:
  %t314 = load i64, ptr %l1, !tbaa !24
  %t315 = load i64, ptr %l182, !tbaa !24
  %t317 = icmp ne i64 %t315, %t314
  br i1 %t317, label %bb87, label %bb88
bb87:
  br label %bb95
bb88:
  br label %bb89
bb89:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/typed:LocalUses", ptr %t319, i32 0, i32 13
  %t322 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t321, i64 %t322)
  br label %bb90
bb90:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/typed:LocalUses", ptr %t325, i32 0, i32 14
  store ptr %t327, ptr %l189, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/typed:LocalUses", ptr %t328, i32 0, i32 14
  %t331 = load i64, ptr %l16, !tbaa !24
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t330, i64 %t331)
  store i64 %t334, ptr %l193
  br label %bb91
bb91:
  %t335 = load ptr, ptr %l189, !tbaa !29
  %t336 = load i64, ptr %l193, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t335, i64 %t336)
  br label %bb92
bb92:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/typed:LocalUses", ptr %t337, i32 0, i32 15
  store ptr %t339, ptr %l195, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/typed:LocalUses", ptr %t340, i32 0, i32 15
  %t343 = load i64, ptr %l16, !tbaa !24
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t342, i64 %t343)
  store i64 %t346, ptr %l199
  br label %bb93
bb93:
  %t347 = load ptr, ptr %l195, !tbaa !29
  %t348 = load i64, ptr %l199, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t347, i64 %t348)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t349 = load i64, ptr %l15, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l15, !tbaa !24
  br label %bb82
bb96:
  store i64 0, ptr %l17, !tbaa !24
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/typed:LocalUses", ptr %t353, i32 0, i32 11
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t355)
  store i64 %t357, ptr %l204
  br label %bb97
bb97:
  %t358 = load i64, ptr %l204, !tbaa !24
  store i64 %t358, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t359 = load i64, ptr %l18, !tbaa !24
  %t360 = load i64, ptr %l17, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb98, label %bb99
bb98:
  %t365 = load i64, ptr %l19, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb103
bb100:
  %t369 = load i64, ptr %l18, !tbaa !24
  %t370 = load i64, ptr %l17, !tbaa !24
  %t373 = sub i64 %t369, %t370
  %t374 = load i64, ptr %l19, !tbaa !24
  %t377 = add i64 %t373, %t374
  %t379 = sub i64 %t377, 1
  %t380 = load i64, ptr %l19, !tbaa !24
  %t383 = sdiv i64 %t379, %t380
  store i64 %t383, ptr %l211, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb102
bb102:
  %t385 = load i64, ptr %l211, !tbaa !24
  store i64 %t385, ptr %l208, !tbaa !24
  br label %bb103
bb103:
  %t386 = load i64, ptr %l208, !tbaa !24
  store i64 %t386, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb104
bb104:
  %t387 = load i64, ptr %l21, !tbaa !24
  %t388 = load i64, ptr %l20, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb105, label %bb106
bb105:
  br label %bb114
bb106:
  br label %bb107
bb107:
  %t395 = load i64, ptr %l17, !tbaa !24
  %t396 = load i64, ptr %l21, !tbaa !24
  %t397 = load i64, ptr %l19, !tbaa !24
  %t400 = mul i64 %t396, %t397
  %t403 = add i64 %t395, %t400
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/typed:LocalUses", ptr %t405, i32 0, i32 11
  %t411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t407, i64 %t403)
  store i64 %t411, ptr %l232
  br label %bb108
bb108:
  %t412 = load i64, ptr %l1, !tbaa !24
  %t413 = load i64, ptr %l232, !tbaa !24
  %t415 = icmp eq i64 %t413, %t412
  br i1 %t415, label %bb109, label %bb110
bb109:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/typed:LocalUses", ptr %t417, i32 0, i32 2
  %t420 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t419, i64 %t420, i1 true)
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t423 = load i64, ptr %l21, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l21, !tbaa !24
  br label %bb104
bb114:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t73 = alloca { i64, [1 x i64] }, align 8
  %t95 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t26, ptr %t30, { i64, [1 x i64] } %t34)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l10, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Bind", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = load ptr, ptr %l10, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Bind", ptr %t69, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 0
  store i64 4, ptr %t74
  %t76 = insertvalue { i32 } undef, i32 %t72, 0
  %t77 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 1
  store { i32 } %t76, ptr %t77
  %t78 = load { i64, [1 x i64] }, ptr %t73
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t63, ptr %t67, { i64, [1 x i64] } %t78)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 0
  store i64 0, ptr %t96
  %t97 = load { i64, [1 x i64] }, ptr %t95
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t90, ptr %t94, { i64, [1 x i64] } %t97)
  br label %bb15
bb15:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t101, ptr %t105)
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Arm", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t108, ptr %t112, { i64, [1 x i64] } %a2)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca i1
  %l74 = alloca i64
  %l77 = alloca i64
  %l98 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca i64
  %l112 = alloca { i64, [1 x i64] }
  %l115 = alloca i64
  %l116 = alloca i64
  %l119 = alloca { i64, ptr }
  %l126 = alloca i1
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l138 = alloca i1
  %l139 = alloca i1
  %l142 = alloca { i64, ptr }
  %l149 = alloca i1
  %l152 = alloca { i64, ptr }
  %t53 = alloca { i64, [1 x i64] }, align 8
  %t204 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 46
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:LocalUses", ptr %t6, i32 0, i32 46
  store i64 -1, ptr %t8, !tbaa !24
  store i64 -1, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Call", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l10, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t17 = load ptr, ptr %l28, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l28, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 5}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l29, !tbaa !21
  br label %bb2
bb2:
  %t24 = load i1, ptr %l29, !tbaa !21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l11, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t31 = load i32, ptr %l11, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb33
bb6:
  %t35 = load ptr, ptr %l10, !tbaa !29
  store ptr %t35, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t36 = load ptr, ptr %l36, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l36, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 5}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l37, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l10, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l12, !tbaa !29
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l12, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [1 x i64] }, ptr %t53
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t50, ptr %t51, { i64, [1 x i64] } %t55)
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l12, !tbaa !29
  %t61 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t59)
  store i32 %t61, ptr %l47
  br label %bb13
bb13:
  %t62 = load i32, ptr %l47, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb33
bb14:
  %t63 = load ptr, ptr %l10, !tbaa !29
  store ptr %t63, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t64 = load ptr, ptr %l48, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l48, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 5}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l49, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { i32, i64, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l13, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t78 = load i32, ptr %l13, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  store i1 true, ptr %l8, !tbaa !21
  br label %bb33
bb20:
  %t80 = load ptr, ptr %l10, !tbaa !29
  store ptr %t80, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t81 = load ptr, ptr %l55, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 5}
  %t87 = icmp eq i64 %t85, 4
  store i1 %t87, ptr %l56, !tbaa !21
  br label %bb22
bb22:
  %t88 = load i1, ptr %l56, !tbaa !21
  br i1 %t88, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb33
bb26:
  %t89 = load ptr, ptr %l10, !tbaa !29
  store ptr %t89, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t90 = load ptr, ptr %l59, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t93 = load ptr, ptr %l59, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 5}
  %t96 = icmp eq i64 %t94, 1
  store i1 %t96, ptr %l60, !tbaa !21
  br label %bb28
bb28:
  %t97 = load i1, ptr %l60, !tbaa !21
  br i1 %t97, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_6ff368c26ca3ad9b_74caa00555ca222f)
  unreachable
bb33:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l64, !tbaa !29
  %t104 = call ptr @__olang_scope_or(ptr %v2, ptr %t103)
  %t105 = ptrtoint ptr %t104 to i64
  %t107 = inttoptr i64 %t105 to ptr
  %t108 = load ptr, ptr %l64, !tbaa !29
  %t110 = call i1 @compiler_2ftyped_2emayHold(ptr %t107, ptr %t108, i32 %a2, i64 0)
  store i1 %t110, ptr %l67
  br label %bb34
bb34:
  %t111 = load i1, ptr %l67, !tbaa !21
  store i1 %t111, ptr %l14, !tbaa !21
  store i64 0, ptr %l15, !tbaa !24
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Call", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t119 = load i64, ptr %l16, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load i64, ptr %l17, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb40
bb37:
  %t129 = load i64, ptr %l16, !tbaa !24
  %t130 = load i64, ptr %l15, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l17, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l17, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l77, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb39
bb39:
  %t145 = load i64, ptr %l77, !tbaa !24
  store i64 %t145, ptr %l74, !tbaa !24
  br label %bb40
bb40:
  %t146 = load i64, ptr %l74, !tbaa !24
  store i64 %t146, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb41
bb41:
  %t147 = load i64, ptr %l19, !tbaa !24
  %t148 = load i64, ptr %l18, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb42, label %bb43
bb42:
  br label %bb61
bb43:
  br label %bb44
bb44:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr %l19, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l20, !tbaa !24
  %t165 = load i1, ptr %l14, !tbaa !21
  br i1 %t165, label %bb45, label %bb46
bb45:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Call", ptr %t168, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l98, !tbaa !27
  %t172 = load i64, ptr %l20, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr ptr, ptr %t175, i64 %t172
  %t177 = load ptr, ptr %t176, !tbaa !39
  %t178 = load i64, ptr %l4, !tbaa !24
  %t179 = load { i64, [1 x i64] }, ptr %l3
  %t180 = load i64, ptr %l5, !tbaa !24
  %t181 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t167, ptr %t177, i64 %t178, { i64, [1 x i64] } %t179, i64 %t180, i64 %t181)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l105, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Call", ptr %t189, i32 0, i32 1
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l107, !tbaa !27
  %t193 = load i64, ptr %l20, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t193
  %t198 = load ptr, ptr %t197, !tbaa !39
  store ptr %t198, ptr %l109, !tbaa !29
  %t199 = load i64, ptr %l4, !tbaa !24
  store i64 %t199, ptr %l110, !tbaa !24
  %t200 = load i1, ptr %l14, !tbaa !21
  br i1 %t200, label %bb49, label %bb50
bb49:
  %t202 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t202, ptr %l112
  br label %bb51
bb50:
  store { i64, [1 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [1 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t206 = load { i64, [1 x i64] }, ptr %t204
  store { i64, [1 x i64] } %t206, ptr %l112
  br label %bb51
bb51:
  %t208 = load i64, ptr %l5, !tbaa !24
  store i64 %t208, ptr %l115, !tbaa !24
  %t209 = load i64, ptr %l20, !tbaa !24
  store i64 %t209, ptr %l116, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Call", ptr %t211, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l119, !tbaa !27
  %t215 = load i64, ptr %l20, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 %t215
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t221 = load i32, ptr %l7, !tbaa !23
  %t222 = load i64, ptr %l20, !tbaa !24
  %t223 = load i1, ptr %l8, !tbaa !21
  %t224 = load i1, ptr %l9, !tbaa !21
  %t231 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eunkept(ptr %v0, ptr %v1, ptr %v2, ptr %t210, ptr %t220, i32 %t221, i64 %t222, i1 %t223, i1 %t224)
  store i1 %t231, ptr %l126
  br label %bb52
bb52:
  %t232 = load ptr, ptr %l105, !tbaa !29
  %t233 = load ptr, ptr %l109, !tbaa !29
  %t234 = load i64, ptr %l110, !tbaa !24
  %t235 = load { i64, [1 x i64] }, ptr %l112
  %t236 = load i64, ptr %l115, !tbaa !24
  %t237 = load i64, ptr %l116, !tbaa !24
  %t238 = load i1, ptr %l126, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2emade(ptr %v0, ptr %v1, ptr %v2, ptr %t232, ptr %t233, i64 %t234, { i64, [1 x i64] } %t235, i64 %t236, i64 %t237, i1 %t238)
  br label %bb53
bb53:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/typed:LocalUses", ptr %t239, i32 0, i32 49
  %t242 = load i1, ptr %t241, !tbaa !21
  store i1 %t242, ptr %l21, !tbaa !21
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l129, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Call", ptr %t246, i32 0, i32 1
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l132, !tbaa !27
  %t250 = load i64, ptr %l20, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr ptr, ptr %t253, i64 %t250
  %t255 = load ptr, ptr %t254, !tbaa !39
  %t256 = load i64, ptr %l5, !tbaa !24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t258 = load i1, ptr %l6, !tbaa !21
  %t264 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egiven(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t245, ptr %t255, i64 %t256, i64 %t257, i1 %t258)
  store i1 %t264, ptr %l138
  br label %bb54
bb54:
  %t265 = load i1, ptr %l138, !tbaa !21
  br i1 %t265, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb58
bb56:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Call", ptr %t267, i32 0, i32 1
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l142, !tbaa !27
  %t271 = load i64, ptr %l20, !tbaa !24
  %t273 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr ptr, ptr %t274, i64 %t271
  %t276 = load ptr, ptr %t275, !tbaa !39
  %t277 = load i32, ptr %l7, !tbaa !23
  %t278 = load i64, ptr %l20, !tbaa !24
  %t279 = load i1, ptr %l8, !tbaa !21
  %t280 = load i1, ptr %l9, !tbaa !21
  %t287 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eunkept(ptr %v0, ptr %v1, ptr %v2, ptr %t266, ptr %t276, i32 %t277, i64 %t278, i1 %t279, i1 %t280)
  store i1 %t287, ptr %l149
  br label %bb57
bb57:
  %t288 = load i1, ptr %l149, !tbaa !21
  store i1 %t288, ptr %l139, !tbaa !21
  br label %bb58
bb58:
  %t289 = load i1, ptr %l139, !tbaa !21
  %t290 = load ptr, ptr %l129, !tbaa !29
  %t291 = getelementptr %"compiler/typed:LocalUses", ptr %t290, i32 0, i32 49
  store i1 %t289, ptr %t291, !tbaa !21
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Call", ptr %t293, i32 0, i32 1
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l152, !tbaa !27
  %t297 = load i64, ptr %l20, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr ptr, ptr %t300, i64 %t297
  %t302 = load ptr, ptr %t301, !tbaa !39
  %t303 = load i64, ptr %l5, !tbaa !24
  %t304 = load i64, ptr %l20, !tbaa !24
  %t305 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t292, ptr %t302, i64 %t303, i64 %t304, i1 %t305)
  br label %bb59
bb59:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i1, ptr %l21, !tbaa !21
  %t315 = getelementptr %"compiler/typed:LocalUses", ptr %t311, i32 0, i32 49
  store i1 %t312, ptr %t315, !tbaa !21
  br label %bb60
bb60:
  %t316 = load i64, ptr %l19, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l19, !tbaa !24
  br label %bb41
bb61:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, [1 x i64] } %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l6 = alloca %"compiler/typed:argRoot"
  %l10 = alloca %"compiler/typed:argRoot"
  %l13 = alloca i1
  %l18 = alloca i64
  %l22 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a1)
  store %"compiler/typed:argRoot" %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load %"compiler/typed:argRoot", ptr %l10
  store %"compiler/typed:argRoot" %t6, ptr %l6
  %t7 = getelementptr %"compiler/typed:argRoot", ptr %l6, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  %t12 = load { i64, [1 x i64] }, ptr %l3
  %t14 = extractvalue { i64, [1 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 0
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l18, !tbaa !24
  br label %bb13
bb9:
  %t24 = load { i64, [1 x i64] }, ptr %l3
  %t26 = extractvalue { i64, [1 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 3
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load i64, ptr @G_2ecompiler_2ftyped_2eHanded, !tbaa !24
  store i64 %t29, ptr %l22, !tbaa !24
  br label %bb12
bb11:
  %t31 = load i64, ptr @G_2ecompiler_2ftyped_2eElsewhere, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb13
bb13:
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:argRoot", ptr %l6, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/typed:argRoot", ptr %l6, i32 0, i32 1
  %t40 = load i1, ptr %t39, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elink(ptr %v0, ptr %t35, i64 %t34, i64 %t38, i1 %t40, i64 %a4, i64 %a5)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t47, ptr %l32, !tbaa !27
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t55, ptr %t53, { i64, [1 x i64] } %a2)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t15, i32 0, i32 9
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l1, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %v1, ptr %t38, i64 %t41, i64 %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecopied(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 47
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:LocalUses", ptr %t8, i32 0, i32 30
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t10, i64 %t11, i1 true)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t15, i32 0, i32 47
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elink(ptr %v0, ptr %t14, i64 %t18, i64 %t19, i1 true, i64 -1, i64 0)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca %"compiler/typed:Local"
  %l84 = alloca i1
  %l85 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v2, ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t31, ptr %t32, i32 %t26)
  store i64 %t34, ptr %l21
  br label %bb6
bb6:
  %t35 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t38 = and i64 %t36, %t35
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t54, i32 0, i32 2
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t58 = load i32, ptr %l4, !tbaa !23
  %t60 = sext i32 %t58 to i64
  store i64 %t60, ptr %l26, !tbaa !24
  br label %bb27
bb15:
  %t62 = load ptr, ptr %l3, !tbaa !29
  store ptr %t62, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 8}
  %t69 = icmp eq i64 %t67, 2
  store i1 %t69, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t81 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store i64 %t81, ptr %l43
  br label %bb21
bb21:
  %t82 = load i64, ptr %l43, !tbaa !24
  store i64 %t82, ptr %l26, !tbaa !24
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b9f0b2a15b6670eb_2e1d369e87bd8cdf)
  unreachable
bb27:
  %t83 = load i64, ptr %l26, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
bb28:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb29, label %bb30
bb29:
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 2
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t92 = load i1, ptr %l45, !tbaa !21
  br i1 %t92, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l6, !tbaa !23
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l7, !tbaa !29
  br label %bb33
bb32:
  br label %bb58
bb33:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/typed:LocalUses", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l53, !tbaa !29
  %t109 = load i32, ptr %l6, !tbaa !23
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = call ptr @__olang_scope_or(ptr %v2, ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t115 = load ptr, ptr %l53, !tbaa !29
  %t117 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t114, ptr %t115, i32 %t109)
  store i1 %t117, ptr %l56
  br label %bb34
bb34:
  %t118 = load i1, ptr %l56, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb38
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/typed:LocalUses", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l60, !tbaa !29
  %t125 = load i32, ptr %l6, !tbaa !23
  %t126 = load ptr, ptr %l60, !tbaa !29
  %t127 = call ptr @__olang_scope_or(ptr %v2, ptr %t126)
  %t128 = ptrtoint ptr %t127 to i64
  %t130 = inttoptr i64 %t128 to ptr
  %t131 = load ptr, ptr %l60, !tbaa !29
  %t133 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t130, ptr %t131, i32 %t125)
  store i64 %t133, ptr %l63
  br label %bb37
bb37:
  %t134 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t135 = load i64, ptr %l63, !tbaa !24
  %t137 = and i64 %t135, %t134
  %t139 = icmp eq i64 %t137, 0
  store i1 %t139, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t141 = load i1, ptr %l58, !tbaa !21
  br i1 %t141, label %bb39, label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l7, !tbaa !29
  store ptr %t143, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t144 = load ptr, ptr %l69, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t147 = load ptr, ptr %l69, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 8}
  %t150 = icmp eq i64 %t148, 0
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t151 = load i1, ptr %l70, !tbaa !21
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t152 = load ptr, ptr %l7, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t154, i32 0, i32 2
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l8, !tbaa !23
  br label %bb46
bb45:
  br label %bb52
bb46:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/typed:LocalUses", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l76, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/typed:LocalUses", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l78, !tbaa !29
  %t166 = load i32, ptr %l8, !tbaa !23
  %t167 = load ptr, ptr %l78, !tbaa !29
  %t168 = call ptr @__olang_scope_or(ptr %v3, ptr %t167)
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = inttoptr i64 %t169 to ptr
  %t172 = load ptr, ptr %l78, !tbaa !29
  %t174 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t171, ptr %t172, i32 %t166)
  store %"compiler/typed:Local" %t174, ptr %l81
  br label %bb47
bb47:
  %t175 = getelementptr %"compiler/typed:Local", ptr %l81, i32 0, i32 2
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l76, !tbaa !29
  %t178 = call ptr @__olang_scope_or(ptr %v2, ptr %t177)
  %t179 = ptrtoint ptr %t178 to i64
  %t181 = inttoptr i64 %t179 to ptr
  %t182 = load ptr, ptr %l76, !tbaa !29
  %t184 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t181, ptr %t182, i32 %t176)
  store i1 %t184, ptr %l84
  br label %bb48
bb48:
  %t185 = load i1, ptr %l84, !tbaa !21
  br i1 %t185, label %bb49, label %bb50
bb49:
  %t186 = load i32, ptr %l8, !tbaa !23
  %t188 = sext i32 %t186 to i64
  store i64 %t188, ptr %l85, !tbaa !24
  br label %bb51
bb50:
  store i64 -1, ptr %l85, !tbaa !24
  br label %bb51
bb51:
  %t190 = load i64, ptr %l85, !tbaa !24
  store i64 %t190, ptr %l68, !tbaa !24
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_5437ab06fdd2422a_119d1d559b7fc05e)
  unreachable
bb57:
  %t191 = load i64, ptr %l68, !tbaa !24
  store i64 %t191, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i64 -1, ptr %rv
  br label %ret
bb62:
  call void @__olang_check_failed(ptr @olang_loc_ef0de602c5122041_f82f60a1eb2bb195)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elink(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LocalUses", ptr %t7, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %a2)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:LocalUses", ptr %t13, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t15, i1 %a3)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:LocalUses", ptr %t19, i32 0, i32 41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t21, i64 %a4)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:LocalUses", ptr %t25, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %a5)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l15 = alloca { i64, ptr }
  %t43 = alloca { i64, [1 x i64] }, align 8
  %t57 = alloca { i64, [1 x i64] }, align 8
  %t66 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb27
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 51}
  %t25 = trunc i64 20 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t28, ptr %t29, { i64, [1 x i64] } %a3)
  br label %bb8
bb8:
  br label %bb25
bb9:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 51}
  %t37 = trunc i64 41 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i32 0, i32 0
  store i64 5, ptr %t44
  %t45 = load { i64, [1 x i64] }, ptr %t43
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t40, ptr %t41, { i64, [1 x i64] } %t45)
  br label %bb13
bb13:
  br label %bb25
bb14:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 51}
  %t51 = trunc i64 30 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [1 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t59 = load { i64, [1 x i64] }, ptr %t57
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t54, ptr %t55, { i64, [1 x i64] } %t59)
  br label %bb18
bb18:
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t66
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t63, ptr %t64, { i64, [1 x i64] } %t68)
  br label %bb23
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dac0899521d00a27_f5966ad5b7471ec3)
  unreachable
bb25:
  br label %bb26
bb26:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb1
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4d8a06dfe39d8193_a27ec756202836f)
  unreachable
bb16:
  %t35 = load i64, ptr %l14, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb42
bb17:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 17
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t55 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i64 %t55, ptr %l31
  br label %bb23
bb23:
  %t56 = load i64, ptr %l31, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  br label %bb42
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb25, label %bb26
bb25:
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 9
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb26
bb26:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb27, label %bb28
bb27:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t68, i32 0, i32 2
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 51}
  store i32 %t70, ptr %l5
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t74, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  br label %bb29
bb28:
  br label %bb37
bb29:
  %t78 = load i32, ptr %l5, !range !{i32 0, i32 51}
  %t80 = trunc i64 20 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t87 = icmp eq i64 %t85, 1
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb32
bb32:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb33, label %bb34
bb33:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 0
  %t95 = load ptr, ptr %t94, !tbaa !39
  %t98 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t90, ptr %t95)
  store i64 %t98, ptr %l50
  br label %bb35
bb34:
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb36
bb35:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %l46, !tbaa !24
  br label %bb36
bb36:
  %t100 = load i64, ptr %l46, !tbaa !24
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_104aca9b23d55792_b4686871930206ae)
  unreachable
bb42:
  %t101 = load i64, ptr %l7, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t30, i1 false)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Nodes", ptr %t1, i32 0, i32 0
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Nodes", ptr %t53, i32 0, i32 0
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp eq ptr %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t65, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l166 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb118
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l32, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  br label %bb14
bb14:
  br label %bb118
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t50 = load ptr, ptr %l43, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l43, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l44, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb28
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t65 = load ptr, ptr %l49, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l49, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 17}
  %t71 = icmp eq i64 %t69, 15
  store i1 %t71, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l50, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb28
bb23:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t80 = load ptr, ptr %l55, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l55, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 17}
  %t86 = icmp eq i64 %t84, 8
  store i1 %t86, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t87 = load i1, ptr %l56, !tbaa !21
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t90, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t95)
  br label %bb29
bb29:
  br label %bb118
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t99 = load ptr, ptr %l63, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 17}
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", ptr }, ptr %t109, i32 0, i32 1
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/typed:If", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t113, ptr %t117)
  br label %bb36
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/typed:If", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t120, ptr %t124)
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 2
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb38
bb38:
  br label %bb118
bb39:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb40, label %bb41
bb40:
  %t139 = load ptr, ptr %l79, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 17}
  %t142 = icmp eq i64 %t140, 4
  store i1 %t142, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t143 = load i1, ptr %l80, !tbaa !21
  br i1 %t143, label %bb42, label %bb43
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l8, !tbaa !29
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  br label %bb45
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  br label %bb46
bb46:
  br label %bb118
bb47:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t166 = load ptr, ptr %l92, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb48, label %bb49
bb48:
  %t169 = load ptr, ptr %l92, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 17}
  %t172 = icmp eq i64 %t170, 6
  store i1 %t172, ptr %l93, !tbaa !21
  br label %bb49
bb49:
  %t173 = load i1, ptr %l93, !tbaa !21
  br i1 %t173, label %bb50, label %bb51
bb50:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [3 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l9, !tbaa !29
  br label %bb60
bb51:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t181 = load ptr, ptr %l98, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb52, label %bb53
bb52:
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 17}
  %t187 = icmp eq i64 %t185, 16
  store i1 %t187, ptr %l99, !tbaa !21
  br label %bb53
bb53:
  %t188 = load i1, ptr %l99, !tbaa !21
  br i1 %t188, label %bb54, label %bb55
bb54:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr }, ptr %t191, i32 0, i32 1
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l9, !tbaa !29
  br label %bb60
bb55:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t196 = load ptr, ptr %l104, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l104, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 9
  store i1 %t202, ptr %l105, !tbaa !21
  br label %bb57
bb57:
  %t203 = load i1, ptr %l105, !tbaa !21
  br i1 %t203, label %bb58, label %bb59
bb58:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t206, i32 0, i32 2
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t210, ptr %t211)
  br label %bb61
bb61:
  br label %bb118
bb62:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb63, label %bb64
bb63:
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 17}
  %t221 = icmp eq i64 %t219, 10
  store i1 %t221, ptr %l113, !tbaa !21
  br label %bb64
bb64:
  %t222 = load i1, ptr %l113, !tbaa !21
  br i1 %t222, label %bb65, label %bb66
bb65:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l10, !tbaa !29
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l11, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  br label %bb68
bb68:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb69
bb69:
  br label %bb118
bb70:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t244 = load ptr, ptr %l124, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb71, label %bb72
bb71:
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 17}
  %t250 = icmp eq i64 %t248, 11
  store i1 %t250, ptr %l125, !tbaa !21
  br label %bb72
bb72:
  %t251 = load i1, ptr %l125, !tbaa !21
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [3 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", ptr }, ptr %t254, i32 0, i32 1
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l12, !tbaa !29
  br label %bb79
bb74:
  %t258 = load ptr, ptr %l1, !tbaa !29
  store ptr %t258, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t259 = load ptr, ptr %l130, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb75, label %bb76
bb75:
  %t262 = load ptr, ptr %l130, !tbaa !29
  %t263 = load i64, ptr %t262, !range !{i64 0, i64 17}
  %t265 = icmp eq i64 %t263, 12
  store i1 %t265, ptr %l131, !tbaa !21
  br label %bb76
bb76:
  %t266 = load i1, ptr %l131, !tbaa !21
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  br label %bb80
bb80:
  br label %bb118
bb81:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t279 = load ptr, ptr %l139, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb82, label %bb83
bb82:
  %t282 = load ptr, ptr %l139, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 17}
  %t285 = icmp eq i64 %t283, 13
  store i1 %t285, ptr %l140, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l140, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", ptr }, ptr %t289, i32 0, i32 1
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l13, !tbaa !29
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l13, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Join", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb87
bb87:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %l13, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Join", ptr %t302, i32 0, i32 2
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %t301, { i64, ptr } %t305)
  br label %bb88
bb88:
  br label %bb118
bb89:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t309 = load ptr, ptr %l152, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb90, label %bb91
bb90:
  %t312 = load ptr, ptr %l152, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 17}
  %t315 = icmp eq i64 %t313, 14
  store i1 %t315, ptr %l153, !tbaa !21
  br label %bb91
bb91:
  %t316 = load i1, ptr %l153, !tbaa !21
  br i1 %t316, label %bb92, label %bb93
bb92:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", ptr }, ptr %t319, i32 0, i32 1
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l14, !tbaa !29
  br label %bb94
bb93:
  br label %bb113
bb94:
  %t323 = load ptr, ptr %l14, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Spawn", ptr %t323, i32 0, i32 0
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t328 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  store i64 %t330, ptr %l17, !tbaa !24
  br label %bb95
bb95:
  %t332 = load i64, ptr %l16, !tbaa !24
  %t333 = load i64, ptr %l17, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb96, label %bb97
bb96:
  br label %bb104
bb97:
  br label %bb98
bb98:
  %t340 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t340, ptr %l166, !tbaa !27
  %t341 = load i64, ptr %l16, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr ptr, ptr %t344, i64 %t341
  %t346 = load ptr, ptr %t345, !tbaa !39
  store ptr %t346, ptr %l18, !tbaa !29
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = icmp eq ptr %t348, null
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb99, label %bb100
bb99:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t354, ptr %t355)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t358 = load i64, ptr %l16, !tbaa !24
  %t360 = add i64 %t358, 1
  store i64 %t360, ptr %l16, !tbaa !24
  br label %bb95
bb104:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l14, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Spawn", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t362, ptr %t366)
  br label %bb105
bb105:
  %t369 = load ptr, ptr %l14, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Spawn", ptr %t369, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  store { i64, ptr } %t372, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l21, !tbaa !24
  br label %bb106
bb106:
  %t378 = load i64, ptr %l20, !tbaa !24
  %t379 = load i64, ptr %l21, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t386 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t386, ptr %l187, !tbaa !27
  %t387 = load i64, ptr %l20, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/typed:TaskClause", ptr %t392, i32 0, i32 3
  %t398 = load ptr, ptr %t397, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t394, ptr %t398)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t401 = load i64, ptr %l20, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l20, !tbaa !24
  br label %bb106
bb112:
  br label %bb118
bb113:
  br i1 true, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_4e4df3a218fbdfef_2fc14a2cfade6f23)
  unreachable
bb118:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropDerived(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca ptr
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Plan", ptr %t53, i32 0, i32 20
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t63 = icmp eq ptr %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Plan", ptr %t65, i32 0, i32 21
  store ptr %t67, ptr %l43, !tbaa !29
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l44, !tbaa !24
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l45
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %s3, ptr %l45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l47
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H850118f76c49c45e73ad12b3c73517c9(ptr %v0, ptr %s3, ptr %t72, i64 %t73, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Plan", ptr %t79, i32 0, i32 20
  %t82 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t85, i32 0, i32 21
  store ptr %t87, ptr %l54, !tbaa !29
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l55
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %s0, ptr %l55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l57
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H658d0bbb24c75abb2e0dcb1121887af6(ptr %v0, ptr %s0, ptr %t91, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassDerived(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/typed:Plan", ptr %a0, i32 0, i32 19
  store ptr %t3, ptr %l4, !tbaa !29
  %t6 = sext i32 %a1 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %s0, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hca132088ebdf08d0820c179196416125(ptr %v0, ptr %s0, ptr %t10, i64 %t11, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t36 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 15
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t40, i32 0, i32 16
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t52 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42, i64 %t49)
  store { i64, [2 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  %t53 = load { i64, [2 x i64] }, ptr %l26
  store { i64, [2 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetTwin(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Plan", ptr %a0, i32 0, i32 13
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t7 = sext i32 %a1 to i64
  %t11 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %t7
  store i64 %a2, ptr %t13, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/typed:LocalUses"
  %l8 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l36 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/typed:LocalUses"
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  %t73 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v2, ptr %t6)
  store i64 %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t9, %t10
  store i1 %t11, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 64
  store i1 %t16, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t18 = load i1, ptr %l17, !tbaa !21
  br i1 %t18, label %bb8, label %bb9
bb8:
  store i64 2, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = mul i64 %t20, 64
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:RefsKept", ptr %t28, i32 0, i32 4
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t30, i64 %t31)
  %t35 = extractvalue { i32, i64 } %t34, 1
  %t36 = extractvalue { i32, i64 } %t34, 0
  store i32 %t36, ptr %l30
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb12, label %ok.38, !prof !99
ok.38:
  store i64 %t35, ptr %l29
  br label %bb11
bb11:
  %t39 = load i64, ptr %l29, !tbaa !24
  store i64 %t39, ptr %l25, !tbaa !24
  br label %bb27
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:RefsKept", ptr %t40, i32 0, i32 4
  %t43 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t42, i64 %t43, i64 2)
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v2, ptr %v2, ptr %t46, i64 %t47)
  store ptr %t50, ptr %l36
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l36, !tbaa !29
  store ptr %t51, ptr %l6, !tbaa !29
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 11
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb19
bb17:
  %t59 = load i64, ptr %l4, !tbaa !24
  store i64 %t59, ptr %l41, !tbaa !24
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 5
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v2, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb18
bb18:
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l44, !tbaa !24
  %t67 = icmp sge i64 %t65, %t66
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  store i64 2, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t73, ptr %v1, ptr %v2, ptr %s2, ptr %t71, ptr %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t73, i64 1320, i1 false)
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l49, i64 1320, i1 false)
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l51, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  store ptr %l7, ptr %l53, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 5
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v2, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l57
  br label %bb24
bb24:
  %t86 = load i32, ptr %l57, !tbaa !23
  %t87 = sext i32 %t86 to i64
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l53, !tbaa !29
  %t93 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t88, ptr %t89, ptr %t90, ptr %t91, i64 %t87, i64 0)
  store i64 %t93, ptr %l59
  br label %bb25
bb25:
  %t94 = load i64, ptr %l59, !tbaa !24
  store i64 %t94, ptr %l8, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:RefsKept", ptr %t95, i32 0, i32 4
  %t98 = load i64, ptr %l5, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t97, i64 %t98, i64 %t99)
  br label %bb26
bb26:
  %t103 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t103, ptr %rv
  br label %ret
bb27:
  %t105 = load i64, ptr %l25, !tbaa !24
  store i64 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enamedOnly(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i1
  %l112 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/typed:LocalUses", ptr %t3, i32 0, i32 13
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v3, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l23
  br label %bb1
bb1:
  %t10 = load i1, ptr %l23, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb5
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = getelementptr %"compiler/typed:LocalUses", ptr %t13, i32 0, i32 11
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v3, ptr %t15, i64 %t11)
  store i1 %t19, ptr %l29
  br label %bb4
bb4:
  %t20 = load i1, ptr %l29, !tbaa !21
  store i1 %t20, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l24, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i64 0, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:LocalUses", ptr %t23, i32 0, i32 9
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t25)
  store i64 %t27, ptr %l33
  br label %bb9
bb9:
  %t28 = load i64, ptr %l33, !tbaa !24
  store i64 %t28, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb15
bb12:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l9, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l40, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l40, !tbaa !24
  store i64 %t55, ptr %l37, !tbaa !24
  br label %bb15
bb15:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t57 = load i64, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l12, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:LocalUses", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l12, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l61
  br label %bb20
bb20:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l61, !tbaa !24
  %t85 = icmp eq i64 %t83, %t82
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l65, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:LocalUses", ptr %t88, i32 0, i32 10
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v3, ptr %v3, ptr %t90, i64 %t91)
  store ptr %t94, ptr %l69
  br label %bb23
bb22:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb25
bb23:
  %t95 = load ptr, ptr %l65, !tbaa !29
  %t96 = load ptr, ptr %l69, !tbaa !29
  %t97 = call i1 @compiler_2ftyped_2eRefReadOut(ptr %v1, ptr %v3, ptr %t95, ptr %t96)
  store i1 %t97, ptr %l70
  br label %bb24
bb24:
  %t98 = load i1, ptr %l70, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l64, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l11, !tbaa !24
  br label %bb16
bb30:
  store i64 0, ptr %l13, !tbaa !24
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %t107, i32 0, i32 16
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t109)
  store i64 %t111, ptr %l77
  br label %bb31
bb31:
  %t112 = load i64, ptr %l77, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t113 = load i64, ptr %l14, !tbaa !24
  %t114 = load i64, ptr %l13, !tbaa !24
  %t117 = icmp sgt i64 %t113, %t114
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t119 = load i64, ptr %l15, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb37
bb34:
  %t123 = load i64, ptr %l14, !tbaa !24
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t133 = sub i64 %t131, 1
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = sdiv i64 %t133, %t134
  store i64 %t137, ptr %l84, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb36
bb36:
  %t139 = load i64, ptr %l84, !tbaa !24
  store i64 %t139, ptr %l81, !tbaa !24
  br label %bb37
bb37:
  %t140 = load i64, ptr %l81, !tbaa !24
  store i64 %t140, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb38
bb38:
  %t141 = load i64, ptr %l17, !tbaa !24
  %t142 = load i64, ptr %l16, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb39, label %bb40
bb39:
  br label %bb57
bb40:
  br label %bb41
bb41:
  %t149 = load i64, ptr %l13, !tbaa !24
  %t150 = load i64, ptr %l17, !tbaa !24
  %t151 = load i64, ptr %l15, !tbaa !24
  %t154 = mul i64 %t150, %t151
  %t157 = add i64 %t149, %t154
  store i64 %t157, ptr %l18, !tbaa !24
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t161 = getelementptr %"compiler/typed:LocalUses", ptr %t159, i32 0, i32 16
  %t162 = load i64, ptr %l18, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l105
  br label %bb42
bb42:
  %t166 = load i64, ptr %l4, !tbaa !24
  %t167 = load i64, ptr %l105, !tbaa !24
  %t169 = icmp eq i64 %t167, %t166
  br i1 %t169, label %bb43, label %bb44
bb43:
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t173 = getelementptr %"compiler/typed:LocalUses", ptr %t171, i32 0, i32 19
  %t174 = load i64, ptr %l18, !tbaa !24
  %t177 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t173, i64 %t174)
  store i1 %t177, ptr %l112
  br label %bb45
bb44:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb45:
  %t178 = load i1, ptr %l112, !tbaa !21
  %t179 = xor i1 %t178, true
  store i1 %t179, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t181 = load i1, ptr %l108, !tbaa !21
  br i1 %t181, label %bb47, label %bb48
bb47:
  store ptr %a0, ptr %l115, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l116, !tbaa !29
  store ptr %a2, ptr %l117, !tbaa !29
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/typed:LocalUses", ptr %t185, i32 0, i32 17
  %t188 = load i64, ptr %l18, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l121
  br label %bb49
bb48:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb52
bb49:
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/typed:LocalUses", ptr %t192, i32 0, i32 18
  %t195 = load i64, ptr %l18, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l125
  br label %bb50
bb50:
  %t199 = load ptr, ptr %l115, !tbaa !29
  %t200 = load ptr, ptr %l116, !tbaa !29
  %t201 = load ptr, ptr %l117, !tbaa !29
  %t202 = load i64, ptr %l121, !tbaa !24
  %t203 = load i64, ptr %l125, !tbaa !24
  %t204 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %t199, ptr %t200, ptr %t201, i64 %t202, i64 %t203)
  store i1 %t204, ptr %l126
  br label %bb51
bb51:
  %t205 = load i1, ptr %l126, !tbaa !21
  %t206 = xor i1 %t205, true
  store i1 %t206, ptr %l114, !tbaa !21
  br label %bb52
bb52:
  %t208 = load i1, ptr %l114, !tbaa !21
  br i1 %t208, label %bb53, label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t210 = load i64, ptr %l17, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l17, !tbaa !24
  br label %bb38
bb57:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l78 = alloca i64
  %l86 = alloca i64
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftyped_2eHanded, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 16
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i64 2, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 31
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t20, i64 %t21)
  store i1 %t24, ptr %l27
  br label %bb10
bb10:
  %t25 = load i1, ptr %l27, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb12:
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l29, !tbaa !24
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/typed:LocalUses", ptr %t27, i32 0, i32 8
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v3, ptr %t29)
  store i64 %t31, ptr %l32
  br label %bb13
bb13:
  %t32 = load i64, ptr %l29, !tbaa !24
  %t33 = load i64, ptr %l32, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:LocalUses", ptr %t36, i32 0, i32 8
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l38
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  %t43 = load i1, ptr %l38, !tbaa !21
  store i1 %t43, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l34, !tbaa !21
  store i1 %t44, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t45 = load i1, ptr %l28, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  store i64 2, ptr %l39, !tbaa !24
  br label %bb25
bb20:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 32
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l43
  br label %bb21
bb21:
  %t53 = load i1, ptr %l43, !tbaa !21
  br i1 %t53, label %bb22, label %bb23
bb22:
  store i64 1, ptr %l44, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb24
bb24:
  %t54 = load i64, ptr %l44, !tbaa !24
  store i64 %t54, ptr %l39, !tbaa !24
  br label %bb25
bb25:
  %t55 = load i64, ptr %l39, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:LocalUses", ptr %t56, i32 0, i32 39
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t58)
  store i64 %t60, ptr %l47
  br label %bb26
bb26:
  %t61 = load i64, ptr %l47, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb27, label %bb28
bb27:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb32
bb29:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb31
bb31:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb32
bb32:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb34, label %bb35
bb34:
  br label %bb54
bb35:
  br label %bb36
bb36:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = icmp eq i64 %t108, 2
  br i1 %t110, label %bb37, label %bb38
bb37:
  %t112 = load i64, ptr %l6, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = getelementptr %"compiler/typed:LocalUses", ptr %t114, i32 0, i32 39
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t116, i64 %t117)
  store i64 %t120, ptr %l78
  br label %bb40
bb40:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load i64, ptr %l78, !tbaa !24
  %t124 = icmp ne i64 %t122, %t121
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb53
bb42:
  br label %bb43
bb43:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t130 = load i64, ptr %l12, !tbaa !24
  %t136 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t126, ptr %t127, ptr %t128, ptr %t129, i64 %t130)
  store i64 %t136, ptr %l86
  br label %bb44
bb44:
  %t137 = load i64, ptr %l86, !tbaa !24
  store i64 %t137, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb45, label %bb46
bb45:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l91, !tbaa !29
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l92, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l93, !tbaa !29
  %t147 = load ptr, ptr %l3, !tbaa !29
  store ptr %t147, ptr %l94, !tbaa !29
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/typed:LocalUses", ptr %t148, i32 0, i32 38
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l98
  br label %bb47
bb46:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb49
bb47:
  %t155 = load i64, ptr %l5, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load ptr, ptr %l91, !tbaa !29
  %t159 = load ptr, ptr %l92, !tbaa !29
  %t160 = load ptr, ptr %l93, !tbaa !29
  %t161 = load ptr, ptr %l94, !tbaa !29
  %t162 = load i64, ptr %l98, !tbaa !24
  %t164 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t158, ptr %t159, ptr %t160, ptr %t161, i64 %t162, i64 %t157)
  store i64 %t164, ptr %l101
  br label %bb48
bb48:
  %t165 = load i64, ptr %l101, !tbaa !24
  %t166 = icmp sgt i64 %t165, 0
  store i1 %t166, ptr %l90, !tbaa !21
  br label %bb49
bb49:
  %t168 = load i1, ptr %l90, !tbaa !21
  br i1 %t168, label %bb50, label %bb51
bb50:
  %t169 = load i64, ptr %l13, !tbaa !24
  store i64 %t169, ptr %l6, !tbaa !24
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t171 = load i64, ptr %l11, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l11, !tbaa !24
  br label %bb33
bb54:
  %t175 = load i64, ptr %l6, !tbaa !24
  store i64 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eSigOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  %t7 = getelementptr %"compiler/typed:Versions", ptr %a0, i32 0, i32 12
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l8
  br label %bb3
bb3:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  store i64 %t4, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Versions", ptr %t10, i32 0, i32 8
  store ptr %t12, ptr %l13, !tbaa !29
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2ftyped_2edefName(i64 %t13, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Versions", ptr %t27, i32 0, i32 8
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i64 @compiler_2ftyped_2edefName(i64 %t30, i64 %t31)
  store i64 %t34, ptr %l24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Versions", ptr %t35, i32 0, i32 3
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l27
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t40, i64 %t41, i64 %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Versions", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 %t46)
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Versions", ptr %t49, i32 0, i32 4
  %t52 = load %"compiler/source:Span", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Versions", ptr %t55, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t57, i32 %a3)
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Versions", ptr %t61, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %t63, ptr %a4)
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Versions", ptr %t67, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t69, i1 %a5)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclassify(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i8
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l99 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Versions", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l23, !tbaa !24
  %t17 = sdiv i64 %t15, %t14
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l32, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l29, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l8, !tbaa !24
  %t65 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t65, ptr %l50
  br label %bb14
bb14:
  %t66 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t66, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l12, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l55, !tbaa !24
  store i64 %t96, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store ptr %l9, ptr %l76, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 11
  %t118 = load i64, ptr %l8, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t126 = add i64 %t122, %t113
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb25
bb25:
  %t130 = load i64, ptr %l84, !tbaa !24
  %t131 = icmp sgt i64 %t130, -2
  br i1 %t131, label %bb26, label %bb27
bb26:
  store i8 49, ptr %l86, !tbaa !22
  br label %bb28
bb27:
  store i8 48, ptr %l86, !tbaa !22
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = load i8, ptr %l86, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %t133, i8 %t134)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l14, !tbaa !24
  br label %bb21
bb31:
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l9)
  store { i64, ptr } %t140, ptr %l90
  br label %bb32
bb32:
  %t141 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t141, ptr %l16, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t145 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %s0, ptr %l2, { i64, ptr } %t142)
  store i1 %t145, ptr %l93
  br label %bb33
bb33:
  %t146 = load i1, ptr %l93, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb34, label %bb35
bb34:
  %t149 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Versions", ptr %t150, i32 0, i32 13
  %t153 = load i64, ptr %t152, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %s0, ptr %l2, { i64, ptr } %t149, i64 %t153)
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l99, !tbaa !29
  %t158 = load ptr, ptr %l99, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Versions", ptr %t158, i32 0, i32 13
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = add i64 %t160, 1
  %t164 = load ptr, ptr %l99, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Versions", ptr %t164, i32 0, i32 13
  store i64 %t162, ptr %t165, !tbaa !24
  br label %bb37
bb37:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Versions", ptr %t166, i32 0, i32 12
  store ptr %t168, ptr %l103, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t172 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %s0, ptr %l2, { i64, ptr } %t169)
  %t173 = extractvalue { i32, i64 } %t172, 1
  %t174 = extractvalue { i32, i64 } %t172, 0
  store i32 %t174, ptr %l108
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb39, label %ok.176, !prof !99
ok.176:
  store i64 %t173, ptr %l107
  br label %bb38
bb38:
  %t177 = load i64, ptr %l107, !tbaa !24
  store i64 %t177, ptr %l104, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb41
bb41:
  %t178 = load ptr, ptr %l103, !tbaa !29
  %t179 = load i64, ptr %l104, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t178, i64 %t179)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb10
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Versions", ptr %t9, i32 0, i32 14
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Versions", ptr %t12, i32 0, i32 14
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t18)
  store i64 %t21, ptr %l12
  br label %bb5
bb5:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = icmp ne i64 %t22, 0
  store i1 %t23, ptr %l5, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l5, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca ptr
  %l74 = alloca i64
  %l76 = alloca ptr
  %l80 = alloca i64
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l95 = alloca i64
  %l114 = alloca ptr
  %l120 = alloca i64
  %l124 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca i32
  %l151 = alloca i32
  %l152 = alloca i32
  %l161 = alloca i64
  %l164 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i32
  %l190 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t11, ptr %t12)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l32
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 3
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l35
  br label %bb7
bb7:
  %t24 = load i64, ptr %l35, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Versions", ptr %t25, i32 0, i32 17
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l38
  br label %bb8
bb8:
  %t30 = load i64, ptr %l38, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 17
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Block", ptr %t34, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t33, i32 %t37)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb15
bb12:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l51, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l51, !tbaa !24
  store i64 %t70, ptr %l48, !tbaa !24
  br label %bb15
bb15:
  %t71 = load i64, ptr %l48, !tbaa !24
  store i64 %t71, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Versions", ptr %t90, i32 0, i32 18
  store ptr %t92, ptr %l70, !tbaa !29
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb20, label %bb21
bb20:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb22
bb21:
  store i64 -2, ptr %l74, !tbaa !24
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l70, !tbaa !29
  %t100 = load i64, ptr %l74, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  br label %bb23
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Versions", ptr %t101, i32 0, i32 19
  store ptr %t103, ptr %l76, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb24, label %bb25
bb24:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb26
bb25:
  store i64 -2, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l76, !tbaa !29
  %t111 = load i64, ptr %l80, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l9, !tbaa !24
  br label %bb16
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t116)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l84
  br label %bb30
bb30:
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l11
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v3, ptr %t120, ptr %l11)
  br label %bb32
bb32:
  store i64 0, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l3, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = icmp sgt i64 %t127, %t128
  br i1 %t131, label %bb33, label %bb34
bb33:
  %t133 = load i64, ptr %l14, !tbaa !24
  %t135 = icmp sgt i64 %t133, 0
  br i1 %t135, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb38
bb35:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t141 = sub i64 %t137, %t138
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t147 = sub i64 %t145, 1
  %t148 = load i64, ptr %l14, !tbaa !24
  %t151 = sdiv i64 %t147, %t148
  store i64 %t151, ptr %l95, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb37
bb37:
  %t153 = load i64, ptr %l95, !tbaa !24
  store i64 %t153, ptr %l92, !tbaa !24
  br label %bb38
bb38:
  %t154 = load i64, ptr %l92, !tbaa !24
  store i64 %t154, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = icmp slt i64 %t155, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l16, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = mul i64 %t164, %t165
  %t171 = add i64 %t163, %t168
  store i64 %t171, ptr %l17, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Versions", ptr %t173, i32 0, i32 19
  store ptr %t175, ptr %l114, !tbaa !29
  %t176 = load i64, ptr %l4, !tbaa !24
  %t177 = load i64, ptr %l3, !tbaa !24
  %t179 = add i64 %t177, 1
  %t182 = mul i64 %t176, %t179
  %t183 = load i64, ptr %l17, !tbaa !24
  %t186 = add i64 %t182, %t183
  store i64 %t186, ptr %l120, !tbaa !24
  %t187 = load i64, ptr %l17, !tbaa !24
  %t188 = load i64, ptr %l3, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb43, label %bb44
bb43:
  store i64 1, ptr %l124, !tbaa !24
  br label %bb45
bb44:
  store i64 -2, ptr %l124, !tbaa !24
  br label %bb45
bb45:
  %t193 = load ptr, ptr %l114, !tbaa !29
  %t194 = load i64, ptr %l120, !tbaa !24
  %t195 = load i64, ptr %l124, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t193, i64 %t194, i64 %t195)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t196 = load i64, ptr %l16, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb39
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb49
bb49:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l130, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l4, !tbaa !24
  %t210 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s5, ptr %t206, i1 false, i64 %t207)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l133
  br label %bb50
bb50:
  %t211 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s5, ptr %t211, ptr %l133)
  br label %bb51
bb51:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t213, ptr %t214)
  br label %bb52
bb52:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Block", ptr %t218, i32 0, i32 0
  %t221 = load i32, ptr %t220, !tbaa !23
  %t225 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v3, ptr %t217, ptr %l11, i32 %t221)
  store i64 %t225, ptr %l141
  br label %bb53
bb53:
  %t226 = load i64, ptr %l141, !tbaa !24
  %t227 = icmp eq i64 %t226, 0
  br i1 %t227, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb57:
  br label %bb31
bb58:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l143, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l4, !tbaa !24
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s0, ptr %t230, i1 true, i64 %t231)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l146
  br label %bb59
bb59:
  %t235 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t235, ptr %l146)
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Versions", ptr %t237, i32 0, i32 17
  %t241 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t239)
  %t242 = extractvalue { i32, i32 } %t241, 1
  %t243 = extractvalue { i32, i32 } %t241, 0
  store i32 %t243, ptr %l152
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb62, label %ok.245, !prof !99
ok.245:
  store i32 %t242, ptr %l151
  br label %bb61
bb61:
  %t246 = load i32, ptr %l151, !tbaa !23
  store i32 %t246, ptr %l148, !tbaa !23
  br label %bb69
bb62:
  %t247 = load i32, ptr %l152, !tbaa !23
  %t248 = icmp eq i32 %t247, 65536
  br i1 %t248, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78)
  unreachable
bb64:
  %t250 = load i32, ptr %l152, !tbaa !23
  %t251 = icmp eq i32 %t250, 65537
  br i1 %t251, label %bb65, label %bb66
bb65:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f658218d2a233859_f81a26e56b3c591d)
  unreachable
bb66:
  %t253 = load i32, ptr %l152, !tbaa !23
  %t254 = icmp eq i32 %t253, 65538
  br i1 %t254, label %bb67, label %bb68
bb67:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4c95fac740fe18b9_da00c3dfb70c298d)
  unreachable
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633)
  unreachable
bb69:
  store i64 0, ptr %l18, !tbaa !24
  %t256 = load i64, ptr %l3, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t260 = load i64, ptr %l19, !tbaa !24
  %t261 = load i64, ptr %l18, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb70, label %bb71
bb70:
  %t266 = load i64, ptr %l20, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb75
bb72:
  %t270 = load i64, ptr %l19, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l20, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l20, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l164, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb74
bb74:
  %t286 = load i64, ptr %l164, !tbaa !24
  store i64 %t286, ptr %l161, !tbaa !24
  br label %bb75
bb75:
  %t287 = load i64, ptr %l161, !tbaa !24
  store i64 %t287, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  %t288 = load i64, ptr %l22, !tbaa !24
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb77, label %bb78
bb77:
  br label %bb99
bb78:
  br label %bb79
bb79:
  %t296 = load i64, ptr %l18, !tbaa !24
  %t297 = load i64, ptr %l22, !tbaa !24
  %t298 = load i64, ptr %l20, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l23, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Versions", ptr %t306, i32 0, i32 18
  %t310 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t308)
  %t311 = extractvalue { i32, i64 } %t310, 1
  %t312 = extractvalue { i32, i64 } %t310, 0
  store i32 %t312, ptr %l186
  %t313 = icmp ne i32 %t312, 0
  br i1 %t313, label %bb81, label %ok.314, !prof !99
ok.314:
  store i64 %t311, ptr %l185
  br label %bb80
bb80:
  %t315 = load i64, ptr %l185, !tbaa !24
  store i64 %t315, ptr %l182, !tbaa !24
  br label %bb88
bb81:
  %t316 = load i32, ptr %l186, !tbaa !23
  %t317 = icmp eq i32 %t316, 65536
  br i1 %t317, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14)
  unreachable
bb83:
  %t319 = load i32, ptr %l186, !tbaa !23
  %t320 = icmp eq i32 %t319, 65537
  br i1 %t320, label %bb84, label %bb85
bb84:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69)
  unreachable
bb85:
  %t322 = load i32, ptr %l186, !tbaa !23
  %t323 = icmp eq i32 %t322, 65538
  br i1 %t323, label %bb86, label %bb87
bb86:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cb0f3499142fc19d_d94490f94af5f129)
  unreachable
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf)
  unreachable
bb88:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/typed:Versions", ptr %t325, i32 0, i32 19
  %t329 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t327)
  %t330 = extractvalue { i32, i64 } %t329, 1
  %t331 = extractvalue { i32, i64 } %t329, 0
  store i32 %t331, ptr %l194
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb90, label %ok.333, !prof !99
ok.333:
  store i64 %t330, ptr %l193
  br label %bb89
bb89:
  %t334 = load i64, ptr %l193, !tbaa !24
  store i64 %t334, ptr %l190, !tbaa !24
  br label %bb97
bb90:
  %t335 = load i32, ptr %l194, !tbaa !23
  %t336 = icmp eq i32 %t335, 65536
  br i1 %t336, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_14162ea47c0c801c_ce4205068f01e790)
  unreachable
bb92:
  %t338 = load i32, ptr %l194, !tbaa !23
  %t339 = icmp eq i32 %t338, 65537
  br i1 %t339, label %bb93, label %bb94
bb93:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a93f600a1cb39be1_ee16d2dfcadba585)
  unreachable
bb94:
  %t341 = load i32, ptr %l194, !tbaa !23
  %t342 = icmp eq i32 %t341, 65538
  br i1 %t342, label %bb95, label %bb96
bb95:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da)
  unreachable
bb96:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8726c5b979482c78_cdee9de0701e13e4)
  unreachable
bb97:
  br label %bb98
bb98:
  %t344 = load i64, ptr %l22, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l22, !tbaa !24
  br label %bb76
bb99:
  %t348 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca i64
  %l51 = alloca i64
  %l59 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = add i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l10, !tbaa !24
  store ptr %l4, ptr %l41, !tbaa !29
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Versions", ptr %t61, i32 0, i32 18
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t72)
  store i64 %t75, ptr %l51
  br label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Versions", ptr %t76, i32 0, i32 19
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t87)
  store i64 %t90, ptr %l59
  br label %bb16
bb15:
  %t91 = load i64, ptr %l51, !tbaa !24
  store i64 %t91, ptr %l43, !tbaa !24
  br label %bb17
bb16:
  %t92 = load i64, ptr %l59, !tbaa !24
  store i64 %t92, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l41, !tbaa !29
  %t94 = load i64, ptr %l43, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t93, i64 %t94)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l80 = alloca %"compiler/typed:Local"
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l199 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca ptr
  %l205 = alloca i1
  %l215 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l229 = alloca ptr
  %l230 = alloca i1
  %l240 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l241 = alloca ptr
  %l242 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca i1
  %l280 = alloca ptr
  %l282 = alloca { i64, ptr }
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca ptr
  %l287 = alloca i1
  %l300 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l306 = alloca i1
  %l320 = alloca i1
  %l328 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l356 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t8)
  store i1 %t10, ptr %l49
  br label %bb3
bb2:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i1, ptr %l49, !tbaa !21
  %t12 = xor i1 %t11, true
  store i1 %t12, ptr %l47, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l47, !tbaa !21
  store i1 %t14, ptr %l2, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l52
  br label %bb5
bb5:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 15
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l55
  br label %bb6
bb6:
  %t24 = load i64, ptr %l55, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t26 = load ptr, ptr %l56, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l56, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l57, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l57, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l5
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l6, !tbaa !23
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l7, !tbaa !29
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb12
bb12:
  %t57 = load i1, ptr %l2, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t64 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erecord(ptr %v0, ptr %s0, ptr %t59, i64 %t63, ptr %l3, i64 %t64)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store i1 false, ptr %l2, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Versions", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 7
  %t75 = load i32, ptr %l6, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t74, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l80
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l80, i32 0, i32 6
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l5
  %t88 = load i32, ptr %l6, !tbaa !23
  %t90 = sext i32 %t88 to i64
  %t91 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edefine(ptr %v0, ptr %v1, ptr %t86, %"compiler/source:Span" %t87, i64 %t90, ptr %t91, i1 true)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb190
bb22:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t98 = load ptr, ptr %l89, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l89, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 17}
  %t104 = icmp eq i64 %t102, 1
  store i1 %t104, ptr %l90, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l90, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l8
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [3 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l9, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l10, !tbaa !29
  br label %bb27
bb26:
  br label %bb45
bb27:
  %t124 = load ptr, ptr %l9, !tbaa !29
  store ptr %t124, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t125 = load ptr, ptr %l99, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t128 = load ptr, ptr %l99, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 8}
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l100, !tbaa !21
  br label %bb29
bb29:
  %t132 = load i1, ptr %l100, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb30, label %bb31
bb30:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  br label %bb34
bb34:
  %t144 = load i1, ptr %l2, !tbaa !21
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = sext i32 %t148 to i64
  %t151 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erecord(ptr %v0, ptr %s0, ptr %t146, i64 %t150, ptr %l3, i64 %t151)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  store i1 false, ptr %l2, !tbaa !21
  %t156 = load ptr, ptr %l9, !tbaa !29
  store ptr %t156, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t157 = load ptr, ptr %l115, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t160 = load ptr, ptr %l115, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 8}
  %t163 = icmp eq i64 %t161, 0
  store i1 %t163, ptr %l116, !tbaa !21
  br label %bb40
bb40:
  %t164 = load i1, ptr %l116, !tbaa !21
  br i1 %t164, label %bb41, label %bb42
bb41:
  %t165 = load ptr, ptr %l9, !tbaa !29
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t167, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l11
  %t171 = load ptr, ptr %l9, !tbaa !29
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l12, !tbaa !23
  %t177 = load ptr, ptr %l9, !tbaa !29
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t179, i32 0, i32 2
  %t181 = load i32, ptr %t180
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l8
  %t187 = sext i32 %t181 to i64
  %t188 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edefine(ptr %v0, ptr %v1, ptr %t183, %"compiler/source:Span" %t184, i64 %t187, ptr %t188, i1 false)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb190
bb45:
  %t194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t194, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t195 = load ptr, ptr %l131, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = load ptr, ptr %l131, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 17}
  %t201 = icmp eq i64 %t199, 2
  store i1 %t201, ptr %l132, !tbaa !21
  br label %bb47
bb47:
  %t202 = load i1, ptr %l132, !tbaa !21
  br i1 %t202, label %bb48, label %bb49
bb48:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l14, !tbaa !29
  br label %bb54
bb49:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t210 = load ptr, ptr %l137, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb50, label %bb51
bb50:
  %t213 = load ptr, ptr %l137, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 17}
  %t216 = icmp eq i64 %t214, 15
  store i1 %t216, ptr %l138, !tbaa !21
  br label %bb51
bb51:
  %t217 = load i1, ptr %l138, !tbaa !21
  br i1 %t217, label %bb52, label %bb53
bb52:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [3 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr }, ptr %t220, i32 0, i32 1
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l14, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t225)
  br label %bb55
bb55:
  br label %bb190
bb56:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t230 = load ptr, ptr %l146, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb57, label %bb58
bb57:
  %t233 = load ptr, ptr %l146, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 17}
  %t236 = icmp eq i64 %t234, 16
  store i1 %t236, ptr %l147, !tbaa !21
  br label %bb58
bb58:
  %t237 = load i1, ptr %l147, !tbaa !21
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", ptr }, ptr %t240, i32 0, i32 1
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l15, !tbaa !29
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t244, ptr %t245)
  br label %bb62
bb62:
  br label %bb190
bb63:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t249 = load ptr, ptr %l154, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb64, label %bb65
bb64:
  %t252 = load ptr, ptr %l154, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 17}
  %t255 = icmp eq i64 %t253, 6
  store i1 %t255, ptr %l155, !tbaa !21
  br label %bb65
bb65:
  %t256 = load i1, ptr %l155, !tbaa !21
  br i1 %t256, label %bb66, label %bb67
bb66:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr }, ptr %t259, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l16, !tbaa !29
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t263, ptr %t264)
  br label %bb69
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t267)
  br label %bb70
bb70:
  br label %bb190
bb71:
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t270 = load ptr, ptr %l163, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb72, label %bb73
bb72:
  %t273 = load ptr, ptr %l163, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 17}
  %t276 = icmp eq i64 %t274, 8
  store i1 %t276, ptr %l164, !tbaa !21
  br label %bb73
bb73:
  %t277 = load i1, ptr %l164, !tbaa !21
  br i1 %t277, label %bb74, label %bb75
bb74:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t280, i32 0, i32 1
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  br label %bb77
bb77:
  %t289 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t289)
  br label %bb78
bb78:
  br label %bb190
bb79:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t292 = load ptr, ptr %l173, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb80, label %bb81
bb80:
  %t295 = load ptr, ptr %l173, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 17}
  %t298 = icmp eq i64 %t296, 7
  store i1 %t298, ptr %l174, !tbaa !21
  br label %bb81
bb81:
  %t299 = load i1, ptr %l174, !tbaa !21
  br i1 %t299, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t300 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t300)
  br label %bb85
bb85:
  br label %bb190
bb86:
  %t302 = load ptr, ptr %l1, !tbaa !29
  store ptr %t302, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t303 = load ptr, ptr %l178, !tbaa !29
  %t304 = icmp ne ptr %t303, null
  br i1 %t304, label %bb87, label %bb88
bb87:
  %t306 = load ptr, ptr %l178, !tbaa !29
  %t307 = load i64, ptr %t306, !range !{i64 0, i64 17}
  %t309 = icmp eq i64 %t307, 9
  store i1 %t309, ptr %l179, !tbaa !21
  br label %bb88
bb88:
  %t310 = load i1, ptr %l179, !tbaa !21
  br i1 %t310, label %bb89, label %bb90
bb89:
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t313, i32 0, i32 2
  %t315 = load ptr, ptr %t314
  store ptr %t315, ptr %l18, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t317, ptr %t318)
  br label %bb92
bb92:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t321)
  br label %bb93
bb93:
  br label %bb190
bb94:
  %t323 = load ptr, ptr %l1, !tbaa !29
  store ptr %t323, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t324 = load ptr, ptr %l187, !tbaa !29
  %t325 = icmp ne ptr %t324, null
  br i1 %t325, label %bb95, label %bb96
bb95:
  %t327 = load ptr, ptr %l187, !tbaa !29
  %t328 = load i64, ptr %t327, !range !{i64 0, i64 17}
  %t330 = icmp eq i64 %t328, 10
  store i1 %t330, ptr %l188, !tbaa !21
  br label %bb96
bb96:
  %t331 = load i1, ptr %l188, !tbaa !21
  br i1 %t331, label %bb97, label %bb98
bb97:
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = getelementptr { i64, [3 x i64] }, ptr %t332, i32 0, i32 1
  %t335 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t334, i32 0, i32 1
  %t336 = load ptr, ptr %t335
  store ptr %t336, ptr %l19, !tbaa !29
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t340 = getelementptr { i64, [3 x i64] }, ptr %t338, i32 0, i32 1
  %t341 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t340, i32 0, i32 2
  %t342 = load ptr, ptr %t341
  store ptr %t342, ptr %l20, !tbaa !29
  br label %bb99
bb98:
  br label %bb104
bb99:
  store %olang.scope zeroinitializer, ptr %s14
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t345)
  br label %bb100
bb100:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s14, ptr %t349)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t351, ptr %l199
  br label %bb101
bb101:
  %t352 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l199
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t352, ptr %l21
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t353, ptr %t354)
  br label %bb102
bb102:
  %t357 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s14, ptr %t357, ptr %l21)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s14)
  br label %bb190
bb104:
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t361 = load ptr, ptr %l204, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb105, label %bb106
bb105:
  %t364 = load ptr, ptr %l204, !tbaa !29
  %t365 = load i64, ptr %t364, !range !{i64 0, i64 17}
  %t367 = icmp eq i64 %t365, 3
  store i1 %t367, ptr %l205, !tbaa !21
  br label %bb106
bb106:
  %t368 = load i1, ptr %l205, !tbaa !21
  br i1 %t368, label %bb107, label %bb108
bb107:
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t371 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { %"compiler/source:Span", ptr }, ptr %t371, i32 0, i32 1
  %t373 = load ptr, ptr %t372
  store ptr %t373, ptr %l22, !tbaa !29
  br label %bb109
bb108:
  br label %bb117
bb109:
  store %olang.scope zeroinitializer, ptr %s15
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l22, !tbaa !29
  %t378 = getelementptr %"compiler/typed:If", ptr %t376, i32 0, i32 0
  %t379 = load ptr, ptr %t378, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t375, ptr %t379)
  br label %bb110
bb110:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s15, ptr %t383)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %l215
  br label %bb111
bb111:
  %t386 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t386, ptr %l23
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l22, !tbaa !29
  %t390 = getelementptr %"compiler/typed:If", ptr %t388, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t387, ptr %t391)
  br label %bb112
bb112:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s15, ptr %t395)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t397, ptr %l221
  br label %bb113
bb113:
  %t398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %l24
  %t399 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s15, ptr %t399, ptr %l23)
  br label %bb114
bb114:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l22, !tbaa !29
  %t405 = getelementptr %"compiler/typed:If", ptr %t403, i32 0, i32 2
  %t406 = load ptr, ptr %t405, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t402, ptr %t406)
  br label %bb115
bb115:
  %t409 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s15, ptr %t409, ptr %l24)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s15)
  br label %bb190
bb117:
  %t412 = load ptr, ptr %l1, !tbaa !29
  store ptr %t412, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t413 = load ptr, ptr %l229, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb118, label %bb119
bb118:
  %t416 = load ptr, ptr %l229, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 17}
  %t419 = icmp eq i64 %t417, 4
  store i1 %t419, ptr %l230, !tbaa !21
  br label %bb119
bb119:
  %t420 = load i1, ptr %l230, !tbaa !21
  br i1 %t420, label %bb120, label %bb121
bb120:
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr { i64, [3 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t423, i32 0, i32 1
  %t425 = load ptr, ptr %t424
  store ptr %t425, ptr %l25, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t429 = getelementptr { i64, [3 x i64] }, ptr %t427, i32 0, i32 1
  %t430 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t429, i32 0, i32 2
  %t431 = load ptr, ptr %t430
  store ptr %t431, ptr %l26, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  store %olang.scope zeroinitializer, ptr %s16
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l25, !tbaa !29
  %t435 = load ptr, ptr %l26, !tbaa !29
  %t439 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %s16, ptr %t433, ptr %t434, ptr %t435)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439, ptr %l240
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s16)
  br label %bb190
bb124:
  %t440 = load ptr, ptr %l1, !tbaa !29
  store ptr %t440, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t441 = load ptr, ptr %l241, !tbaa !29
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %bb125, label %bb126
bb125:
  %t444 = load ptr, ptr %l241, !tbaa !29
  %t445 = load i64, ptr %t444, !range !{i64 0, i64 17}
  %t447 = icmp eq i64 %t445, 5
  store i1 %t447, ptr %l242, !tbaa !21
  br label %bb126
bb126:
  %t448 = load i1, ptr %l242, !tbaa !21
  br i1 %t448, label %bb127, label %bb128
bb127:
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t451 = getelementptr { i64, [3 x i64] }, ptr %t449, i32 0, i32 1
  %t452 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t451, i32 0, i32 1
  %t453 = load i32, ptr %t452, !range !{i32 0, i32 2}
  store i32 %t453, ptr %l27
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t457, i32 0, i32 2
  %t459 = load i32, ptr %t458
  store i32 %t459, ptr %l28, !tbaa !23
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i32, ptr %l27, !range !{i32 0, i32 2}
  %t463 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ejump(ptr %v0, ptr %t461, i32 %t462, i32 %t463)
  br label %bb130
bb130:
  br label %bb190
bb131:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t468 = load ptr, ptr %l252, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb132, label %bb133
bb132:
  %t471 = load ptr, ptr %l252, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 17}
  %t474 = icmp eq i64 %t472, 11
  store i1 %t474, ptr %l253, !tbaa !21
  br label %bb133
bb133:
  %t475 = load i1, ptr %l253, !tbaa !21
  br i1 %t475, label %bb134, label %bb135
bb134:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [3 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr }, ptr %t478, i32 0, i32 1
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l29, !tbaa !29
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t482, ptr %t483)
  br label %bb137
bb137:
  br label %bb190
bb138:
  %t487 = load ptr, ptr %l1, !tbaa !29
  store ptr %t487, ptr %l261, !tbaa !29
  store i1 false, ptr %l262, !tbaa !21
  %t488 = load ptr, ptr %l261, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb139, label %bb140
bb139:
  %t491 = load ptr, ptr %l261, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 17}
  %t494 = icmp eq i64 %t492, 12
  store i1 %t494, ptr %l262, !tbaa !21
  br label %bb140
bb140:
  %t495 = load i1, ptr %l262, !tbaa !21
  br i1 %t495, label %bb141, label %bb142
bb141:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [3 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", ptr }, ptr %t498, i32 0, i32 1
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l30, !tbaa !29
  br label %bb143
bb142:
  br label %bb145
bb143:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2elater(ptr %v0, ptr %v1, ptr %t502, ptr %t503)
  br label %bb144
bb144:
  br label %bb190
bb145:
  %t507 = load ptr, ptr %l1, !tbaa !29
  store ptr %t507, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t508 = load ptr, ptr %l270, !tbaa !29
  %t509 = icmp ne ptr %t508, null
  br i1 %t509, label %bb146, label %bb147
bb146:
  %t511 = load ptr, ptr %l270, !tbaa !29
  %t512 = load i64, ptr %t511, !range !{i64 0, i64 17}
  %t514 = icmp eq i64 %t512, 13
  store i1 %t514, ptr %l271, !tbaa !21
  br label %bb147
bb147:
  %t515 = load i1, ptr %l271, !tbaa !21
  br i1 %t515, label %bb148, label %bb149
bb148:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [3 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", ptr }, ptr %t518, i32 0, i32 1
  %t520 = load ptr, ptr %t519
  store ptr %t520, ptr %l31, !tbaa !29
  br label %bb150
bb149:
  br label %bb154
bb150:
  store %olang.scope zeroinitializer, ptr %s20
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l31, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Join", ptr %t523, i32 0, i32 0
  %t526 = load ptr, ptr %t525, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t522, ptr %t526)
  br label %bb151
bb151:
  %t530 = load ptr, ptr %l0, !tbaa !29
  store ptr %t530, ptr %l280, !tbaa !29
  %t531 = load ptr, ptr %l31, !tbaa !29
  %t533 = getelementptr %"compiler/typed:Join", ptr %t531, i32 0, i32 2
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !27
  store { i64, ptr } %t534, ptr %l282, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s20, ptr %t535)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t537, ptr %l284
  br label %bb152
bb152:
  %t538 = load ptr, ptr %l280, !tbaa !29
  %t539 = load { i64, ptr }, ptr %l282, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %s20, ptr %t538, { i64, ptr } %t539, ptr %l284, i1 true)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s20)
  br label %bb190
bb154:
  %t541 = load ptr, ptr %l1, !tbaa !29
  store ptr %t541, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t542 = load ptr, ptr %l286, !tbaa !29
  %t543 = icmp ne ptr %t542, null
  br i1 %t543, label %bb155, label %bb156
bb155:
  %t545 = load ptr, ptr %l286, !tbaa !29
  %t546 = load i64, ptr %t545, !range !{i64 0, i64 17}
  %t548 = icmp eq i64 %t546, 14
  store i1 %t548, ptr %l287, !tbaa !21
  br label %bb156
bb156:
  %t549 = load i1, ptr %l287, !tbaa !21
  br i1 %t549, label %bb157, label %bb158
bb157:
  %t550 = load ptr, ptr %l1, !tbaa !29
  %t552 = getelementptr { i64, [3 x i64] }, ptr %t550, i32 0, i32 1
  %t553 = getelementptr { %"compiler/source:Span", ptr }, ptr %t552, i32 0, i32 1
  %t554 = load ptr, ptr %t553
  store ptr %t554, ptr %l32, !tbaa !29
  br label %bb159
bb158:
  br label %bb189
bb159:
  %t556 = load ptr, ptr %l32, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Spawn", ptr %t556, i32 0, i32 0
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  store i64 %t563, ptr %l35, !tbaa !24
  br label %bb160
bb160:
  %t565 = load i64, ptr %l34, !tbaa !24
  %t566 = load i64, ptr %l35, !tbaa !24
  %t569 = icmp slt i64 %t565, %t566
  %t571 = xor i1 %t569, true
  br i1 %t571, label %bb161, label %bb162
bb161:
  br label %bb180
bb162:
  br label %bb163
bb163:
  %t573 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t573, ptr %l300, !tbaa !27
  %t574 = load i64, ptr %l34, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr ptr, ptr %t577, i64 %t574
  %t579 = load ptr, ptr %t578, !tbaa !39
  store ptr %t579, ptr %l36, !tbaa !29
  %t581 = load ptr, ptr %l36, !tbaa !29
  %t583 = icmp eq ptr %t581, null
  br i1 %t583, label %bb164, label %bb165
bb164:
  br label %bb179
bb165:
  br label %bb166
bb166:
  %t585 = load ptr, ptr %l36, !tbaa !29
  store ptr %t585, ptr %l305, !tbaa !29
  store i1 false, ptr %l306, !tbaa !21
  %t586 = load ptr, ptr %l305, !tbaa !29
  %t587 = icmp ne ptr %t586, null
  br i1 %t587, label %bb167, label %bb168
bb167:
  %t589 = load ptr, ptr %l305, !tbaa !29
  %t590 = load i64, ptr %t589, !range !{i64 0, i64 8}
  %t592 = icmp eq i64 %t590, 0
  store i1 %t592, ptr %l306, !tbaa !21
  br label %bb168
bb168:
  %t593 = load i1, ptr %l306, !tbaa !21
  %t594 = xor i1 %t593, true
  br i1 %t594, label %bb169, label %bb170
bb169:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t596, ptr %t597)
  br label %bb171
bb170:
  %t600 = load ptr, ptr %l36, !tbaa !29
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t602, i32 0, i32 0
  %t604 = load %"compiler/source:Span", ptr %t603
  store %"compiler/source:Span" %t604, ptr %l37
  %t606 = load ptr, ptr %l36, !tbaa !29
  %t608 = getelementptr { i64, [4 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t608, i32 0, i32 1
  %t610 = load i32, ptr %t609
  store i32 %t610, ptr %l38, !tbaa !23
  %t612 = load ptr, ptr %l36, !tbaa !29
  %t614 = getelementptr { i64, [4 x i64] }, ptr %t612, i32 0, i32 1
  %t615 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t614, i32 0, i32 2
  %t616 = load i32, ptr %t615
  store i32 %t616, ptr %l39, !tbaa !23
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Versions", ptr %t618, i32 0, i32 20
  %t621 = load i1, ptr %t620, !tbaa !21
  br i1 %t621, label %bb172, label %bb173
bb171:
  br label %bb178
bb172:
  %t623 = load i32, ptr %l39, !tbaa !23
  %t625 = sext i32 %t623 to i64
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t628 = getelementptr %"compiler/typed:Versions", ptr %t626, i32 0, i32 2
  %t629 = load { i64, ptr }, ptr %t628, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t634 = icmp slt i64 %t625, %t631
  store i1 %t634, ptr %l320, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb174
bb174:
  %t636 = load i1, ptr %l320, !tbaa !21
  br i1 %t636, label %bb175, label %bb176
bb175:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Versions", ptr %t637, i32 0, i32 2
  %t640 = load { i64, ptr }, ptr %t639, !tbaa !27
  store { i64, ptr } %t640, ptr %l328, !tbaa !27
  %t641 = load i32, ptr %l39, !tbaa !23
  %t643 = sext i32 %t641 to i64
  %t645 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr i1, ptr %t646, i64 %t643
  store i1 false, ptr %t647, !tbaa !31
  br label %bb177
bb176:
  br label %bb177
bb177:
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t648 = load i64, ptr %l34, !tbaa !24
  %t650 = add i64 %t648, 1
  store i64 %t650, ptr %l34, !tbaa !24
  br label %bb160
bb180:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t653 = load ptr, ptr %l32, !tbaa !29
  %t655 = getelementptr %"compiler/typed:Spawn", ptr %t653, i32 0, i32 1
  %t656 = load ptr, ptr %t655, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t652, ptr %t656)
  br label %bb181
bb181:
  %t660 = load ptr, ptr %l32, !tbaa !29
  %t662 = getelementptr %"compiler/typed:Spawn", ptr %t660, i32 0, i32 2
  %t663 = load { i64, ptr }, ptr %t662, !tbaa !27
  store { i64, ptr } %t663, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t665 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t665, 0
  store i64 %t667, ptr %l42, !tbaa !24
  br label %bb182
bb182:
  %t669 = load i64, ptr %l41, !tbaa !24
  %t670 = load i64, ptr %l42, !tbaa !24
  %t673 = icmp slt i64 %t669, %t670
  %t675 = xor i1 %t673, true
  br i1 %t675, label %bb183, label %bb184
bb183:
  br label %bb188
bb184:
  br label %bb185
bb185:
  %t677 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t677, ptr %l345, !tbaa !27
  %t678 = load i64, ptr %l41, !tbaa !24
  %t680 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t681 = load ptr, ptr %t680, !tbaa !27
  %t682 = getelementptr ptr, ptr %t681, i64 %t678
  %t683 = load ptr, ptr %t682, !tbaa !39
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/typed:TaskClause", ptr %t683, i32 0, i32 3
  %t689 = load ptr, ptr %t688, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t685, ptr %t689)
  br label %bb186
bb186:
  br label %bb187
bb187:
  %t692 = load i64, ptr %l41, !tbaa !24
  %t694 = add i64 %t692, 1
  store i64 %t694, ptr %l41, !tbaa !24
  br label %bb182
bb188:
  br label %bb190
bb189:
  call void @__olang_check_failed(ptr @olang_loc_89804b2e92d33dd7_8d0f976d28b858c3)
  unreachable
bb190:
  %t696 = load i1, ptr %l2, !tbaa !21
  br i1 %t696, label %bb191, label %bb192
bb191:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l354, !tbaa !29
  %t699 = load ptr, ptr %l1, !tbaa !29
  %t701 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t699)
  store %"compiler/source:Span" %t701, ptr %l356
  br label %bb193
bb192:
  br label %bb195
bb193:
  %t702 = getelementptr %"compiler/source:Span", ptr %l356, i32 0, i32 0
  %t703 = load i32, ptr %t702, !tbaa !23
  %t705 = sext i32 %t703 to i64
  %t706 = load i64, ptr %l4, !tbaa !24
  %t707 = load ptr, ptr %l354, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erecord(ptr %v0, ptr %s0, ptr %t707, i64 %t705, ptr %l3, i64 %t706)
  br label %bb194
bb194:
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sle i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t15 = and i64 %t11, %t12
  %t17 = icmp ne i64 %t15, 0
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t26, i64 %t27)
  store i64 %t30, ptr %l26
  br label %bb8
bb8:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l33, !tbaa !24
  store i64 %t58, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  store i64 %t79, ptr %l52, !tbaa !24
  %t80 = load i64, ptr %l52, !tbaa !24
  %t81 = load i64, ptr %l52, !tbaa !24
  %t82 = shl i64 1, %t81
  %t85 = and i64 %t78, %t82
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Call", ptr %t90, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l58, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t102 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t89, ptr %t99)
  store i64 %t102, ptr %l61
  br label %bb22
bb22:
  %t103 = load i64, ptr %l61, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sle i64 %t104, 0
  br i1 %t106, label %bb23, label %bb24
bb23:
  store i64 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l3, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = or i64 %t109, %t110
  store i64 %t113, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb15
bb27:
  %t119 = load i64, ptr %l3, !tbaa !24
  store i64 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t21, ptr %t22)
  store i64 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i64, ptr %l24, !tbaa !24
  store i64 %t26, ptr %l15, !tbaa !24
  br label %bb101
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Slice", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t49 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t42, ptr %t46)
  store i64 %t49, ptr %l34
  br label %bb16
bb16:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l15, !tbaa !24
  br label %bb101
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 6
  store i1 %t58, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t70 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t66, ptr %t67)
  store i64 %t70, ptr %l43
  br label %bb23
bb23:
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l15, !tbaa !24
  br label %bb101
bb24:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 11
  store i1 %t79, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t80 = load i1, ptr %l45, !tbaa !21
  br i1 %t80, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Cond", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t94 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t87, ptr %t91)
  store i64 %t94, ptr %l53
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Cond", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t99)
  store i64 %t103, ptr %l58
  br label %bb31
bb31:
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = load i64, ptr %l58, !tbaa !24
  %t106 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t104, i64 %t105)
  store i64 %t106, ptr %l59
  br label %bb32
bb32:
  %t107 = load i64, ptr %l59, !tbaa !24
  store i64 %t107, ptr %l15, !tbaa !24
  br label %bb101
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l60, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 13
  store i1 %t115, ptr %l61, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t127 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t123, ptr %t124)
  store i64 %t127, ptr %l68
  br label %bb39
bb39:
  %t128 = load i64, ptr %l68, !tbaa !24
  store i64 %t128, ptr %l15, !tbaa !24
  br label %bb101
bb40:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t130 = load ptr, ptr %l69, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb41, label %bb42
bb41:
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 14
  store i1 %t136, ptr %l70, !tbaa !21
  br label %bb42
bb42:
  %t137 = load i1, ptr %l70, !tbaa !21
  br i1 %t137, label %bb43, label %bb44
bb43:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l7, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  %t148 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t144, ptr %t145)
  store i64 %t148, ptr %l77
  br label %bb46
bb46:
  %t149 = load i64, ptr %l77, !tbaa !24
  store i64 %t149, ptr %l15, !tbaa !24
  br label %bb101
bb47:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t151 = load ptr, ptr %l78, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb48, label %bb49
bb48:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 12
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb49
bb49:
  %t158 = load i1, ptr %l79, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l8, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Seq", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t172 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t165, ptr %t169)
  store i64 %t172, ptr %l87
  br label %bb53
bb53:
  %t173 = load i64, ptr %l87, !tbaa !24
  store i64 %t173, ptr %l15, !tbaa !24
  br label %bb101
bb54:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t175 = load ptr, ptr %l88, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb55, label %bb56
bb55:
  %t178 = load ptr, ptr %l88, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 18}
  %t181 = icmp eq i64 %t179, 17
  store i1 %t181, ptr %l89, !tbaa !21
  br label %bb56
bb56:
  %t182 = load i1, ptr %l89, !tbaa !21
  br i1 %t182, label %bb57, label %bb58
bb57:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t194 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t189, ptr %t190)
  store i64 %t194, ptr %l97
  br label %bb60
bb60:
  %t195 = load i64, ptr %l97, !tbaa !24
  store i64 %t195, ptr %l15, !tbaa !24
  br label %bb101
bb61:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb62, label %bb63
bb62:
  %t200 = load ptr, ptr %l98, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 9
  store i1 %t203, ptr %l99, !tbaa !21
  br label %bb63
bb63:
  %t204 = load i1, ptr %l99, !tbaa !21
  br i1 %t204, label %bb64, label %bb65
bb64:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t207, i32 0, i32 2
  %t209 = load i32, ptr %t208, !range !{i32 0, i32 51}
  store i32 %t209, ptr %l10
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t213, i32 0, i32 4
  %t215 = load { i64, ptr }, ptr %t214
  store { i64, ptr } %t215, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t217 = load i32, ptr %l10, !range !{i32 0, i32 51}
  %t219 = trunc i64 20 to i32
  %t220 = icmp eq i32 %t217, %t219
  br i1 %t220, label %bb67, label %bb68
bb67:
  %t222 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t226 = icmp eq i64 %t224, 1
  store i1 %t226, ptr %l108, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb69
bb69:
  %t228 = load i1, ptr %l108, !tbaa !21
  br i1 %t228, label %bb70, label %bb71
bb70:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t230, ptr %l114, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 0
  %t234 = load ptr, ptr %t233, !tbaa !39
  %t238 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t229, ptr %t234)
  store i64 %t238, ptr %l117
  br label %bb72
bb71:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb73
bb72:
  %t239 = load i64, ptr %l117, !tbaa !24
  store i64 %t239, ptr %l112, !tbaa !24
  br label %bb73
bb73:
  %t240 = load i64, ptr %l112, !tbaa !24
  store i64 %t240, ptr %l15, !tbaa !24
  br label %bb101
bb74:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t242 = load ptr, ptr %l118, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb75, label %bb76
bb75:
  %t245 = load ptr, ptr %l118, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 18}
  %t248 = icmp eq i64 %t246, 7
  store i1 %t248, ptr %l119, !tbaa !21
  br label %bb76
bb76:
  %t249 = load i1, ptr %l119, !tbaa !21
  br i1 %t249, label %bb77, label %bb78
bb77:
  br label %bb95
bb78:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb79, label %bb80
bb79:
  %t254 = load ptr, ptr %l122, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 18}
  %t257 = icmp eq i64 %t255, 8
  store i1 %t257, ptr %l123, !tbaa !21
  br label %bb80
bb80:
  %t258 = load i1, ptr %l123, !tbaa !21
  br i1 %t258, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t260 = load ptr, ptr %l126, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb83, label %bb84
bb83:
  %t263 = load ptr, ptr %l126, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 16
  store i1 %t266, ptr %l127, !tbaa !21
  br label %bb84
bb84:
  %t267 = load i1, ptr %l127, !tbaa !21
  br i1 %t267, label %bb85, label %bb86
bb85:
  br label %bb95
bb86:
  %t268 = load ptr, ptr %l1, !tbaa !29
  store ptr %t268, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t269 = load ptr, ptr %l130, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb87, label %bb88
bb87:
  %t272 = load ptr, ptr %l130, !tbaa !29
  %t273 = load i64, ptr %t272, !range !{i64 0, i64 18}
  %t275 = icmp eq i64 %t273, 0
  store i1 %t275, ptr %l131, !tbaa !21
  br label %bb88
bb88:
  %t276 = load i1, ptr %l131, !tbaa !21
  br i1 %t276, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t278 = load ptr, ptr %l134, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb91, label %bb92
bb91:
  %t281 = load ptr, ptr %l134, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 18}
  %t284 = icmp eq i64 %t282, 15
  store i1 %t284, ptr %l135, !tbaa !21
  br label %bb92
bb92:
  %t285 = load i1, ptr %l135, !tbaa !21
  br i1 %t285, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_c8b3a2ed155d5757_c640a14e4e3ad273)
  unreachable
bb101:
  %t286 = load i64, ptr %l15, !tbaa !24
  store i64 %t286, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:ViewWalk", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v2, ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t18 = call ptr @compiler_2ftyped_2ecopied(ptr %t15, ptr %v1, ptr %v1, ptr %t16, ptr %t10)
  store ptr %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l11, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t25, ptr %t26)
  store i64 %t30, ptr %l18
  br label %bb8
bb8:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca i64
  %l23 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l48 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l56 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = getelementptr %"compiler/typed:dropWalk", ptr %t12, i32 0, i32 4
  store i64 %t10, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 5
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t45, ptr %t43)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:dropWalk", ptr %t54, i32 0, i32 4
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = sub i64 %t57, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t53, i64 %t59)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:dropWalk", ptr %t62, i32 0, i32 5
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t70 = icmp sgt i64 %t68, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:dropWalk", ptr %t74, i32 0, i32 5
  %t78 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t76)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l44
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb19, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l43
  br label %bb18
bb18:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l40, !tbaa !24
  br label %bb26
bb19:
  %t84 = load i32, ptr %l44, !tbaa !23
  %t85 = icmp eq i32 %t84, 65536
  br i1 %t85, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_17c315ca28f40c4c_14b80e258f8c2b0)
  unreachable
bb21:
  %t87 = load i32, ptr %l44, !tbaa !23
  %t88 = icmp eq i32 %t87, 65537
  br i1 %t88, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5)
  unreachable
bb23:
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = icmp eq i32 %t90, 65538
  br i1 %t91, label %bb24, label %bb25
bb24:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6fe9eb3ff5642bc1_33392e6f48613205)
  unreachable
bb25:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5f1ddc7ef7469727_e10177d23ca0510b)
  unreachable
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:dropWalk", ptr %t93, i32 0, i32 6
  %t97 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l52
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb28, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l51
  br label %bb27
bb27:
  %t102 = load i64, ptr %l51, !tbaa !24
  store i64 %t102, ptr %l48, !tbaa !24
  br label %bb35
bb28:
  %t103 = load i32, ptr %l52, !tbaa !23
  %t104 = icmp eq i32 %t103, 65536
  br i1 %t104, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_24a3ccdd47c97c70_8558c77bc7af118c)
  unreachable
bb30:
  %t106 = load i32, ptr %l52, !tbaa !23
  %t107 = icmp eq i32 %t106, 65537
  br i1 %t107, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_130a89b2782f12a5_38e9334e27b56d91)
  unreachable
bb32:
  %t109 = load i32, ptr %l52, !tbaa !23
  %t110 = icmp eq i32 %t109, 65538
  br i1 %t110, label %bb33, label %bb34
bb33:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1916e27cc0da8fc5_b948d7408e366d01)
  unreachable
bb34:
  call void @__olang_bang_failed_plain(ptr @olang_loc_567e5689d7ac5ccb_d57870be630e767)
  unreachable
bb35:
  br label %bb36
bb36:
  br label %bb13
bb37:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l56, !tbaa !29
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = getelementptr %"compiler/typed:dropWalk", ptr %t113, i32 0, i32 4
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = load ptr, ptr %l56, !tbaa !29
  %t120 = getelementptr %"compiler/typed:dropWalk", ptr %t119, i32 0, i32 4
  store i64 %t117, ptr %t120, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l142 = alloca i64
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l33, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t34)
  store { i64, ptr } %t36, ptr %l41
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l42, !tbaa !24
  %t39 = load i64, ptr %l42, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l43, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l42, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t51 = ptrtoint ptr %s0 to i64
  store i64 %t51, ptr %l44, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = call ptr @__olang_region_make(ptr %s0)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l44, !tbaa !24
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l44
  %t58 = inttoptr i64 %t57 to ptr
  %t60 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %t58, ptr %t56)
  store { i64, ptr } %t60, ptr %l47
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l48, !tbaa !24
  %t63 = load i64, ptr %l48, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = load i64, ptr %l44
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l49, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l48, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load i64, ptr %l44
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = load { i64, ptr }, ptr %l49
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = icmp ne ptr %t82, null
  %t84 = select i1 %t83, ptr %t82, ptr null
  %t85 = icmp eq ptr %t84, %t79
  call void @__olang_region_settle(ptr %t79, i1 %t85)
  br label %bb13
bb13:
  %t86 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:dropWalk", ptr %t87, i32 0, i32 2
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l53
  br label %bb14
bb14:
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t92
  store i1 true, ptr %t95, !tbaa !31
  %t96 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l54
  br label %bb15
bb15:
  %t97 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l8
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t115, ptr %l63, !tbaa !27
  %t116 = load i64, ptr %l10, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t116
  %t121 = load ptr, ptr %t120, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %v1, ptr %l8, ptr %t121)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l10, !tbaa !24
  br label %bb16
bb22:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Match", ptr %t130, i32 0, i32 2
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb23, label %bb24
bb23:
  store ptr %l8, ptr %l74, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Match", ptr %t139, i32 0, i32 2
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb25, label %bb26
bb24:
  br label %bb29
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f5a8870640a369c_e3a704984aad8c8)
  unreachable
bb26:
  br label %bb27
bb27:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Match", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %v1, ptr %t150, ptr %t149)
  br label %bb28
bb28:
  br label %bb29
bb29:
  store ptr %l8, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t153 = load i64, ptr %l14, !tbaa !24
  store i64 %t153, ptr %l81, !tbaa !24
  %t154 = load ptr, ptr %l13, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eLen_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %t154)
  store i64 %t156, ptr %l83
  br label %bb31
bb31:
  %t157 = load i64, ptr %l81, !tbaa !24
  %t158 = load i64, ptr %l83, !tbaa !24
  %t159 = icmp slt i64 %t157, %t158
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb33:
  br label %bb34
bb34:
  %t163 = load ptr, ptr %l13, !tbaa !29
  %t164 = load i64, ptr %l14, !tbaa !24
  %t167 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eAt_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %s0, ptr %t163, i64 %t164)
  store ptr %t167, ptr %l88
  br label %bb35
bb35:
  %t168 = load ptr, ptr %l88, !tbaa !29
  store ptr %t168, ptr %l15, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t169, { i64, ptr } %t170)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l15, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Arm", ptr %t173, i32 0, i32 1
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  store i64 %t180, ptr %l18, !tbaa !24
  br label %bb37
bb37:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l18, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb38, label %bb39
bb38:
  br label %bb50
bb39:
  br label %bb40
bb40:
  %t190 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t190, ptr %l99, !tbaa !27
  %t191 = load i64, ptr %l17, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr ptr, ptr %t194, i64 %t191
  %t196 = load ptr, ptr %t195, !tbaa !39
  store ptr %t196, ptr %l19, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l19, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Alt", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t198, ptr %t202)
  br label %bb41
bb41:
  %t206 = load ptr, ptr %l19, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Alt", ptr %t206, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t216 = load i64, ptr %l22, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t223 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t223, ptr %l114, !tbaa !27
  %t224 = load i64, ptr %l21, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 %t224
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Bind", ptr %t229, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t231, ptr %t235)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t239 = load i64, ptr %l21, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l21, !tbaa !24
  br label %bb42
bb48:
  br label %bb49
bb49:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l17, !tbaa !24
  br label %bb37
bb50:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l15, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Arm", ptr %t248, i32 0, i32 2
  %t251 = load ptr, ptr %t250, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t247, ptr %t251)
  br label %bb51
bb51:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l15, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Arm", ptr %t255, i32 0, i32 3
  %t258 = load ptr, ptr %t257, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %s0, ptr %t254, ptr %t258)
  br label %bb52
bb52:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l15, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Arm", ptr %t262, i32 0, i32 4
  %t265 = load ptr, ptr %t264, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t261, ptr %t265)
  br label %bb53
bb53:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s9, ptr %t268)
  store { i64, ptr } %t270, ptr %l135
  br label %bb54
bb54:
  %t271 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l136, !tbaa !24
  %t273 = load i64, ptr %l136, !tbaa !24
  %t274 = mul i64 %t273, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l137, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l136, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  %t284 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t284, ptr %l24, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t285, { i64, ptr } %t286)
  br label %bb55
bb55:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s9, ptr %t289, { i64, ptr } %t290)
  br label %bb56
bb56:
  %t293 = ptrtoint ptr %s0 to i64
  store i64 %t293, ptr %l142, !tbaa !24
  %t294 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7
  br i1 %t294, label %bb57, label %bb58
bb57:
  %t296 = call ptr @__olang_region_make(ptr %s0)
  %t297 = ptrtoint ptr %t296 to i64
  store i64 %t297, ptr %l142, !tbaa !24
  br label %bb58
bb58:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i64, ptr %l142
  %t300 = inttoptr i64 %t299 to ptr
  %t302 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %t300, ptr %t298)
  store { i64, ptr } %t302, ptr %l145
  br label %bb59
bb59:
  %t303 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l146, !tbaa !24
  %t305 = load i64, ptr %l146, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = load i64, ptr %l142
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = call ptr @__olang_held_alloc(ptr %t308, i64 %t306)
  %t310 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  store { i64, ptr } %t311, ptr %l147, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = load i64, ptr %l146, !tbaa !24
  %t317 = mul i64 %t316, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t313, ptr %t315, i64 %t317, i1 false)
  %t318 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7
  br i1 %t318, label %bb60, label %bb61
bb60:
  %t320 = load i64, ptr %l142
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = load { i64, ptr }, ptr %l147
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = call ptr @__olang_region_or(ptr %t323, ptr null)
  %t325 = icmp ne ptr %t324, null
  %t326 = select i1 %t325, ptr %t324, ptr null
  %t327 = icmp eq ptr %t326, %t321
  call void @__olang_region_settle(ptr %t321, i1 %t327)
  br label %bb61
bb61:
  %t328 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7
  br i1 %t328, label %bb62, label %bb63
bb62:
  %t330 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t330, ptr %l150, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t331, ptr %l7, !tbaa !27
  %t332 = load { i64, ptr }, ptr %l150
  %t333 = extractvalue { i64, ptr } %t332, 1
  call void @__olang_region_release(ptr %t333)
  store { i64, ptr } zeroinitializer, ptr %l150
  br label %bb64
bb63:
  %t334 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l152, !tbaa !24
  %t339 = load i64, ptr %l152, !tbaa !24
  %t340 = icmp eq i64 %t335, %t339
  br i1 %t340, label %bb65, label %bb66
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb65:
  %t342 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = load i64, ptr %l152, !tbaa !24
  %t347 = mul i64 %t346, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t343, ptr %t345, i64 %t347, i1 false)
  br label %bb67
bb66:
  %t348 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t348, ptr %l7, !tbaa !27
  br label %bb67
bb67:
  br label %bb64
bb68:
  %t349 = load i64, ptr %l14, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l14, !tbaa !24
  br label %bb30
bb69:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t353, { i64, ptr } %t354)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l8
  br label %bb3
bb3:
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 1
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:dropWalk", ptr %t18, i32 0, i32 2
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t23, i64 %t24, i64 %t25)
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:dropWalk", ptr %t26, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 false)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = add i64 %t6, 1
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t16, ptr %lp1
  %t18 = load ptr, ptr %lp1
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:dropWalk", ptr %t19, i32 0, i32 2
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l16
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_c1faed4ae36d3640_1d7aa47a4727493c)
  unreachable
bb4:
  %t24 = load i64, ptr %l16, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l23, !tbaa !24
  store i64 %t51, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l20, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/typed:dropWalk", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t74, i64 %t75)
  store i1 %t78, ptr %l45
  br label %bb15
bb15:
  %t79 = load i1, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr %lp1
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i1, ptr %t83, i64 %t81
  store i1 %t79, ptr %t84, !tbaa !31
  br label %bb16
bb16:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:dropWalk", ptr %t89, i32 0, i32 2
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l50
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:dropWalk", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  %t99 = load ptr, ptr %lp1
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t97, ptr %t103, !tbaa !31
  %t104 = load ptr, ptr %lp1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l82 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l111 = alloca i64
  %l120 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i32
  %l131 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i32
  %l179 = alloca { i64, ptr }
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 11
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l34
  br label %bb2
bb2:
  %t12 = load i64, ptr %l34, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 11
  store ptr %t15, ptr %l36, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l39, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = load i1, ptr %l39, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 %t29)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t32, i64 %t36)
  br label %bb7
bb7:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb13
bb10:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l54, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l54, !tbaa !24
  store i64 %t67, ptr %l51, !tbaa !24
  br label %bb13
bb13:
  %t68 = load i64, ptr %l51, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:dropWalk", ptr %t87, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t89, i1 false)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb14
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:dropWalk", ptr %t95, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t97, i1 true)
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Try", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb22
bb22:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l82, !tbaa !24
  %t109 = load i64, ptr %l82, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load i64, ptr %l82, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2cf1608fd5d1230c_1374e48cd144e348)
  unreachable
bb25:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb30
bb27:
  %t132 = load i64, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l93, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb29
bb29:
  %t148 = load i64, ptr %l93, !tbaa !24
  store i64 %t148, ptr %l90, !tbaa !24
  br label %bb30
bb30:
  %t149 = load i64, ptr %l90, !tbaa !24
  store i64 %t149, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t150 = load i64, ptr %l15, !tbaa !24
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l16, !tbaa !24
  store i64 %t168, ptr %l111, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:dropWalk", ptr %t169, i32 0, i32 13
  %t172 = load i64, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l2, !tbaa !24
  %t175 = add i64 %t173, 1
  %t178 = mul i64 %t172, %t175
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t185 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t171, i64 %t182)
  store i1 %t185, ptr %l120
  br label %bb35
bb35:
  %t186 = load i1, ptr %l120, !tbaa !21
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t187
  store i1 %t186, ptr %t190, !tbaa !31
  br label %bb36
bb36:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb31
bb37:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/typed:dropWalk", ptr %t195, i32 0, i32 11
  %t199 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t197)
  %t200 = extractvalue { i32, i1 } %t199, 1
  %t201 = extractvalue { i32, i1 } %t199, 0
  store i32 %t201, ptr %l127
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb39, label %ok.203, !prof !99
ok.203:
  store i1 %t200, ptr %l126
  br label %bb38
bb38:
  %t204 = load i1, ptr %l126, !tbaa !21
  store i1 %t204, ptr %l123, !tbaa !21
  br label %bb46
bb39:
  %t205 = load i32, ptr %l127, !tbaa !23
  %t206 = icmp eq i32 %t205, 65536
  br i1 %t206, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_73be6a0e490978a7_b5fa18d3e7eede33)
  unreachable
bb41:
  %t208 = load i32, ptr %l127, !tbaa !23
  %t209 = icmp eq i32 %t208, 65537
  br i1 %t209, label %bb42, label %bb43
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fb6091d652311b2_1c71a9a414fce87e)
  unreachable
bb43:
  %t211 = load i32, ptr %l127, !tbaa !23
  %t212 = icmp eq i32 %t211, 65538
  br i1 %t212, label %bb44, label %bb45
bb44:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8c1b8241682c8a5c_1491e83e9da6f28)
  unreachable
bb45:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fc9df9522ae1330_697d53c50db00ce4)
  unreachable
bb46:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:dropWalk", ptr %t214, i32 0, i32 12
  %t218 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t216)
  %t219 = extractvalue { i32, i64 } %t218, 1
  %t220 = extractvalue { i32, i64 } %t218, 0
  store i32 %t220, ptr %l135
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb48, label %ok.222, !prof !99
ok.222:
  store i64 %t219, ptr %l134
  br label %bb47
bb47:
  %t223 = load i64, ptr %l134, !tbaa !24
  store i64 %t223, ptr %l131, !tbaa !24
  br label %bb55
bb48:
  %t224 = load i32, ptr %l135, !tbaa !23
  %t225 = icmp eq i32 %t224, 65536
  br i1 %t225, label %bb49, label %bb50
bb49:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e4195c8d52320dab_6e5abcaf8844f88f)
  unreachable
bb50:
  %t227 = load i32, ptr %l135, !tbaa !23
  %t228 = icmp eq i32 %t227, 65537
  br i1 %t228, label %bb51, label %bb52
bb51:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6df7d27e20fc18e6_9af88db0bee394aa)
  unreachable
bb52:
  %t230 = load i32, ptr %l135, !tbaa !23
  %t231 = icmp eq i32 %t230, 65538
  br i1 %t231, label %bb53, label %bb54
bb53:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c52364142dc414a0_4d1da6470710a144)
  unreachable
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730)
  unreachable
bb55:
  store i64 0, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb56, label %bb57
bb56:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb61
bb58:
  %t247 = load i64, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l147, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l147, !tbaa !24
  store i64 %t263, ptr %l144, !tbaa !24
  br label %bb61
bb61:
  %t264 = load i64, ptr %l144, !tbaa !24
  store i64 %t264, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  %t265 = load i64, ptr %l21, !tbaa !24
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l19, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l22, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/typed:dropWalk", ptr %t283, i32 0, i32 13
  %t287 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t285)
  %t288 = extractvalue { i32, i1 } %t287, 1
  %t289 = extractvalue { i32, i1 } %t287, 0
  store i32 %t289, ptr %l169
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb67, label %ok.291, !prof !99
ok.291:
  store i1 %t288, ptr %l168
  br label %bb66
bb66:
  %t292 = load i1, ptr %l168, !tbaa !21
  store i1 %t292, ptr %l165, !tbaa !21
  br label %bb74
bb67:
  %t293 = load i32, ptr %l169, !tbaa !23
  %t294 = icmp eq i32 %t293, 65536
  br i1 %t294, label %bb68, label %bb69
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab)
  unreachable
bb69:
  %t296 = load i32, ptr %l169, !tbaa !23
  %t297 = icmp eq i32 %t296, 65537
  br i1 %t297, label %bb70, label %bb71
bb70:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cdd2e50680d68485_7d51e204495f7309)
  unreachable
bb71:
  %t299 = load i32, ptr %l169, !tbaa !23
  %t300 = icmp eq i32 %t299, 65538
  br i1 %t300, label %bb72, label %bb73
bb72:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2ee7063c57fe9793_68bf97cc73752027)
  unreachable
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f)
  unreachable
bb74:
  br label %bb75
bb75:
  %t302 = load i64, ptr %l21, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l21, !tbaa !24
  br label %bb62
bb76:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Try", ptr %t306, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t313 = icmp eq i64 %t311, 0
  br i1 %t313, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t315 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t315, ptr %l179, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l180, !tbaa !24
  %t318 = load i64, ptr %l180, !tbaa !24
  %t319 = mul i64 %t318, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l181, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = load i64, ptr %l180, !tbaa !24
  %t328 = mul i64 %t327, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t324, ptr %t326, i64 %t328, i1 false)
  %t329 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t329, ptr %l23, !tbaa !27
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Try", ptr %t330, i32 0, i32 1
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  store { i64, ptr } %t333, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l26, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t339 = load i64, ptr %l25, !tbaa !24
  %t340 = load i64, ptr %l26, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t347 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t347, ptr %l190, !tbaa !27
  %t348 = load i64, ptr %l25, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t348
  %t353 = load ptr, ptr %t352, !tbaa !39
  store ptr %t353, ptr %l27, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t355)
  store { i64, ptr } %t357, ptr %l194
  br label %bb84
bb84:
  %t358 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l195, !tbaa !24
  %t360 = load i64, ptr %l195, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l196, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l195, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t371, ptr %l28, !tbaa !27
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t372, { i64, ptr } %t373)
  br label %bb85
bb85:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l27, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Clause", ptr %t377, i32 0, i32 3
  %t380 = load ptr, ptr %t379, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t376, ptr %t380)
  br label %bb86
bb86:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l27, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Clause", ptr %t384, i32 0, i32 4
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t383, { i64, ptr } %t387)
  br label %bb87
bb87:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t390, { i64, ptr } %t391)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t394 = load i64, ptr %l25, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l25, !tbaa !24
  br label %bb80
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l20 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:holdWalk", ptr %t5, i32 0, i32 8
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7, i32 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr ptr, ptr %t35, i64 %t32
  %t37 = load ptr, ptr %t36, !tbaa !39
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t39, ptr %t37)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:holdWalk", ptr %t47, i32 0, i32 8
  %t51 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l30
  br label %bb12
bb12:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l27, !tbaa !23
  br label %bb20
bb13:
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = icmp eq i32 %t57, 65536
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ee90b64eb208d194_3ee30fc86ac20510)
  unreachable
bb15:
  %t60 = load i32, ptr %l31, !tbaa !23
  %t61 = icmp eq i32 %t60, 65537
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_adeeaf8d66de5e9_765e2536cff45a05)
  unreachable
bb17:
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = icmp eq i32 %t63, 65538
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_735ea97a101db8a9_ef46e9a3f6738c65)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_720a79c775c6eb2f_4e77fac288b2d7ab)
  unreachable
bb20:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l19, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t18
  %t23 = load i64, ptr %t22, !tbaa !34
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %l2, i64 %t25)
  store i1 %t28, ptr %l24
  br label %bb6
bb6:
  %t29 = load i1, ptr %l24, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %l2, i64 %t32)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l7, !tbaa !24
  store i64 %t39, ptr %l30, !tbaa !24
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %l2)
  store i64 %t41, ptr %l32
  br label %bb14
bb14:
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l32, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb15, label %bb16
bb15:
  br label %bb35
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t50 = getelementptr %"compiler/typed:holdWalk", ptr %a0, i32 0, i32 2
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %l2, i64 %t51)
  store i64 %t54, ptr %l39
  br label %bb18
bb18:
  %t55 = load ptr, ptr %l36, !tbaa !29
  %t56 = load i64, ptr %l39, !tbaa !24
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s7, ptr %t55, i64 %t56)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l40
  br label %bb19
bb19:
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s7, ptr %l40)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l42
  br label %bb20
bb20:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  store ptr %t61, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  %t63 = load i64, ptr %l9, !tbaa !24
  store i64 %t63, ptr %l44, !tbaa !24
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s7, ptr %t64)
  store i64 %t66, ptr %l46
  br label %bb22
bb22:
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = load i64, ptr %l46, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb23, label %bb24
bb23:
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t73 = load ptr, ptr %l8, !tbaa !29
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s7, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l51
  br label %bb26
bb26:
  %t78 = load i64, ptr %l51, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %l2, i64 %t79)
  store i1 %t82, ptr %l54
  br label %bb27
bb27:
  %t83 = load i1, ptr %l54, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t86 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %l2, i64 %t86)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb21
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb34:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb13
bb35:
  %t97 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Match", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t28, ptr %t26)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Match", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  store ptr %l2, ptr %l38, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t61, ptr %t59)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l41
  br label %bb13
bb13:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t67 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t67
  %t68 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t68, ptr %t67)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb15:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb9
bb16:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Match", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l2, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l50, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Match", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb19, label %bb20
bb18:
  br label %bb24
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7fb442b2027c5df4_8cb8a301a51c1668)
  unreachable
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Match", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t95, ptr %t94)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l56
  br label %bb22
bb22:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t99 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t99
  %t100 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t100, ptr %t99)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb24:
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefusals(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca %"compiler/typed:Local"
  %l44 = alloca ptr
  %l47 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l79 = alloca i64
  %l85 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l98 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheldBefore(ptr %v0, ptr %v2, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l25
  br label %bb7
bb7:
  %t26 = load i64, ptr %l25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:DropHolding", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t33, i64 %t34)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/typed:DropHolding", ptr %t37, i32 0, i32 4
  store ptr %t39, ptr %l32, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:holdWalk", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 7
  store ptr %t45, ptr %l35, !tbaa !29
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l35, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v2, ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t51, ptr %t52, i64 %t46)
  store %"compiler/typed:Local" %t54, ptr %l38
  br label %bb12
bb12:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l38, i32 0, i32 1
  %t56 = load %"compiler/source:Span", ptr %t55
  %t57 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t57, %"compiler/source:Span" %t56)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:DropHolding", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t61, i64 %t62)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:DropHolding", ptr %t65, i32 0, i32 6
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v2, ptr %v3, ptr %t68, i64 %t69)
  store i32 %t72, ptr %l47
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = load i32, ptr %l47, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t73, i32 %t74)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb1
bb18:
  store i64 0, ptr %l6, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:holdWalk", ptr %t79, i32 0, i32 13
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l52
  br label %bb19
bb19:
  %t84 = load i64, ptr %l52, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb25
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l59, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l59, !tbaa !24
  store i64 %t111, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  %t112 = load i64, ptr %l56, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb27, label %bb28
bb27:
  br label %bb41
bb28:
  br label %bb29
bb29:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempHolds(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l79
  br label %bb30
bb30:
  %t136 = load i64, ptr %l79, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp slt i64 %t137, 0
  br i1 %t139, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/typed:DropHolding", ptr %t141, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t143, i64 -1)
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:DropHolding", ptr %t145, i32 0, i32 4
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/typed:holdWalk", ptr %t148, i32 0, i32 13
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t150, i64 %t151)
  store %"compiler/source:Span" %t154, ptr %l89
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l85, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t155, %"compiler/source:Span" %t156)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:DropHolding", ptr %t157, i32 0, i32 5
  %t160 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t159, i64 %t160)
  br label %bb37
bb37:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/typed:DropHolding", ptr %t163, i32 0, i32 6
  store ptr %t165, ptr %l94, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:holdWalk", ptr %t166, i32 0, i32 16
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t168, i64 %t169)
  store i32 %t172, ptr %l98
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l94, !tbaa !29
  %t174 = load i32, ptr %l98, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t173, i32 %t174)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb26
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i64
  %l61 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca i1
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i1
  %l84 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:holdWalk", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:holdWalk", ptr %t58, i32 0, i32 10
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l42
  br label %bb12
bb12:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t68 = icmp eq i64 %t66, %t65
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:holdWalk", ptr %t70, i32 0, i32 11
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l49
  br label %bb15
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l49, !tbaa !24
  %t80 = icmp eq i64 %t78, %t77
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb8
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:holdWalk", ptr %t87, i32 0, i32 10
  %t90 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:holdWalk", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t95, i64 %t96)
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:holdWalk", ptr %t99, i32 0, i32 12
  store ptr %t101, ptr %l61, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l63
  br label %bb24
bb24:
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t105, i32 %t106)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/typed:holdWalk", ptr %t107, i32 0, i32 9
  %t110 = load i64, ptr %l1, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i1 %t113, ptr %l67
  br label %bb26
bb26:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/typed:holdWalk", ptr %t117, i32 0, i32 9
  %t120 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t119, i64 %t120)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/typed:holdWalk", ptr %t123, i32 0, i32 2
  %t126 = load i64, ptr %l1, !tbaa !24
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l75
  br label %bb31
bb31:
  %t131 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l75)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l77
  br label %bb32
bb32:
  %t132 = load i64, ptr %l1, !tbaa !24
  %t135 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l77, i64 %t132)
  store i1 %t135, ptr %l80
  br label %bb33
bb33:
  %t136 = load i1, ptr %l80, !tbaa !21
  br i1 %t136, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/typed:holdWalk", ptr %t137, i32 0, i32 2
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v0, ptr %t139, i64 %t140)
  store ptr %t143, ptr %l84
  br label %bb37
bb37:
  %t144 = load i64, ptr %l1, !tbaa !24
  %t145 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t145, i64 %t144)
  br label %bb38
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/typed:holdWalk", ptr %t147, i32 0, i32 3
  store i1 true, ptr %t149, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l66 = alloca i1
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v2, i64 %t18)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l8
  br label %bb55
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t37, ptr %t38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l27
  br label %bb13
bb13:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l8
  br label %bb55
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t59, ptr %t60)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l36
  br label %bb20
bb20:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l8
  br label %bb55
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t66 = load ptr, ptr %l37, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eelemStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t80, ptr %t81)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l45
  br label %bb27
bb27:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l8
  br label %bb55
bb28:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t87 = load ptr, ptr %l46, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l47, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Payload", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t101, ptr %t105)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l55
  br label %bb34
bb34:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l8
  br label %bb55
bb35:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l56, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 8}
  %t117 = icmp eq i64 %t115, 6
  store i1 %t117, ptr %l57, !tbaa !21
  br label %bb37
bb37:
  %t118 = load i1, ptr %l57, !tbaa !21
  br i1 %t118, label %bb38, label %bb39
bb38:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t125, ptr %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l64
  br label %bb41
bb41:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l8
  br label %bb55
bb42:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t132 = load ptr, ptr %l65, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb43, label %bb44
bb43:
  %t135 = load ptr, ptr %l65, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 7
  store i1 %t138, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t139 = load i1, ptr %l66, !tbaa !21
  br i1 %t139, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etarget(ptr %v0, ptr %v2, ptr %t140)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l70
  br label %bb48
bb48:
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l8
  br label %bb55
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t144 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %l71
  br label %bb53
bb53:
  %t145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l8
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_60996a1f08c29aeb_ed876111a60916df)
  unreachable
bb55:
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l12
  br label %bb2
bb2:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l17
  br label %bb6
bb6:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  store ptr %a2, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l7, !tbaa !24
  store i64 %t21, ptr %l19, !tbaa !24
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t22)
  store i64 %t24, ptr %l21
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l26
  br label %bb12
bb12:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:holdWalk", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v3, ptr %v4, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l31
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v3, ptr %v4, ptr %t46, i64 %t47)
  store i32 %t50, ptr %l34
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v4, ptr %t51)
  %t53 = ptrtoint ptr %t52 to i64
  %t55 = inttoptr i64 %t53 to ptr
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = load i32, ptr %l34, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %t55, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t59, ptr %l36
  br label %bb15
bb15:
  %t60 = load i1, ptr %l36, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eadd(ptr %v0, ptr %t61, i64 %t62, i64 %t63)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb7
bb21:
  br label %bb22
bb22:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb1
bb23:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etarget(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:holdWalk", ptr %t3, i32 0, i32 4
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp sgt i64 %t8, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:holdWalk", ptr %t11, i32 0, i32 4
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:holdWalk", ptr %t14, i32 0, i32 4
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = sub i64 %t19, 1
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %s2, ptr %t21, i64 %t20)
  store { i64, ptr } %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = mul i64 %t26, 8
  %t28 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = mul i64 %t35, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 8
  %t41 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb8, label %bb9
bb8:
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i64, ptr %t61, i64 %t58
  %t63 = load i64, ptr %t62, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l1, i64 %t63)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l3, !tbaa !24
  br label %bb7
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca i1
  %l141 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l163 = alloca i1
  %l164 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l199 = alloca i1
  %l200 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %l211 = alloca ptr
  %l217 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l227 = alloca i1
  %l231 = alloca i1
  %l235 = alloca i1
  %l238 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i1
  %l246 = alloca i1
  %l249 = alloca i1
  %l253 = alloca i1
  %l254 = alloca i1
  %l258 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l278 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb198
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l52
  br label %bb31
bb31:
  %t83 = load i1, ptr %l52, !tbaa !21
  store i1 %t83, ptr %l19, !tbaa !21
  br label %bb198
bb32:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t85 = load ptr, ptr %l53, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t107 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  store i1 %t107, ptr %l63
  br label %bb38
bb38:
  %t108 = load i1, ptr %l63, !tbaa !21
  store i1 %t108, ptr %l19, !tbaa !21
  br label %bb198
bb39:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb40, label %bb41
bb40:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 18}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t117 = load i1, ptr %l65, !tbaa !21
  br i1 %t117, label %bb42, label %bb43
bb42:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l4, !tbaa !23
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb59
bb44:
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t134 = icmp eq i32 %t130, %t131
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:leaveWalk", ptr %t136, i32 0, i32 2
  %t139 = load i1, ptr %t138, !tbaa !21
  br i1 %t139, label %bb47, label %bb48
bb46:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb50
bb47:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb49
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/typed:leaveWalk", ptr %t141, i32 0, i32 1
  %t144 = load i1, ptr %t143, !tbaa !21
  %t146 = xor i1 %t144, true
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l78, !tbaa !21
  store i1 %t148, ptr %l75, !tbaa !21
  br label %bb50
bb50:
  %t149 = load i1, ptr %l75, !tbaa !21
  br i1 %t149, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb54
bb52:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %t150, ptr %t154)
  store i1 %t157, ptr %l86
  br label %bb53
bb53:
  %t158 = load i1, ptr %l86, !tbaa !21
  store i1 %t158, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb58
bb56:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Call", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t167 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t160, { i64, ptr } %t164)
  store i1 %t167, ptr %l91
  br label %bb57
bb57:
  %t168 = load i1, ptr %l91, !tbaa !21
  store i1 %t168, ptr %l87, !tbaa !21
  br label %bb58
bb58:
  %t169 = load i1, ptr %l87, !tbaa !21
  store i1 %t169, ptr %l19, !tbaa !21
  br label %bb198
bb59:
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t171 = load ptr, ptr %l92, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb60, label %bb61
bb60:
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 7
  store i1 %t177, ptr %l93, !tbaa !21
  br label %bb61
bb61:
  %t178 = load i1, ptr %l93, !tbaa !21
  br i1 %t178, label %bb62, label %bb63
bb62:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l6, !tbaa !29
  br label %bb64
bb63:
  br label %bb70
bb64:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Make", ptr %t186, i32 0, i32 2
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t192 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t185, { i64, ptr } %t189)
  store i1 %t192, ptr %l101
  br label %bb65
bb65:
  %t193 = load i1, ptr %l101, !tbaa !21
  br i1 %t193, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb69
bb67:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l6, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Make", ptr %t195, i32 0, i32 3
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t201 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t194, ptr %t198)
  store i1 %t201, ptr %l106
  br label %bb68
bb68:
  %t202 = load i1, ptr %l106, !tbaa !21
  store i1 %t202, ptr %l102, !tbaa !21
  br label %bb69
bb69:
  %t203 = load i1, ptr %l102, !tbaa !21
  store i1 %t203, ptr %l19, !tbaa !21
  br label %bb198
bb70:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t205 = load ptr, ptr %l107, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb71, label %bb72
bb71:
  %t208 = load ptr, ptr %l107, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 18}
  %t211 = icmp eq i64 %t209, 8
  store i1 %t211, ptr %l108, !tbaa !21
  br label %bb72
bb72:
  %t212 = load i1, ptr %l108, !tbaa !21
  br i1 %t212, label %bb73, label %bb74
bb73:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t215, i32 0, i32 2
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l7, !tbaa !29
  br label %bb75
bb74:
  br label %bb81
bb75:
  store %olang.scope zeroinitializer, ptr %s7
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Collect", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t226 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t219, ptr %t223)
  store i1 %t226, ptr %l116
  br label %bb76
bb76:
  %t227 = load i1, ptr %l116, !tbaa !21
  br i1 %t227, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb80
bb78:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l7, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Collect", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t235 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %s7, ptr %t228, ptr %t232, ptr null)
  store i1 %t235, ptr %l121
  br label %bb79
bb79:
  %t236 = load i1, ptr %l121, !tbaa !21
  store i1 %t236, ptr %l117, !tbaa !21
  br label %bb80
bb80:
  %t237 = load i1, ptr %l117, !tbaa !21
  store i1 %t237, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb198
bb81:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t239 = load ptr, ptr %l122, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb82, label %bb83
bb82:
  %t242 = load ptr, ptr %l122, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 18}
  %t245 = icmp eq i64 %t243, 9
  store i1 %t245, ptr %l123, !tbaa !21
  br label %bb83
bb83:
  %t246 = load i1, ptr %l123, !tbaa !21
  br i1 %t246, label %bb84, label %bb85
bb84:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t249, i32 0, i32 4
  %t251 = load { i64, ptr }, ptr %t250
  store { i64, ptr } %t251, ptr %l8, !tbaa !27
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t257 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t253, { i64, ptr } %t254)
  store i1 %t257, ptr %l130
  br label %bb87
bb87:
  %t258 = load i1, ptr %l130, !tbaa !21
  store i1 %t258, ptr %l19, !tbaa !21
  br label %bb198
bb88:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb89, label %bb90
bb89:
  %t263 = load ptr, ptr %l131, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 10
  store i1 %t266, ptr %l132, !tbaa !21
  br label %bb90
bb90:
  %t267 = load i1, ptr %l132, !tbaa !21
  br i1 %t267, label %bb91, label %bb92
bb91:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l9, !tbaa !29
  br label %bb93
bb92:
  br label %bb103
bb93:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l9, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Slice", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t281 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  store i1 %t281, ptr %l140
  br label %bb94
bb94:
  %t282 = load i1, ptr %l140, !tbaa !21
  br i1 %t282, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb98
bb96:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l9, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Slice", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t291 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t283, ptr %t287)
  store i1 %t291, ptr %l146
  br label %bb97
bb97:
  %t292 = load i1, ptr %l146, !tbaa !21
  store i1 %t292, ptr %l141, !tbaa !21
  br label %bb98
bb98:
  %t293 = load i1, ptr %l141, !tbaa !21
  br i1 %t293, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb102
bb100:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l9, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Slice", ptr %t295, i32 0, i32 2
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t302 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  store i1 %t302, ptr %l152
  br label %bb101
bb101:
  %t303 = load i1, ptr %l152, !tbaa !21
  store i1 %t303, ptr %l147, !tbaa !21
  br label %bb102
bb102:
  %t304 = load i1, ptr %l147, !tbaa !21
  store i1 %t304, ptr %l19, !tbaa !21
  br label %bb198
bb103:
  %t305 = load ptr, ptr %l1, !tbaa !29
  store ptr %t305, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb104, label %bb105
bb104:
  %t309 = load ptr, ptr %l153, !tbaa !29
  %t310 = load i64, ptr %t309, !range !{i64 0, i64 18}
  %t312 = icmp eq i64 %t310, 11
  store i1 %t312, ptr %l154, !tbaa !21
  br label %bb105
bb105:
  %t313 = load i1, ptr %l154, !tbaa !21
  br i1 %t313, label %bb106, label %bb107
bb106:
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t316, i32 0, i32 2
  %t318 = load ptr, ptr %t317
  store ptr %t318, ptr %l10, !tbaa !29
  br label %bb108
bb107:
  br label %bb118
bb108:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Cond", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t328 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t320, ptr %t324)
  store i1 %t328, ptr %l163
  br label %bb109
bb109:
  %t329 = load i1, ptr %l163, !tbaa !21
  br i1 %t329, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb113
bb111:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l10, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Cond", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t337 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  store i1 %t337, ptr %l168
  br label %bb112
bb112:
  %t338 = load i1, ptr %l168, !tbaa !21
  store i1 %t338, ptr %l164, !tbaa !21
  br label %bb113
bb113:
  %t339 = load i1, ptr %l164, !tbaa !21
  br i1 %t339, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb117
bb115:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l10, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Cond", ptr %t341, i32 0, i32 2
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t348 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t340, ptr %t344)
  store i1 %t348, ptr %l174
  br label %bb116
bb116:
  %t349 = load i1, ptr %l174, !tbaa !21
  store i1 %t349, ptr %l169, !tbaa !21
  br label %bb117
bb117:
  %t350 = load i1, ptr %l169, !tbaa !21
  store i1 %t350, ptr %l19, !tbaa !21
  br label %bb198
bb118:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t352 = load ptr, ptr %l175, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb119, label %bb120
bb119:
  %t355 = load ptr, ptr %l175, !tbaa !29
  %t356 = load i64, ptr %t355, !range !{i64 0, i64 18}
  %t358 = icmp eq i64 %t356, 12
  store i1 %t358, ptr %l176, !tbaa !21
  br label %bb120
bb120:
  %t359 = load i1, ptr %l176, !tbaa !21
  br i1 %t359, label %bb121, label %bb122
bb121:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t362, i32 0, i32 2
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l11, !tbaa !29
  br label %bb123
bb122:
  br label %bb129
bb123:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l11, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Seq", ptr %t367, i32 0, i32 0
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  %t373 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t366, { i64, ptr } %t370)
  store i1 %t373, ptr %l184
  br label %bb124
bb124:
  %t374 = load i1, ptr %l184, !tbaa !21
  br i1 %t374, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb128
bb126:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l11, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Seq", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t382 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t375, ptr %t379)
  store i1 %t382, ptr %l189
  br label %bb127
bb127:
  %t383 = load i1, ptr %l189, !tbaa !21
  store i1 %t383, ptr %l185, !tbaa !21
  br label %bb128
bb128:
  %t384 = load i1, ptr %l185, !tbaa !21
  store i1 %t384, ptr %l19, !tbaa !21
  br label %bb198
bb129:
  %t385 = load ptr, ptr %l1, !tbaa !29
  store ptr %t385, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t386 = load ptr, ptr %l190, !tbaa !29
  %t387 = icmp ne ptr %t386, null
  br i1 %t387, label %bb130, label %bb131
bb130:
  %t389 = load ptr, ptr %l190, !tbaa !29
  %t390 = load i64, ptr %t389, !range !{i64 0, i64 18}
  %t392 = icmp eq i64 %t390, 13
  store i1 %t392, ptr %l191, !tbaa !21
  br label %bb131
bb131:
  %t393 = load i1, ptr %l191, !tbaa !21
  br i1 %t393, label %bb132, label %bb133
bb132:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t396, i32 0, i32 2
  %t398 = load ptr, ptr %t397
  store ptr %t398, ptr %l12, !tbaa !29
  br label %bb134
bb133:
  br label %bb150
bb134:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l12, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Match", ptr %t401, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  %t407 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t400, { i64, ptr } %t404)
  store i1 %t407, ptr %l199
  br label %bb135
bb135:
  %t408 = load i1, ptr %l199, !tbaa !21
  br i1 %t408, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb139
bb137:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load ptr, ptr %l12, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Match", ptr %t410, i32 0, i32 1
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  %t416 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %t409, { i64, ptr } %t413)
  store i1 %t416, ptr %l204
  br label %bb138
bb138:
  %t417 = load i1, ptr %l204, !tbaa !21
  store i1 %t417, ptr %l200, !tbaa !21
  br label %bb139
bb139:
  %t418 = load i1, ptr %l200, !tbaa !21
  br i1 %t418, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb149
bb141:
  %t419 = load ptr, ptr %l12, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Match", ptr %t419, i32 0, i32 2
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = icmp eq ptr %t422, null
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb142, label %bb143
bb142:
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l211, !tbaa !29
  %t429 = load ptr, ptr %l12, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Match", ptr %t429, i32 0, i32 2
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = icmp eq ptr %t432, null
  br i1 %t434, label %bb144, label %bb145
bb143:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb148
bb144:
  call void @__olang_check_failed(ptr @olang_loc_b80660129801afa0_e660219d512f014)
  unreachable
bb145:
  br label %bb146
bb146:
  %t436 = load ptr, ptr %l12, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Match", ptr %t436, i32 0, i32 2
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t440 = load ptr, ptr %l211, !tbaa !29
  %t442 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %t440, ptr %t439)
  store i1 %t442, ptr %l217
  br label %bb147
bb147:
  %t443 = load i1, ptr %l217, !tbaa !21
  store i1 %t443, ptr %l210, !tbaa !21
  br label %bb148
bb148:
  %t444 = load i1, ptr %l210, !tbaa !21
  store i1 %t444, ptr %l205, !tbaa !21
  br label %bb149
bb149:
  %t445 = load i1, ptr %l205, !tbaa !21
  store i1 %t445, ptr %l19, !tbaa !21
  br label %bb198
bb150:
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t447 = load ptr, ptr %l218, !tbaa !29
  %t448 = icmp ne ptr %t447, null
  br i1 %t448, label %bb151, label %bb152
bb151:
  %t450 = load ptr, ptr %l218, !tbaa !29
  %t451 = load i64, ptr %t450, !range !{i64 0, i64 18}
  %t453 = icmp eq i64 %t451, 14
  store i1 %t453, ptr %l219, !tbaa !21
  br label %bb152
bb152:
  %t454 = load i1, ptr %l219, !tbaa !21
  br i1 %t454, label %bb153, label %bb154
bb153:
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t457, i32 0, i32 2
  %t459 = load ptr, ptr %t458
  store ptr %t459, ptr %l13, !tbaa !29
  br label %bb155
bb154:
  br label %bb183
bb155:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/typed:leaveWalk", ptr %t461, i32 0, i32 1
  %t464 = load i1, ptr %t463, !tbaa !21
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb156, label %bb157
bb156:
  %t468 = load ptr, ptr %l13, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Try", ptr %t468, i32 0, i32 2
  %t471 = load i1, ptr %t470, !tbaa !21
  %t473 = xor i1 %t471, true
  store i1 %t473, ptr %l227, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb158
bb158:
  %t475 = load i1, ptr %l227, !tbaa !21
  br i1 %t475, label %bb159, label %bb160
bb159:
  %t476 = load ptr, ptr %l13, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Try", ptr %t476, i32 0, i32 3
  %t479 = load i1, ptr %t478, !tbaa !21
  %t481 = xor i1 %t479, true
  store i1 %t481, ptr %l231, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb161
bb161:
  %t483 = load i1, ptr %l231, !tbaa !21
  br i1 %t483, label %bb162, label %bb163
bb162:
  %t484 = load ptr, ptr %l13, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Try", ptr %t484, i32 0, i32 4
  %t487 = load i1, ptr %t486, !tbaa !21
  store i1 %t487, ptr %l235, !tbaa !21
  br label %bb164
bb163:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb164
bb164:
  %t489 = load i1, ptr %l235, !tbaa !21
  br i1 %t489, label %bb165, label %bb166
bb165:
  %t490 = load ptr, ptr %l13, !tbaa !29
  %t492 = getelementptr %"compiler/typed:Try", ptr %t490, i32 0, i32 1
  %t493 = load { i64, ptr }, ptr %t492, !tbaa !27
  %t495 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t493)
  store i1 %t495, ptr %l241
  br label %bb167
bb166:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb168
bb167:
  %t496 = load i1, ptr %l241, !tbaa !21
  %t497 = xor i1 %t496, true
  store i1 %t497, ptr %l238, !tbaa !21
  br label %bb168
bb168:
  %t499 = load i1, ptr %l238, !tbaa !21
  br i1 %t499, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l243, !tbaa !21
  br label %bb174
bb170:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/typed:leaveWalk", ptr %t500, i32 0, i32 2
  %t503 = load i1, ptr %t502, !tbaa !21
  br i1 %t503, label %bb171, label %bb172
bb171:
  %t505 = load ptr, ptr %l13, !tbaa !29
  %t507 = getelementptr %"compiler/typed:Try", ptr %t505, i32 0, i32 2
  %t508 = load i1, ptr %t507, !tbaa !21
  store i1 %t508, ptr %l246, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb173
bb173:
  %t510 = load i1, ptr %l246, !tbaa !21
  store i1 %t510, ptr %l243, !tbaa !21
  br label %bb174
bb174:
  %t511 = load i1, ptr %l243, !tbaa !21
  br i1 %t511, label %bb175, label %bb176
bb175:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb178
bb176:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load ptr, ptr %l13, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Try", ptr %t513, i32 0, i32 0
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t519 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t512, ptr %t516)
  store i1 %t519, ptr %l253
  br label %bb177
bb177:
  %t520 = load i1, ptr %l253, !tbaa !21
  store i1 %t520, ptr %l249, !tbaa !21
  br label %bb178
bb178:
  %t521 = load i1, ptr %l249, !tbaa !21
  br i1 %t521, label %bb179, label %bb180
bb179:
  store i1 true, ptr %l254, !tbaa !21
  br label %bb182
bb180:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l13, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Try", ptr %t523, i32 0, i32 1
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  %t529 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t522, { i64, ptr } %t526)
  store i1 %t529, ptr %l258
  br label %bb181
bb181:
  %t530 = load i1, ptr %l258, !tbaa !21
  store i1 %t530, ptr %l254, !tbaa !21
  br label %bb182
bb182:
  %t531 = load i1, ptr %l254, !tbaa !21
  store i1 %t531, ptr %l19, !tbaa !21
  br label %bb198
bb183:
  %t532 = load ptr, ptr %l1, !tbaa !29
  store ptr %t532, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t533 = load ptr, ptr %l259, !tbaa !29
  %t534 = icmp ne ptr %t533, null
  br i1 %t534, label %bb184, label %bb185
bb184:
  %t536 = load ptr, ptr %l259, !tbaa !29
  %t537 = load i64, ptr %t536, !range !{i64 0, i64 18}
  %t539 = icmp eq i64 %t537, 16
  store i1 %t539, ptr %l260, !tbaa !21
  br label %bb185
bb185:
  %t540 = load i1, ptr %l260, !tbaa !21
  br i1 %t540, label %bb186, label %bb187
bb186:
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t543 = getelementptr { i64, [5 x i64] }, ptr %t541, i32 0, i32 1
  %t544 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t543, i32 0, i32 2
  %t545 = load ptr, ptr %t544
  store ptr %t545, ptr %l14, !tbaa !29
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l14, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Text", ptr %t548, i32 0, i32 0
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  %t554 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %t547, { i64, ptr } %t551)
  store i1 %t554, ptr %l268
  br label %bb189
bb189:
  %t555 = load i1, ptr %l268, !tbaa !21
  store i1 %t555, ptr %l19, !tbaa !21
  br label %bb198
bb190:
  %t556 = load ptr, ptr %l1, !tbaa !29
  store ptr %t556, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t557 = load ptr, ptr %l269, !tbaa !29
  %t558 = icmp ne ptr %t557, null
  br i1 %t558, label %bb191, label %bb192
bb191:
  %t560 = load ptr, ptr %l269, !tbaa !29
  %t561 = load i64, ptr %t560, !range !{i64 0, i64 18}
  %t563 = icmp eq i64 %t561, 17
  store i1 %t563, ptr %l270, !tbaa !21
  br label %bb192
bb192:
  %t564 = load i1, ptr %l270, !tbaa !21
  br i1 %t564, label %bb193, label %bb194
bb193:
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t567, i32 0, i32 2
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l15, !tbaa !29
  br label %bb195
bb194:
  br label %bb197
bb195:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l15, !tbaa !29
  %t576 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t571, ptr %t572)
  store i1 %t576, ptr %l278
  br label %bb196
bb196:
  %t577 = load i1, ptr %l278, !tbaa !21
  store i1 %t577, ptr %l19, !tbaa !21
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba)
  unreachable
bb198:
  %t578 = load i1, ptr %l19, !tbaa !21
  store i1 %t578, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Elem", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t86, ptr %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Elem", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Payload", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t128 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t121, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t150 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_1807395182923f6f_ecff5ea7ed15d953)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = sub i64 %t2, 1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t12 = sext i32 %t8 to i64
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s0, ptr %t1, i64 %t4, { i64, ptr } %t26)
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t55, ptr %t53, i64 %t57)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:wordReader", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:wordReader", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sge i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:wordReader", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l10, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:wordReader", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t31 = icmp ne i8 %t27, %a1
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t33 = load i1, ptr %l8, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/typed:wordReader", ptr %t36, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = add i64 %t38, 1
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t43 = getelementptr %"compiler/typed:wordReader", ptr %t42, i32 0, i32 2
  store i64 %t40, ptr %t43, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2espan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %t1)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t17, 0
  store { i32, %"compiler/source:Span" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %t21, i8 44)
  store i32 %t23, ptr %l9
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t34, 0
  store { i32, %"compiler/source:Span" } %t36, ptr %rv
  br label %ret
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %t37)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l14
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb8, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l13
  br label %bb7
bb7:
  %t44 = load i64, ptr %l13, !tbaa !24
  store i64 %t44, ptr %l11, !tbaa !24
  br label %bb9
bb8:
  %t45 = load i32, ptr %l14, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t53, 0
  store { i32, %"compiler/source:Span" } %t55, ptr %rv
  br label %ret
bb9:
  %t56 = load i64, ptr %l11, !tbaa !24
  store i64 %t56, ptr %l2, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %t57, i8 44)
  store i32 %t59, ptr %l17
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb11, label %ok.61, !prof !99
ok.61:
  br label %bb10
bb10:
  br label %bb12
bb11:
  %t62 = load i32, ptr %l17, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t62, 0
  %t68 = shl i32 %t66, 16
  %t69 = or i32 %t68, %t64
  %t70 = select i1 %t67, i32 0, i32 %t69
  call void @__olang_scope_close(ptr %s0)
  %t72 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t70, 0
  store { i32, %"compiler/source:Span" } %t72, ptr %rv
  br label %ret
bb12:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = trunc i64 %t76 to i32
  %t81 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t75, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l23
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load %"compiler/source:Span", ptr %l23
  %t83 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t82, 1
  store { i32, %"compiler/source:Span" } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local ptr @compiler_2ftyped_2econverted(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 51}
  store i32 %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 51}
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l20, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 0
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l19, !tbaa !29
  br label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l19, !tbaa !29
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb24
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 17
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = call ptr @compiler_2ftyped_2econverted(ptr %v0, ptr %v1, ptr %t58)
  store ptr %t60, ptr %l30
  br label %bb18
bb18:
  %t61 = load ptr, ptr %l30, !tbaa !29
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_722457a86dc26837_d472b9738ae39dfb)
  unreachable
bb24:
  %t64 = load ptr, ptr %l4, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 5}
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Make", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store ptr %a0, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 0
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load i32, ptr %l26, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t52, i32 %t53, i32 %t51)
  store i1 %t55, ptr %l28
  br label %bb12
bb12:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t57 = load i1, ptr %l21, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Make", ptr %t58, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l31, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l29, !tbaa !29
  br label %bb16
bb15:
  store ptr null, ptr %l29, !tbaa !29
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l29, !tbaa !29
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb32
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t70 = load ptr, ptr %l34, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l34, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 2
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 10
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8a62bacdff20949b_383b5959755ced57)
  unreachable
bb32:
  %t90 = load ptr, ptr %l4, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l66 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Block", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb62
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l6, !tbaa !29
  store ptr %t26, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t27 = load ptr, ptr %l25, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 17}
  %t33 = icmp eq i64 %t31, 12
  store i1 %t33, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t45 = call i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  store i64 %t45, ptr %l33
  br label %bb10
bb10:
  %t46 = load i64, ptr %l33, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/typed:DropHolding", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t53, i64 %t54)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/typed:DropHolding", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Block", ptr %t60, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t59, i32 %t63)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb60
bb16:
  %t66 = load ptr, ptr %l6, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t67 = load ptr, ptr %l43, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 17}
  %t73 = icmp eq i64 %t71, 11
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l44, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l9, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t81, ptr %t82, ptr %t83)
  br label %bb22
bb22:
  br label %bb60
bb23:
  %t87 = load ptr, ptr %l6, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t88 = load ptr, ptr %l52, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l52, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l53, !tbaa !21
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l10, !tbaa !29
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l10, !tbaa !29
  %t105 = getelementptr %"compiler/typed:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t102, ptr %t106, ptr %t107)
  br label %bb29
bb29:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = getelementptr %"compiler/typed:If", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb30, label %bb31
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/typed:If", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4baf654831ed8d80_eee61e02aec284c4)
  unreachable
bb33:
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/typed:If", ptr %t128, i32 0, i32 2
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t133 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t133, ptr %t131, ptr %t132)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb60
bb37:
  %t136 = load ptr, ptr %l6, !tbaa !29
  store ptr %t136, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l73, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 17}
  %t143 = icmp eq i64 %t141, 4
  store i1 %t143, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l74, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l11, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr { i64, [3 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l12, !tbaa !29
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l11, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t158, ptr %t159)
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb44, label %bb45
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l12, !tbaa !29
  %t171 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t169, ptr %t170, ptr %t171)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb60
bb48:
  %t175 = load ptr, ptr %l6, !tbaa !29
  store ptr %t175, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t176 = load ptr, ptr %l90, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb49, label %bb50
bb49:
  %t179 = load ptr, ptr %l90, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 17}
  %t182 = icmp eq i64 %t180, 13
  store i1 %t182, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb51, label %bb52
bb51:
  %t184 = load ptr, ptr %l6, !tbaa !29
  %t186 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", ptr }, ptr %t186, i32 0, i32 1
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l13, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l13, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Join", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t190, ptr %t194, ptr %t195)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f3eab8194bd11e66_e0240e140d7ed92a)
  unreachable
bb60:
  br label %bb61
bb61:
  %t199 = load i64, ptr %l4, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l4, !tbaa !24
  br label %bb1
bb62:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2efnBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l26 = alloca { i64, ptr }
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 3}
  %t18 = icmp eq i64 %t16, 1
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t40, ptr %l26, !tbaa !27
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t50 = getelementptr %"compiler/typed:Capture", ptr %t46, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t51, i32 %t53)
  store i1 %t56, ptr %l33
  br label %bb16
bb16:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb12
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 3}
  %t71 = icmp eq i64 %t69, 2
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb25, label %bb26
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { i32, ptr, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l47
  br label %bb28
bb28:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l22
  br label %bb8
bb8:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = call ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v0, ptr %t37)
  store ptr %t39, ptr %l25
  br label %bb11
bb11:
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t43 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t41, %"compiler/source:Span" %t40)
  store i1 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb4
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t3)
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t4, 1
  %t15 = extractvalue { i64, ptr } %t4, 0
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t3)
  %t20 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t10, i64 %t11)
  %t21 = getelementptr i8, ptr %t20, i64 %t11
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t17, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb23
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_336e4a7a18e16ea4_5caa821eea897180)
  unreachable
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l28
  br label %bb21
bb21:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l22, !tbaa !21
  store i1 %t57, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l29, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l30, !tbaa !21
  br label %bb25
bb25:
  %t66 = load i1, ptr %l30, !tbaa !21
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = call i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l36
  br label %bb29
bb29:
  %t76 = load i1, ptr %l36, !tbaa !21
  store i1 %t76, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_43ee4571abcd420a_a05ceada06352a66)
  unreachable
bb35:
  %t77 = load i1, ptr %l3, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2epiecesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t45, i32 %a1)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/typed:leaveWalk"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca i64
  %l40 = alloca i64
  %l41 = alloca %"compiler/typed:leaveWalk"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i64 1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = call ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v0, ptr %t38)
  store ptr %t40, ptr %l27
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l27, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t48, %"compiler/source:Span" %t50)
  store i64 %t53, ptr %l35
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = icmp ne i64 %t54, 0
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t63 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t58, %"compiler/source:Span" %t60)
  store i64 %t63, ptr %l40
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  %t64 = load i64, ptr %l40, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = call %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %s3)
  store %"compiler/typed:leaveWalk" %t65, ptr %l41
  br label %bb21
bb21:
  %t66 = load %"compiler/typed:leaveWalk", ptr %l41
  store %"compiler/typed:leaveWalk" %t66, ptr %l7
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %s3, ptr %v0, ptr %l7, ptr %t67)
  store i1 %t70, ptr %l44
  br label %bb22
bb22:
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t72, %"compiler/source:Span" %t74)
  store i1 %t77, ptr %l48
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t78 = load i1, ptr %l48, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb4
bb31:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftyped_2ereadBits(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l10 = alloca i1
  %l12 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = add i64 %t12, 1
  %t17 = icmp ne i64 %t9, %t14
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb13
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l28, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb13
bb13:
  %t52 = load i64, ptr %l25, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb15, label %bb16
bb15:
  br label %bb25
bb16:
  br label %bb17
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l7, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l46, !tbaa !27
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l8, !tbaa !22
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp ne i8 %t81, 48
  br i1 %t83, label %bb18, label %bb19
bb18:
  %t85 = load i8, ptr %l8, !tbaa !22
  %t87 = icmp ne i8 %t85, 49
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l56, !tbaa !27
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load i8, ptr %l8, !tbaa !22
  %t95 = icmp eq i8 %t93, 49
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i1, ptr %t99, i64 %t92
  store i1 %t95, ptr %t100, !tbaa !31
  br label %bb24
bb24:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb14
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t16 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t18 = trunc i64 3 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t21 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t26 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t28 = trunc i64 5 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t33 = trunc i64 6 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t36 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t38 = trunc i64 7 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb37
bb18:
  %t46 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t48 = trunc i64 9 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb19, label %bb20
bb19:
  br label %bb31
bb20:
  %t51 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t53 = trunc i64 10 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t56 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t58 = trunc i64 11 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t61 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t63 = trunc i64 12 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t68 = trunc i64 13 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t73 = trunc i64 14 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4231ae67b136756b_a4f71f39f0a47447)
  unreachable
bb37:
  %t76 = load i1, ptr %l8, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2esharedBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l69 = alloca i32
  %l72 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i64, ptr %l14, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l18, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb31
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l42
  br label %bb12
bb12:
  %t58 = load i64, ptr %l42, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb18
bb15:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l49, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l49, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l46, !tbaa !24
  store i64 %t86, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb20, label %bb21
bb20:
  br label %bb29
bb21:
  br label %bb22
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t105, i64 %t106)
  store i32 %t109, ptr %l69
  br label %bb23
bb23:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l72
  br label %bb24
bb24:
  %t115 = load i32, ptr %l69, !tbaa !23
  %t116 = load i32, ptr %l72, !tbaa !23
  %t117 = icmp eq i32 %t115, %t116
  br i1 %t117, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l11, !tbaa !24
  br label %bb19
bb29:
  br label %bb30
bb30:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb8
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i1
  %l102 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l133 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 4
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t55 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  store i1 %t55, ptr %l35
  br label %bb17
bb17:
  %t56 = load i1, ptr %l35, !tbaa !21
  store i1 %t56, ptr %l14, !tbaa !21
  br label %bb91
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t58 = load ptr, ptr %l36, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 5
  store i1 %t64, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l37, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Promote", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t80 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t75, %"compiler/source:Span" %t77)
  store i1 %t80, ptr %l46
  br label %bb24
bb24:
  %t81 = load i1, ptr %l46, !tbaa !21
  store i1 %t81, ptr %l14, !tbaa !21
  br label %bb91
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb26, label %bb27
bb26:
  %t86 = load ptr, ptr %l47, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 18}
  %t89 = icmp eq i64 %t87, 6
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Call", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load %"compiler/source:Span", ptr %l1
  %t104 = call i1 @compiler_2ftyped_2eturnExprs(ptr %v0, { i64, ptr } %t100, %"compiler/source:Span" %t101)
  store i1 %t104, ptr %l56
  br label %bb31
bb31:
  %t105 = load i1, ptr %l56, !tbaa !21
  store i1 %t105, ptr %l14, !tbaa !21
  br label %bb91
bb32:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l57, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 7
  store i1 %t113, ptr %l58, !tbaa !21
  br label %bb34
bb34:
  %t114 = load i1, ptr %l58, !tbaa !21
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Make", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t125 = load %"compiler/source:Span", ptr %l1
  %t128 = call i1 @compiler_2ftyped_2eturnExprs(ptr %v0, { i64, ptr } %t124, %"compiler/source:Span" %t125)
  store i1 %t128, ptr %l66
  br label %bb38
bb38:
  %t129 = load i1, ptr %l66, !tbaa !21
  br i1 %t129, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb42
bb40:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Make", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l1
  %t137 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t133, %"compiler/source:Span" %t134)
  store i1 %t137, ptr %l71
  br label %bb41
bb41:
  %t138 = load i1, ptr %l71, !tbaa !21
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb42
bb42:
  %t139 = load i1, ptr %l67, !tbaa !21
  store i1 %t139, ptr %l14, !tbaa !21
  br label %bb91
bb43:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t141 = load ptr, ptr %l72, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb44, label %bb45
bb44:
  %t144 = load ptr, ptr %l72, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l73, !tbaa !21
  br label %bb45
bb45:
  %t148 = load i1, ptr %l73, !tbaa !21
  br i1 %t148, label %bb46, label %bb47
bb46:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l6, !tbaa !27
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call i1 @compiler_2ftyped_2eturnExprs(ptr %v0, { i64, ptr } %t155, %"compiler/source:Span" %t156)
  store i1 %t159, ptr %l80
  br label %bb49
bb49:
  %t160 = load i1, ptr %l80, !tbaa !21
  store i1 %t160, ptr %l14, !tbaa !21
  br label %bb91
bb50:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t162 = load ptr, ptr %l81, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l81, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 18}
  %t168 = icmp eq i64 %t166, 10
  store i1 %t168, ptr %l82, !tbaa !21
  br label %bb52
bb52:
  %t169 = load i1, ptr %l82, !tbaa !21
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l7, !tbaa !29
  br label %bb55
bb54:
  br label %bb65
bb55:
  %t176 = load ptr, ptr %l7, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Slice", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  %t183 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t179, %"compiler/source:Span" %t180)
  store i1 %t183, ptr %l90
  br label %bb56
bb56:
  %t184 = load i1, ptr %l90, !tbaa !21
  br i1 %t184, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb60
bb58:
  %t185 = load ptr, ptr %l7, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Slice", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t193 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t188, %"compiler/source:Span" %t190)
  store i1 %t193, ptr %l96
  br label %bb59
bb59:
  %t194 = load i1, ptr %l96, !tbaa !21
  store i1 %t194, ptr %l91, !tbaa !21
  br label %bb60
bb60:
  %t195 = load i1, ptr %l91, !tbaa !21
  br i1 %t195, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb64
bb62:
  %t196 = load ptr, ptr %l7, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Slice", ptr %t196, i32 0, i32 2
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t204 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t199, %"compiler/source:Span" %t201)
  store i1 %t204, ptr %l102
  br label %bb63
bb63:
  %t205 = load i1, ptr %l102, !tbaa !21
  store i1 %t205, ptr %l97, !tbaa !21
  br label %bb64
bb64:
  %t206 = load i1, ptr %l97, !tbaa !21
  store i1 %t206, ptr %l14, !tbaa !21
  br label %bb91
bb65:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t208 = load ptr, ptr %l103, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb66, label %bb67
bb66:
  %t211 = load ptr, ptr %l103, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 18}
  %t214 = icmp eq i64 %t212, 11
  store i1 %t214, ptr %l104, !tbaa !21
  br label %bb67
bb67:
  %t215 = load i1, ptr %l104, !tbaa !21
  br i1 %t215, label %bb68, label %bb69
bb68:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t218, i32 0, i32 2
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l8, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Cond", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t230 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t225, %"compiler/source:Span" %t227)
  store i1 %t230, ptr %l113
  br label %bb71
bb71:
  %t231 = load i1, ptr %l113, !tbaa !21
  store i1 %t231, ptr %l14, !tbaa !21
  br label %bb91
bb72:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t233 = load ptr, ptr %l114, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb73, label %bb74
bb73:
  %t236 = load ptr, ptr %l114, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 17
  store i1 %t239, ptr %l115, !tbaa !21
  br label %bb74
bb74:
  %t240 = load i1, ptr %l115, !tbaa !21
  br i1 %t240, label %bb75, label %bb76
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t243, i32 0, i32 2
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l9, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t247 = load ptr, ptr %l9, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l1
  %t252 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t247, %"compiler/source:Span" %t249)
  store i1 %t252, ptr %l123
  br label %bb78
bb78:
  %t253 = load i1, ptr %l123, !tbaa !21
  store i1 %t253, ptr %l14, !tbaa !21
  br label %bb91
bb79:
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t255 = load ptr, ptr %l124, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb80, label %bb81
bb80:
  %t258 = load ptr, ptr %l124, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 18}
  %t261 = icmp eq i64 %t259, 14
  store i1 %t261, ptr %l125, !tbaa !21
  br label %bb81
bb81:
  %t262 = load i1, ptr %l125, !tbaa !21
  br i1 %t262, label %bb82, label %bb83
bb82:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t265, i32 0, i32 2
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l10, !tbaa !29
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t269 = load ptr, ptr %l10, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Try", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  %t276 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t272, %"compiler/source:Span" %t273)
  store i1 %t276, ptr %l133
  br label %bb85
bb85:
  %t277 = load i1, ptr %l133, !tbaa !21
  store i1 %t277, ptr %l14, !tbaa !21
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_951602b5c1ab1d3_8d3a831a41b7ff67)
  unreachable
bb91:
  %t278 = load i1, ptr %l14, !tbaa !21
  store i1 %t278, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l73 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t28 = icmp eq i32 %t23, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = icmp eq i32 %t31, %t33
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Elem", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t42, %"compiler/source:Span" %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb16
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t52, %"compiler/source:Span" %t54)
  store i1 %t57, ptr %l34
  br label %bb15
bb15:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l29, !tbaa !21
  store i1 %t59, ptr %l8, !tbaa !21
  br label %bb50
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t61 = load ptr, ptr %l35, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 2
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l36, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t80 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t75, %"compiler/source:Span" %t77)
  store i1 %t80, ptr %l44
  br label %bb23
bb23:
  %t81 = load i1, ptr %l44, !tbaa !21
  store i1 %t81, ptr %l8, !tbaa !21
  br label %bb50
bb24:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t83 = load ptr, ptr %l45, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 8}
  %t89 = icmp eq i64 %t87, 3
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t90 = load i1, ptr %l46, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t101 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t97, %"compiler/source:Span" %t98)
  store i1 %t101, ptr %l53
  br label %bb30
bb30:
  %t102 = load i1, ptr %l53, !tbaa !21
  store i1 %t102, ptr %l8, !tbaa !21
  br label %bb50
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t104 = load ptr, ptr %l54, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 8}
  %t110 = icmp eq i64 %t108, 5
  store i1 %t110, ptr %l55, !tbaa !21
  br label %bb33
bb33:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Payload", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t125 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t121, %"compiler/source:Span" %t122)
  store i1 %t125, ptr %l63
  br label %bb37
bb37:
  %t126 = load i1, ptr %l63, !tbaa !21
  store i1 %t126, ptr %l8, !tbaa !21
  br label %bb50
bb38:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb39, label %bb40
bb39:
  %t131 = load ptr, ptr %l64, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 8}
  %t134 = icmp eq i64 %t132, 6
  store i1 %t134, ptr %l65, !tbaa !21
  br label %bb40
bb40:
  %t135 = load i1, ptr %l65, !tbaa !21
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t147 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t142, %"compiler/source:Span" %t144)
  store i1 %t147, ptr %l73
  br label %bb44
bb44:
  %t148 = load i1, ptr %l73, !tbaa !21
  store i1 %t148, ptr %l8, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_76d2aa8969b3545b_e178bc39d62c767f)
  unreachable
bb50:
  %t149 = load i1, ptr %l8, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v0, ptr %v1, i32 %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { ptr, ptr } %pg1, 0
  %t5 = extractvalue { ptr, ptr } %pg1, 1
  %t7 = call { i64, ptr } %t4(ptr %t5, ptr %s0, i32 %a0)
  store { i64, ptr } %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb8:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t21)
  store i1 %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load i1, ptr %l15, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t29)
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t30, 1
  %t38 = extractvalue { i64, ptr } %t30, 0
  %t39 = add i64 %t35, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  %t41 = call i64 @__olang_fmt_i64(ptr %t40, i64 %t29)
  %t42 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  call void @__olang_scope_close(ptr %s0)
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t45, 1
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:BlockInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %a2, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Block"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Block" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Block" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Block" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Block", ptr %rv
  ret %"compiler/typed:Block" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6) #0 {
entry:
  %rv = alloca %"compiler/typed:Clause"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %a0, 0
  %t18 = insertvalue %"compiler/typed:Clause" %t16, { i64, ptr } %a1, 1
  %t20 = insertvalue %"compiler/typed:Clause" %t18, i1 %a2, 2
  %t22 = insertvalue %"compiler/typed:Clause" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/typed:Clause" %t22, { i64, ptr } %a4, 4
  %t26 = insertvalue %"compiler/typed:Clause" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/typed:Clause" %t26, i32 %a6, 6
  store %"compiler/typed:Clause" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %a3, 3
  store %"compiler/typed:Match" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local %"compiler/typed:Nodes" @compiler_2ftyped_3aNodes_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:Nodes"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  %t6 = insertvalue %"compiler/typed:Nodes" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, 0
  %t8 = insertvalue %"compiler/typed:Nodes" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 1
  store %"compiler/typed:Nodes" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Nodes", ptr %rv
  ret %"compiler/typed:Nodes" %rr
}

define dso_local %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Try"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Try" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Try" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Try" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/typed:Try" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/typed:Try" %t18, i1 %a4, 4
  store %"compiler/typed:Try" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Try", ptr %rv
  ret %"compiler/typed:Try" %rr
}

define dso_local void @compiler_2ftyped_3aVersions_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l52 = alloca i64
  %l54 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i64
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i64
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca %"compiler/typed:Versions"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t5 = ptrtoint ptr %v2 to i64
  store i64 %t5, ptr %l25, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e2
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call ptr @__olang_region_make(ptr %v2)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l25, !tbaa !24
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l28, !tbaa !24
  %t13 = load i64, ptr %l28, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l28, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = load i64, ptr %l25
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %t19, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  %t24 = ptrtoint ptr %v2 to i64
  store i64 %t24, ptr %l31, !tbaa !24
  %t25 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e3
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a650b38034a5180c_4858ad52e7b771b8)
  unreachable
bb5:
  %t27 = call ptr @__olang_region_make(ptr %v2)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t29 = load i64, ptr %l31
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t30, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l33
  br label %bb7
bb7:
  %t32 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e3
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load i64, ptr %l31
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = call ptr @__olang_region_or(ptr %t38, ptr null)
  %t40 = call ptr @__olang_region_home(ptr %t39)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  %t43 = icmp eq ptr %t42, %t35
  call void @__olang_region_settle(ptr %t35, i1 %t43)
  br label %bb9
bb9:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l5
  %t45 = ptrtoint ptr %v2 to i64
  store i64 %t45, ptr %l35, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e4
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = call ptr @__olang_region_make(ptr %v2)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l35
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t51, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l37
  br label %bb12
bb12:
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e4
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t55 = load i64, ptr %l35
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = call ptr @__olang_region_home(ptr %t60)
  %t62 = icmp ne ptr %t61, null
  %t63 = select i1 %t62, ptr %t61, ptr null
  %t64 = icmp eq ptr %t63, %t56
  call void @__olang_region_settle(ptr %t56, i1 %t64)
  br label %bb14
bb14:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l6
  %t66 = ptrtoint ptr %v2 to i64
  store i64 %t66, ptr %l39, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e5
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = call ptr @__olang_region_make(ptr %v2)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l39, !tbaa !24
  br label %bb16
bb16:
  %t71 = load i64, ptr %l39
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t72, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l41
  br label %bb17
bb17:
  %t74 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e5
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t76 = load i64, ptr %l39
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41, i32 0, i32 0
  %t79 = load { i64, ptr }, ptr %t78
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = call ptr @__olang_region_or(ptr %t80, ptr null)
  %t82 = call ptr @__olang_region_home(ptr %t81)
  %t83 = icmp ne ptr %t82, null
  %t84 = select i1 %t83, ptr %t82, ptr null
  %t85 = icmp eq ptr %t84, %t77
  call void @__olang_region_settle(ptr %t77, i1 %t85)
  br label %bb19
bb19:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l7
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l43
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l8
  %t89 = ptrtoint ptr %v2 to i64
  store i64 %t89, ptr %l44, !tbaa !24
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e7
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = call ptr @__olang_region_make(ptr %v2)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t94 = load i64, ptr %l44
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t95, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l46
  br label %bb23
bb23:
  %t97 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e7
  br i1 %t97, label %bb24, label %bb25
bb24:
  %t99 = load i64, ptr %l44
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = call ptr @__olang_region_or(ptr %t103, ptr null)
  %t105 = call ptr @__olang_region_home(ptr %t104)
  %t106 = icmp ne ptr %t105, null
  %t107 = select i1 %t106, ptr %t105, ptr null
  %t108 = icmp eq ptr %t107, %t100
  call void @__olang_region_settle(ptr %t100, i1 %t108)
  br label %bb25
bb25:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l9
  %t110 = ptrtoint ptr %v2 to i64
  store i64 %t110, ptr %l48, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e8
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = call ptr @__olang_region_make(ptr %v2)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l48, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l48
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t116)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t117, ptr %l50
  br label %bb28
bb28:
  %t118 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e8
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t120 = load i64, ptr %l48
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 2
  %t123 = load { i64, ptr }, ptr %t122
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr null)
  %t126 = call ptr @__olang_region_home(ptr %t125)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr null
  %t129 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = call ptr @__olang_region_home(ptr %t132)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr %t128
  %t136 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = call ptr @__olang_region_or(ptr %t138, ptr null)
  %t140 = call ptr @__olang_region_home(ptr %t139)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr %t135
  %t143 = icmp eq ptr %t142, %t121
  call void @__olang_region_settle(ptr %t121, i1 %t143)
  br label %bb30
bb30:
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %l10
  %t145 = ptrtoint ptr %v2 to i64
  store i64 %t145, ptr %l52, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e9
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = call ptr @__olang_region_make(ptr %v2)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l52, !tbaa !24
  br label %bb32
bb32:
  %t150 = load i64, ptr %l52
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %t151)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t152, ptr %l54
  br label %bb33
bb33:
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e9
  br i1 %t153, label %bb34, label %bb35
bb34:
  %t155 = load i64, ptr %l52
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = call ptr @__olang_region_or(ptr %t159, ptr null)
  %t161 = call ptr @__olang_region_home(ptr %t160)
  %t162 = icmp ne ptr %t161, null
  %t163 = select i1 %t162, ptr %t161, ptr null
  %t164 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = call ptr @__olang_region_or(ptr %t166, ptr null)
  %t168 = call ptr @__olang_region_home(ptr %t167)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr %t163
  %t171 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = call ptr @__olang_region_or(ptr %t173, ptr null)
  %t175 = call ptr @__olang_region_home(ptr %t174)
  %t176 = icmp ne ptr %t175, null
  %t177 = select i1 %t176, ptr %t175, ptr %t170
  %t178 = icmp eq ptr %t177, %t156
  call void @__olang_region_settle(ptr %t156, i1 %t178)
  br label %bb35
bb35:
  %t179 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t179, ptr %l11
  %t180 = ptrtoint ptr %v2 to i64
  store i64 %t180, ptr %l56, !tbaa !24
  %t181 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e10
  br i1 %t181, label %bb36, label %bb37
bb36:
  %t183 = call ptr @__olang_region_make(ptr %v2)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l56, !tbaa !24
  br label %bb37
bb37:
  %t185 = load i64, ptr %l56
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t186)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t187, ptr %l58
  br label %bb38
bb38:
  %t188 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e10
  br i1 %t188, label %bb39, label %bb40
bb39:
  %t190 = load i64, ptr %l56
  %t191 = inttoptr i64 %t190 to ptr
  %t192 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = call ptr @__olang_region_or(ptr %t194, ptr null)
  %t196 = call ptr @__olang_region_home(ptr %t195)
  %t197 = icmp ne ptr %t196, null
  %t198 = select i1 %t197, ptr %t196, ptr null
  %t199 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = call ptr @__olang_region_home(ptr %t202)
  %t204 = icmp ne ptr %t203, null
  %t205 = select i1 %t204, ptr %t203, ptr %t198
  %t206 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = call ptr @__olang_region_or(ptr %t208, ptr null)
  %t210 = call ptr @__olang_region_home(ptr %t209)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr %t205
  %t213 = icmp eq ptr %t212, %t191
  call void @__olang_region_settle(ptr %t191, i1 %t213)
  br label %bb40
bb40:
  %t214 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t214, ptr %l12
  %t215 = ptrtoint ptr %v2 to i64
  store i64 %t215, ptr %l60, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e11
  br i1 %t216, label %bb41, label %bb42
bb41:
  %t218 = call ptr @__olang_region_make(ptr %v2)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l60, !tbaa !24
  br label %bb42
bb42:
  %t220 = load i64, ptr %l60
  %t221 = inttoptr i64 %t220 to ptr
  %t222 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t221, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, ptr %l62
  br label %bb43
bb43:
  %t223 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e11
  br i1 %t223, label %bb44, label %bb45
bb44:
  %t225 = load i64, ptr %l60
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = call ptr @__olang_region_or(ptr %t229, ptr null)
  %t231 = call ptr @__olang_region_home(ptr %t230)
  %t232 = icmp ne ptr %t231, null
  %t233 = select i1 %t232, ptr %t231, ptr null
  %t234 = icmp eq ptr %t233, %t226
  call void @__olang_region_settle(ptr %t226, i1 %t234)
  br label %bb45
bb45:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l13
  %t236 = ptrtoint ptr %v2 to i64
  store i64 %t236, ptr %l64, !tbaa !24
  %t237 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e12
  br i1 %t237, label %bb46, label %bb47
bb46:
  %t239 = call ptr @__olang_region_make(ptr %v2)
  %t240 = ptrtoint ptr %t239 to i64
  store i64 %t240, ptr %l64, !tbaa !24
  br label %bb47
bb47:
  %t241 = load i64, ptr %l64
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t242, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l66
  br label %bb48
bb48:
  %t244 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e12
  br i1 %t244, label %bb49, label %bb50
bb49:
  %t246 = load i64, ptr %l64
  %t247 = inttoptr i64 %t246 to ptr
  %t248 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t249 = load { i64, ptr }, ptr %t248
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = call ptr @__olang_region_or(ptr %t250, ptr null)
  %t252 = call ptr @__olang_region_home(ptr %t251)
  %t253 = icmp ne ptr %t252, null
  %t254 = select i1 %t253, ptr %t252, ptr null
  %t255 = icmp eq ptr %t254, %t247
  call void @__olang_region_settle(ptr %t247, i1 %t255)
  br label %bb50
bb50:
  %t256 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t257 = ptrtoint ptr %v2 to i64
  store i64 %t257, ptr %l68, !tbaa !24
  %t258 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e14
  br i1 %t258, label %bb51, label %bb52
bb51:
  %t260 = call ptr @__olang_region_make(ptr %v2)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l68, !tbaa !24
  br label %bb52
bb52:
  %t262 = load i64, ptr %l68
  %t263 = inttoptr i64 %t262 to ptr
  %t264 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t263, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l70
  br label %bb53
bb53:
  %t265 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e14
  br i1 %t265, label %bb54, label %bb55
bb54:
  %t267 = load i64, ptr %l68
  %t268 = inttoptr i64 %t267 to ptr
  %t269 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = call ptr @__olang_region_or(ptr %t271, ptr null)
  %t273 = call ptr @__olang_region_home(ptr %t272)
  %t274 = icmp ne ptr %t273, null
  %t275 = select i1 %t274, ptr %t273, ptr null
  %t276 = icmp eq ptr %t275, %t268
  call void @__olang_region_settle(ptr %t268, i1 %t276)
  br label %bb55
bb55:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l16
  %t278 = ptrtoint ptr %v2 to i64
  store i64 %t278, ptr %l72, !tbaa !24
  %t279 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e15
  br i1 %t279, label %bb56, label %bb57
bb56:
  %t281 = call ptr @__olang_region_make(ptr %v2)
  %t282 = ptrtoint ptr %t281 to i64
  store i64 %t282, ptr %l72, !tbaa !24
  br label %bb57
bb57:
  %t283 = load i64, ptr %l72
  %t284 = inttoptr i64 %t283 to ptr
  %t285 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t284, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t285, ptr %l74
  br label %bb58
bb58:
  %t286 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e15
  br i1 %t286, label %bb59, label %bb60
bb59:
  %t288 = load i64, ptr %l72
  %t289 = inttoptr i64 %t288 to ptr
  %t290 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74, i32 0, i32 0
  %t291 = load { i64, ptr }, ptr %t290
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = call ptr @__olang_region_or(ptr %t292, ptr null)
  %t294 = call ptr @__olang_region_home(ptr %t293)
  %t295 = icmp ne ptr %t294, null
  %t296 = select i1 %t295, ptr %t294, ptr null
  %t297 = icmp eq ptr %t296, %t289
  call void @__olang_region_settle(ptr %t289, i1 %t297)
  br label %bb60
bb60:
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %l17
  %t299 = ptrtoint ptr %v2 to i64
  store i64 %t299, ptr %l76, !tbaa !24
  %t300 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e16
  br i1 %t300, label %bb61, label %bb62
bb61:
  %t302 = call ptr @__olang_region_make(ptr %v2)
  %t303 = ptrtoint ptr %t302 to i64
  store i64 %t303, ptr %l76, !tbaa !24
  br label %bb62
bb62:
  %t304 = load i64, ptr %l76
  %t305 = inttoptr i64 %t304 to ptr
  %t306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t305, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l78
  br label %bb63
bb63:
  %t307 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e16
  br i1 %t307, label %bb64, label %bb65
bb64:
  %t309 = load i64, ptr %l76
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78, i32 0, i32 0
  %t312 = load { i64, ptr }, ptr %t311
  %t313 = extractvalue { i64, ptr } %t312, 1
  %t314 = call ptr @__olang_region_or(ptr %t313, ptr null)
  %t315 = call ptr @__olang_region_home(ptr %t314)
  %t316 = icmp ne ptr %t315, null
  %t317 = select i1 %t316, ptr %t315, ptr null
  %t318 = icmp eq ptr %t317, %t310
  call void @__olang_region_settle(ptr %t310, i1 %t318)
  br label %bb65
bb65:
  %t319 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l18
  %t320 = ptrtoint ptr %v2 to i64
  store i64 %t320, ptr %l80, !tbaa !24
  %t321 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e17
  br i1 %t321, label %bb66, label %bb67
bb66:
  %t323 = call ptr @__olang_region_make(ptr %v2)
  %t324 = ptrtoint ptr %t323 to i64
  store i64 %t324, ptr %l80, !tbaa !24
  br label %bb67
bb67:
  %t325 = load i64, ptr %l80
  %t326 = inttoptr i64 %t325 to ptr
  %t327 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t326, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t327, ptr %l82
  br label %bb68
bb68:
  %t328 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e17
  br i1 %t328, label %bb69, label %bb70
bb69:
  %t330 = load i64, ptr %l80
  %t331 = inttoptr i64 %t330 to ptr
  %t332 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82, i32 0, i32 0
  %t333 = load { i64, ptr }, ptr %t332
  %t334 = extractvalue { i64, ptr } %t333, 1
  %t335 = call ptr @__olang_region_or(ptr %t334, ptr null)
  %t336 = call ptr @__olang_region_home(ptr %t335)
  %t337 = icmp ne ptr %t336, null
  %t338 = select i1 %t337, ptr %t336, ptr null
  %t339 = icmp eq ptr %t338, %t331
  call void @__olang_region_settle(ptr %t331, i1 %t339)
  br label %bb70
bb70:
  %t340 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t340, ptr %l19
  %t341 = ptrtoint ptr %v2 to i64
  store i64 %t341, ptr %l84, !tbaa !24
  %t342 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e18
  br i1 %t342, label %bb71, label %bb72
bb71:
  %t344 = call ptr @__olang_region_make(ptr %v2)
  %t345 = ptrtoint ptr %t344 to i64
  store i64 %t345, ptr %l84, !tbaa !24
  br label %bb72
bb72:
  %t346 = load i64, ptr %l84
  %t347 = inttoptr i64 %t346 to ptr
  %t348 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t347, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, ptr %l86
  br label %bb73
bb73:
  %t349 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e18
  br i1 %t349, label %bb74, label %bb75
bb74:
  %t351 = load i64, ptr %l84
  %t352 = inttoptr i64 %t351 to ptr
  %t353 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353
  %t355 = extractvalue { i64, ptr } %t354, 1
  %t356 = call ptr @__olang_region_or(ptr %t355, ptr null)
  %t357 = call ptr @__olang_region_home(ptr %t356)
  %t358 = icmp ne ptr %t357, null
  %t359 = select i1 %t358, ptr %t357, ptr null
  %t360 = icmp eq ptr %t359, %t352
  call void @__olang_region_settle(ptr %t352, i1 %t360)
  br label %bb75
bb75:
  %t361 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t361, ptr %l20
  %t362 = ptrtoint ptr %v2 to i64
  store i64 %t362, ptr %l88, !tbaa !24
  %t363 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e19
  br i1 %t363, label %bb76, label %bb77
bb76:
  %t365 = call ptr @__olang_region_make(ptr %v2)
  %t366 = ptrtoint ptr %t365 to i64
  store i64 %t366, ptr %l88, !tbaa !24
  br label %bb77
bb77:
  %t367 = load i64, ptr %l88
  %t368 = inttoptr i64 %t367 to ptr
  %t369 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t368, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t369, ptr %l90
  br label %bb78
bb78:
  %t370 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e19
  br i1 %t370, label %bb79, label %bb80
bb79:
  %t372 = load i64, ptr %l88
  %t373 = inttoptr i64 %t372 to ptr
  %t374 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t375 = load { i64, ptr }, ptr %t374
  %t376 = extractvalue { i64, ptr } %t375, 1
  %t377 = call ptr @__olang_region_or(ptr %t376, ptr null)
  %t378 = call ptr @__olang_region_home(ptr %t377)
  %t379 = icmp ne ptr %t378, null
  %t380 = select i1 %t379, ptr %t378, ptr null
  %t381 = icmp eq ptr %t380, %t373
  call void @__olang_region_settle(ptr %t373, i1 %t381)
  br label %bb80
bb80:
  %t382 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t383 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 0
  %t384 = load ptr, ptr %l2, !tbaa !29
  store ptr %t384, ptr %t383, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 1
  %t386 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t386, ptr %t385, !tbaa !27
  %t387 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 2
  %t388 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t388, ptr %t387, !tbaa !27
  %t389 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 3
  %t390 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t390, ptr %t389
  %t391 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 4
  %t392 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t392, ptr %t391
  %t393 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 5
  %t394 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t394, ptr %t393
  %t395 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 6
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %t395
  %t397 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 7
  %t398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %t397
  %t399 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 8
  %t400 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t400, ptr %t399
  %t401 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 9
  %t402 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t402, ptr %t401
  %t403 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 10
  %t404 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t404, ptr %t403
  %t405 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 11
  %t406 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t406, ptr %t405
  %t407 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 12
  %t408 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t408, ptr %t407
  %t409 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 13
  %t410 = load i64, ptr %l15, !tbaa !24
  store i64 %t410, ptr %t409, !tbaa !24
  %t411 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 14
  %t412 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t412, ptr %t411
  %t413 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 15
  %t414 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t414, ptr %t413
  %t415 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 16
  %t416 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t416, ptr %t415
  %t417 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 17
  %t418 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t418, ptr %t417
  %t419 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 18
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %t419
  %t421 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %t421
  %t423 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 20
  store i1 true, ptr %t423, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l92, i64 688, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_scope_or(ptr, ptr)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3adropWalk__2ematch_2elocal_2e7 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_release(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e8 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aVersions_2e9 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aVersions_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e19 = weak hidden constant i1 false
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_98ffd35c6a6991db_b4b9a5fbdbb15627 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2einert(ptr %v0, ptr %a0)
@olang_loc_ab97fbd57ee6d83_6d3fb4eb1c4ce94f = external constant [0 x i8]
@olang_loc_466792cdfa40bc02_3c21a4fe0416b90e = external constant [0 x i8]
@olang_loc_22aea6a044f95e17_c10e152cae22b18b = external constant [0 x i8]
declare i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0)
@olang_loc_bf16ba0368763d37_f19ef32b132443ab = external constant [0 x i8]
@olang_loc_af65136929bfae16_48f8be4437d6c6ea = external constant [0 x i8]
@olang_loc_b0232f0aa88d97cf_b0ec20639face60b = external constant [0 x i8]
@G_2ecompiler_2ftyped_2emathNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftyped_2emathArity = available_externally constant <{ [248 x i8] }> <{ [248 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@olang_loc_62af31c5105aaa5b_ddb95177f2bf45e7 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_2b7320a535e51c63_682587c414220c47 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ecb034f719e18c1b_985175307bfdc34f = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6690d985632b6de7_b13460b3c8232d4b = external constant [0 x i8]
@olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e933c796b27591a8_e869c9717a33729c = external constant [0 x i8]
declare %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eRefReadOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eviewInto(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_6ff368c26ca3ad9b_74caa00555ca222f = external constant [0 x i8]
declare i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eunkept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i1 %a4, i1 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2emade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, [1 x i64] } %a3, i64 %a4, i64 %a5, i1 %a6)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egiven(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i1 %a4)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i1 %a4)
declare %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftyped_2eHanded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftyped_2eElsewhere = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_b9f0b2a15b6670eb_2e1d369e87bd8cdf = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5437ab06fdd2422a_119d1d559b7fc05e = external constant [0 x i8]
@olang_loc_ef0de602c5122041_f82f60a1eb2bb195 = external constant [0 x i8]
@olang_loc_dac0899521d00a27_f5966ad5b7471ec3 = external constant [0 x i8]
@olang_loc_4d8a06dfe39d8193_a27ec756202836f = external constant [0 x i8]
@olang_loc_104aca9b23d55792_b4686871930206ae = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e4df3a218fbdfef_2fc14a2cfade6f23 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H850118f76c49c45e73ad12b3c73517c9(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H658d0bbb24c75abb2e0dcb1121887af6(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hca132088ebdf08d0820c179196416125(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i64 @compiler_2ftyped_2edefName(i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %v0, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78 = external constant [0 x i8]
@olang_loc_f658218d2a233859_f81a26e56b3c591d = external constant [0 x i8]
@olang_loc_4c95fac740fe18b9_da00c3dfb70c298d = external constant [0 x i8]
@olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14 = external constant [0 x i8]
@olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69 = external constant [0 x i8]
@olang_loc_cb0f3499142fc19d_d94490f94af5f129 = external constant [0 x i8]
@olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf = external constant [0 x i8]
@olang_loc_14162ea47c0c801c_ce4205068f01e790 = external constant [0 x i8]
@olang_loc_a93f600a1cb39be1_ee16d2dfcadba585 = external constant [0 x i8]
@olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da = external constant [0 x i8]
@olang_loc_8726c5b979482c78_cdee9de0701e13e4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edefine(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, i1 %a4)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2elater(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3)
@olang_loc_89804b2e92d33dd7_8d0f976d28b858c3 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_c8b3a2ed155d5757_c640a14e4e3ad273 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_17c315ca28f40c4c_14b80e258f8c2b0 = external constant [0 x i8]
@olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5 = external constant [0 x i8]
@olang_loc_6fe9eb3ff5642bc1_33392e6f48613205 = external constant [0 x i8]
@olang_loc_5f1ddc7ef7469727_e10177d23ca0510b = external constant [0 x i8]
@olang_loc_24a3ccdd47c97c70_8558c77bc7af118c = external constant [0 x i8]
@olang_loc_130a89b2782f12a5_38e9334e27b56d91 = external constant [0 x i8]
@olang_loc_1916e27cc0da8fc5_b948d7408e366d01 = external constant [0 x i8]
@olang_loc_567e5689d7ac5ccb_d57870be630e767 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f5a8870640a369c_e3a704984aad8c8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eLen_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eAt_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c1faed4ae36d3640_1d7aa47a4727493c = external constant [0 x i8]
@olang_loc_2cf1608fd5d1230c_1374e48cd144e348 = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_73be6a0e490978a7_b5fa18d3e7eede33 = external constant [0 x i8]
@olang_loc_2fb6091d652311b2_1c71a9a414fce87e = external constant [0 x i8]
@olang_loc_8c1b8241682c8a5c_1491e83e9da6f28 = external constant [0 x i8]
@olang_loc_4fc9df9522ae1330_697d53c50db00ce4 = external constant [0 x i8]
@olang_loc_e4195c8d52320dab_6e5abcaf8844f88f = external constant [0 x i8]
@olang_loc_6df7d27e20fc18e6_9af88db0bee394aa = external constant [0 x i8]
@olang_loc_c52364142dc414a0_4d1da6470710a144 = external constant [0 x i8]
@olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730 = external constant [0 x i8]
@olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab = external constant [0 x i8]
@olang_loc_cdd2e50680d68485_7d51e204495f7309 = external constant [0 x i8]
@olang_loc_2ee7063c57fe9793_68bf97cc73752027 = external constant [0 x i8]
@olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_ee90b64eb208d194_3ee30fc86ac20510 = external constant [0 x i8]
@olang_loc_adeeaf8d66de5e9_765e2536cff45a05 = external constant [0 x i8]
@olang_loc_735ea97a101db8a9_ef46e9a3f6738c65 = external constant [0 x i8]
@olang_loc_720a79c775c6eb2f_4e77fac288b2d7ab = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7fb442b2027c5df4_8cb8a301a51c1668 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheldBefore(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempHolds(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eelemStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
@olang_loc_60996a1f08c29aeb_ed876111a60916df = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b80660129801afa0_e660219d512f014 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba = external constant [0 x i8]
@olang_loc_1807395182923f6f_ecff5ea7ed15d953 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_722457a86dc26837_d472b9738ae39dfb = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_8a62bacdff20949b_383b5959755ced57 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4baf654831ed8d80_eee61e02aec284c4 = external constant [0 x i8]
@olang_loc_f3eab8194bd11e66_e0240e140d7ed92a = external constant [0 x i8]
@olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_336e4a7a18e16ea4_5caa821eea897180 = external constant [0 x i8]
@olang_loc_43ee4571abcd420a_a05ceada06352a66 = external constant [0 x i8]
@olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b = external constant [0 x i8]
declare %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %v0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4231ae67b136756b_a4f71f39f0a47447 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_942c69358f77327c_b8abecb88c811c88 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eturnExprs(ptr %v0, { i64, ptr } %a0, %"compiler/source:Span" %a1)
@olang_loc_951602b5c1ab1d3_8d3a831a41b7ff67 = external constant [0 x i8]
@olang_loc_76d2aa8969b3545b_e178bc39d62c767f = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_a650b38034a5180c_4858ad52e7b771b8 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
