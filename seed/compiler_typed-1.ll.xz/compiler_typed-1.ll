; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:landLoop" = type { i32, i64, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l85 = alloca { i64, ptr }
  %l92 = alloca i1
  %l96 = alloca i1
  %l104 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l137 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l154 = alloca i1
  %l164 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l199 = alloca i1
  %l201 = alloca { i64, ptr }
  %l204 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t16 = load ptr, ptr %l29, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 5
  store i1 %t22, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l30, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 8
  store i1 %t31, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l34, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 16
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 6
  store i1 %t50, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t51 = load i1, ptr %l43, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l2, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l50
  br label %bb27
bb27:
  %t63 = load i1, ptr %l50, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t68 = load ptr, ptr %l51, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 11
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb31, label %bb32
bb31:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Cond", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l60
  br label %bb34
bb34:
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb35, label %bb36
bb35:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Cond", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t96 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  store i1 %t96, ptr %l66
  br label %bb37
bb36:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb38
bb37:
  %t97 = load i1, ptr %l66, !tbaa !21
  store i1 %t97, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t98 = load i1, ptr %l61, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
bb39:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb40, label %bb41
bb40:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 13
  store i1 %t106, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t107 = load i1, ptr %l68, !tbaa !21
  br i1 %t107, label %bb42, label %bb43
bb42:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l4, !tbaa !29
  br label %bb44
bb43:
  br label %bb74
bb44:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Match", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Match", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t147, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Arm", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t163 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t156, ptr %t160)
  store i1 %t163, ptr %l96
  br label %bb54
bb53:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb55
bb54:
  %t164 = load i1, ptr %l96, !tbaa !21
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l92, !tbaa !21
  br label %bb55
bb55:
  %t167 = load i1, ptr %l92, !tbaa !21
  br i1 %t167, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t169 = load i64, ptr %l6, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l6, !tbaa !24
  br label %bb48
bb60:
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Match", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = icmp eq ptr %t176, null
  br i1 %t178, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb66
bb62:
  %t180 = load ptr, ptr %l4, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Match", ptr %t180, i32 0, i32 2
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb64:
  br label %bb65
bb65:
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Match", ptr %t187, i32 0, i32 2
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Arm", ptr %t190, i32 0, i32 4
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  store i1 %t196, ptr %l104, !tbaa !21
  br label %bb66
bb66:
  %t198 = load i1, ptr %l104, !tbaa !21
  br i1 %t198, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb73
bb68:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l114, !tbaa !29
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Match", ptr %t200, i32 0, i32 2
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  br i1 %t205, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb70:
  br label %bb71
bb71:
  %t207 = load ptr, ptr %l4, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Match", ptr %t207, i32 0, i32 2
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Arm", ptr %t210, i32 0, i32 4
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load ptr, ptr %l114, !tbaa !29
  %t217 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t215, ptr %t214)
  store i1 %t217, ptr %l122
  br label %bb72
bb72:
  %t218 = load i1, ptr %l122, !tbaa !21
  store i1 %t218, ptr %l113, !tbaa !21
  br label %bb73
bb73:
  %t219 = load i1, ptr %l113, !tbaa !21
  store i1 %t219, ptr %rv
  br label %ret
bb74:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t221 = load ptr, ptr %l123, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb75, label %bb76
bb75:
  %t224 = load ptr, ptr %l123, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 14
  store i1 %t227, ptr %l124, !tbaa !21
  br label %bb76
bb76:
  %t228 = load i1, ptr %l124, !tbaa !21
  br i1 %t228, label %bb77, label %bb78
bb77:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l9, !tbaa !29
  br label %bb79
bb78:
  br label %bb97
bb79:
  %t235 = load ptr, ptr %l9, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Try", ptr %t235, i32 0, i32 1
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  store i64 %t242, ptr %l12, !tbaa !24
  br label %bb80
bb80:
  %t244 = load i64, ptr %l11, !tbaa !24
  %t245 = load i64, ptr %l12, !tbaa !24
  %t248 = icmp slt i64 %t244, %t245
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  br label %bb83
bb83:
  %t252 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t252, ptr %l137, !tbaa !27
  %t253 = load i64, ptr %l11, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 %t253
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t262 = getelementptr %"compiler/typed:Clause", ptr %t258, i32 0, i32 4
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l16, !tbaa !24
  br label %bb84
bb84:
  %t269 = load i64, ptr %l15, !tbaa !24
  %t270 = load i64, ptr %l16, !tbaa !24
  %t273 = icmp slt i64 %t269, %t270
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t277 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t277, ptr %l148, !tbaa !27
  %t278 = load i64, ptr %l15, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr ptr, ptr %t281, i64 %t278
  %t283 = load ptr, ptr %t282, !tbaa !39
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t290 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t285, ptr %t283)
  store i1 %t290, ptr %l154
  br label %bb88
bb88:
  %t291 = load i1, ptr %l154, !tbaa !21
  %t292 = xor i1 %t291, true
  br i1 %t292, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t295 = load i64, ptr %l15, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l15, !tbaa !24
  br label %bb84
bb93:
  br label %bb94
bb94:
  %t299 = load i64, ptr %l11, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l11, !tbaa !24
  br label %bb80
bb95:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l9, !tbaa !29
  %t306 = getelementptr %"compiler/typed:Try", ptr %t304, i32 0, i32 0
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t310 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t303, ptr %t307)
  store i1 %t310, ptr %l164
  br label %bb96
bb96:
  %t311 = load i1, ptr %l164, !tbaa !21
  store i1 %t311, ptr %rv
  br label %ret
bb97:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t313 = load ptr, ptr %l165, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb98, label %bb99
bb98:
  %t316 = load ptr, ptr %l165, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 18}
  %t319 = icmp eq i64 %t317, 12
  store i1 %t319, ptr %l166, !tbaa !21
  br label %bb99
bb99:
  %t320 = load i1, ptr %l166, !tbaa !21
  br i1 %t320, label %bb100, label %bb101
bb100:
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t323, i32 0, i32 2
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l18, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Seq", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t334 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t327, ptr %t331)
  store i1 %t334, ptr %l174
  br label %bb103
bb103:
  %t335 = load i1, ptr %l174, !tbaa !21
  store i1 %t335, ptr %rv
  br label %ret
bb104:
  %t336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t336, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t337 = load ptr, ptr %l175, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb105, label %bb106
bb105:
  %t340 = load ptr, ptr %l175, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 18}
  %t343 = icmp eq i64 %t341, 17
  store i1 %t343, ptr %l176, !tbaa !21
  br label %bb106
bb106:
  %t344 = load i1, ptr %l176, !tbaa !21
  br i1 %t344, label %bb107, label %bb108
bb107:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t347, i32 0, i32 2
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l19, !tbaa !29
  %t356 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store i1 %t356, ptr %l184
  br label %bb110
bb110:
  %t357 = load i1, ptr %l184, !tbaa !21
  store i1 %t357, ptr %rv
  br label %ret
bb111:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t359 = load ptr, ptr %l185, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t362 = load ptr, ptr %l185, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 18}
  %t365 = icmp eq i64 %t363, 9
  store i1 %t365, ptr %l186, !tbaa !21
  br label %bb113
bb113:
  %t366 = load i1, ptr %l186, !tbaa !21
  br i1 %t366, label %bb114, label %bb115
bb114:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load i32, ptr %t370, !range !{i32 0, i32 52}
  store i32 %t371, ptr %l20
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t375, i32 0, i32 4
  %t377 = load { i64, ptr }, ptr %t376
  store { i64, ptr } %t377, ptr %l21, !tbaa !27
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t379 = load i32, ptr %l20, !range !{i32 0, i32 52}
  %t381 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t379)
  store i1 %t381, ptr %l194
  br label %bb117
bb117:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb118, label %bb119
bb118:
  %t383 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t387 = icmp sgt i64 %t385, 0
  store i1 %t387, ptr %l195, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb120
bb120:
  %t389 = load i1, ptr %l195, !tbaa !21
  br i1 %t389, label %bb121, label %bb122
bb121:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t391, ptr %l201, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr ptr, ptr %t393, i64 0
  %t395 = load ptr, ptr %t394, !tbaa !39
  %t399 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t390, ptr %t395)
  store i1 %t399, ptr %l204
  br label %bb123
bb122:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb124
bb123:
  %t400 = load i1, ptr %l204, !tbaa !21
  store i1 %t400, ptr %l199, !tbaa !21
  br label %bb124
bb124:
  %t401 = load i1, ptr %l199, !tbaa !21
  store i1 %t401, ptr %rv
  br label %ret
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store i1 false, ptr %rv
  br label %ret
bb129:
  call void @__olang_check_failed(ptr @olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 13
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Join", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_98ffd35c6a6991db_b4b9a5fbdbb15627)
  unreachable
bb23:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store ptr %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l36 = alloca i64
  %l40 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l47 = alloca i1
  %l66 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l84 = alloca i1
  %l98 = alloca i1
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %t2)
  store i64 %t5, ptr %l36
  br label %bb1
bb1:
  %t6 = load i64, ptr %l36, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Block", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l40, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 0
  %t17 = load ptr, ptr %t16, !tbaa !39
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t20 = load ptr, ptr %l42, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l42, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l43, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l43, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb9
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  %t45 = getelementptr %"compiler/typed:If", ptr %t40, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Block", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp eq i64 %t51, 0
  store i1 %t53, ptr %l47, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l47, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l5
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  %t72 = getelementptr %"compiler/typed:If", ptr %t67, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Block", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l66, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 0
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l7, !tbaa !29
  %t82 = load ptr, ptr %l7, !tbaa !29
  store ptr %t82, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t83 = load ptr, ptr %l68, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb13, label %bb14
bb13:
  %t86 = load ptr, ptr %l68, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 17}
  %t89 = icmp eq i64 %t87, 2
  store i1 %t89, ptr %l69, !tbaa !21
  br label %bb14
bb14:
  %t90 = load i1, ptr %l69, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb15, label %bb16
bb15:
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t94 = load ptr, ptr %l7, !tbaa !29
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 0
  %t98 = load %"compiler/source:Span", ptr %t97
  store %"compiler/source:Span" %t98, ptr %l8
  %t100 = load ptr, ptr %l7, !tbaa !29
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", ptr }, ptr %t102, i32 0, i32 1
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l10, !tbaa !29
  %t108 = load ptr, ptr %l10, !tbaa !29
  store ptr %t108, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t109 = load ptr, ptr %l79, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb18, label %bb19
bb18:
  %t112 = load ptr, ptr %l79, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 9
  store i1 %t115, ptr %l80, !tbaa !21
  br label %bb19
bb19:
  %t116 = load i1, ptr %l80, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb22
bb21:
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t121, i32 0, i32 0
  %t123 = load %"compiler/source:Span", ptr %t122
  store %"compiler/source:Span" %t123, ptr %l11
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t127, i32 0, i32 1
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l12, !tbaa !23
  %t131 = load ptr, ptr %l10, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t133, i32 0, i32 2
  %t135 = load i32, ptr %t134, !range !{i32 0, i32 52}
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t139, i32 0, i32 3
  %t141 = load i32, ptr %t140, !range !{i32 0, i32 3}
  store i32 %t141, ptr %l14
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t145, i32 0, i32 4
  %t147 = load { i64, ptr }, ptr %t146
  store { i64, ptr } %t147, ptr %l15, !tbaa !27
  %t151 = trunc i64 30 to i32
  %t152 = icmp eq i32 %t135, %t151
  %t154 = xor i1 %t152, true
  store i1 %t154, ptr %l84, !tbaa !21
  br label %bb22
bb22:
  %t156 = load i1, ptr %l84, !tbaa !21
  br i1 %t156, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb25
bb24:
  %t157 = load ptr, ptr %l10, !tbaa !29
  %t159 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t159, i32 0, i32 0
  %t161 = load %"compiler/source:Span", ptr %t160
  store %"compiler/source:Span" %t161, ptr %l16
  %t163 = load ptr, ptr %l10, !tbaa !29
  %t165 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t165, i32 0, i32 1
  %t167 = load i32, ptr %t166
  store i32 %t167, ptr %l17, !tbaa !23
  %t169 = load ptr, ptr %l10, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t171, i32 0, i32 2
  %t173 = load i32, ptr %t172, !range !{i32 0, i32 52}
  store i32 %t173, ptr %l18
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t177, i32 0, i32 3
  %t179 = load i32, ptr %t178, !range !{i32 0, i32 3}
  store i32 %t179, ptr %l19
  %t181 = load ptr, ptr %l10, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t183, i32 0, i32 4
  %t185 = load { i64, ptr }, ptr %t184
  %t189 = extractvalue { i64, ptr } %t185, 0
  %t191 = icmp ne i64 %t189, 1
  store i1 %t191, ptr %l98, !tbaa !21
  br label %bb25
bb25:
  %t193 = load i1, ptr %l98, !tbaa !21
  br i1 %t193, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t197, i32 0, i32 0
  %t199 = load %"compiler/source:Span", ptr %t198
  store %"compiler/source:Span" %t199, ptr %l21
  %t201 = load ptr, ptr %l10, !tbaa !29
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t203, i32 0, i32 1
  %t205 = load i32, ptr %t204
  store i32 %t205, ptr %l22, !tbaa !23
  %t207 = load ptr, ptr %l10, !tbaa !29
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t209, i32 0, i32 2
  %t211 = load i32, ptr %t210, !range !{i32 0, i32 52}
  store i32 %t211, ptr %l23
  %t213 = load ptr, ptr %l10, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t215, i32 0, i32 3
  %t217 = load i32, ptr %t216, !range !{i32 0, i32 3}
  store i32 %t217, ptr %l24
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t221 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t221, i32 0, i32 4
  %t223 = load { i64, ptr }, ptr %t222
  store { i64, ptr } %t223, ptr %l124, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 0
  %t230 = load ptr, ptr %t229, !tbaa !39
  store ptr %t230, ptr %l26, !tbaa !29
  %t232 = load ptr, ptr %l26, !tbaa !29
  store ptr %t232, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t233 = load ptr, ptr %l126, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb29, label %bb30
bb29:
  %t236 = load ptr, ptr %l126, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 3
  store i1 %t239, ptr %l127, !tbaa !21
  br label %bb30
bb30:
  %t240 = load i1, ptr %l127, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t244 = load ptr, ptr %l26, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 0
  %t248 = load %"compiler/source:Span", ptr %t247
  store %"compiler/source:Span" %t248, ptr %l27
  %t250 = load ptr, ptr %l26, !tbaa !29
  %t252 = getelementptr { i64, [5 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t252, i32 0, i32 1
  %t254 = load i32, ptr %t253
  store i32 %t254, ptr %l28, !tbaa !23
  %t256 = load ptr, ptr %l26, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l30, !tbaa !29
  %t264 = load ptr, ptr %l30, !tbaa !29
  store ptr %t264, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t265 = load ptr, ptr %l139, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb34, label %bb35
bb34:
  %t268 = load ptr, ptr %l139, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 8}
  %t271 = icmp eq i64 %t269, 0
  store i1 %t271, ptr %l140, !tbaa !21
  br label %bb35
bb35:
  %t272 = load i1, ptr %l140, !tbaa !21
  %t273 = xor i1 %t272, true
  br i1 %t273, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t276 = load ptr, ptr %l30, !tbaa !29
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t278, i32 0, i32 0
  %t280 = load %"compiler/source:Span", ptr %t279
  store %"compiler/source:Span" %t280, ptr %l31
  %t282 = load ptr, ptr %l30, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t284, i32 0, i32 1
  %t286 = load i32, ptr %t285
  store i32 %t286, ptr %l32, !tbaa !23
  %t288 = load ptr, ptr %l30, !tbaa !29
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t290, i32 0, i32 2
  %t292 = load i32, ptr %t291
  %t296 = sext i32 %t292 to i64
  store i64 %t296, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2eDropHolding_2eDropHolds(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca %"compiler/typed:DropHolding"
  %t3 = alloca %"compiler/typed:DropHolding", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftyped_2eDropHolding_2eholding(ptr %t3, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t3, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2eFreshViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { ptr, ptr }
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [1 x i64] }
  %l44 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l86 = alloca i1
  %l92 = alloca i64
  %l95 = alloca i1
  %l100 = alloca i64
  %l103 = alloca ptr
  %l105 = alloca i32
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, [1 x i64] }
  %l114 = alloca { i64, [1 x i64] }
  %l116 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp slt i32 %t17, 0
  store i1 %t19, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l26, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l28, !tbaa !23
  %t28 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t28, ptr %l29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t29)
  store i64 %t31, ptr %l31
  br label %bb10
bb10:
  %t32 = load i64, ptr %l31, !tbaa !24
  %t33 = trunc i64 %t32 to i32
  %t35 = load { ptr, ptr }, ptr %l29
  %t36 = extractvalue { ptr, ptr } %t35, 0
  %t37 = extractvalue { ptr, ptr } %t35, 1
  %t39 = call { i64, ptr } %t36(ptr %t37, ptr %s0, i32 %t33)
  store { i64, ptr } %t39, ptr %l34
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 8
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t50 = call { i64, [1 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s0, ptr %t47, i32 %t48, { i64, ptr } %t46)
  store { i64, [1 x i64] } %t50, ptr %l36
  br label %bb12
bb12:
  %t51 = load { i64, [1 x i64] }, ptr %l36
  store { i64, [1 x i64] } %t51, ptr %l5
  %t52 = load { i64, [1 x i64] }, ptr %l5
  %t54 = extractvalue { i64, [1 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l6, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t63, i64 %t64)
  store i64 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i64, ptr %l44, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb22
bb19:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l51, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb21
bb21:
  %t95 = load i64, ptr %l51, !tbaa !24
  store i64 %t95, ptr %l48, !tbaa !24
  br label %bb22
bb22:
  %t96 = load i64, ptr %l48, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l70, !tbaa !24
  %t117 = load i64, ptr %l70, !tbaa !24
  %t118 = load i64, ptr %l70, !tbaa !24
  %t119 = shl i64 1, %t118
  %t122 = and i64 %t115, %t119
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Call", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l75, !tbaa !27
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v1, ptr %t135)
  store i1 %t137, ptr %l78
  br label %bb30
bb30:
  %t138 = load i1, ptr %l78, !tbaa !21
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb32:
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l80, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  %t150 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v1, ptr %v1, ptr %t148, i64 0)
  store ptr %t150, ptr %l83
  br label %bb34
bb34:
  %t151 = load ptr, ptr %l83, !tbaa !29
  store ptr %t151, ptr %l12, !tbaa !29
  %t152 = load ptr, ptr %l12, !tbaa !29
  %t154 = icmp eq ptr %t152, null
  br i1 %t154, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb37
bb36:
  %t156 = load ptr, ptr %l12, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Call", ptr %t156, i32 0, i32 2
  %t159 = load i32, ptr %t158, !tbaa !23
  %t161 = icmp slt i32 %t159, 0
  store i1 %t161, ptr %l86, !tbaa !21
  br label %bb37
bb37:
  %t163 = load i1, ptr %l86, !tbaa !21
  br i1 %t163, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t167 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t165)
  store i64 %t167, ptr %l92
  br label %bb41
bb41:
  %t168 = load i64, ptr %l92, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp slt i64 %t169, 0
  br i1 %t171, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb45
bb43:
  %t174 = load i64, ptr %l13, !tbaa !24
  %t176 = trunc i64 %t174 to i32
  %t179 = extractvalue { ptr, ptr } %pg3, 0
  %t180 = extractvalue { ptr, ptr } %pg3, 1
  %t182 = call i64 %t179(ptr %t180, i32 %t176)
  store i64 %t182, ptr %l100
  br label %bb44
bb44:
  %t183 = load i64, ptr %l100, !tbaa !24
  %t184 = icmp ne i64 %t183, 0
  store i1 %t184, ptr %l95, !tbaa !21
  br label %bb45
bb45:
  %t186 = load i1, ptr %l95, !tbaa !21
  br i1 %t186, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l103, !tbaa !29
  %t189 = load ptr, ptr %l12, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Call", ptr %t189, i32 0, i32 2
  %t192 = load i32, ptr %t191, !tbaa !23
  store i32 %t192, ptr %l105, !tbaa !23
  %t193 = load { ptr, ptr }, ptr %l4
  %t194 = load i64, ptr %l13, !tbaa !24
  %t196 = trunc i64 %t194 to i32
  %t199 = extractvalue { ptr, ptr } %t193, 0
  %t200 = extractvalue { ptr, ptr } %t193, 1
  %t202 = call { i64, ptr } %t199(ptr %t200, ptr %s4, i32 %t196)
  store { i64, ptr } %t202, ptr %l110
  br label %bb49
bb49:
  %t203 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t205 = extractvalue { i64, ptr } %t203, 1
  %t206 = mul i64 %t204, 8
  %t207 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load ptr, ptr %l103, !tbaa !29
  %t211 = load i32, ptr %l105, !tbaa !23
  %t213 = call { i64, [1 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s4, ptr %t210, i32 %t211, { i64, ptr } %t209)
  store { i64, [1 x i64] } %t213, ptr %l112
  br label %bb50
bb50:
  %t214 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t214, ptr %l114
  %t217 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l112, ptr %l114)
  store i1 %t217, ptr %l116
  br label %bb51
bb51:
  %t218 = load i1, ptr %l116, !tbaa !21
  %t219 = xor i1 %t218, true
  br i1 %t219, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb55:
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l10, !tbaa !24
  br label %bb23
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eNoCallbackExtern(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue { i64, ptr } undef, i64 95, 0
  %t5 = insertvalue { i64, ptr } %t4, ptr @G_2ecompiler_2ftyped_2enoCallbackNames, 1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t10 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7, ptr %v0, { i64, ptr } %t5, { i64, ptr } %a0)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecalleeBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t16, i32 %a1)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_352016b8dfbaae41_4f83dc304b77dded)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t23 = alloca { i64, [1 x i64] }, align 8
  %t54 = alloca { i64, [1 x i64] }, align 8
  %t58 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t1, i32 %t5, i64 %t6)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 5
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t32, i32 %t36)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t50 = load ptr, ptr %l16, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [1 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t54
  store { i64, [1 x i64] } %t56, ptr %l27
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [1 x i64] }, ptr %t58
  store { i64, [1 x i64] } %t60, ptr %l27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, [1 x i64] }
  %l41 = alloca ptr
  %l45 = alloca i32
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t84 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t34)
  br label %bb7
bb6:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb7:
  br label %bb28
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l6
  %t48 = load { i64, [2 x i64] }, ptr %l6
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 6
  store ptr %t55, ptr %l41, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l45
  br label %bb25
bb10:
  br label %bb14
bb11:
  %t63 = load { i64, [2 x i64] }, ptr %l6
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_49a7b0a2550beed6_c54fa6caa81e807a)
  unreachable
bb20:
  %t68 = load i1, ptr %l29, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 6
  store ptr %t71, ptr %l35, !tbaa !29
  br i1 %t68, label %bb21, label %bb22
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l37
  br label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 1, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l37
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load { i64, [1 x i64] }, ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t82, { i64, [1 x i64] } %t83)
  br label %bb24
bb24:
  br label %bb27
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = insertvalue { i32 } undef, i32 %t86, 0
  %t88 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 1
  store { i32 } %t87, ptr %t88
  %t89 = load { i64, [1 x i64] }, ptr %t84
  %t90 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t90, { i64, [1 x i64] } %t89)
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l3, !tbaa !23
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l3, !tbaa !23
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l3, !tbaa !23
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l3, !tbaa !23
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load i32, ptr %l3, !tbaa !23
  store i32 %t185, ptr %l6, !tbaa !23
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l4, !tbaa !23
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l4, !tbaa !23
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l4, !tbaa !23
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l4, !tbaa !23
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l4, !tbaa !23
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l6, !tbaa !23
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l5, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t279 = load ptr, ptr %l5, !tbaa !29
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120, !tbaa !23
  store i32 %t282, ptr %l6, !tbaa !23
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57)
  unreachable
bb84:
  %t283 = load i32, ptr %l6, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca i1
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca i1
  %l91 = alloca i1
  %l93 = alloca i1
  %l97 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i64
  %l104 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb48
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Landings", ptr %t54, i32 0, i32 3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l42, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i1, ptr %t61, i64 %t58
  %t63 = load i1, ptr %t62, !tbaa !31
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb47
bb12:
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  %t71 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %t65, i64 %t66, i64 %t67)
  store i1 %t71, ptr %l48
  br label %bb14
bb14:
  %t72 = load i1, ptr %l48, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  br label %bb47
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l1, !tbaa !24
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Landings", ptr %t77, i32 0, i32 15
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l53
  br label %bb18
bb18:
  %t82 = load i64, ptr %l53, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb24
bb21:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l60, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb23
bb23:
  %t109 = load i64, ptr %l60, !tbaa !24
  store i64 %t109, ptr %l57, !tbaa !24
  br label %bb24
bb24:
  %t110 = load i64, ptr %l57, !tbaa !24
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l13, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Landings", ptr %t129, i32 0, i32 15
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l81
  br label %bb29
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Landings", ptr %t136, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l83, !tbaa !27
  %t140 = load i64, ptr %l7, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t140
  %t145 = load i64, ptr %t144, !tbaa !34
  %t146 = load i64, ptr %l81, !tbaa !24
  %t148 = icmp ne i64 %t146, %t145
  br i1 %t148, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb33
bb31:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Landings", ptr %t150, i32 0, i32 18
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l91
  br label %bb32
bb32:
  %t157 = load i1, ptr %l91, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l87, !tbaa !21
  br label %bb33
bb33:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb41
bb35:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Landings", ptr %t161, i32 0, i32 17
  %t164 = load i64, ptr %l13, !tbaa !24
  %t167 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t163, i64 %t164)
  store i1 %t167, ptr %l97
  br label %bb36
bb36:
  %t168 = load i1, ptr %l97, !tbaa !21
  br i1 %t168, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Landings", ptr %t169, i32 0, i32 16
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l102
  br label %bb39
bb38:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb40
bb39:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Landings", ptr %t176, i32 0, i32 1
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l104, !tbaa !27
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i64, ptr %t183, i64 %t180
  %t185 = load i64, ptr %t184, !tbaa !34
  %t186 = load i64, ptr %l102, !tbaa !24
  %t188 = icmp eq i64 %t186, %t185
  store i1 %t188, ptr %l98, !tbaa !21
  br label %bb40
bb40:
  %t190 = load i1, ptr %l98, !tbaa !21
  store i1 %t190, ptr %l93, !tbaa !21
  br label %bb41
bb41:
  %t191 = load i1, ptr %l93, !tbaa !21
  br i1 %t191, label %bb42, label %bb43
bb42:
  br label %bb45
bb43:
  br label %bb44
bb44:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Landings", ptr %t192, i32 0, i32 3
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l109, !tbaa !27
  %t196 = load i64, ptr %l7, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i1, ptr %t199, i64 %t196
  store i1 true, ptr %t200, !tbaa !31
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Landings", ptr %t201, i32 0, i32 5
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l112, !tbaa !27
  %t205 = load i64, ptr %l7, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i1, ptr %t208, i64 %t205
  store i1 true, ptr %t209, !tbaa !31
  br label %bb45
bb45:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb25
bb46:
  br label %bb47
bb47:
  %t214 = load i64, ptr %l6, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l6, !tbaa !24
  br label %bb7
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l19 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l34, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Landings", ptr %t59, i32 0, i32 15
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l39
  br label %bb10
bb10:
  %t64 = load i64, ptr %l39, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l9, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Bind", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t74, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %t73, i64 %t79, i64 %t80)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb6
bb14:
  br label %bb15
bb15:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  br label %bb17
bb17:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Arm", ptr %t100, i32 0, i32 3
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb18
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Arm", ptr %t107, i32 0, i32 4
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t106, ptr %t110)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:landLoop"
  %l9 = alloca i64
  %l17 = alloca %"compiler/typed:landLoop"
  %l24 = alloca %"compiler/typed:landLoop"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Landings", ptr %t20, i32 0, i32 8
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %s3, ptr %t22, i64 %t23)
  store %"compiler/typed:landLoop" %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = getelementptr %"compiler/typed:landLoop", ptr %l17, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t32 = icmp ne i32 %t28, %a2
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Landings", ptr %t34, i32 0, i32 8
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/typed:landLoop" %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load %"compiler/typed:landLoop", ptr %l24
  store %"compiler/typed:landLoop" %t41, ptr %l4
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %a1, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Landings", ptr %t49, i32 0, i32 6
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t48, { i64, ptr } %t52)
  br label %bb16
bb15:
  %t55 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Landings", ptr %t57, i32 0, i32 6
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t56, { i64, ptr } %t60)
  br label %bb17
bb16:
  %t63 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 4
  store i1 true, ptr %t63, !tbaa !21
  br label %bb18
bb17:
  %t64 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 5
  store i1 true, ptr %t64, !tbaa !21
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Landings", ptr %t65, i32 0, i32 8
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load %"compiler/typed:landLoop", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v0, ptr %t67, i64 %t68, %"compiler/typed:landLoop" %t69)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb20:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = sub i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb5
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Landings", ptr %t77, i32 0, i32 7
  store i1 true, ptr %t79, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i1
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 15
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i64, ptr %l18, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb56
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l46
  br label %bb12
bb12:
  %t62 = load i1, ptr %l46, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l49, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Landings", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l53
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t75, ptr %l54
  br label %bb16
bb16:
  %t76 = load i1, ptr %l54, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  br label %bb55
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 15
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l59
  br label %bb21
bb21:
  %t87 = load i64, ptr %l59, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb27
bb24:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l66, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb26
bb26:
  %t114 = load i64, ptr %l66, !tbaa !24
  store i64 %t114, ptr %l63, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb29, label %bb30
bb29:
  br label %bb54
bb30:
  br label %bb31
bb31:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l13, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Landings", ptr %t134, i32 0, i32 15
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l87
  br label %bb32
bb32:
  %t141 = load i64, ptr %l87, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  store i64 %t142, ptr %l88, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Landings", ptr %t143, i32 0, i32 15
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l92
  br label %bb33
bb33:
  %t150 = load i64, ptr %l88, !tbaa !24
  %t151 = load i64, ptr %l92, !tbaa !24
  %t152 = icmp eq i64 %t150, %t151
  br i1 %t152, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb37
bb35:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Landings", ptr %t154, i32 0, i32 18
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t156, i64 %t157)
  store i1 %t160, ptr %l98
  br label %bb36
bb36:
  %t161 = load i1, ptr %l98, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l94, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l94, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb40
bb39:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = icmp slt i64 %t165, 0
  store i1 %t167, ptr %l100, !tbaa !21
  br label %bb40
bb40:
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb43
bb42:
  %t170 = load i64, ptr %l14, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Landings", ptr %t171, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t179 = icmp sge i64 %t170, %t176
  store i1 %t179, ptr %l103, !tbaa !21
  br label %bb43
bb43:
  %t181 = load i1, ptr %l103, !tbaa !21
  br i1 %t181, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb46
bb45:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Landings", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l111, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t186
  %t191 = load i1, ptr %t190, !tbaa !31
  %t193 = xor i1 %t191, true
  store i1 %t193, ptr %l109, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l109, !tbaa !21
  br i1 %t195, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  br label %bb49
bb49:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Landings", ptr %t196, i32 0, i32 21
  %t199 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t198, i64 %t199)
  br label %bb50
bb50:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Landings", ptr %t202, i32 0, i32 22
  store ptr %t204, ptr %l119, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Landings", ptr %t205, i32 0, i32 15
  %t208 = load i64, ptr %l7, !tbaa !24
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t208)
  store i64 %t211, ptr %l123
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l119, !tbaa !29
  %t213 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l12, !tbaa !24
  br label %bb28
bb54:
  br label %bb55
bb55:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb8
bb56:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elastAfter(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l48 = alloca i64
  %l50 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Landings", ptr %t53, i32 0, i32 13
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Landings", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l40, !tbaa !27
  %t64 = load i64, ptr %l1, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i64, ptr %t67, i64 %t64
  %t69 = load i64, ptr %t68, !tbaa !34
  %t70 = load i64, ptr %l38, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb13, label %bb14
bb13:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Landings", ptr %t74, i32 0, i32 14
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t76, i64 %t77)
  store i64 %t80, ptr %l48
  br label %bb15
bb14:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb16
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Landings", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i64, ptr %t88, i64 %t85
  %t90 = load i64, ptr %t89, !tbaa !34
  %t91 = load i64, ptr %l48, !tbaa !24
  %t93 = icmp ne i64 %t91, %t90
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb8
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"compiler/typed:landState"
  %l7 = alloca %"compiler/typed:landState"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l28 = alloca %"compiler/typed:landState"
  %l31 = alloca i64
  %l34 = alloca %"compiler/typed:landState"
  %l43 = alloca { i64, ptr }
  %l53 = alloca %"compiler/typed:landState"
  %l62 = alloca ptr
  %l71 = alloca %"compiler/typed:landState"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t34)
  store %"compiler/typed:landState" %t36, ptr %l28
  br label %bb8
bb8:
  %t37 = load %"compiler/typed:landState", ptr %l28
  store %"compiler/typed:landState" %t37, ptr %l6
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Landings", ptr %t38, i32 0, i32 6
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %s0, ptr %s0, { i64, ptr } %t51, i1 true)
  store %"compiler/typed:landState" %t53, ptr %l34
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_17d1ac1d0088a46d_f6898a8fba654071)
  unreachable
bb11:
  %t54 = load %"compiler/typed:landState", ptr %l34
  store %"compiler/typed:landState" %t54, ptr %l7
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l11, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t80, ptr %l6)
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t87, ptr %l7)
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t90)
  store %"compiler/typed:landState" %t92, ptr %l53
  br label %bb19
bb19:
  %t93 = load %"compiler/typed:landState", ptr %l53
  store %"compiler/typed:landState" %t93, ptr %l7
  br label %bb20
bb20:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t107, ptr %l6)
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l62, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Match", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_53c662fb23aaf808_98195192fab83824)
  unreachable
bb26:
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Match", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %t122, ptr %t121)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t124, ptr %l7)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t127)
  store %"compiler/typed:landState" %t129, ptr %l71
  br label %bb30
bb30:
  %t130 = load %"compiler/typed:landState", ptr %l71
  store %"compiler/typed:landState" %t130, ptr %l7
  br label %bb31
bb31:
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t131, ptr %l7)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 15
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l16, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 17
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l40
  br label %bb12
bb12:
  %t62 = load i1, ptr %l40, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Landings", ptr %t63, i32 0, i32 15
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i64, ptr %l1, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  %t80 = load i64, ptr %l45, !tbaa !24
  %t82 = icmp eq i64 %t80, %t79
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Landings", ptr %t85, i32 0, i32 16
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l57, !tbaa !27
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i64, ptr %t99, i64 %t96
  %t101 = load i64, ptr %t100, !tbaa !34
  %t102 = load i64, ptr %l55, !tbaa !24
  %t104 = icmp eq i64 %t102, %t101
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l51, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erenewed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Landings", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l23, !tbaa !24
  store i64 %t47, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l7, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Landings", ptr %t67, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t80 = icmp eq i64 %t76, %a1
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 6
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = load i64, ptr %l7, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i1, ptr %t89, i64 %t86
  store i1 false, ptr %t90, !tbaa !31
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb13
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Landings", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t19
  %t24 = load i64, ptr %t23, !tbaa !34
  %t30 = icmp eq i64 %t24, %a1
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca i1
  %l87 = alloca i64
  %l91 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:LastUses", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LastUses", ptr %t55, i32 0, i32 8
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l47
  br label %bb12
bb12:
  %t62 = load i64, ptr %l47, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb37
bb14:
  br label %bb15
bb15:
  %t69 = add i64 %a1, 1
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb21
bb18:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l61, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t104 = load i64, ptr %l61, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  br label %bb21
bb21:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb23, label %bb24
bb23:
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l15, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp ne i64 %t124, %t125
  br i1 %t128, label %bb26, label %bb27
bb26:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/typed:LastUses", ptr %t130, i32 0, i32 9
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = sub i64 %t133, 1
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t132, i64 %t135)
  store i64 %t138, ptr %l87
  br label %bb28
bb27:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb30
bb28:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:LastUses", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l91
  br label %bb29
bb29:
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = load i64, ptr %l91, !tbaa !24
  %t148 = icmp eq i64 %t146, %t147
  store i1 %t148, ptr %l82, !tbaa !21
  br label %bb30
bb30:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:LastUses", ptr %t151, i32 0, i32 8
  %t154 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t153, i64 %t154, i64 -1)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb22
bb36:
  br label %bb37
bb37:
  %t161 = load i64, ptr %l7, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l7, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp sge i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LastUses", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp slt i64 %t9, %t13
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:LastUses", ptr %t19, i32 0, i32 2
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t32 = icmp slt i64 %t30, 0
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l11, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:LastUses", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l19, !tbaa !27
  %t39 = load i32, ptr %l1, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:LastUses", ptr %t42, i32 0, i32 4
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i64, ptr %t49, i64 %t41
  store i64 %t45, ptr %t50, !tbaa !34
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca ptr
  %l137 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l211 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t6 = load ptr, ptr %l33, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l33, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t15 = load ptr, ptr %l37, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l37, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l38, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb170
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t24 = load ptr, ptr %l41, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l41, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l42, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t39 = load ptr, ptr %l47, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l47, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l48, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t54 = load ptr, ptr %l53, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l53, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb170
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l61, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l62, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l62, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb170
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t96 = load ptr, ptr %l71, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l71, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l72, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LastUses", ptr %t110, i32 0, i32 3
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LastUses", ptr %t115, i32 0, i32 6
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb41
bb41:
  %t120 = load i64, ptr %l81, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  store ptr %t126, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t127 = load ptr, ptr %l84, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l84, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 5}
  %t133 = icmp eq i64 %t131, 2
  store i1 %t133, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l85, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { ptr }, ptr %t137, i32 0, i32 0
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l8, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_198aad80d0550ab5_c06608159f163401)
  unreachable
bb53:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  br label %bb54
bb54:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i64, ptr %l5, !tbaa !24
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  br label %bb55
bb55:
  br label %bb170
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l99, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 7
  store i1 %t166, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb67
bb61:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LastUses", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/typed:LastUses", ptr %t179, i32 0, i32 6
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l109
  br label %bb62
bb62:
  %t184 = load i64, ptr %l109, !tbaa !24
  store i64 %t184, ptr %l11, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %t185, ptr %t186)
  br label %bb63
bb63:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Make", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t189, { i64, ptr } %t193)
  br label %bb64
bb64:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l9, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Make", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  br label %bb65
bb65:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t203, i64 %t204, i64 %t205)
  br label %bb66
bb66:
  br label %bb170
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l121, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 8
  store i1 %t216, ptr %l122, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l122, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Collect", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t228)
  br label %bb73
bb73:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l130, !tbaa !29
  %t232 = load ptr, ptr %l130, !tbaa !29
  %t233 = getelementptr %"compiler/typed:LastUses", ptr %t232, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  %t236 = add i64 %t234, 1
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t239 = getelementptr %"compiler/typed:LastUses", ptr %t238, i32 0, i32 4
  store i64 %t236, ptr %t239, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Collect", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb74
bb74:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l137, !tbaa !29
  %t249 = load ptr, ptr %l137, !tbaa !29
  %t250 = getelementptr %"compiler/typed:LastUses", ptr %t249, i32 0, i32 4
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = sub i64 %t251, 1
  %t255 = load ptr, ptr %l137, !tbaa !29
  %t256 = getelementptr %"compiler/typed:LastUses", ptr %t255, i32 0, i32 4
  store i64 %t253, ptr %t256, !tbaa !24
  br label %bb170
bb75:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t258 = load ptr, ptr %l140, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb76, label %bb77
bb76:
  %t261 = load ptr, ptr %l140, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 18}
  %t264 = icmp eq i64 %t262, 9
  store i1 %t264, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t265 = load i1, ptr %l141, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [5 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t268, i32 0, i32 4
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l13, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t273)
  br label %bb81
bb81:
  br label %bb170
bb82:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb83, label %bb84
bb83:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 10
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb84
bb84:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb85, label %bb86
bb85:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 2
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l14, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Slice", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t291, ptr %t295)
  br label %bb88
bb88:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l14, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Slice", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t298, ptr %t302)
  br label %bb89
bb89:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l14, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Slice", ptr %t307, i32 0, i32 2
  %t310 = load ptr, ptr %t309, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t306, ptr %t310)
  br label %bb90
bb90:
  br label %bb170
bb91:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t315 = load ptr, ptr %l165, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb92, label %bb93
bb92:
  %t318 = load ptr, ptr %l165, !tbaa !29
  %t319 = load i64, ptr %t318, !range !{i64 0, i64 18}
  %t321 = icmp eq i64 %t319, 11
  store i1 %t321, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t322 = load i1, ptr %l166, !tbaa !21
  br i1 %t322, label %bb94, label %bb95
bb94:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t325, i32 0, i32 2
  %t327 = load ptr, ptr %t326
  store ptr %t327, ptr %l15, !tbaa !29
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Cond", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t333)
  br label %bb97
bb97:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l15, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Cond", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t337, ptr %t341)
  br label %bb98
bb98:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l15, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Cond", ptr %t345, i32 0, i32 2
  %t348 = load ptr, ptr %t347, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t348)
  br label %bb99
bb99:
  br label %bb170
bb100:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t353 = load ptr, ptr %l182, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb101, label %bb102
bb101:
  %t356 = load ptr, ptr %l182, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 18}
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l183, !tbaa !21
  br label %bb102
bb102:
  %t360 = load i1, ptr %l183, !tbaa !21
  br i1 %t360, label %bb103, label %bb104
bb103:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l16, !tbaa !29
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l16, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t367, { i64, ptr } %t371)
  br label %bb106
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l16, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Seq", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t374, ptr %t378)
  br label %bb107
bb107:
  br label %bb170
bb108:
  %t381 = load ptr, ptr %l1, !tbaa !29
  store ptr %t381, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t382 = load ptr, ptr %l194, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb109, label %bb110
bb109:
  %t385 = load ptr, ptr %l194, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 18}
  %t388 = icmp eq i64 %t386, 13
  store i1 %t388, ptr %l195, !tbaa !21
  br label %bb110
bb110:
  %t389 = load i1, ptr %l195, !tbaa !21
  br i1 %t389, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t392, i32 0, i32 2
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l17, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l17, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t396, { i64, ptr } %t400)
  br label %bb114
bb114:
  %t403 = load ptr, ptr %l17, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Match", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t408 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  store i64 %t410, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t412 = load i64, ptr %l19, !tbaa !24
  %t413 = load i64, ptr %l20, !tbaa !24
  %t416 = icmp slt i64 %t412, %t413
  %t418 = xor i1 %t416, true
  br i1 %t418, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t420 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t420, ptr %l211, !tbaa !27
  %t421 = load i64, ptr %l19, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr ptr, ptr %t424, i64 %t421
  %t426 = load ptr, ptr %t425, !tbaa !39
  %t428 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t428, ptr %t426)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t432 = load i64, ptr %l19, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l19, !tbaa !24
  br label %bb115
bb121:
  %t436 = load ptr, ptr %l17, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Match", ptr %t436, i32 0, i32 2
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = icmp eq ptr %t439, null
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb122, label %bb123
bb122:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l222, !tbaa !29
  %t446 = load ptr, ptr %l17, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Match", ptr %t446, i32 0, i32 2
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = icmp eq ptr %t449, null
  br i1 %t451, label %bb124, label %bb125
bb123:
  br label %bb128
bb124:
  call void @__olang_check_failed(ptr @olang_loc_28655f8a56cf669d_dc60f62ebe04c639)
  unreachable
bb125:
  br label %bb126
bb126:
  %t453 = load ptr, ptr %l17, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Match", ptr %t453, i32 0, i32 2
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t457 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t457, ptr %t456)
  br label %bb127
bb127:
  br label %bb128
bb128:
  br label %bb170
bb129:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t460 = load ptr, ptr %l228, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb130, label %bb131
bb130:
  %t463 = load ptr, ptr %l228, !tbaa !29
  %t464 = load i64, ptr %t463, !range !{i64 0, i64 18}
  %t466 = icmp eq i64 %t464, 14
  store i1 %t466, ptr %l229, !tbaa !21
  br label %bb131
bb131:
  %t467 = load i1, ptr %l229, !tbaa !21
  br i1 %t467, label %bb132, label %bb133
bb132:
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t470, i32 0, i32 2
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l22, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Try", ptr %t475, i32 0, i32 0
  %t478 = load ptr, ptr %t477, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t474, ptr %t478)
  br label %bb135
bb135:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l22, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Try", ptr %t482, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t481, { i64, ptr } %t485)
  br label %bb136
bb136:
  br label %bb170
bb137:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t489 = load ptr, ptr %l240, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb138, label %bb139
bb138:
  %t492 = load ptr, ptr %l240, !tbaa !29
  %t493 = load i64, ptr %t492, !range !{i64 0, i64 18}
  %t495 = icmp eq i64 %t493, 15
  store i1 %t495, ptr %l241, !tbaa !21
  br label %bb139
bb139:
  %t496 = load i1, ptr %l241, !tbaa !21
  br i1 %t496, label %bb140, label %bb141
bb140:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t499, i32 0, i32 2
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l23, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %t503, ptr %t504)
  br label %bb143
bb143:
  br label %bb170
bb144:
  %t507 = load ptr, ptr %l1, !tbaa !29
  store ptr %t507, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t508 = load ptr, ptr %l248, !tbaa !29
  %t509 = icmp ne ptr %t508, null
  br i1 %t509, label %bb145, label %bb146
bb145:
  %t511 = load ptr, ptr %l248, !tbaa !29
  %t512 = load i64, ptr %t511, !range !{i64 0, i64 18}
  %t514 = icmp eq i64 %t512, 16
  store i1 %t514, ptr %l249, !tbaa !21
  br label %bb146
bb146:
  %t515 = load i1, ptr %l249, !tbaa !21
  br i1 %t515, label %bb147, label %bb148
bb147:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t518, i32 0, i32 2
  %t520 = load ptr, ptr %t519
  store ptr %t520, ptr %l24, !tbaa !29
  br label %bb149
bb148:
  br label %bb162
bb149:
  %t522 = load ptr, ptr %l24, !tbaa !29
  %t524 = getelementptr %"compiler/typed:Text", ptr %t522, i32 0, i32 0
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t527, 0
  store i64 %t529, ptr %l27, !tbaa !24
  br label %bb150
bb150:
  %t531 = load i64, ptr %l26, !tbaa !24
  %t532 = load i64, ptr %l27, !tbaa !24
  %t535 = icmp slt i64 %t531, %t532
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb151, label %bb152
bb151:
  br label %bb161
bb152:
  br label %bb153
bb153:
  %t539 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t539, ptr %l262, !tbaa !27
  %t540 = load i64, ptr %l26, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr ptr, ptr %t543, i64 %t540
  %t545 = load ptr, ptr %t544, !tbaa !39
  store ptr %t545, ptr %l28, !tbaa !29
  %t547 = load ptr, ptr %l28, !tbaa !29
  store ptr %t547, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t548 = load ptr, ptr %l265, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb154, label %bb155
bb154:
  %t551 = load ptr, ptr %l265, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 2}
  %t554 = icmp eq i64 %t552, 1
  store i1 %t554, ptr %l266, !tbaa !21
  br label %bb155
bb155:
  %t555 = load i1, ptr %l266, !tbaa !21
  br i1 %t555, label %bb156, label %bb157
bb156:
  %t556 = load ptr, ptr %l28, !tbaa !29
  %t558 = getelementptr { i64, [2 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { ptr }, ptr %t558, i32 0, i32 0
  %t560 = load ptr, ptr %t559
  %t562 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t562, ptr %t560)
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t567 = load i64, ptr %l26, !tbaa !24
  %t569 = add i64 %t567, 1
  store i64 %t569, ptr %l26, !tbaa !24
  br label %bb150
bb161:
  br label %bb170
bb162:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t572 = load ptr, ptr %l276, !tbaa !29
  %t573 = icmp ne ptr %t572, null
  br i1 %t573, label %bb163, label %bb164
bb163:
  %t575 = load ptr, ptr %l276, !tbaa !29
  %t576 = load i64, ptr %t575, !range !{i64 0, i64 18}
  %t578 = icmp eq i64 %t576, 17
  store i1 %t578, ptr %l277, !tbaa !21
  br label %bb164
bb164:
  %t579 = load i1, ptr %l277, !tbaa !21
  br i1 %t579, label %bb165, label %bb166
bb165:
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t580, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t582, i32 0, i32 2
  %t584 = load ptr, ptr %t583
  store ptr %t584, ptr %l30, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t587)
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_d36f57f073c6a2ff_232866ca740484ab)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 3}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 3}
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_faea1712f2053751_ed9fc9ee56afb56d)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:LocalUses", ptr %t5, i32 0, i32 24
  %t8 = load i32, ptr %t7, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Block", ptr %t11, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 24
  store i32 %t14, ptr %t17, !tbaa !23
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %t43, ptr %t41)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = getelementptr %"compiler/typed:LocalUses", ptr %t51, i32 0, i32 24
  store i32 %t52, ptr %t55, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4, i1 true)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LocalUses", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t9, i64 %t10, i1 true)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i64 %t35, ptr %l23
  br label %bb10
bb10:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb50
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l24, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 10
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Slice", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t52, ptr %t56)
  store i64 %t59, ptr %l33
  br label %bb17
bb17:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb50
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Promote", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t76, ptr %t80)
  store i64 %t83, ptr %l43
  br label %bb24
bb24:
  %t84 = load i64, ptr %l43, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb50
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t86 = load ptr, ptr %l44, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 17
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l52
  br label %bb31
bb31:
  %t105 = load i64, ptr %l52, !tbaa !24
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb50
bb32:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t107 = load ptr, ptr %l53, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 9
  store i1 %t113, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t114 = load i1, ptr %l54, !tbaa !21
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t117, i32 0, i32 2
  %t119 = load i32, ptr %t118, !range !{i32 0, i32 52}
  store i32 %t119, ptr %l6
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t123, i32 0, i32 4
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t127 = load i32, ptr %l6, !range !{i32 0, i32 52}
  %t129 = trunc i64 20 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = icmp eq i64 %t134, 1
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t138 = load i1, ptr %l63, !tbaa !21
  br i1 %t138, label %bb41, label %bb42
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t140, ptr %l69, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 0
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t147 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t139, ptr %t144)
  store i64 %t147, ptr %l71
  br label %bb43
bb42:
  store i64 -1, ptr %l67, !tbaa !24
  br label %bb44
bb43:
  %t148 = load i64, ptr %l71, !tbaa !24
  store i64 %t148, ptr %l67, !tbaa !24
  br label %bb44
bb44:
  %t149 = load i64, ptr %l67, !tbaa !24
  store i64 %t149, ptr %l8, !tbaa !24
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ea76fa4e8d5c92b6_ce360b1ee865cf5a)
  unreachable
bb50:
  %t150 = load i64, ptr %l8, !tbaa !24
  store i64 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l15 = alloca { i64, ptr }
  %t43 = alloca { i64, [1 x i64] }, align 8
  %t57 = alloca { i64, [1 x i64] }, align 8
  %t66 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb27
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 52}
  %t25 = trunc i64 20 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t28, ptr %t29, { i64, [1 x i64] } %a3)
  br label %bb8
bb8:
  br label %bb25
bb9:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 52}
  %t37 = trunc i64 42 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i32 0, i32 0
  store i64 5, ptr %t44
  %t45 = load { i64, [1 x i64] }, ptr %t43
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t40, ptr %t41, { i64, [1 x i64] } %t45)
  br label %bb13
bb13:
  br label %bb25
bb14:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 52}
  %t51 = trunc i64 30 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [1 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t59 = load { i64, [1 x i64] }, ptr %t57
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t54, ptr %t55, { i64, [1 x i64] } %t59)
  br label %bb18
bb18:
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t66
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t64, { i64, [1 x i64] } %t68)
  br label %bb23
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dac0899521d00a27_f5966ad5b7471ec3)
  unreachable
bb25:
  br label %bb26
bb26:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb1
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca ptr
  %l61 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = call ptr @__olang_scope_of(ptr %t27, ptr null)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t34 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t31, ptr %t32, i32 %t26)
  store i64 %t34, ptr %l23
  br label %bb6
bb6:
  %t35 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t38 = and i64 %t36, %t35
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  br label %bb9
bb8:
  store ptr null, ptr %l27, !tbaa !29
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %l10, !tbaa !29
  br label %bb29
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t47 = load ptr, ptr %l30, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 2
  store i1 %t53, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l6, !tbaa !23
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb15
bb14:
  br label %bb24
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load i32, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = call ptr @__olang_scope_of(ptr %t72, ptr null)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t79 = call i1 @compiler_2ftyped_2escalarType(ptr %t76, ptr %t77, i32 %t71)
  store i1 %t79, ptr %l42
  br label %bb16
bb16:
  %t80 = load i1, ptr %l42, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  %t87 = load i32, ptr %l6, !tbaa !23
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = call ptr @__olang_scope_of(ptr %t88, ptr null)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t92, ptr %t93, i32 %t87)
  store i64 %t95, ptr %l49
  br label %bb19
bb18:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb20
bb19:
  %t96 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t97 = load i64, ptr %l49, !tbaa !24
  %t99 = and i64 %t97, %t96
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l44, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load ptr, ptr %l7, !tbaa !29
  store ptr %t104, ptr %l53, !tbaa !29
  br label %bb23
bb22:
  store ptr null, ptr %l53, !tbaa !29
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l53, !tbaa !29
  store ptr %t107, ptr %l10, !tbaa !29
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_93af16bb2b9103f6_23d1e52eae2906e2)
  unreachable
bb29:
  %t108 = load ptr, ptr %l10, !tbaa !29
  store ptr %t108, ptr %l8, !tbaa !29
  %t109 = load ptr, ptr %l8, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  br i1 %t111, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t118 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i64 %t118, ptr %l61
  br label %bb33
bb33:
  %t119 = load i64, ptr %l61, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  br label %bb37
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:LocalUses", ptr %t129, i32 0, i32 5
  %t132 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t131, i64 %t132, i1 true)
  br label %bb38
bb38:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:LocalUses", ptr %t135, i32 0, i32 15
  %t138 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t137, i64 %t138)
  br label %bb39
bb39:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/typed:LocalUses", ptr %t141, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t143, i64 %a2)
  br label %bb40
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/typed:LocalUses", ptr %t147, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t149, i64 %a3)
  br label %bb41
bb41:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %t30, i1 false)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 6
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:LocalUses", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call ptr @__olang_scope_of(ptr %t42, ptr null)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t44 to ptr
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t46, ptr %t47, i32 %t41)
  store i64 %t49, ptr %l27
  br label %bb11
bb11:
  %t50 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t51 = load i64, ptr %l27, !tbaa !24
  %t53 = and i64 %t51, %t50
  %t55 = icmp ne i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l4, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  br label %bb14
bb13:
  store ptr null, ptr %l31, !tbaa !29
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l31, !tbaa !29
  store ptr %t60, ptr %l16, !tbaa !29
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store ptr null, ptr %l16, !tbaa !29
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_43639d7480e3f1b2_6970610da298d01e)
  unreachable
bb20:
  %t61 = load ptr, ptr %l16, !tbaa !29
  store ptr %t61, ptr %l7, !tbaa !29
  br label %bb36
bb21:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 5
  store i1 %t69, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t70 = load i1, ptr %l35, !tbaa !21
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l5, !tbaa !23
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l43, !tbaa !29
  %t87 = load i32, ptr %l5, !tbaa !23
  %t88 = load ptr, ptr %l43, !tbaa !29
  %t89 = call ptr @__olang_scope_of(ptr %t88, ptr null)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l43, !tbaa !29
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t92, ptr %t93, i32 %t87)
  store i64 %t95, ptr %l46
  br label %bb27
bb27:
  %t96 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t97 = load i64, ptr %l46, !tbaa !24
  %t99 = and i64 %t97, %t96
  %t101 = icmp ne i64 %t99, 0
  br i1 %t101, label %bb28, label %bb29
bb28:
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Promote", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l50, !tbaa !29
  br label %bb30
bb29:
  store ptr null, ptr %l50, !tbaa !29
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l50, !tbaa !29
  store ptr %t109, ptr %l7, !tbaa !29
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_13022d0d55ff9b33_d1cf61a4f0453a9f)
  unreachable
bb36:
  %t110 = load ptr, ptr %l7, !tbaa !29
  store ptr %t110, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1)
  unreachable
bb37:
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eFind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca { i64, [1 x i64] }
  %t14 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t3, ptr %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Plan", ptr %t7, i32 0, i32 8
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  store { i64, [1 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 0
  store i64 7, ptr %t15
  %t17 = insertvalue { i64 } undef, i64 %t13, 0
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  store { i64 } %t17, ptr %t18
  %t19 = load { i64, [1 x i64] }, ptr %t14
  store { i64, [1 x i64] } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t8, i32 0, i32 11
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = add i64 %t13, 1
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t14, ptr %t19, !tbaa !34
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 10
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t26
  store i64 %t29, ptr %t34, !tbaa !34
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i64 %t50
  %t55 = load { i64, [1 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t57, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t59, { i64, [1 x i64] } %t55)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t36 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 10
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t36
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t40, i32 0, i32 11
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t52 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42, i64 %t49)
  store { i64, [1 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  %t53 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 17}
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l6
  br label %bb79
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 17}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb43
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 17}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb43
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb43
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l56, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 17}
  %t130 = icmp eq i64 %t128, 9
  store i1 %t130, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l57, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb43
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l62, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 17}
  %t145 = icmp eq i64 %t143, 10
  store i1 %t145, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l63, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l2
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l6
  br label %bb79
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 17}
  %t162 = icmp eq i64 %t160, 8
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t170 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t170, ptr %l6
  br label %bb79
bb50:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t173 = load ptr, ptr %l76, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l76, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 17}
  %t179 = icmp eq i64 %t177, 11
  store i1 %t179, ptr %l77, !tbaa !21
  br label %bb52
bb52:
  %t180 = load i1, ptr %l77, !tbaa !21
  br i1 %t180, label %bb53, label %bb54
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr { i64, [3 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr }, ptr %t183, i32 0, i32 0
  %t185 = load %"compiler/source:Span", ptr %t184
  store %"compiler/source:Span" %t185, ptr %l4
  br label %bb71
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 17}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb71
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb71
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb71
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t247 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t247, ptr %l6
  br label %bb79
bb72:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t250 = load ptr, ptr %l107, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l107, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 17}
  %t256 = icmp eq i64 %t254, 16
  store i1 %t256, ptr %l108, !tbaa !21
  br label %bb74
bb74:
  %t257 = load i1, ptr %l108, !tbaa !21
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 0
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l5
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t264 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t264, ptr %l6
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba)
  unreachable
bb79:
  %t266 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t266, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eAcross(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 10
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i32 -1, ptr %l12, !tbaa !23
  br label %bb9
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Versions", ptr %t18, i32 0, i32 11
  store ptr %t20, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Versions", ptr %t22, i32 0, i32 3
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = mul i64 %t27, %t28
  %t33 = add i64 %t29, %a2
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t33)
  store i64 %t36, ptr %l22
  br label %bb8
bb8:
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = trunc i64 %t37 to i32
  store i32 %t38, ptr %l12, !tbaa !23
  br label %bb9
bb9:
  %t41 = load i32, ptr %l12, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %t2, i64 %a1)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v1, ptr %t9, i64 %t10, i64 %a2, ptr %a3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i1
  %l42 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v1, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Versions", ptr %t3, i32 0, i32 9
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t5, i64 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Versions", ptr %t13, i32 0, i32 3
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 9
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_He64c344d05691a582e6fe54d21a34702(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  %t26 = extractvalue { i32, ptr } %t25, 1
  %t27 = extractvalue { i32, ptr } %t25, 0
  store i32 %t27, ptr %l22
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb8, label %ok.29, !prof !99
ok.29:
  store ptr %t26, ptr %l21
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l21, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  br label %bb11
bb8:
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = icmp eq i32 %t31, 65536
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_7e4ec1e19232cd88_f10154fa6134f764)
  unreachable
bb10:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a0166decbffe4964_9ac2fce80458edf8)
  unreachable
bb11:
  %t34 = load ptr, ptr %l17, !tbaa !29
  store ptr %t34, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l24, !tbaa !24
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb13
bb13:
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l26, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t45, i64 %t46)
  store i64 %t49, ptr %l31
  br label %bb17
bb17:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Versions", ptr %t55, i32 0, i32 11
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t66)
  store i64 %t69, ptr %l42
  br label %bb20
bb20:
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = icmp sgt i64 %t70, -2
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l34, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t75 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t74, i64 %t75)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb12
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  store i64 %t4, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Versions", ptr %t10, i32 0, i32 8
  store ptr %t12, ptr %l13, !tbaa !29
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2ftyped_2edefName(i64 %t13, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Versions", ptr %t27, i32 0, i32 8
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i64 @compiler_2ftyped_2edefName(i64 %t30, i64 %t31)
  store i64 %t34, ptr %l24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Versions", ptr %t35, i32 0, i32 3
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l27
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t40, i64 %t41, i64 %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Versions", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 %t46)
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Versions", ptr %t49, i32 0, i32 4
  %t52 = load %"compiler/source:Span", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Versions", ptr %t55, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t57, i32 %a3)
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Versions", ptr %t61, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %t63, ptr %a4)
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Versions", ptr %t67, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t69, i1 %a5)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclassify(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i8
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l99 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Versions", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l23, !tbaa !24
  %t17 = sdiv i64 %t15, %t14
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l32, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l29, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l8, !tbaa !24
  %t65 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t65, ptr %l50
  br label %bb14
bb14:
  %t66 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t66, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l12, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l55, !tbaa !24
  store i64 %t96, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store ptr %l9, ptr %l76, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 11
  %t118 = load i64, ptr %l8, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t126 = add i64 %t122, %t113
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb25
bb25:
  %t130 = load i64, ptr %l84, !tbaa !24
  %t131 = icmp sgt i64 %t130, -2
  br i1 %t131, label %bb26, label %bb27
bb26:
  store i8 49, ptr %l86, !tbaa !22
  br label %bb28
bb27:
  store i8 48, ptr %l86, !tbaa !22
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = load i8, ptr %l86, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %t133, i8 %t134)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l14, !tbaa !24
  br label %bb21
bb31:
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l9)
  store { i64, ptr } %t140, ptr %l90
  br label %bb32
bb32:
  %t141 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t141, ptr %l16, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t145 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %s0, ptr %l2, { i64, ptr } %t142)
  store i1 %t145, ptr %l93
  br label %bb33
bb33:
  %t146 = load i1, ptr %l93, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb34, label %bb35
bb34:
  %t149 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Versions", ptr %t150, i32 0, i32 13
  %t153 = load i64, ptr %t152, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %s0, ptr %l2, { i64, ptr } %t149, i64 %t153)
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l99, !tbaa !29
  %t158 = load ptr, ptr %l99, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Versions", ptr %t158, i32 0, i32 13
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = add i64 %t160, 1
  %t164 = load ptr, ptr %l99, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Versions", ptr %t164, i32 0, i32 13
  store i64 %t162, ptr %t165, !tbaa !24
  br label %bb37
bb37:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Versions", ptr %t166, i32 0, i32 12
  store ptr %t168, ptr %l103, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t172 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %s0, ptr %l2, { i64, ptr } %t169)
  %t173 = extractvalue { i32, i64 } %t172, 1
  %t174 = extractvalue { i32, i64 } %t172, 0
  store i32 %t174, ptr %l108
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb39, label %ok.176, !prof !99
ok.176:
  store i64 %t173, ptr %l107
  br label %bb38
bb38:
  %t177 = load i64, ptr %l107, !tbaa !24
  store i64 %t177, ptr %l104, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb41
bb41:
  %t178 = load ptr, ptr %l103, !tbaa !29
  %t179 = load i64, ptr %l104, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t178, i64 %t179)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb10
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edefine(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t5, %t11
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Versions", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l22, !tbaa !27
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i1, ptr %t24, i64 %t21
  %t26 = load i1, ptr %t25, !tbaa !31
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 20
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l29
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Versions", ptr %t39, i32 0, i32 16
  store ptr %t41, ptr %l32, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Versions", ptr %t42, i32 0, i32 16
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l35
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = sub i64 %t47, 1
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49, i64 %t48)
  store i32 %t51, ptr %l37
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, i64 %t56, i32 %t57, ptr %a3, i1 %a4)
  br label %bb14
bb14:
  br label %ret
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t65 = load i64, ptr %l2, !tbaa !24
  %t69 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eDefOf(ptr %v0, ptr %t60, i64 %t64, i64 %t65)
  store i64 %t69, ptr %l44
  br label %bb16
bb16:
  %t70 = load i64, ptr %l44, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb20
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t75)
  store i1 %t77, ptr %l49
  br label %bb19
bb19:
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Versions", ptr %t80, i32 0, i32 3
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t82)
  store i64 %t84, ptr %l52
  br label %bb24
bb24:
  %t85 = load i64, ptr %l52, !tbaa !24
  store i64 %t85, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb30
bb27:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l59, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb29
bb29:
  %t112 = load i64, ptr %l59, !tbaa !24
  store i64 %t112, ptr %l56, !tbaa !24
  br label %bb30
bb30:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb32, label %bb33
bb32:
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Versions", ptr %t132, i32 0, i32 3
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l80
  br label %bb35
bb35:
  %t139 = load i64, ptr %l2, !tbaa !24
  %t140 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp eq i64 %t140, %t139
  br i1 %t142, label %bb36, label %bb37
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Versions", ptr %t144, i32 0, i32 14
  %t147 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t146, i64 %t147, i64 -2)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb31
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Versions", ptr %t154, i32 0, i32 14
  %t157 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t157, i64 -1)
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Versions", ptr %t160, i32 0, i32 15
  %t163 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i32
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca ptr
  %l76 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l16
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l14, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t11)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Versions", ptr %t13, i32 0, i32 3
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l20
  br label %bb9
bb9:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 17
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l23
  br label %bb10
bb10:
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Versions", ptr %t33, i32 0, i32 17
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t35, i64 %t36)
  store i32 %t39, ptr %l31
  br label %bb15
bb15:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t43 = icmp ne i32 %t41, %a2
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb47
bb17:
  br label %bb18
bb18:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = mul i64 %t45, %t48
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb21:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l45, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l45, !tbaa !24
  store i64 %t81, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t82 = load i64, ptr %l42, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb41
bb27:
  br label %bb28
bb28:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l11, !tbaa !24
  %t101 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t103 = trunc i64 0 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Versions", ptr %t106, i32 0, i32 18
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l70, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 18
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t122)
  store i64 %t125, ptr %l76
  br label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Versions", ptr %t126, i32 0, i32 19
  store ptr %t128, ptr %l83, !tbaa !29
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l86, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l87, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Versions", ptr %t135, i32 0, i32 19
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t142)
  store i64 %t145, ptr %l93
  br label %bb35
bb31:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Versions", ptr %t146, i32 0, i32 14
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l80
  br label %bb32
bb32:
  %t153 = load ptr, ptr %l70, !tbaa !29
  %t154 = load i64, ptr %l76, !tbaa !24
  %t155 = load i64, ptr %l80, !tbaa !24
  %t156 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  store i64 %t156, ptr %l81
  br label %bb33
bb33:
  %t157 = load ptr, ptr %l66, !tbaa !29
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = load i64, ptr %l81, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t157, i64 %t158, i64 %t159)
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Versions", ptr %t160, i32 0, i32 14
  %t163 = load i64, ptr %l11, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l97
  br label %bb36
bb36:
  %t167 = load ptr, ptr %l87, !tbaa !29
  %t168 = load i64, ptr %l93, !tbaa !24
  %t169 = load i64, ptr %l97, !tbaa !24
  %t170 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t167, i64 %t168, i64 %t169)
  store i64 %t170, ptr %l98
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l83, !tbaa !29
  %t172 = load i64, ptr %l86, !tbaa !24
  %t173 = load i64, ptr %l98, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172, i64 %t173)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb25
bb41:
  %t178 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t180 = trunc i64 0 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Versions", ptr %t183, i32 0, i32 18
  %t186 = load i64, ptr %l5, !tbaa !24
  %t187 = load i64, ptr %l3, !tbaa !24
  %t190 = add i64 %t186, %t187
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t185, i64 %t190, i64 0)
  br label %bb44
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Versions", ptr %t193, i32 0, i32 19
  %t196 = load i64, ptr %l5, !tbaa !24
  %t197 = load i64, ptr %l3, !tbaa !24
  %t200 = add i64 %t196, %t197
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t195, i64 %t200, i64 0)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb48
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t205 = sub i64 %t203, 1
  store i64 %t205, ptr %l4, !tbaa !24
  br label %bb11
bb48:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t207)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca ptr
  %l74 = alloca i64
  %l76 = alloca ptr
  %l80 = alloca i64
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l95 = alloca i64
  %l114 = alloca ptr
  %l120 = alloca i64
  %l124 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca i32
  %l151 = alloca i32
  %l152 = alloca i32
  %l161 = alloca i64
  %l164 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i32
  %l190 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t11, ptr %t12)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l32
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 3
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l35
  br label %bb7
bb7:
  %t24 = load i64, ptr %l35, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Versions", ptr %t25, i32 0, i32 17
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l38
  br label %bb8
bb8:
  %t30 = load i64, ptr %l38, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 17
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Block", ptr %t34, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t33, i32 %t37)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb15
bb12:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l51, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l51, !tbaa !24
  store i64 %t70, ptr %l48, !tbaa !24
  br label %bb15
bb15:
  %t71 = load i64, ptr %l48, !tbaa !24
  store i64 %t71, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Versions", ptr %t90, i32 0, i32 18
  store ptr %t92, ptr %l70, !tbaa !29
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb20, label %bb21
bb20:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb22
bb21:
  store i64 -2, ptr %l74, !tbaa !24
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l70, !tbaa !29
  %t100 = load i64, ptr %l74, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  br label %bb23
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Versions", ptr %t101, i32 0, i32 19
  store ptr %t103, ptr %l76, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb24, label %bb25
bb24:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb26
bb25:
  store i64 -2, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l76, !tbaa !29
  %t111 = load i64, ptr %l80, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l9, !tbaa !24
  br label %bb16
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t116)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l84
  br label %bb30
bb30:
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t119, ptr %lp11
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  %t121 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %t121
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %lp11
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v3, ptr %t122, ptr %t123)
  br label %bb32
bb32:
  store i64 0, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l3, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t136 = load i64, ptr %l14, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb38
bb35:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l95, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb37
bb37:
  %t156 = load i64, ptr %l95, !tbaa !24
  store i64 %t156, ptr %l92, !tbaa !24
  br label %bb38
bb38:
  %t157 = load i64, ptr %l92, !tbaa !24
  store i64 %t157, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t166 = load i64, ptr %l12, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l17, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Versions", ptr %t176, i32 0, i32 19
  store ptr %t178, ptr %l114, !tbaa !29
  %t179 = load i64, ptr %l4, !tbaa !24
  %t180 = load i64, ptr %l3, !tbaa !24
  %t182 = add i64 %t180, 1
  %t185 = mul i64 %t179, %t182
  %t186 = load i64, ptr %l17, !tbaa !24
  %t189 = add i64 %t185, %t186
  store i64 %t189, ptr %l120, !tbaa !24
  %t190 = load i64, ptr %l17, !tbaa !24
  %t191 = load i64, ptr %l3, !tbaa !24
  %t194 = icmp eq i64 %t190, %t191
  br i1 %t194, label %bb43, label %bb44
bb43:
  store i64 1, ptr %l124, !tbaa !24
  br label %bb45
bb44:
  store i64 -2, ptr %l124, !tbaa !24
  br label %bb45
bb45:
  %t196 = load ptr, ptr %l114, !tbaa !29
  %t197 = load i64, ptr %l120, !tbaa !24
  %t198 = load i64, ptr %l124, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197, i64 %t198)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t199 = load i64, ptr %l16, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l16, !tbaa !24
  br label %bb39
bb48:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb49
bb49:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l130, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l4, !tbaa !24
  %t213 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s5, ptr %t209, i1 false, i64 %t210)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l133
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s5, ptr %t214, ptr %l133)
  br label %bb51
bb51:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t216, ptr %t217)
  br label %bb52
bb52:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %lp11
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Block", ptr %t222, i32 0, i32 0
  %t225 = load i32, ptr %t224, !tbaa !23
  %t229 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v3, ptr %t220, ptr %t221, i32 %t225)
  store i64 %t229, ptr %l141
  br label %bb53
bb53:
  %t230 = load i64, ptr %l141, !tbaa !24
  %t231 = icmp eq i64 %t230, 0
  br i1 %t231, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb57:
  br label %bb31
bb58:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l143, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l4, !tbaa !24
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s0, ptr %t234, i1 true, i64 %t235)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l146
  br label %bb59
bb59:
  %t239 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t239, ptr %l146)
  br label %bb60
bb60:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Versions", ptr %t241, i32 0, i32 17
  %t245 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t243)
  %t246 = extractvalue { i32, i32 } %t245, 1
  %t247 = extractvalue { i32, i32 } %t245, 0
  store i32 %t247, ptr %l152
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb62, label %ok.249, !prof !99
ok.249:
  store i32 %t246, ptr %l151
  br label %bb61
bb61:
  %t250 = load i32, ptr %l151, !tbaa !23
  store i32 %t250, ptr %l148, !tbaa !23
  br label %bb69
bb62:
  %t251 = load i32, ptr %l152, !tbaa !23
  %t252 = icmp eq i32 %t251, 65536
  br i1 %t252, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78)
  unreachable
bb64:
  %t254 = load i32, ptr %l152, !tbaa !23
  %t255 = icmp eq i32 %t254, 65537
  br i1 %t255, label %bb65, label %bb66
bb65:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f658218d2a233859_f81a26e56b3c591d)
  unreachable
bb66:
  %t257 = load i32, ptr %l152, !tbaa !23
  %t258 = icmp eq i32 %t257, 65538
  br i1 %t258, label %bb67, label %bb68
bb67:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4c95fac740fe18b9_da00c3dfb70c298d)
  unreachable
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633)
  unreachable
bb69:
  store i64 0, ptr %l18, !tbaa !24
  %t260 = load i64, ptr %l3, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l19, !tbaa !24
  %t265 = load i64, ptr %l18, !tbaa !24
  %t268 = icmp sgt i64 %t264, %t265
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load i64, ptr %l20, !tbaa !24
  %t272 = icmp sgt i64 %t270, 0
  br i1 %t272, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb75
bb72:
  %t274 = load i64, ptr %l19, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t278 = sub i64 %t274, %t275
  %t279 = load i64, ptr %l20, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t284 = sub i64 %t282, 1
  %t285 = load i64, ptr %l20, !tbaa !24
  %t288 = sdiv i64 %t284, %t285
  store i64 %t288, ptr %l164, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb74
bb74:
  %t290 = load i64, ptr %l164, !tbaa !24
  store i64 %t290, ptr %l161, !tbaa !24
  br label %bb75
bb75:
  %t291 = load i64, ptr %l161, !tbaa !24
  store i64 %t291, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  %t292 = load i64, ptr %l22, !tbaa !24
  %t293 = load i64, ptr %l21, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb77, label %bb78
bb77:
  br label %bb99
bb78:
  br label %bb79
bb79:
  %t300 = load i64, ptr %l18, !tbaa !24
  %t301 = load i64, ptr %l22, !tbaa !24
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = mul i64 %t301, %t302
  %t308 = add i64 %t300, %t305
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Versions", ptr %t310, i32 0, i32 18
  %t314 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t312)
  %t315 = extractvalue { i32, i64 } %t314, 1
  %t316 = extractvalue { i32, i64 } %t314, 0
  store i32 %t316, ptr %l186
  %t317 = icmp ne i32 %t316, 0
  br i1 %t317, label %bb81, label %ok.318, !prof !99
ok.318:
  store i64 %t315, ptr %l185
  br label %bb80
bb80:
  %t319 = load i64, ptr %l185, !tbaa !24
  store i64 %t319, ptr %l182, !tbaa !24
  br label %bb88
bb81:
  %t320 = load i32, ptr %l186, !tbaa !23
  %t321 = icmp eq i32 %t320, 65536
  br i1 %t321, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14)
  unreachable
bb83:
  %t323 = load i32, ptr %l186, !tbaa !23
  %t324 = icmp eq i32 %t323, 65537
  br i1 %t324, label %bb84, label %bb85
bb84:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69)
  unreachable
bb85:
  %t326 = load i32, ptr %l186, !tbaa !23
  %t327 = icmp eq i32 %t326, 65538
  br i1 %t327, label %bb86, label %bb87
bb86:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cb0f3499142fc19d_d94490f94af5f129)
  unreachable
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf)
  unreachable
bb88:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Versions", ptr %t329, i32 0, i32 19
  %t333 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t331)
  %t334 = extractvalue { i32, i64 } %t333, 1
  %t335 = extractvalue { i32, i64 } %t333, 0
  store i32 %t335, ptr %l194
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb90, label %ok.337, !prof !99
ok.337:
  store i64 %t334, ptr %l193
  br label %bb89
bb89:
  %t338 = load i64, ptr %l193, !tbaa !24
  store i64 %t338, ptr %l190, !tbaa !24
  br label %bb97
bb90:
  %t339 = load i32, ptr %l194, !tbaa !23
  %t340 = icmp eq i32 %t339, 65536
  br i1 %t340, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_14162ea47c0c801c_ce4205068f01e790)
  unreachable
bb92:
  %t342 = load i32, ptr %l194, !tbaa !23
  %t343 = icmp eq i32 %t342, 65537
  br i1 %t343, label %bb93, label %bb94
bb93:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a93f600a1cb39be1_ee16d2dfcadba585)
  unreachable
bb94:
  %t345 = load i32, ptr %l194, !tbaa !23
  %t346 = icmp eq i32 %t345, 65538
  br i1 %t346, label %bb95, label %bb96
bb95:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da)
  unreachable
bb96:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8726c5b979482c78_cdee9de0701e13e4)
  unreachable
bb97:
  br label %bb98
bb98:
  %t348 = load i64, ptr %l22, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l22, !tbaa !24
  br label %bb76
bb99:
  %t352 = load ptr, ptr %lp11
  %t353 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t352
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca ptr
  %l36 = alloca i64
  %l46 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l28
  br label %bb8
bb8:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l6
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l30
  br label %bb9
bb9:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l7
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Versions", ptr %t42, i32 0, i32 20
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  store ptr %l7, ptr %l34, !tbaa !29
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t50, ptr %l36
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t51 = load i64, ptr %l36, !tbaa !24
  %t52 = sub i64 %t51, 1
  %t53 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %t53, i64 %t52, i64 1)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l46, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l11, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t80, ptr %l6)
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb20
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t87, ptr %l7)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t90)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l56
  br label %bb22
bb22:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l7
  br label %bb23
bb23:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l9, !tbaa !24
  br label %bb15
bb24:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t107, ptr %l6)
  br label %bb27
bb26:
  br label %bb34
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l65, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Match", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_456f0c0b74db68d5_29242d1724c8a7c1)
  unreachable
bb29:
  br label %bb30
bb30:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Match", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t122, ptr %t121)
  br label %bb31
bb31:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t124, ptr %l7)
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t127)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l74
  br label %bb33
bb33:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l7
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t131, ptr %l7)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb4
bb4:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l19, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l16, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Versions", ptr %t58, i32 0, i32 14
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %a1, i64 %t63)
  store i64 %t66, ptr %l42
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l38, !tbaa !29
  %t68 = load i64, ptr %l39, !tbaa !24
  %t69 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t68, i64 %t69)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l6, !tbaa !24
  br label %bb11
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eSettle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l54 = alloca i1
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca i64
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 1
  store i1 %t10, ptr %l3, !tbaa !21
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:ViewWalk", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  store ptr %t17, ptr %l23, !tbaa !29
  %t18 = load ptr, ptr %l23, !tbaa !29
  %t19 = call ptr @__olang_scope_of(ptr %t18, ptr null)
  %t20 = ptrtoint ptr %t19 to i64
  %t22 = inttoptr i64 %t20 to ptr
  %t23 = load ptr, ptr %l23, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %t22, ptr %t23)
  store i64 %t24, ptr %l25
  br label %bb1
bb1:
  %t25 = load i64, ptr %l25, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb4:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l32, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb6
bb6:
  %t52 = load i64, ptr %l32, !tbaa !24
  store i64 %t52, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i1, ptr %l3, !tbaa !21
  %t80 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i64 %t74, i1 %t75)
  store i1 %t80, ptr %l54
  br label %bb12
bb12:
  %t81 = load i1, ptr %l54, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 9
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l60
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = load ptr, ptr %l60, !tbaa !29
  %t94 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i64 %t94, ptr %l61
  br label %bb17
bb17:
  %t95 = load i64, ptr %l61, !tbaa !24
  store i64 %t95, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:LocalUses", ptr %t96, i32 0, i32 10
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t98)
  store i64 %t100, ptr %l64
  br label %bb18
bb18:
  %t101 = load i64, ptr %l64, !tbaa !24
  store i64 %t101, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb24
bb21:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l71, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb23
bb23:
  %t128 = load i64, ptr %l71, !tbaa !24
  store i64 %t128, ptr %l68, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t130 = load i64, ptr %l15, !tbaa !24
  %t131 = load i64, ptr %l14, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l13, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l16, !tbaa !24
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/typed:LocalUses", ptr %t148, i32 0, i32 10
  %t151 = load i64, ptr %l16, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l92
  br label %bb29
bb29:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l92, !tbaa !24
  %t158 = icmp eq i64 %t156, %t155
  br i1 %t158, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t160 = load i64, ptr %l10, !tbaa !24
  store i64 %t160, ptr %l95, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l96, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/typed:LocalUses", ptr %t162, i32 0, i32 11
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %s6, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l100
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t169 = load ptr, ptr %l100, !tbaa !29
  %t170 = load ptr, ptr %l96, !tbaa !29
  %t172 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %s6, ptr %t170, ptr %t169)
  store i64 %t172, ptr %l102
  br label %bb33
bb33:
  %t173 = load i64, ptr %l95, !tbaa !24
  %t174 = load i64, ptr %l102, !tbaa !24
  %t175 = or i64 %t173, %t174
  store i64 %t175, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l15, !tbaa !24
  br label %bb25
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l9, !tbaa !24
  %t187 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %a2, i64 %t186, i64 %t187)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t191 = load i64, ptr %l8, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l8, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l25 = alloca i1
  %l29 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l101 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = call ptr @__olang_scope_of(ptr %t8, ptr null)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t12, ptr %t13, i64 %t7)
  store %"compiler/typed:Local" %t15, ptr %l20
  br label %bb1
bb1:
  %t16 = load %"compiler/typed:Local", ptr %l20
  store %"compiler/typed:Local" %t16, ptr %l4
  %t17 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 7}
  store i32 %t18, ptr %l5
  %t20 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t29 = trunc i64 3 to i32
  %t30 = icmp eq i32 %t27, %t29
  %t32 = xor i1 %t30, true
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t34 = load i1, ptr %l25, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t35 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i1, ptr %l29, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/typed:ViewWalk", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l35, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l35, !tbaa !29
  %t51 = call ptr @__olang_scope_of(ptr %t50, ptr null)
  %t52 = ptrtoint ptr %t51 to i64
  %t54 = inttoptr i64 %t52 to ptr
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t57 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t54, ptr %t55, i32 %t49)
  store i1 %t57, ptr %l38
  br label %bb11
bb11:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb15
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:ViewWalk", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l41, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load ptr, ptr %l41, !tbaa !29
  %t66 = call ptr @__olang_scope_of(ptr %t65, ptr null)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t72 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t69, ptr %t70, i32 %t64)
  store i1 %t72, ptr %l44
  br label %bb14
bb14:
  %t73 = load i1, ptr %l44, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 5
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l50
  br label %bb19
bb19:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:LocalUses", ptr %t86, i32 0, i32 2
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l55
  br label %bb22
bb22:
  %t93 = load i1, ptr %l55, !tbaa !21
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb27
bb25:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t95, i32 0, i32 4
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load i1, ptr %l60, !tbaa !21
  store i1 %t102, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:LocalUses", ptr %t105, i32 0, i32 12
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t107)
  store i64 %t109, ptr %l64
  br label %bb31
bb31:
  %t110 = load i64, ptr %l64, !tbaa !24
  store i64 %t110, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb32, label %bb33
bb32:
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb37
bb34:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l71, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb36
bb36:
  %t137 = load i64, ptr %l71, !tbaa !24
  store i64 %t137, ptr %l68, !tbaa !24
  br label %bb37
bb37:
  %t138 = load i64, ptr %l68, !tbaa !24
  store i64 %t138, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb38
bb38:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t147 = load i64, ptr %l6, !tbaa !24
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 12
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t159, i64 %t155)
  store i64 %t163, ptr %l92
  br label %bb42
bb42:
  %t164 = load i64, ptr %l2, !tbaa !24
  %t165 = load i64, ptr %l92, !tbaa !24
  %t167 = icmp eq i64 %t165, %t164
  br i1 %t167, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LocalUses", ptr %t174, i32 0, i32 7
  %t177 = load i64, ptr %l2, !tbaa !24
  %t180 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t176, i64 %t177)
  store i1 %t180, ptr %l101
  br label %bb48
bb48:
  %t181 = load i1, ptr %l101, !tbaa !21
  br i1 %t181, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t185 = xor i1 %a3, true
  br i1 %t185, label %bb52, label %bb53
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/typed:ViewWalk", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Body", ptr %t191, i32 0, i32 10
  store ptr %t193, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb55
bb55:
  %t195 = load i64, ptr %l13, !tbaa !24
  store i64 %t195, ptr %l109, !tbaa !24
  %t196 = load ptr, ptr %l12, !tbaa !29
  store ptr %t196, ptr %l110, !tbaa !29
  %t197 = load ptr, ptr %l110, !tbaa !29
  %t198 = call ptr @__olang_scope_of(ptr %t197, ptr null)
  %t199 = ptrtoint ptr %t198 to i64
  %t201 = inttoptr i64 %t199 to ptr
  %t202 = load ptr, ptr %l110, !tbaa !29
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t201, ptr %t202)
  store i64 %t203, ptr %l112
  br label %bb56
bb56:
  %t204 = load i64, ptr %l109, !tbaa !24
  %t205 = load i64, ptr %l112, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb57, label %bb58
bb57:
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t210 = load ptr, ptr %l12, !tbaa !29
  store ptr %t210, ptr %l115, !tbaa !29
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load ptr, ptr %l115, !tbaa !29
  %t213 = call ptr @__olang_scope_of(ptr %t212, ptr null)
  %t214 = ptrtoint ptr %t213 to i64
  %t216 = inttoptr i64 %t214 to ptr
  %t217 = load ptr, ptr %l115, !tbaa !29
  %t219 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t216, ptr %t217, i64 %t211)
  store i32 %t219, ptr %l118
  br label %bb60
bb60:
  %t220 = load i32, ptr %l118, !tbaa !23
  %t223 = sext i32 %t220 to i64
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  br i1 %t227, label %bb61, label %bb62
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb55
bb65:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l23 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Try", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load i64, ptr %l14, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Try", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = getelementptr %"compiler/typed:Clause", ptr %t33, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t61, ptr %t58)
  store i64 %t66, ptr %l41
  br label %bb10
bb10:
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t67, i64 %t68)
  store i64 %t69, ptr %l42
  br label %bb11
bb11:
  %t70 = load i64, ptr %l42, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca i64
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l117 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb4
bb4:
  %t11 = load i64, ptr %l21, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i1 %a1, ptr %l3, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 12
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l25
  br label %bb5
bb5:
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l27, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:dropWalk", ptr %t23, i32 0, i32 12
  store ptr %t25, ptr %l29, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:dropWalk", ptr %t26, i32 0, i32 12
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l32
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t31 = load i64, ptr %l32, !tbaa !24
  %t32 = sub i64 %t31, 1
  %t33 = load ptr, ptr %l29, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t33, i64 %t32)
  store i64 %t35, ptr %l34
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l27, !tbaa !29
  %t37 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t36, i64 %t37)
  br label %bb10
bb10:
  br label %bb11
bb11:
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:dropWalk", ptr %t38, i32 0, i32 11
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l37
  br label %bb12
bb12:
  %t43 = load i64, ptr %l37, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l44, !tbaa !24
  store i64 %t70, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t71 = load i64, ptr %l41, !tbaa !24
  store i64 %t71, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb20, label %bb21
bb20:
  br label %bb47
bb21:
  br label %bb22
bb22:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l2, !tbaa !24
  %t93 = add i64 %t91, 1
  %t96 = mul i64 %t90, %t93
  store i64 %t96, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb28
bb25:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l73, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l73, !tbaa !24
  store i64 %t126, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t127 = load i64, ptr %l70, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l16, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:dropWalk", ptr %t146, i32 0, i32 13
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l16, !tbaa !24
  %t153 = add i64 %t149, %t150
  store i64 %t153, ptr %l95, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:dropWalk", ptr %t154, i32 0, i32 13
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l16, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t164 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t156, i64 %t161)
  store i1 %t164, ptr %l101
  br label %bb33
bb33:
  %t165 = load i1, ptr %l101, !tbaa !21
  br i1 %t165, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb37
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:dropWalk", ptr %t166, i32 0, i32 2
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t168, i64 %t169)
  store i1 %t172, ptr %l106
  br label %bb36
bb36:
  %t173 = load i1, ptr %l106, !tbaa !21
  store i1 %t173, ptr %l102, !tbaa !21
  br label %bb37
bb37:
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load i64, ptr %l95, !tbaa !24
  %t176 = load i1, ptr %l102, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t174, i64 %t175, i1 %t176)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l15, !tbaa !24
  br label %bb29
bb40:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/typed:dropWalk", ptr %t181, i32 0, i32 13
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l2, !tbaa !24
  %t188 = add i64 %t184, %t185
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t183, i64 %t188, i1 false)
  br label %bb41
bb41:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/typed:dropWalk", ptr %t191, i32 0, i32 11
  %t194 = load i64, ptr %l9, !tbaa !24
  %t197 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l117
  br label %bb42
bb42:
  %t198 = load i1, ptr %l117, !tbaa !21
  br i1 %t198, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t199 = load i64, ptr %l8, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l8, !tbaa !24
  br label %bb19
bb47:
  %t203 = load i1, ptr %l3, !tbaa !21
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t205, i64 -1)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb52
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 12
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i64 %t50, ptr %l34
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %t51, i64 %t52)
  br label %bb14
bb14:
  br label %bb50
bb15:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 11
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb21
bb21:
  br label %bb50
bb22:
  %t73 = load ptr, ptr %l5, !tbaa !29
  store ptr %t73, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 17}
  %t80 = icmp eq i64 %t78, 3
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb29
bb29:
  br label %bb50
bb30:
  %t103 = load ptr, ptr %l5, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 17}
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr { i64, [3 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l9, !tbaa !29
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  br label %bb37
bb37:
  br label %bb50
bb38:
  %t133 = load ptr, ptr %l5, !tbaa !29
  store ptr %t133, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l70, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 17}
  %t140 = icmp eq i64 %t138, 13
  store i1 %t140, ptr %l71, !tbaa !21
  br label %bb40
bb40:
  %t141 = load i1, ptr %l71, !tbaa !21
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l11, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Join", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t148, ptr %t152)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_9f9fe097503cda9_c6b719cc2534ac35)
  unreachable
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l3, !tbaa !24
  br label %bb4
bb52:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:dropWalk", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %a2
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:dropWalk", ptr %t28, i32 0, i32 8
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l21
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t35, i64 %t36)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %a1, %t40
  %t42 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %t37, i1 %t41, i64 %t42)
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:dropWalk", ptr %t50, i32 0, i32 3
  store i1 true, ptr %t52, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i32
  %l150 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i32
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca i1
  %l187 = alloca i1
  %l188 = alloca i32
  %l192 = alloca i1
  %l195 = alloca i1
  %l196 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i64, ptr %l29, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 7
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Block", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t15, i32 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:dropWalk", ptr %t22, i32 0, i32 8
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:dropWalk", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t24, i64 %t28)
  br label %bb4
bb4:
  store i64 0, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t35, %t36
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb10
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = add i64 %t49, %t50
  %t55 = sub i64 %t53, 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sdiv i64 %t55, %t56
  store i64 %t59, ptr %l46, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l43, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = mul i64 %t72, %t73
  %t79 = add i64 %t71, %t76
  store i64 %t79, ptr %l10, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:dropWalk", ptr %t81, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t83, i1 false)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t87, i1 false)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb11
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:dropWalk", ptr %t93, i32 0, i32 9
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  %t102 = mul i64 %t96, %t99
  %t103 = load i64, ptr %l3, !tbaa !24
  %t106 = add i64 %t102, %t103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t106, i1 true)
  br label %bb19
bb19:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t109)
  store { i64, ptr } %t111, ptr %l79
  br label %bb20
bb20:
  %t112 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l80, !tbaa !24
  %t114 = load i64, ptr %l80, !tbaa !24
  %t115 = mul i64 %t114, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l81, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l80, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  %t125 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t125, ptr %l11, !tbaa !27
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t126, { i64, ptr } %t127)
  br label %bb22
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb23, label %bb24
bb23:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb28
bb25:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l92, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb27
bb27:
  %t160 = load i64, ptr %l92, !tbaa !24
  store i64 %t160, ptr %l89, !tbaa !24
  br label %bb28
bb28:
  %t161 = load i64, ptr %l89, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/typed:dropWalk", ptr %t180, i32 0, i32 10
  %t183 = load i64, ptr %l4, !tbaa !24
  %t184 = load i64, ptr %l3, !tbaa !24
  %t186 = add i64 %t184, 1
  %t189 = mul i64 %t183, %t186
  %t190 = load i64, ptr %l17, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = load i64, ptr %l3, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t182, i64 %t193, i1 %t198)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t202 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l16, !tbaa !24
  br label %bb29
bb35:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t206, ptr %t207)
  br label %bb36
bb36:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l126, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l4, !tbaa !24
  %t216 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s4, ptr %t212, i1 false, i64 %t213)
  store { i64, ptr } %t216, ptr %l129
  br label %bb37
bb37:
  %t217 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t224 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s4, ptr %t224, { i64, ptr } %t223)
  br label %bb38
bb38:
  %t226 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v2, ptr %t226, ptr %a2)
  br label %bb39
bb39:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %s0, ptr %t230, { i64, ptr } %t231)
  store i64 %t234, ptr %l135
  br label %bb40
bb40:
  %t235 = load i64, ptr %l135, !tbaa !24
  %t236 = icmp eq i64 %t235, 0
  br i1 %t236, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb21
bb45:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i64, ptr %l4, !tbaa !24
  %t243 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s0, ptr %t239, i1 true, i64 %t240)
  store { i64, ptr } %t243, ptr %l140
  br label %bb46
bb46:
  %t244 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t250)
  br label %bb47
bb47:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/typed:dropWalk", ptr %t253, i32 0, i32 7
  %t257 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t255)
  %t258 = extractvalue { i32, i32 } %t257, 1
  %t259 = extractvalue { i32, i32 } %t257, 0
  store i32 %t259, ptr %l146
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb49, label %ok.261, !prof !99
ok.261:
  store i32 %t258, ptr %l145
  br label %bb48
bb48:
  %t262 = load i32, ptr %l145, !tbaa !23
  store i32 %t262, ptr %l142, !tbaa !23
  br label %bb56
bb49:
  %t263 = load i32, ptr %l146, !tbaa !23
  %t264 = icmp eq i32 %t263, 65536
  br i1 %t264, label %bb50, label %bb51
bb50:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b)
  unreachable
bb51:
  %t266 = load i32, ptr %l146, !tbaa !23
  %t267 = icmp eq i32 %t266, 65537
  br i1 %t267, label %bb52, label %bb53
bb52:
  call void @__olang_bang_failed_plain(ptr @olang_loc_54fd08b205476dc4_657f8db756d05b08)
  unreachable
bb53:
  %t269 = load i32, ptr %l146, !tbaa !23
  %t270 = icmp eq i32 %t269, 65538
  br i1 %t270, label %bb54, label %bb55
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60)
  unreachable
bb55:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3398753e62525e0a_a26aec7fb7dfed8e)
  unreachable
bb56:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/typed:dropWalk", ptr %t272, i32 0, i32 8
  %t276 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t274)
  %t277 = extractvalue { i32, i64 } %t276, 1
  %t278 = extractvalue { i32, i64 } %t276, 0
  store i32 %t278, ptr %l154
  %t279 = icmp ne i32 %t278, 0
  br i1 %t279, label %bb58, label %ok.280, !prof !99
ok.280:
  store i64 %t277, ptr %l153
  br label %bb57
bb57:
  %t281 = load i64, ptr %l153, !tbaa !24
  store i64 %t281, ptr %l150, !tbaa !24
  br label %bb65
bb58:
  %t282 = load i32, ptr %l154, !tbaa !23
  %t283 = icmp eq i32 %t282, 65536
  br i1 %t283, label %bb59, label %bb60
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8b9fe86f9939495b_ac6312ba480f0d67)
  unreachable
bb60:
  %t285 = load i32, ptr %l154, !tbaa !23
  %t286 = icmp eq i32 %t285, 65537
  br i1 %t286, label %bb61, label %bb62
bb61:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3f464ddbb91b0a38_82918aeeacdcc614)
  unreachable
bb62:
  %t288 = load i32, ptr %l154, !tbaa !23
  %t289 = icmp eq i32 %t288, 65538
  br i1 %t289, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c)
  unreachable
bb64:
  call void @__olang_bang_failed_plain(ptr @olang_loc_18d2a0b724f39c7e_37ab118f04dce49a)
  unreachable
bb65:
  store i64 0, ptr %l18, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t295 = load i64, ptr %l19, !tbaa !24
  %t296 = load i64, ptr %l18, !tbaa !24
  %t299 = icmp sgt i64 %t295, %t296
  br i1 %t299, label %bb66, label %bb67
bb66:
  %t301 = load i64, ptr %l20, !tbaa !24
  %t303 = icmp sgt i64 %t301, 0
  br i1 %t303, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb71
bb68:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t306 = load i64, ptr %l18, !tbaa !24
  %t309 = sub i64 %t305, %t306
  %t310 = load i64, ptr %l20, !tbaa !24
  %t313 = add i64 %t309, %t310
  %t315 = sub i64 %t313, 1
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = sdiv i64 %t315, %t316
  store i64 %t319, ptr %l166, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb70
bb70:
  %t321 = load i64, ptr %l166, !tbaa !24
  store i64 %t321, ptr %l163, !tbaa !24
  br label %bb71
bb71:
  %t322 = load i64, ptr %l163, !tbaa !24
  store i64 %t322, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb72
bb72:
  %t323 = load i64, ptr %l22, !tbaa !24
  %t324 = load i64, ptr %l21, !tbaa !24
  %t327 = icmp slt i64 %t323, %t324
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb73, label %bb74
bb73:
  br label %bb95
bb74:
  br label %bb75
bb75:
  %t331 = load i64, ptr %l18, !tbaa !24
  %t332 = load i64, ptr %l22, !tbaa !24
  %t333 = load i64, ptr %l20, !tbaa !24
  %t336 = mul i64 %t332, %t333
  %t339 = add i64 %t331, %t336
  store i64 %t339, ptr %l23, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/typed:dropWalk", ptr %t341, i32 0, i32 9
  %t345 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t343)
  %t346 = extractvalue { i32, i1 } %t345, 1
  %t347 = extractvalue { i32, i1 } %t345, 0
  store i32 %t347, ptr %l188
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb77, label %ok.349, !prof !99
ok.349:
  store i1 %t346, ptr %l187
  br label %bb76
bb76:
  %t350 = load i1, ptr %l187, !tbaa !21
  store i1 %t350, ptr %l184, !tbaa !21
  br label %bb84
bb77:
  %t351 = load i32, ptr %l188, !tbaa !23
  %t352 = icmp eq i32 %t351, 65536
  br i1 %t352, label %bb78, label %bb79
bb78:
  call void @__olang_bang_failed_plain(ptr @olang_loc_fb0720d2dfee7f_1f99818eb62f02f3)
  unreachable
bb79:
  %t354 = load i32, ptr %l188, !tbaa !23
  %t355 = icmp eq i32 %t354, 65537
  br i1 %t355, label %bb80, label %bb81
bb80:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0)
  unreachable
bb81:
  %t357 = load i32, ptr %l188, !tbaa !23
  %t358 = icmp eq i32 %t357, 65538
  br i1 %t358, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5)
  unreachable
bb83:
  call void @__olang_bang_failed_plain(ptr @olang_loc_313fe9555679a06f_fa589a226c49c6eb)
  unreachable
bb84:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/typed:dropWalk", ptr %t360, i32 0, i32 10
  %t364 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t362)
  %t365 = extractvalue { i32, i1 } %t364, 1
  %t366 = extractvalue { i32, i1 } %t364, 0
  store i32 %t366, ptr %l196
  %t367 = icmp ne i32 %t366, 0
  br i1 %t367, label %bb86, label %ok.368, !prof !99
ok.368:
  store i1 %t365, ptr %l195
  br label %bb85
bb85:
  %t369 = load i1, ptr %l195, !tbaa !21
  store i1 %t369, ptr %l192, !tbaa !21
  br label %bb93
bb86:
  %t370 = load i32, ptr %l196, !tbaa !23
  %t371 = icmp eq i32 %t370, 65536
  br i1 %t371, label %bb87, label %bb88
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f3df993f4c7e1fd4_8419908bae6ac650)
  unreachable
bb88:
  %t373 = load i32, ptr %l196, !tbaa !23
  %t374 = icmp eq i32 %t373, 65537
  br i1 %t374, label %bb89, label %bb90
bb89:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e306d5ccad957c29_6b95b0de26f94a45)
  unreachable
bb90:
  %t376 = load i32, ptr %l196, !tbaa !23
  %t377 = icmp eq i32 %t376, 65538
  br i1 %t377, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d73b6870bbe51a4d_d845c63f23993221)
  unreachable
bb92:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747)
  unreachable
bb93:
  br label %bb94
bb94:
  %t379 = load i64, ptr %l22, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l22, !tbaa !24
  br label %bb72
bb95:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l48 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l10, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = add i64 %t7, 1
  %t9 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t9, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = add i64 %t18, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l9, !tbaa !24
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82)
  store i1 %t85, ptr %l54
  br label %bb15
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:dropWalk", ptr %t86, i32 0, i32 10
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t96 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t93)
  store i1 %t96, ptr %l60
  br label %bb16
bb15:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l48, !tbaa !21
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t99, ptr %t103, !tbaa !31
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = add i64 %t104, 1
  store i64 %t105, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l8
  br label %bb3
bb3:
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 1
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:dropWalk", ptr %t18, i32 0, i32 2
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t23, i64 %t24, i64 %t25)
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:dropWalk", ptr %t26, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 false)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l82 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l111 = alloca i64
  %l120 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i32
  %l131 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i32
  %l179 = alloca { i64, ptr }
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 11
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l34
  br label %bb2
bb2:
  %t12 = load i64, ptr %l34, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 11
  store ptr %t15, ptr %l36, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l39, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = load i1, ptr %l39, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 %t29)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t32, i64 %t36)
  br label %bb7
bb7:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb13
bb10:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l54, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l54, !tbaa !24
  store i64 %t67, ptr %l51, !tbaa !24
  br label %bb13
bb13:
  %t68 = load i64, ptr %l51, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:dropWalk", ptr %t87, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t89, i1 false)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb14
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:dropWalk", ptr %t95, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t97, i1 true)
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Try", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb22
bb22:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l82, !tbaa !24
  %t109 = load i64, ptr %l82, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load i64, ptr %l82, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2cf1608fd5d1230c_1374e48cd144e348)
  unreachable
bb25:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb30
bb27:
  %t132 = load i64, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l93, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb29
bb29:
  %t148 = load i64, ptr %l93, !tbaa !24
  store i64 %t148, ptr %l90, !tbaa !24
  br label %bb30
bb30:
  %t149 = load i64, ptr %l90, !tbaa !24
  store i64 %t149, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t150 = load i64, ptr %l15, !tbaa !24
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l16, !tbaa !24
  store i64 %t168, ptr %l111, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:dropWalk", ptr %t169, i32 0, i32 13
  %t172 = load i64, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l2, !tbaa !24
  %t175 = add i64 %t173, 1
  %t178 = mul i64 %t172, %t175
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t185 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t171, i64 %t182)
  store i1 %t185, ptr %l120
  br label %bb35
bb35:
  %t186 = load i1, ptr %l120, !tbaa !21
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t187
  store i1 %t186, ptr %t190, !tbaa !31
  br label %bb36
bb36:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb31
bb37:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/typed:dropWalk", ptr %t195, i32 0, i32 11
  %t199 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t197)
  %t200 = extractvalue { i32, i1 } %t199, 1
  %t201 = extractvalue { i32, i1 } %t199, 0
  store i32 %t201, ptr %l127
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb39, label %ok.203, !prof !99
ok.203:
  store i1 %t200, ptr %l126
  br label %bb38
bb38:
  %t204 = load i1, ptr %l126, !tbaa !21
  store i1 %t204, ptr %l123, !tbaa !21
  br label %bb46
bb39:
  %t205 = load i32, ptr %l127, !tbaa !23
  %t206 = icmp eq i32 %t205, 65536
  br i1 %t206, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_73be6a0e490978a7_b5fa18d3e7eede33)
  unreachable
bb41:
  %t208 = load i32, ptr %l127, !tbaa !23
  %t209 = icmp eq i32 %t208, 65537
  br i1 %t209, label %bb42, label %bb43
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fb6091d652311b2_1c71a9a414fce87e)
  unreachable
bb43:
  %t211 = load i32, ptr %l127, !tbaa !23
  %t212 = icmp eq i32 %t211, 65538
  br i1 %t212, label %bb44, label %bb45
bb44:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8c1b8241682c8a5c_1491e83e9da6f28)
  unreachable
bb45:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fc9df9522ae1330_697d53c50db00ce4)
  unreachable
bb46:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:dropWalk", ptr %t214, i32 0, i32 12
  %t218 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t216)
  %t219 = extractvalue { i32, i64 } %t218, 1
  %t220 = extractvalue { i32, i64 } %t218, 0
  store i32 %t220, ptr %l135
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb48, label %ok.222, !prof !99
ok.222:
  store i64 %t219, ptr %l134
  br label %bb47
bb47:
  %t223 = load i64, ptr %l134, !tbaa !24
  store i64 %t223, ptr %l131, !tbaa !24
  br label %bb55
bb48:
  %t224 = load i32, ptr %l135, !tbaa !23
  %t225 = icmp eq i32 %t224, 65536
  br i1 %t225, label %bb49, label %bb50
bb49:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e4195c8d52320dab_6e5abcaf8844f88f)
  unreachable
bb50:
  %t227 = load i32, ptr %l135, !tbaa !23
  %t228 = icmp eq i32 %t227, 65537
  br i1 %t228, label %bb51, label %bb52
bb51:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6df7d27e20fc18e6_9af88db0bee394aa)
  unreachable
bb52:
  %t230 = load i32, ptr %l135, !tbaa !23
  %t231 = icmp eq i32 %t230, 65538
  br i1 %t231, label %bb53, label %bb54
bb53:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c52364142dc414a0_4d1da6470710a144)
  unreachable
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730)
  unreachable
bb55:
  store i64 0, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb56, label %bb57
bb56:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb61
bb58:
  %t247 = load i64, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l147, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l147, !tbaa !24
  store i64 %t263, ptr %l144, !tbaa !24
  br label %bb61
bb61:
  %t264 = load i64, ptr %l144, !tbaa !24
  store i64 %t264, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  %t265 = load i64, ptr %l21, !tbaa !24
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l19, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l22, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/typed:dropWalk", ptr %t283, i32 0, i32 13
  %t287 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t285)
  %t288 = extractvalue { i32, i1 } %t287, 1
  %t289 = extractvalue { i32, i1 } %t287, 0
  store i32 %t289, ptr %l169
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb67, label %ok.291, !prof !99
ok.291:
  store i1 %t288, ptr %l168
  br label %bb66
bb66:
  %t292 = load i1, ptr %l168, !tbaa !21
  store i1 %t292, ptr %l165, !tbaa !21
  br label %bb74
bb67:
  %t293 = load i32, ptr %l169, !tbaa !23
  %t294 = icmp eq i32 %t293, 65536
  br i1 %t294, label %bb68, label %bb69
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab)
  unreachable
bb69:
  %t296 = load i32, ptr %l169, !tbaa !23
  %t297 = icmp eq i32 %t296, 65537
  br i1 %t297, label %bb70, label %bb71
bb70:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cdd2e50680d68485_7d51e204495f7309)
  unreachable
bb71:
  %t299 = load i32, ptr %l169, !tbaa !23
  %t300 = icmp eq i32 %t299, 65538
  br i1 %t300, label %bb72, label %bb73
bb72:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2ee7063c57fe9793_68bf97cc73752027)
  unreachable
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f)
  unreachable
bb74:
  br label %bb75
bb75:
  %t302 = load i64, ptr %l21, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l21, !tbaa !24
  br label %bb62
bb76:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Try", ptr %t306, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t313 = icmp eq i64 %t311, 0
  br i1 %t313, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t315 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t315, ptr %l179, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l180, !tbaa !24
  %t318 = load i64, ptr %l180, !tbaa !24
  %t319 = mul i64 %t318, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l181, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = load i64, ptr %l180, !tbaa !24
  %t328 = mul i64 %t327, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t324, ptr %t326, i64 %t328, i1 false)
  %t329 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t329, ptr %l23, !tbaa !27
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Try", ptr %t330, i32 0, i32 1
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  store { i64, ptr } %t333, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l26, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t339 = load i64, ptr %l25, !tbaa !24
  %t340 = load i64, ptr %l26, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t347 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t347, ptr %l190, !tbaa !27
  %t348 = load i64, ptr %l25, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t348
  %t353 = load ptr, ptr %t352, !tbaa !39
  store ptr %t353, ptr %l27, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t355)
  store { i64, ptr } %t357, ptr %l194
  br label %bb84
bb84:
  %t358 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l195, !tbaa !24
  %t360 = load i64, ptr %l195, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l196, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l195, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t371, ptr %l28, !tbaa !27
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t372, { i64, ptr } %t373)
  br label %bb85
bb85:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l27, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Clause", ptr %t377, i32 0, i32 3
  %t380 = load ptr, ptr %t379, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t376, ptr %t380)
  br label %bb86
bb86:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l27, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Clause", ptr %t384, i32 0, i32 4
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t383, { i64, ptr } %t387)
  br label %bb87
bb87:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t390, { i64, ptr } %t391)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t394 = load i64, ptr %l25, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l25, !tbaa !24
  br label %bb80
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l39 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l20
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t13 = load ptr, ptr %l23, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l23, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 5}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l24, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { ptr }, ptr %t23, i32 0, i32 0
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l5, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t27)
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2676a1f2cfb255f8_2530c83c98e00394)
  unreachable
bb14:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %l39, !tbaa !27
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t53)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l7, !tbaa !24
  br label %bb15
bb21:
  store ptr %l3, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t63 = load i64, ptr %l11, !tbaa !24
  store i64 %t63, ptr %l47, !tbaa !24
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t64)
  store i64 %t66, ptr %l49
  br label %bb23
bb23:
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = load i64, ptr %l49, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t73 = load ptr, ptr %l10, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l54
  br label %bb27
bb27:
  %t78 = load ptr, ptr %l54, !tbaa !29
  %t79 = load ptr, ptr %lp2
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %s0, ptr %v0, ptr %t80, ptr %t78)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l59
  br label %bb28
bb28:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t87 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t87
  %t88 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t88, ptr %t87)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l11, !tbaa !24
  br label %bb22
bb31:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l63, !tbaa !29
  %t96 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t96, ptr %l65
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l63, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l65, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %s0, ptr %t97, { i64, ptr } %t98)
  br label %bb33
bb33:
  store i64 0, ptr %l13, !tbaa !24
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %l3)
  store i64 %t100, ptr %l67
  br label %bb34
bb34:
  %t101 = load i64, ptr %l67, !tbaa !24
  store i64 %t101, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t102 = load i64, ptr %l14, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb35, label %bb36
bb35:
  %t108 = load i64, ptr %l15, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb40
bb37:
  %t112 = load i64, ptr %l14, !tbaa !24
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l15, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l15, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l74, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb39
bb39:
  %t128 = load i64, ptr %l74, !tbaa !24
  store i64 %t128, ptr %l71, !tbaa !24
  br label %bb40
bb40:
  %t129 = load i64, ptr %l71, !tbaa !24
  store i64 %t129, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t130 = load i64, ptr %l17, !tbaa !24
  %t131 = load i64, ptr %l16, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb43:
  br label %bb44
bb44:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l17, !tbaa !24
  %t140 = load i64, ptr %l15, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l18, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load i64, ptr %l18, !tbaa !24
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s10, ptr %l3, i64 %t149)
  store ptr %t152, ptr %l95
  br label %bb45
bb45:
  %t153 = load ptr, ptr %l95, !tbaa !29
  %t154 = load ptr, ptr %l92, !tbaa !29
  %t156 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %s10, ptr %t154, ptr %t153)
  store i1 %t156, ptr %l97
  br label %bb46
bb46:
  %t157 = load i1, ptr %l97, !tbaa !21
  br i1 %t157, label %bb47, label %bb48
bb47:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/typed:holdWalk", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l100, !tbaa !29
  %t162 = load i64, ptr %l18, !tbaa !24
  %t165 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t162)
  store ptr %t165, ptr %l103
  br label %bb49
bb48:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb52
bb49:
  %t166 = load ptr, ptr %l103, !tbaa !29
  %t167 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %s0, ptr %t166)
  store i32 %t167, ptr %l104
  br label %bb50
bb50:
  %t168 = load ptr, ptr %l100, !tbaa !29
  %t169 = call ptr @__olang_scope_of(ptr %t168, ptr null)
  %t170 = ptrtoint ptr %t169 to i64
  %t172 = inttoptr i64 %t170 to ptr
  %t173 = load ptr, ptr %l100, !tbaa !29
  %t174 = load i32, ptr %l104, !tbaa !23
  %t175 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %t172, ptr %t173, i32 %t174)
  store i1 %t175, ptr %l106
  br label %bb51
bb51:
  %t176 = load i1, ptr %l106, !tbaa !21
  store i1 %t176, ptr %l98, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l98, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %s0, ptr %t178, i64 %t179, ptr %l3)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t183 = load i64, ptr %l17, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l17, !tbaa !24
  br label %bb41
bb58:
  %t187 = load ptr, ptr %lp2
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t187
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l19, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  store i64 %t25, ptr %l6, !tbaa !24
  %t27 = load ptr, ptr %lp2
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l24
  br label %bb6
bb6:
  %t32 = load i1, ptr %l24, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %lp2
  %t36 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t35, i64 %t36)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t43 = load i64, ptr %l7, !tbaa !24
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load ptr, ptr %lp2
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t44)
  store i64 %t46, ptr %l32
  br label %bb14
bb14:
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %bb35
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t55 = getelementptr %"compiler/typed:holdWalk", ptr %a0, i32 0, i32 2
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load ptr, ptr %lp2
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l39
  br label %bb18
bb18:
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s7, ptr %t61, i64 %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l40
  br label %bb19
bb19:
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s7, ptr %l40)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l42
  br label %bb20
bb20:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  %t67 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t67
  store ptr %t67, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  %t69 = load i64, ptr %l9, !tbaa !24
  store i64 %t69, ptr %l44, !tbaa !24
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s7, ptr %t70)
  store i64 %t72, ptr %l46
  br label %bb22
bb22:
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp slt i64 %t73, %t74
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb23, label %bb24
bb23:
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s7, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l51
  br label %bb26
bb26:
  %t84 = load i64, ptr %l51, !tbaa !24
  store i64 %t84, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %lp2
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l54
  br label %bb27
bb27:
  %t90 = load i1, ptr %l54, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %lp2
  %t94 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t93, i64 %t94)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l9, !tbaa !24
  br label %bb21
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb34:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb13
bb35:
  %t105 = load ptr, ptr %lp2
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t105
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eencloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca %"compiler/typed:BlockInfo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:holdWalk", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 8
  store ptr %t8, ptr %l13, !tbaa !29
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = call ptr @__olang_scope_of(ptr %t9, ptr null)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %t13, ptr %t14)
  store i64 %t15, ptr %l15
  br label %bb1
bb1:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = add i64 %t16, 1
  store i64 %t17, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb2, label %bb3
bb2:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l9, !tbaa !24
  %t65 = load i32, ptr %l3, !tbaa !23
  %t69 = icmp eq i32 %t65, %a1
  br i1 %t69, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t72 = load i32, ptr %l3, !tbaa !23
  %t74 = icmp slt i32 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:holdWalk", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 8
  store ptr %t82, ptr %l50, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load ptr, ptr %l50, !tbaa !29
  %t87 = call ptr @__olang_scope_of(ptr %t86, ptr null)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l50, !tbaa !29
  %t93 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t90, ptr %t91, i64 %t85)
  store %"compiler/typed:BlockInfo" %t93, ptr %l54
  br label %bb18
bb18:
  %t94 = getelementptr %"compiler/typed:BlockInfo", ptr %l54, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l3, !tbaa !23
  br label %bb19
bb19:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb8
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %t34, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
bb6:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l25
  br label %bb7
bb7:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t41, ptr %lp6
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t43 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t43
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %s2, ptr %t44, ptr %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l28
  br label %bb8
bb8:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %t50
  store ptr %t50, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t53)
  store i64 %t55, ptr %l32
  br label %bb10
bb10:
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l7, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l37
  br label %bb14
bb14:
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = load ptr, ptr %lp6
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:holdWalk", ptr %t69, i32 0, i32 2
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t71, i64 %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l42
  br label %bb15
bb15:
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l44
  br label %bb16
bb16:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t79
  %t80 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t80, ptr %t79)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t86 = load ptr, ptr %lp6
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheldBefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s1, i64 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s1, ptr %s1, ptr %t6)
  store { i64, ptr } %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %s1, ptr %s1, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l10
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l12, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb26
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l19
  br label %bb9
bb9:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:holdWalk", ptr %t37, i32 0, i32 6
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i1 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t45, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:holdWalk", ptr %t47, i32 0, i32 9
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l31
  br label %bb17
bb17:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l1, !tbaa !24
  %t61 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregisteredBefore(ptr %v0, ptr %t55, i64 %t56, i64 %t57)
  store i1 %t61, ptr %l36
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb20:
  %t62 = load i1, ptr %l36, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t66 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t66, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Match", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %t30, ptr %t28)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Match", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %lp2
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %t64, ptr %t61)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l41
  br label %bb13
bb13:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t70 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  %t71 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t71, ptr %t70)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb15:
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l8, !tbaa !24
  br label %bb9
bb16:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Match", ptr %t77, i32 0, i32 2
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load ptr, ptr %lp2
  store ptr %t86, ptr %l49, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Match", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb19, label %bb20
bb18:
  br label %bb24
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7fb442b2027c5df4_8cb8a301a51c1668)
  unreachable
bb20:
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Match", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t101 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %t99, ptr %t98)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l56
  br label %bb22
bb22:
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t103 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %t103
  %t104 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t104, ptr %t103)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb24:
  %t106 = load ptr, ptr %lp2
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefusals(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca %"compiler/typed:Local"
  %l44 = alloca ptr
  %l47 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l79 = alloca i64
  %l85 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l98 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheldBefore(ptr %v0, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l25
  br label %bb7
bb7:
  %t26 = load i64, ptr %l25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:DropHolding", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t33, i64 %t34)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/typed:DropHolding", ptr %t37, i32 0, i32 4
  store ptr %t39, ptr %l32, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:holdWalk", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 7
  store ptr %t45, ptr %l35, !tbaa !29
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l35, !tbaa !29
  %t48 = call ptr @__olang_scope_of(ptr %t47, ptr null)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t51, ptr %t52, i64 %t46)
  store %"compiler/typed:Local" %t54, ptr %l38
  br label %bb12
bb12:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l38, i32 0, i32 1
  %t56 = load %"compiler/source:Span", ptr %t55
  %t57 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t57, %"compiler/source:Span" %t56)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:DropHolding", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t61, i64 %t62)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:DropHolding", ptr %t65, i32 0, i32 6
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %t68, i64 %t69)
  store i32 %t72, ptr %l47
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = load i32, ptr %l47, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t73, i32 %t74)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb1
bb18:
  store i64 0, ptr %l6, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:holdWalk", ptr %t79, i32 0, i32 13
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l52
  br label %bb19
bb19:
  %t84 = load i64, ptr %l52, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb25
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l59, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l59, !tbaa !24
  store i64 %t111, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  %t112 = load i64, ptr %l56, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb27, label %bb28
bb27:
  br label %bb41
bb28:
  br label %bb29
bb29:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempHolds(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l79
  br label %bb30
bb30:
  %t136 = load i64, ptr %l79, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp slt i64 %t137, 0
  br i1 %t139, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/typed:DropHolding", ptr %t141, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t143, i64 -1)
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:DropHolding", ptr %t145, i32 0, i32 4
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/typed:holdWalk", ptr %t148, i32 0, i32 13
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t150, i64 %t151)
  store %"compiler/source:Span" %t154, ptr %l89
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l85, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t155, %"compiler/source:Span" %t156)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:DropHolding", ptr %t157, i32 0, i32 5
  %t160 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t159, i64 %t160)
  br label %bb37
bb37:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/typed:DropHolding", ptr %t163, i32 0, i32 6
  store ptr %t165, ptr %l94, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:holdWalk", ptr %t166, i32 0, i32 16
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t168, i64 %t169)
  store i32 %t172, ptr %l98
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l94, !tbaa !29
  %t174 = load i32, ptr %l98, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t173, i32 %t174)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb26
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i64
  %l61 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca i1
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i1
  %l82 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:holdWalk", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:holdWalk", ptr %t58, i32 0, i32 10
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l42
  br label %bb12
bb12:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t68 = icmp eq i64 %t66, %t65
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:holdWalk", ptr %t70, i32 0, i32 11
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l49
  br label %bb15
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l49, !tbaa !24
  %t80 = icmp eq i64 %t78, %t77
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb8
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:holdWalk", ptr %t87, i32 0, i32 10
  %t90 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:holdWalk", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t95, i64 %t96)
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:holdWalk", ptr %t99, i32 0, i32 12
  store ptr %t101, ptr %l61, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l63
  br label %bb24
bb24:
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t105, i32 %t106)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/typed:holdWalk", ptr %t107, i32 0, i32 9
  %t110 = load i64, ptr %l1, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i1 %t113, ptr %l67
  br label %bb26
bb26:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/typed:holdWalk", ptr %t117, i32 0, i32 9
  %t120 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t119, i64 %t120)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/typed:holdWalk", ptr %t123, i32 0, i32 2
  %t126 = load i64, ptr %l1, !tbaa !24
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l75
  br label %bb31
bb31:
  %t130 = load i64, ptr %l1, !tbaa !24
  %t133 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l75, i64 %t130)
  store i1 %t133, ptr %l78
  br label %bb32
bb32:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:holdWalk", ptr %t135, i32 0, i32 2
  %t138 = load i64, ptr %l1, !tbaa !24
  %t141 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l82
  br label %bb36
bb36:
  %t142 = load i64, ptr %l1, !tbaa !24
  %t143 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t143, i64 %t142)
  br label %bb37
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:holdWalk", ptr %t145, i32 0, i32 3
  store i1 true, ptr %t147, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 5
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:holdWalk", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t28)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = call ptr @__olang_scope_of(ptr %t31, ptr null)
  %t33 = ptrtoint ptr %t32 to i64
  %t35 = inttoptr i64 %t33 to ptr
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i32, ptr %l19, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t35, ptr %t36, i32 %t37)
  store i1 %t38, ptr %l21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l21, !tbaa !21
  store i1 %t39, ptr %l8, !tbaa !21
  br label %bb30
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 14
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Try", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %t55, ptr %t59)
  store i1 %t62, ptr %l31
  br label %bb17
bb17:
  %t63 = load i1, ptr %l31, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb30
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l33, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Seq", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l41
  br label %bb24
bb24:
  %t87 = load i1, ptr %l41, !tbaa !21
  store i1 %t87, ptr %l8, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_77c9af98e9dace58_20acd54f7de13794)
  unreachable
bb30:
  %t88 = load i1, ptr %l8, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregisteredBefore(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i32
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l103 = alloca i64
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca i32
  %l113 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store i32 -1, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l7, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:holdWalk", ptr %t53, i32 0, i32 11
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l47
  br label %bb12
bb12:
  %t61 = load i64, ptr %l47, !tbaa !24
  %t63 = icmp ne i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:holdWalk", ptr %t70, i32 0, i32 10
  %t73 = load i64, ptr %l10, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l56
  br label %bb19
bb19:
  %t77 = load i64, ptr %l56, !tbaa !24
  store i64 %t77, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:holdWalk", ptr %t78, i32 0, i32 12
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t84, ptr %l60
  br label %bb20
bb20:
  %t85 = load i32, ptr %l60, !tbaa !23
  store i32 %t85, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb23, label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:holdWalk", ptr %t95, i32 0, i32 11
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l68
  br label %bb26
bb26:
  %t100 = load i64, ptr %l68, !tbaa !24
  store i64 %t100, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb29:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l75, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb31
bb31:
  %t127 = load i64, ptr %l75, !tbaa !24
  store i64 %t127, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t128 = load i64, ptr %l72, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l16, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/typed:holdWalk", ptr %t147, i32 0, i32 11
  %t150 = load i64, ptr %l16, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l96
  br label %bb37
bb37:
  %t155 = load i64, ptr %l96, !tbaa !24
  %t157 = icmp eq i64 %t155, %a2
  br i1 %t157, label %bb38, label %bb39
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/typed:holdWalk", ptr %t159, i32 0, i32 10
  %t162 = load i64, ptr %l16, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l103
  br label %bb40
bb39:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb40:
  %t166 = load i64, ptr %l3, !tbaa !24
  %t167 = load i64, ptr %l103, !tbaa !24
  %t169 = icmp sle i64 %t167, %t166
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb45
bb42:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l107, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  store i32 %t172, ptr %l108, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:holdWalk", ptr %t173, i32 0, i32 12
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t175, i64 %t176)
  store i32 %t179, ptr %l112
  br label %bb43
bb43:
  %t180 = load ptr, ptr %l107, !tbaa !29
  %t181 = load i32, ptr %l108, !tbaa !23
  %t182 = load i32, ptr %l112, !tbaa !23
  %t183 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eencloses(ptr %v0, ptr %t180, i32 %t181, i32 %t182)
  store i1 %t183, ptr %l113
  br label %bb44
bb44:
  %t184 = load i1, ptr %l113, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l106, !tbaa !21
  br label %bb45
bb45:
  %t187 = load i1, ptr %l106, !tbaa !21
  store i1 %t187, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t188 = load i1, ptr %l99, !tbaa !21
  br i1 %t188, label %bb47, label %bb48
bb47:
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb33
bb51:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca %"compiler/typed:Local"
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = call ptr @__olang_scope_of(ptr %t8, ptr null)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t12, ptr %t13, i64 %t7)
  store %"compiler/typed:Local" %t15, ptr %l8
  br label %bb1
bb1:
  %t16 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l2, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:holdWalk", ptr %t19, i32 0, i32 9
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l13
  br label %bb2
bb2:
  %t26 = load i1, ptr %l13, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:holdWalk", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l17, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = call ptr @__olang_scope_of(ptr %t34, ptr null)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l17, !tbaa !29
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t38, ptr %t39, i32 %t33)
  store i32 %t41, ptr %l20
  br label %bb5
bb5:
  %t42 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t44 = trunc i64 20 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t49 = load i1, ptr %l15, !tbaa !21
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/typed:holdWalk", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  %t56 = load i32, ptr %l2, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = call ptr @__olang_scope_of(ptr %t57, ptr null)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t61, ptr %t62, i32 %t56)
  store i32 %t64, ptr %l29
  br label %bb10
bb10:
  %t65 = load i32, ptr %l29, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l66 = alloca i1
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v2, i64 %t18)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l8
  br label %bb55
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l27
  br label %bb13
bb13:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l8
  br label %bb55
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %t59, ptr %t60)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l36
  br label %bb20
bb20:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l8
  br label %bb55
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t66 = load ptr, ptr %l37, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eelemStorage(ptr %v0, ptr %v1, ptr %v2, ptr %t80, ptr %t81)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l45
  br label %bb27
bb27:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l8
  br label %bb55
bb28:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t87 = load ptr, ptr %l46, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l47, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Payload", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t105)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l55
  br label %bb34
bb34:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l8
  br label %bb55
bb35:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l56, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 8}
  %t117 = icmp eq i64 %t115, 6
  store i1 %t117, ptr %l57, !tbaa !21
  br label %bb37
bb37:
  %t118 = load i1, ptr %l57, !tbaa !21
  br i1 %t118, label %bb38, label %bb39
bb38:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %t125, ptr %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l64
  br label %bb41
bb41:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l8
  br label %bb55
bb42:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t132 = load ptr, ptr %l65, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb43, label %bb44
bb43:
  %t135 = load ptr, ptr %l65, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 7
  store i1 %t138, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t139 = load i1, ptr %l66, !tbaa !21
  br i1 %t139, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etarget(ptr %v0, ptr %v2, ptr %t140)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l70
  br label %bb48
bb48:
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l8
  br label %bb55
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t144 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %l71
  br label %bb53
bb53:
  %t145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l8
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_60996a1f08c29aeb_ed876111a60916df)
  unreachable
bb55:
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempHolds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l61 = alloca i32
  %l65 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s1, ptr %t3, i64 %t4)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb3
bb3:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = load i64, ptr %l18, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb31
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l23
  br label %bb7
bb7:
  %t26 = load i64, ptr %l23, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:holdWalk", ptr %t27, i32 0, i32 6
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l26
  br label %bb8
bb8:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l33, !tbaa !24
  store i64 %t59, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l10, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:holdWalk", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t81, i64 %t82)
  store i64 %t85, ptr %l54
  br label %bb19
bb19:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l54, !tbaa !24
  %t89 = icmp eq i64 %t87, %t86
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:holdWalk", ptr %t91, i32 0, i32 7
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t93, i64 %t94)
  store i32 %t97, ptr %l61
  br label %bb22
bb21:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb24
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/typed:holdWalk", ptr %t98, i32 0, i32 15
  %t101 = load i64, ptr %l1, !tbaa !24
  %t104 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t100, i64 %t101)
  store i32 %t104, ptr %l65
  br label %bb23
bb23:
  %t105 = load i32, ptr %l61, !tbaa !23
  %t106 = load i32, ptr %l65, !tbaa !23
  %t107 = icmp eq i32 %t105, %t106
  store i1 %t107, ptr %l57, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l57, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t110 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t110, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l9, !tbaa !24
  br label %bb15
bb29:
  br label %bb30
bb30:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb2
bb31:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %lp2
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t12)
  store i32 %t14, ptr %l12
  br label %bb5
bb5:
  %t15 = load i32, ptr %l12, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s2, ptr %t16, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t23 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t23
  store ptr %t23, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t26)
  store i64 %t28, ptr %l20
  br label %bb8
bb8:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:holdWalk", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  store i32 %t45, ptr %l28, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %t46, i64 %t47)
  store i32 %t50, ptr %l31
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l27, !tbaa !29
  %t52 = call ptr @__olang_scope_of(ptr %t51, ptr null)
  %t53 = ptrtoint ptr %t52 to i64
  %t55 = inttoptr i64 %t53 to ptr
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = load i32, ptr %l28, !tbaa !23
  %t58 = load i32, ptr %l31, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %t55, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t59, ptr %l33
  br label %bb14
bb14:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %lp2
  %t62 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t61, i64 %t62)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l5, !tbaa !24
  br label %bb7
bb20:
  call void @__olang_scope_close(ptr %s2)
  %t69 = load ptr, ptr %lp2
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Arm", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Arm", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  store i1 %t17, ptr %l18
  br label %bb4
bb4:
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Arm", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  store i1 %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Arm", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l33, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Alt", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t64 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i1 %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load i1, ptr %l40, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Alt", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Bind", ptr %t90, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  store i1 %t100, ptr %l57
  br label %bb25
bb25:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb21
bb30:
  br label %bb31
bb31:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb13
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t10)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_10efe43793a641ac_2dabf1c43cd6a168)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l161 = alloca i1
  %l162 = alloca i1
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca i1
  %l203 = alloca i1
  %l204 = alloca ptr
  %l210 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i1
  %l220 = alloca i1
  %l224 = alloca i1
  %l227 = alloca i1
  %l230 = alloca i1
  %l232 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l251 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l261 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb183
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l52
  br label %bb31
bb31:
  %t83 = load i1, ptr %l52, !tbaa !21
  store i1 %t83, ptr %l19, !tbaa !21
  br label %bb183
bb32:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t85 = load ptr, ptr %l53, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t107 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  store i1 %t107, ptr %l63
  br label %bb38
bb38:
  %t108 = load i1, ptr %l63, !tbaa !21
  store i1 %t108, ptr %l19, !tbaa !21
  br label %bb183
bb39:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb40, label %bb41
bb40:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 18}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t117 = load i1, ptr %l65, !tbaa !21
  br i1 %t117, label %bb42, label %bb43
bb42:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l4, !tbaa !23
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t134 = icmp eq i32 %t130, %t131
  br i1 %t134, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb48
bb46:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Call", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %t136, ptr %t140)
  store i1 %t143, ptr %l79
  br label %bb47
bb47:
  %t144 = load i1, ptr %l79, !tbaa !21
  store i1 %t144, ptr %l75, !tbaa !21
  br label %bb48
bb48:
  %t145 = load i1, ptr %l75, !tbaa !21
  br i1 %t145, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb52
bb50:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l5, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t153 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  store i1 %t153, ptr %l84
  br label %bb51
bb51:
  %t154 = load i1, ptr %l84, !tbaa !21
  store i1 %t154, ptr %l80, !tbaa !21
  br label %bb52
bb52:
  %t155 = load i1, ptr %l80, !tbaa !21
  store i1 %t155, ptr %l19, !tbaa !21
  br label %bb183
bb53:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb54, label %bb55
bb54:
  %t160 = load ptr, ptr %l85, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 18}
  %t163 = icmp eq i64 %t161, 7
  store i1 %t163, ptr %l86, !tbaa !21
  br label %bb55
bb55:
  %t164 = load i1, ptr %l86, !tbaa !21
  br i1 %t164, label %bb56, label %bb57
bb56:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Make", ptr %t172, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t178 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t171, { i64, ptr } %t175)
  store i1 %t178, ptr %l94
  br label %bb59
bb59:
  %t179 = load i1, ptr %l94, !tbaa !21
  br i1 %t179, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb63
bb61:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l6, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Make", ptr %t181, i32 0, i32 3
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t187 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t180, ptr %t184)
  store i1 %t187, ptr %l99
  br label %bb62
bb62:
  %t188 = load i1, ptr %l99, !tbaa !21
  store i1 %t188, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t189 = load i1, ptr %l95, !tbaa !21
  store i1 %t189, ptr %l19, !tbaa !21
  br label %bb183
bb64:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t191 = load ptr, ptr %l100, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb65, label %bb66
bb65:
  %t194 = load ptr, ptr %l100, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 18}
  %t197 = icmp eq i64 %t195, 8
  store i1 %t197, ptr %l101, !tbaa !21
  br label %bb66
bb66:
  %t198 = load i1, ptr %l101, !tbaa !21
  br i1 %t198, label %bb67, label %bb68
bb67:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t201, i32 0, i32 2
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l7, !tbaa !29
  br label %bb69
bb68:
  br label %bb75
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Collect", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t212 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t205, ptr %t209)
  store i1 %t212, ptr %l109
  br label %bb70
bb70:
  %t213 = load i1, ptr %l109, !tbaa !21
  br i1 %t213, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb74
bb72:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l7, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Collect", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %s7, ptr %t214, ptr %t218, ptr null)
  store i1 %t221, ptr %l114
  br label %bb73
bb73:
  %t222 = load i1, ptr %l114, !tbaa !21
  store i1 %t222, ptr %l110, !tbaa !21
  br label %bb74
bb74:
  %t223 = load i1, ptr %l110, !tbaa !21
  store i1 %t223, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb183
bb75:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t225 = load ptr, ptr %l115, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb76, label %bb77
bb76:
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 18}
  %t231 = icmp eq i64 %t229, 9
  store i1 %t231, ptr %l116, !tbaa !21
  br label %bb77
bb77:
  %t232 = load i1, ptr %l116, !tbaa !21
  br i1 %t232, label %bb78, label %bb79
bb78:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t235, i32 0, i32 4
  %t237 = load { i64, ptr }, ptr %t236
  store { i64, ptr } %t237, ptr %l8, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t243 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t239, { i64, ptr } %t240)
  store i1 %t243, ptr %l123
  br label %bb81
bb81:
  %t244 = load i1, ptr %l123, !tbaa !21
  store i1 %t244, ptr %l19, !tbaa !21
  br label %bb183
bb82:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t246 = load ptr, ptr %l124, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb83, label %bb84
bb83:
  %t249 = load ptr, ptr %l124, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 18}
  %t252 = icmp eq i64 %t250, 10
  store i1 %t252, ptr %l125, !tbaa !21
  br label %bb84
bb84:
  %t253 = load i1, ptr %l125, !tbaa !21
  br i1 %t253, label %bb85, label %bb86
bb85:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l9, !tbaa !29
  br label %bb87
bb86:
  br label %bb97
bb87:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l9, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Slice", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t267 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t260, ptr %t264)
  store i1 %t267, ptr %l133
  br label %bb88
bb88:
  %t268 = load i1, ptr %l133, !tbaa !21
  br i1 %t268, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb92
bb90:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l9, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Slice", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t277 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t269, ptr %t273)
  store i1 %t277, ptr %l139
  br label %bb91
bb91:
  %t278 = load i1, ptr %l139, !tbaa !21
  store i1 %t278, ptr %l134, !tbaa !21
  br label %bb92
bb92:
  %t279 = load i1, ptr %l134, !tbaa !21
  br i1 %t279, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb96
bb94:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l9, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Slice", ptr %t281, i32 0, i32 2
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t288 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t280, ptr %t284)
  store i1 %t288, ptr %l145
  br label %bb95
bb95:
  %t289 = load i1, ptr %l145, !tbaa !21
  store i1 %t289, ptr %l140, !tbaa !21
  br label %bb96
bb96:
  %t290 = load i1, ptr %l140, !tbaa !21
  store i1 %t290, ptr %l19, !tbaa !21
  br label %bb183
bb97:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t292 = load ptr, ptr %l146, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb98, label %bb99
bb98:
  %t295 = load ptr, ptr %l146, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 18}
  %t298 = icmp eq i64 %t296, 11
  store i1 %t298, ptr %l147, !tbaa !21
  br label %bb99
bb99:
  %t299 = load i1, ptr %l147, !tbaa !21
  br i1 %t299, label %bb100, label %bb101
bb100:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t302, i32 0, i32 2
  %t304 = load ptr, ptr %t303
  store ptr %t304, ptr %l10, !tbaa !29
  br label %bb102
bb101:
  br label %bb112
bb102:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l10, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Cond", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t314 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t306, ptr %t310)
  store i1 %t314, ptr %l156
  br label %bb103
bb103:
  %t315 = load i1, ptr %l156, !tbaa !21
  br i1 %t315, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb107
bb105:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l10, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Cond", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t323 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t323, ptr %l161
  br label %bb106
bb106:
  %t324 = load i1, ptr %l161, !tbaa !21
  store i1 %t324, ptr %l157, !tbaa !21
  br label %bb107
bb107:
  %t325 = load i1, ptr %l157, !tbaa !21
  br i1 %t325, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb111
bb109:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l10, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Cond", ptr %t327, i32 0, i32 2
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t334 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t326, ptr %t330)
  store i1 %t334, ptr %l167
  br label %bb110
bb110:
  %t335 = load i1, ptr %l167, !tbaa !21
  store i1 %t335, ptr %l162, !tbaa !21
  br label %bb111
bb111:
  %t336 = load i1, ptr %l162, !tbaa !21
  store i1 %t336, ptr %l19, !tbaa !21
  br label %bb183
bb112:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t338 = load ptr, ptr %l168, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb113, label %bb114
bb113:
  %t341 = load ptr, ptr %l168, !tbaa !29
  %t342 = load i64, ptr %t341, !range !{i64 0, i64 18}
  %t344 = icmp eq i64 %t342, 12
  store i1 %t344, ptr %l169, !tbaa !21
  br label %bb114
bb114:
  %t345 = load i1, ptr %l169, !tbaa !21
  br i1 %t345, label %bb115, label %bb116
bb115:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t348, i32 0, i32 2
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l11, !tbaa !29
  br label %bb117
bb116:
  br label %bb123
bb117:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l11, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Seq", ptr %t353, i32 0, i32 0
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  %t359 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t352, { i64, ptr } %t356)
  store i1 %t359, ptr %l177
  br label %bb118
bb118:
  %t360 = load i1, ptr %l177, !tbaa !21
  br i1 %t360, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb122
bb120:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l11, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Seq", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t368 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t361, ptr %t365)
  store i1 %t368, ptr %l182
  br label %bb121
bb121:
  %t369 = load i1, ptr %l182, !tbaa !21
  store i1 %t369, ptr %l178, !tbaa !21
  br label %bb122
bb122:
  %t370 = load i1, ptr %l178, !tbaa !21
  store i1 %t370, ptr %l19, !tbaa !21
  br label %bb183
bb123:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t372 = load ptr, ptr %l183, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb124, label %bb125
bb124:
  %t375 = load ptr, ptr %l183, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 13
  store i1 %t378, ptr %l184, !tbaa !21
  br label %bb125
bb125:
  %t379 = load i1, ptr %l184, !tbaa !21
  br i1 %t379, label %bb126, label %bb127
bb126:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l12, !tbaa !29
  br label %bb128
bb127:
  br label %bb144
bb128:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l12, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Match", ptr %t387, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t393 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t386, { i64, ptr } %t390)
  store i1 %t393, ptr %l192
  br label %bb129
bb129:
  %t394 = load i1, ptr %l192, !tbaa !21
  br i1 %t394, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb133
bb131:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l12, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Match", ptr %t396, i32 0, i32 1
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  %t402 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %t395, { i64, ptr } %t399)
  store i1 %t402, ptr %l197
  br label %bb132
bb132:
  %t403 = load i1, ptr %l197, !tbaa !21
  store i1 %t403, ptr %l193, !tbaa !21
  br label %bb133
bb133:
  %t404 = load i1, ptr %l193, !tbaa !21
  br i1 %t404, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb143
bb135:
  %t405 = load ptr, ptr %l12, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Match", ptr %t405, i32 0, i32 2
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = icmp eq ptr %t408, null
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb136, label %bb137
bb136:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l204, !tbaa !29
  %t415 = load ptr, ptr %l12, !tbaa !29
  %t417 = getelementptr %"compiler/typed:Match", ptr %t415, i32 0, i32 2
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = icmp eq ptr %t418, null
  br i1 %t420, label %bb138, label %bb139
bb137:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb142
bb138:
  call void @__olang_check_failed(ptr @olang_loc_b80660129801afa0_e660219d512f014)
  unreachable
bb139:
  br label %bb140
bb140:
  %t422 = load ptr, ptr %l12, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Match", ptr %t422, i32 0, i32 2
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t426 = load ptr, ptr %l204, !tbaa !29
  %t428 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %t426, ptr %t425)
  store i1 %t428, ptr %l210
  br label %bb141
bb141:
  %t429 = load i1, ptr %l210, !tbaa !21
  store i1 %t429, ptr %l203, !tbaa !21
  br label %bb142
bb142:
  %t430 = load i1, ptr %l203, !tbaa !21
  store i1 %t430, ptr %l198, !tbaa !21
  br label %bb143
bb143:
  %t431 = load i1, ptr %l198, !tbaa !21
  store i1 %t431, ptr %l19, !tbaa !21
  br label %bb183
bb144:
  %t432 = load ptr, ptr %l1, !tbaa !29
  store ptr %t432, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t433 = load ptr, ptr %l211, !tbaa !29
  %t434 = icmp ne ptr %t433, null
  br i1 %t434, label %bb145, label %bb146
bb145:
  %t436 = load ptr, ptr %l211, !tbaa !29
  %t437 = load i64, ptr %t436, !range !{i64 0, i64 18}
  %t439 = icmp eq i64 %t437, 14
  store i1 %t439, ptr %l212, !tbaa !21
  br label %bb146
bb146:
  %t440 = load i1, ptr %l212, !tbaa !21
  br i1 %t440, label %bb147, label %bb148
bb147:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [5 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t443, i32 0, i32 2
  %t445 = load ptr, ptr %t444
  store ptr %t445, ptr %l13, !tbaa !29
  br label %bb149
bb148:
  br label %bb168
bb149:
  %t447 = load ptr, ptr %l13, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Try", ptr %t447, i32 0, i32 2
  %t450 = load i1, ptr %t449, !tbaa !21
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb150, label %bb151
bb150:
  %t454 = load ptr, ptr %l13, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Try", ptr %t454, i32 0, i32 3
  %t457 = load i1, ptr %t456, !tbaa !21
  %t459 = xor i1 %t457, true
  store i1 %t459, ptr %l220, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb152
bb152:
  %t461 = load i1, ptr %l220, !tbaa !21
  br i1 %t461, label %bb153, label %bb154
bb153:
  %t462 = load ptr, ptr %l13, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Try", ptr %t462, i32 0, i32 4
  %t465 = load i1, ptr %t464, !tbaa !21
  store i1 %t465, ptr %l224, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb155
bb155:
  %t467 = load i1, ptr %l224, !tbaa !21
  br i1 %t467, label %bb156, label %bb157
bb156:
  %t468 = load ptr, ptr %l13, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Try", ptr %t468, i32 0, i32 1
  %t471 = load { i64, ptr }, ptr %t470, !tbaa !27
  %t473 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t471)
  store i1 %t473, ptr %l230
  br label %bb158
bb157:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb159
bb158:
  %t474 = load i1, ptr %l230, !tbaa !21
  %t475 = xor i1 %t474, true
  store i1 %t475, ptr %l227, !tbaa !21
  br label %bb159
bb159:
  %t477 = load i1, ptr %l227, !tbaa !21
  br i1 %t477, label %bb160, label %bb161
bb160:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb163
bb161:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l13, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Try", ptr %t479, i32 0, i32 0
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t485 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  store i1 %t485, ptr %l236
  br label %bb162
bb162:
  %t486 = load i1, ptr %l236, !tbaa !21
  store i1 %t486, ptr %l232, !tbaa !21
  br label %bb163
bb163:
  %t487 = load i1, ptr %l232, !tbaa !21
  br i1 %t487, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb167
bb165:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l13, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Try", ptr %t489, i32 0, i32 1
  %t492 = load { i64, ptr }, ptr %t491, !tbaa !27
  %t495 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t488, { i64, ptr } %t492)
  store i1 %t495, ptr %l241
  br label %bb166
bb166:
  %t496 = load i1, ptr %l241, !tbaa !21
  store i1 %t496, ptr %l237, !tbaa !21
  br label %bb167
bb167:
  %t497 = load i1, ptr %l237, !tbaa !21
  store i1 %t497, ptr %l19, !tbaa !21
  br label %bb183
bb168:
  %t498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t498, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t499 = load ptr, ptr %l242, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb169, label %bb170
bb169:
  %t502 = load ptr, ptr %l242, !tbaa !29
  %t503 = load i64, ptr %t502, !range !{i64 0, i64 18}
  %t505 = icmp eq i64 %t503, 16
  store i1 %t505, ptr %l243, !tbaa !21
  br label %bb170
bb170:
  %t506 = load i1, ptr %l243, !tbaa !21
  br i1 %t506, label %bb171, label %bb172
bb171:
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t509, i32 0, i32 2
  %t511 = load ptr, ptr %t510
  store ptr %t511, ptr %l14, !tbaa !29
  br label %bb173
bb172:
  br label %bb175
bb173:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load ptr, ptr %l14, !tbaa !29
  %t516 = getelementptr %"compiler/typed:Text", ptr %t514, i32 0, i32 0
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  %t520 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %t513, { i64, ptr } %t517)
  store i1 %t520, ptr %l251
  br label %bb174
bb174:
  %t521 = load i1, ptr %l251, !tbaa !21
  store i1 %t521, ptr %l19, !tbaa !21
  br label %bb183
bb175:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t523 = load ptr, ptr %l252, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb176, label %bb177
bb176:
  %t526 = load ptr, ptr %l252, !tbaa !29
  %t527 = load i64, ptr %t526, !range !{i64 0, i64 18}
  %t529 = icmp eq i64 %t527, 17
  store i1 %t529, ptr %l253, !tbaa !21
  br label %bb177
bb177:
  %t530 = load i1, ptr %l253, !tbaa !21
  br i1 %t530, label %bb178, label %bb179
bb178:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [5 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t533, i32 0, i32 2
  %t535 = load ptr, ptr %t534
  store ptr %t535, ptr %l15, !tbaa !29
  br label %bb180
bb179:
  br label %bb182
bb180:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load ptr, ptr %l15, !tbaa !29
  %t542 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t537, ptr %t538)
  store i1 %t542, ptr %l261
  br label %bb181
bb181:
  %t543 = load i1, ptr %l261, !tbaa !21
  store i1 %t543, ptr %l19, !tbaa !21
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba)
  unreachable
bb183:
  %t544 = load i1, ptr %l19, !tbaa !21
  store i1 %t544, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %l154 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i1
  %l164 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l175 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t11 = load ptr, ptr %l18, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l18, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l19, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 8
  store i1 %t26, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l23, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t29 = load ptr, ptr %l26, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 16
  store i1 %t35, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb123
bb18:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 5
  store i1 %t44, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l31, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l2, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/typed:leaveWalk", ptr %t52, i32 0, i32 0
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l39
  br label %bb24
bb24:
  %t59 = load i1, ptr %l39, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l13, !tbaa !21
  br label %bb123
bb25:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t63 = load ptr, ptr %l41, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb26, label %bb27
bb26:
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 17}
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb28, label %bb29
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l3, !tbaa !29
  br label %bb38
bb29:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t78 = load ptr, ptr %l47, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 17}
  %t84 = icmp eq i64 %t82, 2
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb32, label %bb33
bb32:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l3, !tbaa !29
  br label %bb38
bb33:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t93 = load ptr, ptr %l53, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb34, label %bb35
bb34:
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 17}
  %t99 = icmp eq i64 %t97, 15
  store i1 %t99, ptr %l54, !tbaa !21
  br label %bb35
bb35:
  %t100 = load i1, ptr %l54, !tbaa !21
  br i1 %t100, label %bb36, label %bb37
bb36:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr }, ptr %t103, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l3, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t112 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i1 %t112, ptr %l62
  br label %bb39
bb39:
  %t113 = load i1, ptr %l62, !tbaa !21
  store i1 %t113, ptr %l13, !tbaa !21
  br label %bb123
bb40:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb41, label %bb42
bb41:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 17}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t122 = load i1, ptr %l64, !tbaa !21
  br i1 %t122, label %bb43, label %bb44
bb43:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l4, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l5, !tbaa !29
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t139 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i1 %t139, ptr %l73
  br label %bb46
bb46:
  %t140 = load i1, ptr %l73, !tbaa !21
  br i1 %t140, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb50
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t146 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  store i1 %t146, ptr %l78
  br label %bb49
bb49:
  %t147 = load i1, ptr %l78, !tbaa !21
  store i1 %t147, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t148 = load i1, ptr %l74, !tbaa !21
  store i1 %t148, ptr %l13, !tbaa !21
  br label %bb123
bb51:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t150 = load ptr, ptr %l79, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb52, label %bb53
bb52:
  %t153 = load ptr, ptr %l79, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 17}
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb53
bb53:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb54, label %bb55
bb54:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l6, !tbaa !29
  br label %bb56
bb55:
  br label %bb66
bb56:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t172 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  store i1 %t172, ptr %l89
  br label %bb57
bb57:
  %t173 = load i1, ptr %l89, !tbaa !21
  br i1 %t173, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb61
bb59:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l6, !tbaa !29
  %t177 = getelementptr %"compiler/typed:If", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t182 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t174, ptr %t178)
  store i1 %t182, ptr %l95
  br label %bb60
bb60:
  %t183 = load i1, ptr %l95, !tbaa !21
  store i1 %t183, ptr %l90, !tbaa !21
  br label %bb61
bb61:
  %t184 = load i1, ptr %l90, !tbaa !21
  br i1 %t184, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb65
bb63:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr %"compiler/typed:If", ptr %t186, i32 0, i32 2
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t192 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t185, ptr %t189)
  store i1 %t192, ptr %l100
  br label %bb64
bb64:
  %t193 = load i1, ptr %l100, !tbaa !21
  store i1 %t193, ptr %l96, !tbaa !21
  br label %bb65
bb65:
  %t194 = load i1, ptr %l96, !tbaa !21
  store i1 %t194, ptr %l13, !tbaa !21
  br label %bb123
bb66:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t196 = load ptr, ptr %l101, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb67, label %bb68
bb67:
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 4
  store i1 %t202, ptr %l102, !tbaa !21
  br label %bb68
bb68:
  %t203 = load i1, ptr %l102, !tbaa !21
  br i1 %t203, label %bb69, label %bb70
bb69:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t206, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l7, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l8, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l7, !tbaa !29
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t222 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v1, ptr %t216, ptr %t217, ptr %t218)
  store i1 %t222, ptr %l112
  br label %bb72
bb72:
  %t223 = load i1, ptr %l112, !tbaa !21
  store i1 %t223, ptr %l13, !tbaa !21
  br label %bb123
bb73:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t225 = load ptr, ptr %l113, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb74, label %bb75
bb74:
  %t228 = load ptr, ptr %l113, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 17}
  %t231 = icmp eq i64 %t229, 9
  store i1 %t231, ptr %l114, !tbaa !21
  br label %bb75
bb75:
  %t232 = load i1, ptr %l114, !tbaa !21
  br i1 %t232, label %bb76, label %bb77
bb76:
  br label %bb82
bb77:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t234 = load ptr, ptr %l117, !tbaa !29
  %t235 = icmp ne ptr %t234, null
  br i1 %t235, label %bb78, label %bb79
bb78:
  %t237 = load ptr, ptr %l117, !tbaa !29
  %t238 = load i64, ptr %t237, !range !{i64 0, i64 17}
  %t240 = icmp eq i64 %t238, 10
  store i1 %t240, ptr %l118, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l118, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb123
bb83:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t243 = load ptr, ptr %l121, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb84, label %bb85
bb84:
  %t246 = load ptr, ptr %l121, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 17}
  %t249 = icmp eq i64 %t247, 11
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb85
bb85:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb86, label %bb87
bb86:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l9, !tbaa !29
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l9, !tbaa !29
  %t262 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i1 %t262, ptr %l130
  br label %bb89
bb89:
  %t263 = load i1, ptr %l130, !tbaa !21
  store i1 %t263, ptr %l13, !tbaa !21
  br label %bb123
bb90:
  %t264 = load ptr, ptr %l1, !tbaa !29
  store ptr %t264, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t265 = load ptr, ptr %l131, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb91, label %bb92
bb91:
  %t268 = load ptr, ptr %l131, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 17}
  %t271 = icmp eq i64 %t269, 12
  store i1 %t271, ptr %l132, !tbaa !21
  br label %bb92
bb92:
  %t272 = load i1, ptr %l132, !tbaa !21
  br i1 %t272, label %bb93, label %bb94
bb93:
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr }, ptr %t275, i32 0, i32 1
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l10, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l10, !tbaa !29
  %t284 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t279, ptr %t280)
  store i1 %t284, ptr %l140
  br label %bb96
bb96:
  %t285 = load i1, ptr %l140, !tbaa !21
  store i1 %t285, ptr %l13, !tbaa !21
  br label %bb123
bb97:
  %t286 = load ptr, ptr %l1, !tbaa !29
  store ptr %t286, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t287 = load ptr, ptr %l141, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb98, label %bb99
bb98:
  %t290 = load ptr, ptr %l141, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 13
  store i1 %t293, ptr %l142, !tbaa !21
  br label %bb99
bb99:
  %t294 = load i1, ptr %l142, !tbaa !21
  br i1 %t294, label %bb100, label %bb101
bb100:
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l11, !tbaa !29
  br label %bb102
bb101:
  br label %bb115
bb102:
  %t301 = load ptr, ptr %l11, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Join", ptr %t301, i32 0, i32 1
  %t304 = load i1, ptr %t303, !tbaa !21
  br i1 %t304, label %bb103, label %bb104
bb103:
  %t306 = load ptr, ptr %l11, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Join", ptr %t306, i32 0, i32 2
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t309)
  store i1 %t311, ptr %l152
  br label %bb105
bb104:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb106
bb105:
  %t312 = load i1, ptr %l152, !tbaa !21
  %t313 = xor i1 %t312, true
  store i1 %t313, ptr %l149, !tbaa !21
  br label %bb106
bb106:
  %t315 = load i1, ptr %l149, !tbaa !21
  br i1 %t315, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb110
bb108:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l11, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Join", ptr %t317, i32 0, i32 0
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t324 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t324, ptr %l159
  br label %bb109
bb109:
  %t325 = load i1, ptr %l159, !tbaa !21
  store i1 %t325, ptr %l154, !tbaa !21
  br label %bb110
bb110:
  %t326 = load i1, ptr %l154, !tbaa !21
  br i1 %t326, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb114
bb112:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l11, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Join", ptr %t328, i32 0, i32 2
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t334 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t327, { i64, ptr } %t331)
  store i1 %t334, ptr %l164
  br label %bb113
bb113:
  %t335 = load i1, ptr %l164, !tbaa !21
  store i1 %t335, ptr %l160, !tbaa !21
  br label %bb114
bb114:
  %t336 = load i1, ptr %l160, !tbaa !21
  store i1 %t336, ptr %l13, !tbaa !21
  br label %bb123
bb115:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t338 = load ptr, ptr %l165, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb116, label %bb117
bb116:
  %t341 = load ptr, ptr %l165, !tbaa !29
  %t342 = load i64, ptr %t341, !range !{i64 0, i64 17}
  %t344 = icmp eq i64 %t342, 14
  store i1 %t344, ptr %l166, !tbaa !21
  br label %bb117
bb117:
  %t345 = load i1, ptr %l166, !tbaa !21
  br i1 %t345, label %bb118, label %bb119
bb118:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", ptr }, ptr %t348, i32 0, i32 1
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l12, !tbaa !29
  br label %bb120
bb119:
  br label %bb122
bb120:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l12, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Spawn", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t360 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t352, ptr %t356)
  store i1 %t360, ptr %l175
  br label %bb121
bb121:
  %t361 = load i1, ptr %l175, !tbaa !21
  store i1 %t361, ptr %l13, !tbaa !21
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0)
  unreachable
bb123:
  %t362 = load i1, ptr %l13, !tbaa !21
  store i1 %t362, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  br label %bb36
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 5}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l9, !tbaa !27
  br label %bb36
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 5}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l27, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { ptr }, ptr %t67, i32 0, i32 0
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t71, ptr %t72)
  store { i64, ptr } %t76, ptr %l35
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t85 = load ptr, ptr %l37, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 5}
  %t91 = icmp eq i64 %t89, 4
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l38, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { i32, i32 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 2}
  store i32 %t97, ptr %l5
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { i32, i32 }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l6, !tbaa !23
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i32, ptr %l5, !range !{i32 0, i32 2}
  store i32 %t105, ptr %l45
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %s8, ptr %l45, i64 0)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %s8
  %t108 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t109 = load i64, ptr %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t107, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l47, !tbaa !27
  %t113 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t114 = load ptr, ptr %t113
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %sbgrew.116, label %sbdone.117
sbgrew.116:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.117
sbdone.117:
  %t118 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t124)
  store { i64, ptr } %t126, ptr %l49
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/typed:printer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l51, !tbaa !29
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load ptr, ptr %l51, !tbaa !29
  %t133 = call ptr @__olang_scope_of(ptr %t132, ptr null)
  %t134 = ptrtoint ptr %t133 to i64
  %t136 = inttoptr i64 %t134 to ptr
  %t137 = load ptr, ptr %l51, !tbaa !29
  %t139 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t136, ptr %s7, ptr %t137, i32 %t131)
  store { i64, ptr } %t139, ptr %l54
  br label %bb27
bb27:
  %t140 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb28:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t157 = load ptr, ptr %l56, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb29, label %bb30
bb29:
  %t160 = load ptr, ptr %l56, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 5}
  %t163 = icmp eq i64 %t161, 3
  store i1 %t163, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t164 = load i1, ptr %l57, !tbaa !21
  br i1 %t164, label %bb31, label %bb32
bb31:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { i32, i64, i32 }, ptr %t167, i32 0, i32 0
  %t169 = load i32, ptr %t168
  store i32 %t169, ptr %l7, !tbaa !23
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { i32, i64, i32 }, ptr %t173, i32 0, i32 1
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l8, !tbaa !24
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/typed:printer", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  store ptr %t180, ptr %l65, !tbaa !29
  %t181 = load i32, ptr %l7, !tbaa !23
  %t182 = load ptr, ptr %l65, !tbaa !29
  %t183 = call ptr @__olang_scope_of(ptr %t182, ptr null)
  %t184 = ptrtoint ptr %t183 to i64
  %t186 = inttoptr i64 %t184 to ptr
  %t187 = load ptr, ptr %l65, !tbaa !29
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t186, ptr %s10, ptr %t187, i32 %t181)
  store { i64, ptr } %t189, ptr %l68
  br label %bb34
bb34:
  %t190 = load i64, ptr %l8, !tbaa !24
  %t191 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t193 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t201 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t191, i64 %t192)
  %t204 = getelementptr i8, ptr %t203, i64 %t192
  call void @olang_textcopy(ptr %t204, ptr %t194, i64 %t195)
  %t205 = getelementptr i8, ptr %t204, i64 %t195
  call void @olang_textcopy(ptr %t205, ptr %t197, i64 %t198)
  %t206 = getelementptr i8, ptr %t205, i64 %t198
  %t207 = call i64 @__olang_fmt_i64(ptr %t206, i64 %t190)
  %t208 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t203, 1
  store { i64, ptr } %t209, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22)
  unreachable
bb36:
  %t211 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t211, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i64
  %l159 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l187 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i64
  %l197 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l201 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i64
  %l208 = alloca i32
  %l210 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l216 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i64
  %l226 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l230 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca i1
  %l257 = alloca ptr
  %l258 = alloca i64
  %l261 = alloca { i64, ptr }
  %l269 = alloca ptr
  %l270 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i64
  %l281 = alloca { i64, ptr }
  %l286 = alloca ptr
  %l287 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i64
  %l297 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l301 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i64
  %l308 = alloca ptr
  %l313 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l33, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l34, !tbaa !24
  %t24 = load i32, ptr %l3, !tbaa !23
  store i32 %t24, ptr %l35, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t25, ptr %t26)
  store { i64, ptr } %t30, ptr %l39
  br label %bb6
bb6:
  %t31 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t33 = load i32, ptr %l35, !tbaa !23
  %t34 = sext i32 %t33 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t31, i64 %t32)
  %t45 = getelementptr i8, ptr %t44, i64 %t32
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t34)
  %t47 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s1, ptr %t58, i64 %t59, { i64, ptr } %t57)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb163
bb8:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb9, label %bb10
bb9:
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 17}
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l43, !tbaa !21
  br label %bb10
bb10:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb11, label %bb12
bb11:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l50, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %l51, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s3, ptr %t84, ptr %t85)
  store { i64, ptr } %t88, ptr %l54
  br label %bb14
bb14:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %t89, ptr %t90)
  store { i64, ptr } %t94, ptr %l58
  br label %bb15
bb15:
  %t95 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t97 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t95, i64 %t96)
  %t109 = getelementptr i8, ptr %t108, i64 %t96
  call void @olang_textcopy(ptr %t109, ptr %t98, i64 %t99)
  %t110 = getelementptr i8, ptr %t109, i64 %t99
  call void @olang_textcopy(ptr %t110, ptr %t101, i64 %t102)
  %t111 = getelementptr i8, ptr %t110, i64 %t102
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t108, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load ptr, ptr %l50, !tbaa !29
  %t122 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s3, ptr %t121, i64 %t122, { i64, ptr } %t120)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb163
bb17:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t125 = load ptr, ptr %l61, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb18, label %bb19
bb18:
  %t128 = load ptr, ptr %l61, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 17}
  %t131 = icmp eq i64 %t129, 2
  store i1 %t131, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t132 = load i1, ptr %l62, !tbaa !21
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l67, !tbaa !29
  %t140 = load i64, ptr %l2, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t141, ptr %t142)
  store { i64, ptr } %t146, ptr %l72
  br label %bb23
bb23:
  %t147 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t149 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l67, !tbaa !29
  %t165 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s5, ptr %t164, i64 %t165, { i64, ptr } %t163)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb163
bb25:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t168 = load ptr, ptr %l75, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 3
  store i1 %t174, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t175 = load i1, ptr %l76, !tbaa !21
  br i1 %t175, label %bb28, label %bb29
bb28:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l81, !tbaa !29
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l82, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/typed:If", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t184, ptr %t188)
  store { i64, ptr } %t192, ptr %l87
  br label %bb31
bb31:
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t195 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = getelementptr i8, ptr %t199, i64 %t194
  call void @olang_textcopy(ptr %t200, ptr %t196, i64 %t197)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load ptr, ptr %l81, !tbaa !29
  %t211 = load i64, ptr %l82, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s7, ptr %t210, i64 %t211, { i64, ptr } %t209)
  br label %bb32
bb32:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:If", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load i64, ptr %l2, !tbaa !24
  %t220 = add i64 %t218, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t213, ptr %t217, i64 %t220)
  br label %bb33
bb33:
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:If", ptr %t224, i32 0, i32 2
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s9, ptr %t233, i64 %t234, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l101, !tbaa !29
  %t238 = load ptr, ptr %l8, !tbaa !29
  %t240 = getelementptr %"compiler/typed:If", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_7b432bbe8f05f1d7_7deffd42aa472253)
  unreachable
bb38:
  br label %bb39
bb39:
  %t245 = load ptr, ptr %l8, !tbaa !29
  %t247 = getelementptr %"compiler/typed:If", ptr %t245, i32 0, i32 2
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load i64, ptr %l2, !tbaa !24
  %t251 = add i64 %t249, 1
  %t252 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t252, ptr %t248, i64 %t251)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb163
bb42:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t256 = load ptr, ptr %l109, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb43, label %bb44
bb43:
  %t259 = load ptr, ptr %l109, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 17}
  %t262 = icmp eq i64 %t260, 4
  store i1 %t262, ptr %l110, !tbaa !21
  br label %bb44
bb44:
  %t263 = load i1, ptr %l110, !tbaa !21
  br i1 %t263, label %bb45, label %bb46
bb45:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t266, i32 0, i32 1
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l9, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t272, i32 0, i32 2
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s10, ptr %t276, i64 %t277, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb48
bb48:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l9, !tbaa !29
  %t282 = load i64, ptr %l2, !tbaa !24
  %t284 = add i64 %t282, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t280, ptr %t281, i64 %t284)
  br label %bb49
bb49:
  %t288 = load ptr, ptr %l10, !tbaa !29
  %t290 = icmp eq ptr %t288, null
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s11, ptr %t294, i64 %t295, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t300 = load i64, ptr %l2, !tbaa !24
  %t302 = add i64 %t300, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t298, ptr %t299, i64 %t302)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb163
bb55:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t307 = load ptr, ptr %l132, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb56, label %bb57
bb56:
  %t310 = load ptr, ptr %l132, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 5
  store i1 %t313, ptr %l133, !tbaa !21
  br label %bb57
bb57:
  %t314 = load i1, ptr %l133, !tbaa !21
  br i1 %t314, label %bb58, label %bb59
bb58:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t317, i32 0, i32 1
  %t319 = load i32, ptr %t318, !range !{i32 0, i32 2}
  store i32 %t319, ptr %l11
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t323, i32 0, i32 2
  %t325 = load i32, ptr %t324
  store i32 %t325, ptr %l12, !tbaa !23
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l140, !tbaa !29
  %t328 = load i64, ptr %l2, !tbaa !24
  store i64 %t328, ptr %l141, !tbaa !24
  %t329 = load i32, ptr %l11, !range !{i32 0, i32 2}
  %t331 = trunc i64 0 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb63:
  %t334 = load i32, ptr %l12, !tbaa !23
  %t335 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t342 = sext i32 %t334 to i64
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t344 = add i64 %t340, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t336, i64 %t337)
  %t346 = getelementptr i8, ptr %t345, i64 %t337
  call void @olang_textcopy(ptr %t346, ptr %t338, i64 %t339)
  %t347 = getelementptr i8, ptr %t346, i64 %t339
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t342)
  %t349 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t345, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l140, !tbaa !29
  %t359 = load i64, ptr %l141, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s12, ptr %t358, i64 %t359, { i64, ptr } %t357)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb163
bb65:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t362 = load ptr, ptr %l148, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb66, label %bb67
bb66:
  %t365 = load ptr, ptr %l148, !tbaa !29
  %t366 = load i64, ptr %t365, !range !{i64 0, i64 17}
  %t368 = icmp eq i64 %t366, 6
  store i1 %t368, ptr %l149, !tbaa !21
  br label %bb67
bb67:
  %t369 = load i1, ptr %l149, !tbaa !21
  br i1 %t369, label %bb68, label %bb69
bb68:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr }, ptr %t372, i32 0, i32 1
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l154, !tbaa !29
  %t377 = load i64, ptr %l2, !tbaa !24
  store i64 %t377, ptr %l155, !tbaa !24
  %t378 = load ptr, ptr %l13, !tbaa !29
  %t380 = icmp eq ptr %t378, null
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb71, label %bb72
bb71:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l13, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s14, ptr %t384, ptr %t385)
  store { i64, ptr } %t389, ptr %l163
  br label %bb73
bb72:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l159, !tbaa !27
  br label %bb74
bb73:
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t392 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t390, i64 %t391)
  %t397 = getelementptr i8, ptr %t396, i64 %t391
  call void @olang_textcopy(ptr %t397, ptr %t393, i64 %t394)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l159, !tbaa !27
  br label %bb74
bb74:
  %t408 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t410 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t413)
  call void @olang_textcopy(ptr %t414, ptr %t408, i64 %t409)
  %t415 = getelementptr i8, ptr %t414, i64 %t409
  call void @olang_textcopy(ptr %t415, ptr %t411, i64 %t412)
  %t416 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t414, 1
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = extractvalue { i64, ptr } %t417, 1
  %t421 = mul i64 %t419, 1
  %t422 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t422, ptr %t420, i64 %t421, i1 false)
  %t423 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  %t425 = load ptr, ptr %l154, !tbaa !29
  %t426 = load i64, ptr %l155, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s14, ptr %t425, i64 %t426, { i64, ptr } %t424)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb163
bb76:
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t429 = load ptr, ptr %l168, !tbaa !29
  %t430 = icmp ne ptr %t429, null
  br i1 %t430, label %bb77, label %bb78
bb77:
  %t432 = load ptr, ptr %l168, !tbaa !29
  %t433 = load i64, ptr %t432, !range !{i64 0, i64 17}
  %t435 = icmp eq i64 %t433, 7
  store i1 %t435, ptr %l169, !tbaa !21
  br label %bb78
bb78:
  %t436 = load i1, ptr %l169, !tbaa !21
  br i1 %t436, label %bb79, label %bb80
bb79:
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [3 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t439, i32 0, i32 1
  %t441 = load i32, ptr %t440
  store i32 %t441, ptr %l14, !tbaa !23
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [3 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t445, i32 0, i32 2
  %t447 = load i64, ptr %t446
  store i64 %t447, ptr %l15, !tbaa !24
  br label %bb81
bb80:
  br label %bb84
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l176, !tbaa !29
  %t450 = load i64, ptr %l2, !tbaa !24
  store i64 %t450, ptr %l177, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/typed:printer", ptr %t451, i32 0, i32 0
  %t454 = load ptr, ptr %t453, !tbaa !29
  store ptr %t454, ptr %l179, !tbaa !29
  %t455 = load i32, ptr %l14, !tbaa !23
  %t456 = load ptr, ptr %l179, !tbaa !29
  %t457 = call ptr @__olang_scope_of(ptr %t456, ptr null)
  %t458 = ptrtoint ptr %t457 to i64
  %t460 = inttoptr i64 %t458 to ptr
  %t461 = load ptr, ptr %l179, !tbaa !29
  %t463 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t460, ptr %s17, ptr %t461, i32 %t455)
  store { i64, ptr } %t463, ptr %l182
  br label %bb82
bb82:
  %t464 = load i64, ptr %l15, !tbaa !24
  %t465 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t467 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = add i64 %t466, %t469
  %t471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t473 = add i64 %t470, %t472
  %t475 = call i64 @__olang_fmt_i64(ptr null, i64 %t464)
  %t476 = add i64 %t473, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t465, i64 %t466)
  %t478 = getelementptr i8, ptr %t477, i64 %t466
  call void @olang_textcopy(ptr %t478, ptr %t468, i64 %t469)
  %t479 = getelementptr i8, ptr %t478, i64 %t469
  call void @olang_textcopy(ptr %t479, ptr %t471, i64 %t472)
  %t480 = getelementptr i8, ptr %t479, i64 %t472
  %t481 = call i64 @__olang_fmt_i64(ptr %t480, i64 %t464)
  %t482 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t477, 1
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t486 = extractvalue { i64, ptr } %t483, 1
  %t487 = mul i64 %t485, 1
  %t488 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t487)
  call void @llvm.memcpy.p0.p0.i64(ptr %t488, ptr %t486, i64 %t487, i1 false)
  %t489 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t488, 1
  %t491 = load ptr, ptr %l176, !tbaa !29
  %t492 = load i64, ptr %l177, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s17, ptr %t491, i64 %t492, { i64, ptr } %t490)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb163
bb84:
  %t494 = load ptr, ptr %l1, !tbaa !29
  store ptr %t494, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t495 = load ptr, ptr %l186, !tbaa !29
  %t496 = icmp ne ptr %t495, null
  br i1 %t496, label %bb85, label %bb86
bb85:
  %t498 = load ptr, ptr %l186, !tbaa !29
  %t499 = load i64, ptr %t498, !range !{i64 0, i64 17}
  %t501 = icmp eq i64 %t499, 8
  store i1 %t501, ptr %l187, !tbaa !21
  br label %bb86
bb86:
  %t502 = load i1, ptr %l187, !tbaa !21
  br i1 %t502, label %bb87, label %bb88
bb87:
  %t503 = load ptr, ptr %l1, !tbaa !29
  %t505 = getelementptr { i64, [3 x i64] }, ptr %t503, i32 0, i32 1
  %t506 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t505, i32 0, i32 1
  %t507 = load ptr, ptr %t506
  store ptr %t507, ptr %l16, !tbaa !29
  br label %bb89
bb88:
  br label %bb92
bb89:
  store %olang.scope zeroinitializer, ptr %s19
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l192, !tbaa !29
  %t510 = load i64, ptr %l2, !tbaa !24
  store i64 %t510, ptr %l193, !tbaa !24
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load ptr, ptr %l16, !tbaa !29
  %t516 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %t511, ptr %t512)
  store { i64, ptr } %t516, ptr %l197
  br label %bb90
bb90:
  %t517 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t519 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 1
  %t521 = extractvalue { i64, ptr } %t519, 0
  %t522 = add i64 %t518, %t521
  %t523 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t522)
  call void @olang_textcopy(ptr %t523, ptr %t517, i64 %t518)
  %t524 = getelementptr i8, ptr %t523, i64 %t518
  call void @olang_textcopy(ptr %t524, ptr %t520, i64 %t521)
  %t525 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t523, 1
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t529 = extractvalue { i64, ptr } %t526, 1
  %t530 = mul i64 %t528, 1
  %t531 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t530)
  call void @llvm.memcpy.p0.p0.i64(ptr %t531, ptr %t529, i64 %t530, i1 false)
  %t532 = insertvalue { i64, ptr } undef, i64 %t528, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t531, 1
  %t534 = load ptr, ptr %l192, !tbaa !29
  %t535 = load i64, ptr %l193, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s19, ptr %t534, i64 %t535, { i64, ptr } %t533)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb163
bb92:
  %t537 = load ptr, ptr %l1, !tbaa !29
  store ptr %t537, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t538 = load ptr, ptr %l200, !tbaa !29
  %t539 = icmp ne ptr %t538, null
  br i1 %t539, label %bb93, label %bb94
bb93:
  %t541 = load ptr, ptr %l200, !tbaa !29
  %t542 = load i64, ptr %t541, !range !{i64 0, i64 17}
  %t544 = icmp eq i64 %t542, 9
  store i1 %t544, ptr %l201, !tbaa !21
  br label %bb94
bb94:
  %t545 = load i1, ptr %l201, !tbaa !21
  br i1 %t545, label %bb95, label %bb96
bb95:
  %t546 = load ptr, ptr %l1, !tbaa !29
  %t548 = getelementptr { i64, [3 x i64] }, ptr %t546, i32 0, i32 1
  %t549 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t548, i32 0, i32 1
  %t550 = load i32, ptr %t549, !range !{i32 0, i32 2}
  store i32 %t550, ptr %l17
  br label %bb97
bb96:
  br label %bb101
bb97:
  store %olang.scope zeroinitializer, ptr %s21
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l206, !tbaa !29
  %t553 = load i64, ptr %l2, !tbaa !24
  store i64 %t553, ptr %l207, !tbaa !24
  %t554 = load i32, ptr %l17, !range !{i32 0, i32 2}
  store i32 %t554, ptr %l208
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %s22, ptr %l208, i64 0)
  br label %bb98
bb98:
  %t556 = load ptr, ptr %s22
  %t557 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t558 = load i64, ptr %t557
  %t559 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t558)
  call void @olang_textcopy(ptr %t559, ptr %t556, i64 %t558)
  %t560 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  store { i64, ptr } %t561, ptr %l210, !tbaa !27
  %t562 = getelementptr %olang.builder, ptr %s22, i32 0, i32 3
  %t563 = load ptr, ptr %t562
  %t564 = icmp ne ptr %t563, null
  br i1 %t564, label %sbgrew.565, label %sbdone.566
sbgrew.565:
  call void @__olang_sb_done(ptr %s22)
  br label %sbdone.566
sbdone.566:
  %t567 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  %t569 = extractvalue { i64, ptr } %t567, 1
  %t570 = mul i64 %t568, 1
  %t571 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t570)
  call void @llvm.memcpy.p0.p0.i64(ptr %t571, ptr %t569, i64 %t570, i1 false)
  %t572 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  %t575 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s21, ptr %s21, { i64, ptr } %t573)
  store { i64, ptr } %t575, ptr %l212
  br label %bb99
bb99:
  %t576 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t578 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t581 = add i64 %t577, %t580
  %t582 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t581)
  call void @olang_textcopy(ptr %t582, ptr %t576, i64 %t577)
  %t583 = getelementptr i8, ptr %t582, i64 %t577
  call void @olang_textcopy(ptr %t583, ptr %t579, i64 %t580)
  %t584 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t582, 1
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t588 = extractvalue { i64, ptr } %t585, 1
  %t589 = mul i64 %t587, 1
  %t590 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t588, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  %t593 = load ptr, ptr %l206, !tbaa !29
  %t594 = load i64, ptr %l207, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s21, ptr %t593, i64 %t594, { i64, ptr } %t592)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s21)
  br label %bb163
bb101:
  %t596 = load ptr, ptr %l1, !tbaa !29
  store ptr %t596, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t597 = load ptr, ptr %l215, !tbaa !29
  %t598 = icmp ne ptr %t597, null
  br i1 %t598, label %bb102, label %bb103
bb102:
  %t600 = load ptr, ptr %l215, !tbaa !29
  %t601 = load i64, ptr %t600, !range !{i64 0, i64 17}
  %t603 = icmp eq i64 %t601, 10
  store i1 %t603, ptr %l216, !tbaa !21
  br label %bb103
bb103:
  %t604 = load i1, ptr %l216, !tbaa !21
  br i1 %t604, label %bb104, label %bb105
bb104:
  %t605 = load ptr, ptr %l1, !tbaa !29
  %t607 = getelementptr { i64, [3 x i64] }, ptr %t605, i32 0, i32 1
  %t608 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t607, i32 0, i32 1
  %t609 = load ptr, ptr %t608
  store ptr %t609, ptr %l18, !tbaa !29
  br label %bb106
bb105:
  br label %bb109
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l221, !tbaa !29
  %t612 = load i64, ptr %l2, !tbaa !24
  store i64 %t612, ptr %l222, !tbaa !24
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load ptr, ptr %l18, !tbaa !29
  %t618 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s24, ptr %t613, ptr %t614)
  store { i64, ptr } %t618, ptr %l226
  br label %bb107
bb107:
  %t619 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t621 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t621, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t624 = add i64 %t620, %t623
  %t625 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t624)
  call void @olang_textcopy(ptr %t625, ptr %t619, i64 %t620)
  %t626 = getelementptr i8, ptr %t625, i64 %t620
  call void @olang_textcopy(ptr %t626, ptr %t622, i64 %t623)
  %t627 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t625, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = extractvalue { i64, ptr } %t628, 1
  %t632 = mul i64 %t630, 1
  %t633 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t632)
  call void @llvm.memcpy.p0.p0.i64(ptr %t633, ptr %t631, i64 %t632, i1 false)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  %t636 = load ptr, ptr %l221, !tbaa !29
  %t637 = load i64, ptr %l222, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s24, ptr %t636, i64 %t637, { i64, ptr } %t635)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s24)
  br label %bb163
bb109:
  %t639 = load ptr, ptr %l1, !tbaa !29
  store ptr %t639, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t640 = load ptr, ptr %l229, !tbaa !29
  %t641 = icmp ne ptr %t640, null
  br i1 %t641, label %bb110, label %bb111
bb110:
  %t643 = load ptr, ptr %l229, !tbaa !29
  %t644 = load i64, ptr %t643, !range !{i64 0, i64 17}
  %t646 = icmp eq i64 %t644, 11
  store i1 %t646, ptr %l230, !tbaa !21
  br label %bb111
bb111:
  %t647 = load i1, ptr %l230, !tbaa !21
  br i1 %t647, label %bb112, label %bb113
bb112:
  %t648 = load ptr, ptr %l1, !tbaa !29
  %t650 = getelementptr { i64, [3 x i64] }, ptr %t648, i32 0, i32 1
  %t651 = getelementptr { %"compiler/source:Span", ptr }, ptr %t650, i32 0, i32 1
  %t652 = load ptr, ptr %t651
  store ptr %t652, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load ptr, ptr %l19, !tbaa !29
  %t656 = load i64, ptr %l2, !tbaa !24
  %t658 = add i64 %t656, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t654, ptr %t655, i64 %t658)
  br label %bb115
bb115:
  br label %bb163
bb116:
  %t662 = load ptr, ptr %l1, !tbaa !29
  store ptr %t662, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t663 = load ptr, ptr %l239, !tbaa !29
  %t664 = icmp ne ptr %t663, null
  br i1 %t664, label %bb117, label %bb118
bb117:
  %t666 = load ptr, ptr %l239, !tbaa !29
  %t667 = load i64, ptr %t666, !range !{i64 0, i64 17}
  %t669 = icmp eq i64 %t667, 12
  store i1 %t669, ptr %l240, !tbaa !21
  br label %bb118
bb118:
  %t670 = load i1, ptr %l240, !tbaa !21
  br i1 %t670, label %bb119, label %bb120
bb119:
  %t671 = load ptr, ptr %l1, !tbaa !29
  %t673 = getelementptr { i64, [3 x i64] }, ptr %t671, i32 0, i32 1
  %t674 = getelementptr { %"compiler/source:Span", ptr }, ptr %t673, i32 0, i32 1
  %t675 = load ptr, ptr %t674
  store ptr %t675, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb124
bb121:
  store %olang.scope zeroinitializer, ptr %s27
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s27, ptr %t677, i64 %t678, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb122
bb122:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load ptr, ptr %l20, !tbaa !29
  %t683 = load i64, ptr %l2, !tbaa !24
  %t685 = add i64 %t683, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t681, ptr %t682, i64 %t685)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb163
bb124:
  %t689 = load ptr, ptr %l1, !tbaa !29
  store ptr %t689, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t690 = load ptr, ptr %l251, !tbaa !29
  %t691 = icmp ne ptr %t690, null
  br i1 %t691, label %bb125, label %bb126
bb125:
  %t693 = load ptr, ptr %l251, !tbaa !29
  %t694 = load i64, ptr %t693, !range !{i64 0, i64 17}
  %t696 = icmp eq i64 %t694, 13
  store i1 %t696, ptr %l252, !tbaa !21
  br label %bb126
bb126:
  %t697 = load i1, ptr %l252, !tbaa !21
  br i1 %t697, label %bb127, label %bb128
bb127:
  %t698 = load ptr, ptr %l1, !tbaa !29
  %t700 = getelementptr { i64, [3 x i64] }, ptr %t698, i32 0, i32 1
  %t701 = getelementptr { %"compiler/source:Span", ptr }, ptr %t700, i32 0, i32 1
  %t702 = load ptr, ptr %t701
  store ptr %t702, ptr %l21, !tbaa !29
  br label %bb129
bb128:
  br label %bb135
bb129:
  store %olang.scope zeroinitializer, ptr %s28
  %t704 = load ptr, ptr %l0, !tbaa !29
  store ptr %t704, ptr %l257, !tbaa !29
  %t705 = load i64, ptr %l2, !tbaa !24
  store i64 %t705, ptr %l258, !tbaa !24
  %t706 = load ptr, ptr %l21, !tbaa !29
  %t708 = getelementptr %"compiler/typed:Join", ptr %t706, i32 0, i32 1
  %t709 = load i1, ptr %t708, !tbaa !21
  br i1 %t709, label %bb130, label %bb131
bb130:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb132
bb131:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb132
bb132:
  %t711 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t712 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t713 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t714 = extractvalue { i64, ptr } %t713, 1
  %t715 = extractvalue { i64, ptr } %t713, 0
  %t716 = add i64 %t712, %t715
  %t717 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t716)
  call void @olang_textcopy(ptr %t717, ptr %t711, i64 %t712)
  %t718 = getelementptr i8, ptr %t717, i64 %t712
  call void @olang_textcopy(ptr %t718, ptr %t714, i64 %t715)
  %t719 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t717, 1
  %t722 = extractvalue { i64, ptr } %t720, 0
  %t723 = extractvalue { i64, ptr } %t720, 1
  %t724 = mul i64 %t722, 1
  %t725 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t724)
  call void @llvm.memcpy.p0.p0.i64(ptr %t725, ptr %t723, i64 %t724, i1 false)
  %t726 = insertvalue { i64, ptr } undef, i64 %t722, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  %t728 = load ptr, ptr %l257, !tbaa !29
  %t729 = load i64, ptr %l258, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s28, ptr %t728, i64 %t729, { i64, ptr } %t727)
  br label %bb133
bb133:
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load ptr, ptr %l21, !tbaa !29
  %t734 = getelementptr %"compiler/typed:Join", ptr %t732, i32 0, i32 0
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t736 = load i64, ptr %l2, !tbaa !24
  %t738 = add i64 %t736, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t731, ptr %t735, i64 %t738)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb163
bb135:
  %t742 = load ptr, ptr %l1, !tbaa !29
  store ptr %t742, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t743 = load ptr, ptr %l269, !tbaa !29
  %t744 = icmp ne ptr %t743, null
  br i1 %t744, label %bb136, label %bb137
bb136:
  %t746 = load ptr, ptr %l269, !tbaa !29
  %t747 = load i64, ptr %t746, !range !{i64 0, i64 17}
  %t749 = icmp eq i64 %t747, 14
  store i1 %t749, ptr %l270, !tbaa !21
  br label %bb137
bb137:
  %t750 = load i1, ptr %l270, !tbaa !21
  br i1 %t750, label %bb138, label %bb139
bb138:
  %t751 = load ptr, ptr %l1, !tbaa !29
  %t753 = getelementptr { i64, [3 x i64] }, ptr %t751, i32 0, i32 1
  %t754 = getelementptr { %"compiler/source:Span", ptr }, ptr %t753, i32 0, i32 1
  %t755 = load ptr, ptr %t754
  store ptr %t755, ptr %l22, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  store %olang.scope zeroinitializer, ptr %s30
  %t757 = load ptr, ptr %l0, !tbaa !29
  store ptr %t757, ptr %l275, !tbaa !29
  %t758 = load i64, ptr %l2, !tbaa !24
  store i64 %t758, ptr %l276, !tbaa !24
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t760 = load ptr, ptr %l22, !tbaa !29
  %t762 = getelementptr %"compiler/typed:Spawn", ptr %t760, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !29
  %t767 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s30, ptr %t759, ptr %t763)
  store { i64, ptr } %t767, ptr %l281
  br label %bb141
bb141:
  %t768 = load ptr, ptr %l22, !tbaa !29
  %t770 = getelementptr %"compiler/typed:Spawn", ptr %t768, i32 0, i32 3
  %t771 = load i32, ptr %t770, !tbaa !23
  %t772 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t773 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t774 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t775 = extractvalue { i64, ptr } %t774, 1
  %t776 = extractvalue { i64, ptr } %t774, 0
  %t777 = add i64 %t773, %t776
  %t778 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t779 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t780 = add i64 %t777, %t779
  %t782 = sext i32 %t771 to i64
  %t783 = call i64 @__olang_fmt_i64(ptr null, i64 %t782)
  %t784 = add i64 %t780, %t783
  %t785 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t784)
  call void @olang_textcopy(ptr %t785, ptr %t772, i64 %t773)
  %t786 = getelementptr i8, ptr %t785, i64 %t773
  call void @olang_textcopy(ptr %t786, ptr %t775, i64 %t776)
  %t787 = getelementptr i8, ptr %t786, i64 %t776
  call void @olang_textcopy(ptr %t787, ptr %t778, i64 %t779)
  %t788 = getelementptr i8, ptr %t787, i64 %t779
  %t789 = call i64 @__olang_fmt_i64(ptr %t788, i64 %t782)
  %t790 = insertvalue { i64, ptr } undef, i64 %t784, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t785, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = extractvalue { i64, ptr } %t791, 1
  %t795 = mul i64 %t793, 1
  %t796 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t795)
  call void @llvm.memcpy.p0.p0.i64(ptr %t796, ptr %t794, i64 %t795, i1 false)
  %t797 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t798 = insertvalue { i64, ptr } %t797, ptr %t796, 1
  %t799 = load ptr, ptr %l275, !tbaa !29
  %t800 = load i64, ptr %l276, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s30, ptr %t799, i64 %t800, { i64, ptr } %t798)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s30)
  br label %bb163
bb143:
  %t802 = load ptr, ptr %l1, !tbaa !29
  store ptr %t802, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t803 = load ptr, ptr %l286, !tbaa !29
  %t804 = icmp ne ptr %t803, null
  br i1 %t804, label %bb144, label %bb145
bb144:
  %t806 = load ptr, ptr %l286, !tbaa !29
  %t807 = load i64, ptr %t806, !range !{i64 0, i64 17}
  %t809 = icmp eq i64 %t807, 15
  store i1 %t809, ptr %l287, !tbaa !21
  br label %bb145
bb145:
  %t810 = load i1, ptr %l287, !tbaa !21
  br i1 %t810, label %bb146, label %bb147
bb146:
  %t811 = load ptr, ptr %l1, !tbaa !29
  %t813 = getelementptr { i64, [3 x i64] }, ptr %t811, i32 0, i32 1
  %t814 = getelementptr { %"compiler/source:Span", ptr }, ptr %t813, i32 0, i32 1
  %t815 = load ptr, ptr %t814
  store ptr %t815, ptr %l23, !tbaa !29
  br label %bb148
bb147:
  br label %bb151
bb148:
  store %olang.scope zeroinitializer, ptr %s32
  %t817 = load ptr, ptr %l0, !tbaa !29
  store ptr %t817, ptr %l292, !tbaa !29
  %t818 = load i64, ptr %l2, !tbaa !24
  store i64 %t818, ptr %l293, !tbaa !24
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t820 = load ptr, ptr %l23, !tbaa !29
  %t824 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s32, ptr %t819, ptr %t820)
  store { i64, ptr } %t824, ptr %l297
  br label %bb149
bb149:
  %t825 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t826 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t827 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t827, 1
  %t829 = extractvalue { i64, ptr } %t827, 0
  %t830 = add i64 %t826, %t829
  %t831 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t830)
  call void @olang_textcopy(ptr %t831, ptr %t825, i64 %t826)
  %t832 = getelementptr i8, ptr %t831, i64 %t826
  call void @olang_textcopy(ptr %t832, ptr %t828, i64 %t829)
  %t833 = insertvalue { i64, ptr } undef, i64 %t830, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t831, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = extractvalue { i64, ptr } %t834, 1
  %t838 = mul i64 %t836, 1
  %t839 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t838)
  call void @llvm.memcpy.p0.p0.i64(ptr %t839, ptr %t837, i64 %t838, i1 false)
  %t840 = insertvalue { i64, ptr } undef, i64 %t836, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t839, 1
  %t842 = load ptr, ptr %l292, !tbaa !29
  %t843 = load i64, ptr %l293, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s32, ptr %t842, i64 %t843, { i64, ptr } %t841)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s32)
  br label %bb163
bb151:
  %t845 = load ptr, ptr %l1, !tbaa !29
  store ptr %t845, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t846 = load ptr, ptr %l300, !tbaa !29
  %t847 = icmp ne ptr %t846, null
  br i1 %t847, label %bb152, label %bb153
bb152:
  %t849 = load ptr, ptr %l300, !tbaa !29
  %t850 = load i64, ptr %t849, !range !{i64 0, i64 17}
  %t852 = icmp eq i64 %t850, 16
  store i1 %t852, ptr %l301, !tbaa !21
  br label %bb153
bb153:
  %t853 = load i1, ptr %l301, !tbaa !21
  br i1 %t853, label %bb154, label %bb155
bb154:
  %t854 = load ptr, ptr %l1, !tbaa !29
  %t856 = getelementptr { i64, [3 x i64] }, ptr %t854, i32 0, i32 1
  %t857 = getelementptr { %"compiler/source:Span", ptr }, ptr %t856, i32 0, i32 1
  %t858 = load ptr, ptr %t857
  store ptr %t858, ptr %l24, !tbaa !29
  br label %bb156
bb155:
  br label %bb162
bb156:
  store %olang.scope zeroinitializer, ptr %s34
  %t860 = load ptr, ptr %l0, !tbaa !29
  store ptr %t860, ptr %l306, !tbaa !29
  %t861 = load i64, ptr %l2, !tbaa !24
  store i64 %t861, ptr %l307, !tbaa !24
  %t862 = load ptr, ptr %l0, !tbaa !29
  store ptr %t862, ptr %l308, !tbaa !29
  %t863 = load ptr, ptr %l24, !tbaa !29
  %t865 = icmp eq ptr %t863, null
  br i1 %t865, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_78afbb313fff45b8_957466907ebeb484)
  unreachable
bb158:
  br label %bb159
bb159:
  %t867 = load ptr, ptr %l24, !tbaa !29
  %t869 = load ptr, ptr %l308, !tbaa !29
  %t871 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s34, ptr %t869, ptr %t867)
  store { i64, ptr } %t871, ptr %l313
  br label %bb160
bb160:
  %t872 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t873 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t874 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t875 = extractvalue { i64, ptr } %t874, 1
  %t876 = extractvalue { i64, ptr } %t874, 0
  %t877 = add i64 %t873, %t876
  %t878 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t877)
  call void @olang_textcopy(ptr %t878, ptr %t872, i64 %t873)
  %t879 = getelementptr i8, ptr %t878, i64 %t873
  call void @olang_textcopy(ptr %t879, ptr %t875, i64 %t876)
  %t880 = insertvalue { i64, ptr } undef, i64 %t877, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t878, 1
  %t883 = extractvalue { i64, ptr } %t881, 0
  %t884 = extractvalue { i64, ptr } %t881, 1
  %t885 = mul i64 %t883, 1
  %t886 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t885)
  call void @llvm.memcpy.p0.p0.i64(ptr %t886, ptr %t884, i64 %t885, i1 false)
  %t887 = insertvalue { i64, ptr } undef, i64 %t883, 0
  %t888 = insertvalue { i64, ptr } %t887, ptr %t886, 1
  %t889 = load ptr, ptr %l306, !tbaa !29
  %t890 = load i64, ptr %l307, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s34, ptr %t889, i64 %t890, { i64, ptr } %t888)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s34)
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_90a2a4daf32abd74_d37804826367c570)
  unreachable
bb163:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 5}
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Make", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store ptr %a0, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 0
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load i32, ptr %l26, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t52, i32 %t53, i32 %t51)
  store i1 %t55, ptr %l28
  br label %bb12
bb12:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t57 = load i1, ptr %l21, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Make", ptr %t58, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l31, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l29, !tbaa !29
  br label %bb16
bb15:
  store ptr null, ptr %l29, !tbaa !29
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l29, !tbaa !29
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb32
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t70 = load ptr, ptr %l34, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l34, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 2
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 10
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8a62bacdff20949b_383b5959755ced57)
  unreachable
bb32:
  %t90 = load ptr, ptr %l4, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ftyped_2edefName(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1048576
  %t7 = add i64 %t3, %a1
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2efnBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l26 = alloca { i64, ptr }
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 3}
  %t18 = icmp eq i64 %t16, 1
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t40, ptr %l26, !tbaa !27
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t50 = getelementptr %"compiler/typed:Capture", ptr %t46, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t51, i32 %t53)
  store i1 %t56, ptr %l33
  br label %bb16
bb16:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb12
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 3}
  %t71 = icmp eq i64 %t69, 2
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb25, label %bb26
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { i32, ptr, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l47
  br label %bb28
bb28:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb24
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Make", ptr %t25, i32 0, i32 0
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 5}
  %t30 = trunc i64 4 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l3, !tbaa !21
  br label %bb24
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb18
bb18:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_bea5bf6ffc689610_b71acf810bfa0324)
  unreachable
bb24:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l22
  br label %bb8
bb8:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = call ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v0, ptr %t37)
  store ptr %t39, ptr %l25
  br label %bb11
bb11:
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t43 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t41, %"compiler/source:Span" %t40)
  store i1 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb4
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb9
bb9:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l25
  br label %bb12
bb12:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t37, 1
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i32, ptr %l25, !tbaa !23
  %t43 = call i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %t40, i32 %t41, i64 %t39)
  store i1 %t43, ptr %l28
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l21, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t48 = trunc i64 22 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t51 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t53 = trunc i64 23 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t63, i32 %t64, i64 %t62)
  store i1 %t66, ptr %l38
  br label %bb22
bb22:
  %t67 = load i1, ptr %l38, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
bb23:
  %t68 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t70 = trunc i64 24 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb27
bb27:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i32, ptr %l44, !tbaa !23
  %t83 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t80, i32 %t81, i64 %t79)
  store i1 %t83, ptr %l46
  br label %bb28
bb28:
  %t84 = load i1, ptr %l46, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb29:
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb56
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l51
  br label %bb33
bb33:
  %t95 = load i1, ptr %l51, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l57
  br label %bb37
bb37:
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = load i32, ptr %l57, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t107, ptr %l58
  br label %bb38
bb38:
  %t108 = load i32, ptr %l58, !range !{i32 0, i32 6}
  store i32 %t108, ptr %l5
  %t109 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t111 = trunc i64 0 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l62, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l65
  br label %bb42
bb42:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = load i32, ptr %l65, !tbaa !23
  %t124 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t121, i32 %t122, i64 %t120)
  store i1 %t124, ptr %l67
  br label %bb43
bb43:
  %t125 = load i1, ptr %l67, !tbaa !21
  store i1 %t125, ptr %l59, !tbaa !21
  br label %bb55
bb44:
  %t126 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t128 = trunc i64 1 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l70, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l3, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l73
  br label %bb48
bb48:
  %t137 = load i64, ptr %l2, !tbaa !24
  %t138 = load ptr, ptr %l70, !tbaa !29
  %t139 = load i32, ptr %l73, !tbaa !23
  %t141 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t138, i32 %t139, i64 %t137)
  store i1 %t141, ptr %l75
  br label %bb49
bb49:
  %t142 = load i1, ptr %l75, !tbaa !21
  store i1 %t142, ptr %l59, !tbaa !21
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_61141ab026762302_86235c78c2d902d6)
  unreachable
bb55:
  %t143 = load i1, ptr %l59, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2566079f8423d483_66fa93375f6766f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 6
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t11, ptr %l3
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l15
  br label %bb8
bb8:
  %t22 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t25 = and i64 %t23, %t22
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = add i64 %t35, 1
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l23, !tbaa !23
  %t41 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t38, i32 %t39, i64 %t37)
  store i1 %t41, ptr %l26
  br label %bb12
bb12:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l19, !tbaa !21
  store i1 %t43, ptr %l10, !tbaa !21
  br label %bb49
bb14:
  %t44 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l32
  br label %bb18
bb18:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = add i64 %t55, 1
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t61 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t58, i32 %t59, i64 %t57)
  store i1 %t61, ptr %l35
  br label %bb19
bb19:
  %t62 = load i1, ptr %l35, !tbaa !21
  store i1 %t62, ptr %l10, !tbaa !21
  br label %bb49
bb20:
  %t63 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t65 = trunc i64 22 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t68 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t70 = trunc i64 23 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l40, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l44
  br label %bb26
bb26:
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = trunc i64 %t80 to i32
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t83, i32 %t81)
  store { i64, ptr } %t85, ptr %l47
  br label %bb27
bb27:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t90 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t87, { i64, ptr } %t88, i64 %t86)
  store i1 %t90, ptr %l49
  br label %bb28
bb28:
  %t91 = load i1, ptr %l49, !tbaa !21
  store i1 %t91, ptr %l10, !tbaa !21
  br label %bb49
bb29:
  %t92 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t94 = trunc i64 18 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t99 = load i64, ptr %l2, !tbaa !24
  %t103 = call i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %t97, i32 %t98, i64 %t99)
  store i1 %t103, ptr %l55
  br label %bb33
bb33:
  %t104 = load i1, ptr %l55, !tbaa !21
  store i1 %t104, ptr %l10, !tbaa !21
  br label %bb49
bb34:
  %t105 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t107 = trunc i64 21 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  %t110 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t112 = trunc i64 29 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  %t115 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t117 = trunc i64 25 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  %t120 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t122 = trunc i64 24 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_897c6ec4bdb8e7c2_3b49e2eddb87c67e)
  unreachable
bb49:
  %t125 = load i1, ptr %l10, !tbaa !21
  store i1 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb6
bb5:
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = or i64 %t10, %t11
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t43, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Payload", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t145, i32 %t147)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_f3346b4d6d82824c_aeee08707a274ea0)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/typed:leaveWalk"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca i64
  %l40 = alloca i64
  %l41 = alloca %"compiler/typed:leaveWalk"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i64 1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = call ptr @compiler_2ftyped_2eBlock_2ewithin(ptr %v0, ptr %v0, ptr %t38)
  store ptr %t40, ptr %l27
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l27, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t48, %"compiler/source:Span" %t50)
  store i64 %t53, ptr %l35
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = icmp ne i64 %t54, 0
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t63 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t58, %"compiler/source:Span" %t60)
  store i64 %t63, ptr %l40
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  %t64 = load i64, ptr %l40, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = call %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %s3)
  store %"compiler/typed:leaveWalk" %t65, ptr %l41
  br label %bb21
bb21:
  %t66 = load %"compiler/typed:leaveWalk", ptr %l41
  store %"compiler/typed:leaveWalk" %t66, ptr %l7
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %s3, ptr %v0, ptr %l7, ptr %t67)
  store i1 %t70, ptr %l44
  br label %bb22
bb22:
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t72, %"compiler/source:Span" %t74)
  store i1 %t77, ptr %l48
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t78 = load i1, ptr %l48, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb4
bb31:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l2
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  %t45 = sext i32 %t41 to i64
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb10
bb9:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l17, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb23
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 17
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l33
  br label %bb17
bb17:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9bf6326dc96b231_1fb9b096f472b9bd)
  unreachable
bb23:
  %t67 = load i64, ptr %l6, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Alt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Alt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:BlockInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %a2, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"compiler/typed:Body"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l30
  br label %bb1
bb1:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l10
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l11
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l32
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l33
  br label %bb4
bb4:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l13
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l34
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l14
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l35
  br label %bb6
bb6:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l15
  store ptr null, ptr %l16, !tbaa !29
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l36
  br label %bb7
bb7:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l37
  br label %bb8
bb8:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l18
  store i1 false, ptr %l19, !tbaa !21
  store i32 -1, ptr %l20, !tbaa !23
  store i1 false, ptr %l21, !tbaa !21
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l38
  br label %bb9
bb9:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l39
  br label %bb10
bb10:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t31 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 0
  %t32 = load i32, ptr %l5, !tbaa !23
  store i32 %t32, ptr %t31, !tbaa !23
  %t33 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 1
  %t34 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t34, ptr %t33
  %t35 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 2
  %t36 = load i32, ptr %l7, !tbaa !23
  store i32 %t36, ptr %t35, !tbaa !23
  %t37 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 3
  %t38 = load i64, ptr %l8, !tbaa !24
  store i64 %t38, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 4
  %t40 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t40, ptr %t39
  %t41 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 5
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 6
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 7
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 8
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 9
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 10
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 11
  %t54 = load ptr, ptr %l16, !tbaa !29
  store ptr %t54, ptr %t53, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 12
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t55
  %t57 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 13
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 14
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %t59, !tbaa !21
  %t61 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 15
  %t62 = load i32, ptr %l20, !tbaa !23
  store i32 %t62, ptr %t61, !tbaa !23
  %t63 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 16
  %t64 = load i1, ptr %l21, !tbaa !21
  store i1 %t64, ptr %t63, !tbaa !21
  %t65 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 17
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t65
  %t67 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 18
  %t68 = load i1, ptr %l23, !tbaa !21
  store i1 %t68, ptr %t67, !tbaa !21
  %t69 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t69
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l40, i64 408, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Capture"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %a1, 1
  store %"compiler/typed:Capture" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6) #0 {
entry:
  %rv = alloca %"compiler/typed:Clause"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %a0, 0
  %t18 = insertvalue %"compiler/typed:Clause" %t16, { i64, ptr } %a1, 1
  %t20 = insertvalue %"compiler/typed:Clause" %t18, i1 %a2, 2
  %t22 = insertvalue %"compiler/typed:Clause" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/typed:Clause" %t22, { i64, ptr } %a4, 4
  %t26 = insertvalue %"compiler/typed:Clause" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/typed:Clause" %t26, i32 %a6, 6
  store %"compiler/typed:Clause" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local void @compiler_2ftyped_3aDropHolding_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/typed:DropHolding"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l12
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l13
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t15 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 0
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t15
  %t17 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 1
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 2
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 3
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 4
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t23
  %t25 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 5
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/typed:DropHolding", ptr %l14, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l14, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aLandings_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"compiler/typed:Landings"
  %t31 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l31, !tbaa !24
  %t10 = load i64, ptr %l31, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l31, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l35, !tbaa !24
  %t22 = load i64, ptr %l35, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6cac4c556ee1b7d9_257131421adb63ad)
  unreachable
bb3:
  %t25 = load i64, ptr %l35, !tbaa !24
  %t26 = icmp sle i64 %t25, 1152921504606846975
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb5:
  %t28 = load i64, ptr %l35, !tbaa !24
  %t29 = mul i64 %t28, 8
  %t30 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t29)
  store i64 0, ptr %t31
  br label %fill.32
fill.32:
  %t35 = load i64, ptr %t31
  %t36 = icmp slt i64 %t35, %t28
  br i1 %t36, label %fillb.33, label %filld.34
fillb.33:
  %t37 = getelementptr i64, ptr %t30, i64 %t35
  store i64 -1, ptr %t37
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %t31
  br label %fill.32
filld.34:
  %t39 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t30, 1
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l40, !tbaa !24
  %t45 = load i64, ptr %l40, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb7:
  %t48 = load i64, ptr %l40, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l44, !tbaa !24
  %t57 = load i64, ptr %l44, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  br i1 %t58, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_75ea3af438a3ca2f_999b6c305f7ce623)
  unreachable
bb9:
  %t60 = load i64, ptr %l44, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  store i1 false, ptr %l10, !tbaa !21
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l47
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5a80d8a416bdb25a_ede72ef348da89ae)
  unreachable
bb11:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t68 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t68, ptr %l48
  br label %bb12
bb12:
  %t69 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t69, ptr %l14
  %t70 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l49
  br label %bb13
bb13:
  %t71 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t71, ptr %l15
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l50
  br label %bb14
bb14:
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l16
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l51
  br label %bb15
bb15:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l17
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l52
  br label %bb16
bb16:
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l18
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l53
  br label %bb17
bb17:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l19
  %t80 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l54
  br label %bb18
bb18:
  %t81 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l20
  %t82 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l55
  br label %bb19
bb19:
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l21
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l56
  br label %bb20
bb20:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l22
  store i64 0, ptr %l23, !tbaa !24
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  br label %bb21
bb21:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l24
  %t88 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l58
  br label %bb22
bb22:
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  %t90 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t91, ptr %t90, !tbaa !27
  %t92 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 3
  %t97 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t97, ptr %t96, !tbaa !27
  %t98 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 4
  %t99 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t99, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 5
  %t101 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t101, ptr %t100, !tbaa !27
  %t102 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 6
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t103, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 7
  %t105 = load i1, ptr %l10, !tbaa !21
  store i1 %t105, ptr %t104, !tbaa !21
  %t106 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 8
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t106
  %t108 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 9
  %t109 = load i64, ptr %l12, !tbaa !24
  store i64 %t109, ptr %t108, !tbaa !24
  %t110 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 10
  %t111 = load i64, ptr %l13, !tbaa !24
  store i64 %t111, ptr %t110, !tbaa !24
  %t112 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 11
  %t113 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t113, ptr %t112
  %t114 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 12
  %t115 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t115, ptr %t114
  %t116 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 13
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t116
  %t118 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 14
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %t118
  %t120 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 15
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %t120
  %t122 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 16
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %t122
  %t124 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 17
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %t124
  %t126 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 18
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t126
  %t128 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 19
  %t129 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %t128
  %t130 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 20
  %t131 = load i64, ptr %l23, !tbaa !24
  store i64 %t131, ptr %t130, !tbaa !24
  %t132 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 21
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %t132
  %t134 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %t134
  %t136 = getelementptr %"compiler/typed:Landings", ptr %l59, i32 0, i32 23
  store i64 -1, ptr %t136, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l59, i64 616, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [1 x i64] } %a5, 5
  %t26 = insertvalue %"compiler/typed:Local" %t24, i1 false, 6
  store %"compiler/typed:Local" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %a3, 3
  store %"compiler/typed:Match" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Payload"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %a2, 2
  store %"compiler/typed:Payload" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:SiteInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Slice"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Slice" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Slice" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Slice" %t14, i32 %a3, 3
  store %"compiler/typed:Slice" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:TaskClause" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/typed:TaskClause" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:TaskClause" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:TaskClause" %t14, ptr %a3, 3
  store %"compiler/typed:TaskClause" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:TaskClause", ptr %rv
  ret %"compiler/typed:TaskClause" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Text"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %a1, 1
  store %"compiler/typed:Text" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local void @compiler_2ftyped_3aVersions_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"compiler/typed:Versions"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l26, !tbaa !24
  %t8 = load i64, ptr %l26, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l26, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l29
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a650b38034a5180c_4858ad52e7b771b8)
  unreachable
bb3:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l30
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l6
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l31
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l7
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l32
  br label %bb6
bb6:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l8
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l33
  br label %bb7
bb7:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l9
  %t27 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t27, ptr %l34
  br label %bb8
bb8:
  %t28 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l34
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t28, ptr %l10
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l35
  br label %bb9
bb9:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l11
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l36
  br label %bb10
bb10:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l12
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l37
  br label %bb11
bb11:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l13
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l38
  br label %bb12
bb12:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l39
  br label %bb13
bb13:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l16
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l40
  br label %bb14
bb14:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l17
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l41
  br label %bb15
bb15:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l18
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l42
  br label %bb16
bb16:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l43
  br label %bb17
bb17:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l20
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l44
  br label %bb18
bb18:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t49 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 0
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %t49, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t52, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 3
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t55
  %t57 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 4
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 5
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 6
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %t61
  %t63 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 7
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t63
  %t65 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 8
  %t66 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t66, ptr %t65
  %t67 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 9
  %t68 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t68, ptr %t67
  %t69 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 10
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %t69
  %t71 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 11
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 12
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t73
  %t75 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 13
  %t76 = load i64, ptr %l15, !tbaa !24
  store i64 %t76, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 14
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 15
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t79
  %t81 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 16
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t81
  %t83 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 17
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t83
  %t85 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 18
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t85
  %t87 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t87
  %t89 = getelementptr %"compiler/typed:Versions", ptr %l45, i32 0, i32 20
  store i1 true, ptr %t89, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l45, i64 688, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:ViewWalk" @compiler_2ftyped_3aViewWalk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %rv = alloca %"compiler/typed:ViewWalk"
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:ViewWalk" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:ViewWalk" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/typed:ViewWalk" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/typed:ViewWalk" %t16, { ptr, ptr } %pg3, 3
  %t20 = insertvalue %"compiler/typed:ViewWalk" %t18, { ptr, ptr } %pg4, 4
  store %"compiler/typed:ViewWalk" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ViewWalk", ptr %rv
  ret %"compiler/typed:ViewWalk" %rr
}

define dso_local void @compiler_2ftyped_3aholdWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"compiler/typed:holdWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  store i1 false, ptr %l5, !tbaa !21
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l23
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l24
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l8
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l25
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l9
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l26
  br label %bb6
bb6:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l10
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l27
  br label %bb7
bb7:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l11
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l28
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l12
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l29
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l13
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l30
  br label %bb10
bb10:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l14
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l31
  br label %bb11
bb11:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l15
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l32
  br label %bb12
bb12:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l16
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l33
  br label %bb13
bb13:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l17
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l34
  br label %bb14
bb14:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t33 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 0
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %t33, !tbaa !29
  %t35 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 1
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %t35, !tbaa !29
  %t37 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 2
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %t37
  %t39 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 3
  %t40 = load i1, ptr %l5, !tbaa !21
  store i1 %t40, ptr %t39, !tbaa !21
  %t41 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 4
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 5
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 6
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 7
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 8
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 9
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 10
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 11
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t55
  %t57 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 12
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 13
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 14
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %t61
  %t63 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 15
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t63
  %t65 = getelementptr %"compiler/typed:holdWalk", ptr %l35, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t65
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 472, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:landLoop" @compiler_2ftyped_3alandLoop_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %rv = alloca %"compiler/typed:landLoop"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_652e3003820639e_452d7c4eea959e6a)
  unreachable
bb3:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t25 = load i32, ptr %l2, !tbaa !23
  %t26 = insertvalue %"compiler/typed:landLoop" undef, i32 %t25, 0
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = insertvalue %"compiler/typed:landLoop" %t26, i64 %t27, 1
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = insertvalue %"compiler/typed:landLoop" %t28, { i64, ptr } %t29, 2
  %t32 = insertvalue %"compiler/typed:landLoop" %t30, { i64, ptr } %t23, 3
  %t34 = insertvalue %"compiler/typed:landLoop" %t32, i1 false, 4
  %t36 = insertvalue %"compiler/typed:landLoop" %t34, i1 false, 5
  store %"compiler/typed:landLoop" %t36, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6ab171d7108733d3_fb4921eacef8293f)
  unreachable
ret:
  %rr = load %"compiler/typed:landLoop", ptr %rv
  ret %"compiler/typed:landLoop" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 8}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 8}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 ]
bb3:
  br label %bb12
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb11, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_scope_of(ptr, ptr) noinline
declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"let L" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assign " }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"eval " }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"loop" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"post" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"break" }>, align 8
@.d15 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"continue" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"reraise " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d24 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d25 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"defer" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" try" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d33 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.Helper.Equal" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d34 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Helper.Hash" }>, align 8
@.d35 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.ExitKind.Unreachable" }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.ExitKind.NullReached" }>, align 8
declare i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9640b30413567955_c65a1e6fb20cf981 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9 = external constant [0 x i8]
@olang_loc_98ffd35c6a6991db_b4b9a5fbdbb15627 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2eDropHolding_2eholding(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %a0)
declare ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2enoCallbackNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_352016b8dfbaae41_4f83dc304b77dded = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_49a7b0a2550beed6_c54fa6caa81e807a = external constant [0 x i8]
@olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/typed:landLoop" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_17d1ac1d0088a46d_f6898a8fba654071 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_53c662fb23aaf808_98195192fab83824 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_198aad80d0550ab5_c06608159f163401 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_28655f8a56cf669d_dc60f62ebe04c639 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d36f57f073c6a2ff_232866ca740484ab = external constant [0 x i8]
@olang_loc_faea1712f2053751_ed9fc9ee56afb56d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ea76fa4e8d5c92b6_ce360b1ee865cf5a = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
@olang_loc_dac0899521d00a27_f5966ad5b7471ec3 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_93af16bb2b9103f6_23d1e52eae2906e2 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_43639d7480e3f1b2_6970610da298d01e = external constant [0 x i8]
@olang_loc_13022d0d55ff9b33_d1cf61a4f0453a9f = external constant [0 x i8]
@olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_He64c344d05691a582e6fe54d21a34702(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7e4ec1e19232cd88_f10154fa6134f764 = external constant [0 x i8]
@olang_loc_a0166decbffe4964_9ac2fce80458edf8 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %v0, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eDefOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78 = external constant [0 x i8]
@olang_loc_f658218d2a233859_f81a26e56b3c591d = external constant [0 x i8]
@olang_loc_4c95fac740fe18b9_da00c3dfb70c298d = external constant [0 x i8]
@olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14 = external constant [0 x i8]
@olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69 = external constant [0 x i8]
@olang_loc_cb0f3499142fc19d_d94490f94af5f129 = external constant [0 x i8]
@olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf = external constant [0 x i8]
@olang_loc_14162ea47c0c801c_ce4205068f01e790 = external constant [0 x i8]
@olang_loc_a93f600a1cb39be1_ee16d2dfcadba585 = external constant [0 x i8]
@olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da = external constant [0 x i8]
@olang_loc_8726c5b979482c78_cdee9de0701e13e4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_456f0c0b74db68d5_29242d1724c8a7c1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9f9fe097503cda9_c6b719cc2534ac35 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %a0, i1 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b = external constant [0 x i8]
@olang_loc_54fd08b205476dc4_657f8db756d05b08 = external constant [0 x i8]
@olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60 = external constant [0 x i8]
@olang_loc_3398753e62525e0a_a26aec7fb7dfed8e = external constant [0 x i8]
@olang_loc_8b9fe86f9939495b_ac6312ba480f0d67 = external constant [0 x i8]
@olang_loc_3f464ddbb91b0a38_82918aeeacdcc614 = external constant [0 x i8]
@olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c = external constant [0 x i8]
@olang_loc_18d2a0b724f39c7e_37ab118f04dce49a = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_fb0720d2dfee7f_1f99818eb62f02f3 = external constant [0 x i8]
@olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0 = external constant [0 x i8]
@olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5 = external constant [0 x i8]
@olang_loc_313fe9555679a06f_fa589a226c49c6eb = external constant [0 x i8]
@olang_loc_f3df993f4c7e1fd4_8419908bae6ac650 = external constant [0 x i8]
@olang_loc_e306d5ccad957c29_6b95b0de26f94a45 = external constant [0 x i8]
@olang_loc_d73b6870bbe51a4d_d845c63f23993221 = external constant [0 x i8]
@olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747 = external constant [0 x i8]
@olang_loc_2cf1608fd5d1230c_1374e48cd144e348 = external constant [0 x i8]
@olang_loc_73be6a0e490978a7_b5fa18d3e7eede33 = external constant [0 x i8]
@olang_loc_2fb6091d652311b2_1c71a9a414fce87e = external constant [0 x i8]
@olang_loc_8c1b8241682c8a5c_1491e83e9da6f28 = external constant [0 x i8]
@olang_loc_4fc9df9522ae1330_697d53c50db00ce4 = external constant [0 x i8]
@olang_loc_e4195c8d52320dab_6e5abcaf8844f88f = external constant [0 x i8]
@olang_loc_6df7d27e20fc18e6_9af88db0bee394aa = external constant [0 x i8]
@olang_loc_c52364142dc414a0_4d1da6470710a144 = external constant [0 x i8]
@olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730 = external constant [0 x i8]
@olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab = external constant [0 x i8]
@olang_loc_cdd2e50680d68485_7d51e204495f7309 = external constant [0 x i8]
@olang_loc_2ee7063c57fe9793_68bf97cc73752027 = external constant [0 x i8]
@olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2676a1f2cfb255f8_2530c83c98e00394 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_7fb442b2027c5df4_8cb8a301a51c1668 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77c9af98e9dace58_20acd54f7de13794 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eelemStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etarget(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_60996a1f08c29aeb_ed876111a60916df = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_10efe43793a641ac_2dabf1c43cd6a168 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b80660129801afa0_e660219d512f014 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_7b432bbe8f05f1d7_7deffd42aa472253 = external constant [0 x i8]
@olang_loc_78afbb313fff45b8_957466907ebeb484 = external constant [0 x i8]
@olang_loc_90a2a4daf32abd74_d37804826367c570 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_8a62bacdff20949b_383b5959755ced57 = external constant [0 x i8]
@olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb = external constant [0 x i8]
@olang_loc_bea5bf6ffc689610_b71acf810bfa0324 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_61141ab026762302_86235c78c2d902d6 = external constant [0 x i8]
@olang_loc_2566079f8423d483_66fa93375f6766f7 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_897c6ec4bdb8e7c2_3b49e2eddb87c67e = external constant [0 x i8]
@olang_loc_f3346b4d6d82824c_aeee08707a274ea0 = external constant [0 x i8]
declare %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %v0)
@olang_loc_9bf6326dc96b231_1fb9b096f472b9bd = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_6cac4c556ee1b7d9_257131421adb63ad = external constant [0 x i8]
@olang_loc_52c63b14e30804cc_be8191a117211c80 = external constant [0 x i8]
@olang_loc_75ea3af438a3ca2f_999b6c305f7ce623 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_5a80d8a416bdb25a_ede72ef348da89ae = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_a650b38034a5180c_4858ad52e7b771b8 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_652e3003820639e_452d7c4eea959e6a = external constant [0 x i8]
@olang_loc_6ab171d7108733d3_fb4921eacef8293f = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
