; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:landLoop" = type { i32, i64, { i64, ptr }, { i64, ptr }, i1, i1 }
define dso_local i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %t9, i32 %a1)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9)
  unreachable
bb11:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l17
  br label %bb11
bb11:
  %t34 = load i1, ptr %l17, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bf16ba0368763d37_f19ef32b132443ab)
  unreachable
bb17:
  br label %bb30
bb18:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb20
bb20:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb21, label %bb22
bb21:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb24
bb24:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_af65136929bfae16_48f8be4437d6c6ea)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { ptr, ptr }
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [1 x i64] }
  %l44 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca i1
  %l87 = alloca i64
  %l90 = alloca i1
  %l95 = alloca i64
  %l98 = alloca ptr
  %l100 = alloca i32
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, [1 x i64] }
  %l109 = alloca { i64, [1 x i64] }
  %l111 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp slt i32 %t17, 0
  store i1 %t19, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l26, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l28, !tbaa !23
  %t28 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t28, ptr %l29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t29)
  store i64 %t31, ptr %l31
  br label %bb10
bb10:
  %t32 = load i64, ptr %l31, !tbaa !24
  %t33 = trunc i64 %t32 to i32
  %t35 = load { ptr, ptr }, ptr %l29
  %t36 = extractvalue { ptr, ptr } %t35, 0
  %t37 = extractvalue { ptr, ptr } %t35, 1
  %t39 = call { i64, ptr } %t36(ptr %t37, ptr %s0, i32 %t33)
  store { i64, ptr } %t39, ptr %l34
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 8
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t50 = call { i64, [1 x i64] } @compiler_2ftyped_2eresultScope(ptr %v0, ptr %s0, ptr %t47, i32 %t48, { i64, ptr } %t46)
  store { i64, [1 x i64] } %t50, ptr %l36
  br label %bb12
bb12:
  %t51 = load { i64, [1 x i64] }, ptr %l36
  store { i64, [1 x i64] } %t51, ptr %l5
  %t52 = load { i64, [1 x i64] }, ptr %l5
  %t54 = extractvalue { i64, [1 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l6, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t63, i64 %t64)
  store i64 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i64, ptr %l44, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb22
bb19:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l51, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb21
bb21:
  %t95 = load i64, ptr %l51, !tbaa !24
  store i64 %t95, ptr %l48, !tbaa !24
  br label %bb22
bb22:
  %t96 = load i64, ptr %l48, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l70, !tbaa !24
  %t117 = load i64, ptr %l70, !tbaa !24
  %t118 = load i64, ptr %l70, !tbaa !24
  %t119 = shl i64 1, %t118
  %t122 = and i64 %t115, %t119
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Call", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l75, !tbaa !27
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = call ptr @compiler_2ftyped_2efreshCall(ptr %v1, ptr %v1, ptr %t135, i64 0)
  store ptr %t137, ptr %l78
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l78, !tbaa !29
  store ptr %t138, ptr %l12, !tbaa !29
  %t139 = load ptr, ptr %l12, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb33
bb32:
  %t143 = load ptr, ptr %l12, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Call", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %t145, !tbaa !23
  %t148 = icmp slt i32 %t146, 0
  store i1 %t148, ptr %l81, !tbaa !21
  br label %bb33
bb33:
  %t150 = load i1, ptr %l81, !tbaa !21
  br i1 %t150, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t152 = load ptr, ptr %l12, !tbaa !29
  %t154 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t152)
  store i64 %t154, ptr %l87
  br label %bb37
bb37:
  %t155 = load i64, ptr %l87, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = icmp slt i64 %t156, 0
  br i1 %t158, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb41
bb39:
  %t161 = load i64, ptr %l13, !tbaa !24
  %t163 = trunc i64 %t161 to i32
  %t166 = extractvalue { ptr, ptr } %pg3, 0
  %t167 = extractvalue { ptr, ptr } %pg3, 1
  %t169 = call i64 %t166(ptr %t167, i32 %t163)
  store i64 %t169, ptr %l95
  br label %bb40
bb40:
  %t170 = load i64, ptr %l95, !tbaa !24
  %t171 = icmp ne i64 %t170, 0
  store i1 %t171, ptr %l90, !tbaa !21
  br label %bb41
bb41:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l98, !tbaa !29
  %t176 = load ptr, ptr %l12, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Call", ptr %t176, i32 0, i32 2
  %t179 = load i32, ptr %t178, !tbaa !23
  store i32 %t179, ptr %l100, !tbaa !23
  %t180 = load { ptr, ptr }, ptr %l4
  %t181 = load i64, ptr %l13, !tbaa !24
  %t183 = trunc i64 %t181 to i32
  %t186 = extractvalue { ptr, ptr } %t180, 0
  %t187 = extractvalue { ptr, ptr } %t180, 1
  %t189 = call { i64, ptr } %t186(ptr %t187, ptr %s4, i32 %t183)
  store { i64, ptr } %t189, ptr %l105
  br label %bb45
bb45:
  %t190 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 8
  %t194 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = load i32, ptr %l100, !tbaa !23
  %t200 = call { i64, [1 x i64] } @compiler_2ftyped_2eresultScope(ptr %v0, ptr %s4, ptr %t197, i32 %t198, { i64, ptr } %t196)
  store { i64, [1 x i64] } %t200, ptr %l107
  br label %bb46
bb46:
  %t201 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t201, ptr %l109
  %t204 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l107, ptr %l109)
  store i1 %t204, ptr %l111
  br label %bb47
bb47:
  %t205 = load i1, ptr %l111, !tbaa !21
  %t206 = xor i1 %t205, true
  br i1 %t206, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb51:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l10, !tbaa !24
  br label %bb23
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2ftyped_2emathNames, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l2
  store i64 31, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = getelementptr [31 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load ptr, ptr @__olang_prog_scope
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t24, { i64, ptr } %t22, { i64, ptr } %t23)
  store i1 %t27, ptr %l20
  br label %bb5
bb5:
  %t28 = load i1, ptr %l20, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  call void @olang_textcopy(ptr %t38, ptr %t34, i64 %t35)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t29, { i64, ptr } %t47)
  store i1 %t50, ptr %l26
  br label %bb8
bb8:
  %t51 = load i1, ptr %l26, !tbaa !21
  store i1 %t51, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t52 = load i1, ptr %l21, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = getelementptr [31 x i64], ptr @G_2ecompiler_2ftyped_2emathArity, i64 0, i64 %t54
  %t57 = load i64, ptr %t56, !tbaa !34
  %t60 = icmp eq i64 %a1, %t57
  store i1 %t60, ptr %l27, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ePartOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 4
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_62af31c5105aaa5b_ddb95177f2bf45e7)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca %"compiler/typed:LocalUses"
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l56 = alloca ptr
  %l65 = alloca i64
  %l67 = alloca i64
  %l72 = alloca i32
  %l79 = alloca %"compiler/typed:LocalUses"
  %t3 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_3aLocalUses_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t3, i64 704, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 704, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l14, i64 704, i1 false)
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t10)
  store i64 %t12, ptr %l17
  br label %bb2
bb2:
  %t13 = load i64, ptr %l17, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l24, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %lp2
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t60, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t61, i1 false)
  br label %bb13
bb13:
  %t63 = load ptr, ptr %lp2
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t63, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t64, i1 false)
  br label %bb14
bb14:
  %t66 = load ptr, ptr %lp2
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t67, i1 false)
  br label %bb15
bb15:
  %t69 = load ptr, ptr %lp2
  %t70 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t70, i1 false)
  br label %bb16
bb16:
  %t72 = load ptr, ptr %lp2
  %t73 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t73, i1 false)
  br label %bb17
bb17:
  %t75 = load ptr, ptr %lp2
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t75, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t76, i1 false)
  br label %bb18
bb18:
  %t78 = load ptr, ptr %lp2
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t79, i64 -1)
  br label %bb19
bb19:
  %t81 = load ptr, ptr %lp2
  %t82 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v2, ptr %v2, ptr %t82, ptr null)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb9
bb22:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 11
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load ptr, ptr %lp2
  store ptr %t97, ptr %l56, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 11
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb25, label %bb26
bb24:
  br label %bb29
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d25bca10c486d8b4_954c3a018844fd8)
  unreachable
bb26:
  br label %bb27
bb27:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Body", ptr %t105, i32 0, i32 11
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v2, ptr %v1, ptr %t110, ptr %t108)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Body", ptr %t112, i32 0, i32 10
  store ptr %t114, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t116 = load i64, ptr %l10, !tbaa !24
  store i64 %t116, ptr %l65, !tbaa !24
  %t117 = load ptr, ptr %l9, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t117)
  store i64 %t119, ptr %l67
  br label %bb31
bb31:
  %t120 = load i64, ptr %l65, !tbaa !24
  %t121 = load i64, ptr %l67, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t126, i64 %t127)
  store i32 %t130, ptr %l72
  br label %bb35
bb35:
  %t131 = load i32, ptr %l72, !tbaa !23
  %t132 = load ptr, ptr %lp2
  %t133 = getelementptr %"compiler/typed:LocalUses", ptr %t132, i32 0, i32 7
  %t136 = sext i32 %t131 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t133, i64 %t136, i1 true)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l10, !tbaa !24
  br label %bb30
bb38:
  %t143 = load ptr, ptr %lp2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v2, ptr %t143)
  br label %bb39
bb39:
  %t145 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t145, i64 704, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l79, i64 704, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load i32, ptr %l13, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 19 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = icmp eq i32 %t23, 0
  store i1 %t24, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 23 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = load i32, ptr %l27, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t66, i32 %t64)
  store i1 %t70, ptr %l40
  br label %bb19
bb19:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ecb034f719e18c1b_985175307bfdc34f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Arm", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l18
  br label %bb4
bb4:
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Arm", ptr %t20, i32 0, i32 4
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Arm", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l33, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Alt", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t59, i32 %t61)
  store i1 %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load i1, ptr %l40, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Alt", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t94 = getelementptr %"compiler/typed:Bind", ptr %t90, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t95, i32 %t97)
  store i1 %t100, ptr %l57
  br label %bb25
bb25:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb21
bb30:
  br label %bb31
bb31:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb13
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2earmsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %t28, i32 %a1)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecalleeBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t16, i32 %a1)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_352016b8dfbaae41_4f83dc304b77dded)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t28, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/typed:Local"
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 7
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/typed:Local" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/typed:Local", ptr %l6
  store %"compiler/typed:Local" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2ePrint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/typed:printer"
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l30 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v1, ptr %s0, ptr %a1)
  store %"compiler/typed:printer" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/typed:printer", ptr %l4
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/typed:printer" %t4, ptr %t5
  store ptr %t5, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 9
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l12, !tbaa !24
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = call i64 @__olang_fmt_i64(ptr null, i64 %t37)
  %t39 = add i64 %t36, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t25)
  %t46 = getelementptr i8, ptr %t44, i64 %t26
  call void @olang_textcopy(ptr %t46, ptr %t28, i64 %t29)
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t31)
  %t49 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t49, ptr %t34, i64 %t35)
  %t50 = getelementptr i8, ptr %t49, i64 %t35
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t37)
  %t52 = getelementptr i8, ptr %t50, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t40, i64 %t41)
  %t53 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t62 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %s0, ptr %s0, ptr %t62, i64 0, { i64, ptr } %t61)
  br label %bb5
bb5:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 11
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb6, label %bb7
bb6:
  %t73 = load ptr, ptr %l2, !tbaa !29
  store ptr %t73, ptr %l22, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 11
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb8, label %bb9
bb7:
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b47e7a13871964ca_e65b2c3f8690a096)
  unreachable
bb9:
  br label %bb10
bb10:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t81, i32 0, i32 11
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %s0, ptr %v0, ptr %t85, ptr %t84, i64 1)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/typed:printer", ptr %t87, i32 0, i32 1
  %t91 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t89)
  store { i64, ptr } %t91, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l6
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l6
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_6690d985632b6de7_b13460b3c8232d4b)
  unreachable
bb83:
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l3, !tbaa !23
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l3, !tbaa !23
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l3, !tbaa !23
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l3, !tbaa !23
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load i32, ptr %l3, !tbaa !23
  store i32 %t185, ptr %l6, !tbaa !23
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l4, !tbaa !23
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l4, !tbaa !23
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l4, !tbaa !23
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l4, !tbaa !23
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l4, !tbaa !23
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l6, !tbaa !23
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l5, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t279 = load ptr, ptr %l5, !tbaa !29
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120, !tbaa !23
  store i32 %t282, ptr %l6, !tbaa !23
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57)
  unreachable
bb84:
  %t283 = load i32, ptr %l6, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/typed:landState"
  %l21 = alloca %"compiler/typed:landState"
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca %"compiler/typed:landState"
  %l30 = alloca %"compiler/typed:landState"
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca %"compiler/typed:landState"
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l122 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l199 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca i1
  %l221 = alloca %"compiler/typed:landState"
  %l226 = alloca %"compiler/typed:landState"
  %l235 = alloca ptr
  %l236 = alloca i1
  %l249 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l274 = alloca %"compiler/typed:landState"
  %l279 = alloca %"compiler/typed:landState"
  %l288 = alloca { i64, ptr }
  %l302 = alloca %"compiler/typed:landState"
  %l308 = alloca %"compiler/typed:landState"
  %l313 = alloca ptr
  %l314 = alloca i1
  %l319 = alloca ptr
  %l320 = alloca i1
  %l332 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l342 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca i1
  %l354 = alloca ptr
  %l355 = alloca i1
  %l368 = alloca { i64, ptr }
  %l371 = alloca ptr
  %l372 = alloca i1
  %l382 = alloca ptr
  %l383 = alloca i1
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t6 = load ptr, ptr %l52, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l52, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l53, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l53, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t15 = load ptr, ptr %l56, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l56, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l57, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l57, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb220
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t24 = load ptr, ptr %l60, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l60, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l61, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l61, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 0
  %t36 = load %"compiler/source:Span", ptr %t35
  store %"compiler/source:Span" %t36, ptr %l2
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t45 = load ptr, ptr %l68, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l68, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l69, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l69, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l4
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l5, !tbaa !23
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load i32, ptr %t68
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t74 = load i32, ptr %t73, !tbaa !23
  %t76 = sext i32 %t74 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %t71, i32 %t69, i64 %t76, i1 true)
  br label %bb23
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb220
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t85 = load ptr, ptr %l84, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l84, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 3
  store i1 %t91, ptr %l85, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l85, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l7, !tbaa !29
  br label %bb35
bb30:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t100 = load ptr, ptr %l90, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l90, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 4
  store i1 %t106, ptr %l91, !tbaa !21
  br label %bb32
bb32:
  %t107 = load i1, ptr %l91, !tbaa !21
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l96, !tbaa !29
  %t115 = load ptr, ptr %l96, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Landings", ptr %t115, i32 0, i32 18
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = add i64 %t117, 1
  %t121 = load ptr, ptr %l96, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Landings", ptr %t121, i32 0, i32 18
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb36
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l101, !tbaa !29
  %t128 = load ptr, ptr %l101, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Landings", ptr %t128, i32 0, i32 18
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = sub i64 %t130, 1
  %t134 = load ptr, ptr %l101, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Landings", ptr %t134, i32 0, i32 18
  store i64 %t132, ptr %t135, !tbaa !24
  br label %bb220
bb37:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t137 = load ptr, ptr %l104, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l104, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 18}
  %t143 = icmp eq i64 %t141, 5
  store i1 %t143, ptr %l105, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l105, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t147, i32 0, i32 2
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Promote", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t151, ptr %t155)
  br label %bb43
bb43:
  br label %bb220
bb44:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t160 = load ptr, ptr %l114, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = load ptr, ptr %l114, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l115, !tbaa !21
  br label %bb46
bb46:
  %t167 = load i1, ptr %l115, !tbaa !21
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb49
bb48:
  br label %bb66
bb49:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Landings", ptr %t174, i32 0, i32 13
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l122
  br label %bb50
bb50:
  %t179 = load i64, ptr %l122, !tbaa !24
  store i64 %t179, ptr %l10, !tbaa !24
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Call", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  store ptr %t183, ptr %l11, !tbaa !29
  %t185 = load ptr, ptr %l11, !tbaa !29
  store ptr %t185, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t186 = load ptr, ptr %l125, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = load ptr, ptr %l125, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 5}
  %t192 = icmp eq i64 %t190, 2
  store i1 %t192, ptr %l126, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l126, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  %t194 = load ptr, ptr %l11, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { ptr }, ptr %t196, i32 0, i32 0
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l12, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb56
bb56:
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_9444a0fe500d35e5_4f818c2c3ae57dd9)
  unreachable
bb62:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l9, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Call", ptr %t206, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t205, { i64, ptr } %t209)
  br label %bb63
bb63:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %t212, i64 %t213)
  br label %bb64
bb64:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %t216, i64 %t217)
  br label %bb65
bb65:
  br label %bb220
bb66:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t221 = load ptr, ptr %l141, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb67, label %bb68
bb67:
  %t224 = load ptr, ptr %l141, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 7
  store i1 %t227, ptr %l142, !tbaa !21
  br label %bb68
bb68:
  %t228 = load i1, ptr %l142, !tbaa !21
  br i1 %t228, label %bb69, label %bb70
bb69:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Landings", ptr %t235, i32 0, i32 13
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l149
  br label %bb72
bb72:
  %t240 = load i64, ptr %l149, !tbaa !24
  store i64 %t240, ptr %l14, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l13, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Make", ptr %t242, i32 0, i32 2
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t241, { i64, ptr } %t245)
  br label %bb73
bb73:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l13, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Make", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t248, ptr %t252)
  br label %bb74
bb74:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %t255, i64 %t256)
  br label %bb75
bb75:
  br label %bb220
bb76:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t260 = load ptr, ptr %l158, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb77, label %bb78
bb77:
  %t263 = load ptr, ptr %l158, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 8
  store i1 %t266, ptr %l159, !tbaa !21
  br label %bb78
bb78:
  %t267 = load i1, ptr %l159, !tbaa !21
  br i1 %t267, label %bb79, label %bb80
bb79:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l15, !tbaa !29
  br label %bb81
bb80:
  br label %bb84
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l15, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Collect", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  br label %bb82
bb82:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l15, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Collect", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Block", ptr %t285, i32 0, i32 0
  %t288 = load i32, ptr %t287, !tbaa !23
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Collect", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %s12, ptr %t281, i32 %t288, ptr %t292, ptr null)
  br label %bb83
bb83:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Landings", ptr %t296, i32 0, i32 8
  store i1 false, ptr %t298, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb220
bb84:
  %t299 = load ptr, ptr %l1, !tbaa !29
  store ptr %t299, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t300 = load ptr, ptr %l174, !tbaa !29
  %t301 = icmp ne ptr %t300, null
  br i1 %t301, label %bb85, label %bb86
bb85:
  %t303 = load ptr, ptr %l174, !tbaa !29
  %t304 = load i64, ptr %t303, !range !{i64 0, i64 18}
  %t306 = icmp eq i64 %t304, 9
  store i1 %t306, ptr %l175, !tbaa !21
  br label %bb86
bb86:
  %t307 = load i1, ptr %l175, !tbaa !21
  br i1 %t307, label %bb87, label %bb88
bb87:
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t310, i32 0, i32 2
  %t312 = load i32, ptr %t311, !range !{i32 0, i32 47}
  store i32 %t312, ptr %l16
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t316, i32 0, i32 4
  %t318 = load { i64, ptr }, ptr %t317
  store { i64, ptr } %t318, ptr %l17, !tbaa !27
  br label %bb89
bb88:
  br label %bb94
bb89:
  %t320 = load i32, ptr %l16, !range !{i32 0, i32 47}
  %t322 = trunc i64 31 to i32
  %t323 = icmp eq i32 %t320, %t322
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb90, label %bb91
bb90:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t327, { i64, ptr } %t328)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  br label %bb220
bb94:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t332 = load ptr, ptr %l187, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb95, label %bb96
bb95:
  %t335 = load ptr, ptr %l187, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 18}
  %t338 = icmp eq i64 %t336, 10
  store i1 %t338, ptr %l188, !tbaa !21
  br label %bb96
bb96:
  %t339 = load i1, ptr %l188, !tbaa !21
  br i1 %t339, label %bb97, label %bb98
bb97:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t342, i32 0, i32 2
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l18, !tbaa !29
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l193, !tbaa !29
  %t347 = load ptr, ptr %l193, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Landings", ptr %t347, i32 0, i32 18
  %t349 = load i64, ptr %t348, !tbaa !24
  %t351 = add i64 %t349, 1
  %t353 = load ptr, ptr %l193, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Landings", ptr %t353, i32 0, i32 18
  store i64 %t351, ptr %t354, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l18, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Slice", ptr %t356, i32 0, i32 0
  %t359 = load ptr, ptr %t358, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t355, ptr %t359)
  br label %bb100
bb100:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l199, !tbaa !29
  %t363 = load ptr, ptr %l199, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Landings", ptr %t363, i32 0, i32 18
  %t365 = load i64, ptr %t364, !tbaa !24
  %t367 = sub i64 %t365, 1
  %t369 = load ptr, ptr %l199, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Landings", ptr %t369, i32 0, i32 18
  store i64 %t367, ptr %t370, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l18, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Slice", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t371, ptr %t375)
  br label %bb101
bb101:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l18, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Slice", ptr %t380, i32 0, i32 2
  %t383 = load ptr, ptr %t382, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t379, ptr %t383)
  br label %bb102
bb102:
  br label %bb220
bb103:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t388 = load ptr, ptr %l210, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb104, label %bb105
bb104:
  %t391 = load ptr, ptr %l210, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 11
  store i1 %t394, ptr %l211, !tbaa !21
  br label %bb105
bb105:
  %t395 = load i1, ptr %l211, !tbaa !21
  br i1 %t395, label %bb106, label %bb107
bb106:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t398, i32 0, i32 2
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l19, !tbaa !29
  br label %bb108
bb107:
  br label %bb116
bb108:
  store %olang.scope zeroinitializer, ptr %s16
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l19, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Cond", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t402, ptr %t406)
  br label %bb109
bb109:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s16, ptr %t410)
  store %"compiler/typed:landState" %t412, ptr %l221
  br label %bb110
bb110:
  %t413 = load %"compiler/typed:landState", ptr %l221
  store %"compiler/typed:landState" %t413, ptr %l20
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l19, !tbaa !29
  %t417 = getelementptr %"compiler/typed:Cond", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t414, ptr %t418)
  br label %bb111
bb111:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s16, ptr %t421)
  store %"compiler/typed:landState" %t423, ptr %l226
  br label %bb112
bb112:
  %t424 = load %"compiler/typed:landState", ptr %l226
  store %"compiler/typed:landState" %t424, ptr %l21
  %t425 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s16, ptr %t425, ptr %l20)
  br label %bb113
bb113:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Cond", ptr %t429, i32 0, i32 2
  %t432 = load ptr, ptr %t431, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t428, ptr %t432)
  br label %bb114
bb114:
  %t436 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s16, ptr %t436, ptr %l21)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s16)
  br label %bb220
bb116:
  %t439 = load ptr, ptr %l1, !tbaa !29
  store ptr %t439, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t440 = load ptr, ptr %l235, !tbaa !29
  %t441 = icmp ne ptr %t440, null
  br i1 %t441, label %bb117, label %bb118
bb117:
  %t443 = load ptr, ptr %l235, !tbaa !29
  %t444 = load i64, ptr %t443, !range !{i64 0, i64 18}
  %t446 = icmp eq i64 %t444, 12
  store i1 %t446, ptr %l236, !tbaa !21
  br label %bb118
bb118:
  %t447 = load i1, ptr %l236, !tbaa !21
  br i1 %t447, label %bb119, label %bb120
bb119:
  %t448 = load ptr, ptr %l1, !tbaa !29
  %t450 = getelementptr { i64, [5 x i64] }, ptr %t448, i32 0, i32 1
  %t451 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t450, i32 0, i32 2
  %t452 = load ptr, ptr %t451
  store ptr %t452, ptr %l22, !tbaa !29
  br label %bb121
bb120:
  br label %bb130
bb121:
  %t454 = load ptr, ptr %l22, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Seq", ptr %t454, i32 0, i32 0
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t459 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  store i64 %t461, ptr %l25, !tbaa !24
  br label %bb122
bb122:
  %t463 = load i64, ptr %l24, !tbaa !24
  %t464 = load i64, ptr %l25, !tbaa !24
  %t467 = icmp slt i64 %t463, %t464
  %t469 = xor i1 %t467, true
  br i1 %t469, label %bb123, label %bb124
bb123:
  br label %bb128
bb124:
  br label %bb125
bb125:
  %t471 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t471, ptr %l249, !tbaa !27
  %t472 = load i64, ptr %l24, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr ptr, ptr %t475, i64 %t472
  %t477 = load ptr, ptr %t476, !tbaa !39
  %t479 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %t479, ptr %t477)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t483 = load i64, ptr %l24, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l24, !tbaa !24
  br label %bb122
bb128:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l22, !tbaa !29
  %t490 = getelementptr %"compiler/typed:Seq", ptr %t488, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t487, ptr %t491)
  br label %bb129
bb129:
  br label %bb220
bb130:
  %t494 = load ptr, ptr %l1, !tbaa !29
  store ptr %t494, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t495 = load ptr, ptr %l259, !tbaa !29
  %t496 = icmp ne ptr %t495, null
  br i1 %t496, label %bb131, label %bb132
bb131:
  %t498 = load ptr, ptr %l259, !tbaa !29
  %t499 = load i64, ptr %t498, !range !{i64 0, i64 18}
  %t501 = icmp eq i64 %t499, 13
  store i1 %t501, ptr %l260, !tbaa !21
  br label %bb132
bb132:
  %t502 = load i1, ptr %l260, !tbaa !21
  br i1 %t502, label %bb133, label %bb134
bb133:
  %t503 = load ptr, ptr %l1, !tbaa !29
  %t505 = getelementptr { i64, [5 x i64] }, ptr %t503, i32 0, i32 1
  %t506 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t505, i32 0, i32 2
  %t507 = load ptr, ptr %t506
  store ptr %t507, ptr %l27, !tbaa !29
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %t509, ptr %t510)
  br label %bb136
bb136:
  br label %bb220
bb137:
  %t513 = load ptr, ptr %l1, !tbaa !29
  store ptr %t513, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t514 = load ptr, ptr %l267, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb138, label %bb139
bb138:
  %t517 = load ptr, ptr %l267, !tbaa !29
  %t518 = load i64, ptr %t517, !range !{i64 0, i64 18}
  %t520 = icmp eq i64 %t518, 14
  store i1 %t520, ptr %l268, !tbaa !21
  br label %bb139
bb139:
  %t521 = load i1, ptr %l268, !tbaa !21
  br i1 %t521, label %bb140, label %bb141
bb140:
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t524, i32 0, i32 2
  %t526 = load ptr, ptr %t525
  store ptr %t526, ptr %l28, !tbaa !29
  br label %bb142
bb141:
  br label %bb161
bb142:
  store %olang.scope zeroinitializer, ptr %s22
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s22, ptr %t528)
  store %"compiler/typed:landState" %t530, ptr %l274
  br label %bb143
bb143:
  %t531 = load %"compiler/typed:landState", ptr %l274
  store %"compiler/typed:landState" %t531, ptr %l29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load ptr, ptr %l28, !tbaa !29
  %t535 = getelementptr %"compiler/typed:Try", ptr %t533, i32 0, i32 0
  %t536 = load ptr, ptr %t535, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t532, ptr %t536)
  br label %bb144
bb144:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s22, ptr %t539)
  store %"compiler/typed:landState" %t541, ptr %l279
  br label %bb145
bb145:
  %t542 = load %"compiler/typed:landState", ptr %l279
  store %"compiler/typed:landState" %t542, ptr %l30
  %t543 = load ptr, ptr %l28, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Try", ptr %t543, i32 0, i32 1
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  store { i64, ptr } %t546, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t548, 0
  store i64 %t550, ptr %l33, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s24
  %t552 = load i64, ptr %l32, !tbaa !24
  %t553 = load i64, ptr %l33, !tbaa !24
  %t556 = icmp slt i64 %t552, %t553
  %t558 = xor i1 %t556, true
  br i1 %t558, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s24)
  br label %bb159
bb148:
  br label %bb149
bb149:
  %t560 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t560, ptr %l288, !tbaa !27
  %t561 = load i64, ptr %l32, !tbaa !24
  %t563 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr ptr, ptr %t564, i64 %t561
  %t566 = load ptr, ptr %t565, !tbaa !39
  store ptr %t566, ptr %l34, !tbaa !29
  %t568 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s22, ptr %t568, ptr %l29)
  br label %bb150
bb150:
  %t571 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s22, ptr %t571, ptr %l30)
  br label %bb151
bb151:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %l34, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Clause", ptr %t575, i32 0, i32 3
  %t578 = load ptr, ptr %t577, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t574, ptr %t578)
  br label %bb152
bb152:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l34, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Clause", ptr %t582, i32 0, i32 4
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t581, { i64, ptr } %t585)
  br label %bb153
bb153:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s24, ptr %t588)
  store %"compiler/typed:landState" %t590, ptr %l302
  br label %bb154
bb154:
  %t591 = load %"compiler/typed:landState", ptr %l302
  store %"compiler/typed:landState" %t591, ptr %l35
  %t592 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s22, ptr %t592, ptr %l30)
  br label %bb155
bb155:
  %t595 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s24, ptr %t595, ptr %l35)
  br label %bb156
bb156:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s22, ptr %t598)
  store %"compiler/typed:landState" %t600, ptr %l308
  br label %bb157
bb157:
  %t601 = load %"compiler/typed:landState", ptr %l308
  store %"compiler/typed:landState" %t601, ptr %l30
  call void @__olang_scope_close(ptr %s24)
  br label %bb158
bb158:
  %t602 = load i64, ptr %l32, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l32, !tbaa !24
  br label %bb146
bb159:
  %t606 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s22, ptr %t606, ptr %l30)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s22)
  br label %bb220
bb161:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t610 = load ptr, ptr %l313, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb162, label %bb163
bb162:
  %t613 = load ptr, ptr %l313, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 18}
  %t616 = icmp eq i64 %t614, 15
  store i1 %t616, ptr %l314, !tbaa !21
  br label %bb163
bb163:
  %t617 = load i1, ptr %l314, !tbaa !21
  br i1 %t617, label %bb164, label %bb165
bb164:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t620, i32 0, i32 2
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l36, !tbaa !29
  br label %bb166
bb165:
  br label %bb194
bb166:
  %t624 = load ptr, ptr %l36, !tbaa !29
  store ptr %t624, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t625 = load ptr, ptr %l319, !tbaa !29
  %t626 = icmp ne ptr %t625, null
  br i1 %t626, label %bb167, label %bb168
bb167:
  %t628 = load ptr, ptr %l319, !tbaa !29
  %t629 = load i64, ptr %t628, !range !{i64 0, i64 3}
  %t631 = icmp eq i64 %t629, 1
  store i1 %t631, ptr %l320, !tbaa !21
  br label %bb168
bb168:
  %t632 = load i1, ptr %l320, !tbaa !21
  br i1 %t632, label %bb169, label %bb170
bb169:
  %t633 = load ptr, ptr %l36, !tbaa !29
  %t635 = getelementptr { i64, [4 x i64] }, ptr %t633, i32 0, i32 1
  %t636 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t635, i32 0, i32 1
  %t637 = load { i64, ptr }, ptr %t636
  store { i64, ptr } %t637, ptr %l37, !tbaa !27
  br label %bb171
bb170:
  br label %bb179
bb171:
  %t639 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t639, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t641 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t641, 0
  store i64 %t643, ptr %l40, !tbaa !24
  br label %bb172
bb172:
  %t645 = load i64, ptr %l39, !tbaa !24
  %t646 = load i64, ptr %l40, !tbaa !24
  %t649 = icmp slt i64 %t645, %t646
  %t651 = xor i1 %t649, true
  br i1 %t651, label %bb173, label %bb174
bb173:
  br label %bb178
bb174:
  br label %bb175
bb175:
  %t653 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t653, ptr %l332, !tbaa !27
  %t654 = load i64, ptr %l39, !tbaa !24
  %t656 = getelementptr { i64, ptr }, ptr %l332, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = getelementptr ptr, ptr %t657, i64 %t654
  %t659 = load ptr, ptr %t658, !tbaa !39
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/typed:Capture", ptr %t659, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t661, ptr %t665)
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t669 = load i64, ptr %l39, !tbaa !24
  %t671 = add i64 %t669, 1
  store i64 %t671, ptr %l39, !tbaa !24
  br label %bb172
bb178:
  br label %bb193
bb179:
  %t673 = load ptr, ptr %l36, !tbaa !29
  store ptr %t673, ptr %l341, !tbaa !29
  store i1 false, ptr %l342, !tbaa !21
  %t674 = load ptr, ptr %l341, !tbaa !29
  %t675 = icmp ne ptr %t674, null
  br i1 %t675, label %bb180, label %bb181
bb180:
  %t677 = load ptr, ptr %l341, !tbaa !29
  %t678 = load i64, ptr %t677, !range !{i64 0, i64 3}
  %t680 = icmp eq i64 %t678, 2
  store i1 %t680, ptr %l342, !tbaa !21
  br label %bb181
bb181:
  %t681 = load i1, ptr %l342, !tbaa !21
  br i1 %t681, label %bb182, label %bb183
bb182:
  %t682 = load ptr, ptr %l36, !tbaa !29
  %t684 = getelementptr { i64, [4 x i64] }, ptr %t682, i32 0, i32 1
  %t685 = getelementptr { i32, ptr, i32 }, ptr %t684, i32 0, i32 1
  %t686 = load ptr, ptr %t685
  store ptr %t686, ptr %l42, !tbaa !29
  br label %bb184
bb183:
  br label %bb186
bb184:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t688, ptr %t689)
  br label %bb185
bb185:
  br label %bb193
bb186:
  %t693 = load ptr, ptr %l36, !tbaa !29
  store ptr %t693, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t694 = load ptr, ptr %l350, !tbaa !29
  %t695 = icmp ne ptr %t694, null
  br i1 %t695, label %bb187, label %bb188
bb187:
  %t697 = load ptr, ptr %l350, !tbaa !29
  %t698 = load i64, ptr %t697, !range !{i64 0, i64 3}
  %t700 = icmp eq i64 %t698, 0
  store i1 %t700, ptr %l351, !tbaa !21
  br label %bb188
bb188:
  %t701 = load i1, ptr %l351, !tbaa !21
  br i1 %t701, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  br label %bb193
bb192:
  call void @__olang_check_failed(ptr @olang_loc_3f422f8bccda2eb4_607c7ad0cff40408)
  unreachable
bb193:
  br label %bb220
bb194:
  %t702 = load ptr, ptr %l1, !tbaa !29
  store ptr %t702, ptr %l354, !tbaa !29
  store i1 false, ptr %l355, !tbaa !21
  %t703 = load ptr, ptr %l354, !tbaa !29
  %t704 = icmp ne ptr %t703, null
  br i1 %t704, label %bb195, label %bb196
bb195:
  %t706 = load ptr, ptr %l354, !tbaa !29
  %t707 = load i64, ptr %t706, !range !{i64 0, i64 18}
  %t709 = icmp eq i64 %t707, 16
  store i1 %t709, ptr %l355, !tbaa !21
  br label %bb196
bb196:
  %t710 = load i1, ptr %l355, !tbaa !21
  br i1 %t710, label %bb197, label %bb198
bb197:
  %t711 = load ptr, ptr %l1, !tbaa !29
  %t713 = getelementptr { i64, [5 x i64] }, ptr %t711, i32 0, i32 1
  %t714 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t713, i32 0, i32 2
  %t715 = load ptr, ptr %t714
  store ptr %t715, ptr %l43, !tbaa !29
  br label %bb199
bb198:
  br label %bb212
bb199:
  %t717 = load ptr, ptr %l43, !tbaa !29
  %t719 = getelementptr %"compiler/typed:Text", ptr %t717, i32 0, i32 0
  %t720 = load { i64, ptr }, ptr %t719, !tbaa !27
  store { i64, ptr } %t720, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t722 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t722, 0
  store i64 %t724, ptr %l46, !tbaa !24
  br label %bb200
bb200:
  %t726 = load i64, ptr %l45, !tbaa !24
  %t727 = load i64, ptr %l46, !tbaa !24
  %t730 = icmp slt i64 %t726, %t727
  %t732 = xor i1 %t730, true
  br i1 %t732, label %bb201, label %bb202
bb201:
  br label %bb211
bb202:
  br label %bb203
bb203:
  %t734 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t734, ptr %l368, !tbaa !27
  %t735 = load i64, ptr %l45, !tbaa !24
  %t737 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !27
  %t739 = getelementptr ptr, ptr %t738, i64 %t735
  %t740 = load ptr, ptr %t739, !tbaa !39
  store ptr %t740, ptr %l47, !tbaa !29
  %t742 = load ptr, ptr %l47, !tbaa !29
  store ptr %t742, ptr %l371, !tbaa !29
  store i1 false, ptr %l372, !tbaa !21
  %t743 = load ptr, ptr %l371, !tbaa !29
  %t744 = icmp ne ptr %t743, null
  br i1 %t744, label %bb204, label %bb205
bb204:
  %t746 = load ptr, ptr %l371, !tbaa !29
  %t747 = load i64, ptr %t746, !range !{i64 0, i64 2}
  %t749 = icmp eq i64 %t747, 1
  store i1 %t749, ptr %l372, !tbaa !21
  br label %bb205
bb205:
  %t750 = load i1, ptr %l372, !tbaa !21
  br i1 %t750, label %bb206, label %bb207
bb206:
  %t751 = load ptr, ptr %l47, !tbaa !29
  %t753 = getelementptr { i64, [2 x i64] }, ptr %t751, i32 0, i32 1
  %t754 = getelementptr { ptr }, ptr %t753, i32 0, i32 0
  %t755 = load ptr, ptr %t754
  %t757 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t757, ptr %t755)
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb209
bb209:
  br label %bb210
bb210:
  %t762 = load i64, ptr %l45, !tbaa !24
  %t764 = add i64 %t762, 1
  store i64 %t764, ptr %l45, !tbaa !24
  br label %bb200
bb211:
  br label %bb220
bb212:
  %t766 = load ptr, ptr %l1, !tbaa !29
  store ptr %t766, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t767 = load ptr, ptr %l382, !tbaa !29
  %t768 = icmp ne ptr %t767, null
  br i1 %t768, label %bb213, label %bb214
bb213:
  %t770 = load ptr, ptr %l382, !tbaa !29
  %t771 = load i64, ptr %t770, !range !{i64 0, i64 18}
  %t773 = icmp eq i64 %t771, 17
  store i1 %t773, ptr %l383, !tbaa !21
  br label %bb214
bb214:
  %t774 = load i1, ptr %l383, !tbaa !21
  br i1 %t774, label %bb215, label %bb216
bb215:
  %t775 = load ptr, ptr %l1, !tbaa !29
  %t777 = getelementptr { i64, [5 x i64] }, ptr %t775, i32 0, i32 1
  %t778 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t777, i32 0, i32 2
  %t779 = load ptr, ptr %t778
  store ptr %t779, ptr %l49, !tbaa !29
  br label %bb217
bb216:
  br label %bb219
bb217:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t781, ptr %t782)
  br label %bb218
bb218:
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_90af12c8bdcc10ef_2ee3a51413a547e3)
  unreachable
bb220:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eguardedAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l49 = alloca i1
  %l51 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Landings", ptr %t54, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i64, ptr %t61, i64 %t58
  %t63 = load i64, ptr %t62, !tbaa !34
  %t67 = icmp eq i64 %t63, %a1
  br i1 %t67, label %bb11, label %bb12
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Landings", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i64, ptr %t76, i64 %t73
  %t78 = load i64, ptr %t77, !tbaa !34
  %t82 = icmp eq i64 %t78, %a2
  store i1 %t82, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb14, label %bb15
bb14:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Landings", ptr %t85, i32 0, i32 3
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l51, !tbaa !27
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i1, ptr %t92, i64 %t89
  %t94 = load i1, ptr %t93, !tbaa !31
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb7
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/typed:landState"
  %l3 = alloca %"compiler/typed:landState"
  %l9 = alloca %"compiler/typed:landState"
  %l15 = alloca %"compiler/typed:landState"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:If", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t9)
  store %"compiler/typed:landState" %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load %"compiler/typed:landState", ptr %l9
  store %"compiler/typed:landState" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:If", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t13, ptr %t17)
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t21)
  store %"compiler/typed:landState" %t23, ptr %l15
  br label %bb4
bb4:
  %t24 = load %"compiler/typed:landState", ptr %l15
  store %"compiler/typed:landState" %t24, ptr %l3
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t25, ptr %l2)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:If", ptr %t29, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t28, ptr %t32)
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t35, ptr %l3)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i1
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 13
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i64, ptr %l18, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb56
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 17
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l46
  br label %bb12
bb12:
  %t62 = load i1, ptr %l46, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l49, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Landings", ptr %t66, i32 0, i32 13
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l53
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t75, ptr %l54
  br label %bb16
bb16:
  %t76 = load i1, ptr %l54, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  br label %bb55
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 13
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l59
  br label %bb21
bb21:
  %t87 = load i64, ptr %l59, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb27
bb24:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l66, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb26
bb26:
  %t114 = load i64, ptr %l66, !tbaa !24
  store i64 %t114, ptr %l63, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l63, !tbaa !24
  store i64 %t115, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb29, label %bb30
bb29:
  br label %bb54
bb30:
  br label %bb31
bb31:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l13, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Landings", ptr %t134, i32 0, i32 13
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l87
  br label %bb32
bb32:
  %t141 = load i64, ptr %l87, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  store i64 %t142, ptr %l88, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Landings", ptr %t143, i32 0, i32 13
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l92
  br label %bb33
bb33:
  %t150 = load i64, ptr %l88, !tbaa !24
  %t151 = load i64, ptr %l92, !tbaa !24
  %t152 = icmp eq i64 %t150, %t151
  br i1 %t152, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb37
bb35:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Landings", ptr %t154, i32 0, i32 16
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t156, i64 %t157)
  store i1 %t160, ptr %l98
  br label %bb36
bb36:
  %t161 = load i1, ptr %l98, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l94, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l94, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb40
bb39:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = icmp slt i64 %t165, 0
  store i1 %t167, ptr %l100, !tbaa !21
  br label %bb40
bb40:
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb43
bb42:
  %t170 = load i64, ptr %l14, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Landings", ptr %t171, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t179 = icmp sge i64 %t170, %t176
  store i1 %t179, ptr %l103, !tbaa !21
  br label %bb43
bb43:
  %t181 = load i1, ptr %l103, !tbaa !21
  br i1 %t181, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb46
bb45:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Landings", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l111, !tbaa !27
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t186
  %t191 = load i1, ptr %t190, !tbaa !31
  %t193 = xor i1 %t191, true
  store i1 %t193, ptr %l109, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l109, !tbaa !21
  br i1 %t195, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  br label %bb49
bb49:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Landings", ptr %t196, i32 0, i32 19
  %t199 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t198, i64 %t199)
  br label %bb50
bb50:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Landings", ptr %t202, i32 0, i32 20
  store ptr %t204, ptr %l119, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Landings", ptr %t205, i32 0, i32 13
  %t208 = load i64, ptr %l7, !tbaa !24
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t208)
  store i64 %t211, ptr %l123
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l119, !tbaa !29
  %t213 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l12, !tbaa !24
  br label %bb28
bb54:
  br label %bb55
bb55:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb8
bb56:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t2, i32 0, i32 10
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Landings", ptr %t8, i32 0, i32 10
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Landings", ptr %t15, i32 0, i32 10
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sub i64 %t17, 1
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Landings", ptr %t21, i32 0, i32 10
  store i64 %t19, ptr %t22, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:landState", ptr %t10, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Landings", ptr %t15, i32 0, i32 7
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb13
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l23, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l20, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Landings", ptr %t68, i32 0, i32 7
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Landings", ptr %t73, i32 0, i32 7
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l45, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t77
  %t82 = load i1, ptr %t81, !tbaa !31
  br i1 %t82, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:landState", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l50, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i1, ptr %t91, i64 %t88
  %t93 = load i1, ptr %t92, !tbaa !31
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l48, !tbaa !21
  %t96 = load i64, ptr %l43, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i1, ptr %t98, i64 %t96
  store i1 %t95, ptr %t99, !tbaa !31
  br label %bb21
bb21:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %t22, i32 %t23, i64 %t27, i1 false)
  br label %bb6
bb6:
  br label %bb54
bb7:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb13
bb13:
  br label %bb54
bb14:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 3
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l32, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb20
bb20:
  br label %bb54
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l6, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 18
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Landings", ptr %t97, i32 0, i32 18
  store i64 0, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Elem", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t100, ptr %t104)
  br label %bb28
bb28:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr %"compiler/typed:Landings", ptr %t108, i32 0, i32 18
  store i64 %t109, ptr %t112, !tbaa !24
  br label %bb54
bb29:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t117 = load ptr, ptr %l57, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 8}
  %t120 = icmp eq i64 %t118, 5
  store i1 %t120, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Payload", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t136 = load ptr, ptr %l66, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t139 = load ptr, ptr %l66, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 6
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l67, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  br label %bb42
bb42:
  br label %bb54
bb43:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t156 = load ptr, ptr %l75, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb44, label %bb45
bb44:
  %t159 = load ptr, ptr %l75, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 8}
  %t162 = icmp eq i64 %t160, 1
  store i1 %t162, ptr %l76, !tbaa !21
  br label %bb45
bb45:
  %t163 = load i1, ptr %l76, !tbaa !21
  br i1 %t163, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l79, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 8}
  %t171 = icmp eq i64 %t169, 7
  store i1 %t171, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t172 = load i1, ptr %l80, !tbaa !21
  br i1 %t172, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_af04a8710b199599_1473152472f015d)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 13
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l16, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 15
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l40
  br label %bb12
bb12:
  %t62 = load i1, ptr %l40, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Landings", ptr %t63, i32 0, i32 13
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i64, ptr %l1, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  %t80 = load i64, ptr %l45, !tbaa !24
  %t82 = icmp eq i64 %t80, %t79
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Landings", ptr %t85, i32 0, i32 14
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l57, !tbaa !27
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i64, ptr %t99, i64 %t96
  %t101 = load i64, ptr %t100, !tbaa !34
  %t102 = load i64, ptr %l55, !tbaa !24
  %t104 = icmp eq i64 %t102, %t101
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l51, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca %"compiler/typed:landState"
  %rv = alloca %"compiler/typed:landState"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t15, ptr %lp1
  %t17 = load ptr, ptr %lp1
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %lp1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e933c796b27591a8_e869c9717a33729c)
  unreachable
bb3:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l21, !tbaa !24
  store i64 %t49, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l18, !tbaa !24
  store i64 %t50, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 7
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i1, ptr %t77, i64 %t74
  %t79 = load i1, ptr %t78, !tbaa !31
  %t81 = load ptr, ptr %lp1
  %t83 = getelementptr { i64, ptr }, ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i1, ptr %t84, i64 %t69
  store i1 %t79, ptr %t85, !tbaa !31
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb9
bb14:
  %t90 = load ptr, ptr %lp1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 8
  %t95 = load i1, ptr %t94, !tbaa !21
  %t98 = call %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v1, ptr %v1, { i64, ptr } %t91, i1 %t95)
  store %"compiler/typed:landState" %t98, ptr %l49
  br label %bb15
bb15:
  %t99 = load %"compiler/typed:landState", ptr %l49
  store %"compiler/typed:landState" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:landState", ptr %rv
  ret %"compiler/typed:landState" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca ptr
  %l137 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l211 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t6 = load ptr, ptr %l33, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l33, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t15 = load ptr, ptr %l37, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l37, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l38, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb170
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t24 = load ptr, ptr %l41, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l41, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l42, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t39 = load ptr, ptr %l47, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l47, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l48, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t54 = load ptr, ptr %l53, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l53, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb170
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l61, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l62, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l62, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb170
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t96 = load ptr, ptr %l71, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l71, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l72, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LastUses", ptr %t110, i32 0, i32 3
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LastUses", ptr %t115, i32 0, i32 6
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb41
bb41:
  %t120 = load i64, ptr %l81, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  store ptr %t126, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t127 = load ptr, ptr %l84, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l84, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 5}
  %t133 = icmp eq i64 %t131, 2
  store i1 %t133, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l85, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { ptr }, ptr %t137, i32 0, i32 0
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l8, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_198aad80d0550ab5_c06608159f163401)
  unreachable
bb53:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  br label %bb54
bb54:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i64, ptr %l5, !tbaa !24
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  br label %bb55
bb55:
  br label %bb170
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l99, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 7
  store i1 %t166, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb67
bb61:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LastUses", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/typed:LastUses", ptr %t179, i32 0, i32 6
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l109
  br label %bb62
bb62:
  %t184 = load i64, ptr %l109, !tbaa !24
  store i64 %t184, ptr %l11, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %t185, ptr %t186)
  br label %bb63
bb63:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Make", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t189, { i64, ptr } %t193)
  br label %bb64
bb64:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l9, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Make", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  br label %bb65
bb65:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t203, i64 %t204, i64 %t205)
  br label %bb66
bb66:
  br label %bb170
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l121, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 8
  store i1 %t216, ptr %l122, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l122, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Collect", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t228)
  br label %bb73
bb73:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l130, !tbaa !29
  %t232 = load ptr, ptr %l130, !tbaa !29
  %t233 = getelementptr %"compiler/typed:LastUses", ptr %t232, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  %t236 = add i64 %t234, 1
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t239 = getelementptr %"compiler/typed:LastUses", ptr %t238, i32 0, i32 4
  store i64 %t236, ptr %t239, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Collect", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb74
bb74:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l137, !tbaa !29
  %t249 = load ptr, ptr %l137, !tbaa !29
  %t250 = getelementptr %"compiler/typed:LastUses", ptr %t249, i32 0, i32 4
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = sub i64 %t251, 1
  %t255 = load ptr, ptr %l137, !tbaa !29
  %t256 = getelementptr %"compiler/typed:LastUses", ptr %t255, i32 0, i32 4
  store i64 %t253, ptr %t256, !tbaa !24
  br label %bb170
bb75:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t258 = load ptr, ptr %l140, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb76, label %bb77
bb76:
  %t261 = load ptr, ptr %l140, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 18}
  %t264 = icmp eq i64 %t262, 9
  store i1 %t264, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t265 = load i1, ptr %l141, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [5 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t268, i32 0, i32 4
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l13, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t273)
  br label %bb81
bb81:
  br label %bb170
bb82:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb83, label %bb84
bb83:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 10
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb84
bb84:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb85, label %bb86
bb85:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 2
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l14, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Slice", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t291, ptr %t295)
  br label %bb88
bb88:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l14, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Slice", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t298, ptr %t302)
  br label %bb89
bb89:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l14, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Slice", ptr %t307, i32 0, i32 2
  %t310 = load ptr, ptr %t309, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t306, ptr %t310)
  br label %bb90
bb90:
  br label %bb170
bb91:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t315 = load ptr, ptr %l165, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb92, label %bb93
bb92:
  %t318 = load ptr, ptr %l165, !tbaa !29
  %t319 = load i64, ptr %t318, !range !{i64 0, i64 18}
  %t321 = icmp eq i64 %t319, 11
  store i1 %t321, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t322 = load i1, ptr %l166, !tbaa !21
  br i1 %t322, label %bb94, label %bb95
bb94:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t325, i32 0, i32 2
  %t327 = load ptr, ptr %t326
  store ptr %t327, ptr %l15, !tbaa !29
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Cond", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t333)
  br label %bb97
bb97:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l15, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Cond", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t337, ptr %t341)
  br label %bb98
bb98:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l15, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Cond", ptr %t345, i32 0, i32 2
  %t348 = load ptr, ptr %t347, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t348)
  br label %bb99
bb99:
  br label %bb170
bb100:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t353 = load ptr, ptr %l182, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb101, label %bb102
bb101:
  %t356 = load ptr, ptr %l182, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 18}
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l183, !tbaa !21
  br label %bb102
bb102:
  %t360 = load i1, ptr %l183, !tbaa !21
  br i1 %t360, label %bb103, label %bb104
bb103:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l16, !tbaa !29
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l16, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t367, { i64, ptr } %t371)
  br label %bb106
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l16, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Seq", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t374, ptr %t378)
  br label %bb107
bb107:
  br label %bb170
bb108:
  %t381 = load ptr, ptr %l1, !tbaa !29
  store ptr %t381, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t382 = load ptr, ptr %l194, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb109, label %bb110
bb109:
  %t385 = load ptr, ptr %l194, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 18}
  %t388 = icmp eq i64 %t386, 13
  store i1 %t388, ptr %l195, !tbaa !21
  br label %bb110
bb110:
  %t389 = load i1, ptr %l195, !tbaa !21
  br i1 %t389, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t392, i32 0, i32 2
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l17, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l17, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t396, { i64, ptr } %t400)
  br label %bb114
bb114:
  %t403 = load ptr, ptr %l17, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Match", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t408 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  store i64 %t410, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t412 = load i64, ptr %l19, !tbaa !24
  %t413 = load i64, ptr %l20, !tbaa !24
  %t416 = icmp slt i64 %t412, %t413
  %t418 = xor i1 %t416, true
  br i1 %t418, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t420 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t420, ptr %l211, !tbaa !27
  %t421 = load i64, ptr %l19, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr ptr, ptr %t424, i64 %t421
  %t426 = load ptr, ptr %t425, !tbaa !39
  %t428 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t428, ptr %t426)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t432 = load i64, ptr %l19, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l19, !tbaa !24
  br label %bb115
bb121:
  %t436 = load ptr, ptr %l17, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Match", ptr %t436, i32 0, i32 2
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = icmp eq ptr %t439, null
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb122, label %bb123
bb122:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l222, !tbaa !29
  %t446 = load ptr, ptr %l17, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Match", ptr %t446, i32 0, i32 2
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = icmp eq ptr %t449, null
  br i1 %t451, label %bb124, label %bb125
bb123:
  br label %bb128
bb124:
  call void @__olang_check_failed(ptr @olang_loc_28655f8a56cf669d_dc60f62ebe04c639)
  unreachable
bb125:
  br label %bb126
bb126:
  %t453 = load ptr, ptr %l17, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Match", ptr %t453, i32 0, i32 2
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t457 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t457, ptr %t456)
  br label %bb127
bb127:
  br label %bb128
bb128:
  br label %bb170
bb129:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t460 = load ptr, ptr %l228, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb130, label %bb131
bb130:
  %t463 = load ptr, ptr %l228, !tbaa !29
  %t464 = load i64, ptr %t463, !range !{i64 0, i64 18}
  %t466 = icmp eq i64 %t464, 14
  store i1 %t466, ptr %l229, !tbaa !21
  br label %bb131
bb131:
  %t467 = load i1, ptr %l229, !tbaa !21
  br i1 %t467, label %bb132, label %bb133
bb132:
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t470, i32 0, i32 2
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l22, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Try", ptr %t475, i32 0, i32 0
  %t478 = load ptr, ptr %t477, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t474, ptr %t478)
  br label %bb135
bb135:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l22, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Try", ptr %t482, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t481, { i64, ptr } %t485)
  br label %bb136
bb136:
  br label %bb170
bb137:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t489 = load ptr, ptr %l240, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb138, label %bb139
bb138:
  %t492 = load ptr, ptr %l240, !tbaa !29
  %t493 = load i64, ptr %t492, !range !{i64 0, i64 18}
  %t495 = icmp eq i64 %t493, 15
  store i1 %t495, ptr %l241, !tbaa !21
  br label %bb139
bb139:
  %t496 = load i1, ptr %l241, !tbaa !21
  br i1 %t496, label %bb140, label %bb141
bb140:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t499, i32 0, i32 2
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l23, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %t503, ptr %t504)
  br label %bb143
bb143:
  br label %bb170
bb144:
  %t507 = load ptr, ptr %l1, !tbaa !29
  store ptr %t507, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t508 = load ptr, ptr %l248, !tbaa !29
  %t509 = icmp ne ptr %t508, null
  br i1 %t509, label %bb145, label %bb146
bb145:
  %t511 = load ptr, ptr %l248, !tbaa !29
  %t512 = load i64, ptr %t511, !range !{i64 0, i64 18}
  %t514 = icmp eq i64 %t512, 16
  store i1 %t514, ptr %l249, !tbaa !21
  br label %bb146
bb146:
  %t515 = load i1, ptr %l249, !tbaa !21
  br i1 %t515, label %bb147, label %bb148
bb147:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t518, i32 0, i32 2
  %t520 = load ptr, ptr %t519
  store ptr %t520, ptr %l24, !tbaa !29
  br label %bb149
bb148:
  br label %bb162
bb149:
  %t522 = load ptr, ptr %l24, !tbaa !29
  %t524 = getelementptr %"compiler/typed:Text", ptr %t522, i32 0, i32 0
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t527, 0
  store i64 %t529, ptr %l27, !tbaa !24
  br label %bb150
bb150:
  %t531 = load i64, ptr %l26, !tbaa !24
  %t532 = load i64, ptr %l27, !tbaa !24
  %t535 = icmp slt i64 %t531, %t532
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb151, label %bb152
bb151:
  br label %bb161
bb152:
  br label %bb153
bb153:
  %t539 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t539, ptr %l262, !tbaa !27
  %t540 = load i64, ptr %l26, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr ptr, ptr %t543, i64 %t540
  %t545 = load ptr, ptr %t544, !tbaa !39
  store ptr %t545, ptr %l28, !tbaa !29
  %t547 = load ptr, ptr %l28, !tbaa !29
  store ptr %t547, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t548 = load ptr, ptr %l265, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb154, label %bb155
bb154:
  %t551 = load ptr, ptr %l265, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 2}
  %t554 = icmp eq i64 %t552, 1
  store i1 %t554, ptr %l266, !tbaa !21
  br label %bb155
bb155:
  %t555 = load i1, ptr %l266, !tbaa !21
  br i1 %t555, label %bb156, label %bb157
bb156:
  %t556 = load ptr, ptr %l28, !tbaa !29
  %t558 = getelementptr { i64, [2 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { ptr }, ptr %t558, i32 0, i32 0
  %t560 = load ptr, ptr %t559
  %t562 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t562, ptr %t560)
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t567 = load i64, ptr %l26, !tbaa !24
  %t569 = add i64 %t567, 1
  store i64 %t569, ptr %l26, !tbaa !24
  br label %bb150
bb161:
  br label %bb170
bb162:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t572 = load ptr, ptr %l276, !tbaa !29
  %t573 = icmp ne ptr %t572, null
  br i1 %t573, label %bb163, label %bb164
bb163:
  %t575 = load ptr, ptr %l276, !tbaa !29
  %t576 = load i64, ptr %t575, !range !{i64 0, i64 18}
  %t578 = icmp eq i64 %t576, 17
  store i1 %t578, ptr %l277, !tbaa !21
  br label %bb164
bb164:
  %t579 = load i1, ptr %l277, !tbaa !21
  br i1 %t579, label %bb165, label %bb166
bb165:
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t580, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t582, i32 0, i32 2
  %t584 = load ptr, ptr %t583
  store ptr %t584, ptr %l30, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t587)
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_d36f57f073c6a2ff_232866ca740484ab)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 3}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 3}
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_faea1712f2053751_ed9fc9ee56afb56d)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LastUses", ptr %t2, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LastUses", ptr %t8, i32 0, i32 5
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/typed:LastUses", ptr %t15, i32 0, i32 5
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sub i64 %t17, 1
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = getelementptr %"compiler/typed:LastUses", ptr %t21, i32 0, i32 5
  store i64 %t19, ptr %t22, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb54
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb54
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  br label %bb20
bb20:
  br label %bb54
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Elem", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  br label %bb27
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Elem", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  br label %bb28
bb28:
  br label %bb54
bb29:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb30, label %bb31
bb30:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Payload", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 8}
  %t118 = icmp eq i64 %t116, 6
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb39, label %bb40
bb39:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  br label %bb42
bb42:
  br label %bb54
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t132 = load ptr, ptr %l64, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l64, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb45
bb45:
  %t139 = load i1, ptr %l65, !tbaa !21
  br i1 %t139, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t141 = load ptr, ptr %l68, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb48, label %bb49
bb48:
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 8}
  %t147 = icmp eq i64 %t145, 7
  store i1 %t147, ptr %l69, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l69, !tbaa !21
  br i1 %t148, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_4860703a134569c9_d00fc34d053d5355)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l37 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i1
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l95 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca ptr
  %l112 = alloca i64
  %l117 = alloca i64
  %l122 = alloca i64
  %l125 = alloca i64
  %l146 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca i64
  %l168 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l196 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load i1, ptr %l25, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:LocalUses", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l30
  br label %bb4
bb4:
  %t16 = load i1, ptr %l30, !tbaa !21
  store i1 %t16, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l26, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t20, i64 %t21, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l37
  br label %bb10
bb10:
  %t31 = load i1, ptr %l37, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l44
  br label %bb15
bb15:
  %t45 = load i1, ptr %l44, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb19
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l49
  br label %bb18
bb18:
  %t53 = load i1, ptr %l49, !tbaa !21
  store i1 %t53, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l45, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 5
  %t58 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:LocalUses", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l56
  br label %bb24
bb24:
  %t68 = load i1, ptr %l56, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb28
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 7
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l61
  br label %bb27
bb27:
  %t76 = load i1, ptr %l61, !tbaa !21
  store i1 %t76, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l57, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l3, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 15
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l67
  br label %bb33
bb33:
  %t89 = load i64, ptr %l67, !tbaa !24
  store i64 %t89, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb34, label %bb35
bb34:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb39
bb36:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l74, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l74, !tbaa !24
  store i64 %t116, ptr %l71, !tbaa !24
  br label %bb39
bb39:
  %t117 = load i64, ptr %l71, !tbaa !24
  store i64 %t117, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb54
bb42:
  br label %bb43
bb43:
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l8, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:LocalUses", ptr %t136, i32 0, i32 15
  %t139 = load i64, ptr %l8, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l95
  br label %bb44
bb44:
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load i64, ptr %l95, !tbaa !24
  %t146 = icmp ne i64 %t144, %t143
  br i1 %t146, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  br label %bb47
bb47:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/typed:LocalUses", ptr %t148, i32 0, i32 15
  %t151 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  br label %bb48
bb48:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:LocalUses", ptr %t154, i32 0, i32 16
  store ptr %t156, ptr %l102, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 16
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l106
  br label %bb49
bb49:
  %t164 = load ptr, ptr %l102, !tbaa !29
  %t165 = load i64, ptr %l106, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t164, i64 %t165)
  br label %bb50
bb50:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:LocalUses", ptr %t166, i32 0, i32 17
  store ptr %t168, ptr %l108, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:LocalUses", ptr %t169, i32 0, i32 17
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l112
  br label %bb51
bb51:
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = load i64, ptr %l112, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t178 = load i64, ptr %l7, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l7, !tbaa !24
  br label %bb40
bb54:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:LocalUses", ptr %t182, i32 0, i32 12
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l117
  br label %bb55
bb55:
  %t187 = load i64, ptr %l117, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store i64 %t187, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l10, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb56, label %bb57
bb56:
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb61
bb58:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l12, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l125, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb60
bb60:
  %t216 = load i64, ptr %l125, !tbaa !24
  store i64 %t216, ptr %l122, !tbaa !24
  br label %bb61
bb61:
  %t217 = load i64, ptr %l122, !tbaa !24
  store i64 %t217, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb62
bb62:
  %t218 = load i64, ptr %l14, !tbaa !24
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t226 = load i64, ptr %l10, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l15, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/typed:LocalUses", ptr %t236, i32 0, i32 12
  %t239 = load i64, ptr %l15, !tbaa !24
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l146
  br label %bb66
bb66:
  %t243 = load i64, ptr %l1, !tbaa !24
  %t244 = load i64, ptr %l146, !tbaa !24
  %t246 = icmp ne i64 %t244, %t243
  br i1 %t246, label %bb67, label %bb68
bb67:
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/typed:LocalUses", ptr %t248, i32 0, i32 12
  %t251 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  br label %bb70
bb70:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/typed:LocalUses", ptr %t254, i32 0, i32 13
  store ptr %t256, ptr %l153, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/typed:LocalUses", ptr %t257, i32 0, i32 13
  %t260 = load i64, ptr %l15, !tbaa !24
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t259, i64 %t260)
  store i64 %t263, ptr %l157
  br label %bb71
bb71:
  %t264 = load ptr, ptr %l153, !tbaa !29
  %t265 = load i64, ptr %l157, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t264, i64 %t265)
  br label %bb72
bb72:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/typed:LocalUses", ptr %t266, i32 0, i32 14
  store ptr %t268, ptr %l159, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/typed:LocalUses", ptr %t269, i32 0, i32 14
  %t272 = load i64, ptr %l15, !tbaa !24
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t271, i64 %t272)
  store i64 %t275, ptr %l163
  br label %bb73
bb73:
  %t276 = load ptr, ptr %l159, !tbaa !29
  %t277 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t276, i64 %t277)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t278 = load i64, ptr %l14, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l14, !tbaa !24
  br label %bb62
bb76:
  store i64 0, ptr %l16, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/typed:LocalUses", ptr %t282, i32 0, i32 10
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l168
  br label %bb77
bb77:
  %t287 = load i64, ptr %l168, !tbaa !24
  store i64 %t287, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l16, !tbaa !24
  %t292 = icmp sgt i64 %t288, %t289
  br i1 %t292, label %bb78, label %bb79
bb78:
  %t294 = load i64, ptr %l18, !tbaa !24
  %t296 = icmp sgt i64 %t294, 0
  br i1 %t296, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb83
bb80:
  %t298 = load i64, ptr %l17, !tbaa !24
  %t299 = load i64, ptr %l16, !tbaa !24
  %t302 = sub i64 %t298, %t299
  %t303 = load i64, ptr %l18, !tbaa !24
  %t306 = add i64 %t302, %t303
  %t308 = sub i64 %t306, 1
  %t309 = load i64, ptr %l18, !tbaa !24
  %t312 = sdiv i64 %t308, %t309
  store i64 %t312, ptr %l175, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb82
bb82:
  %t314 = load i64, ptr %l175, !tbaa !24
  store i64 %t314, ptr %l172, !tbaa !24
  br label %bb83
bb83:
  %t315 = load i64, ptr %l172, !tbaa !24
  store i64 %t315, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb84
bb84:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb85, label %bb86
bb85:
  br label %bb94
bb86:
  br label %bb87
bb87:
  %t324 = load i64, ptr %l16, !tbaa !24
  %t325 = load i64, ptr %l20, !tbaa !24
  %t326 = load i64, ptr %l18, !tbaa !24
  %t329 = mul i64 %t325, %t326
  %t332 = add i64 %t324, %t329
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/typed:LocalUses", ptr %t334, i32 0, i32 10
  %t340 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t336, i64 %t332)
  store i64 %t340, ptr %l196
  br label %bb88
bb88:
  %t341 = load i64, ptr %l1, !tbaa !24
  %t342 = load i64, ptr %l196, !tbaa !24
  %t344 = icmp eq i64 %t342, %t341
  br i1 %t344, label %bb89, label %bb90
bb89:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/typed:LocalUses", ptr %t346, i32 0, i32 2
  %t349 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t348, i64 %t349, i1 true)
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t352 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb84
bb94:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t73 = alloca { i64, [1 x i64] }, align 8
  %t95 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30, { i64, [1 x i64] } %t34)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l10, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Bind", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = load ptr, ptr %l10, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Bind", ptr %t69, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 0
  store i64 4, ptr %t74
  %t76 = insertvalue { i32 } undef, i32 %t72, 0
  %t77 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 1
  store { i32 } %t76, ptr %t77
  %t78 = load { i64, [1 x i64] }, ptr %t73
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t67, { i64, [1 x i64] } %t78)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 0
  store i64 0, ptr %t96
  %t97 = load { i64, [1 x i64] }, ptr %t95
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t90, ptr %t94, { i64, [1 x i64] } %t97)
  br label %bb15
bb15:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t101, ptr %t105)
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Arm", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t108, ptr %t112, { i64, [1 x i64] } %a2)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i1
  %l80 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca i1
  %l107 = alloca i1
  %l125 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca i1
  %l129 = alloca i1
  %l133 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca ptr
  %l150 = alloca { i64, [1 x i64] }
  %t43 = alloca { i64, [1 x i64] }, align 8
  %t273 = alloca { i64, [1 x i64] }, align 8
  %t277 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l2, !tbaa !24
  br label %bb24
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  store ptr %t25, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l27, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 5}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l28, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { ptr }, ptr %t36, i32 0, i32 0
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l6, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t45 = load { i64, [1 x i64] }, ptr %t43
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t40, ptr %t41, { i64, [1 x i64] } %t45)
  br label %bb12
bb12:
  br label %bb24
bb13:
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l37, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 5}
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l38, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6ff368c26ca3ad9b_74caa00555ca222f)
  unreachable
bb24:
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb25, label %bb26
bb25:
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb30
bb27:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l50, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t91 = load i64, ptr %l50, !tbaa !24
  store i64 %t91, ptr %l47, !tbaa !24
  br label %bb30
bb30:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb31
bb31:
  %t93 = load i64, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  br label %bb89
bb33:
  br label %bb34
bb34:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l69, !tbaa !27
  %t115 = load i64, ptr %l12, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l13, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l13, !tbaa !29
  %t126 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  store i64 %t126, ptr %l74
  br label %bb35
bb35:
  %t127 = load i64, ptr %l74, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  %t128 = load i64, ptr %l14, !tbaa !24
  %t130 = icmp sge i64 %t128, 0
  br i1 %t130, label %bb36, label %bb37
bb36:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb38
bb38:
  %t136 = load i1, ptr %l77, !tbaa !21
  br i1 %t136, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/typed:LocalUses", ptr %t137, i32 0, i32 23
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = icmp eq i64 %t140, 0
  store i1 %t142, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t144 = load i1, ptr %l80, !tbaa !21
  br i1 %t144, label %bb42, label %bb43
bb42:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 12
  %t148 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t147, i64 %t148)
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:LocalUses", ptr %t151, i32 0, i32 13
  %t154 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t153, i64 %t154)
  br label %bb45
bb45:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 14
  %t160 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t159, i64 %t160)
  br label %bb46
bb46:
  br label %bb88
bb47:
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb48, label %bb49
bb48:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:LocalUses", ptr %t167, i32 0, i32 2
  %t170 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t169, i64 %t170, i1 true)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l13, !tbaa !29
  %t177 = call ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v1, ptr %t173, ptr %t174)
  store ptr %t177, ptr %l100
  br label %bb52
bb52:
  %t178 = load ptr, ptr %l100, !tbaa !29
  store ptr %t178, ptr %l15, !tbaa !29
  %t179 = load ptr, ptr %l15, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb53, label %bb54
bb53:
  %t185 = load i64, ptr %l2, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  store i1 %t187, ptr %l104, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb55
bb55:
  %t189 = load i1, ptr %l104, !tbaa !21
  br i1 %t189, label %bb56, label %bb57
bb56:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/typed:LocalUses", ptr %t190, i32 0, i32 23
  %t193 = load i64, ptr %t192, !tbaa !24
  %t195 = icmp eq i64 %t193, 0
  store i1 %t195, ptr %l107, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb58
bb58:
  %t197 = load i1, ptr %l107, !tbaa !21
  br i1 %t197, label %bb59, label %bb60
bb59:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/typed:LocalUses", ptr %t198, i32 0, i32 19
  %t201 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:LocalUses", ptr %t204, i32 0, i32 20
  %t207 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  br label %bb62
bb62:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %t210, i32 0, i32 21
  %t213 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  br label %bb63
bb63:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/typed:LocalUses", ptr %t216, i32 0, i32 22
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/typed:LocalUses", ptr %t219, i32 0, i32 24
  %t222 = load i32, ptr %t221, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t218, i32 %t222)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/typed:LocalUses", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  store ptr %t228, ptr %l125, !tbaa !29
  %t229 = load ptr, ptr %l13, !tbaa !29
  %t231 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t229)
  store i32 %t231, ptr %l127
  br label %bb66
bb66:
  %t232 = load ptr, ptr @__olang_prog_scope
  %t233 = load ptr, ptr %l125, !tbaa !29
  %t234 = load i32, ptr %l127, !tbaa !23
  %t235 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t232, ptr %t233, i32 %t234)
  store i1 %t235, ptr %l128
  br label %bb67
bb67:
  %t236 = load i1, ptr %l128, !tbaa !21
  br i1 %t236, label %bb68, label %bb69
bb68:
  %t237 = load i1, ptr %l3, !tbaa !21
  %t239 = xor i1 %t237, true
  store i1 %t239, ptr %l129, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb70
bb70:
  %t241 = load i1, ptr %l129, !tbaa !21
  store i1 %t241, ptr %l16, !tbaa !21
  %t242 = load i1, ptr %l16, !tbaa !21
  br i1 %t242, label %bb71, label %bb72
bb71:
  %t244 = load i64, ptr %l2, !tbaa !24
  %t246 = icmp sge i64 %t244, 0
  store i1 %t246, ptr %l133, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb73
bb73:
  %t248 = load i1, ptr %l133, !tbaa !21
  br i1 %t248, label %bb74, label %bb75
bb74:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/typed:LocalUses", ptr %t249, i32 0, i32 23
  %t252 = load i64, ptr %t251, !tbaa !24
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l136, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb76
bb76:
  %t256 = load i1, ptr %l136, !tbaa !21
  br i1 %t256, label %bb77, label %bb78
bb77:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l13, !tbaa !29
  %t259 = load i64, ptr %l2, !tbaa !24
  %t260 = load i64, ptr %l12, !tbaa !24
  %t265 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %t257, ptr %t258, i64 %t259, i64 %t260)
  store i1 %t265, ptr %l145
  br label %bb79
bb78:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb80
bb79:
  %t266 = load i1, ptr %l145, !tbaa !21
  store i1 %t266, ptr %l140, !tbaa !21
  br label %bb80
bb80:
  %t267 = load i1, ptr %l140, !tbaa !21
  br i1 %t267, label %bb81, label %bb82
bb81:
  br label %bb88
bb82:
  br label %bb83
bb83:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l146, !tbaa !29
  %t269 = load ptr, ptr %l13, !tbaa !29
  store ptr %t269, ptr %l148, !tbaa !29
  %t271 = load i1, ptr %l16, !tbaa !21
  br i1 %t271, label %bb84, label %bb85
bb84:
  store { i64, [1 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [1 x i64] }, ptr %t273, i32 0, i32 0
  store i64 5, ptr %t274
  %t275 = load { i64, [1 x i64] }, ptr %t273
  store { i64, [1 x i64] } %t275, ptr %l150
  br label %bb86
bb85:
  store { i64, [1 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [1 x i64] }, ptr %t277, i32 0, i32 0
  store i64 1, ptr %t278
  %t279 = load { i64, [1 x i64] }, ptr %t277
  store { i64, [1 x i64] } %t279, ptr %l150
  br label %bb86
bb86:
  %t281 = load ptr, ptr %l146, !tbaa !29
  %t282 = load ptr, ptr %l148, !tbaa !29
  %t283 = load { i64, [1 x i64] }, ptr %l150
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t282, { i64, [1 x i64] } %t283)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t284 = load i64, ptr %l11, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l11, !tbaa !24
  br label %bb31
bb89:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t47, ptr %l32, !tbaa !27
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t55, ptr %t53, { i64, [1 x i64] } %a2)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t15, i32 0, i32 8
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l1, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %t38, i64 %t41, i64 %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l20 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i64
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i1
  %l73 = alloca ptr
  %l77 = alloca %"compiler/typed:Local"
  %l79 = alloca i1
  %l80 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr @__olang_prog_scope
  %t30 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t27, ptr %t25, i32 %t26)
  store i64 %t30, ptr %l20
  br label %bb6
bb6:
  %t31 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t34 = and i64 %t32, %t31
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l3, !tbaa !29
  store ptr %t39, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t40 = load ptr, ptr %l26, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 0
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t54 = load i32, ptr %l4, !tbaa !23
  %t56 = sext i32 %t54 to i64
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb27
bb15:
  %t58 = load ptr, ptr %l3, !tbaa !29
  store ptr %t58, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 8}
  %t65 = icmp eq i64 %t63, 2
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l35, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t77 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i64 %t77, ptr %l42
  br label %bb21
bb21:
  %t78 = load i64, ptr %l42, !tbaa !24
  store i64 %t78, ptr %l25, !tbaa !24
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b9f0b2a15b6670eb_2e1d369e87bd8cdf)
  unreachable
bb27:
  %t79 = load i64, ptr %l25, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
bb28:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 18}
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l44, !tbaa !21
  br i1 %t88, label %bb31, label %bb32
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l6, !tbaa !23
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l7, !tbaa !29
  br label %bb33
bb32:
  br label %bb58
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i32, ptr %l6, !tbaa !23
  %t106 = load ptr, ptr @__olang_prog_scope
  %t109 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t106, ptr %t104, i32 %t105)
  store i1 %t109, ptr %l54
  br label %bb34
bb34:
  %t110 = load i1, ptr %l54, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb38
bb36:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/typed:LocalUses", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  %t118 = load ptr, ptr @__olang_prog_scope
  %t121 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t118, ptr %t116, i32 %t117)
  store i64 %t121, ptr %l60
  br label %bb37
bb37:
  %t122 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t123 = load i64, ptr %l60, !tbaa !24
  %t125 = and i64 %t123, %t122
  %t127 = icmp eq i64 %t125, 0
  store i1 %t127, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t129 = load i1, ptr %l56, !tbaa !21
  br i1 %t129, label %bb39, label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t131 = load ptr, ptr %l7, !tbaa !29
  store ptr %t131, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t132 = load ptr, ptr %l66, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t135 = load ptr, ptr %l66, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 0
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t139 = load i1, ptr %l67, !tbaa !21
  br i1 %t139, label %bb44, label %bb45
bb44:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l8, !tbaa !23
  br label %bb46
bb45:
  br label %bb52
bb46:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:LocalUses", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l73, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:LocalUses", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t155 = load ptr, ptr @__olang_prog_scope
  %t158 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t155, ptr %t153, i32 %t154)
  store %"compiler/typed:Local" %t158, ptr %l77
  br label %bb47
bb47:
  %t159 = getelementptr %"compiler/typed:Local", ptr %l77, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t161 = load ptr, ptr @__olang_prog_scope
  %t162 = load ptr, ptr %l73, !tbaa !29
  %t164 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t161, ptr %t162, i32 %t160)
  store i1 %t164, ptr %l79
  br label %bb48
bb48:
  %t165 = load i1, ptr %l79, !tbaa !21
  br i1 %t165, label %bb49, label %bb50
bb49:
  %t166 = load i32, ptr %l8, !tbaa !23
  %t168 = sext i32 %t166 to i64
  store i64 %t168, ptr %l80, !tbaa !24
  br label %bb51
bb50:
  store i64 -1, ptr %l80, !tbaa !24
  br label %bb51
bb51:
  %t170 = load i64, ptr %l80, !tbaa !24
  store i64 %t170, ptr %l65, !tbaa !24
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i64 -1, ptr %l65, !tbaa !24
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_5437ab06fdd2422a_119d1d559b7fc05e)
  unreachable
bb57:
  %t171 = load i64, ptr %l65, !tbaa !24
  store i64 %t171, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i64 -1, ptr %rv
  br label %ret
bb62:
  call void @__olang_check_failed(ptr @olang_loc_ef0de602c5122041_f82f60a1eb2bb195)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l15 = alloca { i64, ptr }
  %t43 = alloca { i64, [1 x i64] }, align 8
  %t57 = alloca { i64, [1 x i64] }, align 8
  %t66 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb27
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 47}
  %t25 = trunc i64 20 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t28, ptr %t29, { i64, [1 x i64] } %a3)
  br label %bb8
bb8:
  br label %bb25
bb9:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 47}
  %t37 = trunc i64 41 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i32 0, i32 0
  store i64 5, ptr %t44
  %t45 = load { i64, [1 x i64] }, ptr %t43
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t40, ptr %t41, { i64, [1 x i64] } %t45)
  br label %bb13
bb13:
  br label %bb25
bb14:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 47}
  %t51 = trunc i64 31 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [1 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t59 = load { i64, [1 x i64] }, ptr %t57
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t54, ptr %t55, { i64, [1 x i64] } %t59)
  br label %bb18
bb18:
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t66
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t64, { i64, [1 x i64] } %t68)
  br label %bb23
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dac0899521d00a27_f5966ad5b7471ec3)
  unreachable
bb25:
  br label %bb26
bb26:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb1
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4d8a06dfe39d8193_a27ec756202836f)
  unreachable
bb16:
  %t35 = load i64, ptr %l14, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb42
bb17:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 17
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t55 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i64 %t55, ptr %l31
  br label %bb23
bb23:
  %t56 = load i64, ptr %l31, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  br label %bb42
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb25, label %bb26
bb25:
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 9
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb26
bb26:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb27, label %bb28
bb27:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t68, i32 0, i32 2
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 47}
  store i32 %t70, ptr %l5
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t74, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  br label %bb29
bb28:
  br label %bb37
bb29:
  %t78 = load i32, ptr %l5, !range !{i32 0, i32 47}
  %t80 = trunc i64 20 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t87 = icmp eq i64 %t85, 1
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb32
bb32:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb33, label %bb34
bb33:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 0
  %t95 = load ptr, ptr %t94, !tbaa !39
  %t98 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t90, ptr %t95)
  store i64 %t98, ptr %l50
  br label %bb35
bb34:
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb36
bb35:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %l46, !tbaa !24
  br label %bb36
bb36:
  %t100 = load i64, ptr %l46, !tbaa !24
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_104aca9b23d55792_b4686871930206ae)
  unreachable
bb42:
  %t101 = load i64, ptr %l7, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t5)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = call i1 @compiler_2ftyped_2escalarType(ptr %t8, ptr %t9, i32 %t10)
  store i1 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i1, ptr %l7, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l19
  br label %bb11
bb11:
  %t36 = load i1, ptr %l19, !tbaa !21
  store i1 %t36, ptr %l10, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c33a5c6933895_a18ea8bdcccb3229)
  unreachable
bb17:
  %t37 = load i1, ptr %l10, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca { i64, [1 x i64] }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l199 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l227 = alloca ptr
  %l228 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %t70 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t114 = alloca { i64, [1 x i64] }, align 8
  %t149 = alloca { i64, [1 x i64] }, align 8
  %t173 = alloca { i64, [1 x i64] }, align 8
  %t196 = alloca { i64, [1 x i64] }, align 8
  %t223 = alloca { i64, [1 x i64] }, align 8
  %t291 = alloca { i64, [1 x i64] }, align 8
  %t321 = alloca { i64, [1 x i64] }, align 8
  %t329 = alloca { i64, [1 x i64] }, align 8
  %t398 = alloca { i64, [1 x i64] }, align 8
  %t441 = alloca { i64, [1 x i64] }, align 8
  %t477 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %t22, i32 %t23, ptr %t24)
  br label %bb6
bb6:
  br label %bb133
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t29 = load ptr, ptr %l34, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l34, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l35, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l35, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t49, ptr %t50, ptr %t51)
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l45, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  store ptr %t56, ptr %l47, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l49, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t62)
  store i32 %t64, ptr %l51
  br label %bb14
bb14:
  %t65 = load ptr, ptr @__olang_prog_scope
  %t66 = load ptr, ptr %l49, !tbaa !29
  %t67 = load i32, ptr %l51, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t65, ptr %t66, i32 %t67)
  store i1 %t68, ptr %l52
  br label %bb15
bb15:
  %t69 = load i1, ptr %l52, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [1 x i64] }, ptr %t70, i32 0, i32 0
  store i64 5, ptr %t71
  %t72 = load { i64, [1 x i64] }, ptr %t70
  store { i64, [1 x i64] } %t72, ptr %l53
  br label %bb18
bb17:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l53
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t79 = load ptr, ptr %l47, !tbaa !29
  %t80 = load { i64, [1 x i64] }, ptr %l53
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t78, ptr %t79, { i64, [1 x i64] } %t80)
  br label %bb19
bb19:
  br label %bb133
bb20:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t82 = load ptr, ptr %l56, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l56, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 2
  store i1 %t88, ptr %l57, !tbaa !21
  br label %bb22
bb22:
  %t89 = load i1, ptr %l57, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l6, !tbaa !29
  br label %bb29
bb24:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t97 = load ptr, ptr %l62, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb25, label %bb26
bb25:
  %t100 = load ptr, ptr %l62, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 17}
  %t103 = icmp eq i64 %t101, 8
  store i1 %t103, ptr %l63, !tbaa !21
  br label %bb26
bb26:
  %t104 = load i1, ptr %l63, !tbaa !21
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t107, i32 0, i32 1
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t114
  %t115 = getelementptr { i64, [1 x i64] }, ptr %t114, i32 0, i32 0
  store i64 0, ptr %t115
  %t116 = load { i64, [1 x i64] }, ptr %t114
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t111, ptr %t112, { i64, [1 x i64] } %t116)
  br label %bb30
bb30:
  br label %bb133
bb31:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t121 = load ptr, ptr %l72, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb32, label %bb33
bb32:
  %t124 = load ptr, ptr %l72, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 17}
  %t127 = icmp eq i64 %t125, 6
  store i1 %t127, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t128 = load i1, ptr %l73, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr }, ptr %t131, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb37, label %bb38
bb37:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/typed:LocalUses", ptr %t141, i32 0, i32 18
  %t144 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [1 x i64] }, ptr %t149, i32 0, i32 0
  store i64 3, ptr %t150
  %t151 = load { i64, [1 x i64] }, ptr %t149
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t147, ptr %t148, { i64, [1 x i64] } %t151)
  br label %bb41
bb41:
  br label %bb133
bb42:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t156 = load ptr, ptr %l87, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb43, label %bb44
bb43:
  %t159 = load ptr, ptr %l87, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 17}
  %t162 = icmp eq i64 %t160, 15
  store i1 %t162, ptr %l88, !tbaa !21
  br label %bb44
bb44:
  %t163 = load i1, ptr %l88, !tbaa !21
  br i1 %t163, label %bb45, label %bb46
bb45:
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l8, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [1 x i64] }, ptr %t173, i32 0, i32 0
  store i64 5, ptr %t174
  %t175 = load { i64, [1 x i64] }, ptr %t173
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t170, ptr %t171, { i64, [1 x i64] } %t175)
  br label %bb48
bb48:
  br label %bb133
bb49:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t180 = load ptr, ptr %l97, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb50, label %bb51
bb50:
  %t183 = load ptr, ptr %l97, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 17}
  %t186 = icmp eq i64 %t184, 16
  store i1 %t186, ptr %l98, !tbaa !21
  br label %bb51
bb51:
  %t187 = load i1, ptr %l98, !tbaa !21
  br i1 %t187, label %bb52, label %bb53
bb52:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l9, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [1 x i64] }, ptr %t196, i32 0, i32 0
  store i64 5, ptr %t197
  %t198 = load { i64, [1 x i64] }, ptr %t196
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t194, ptr %t195, { i64, [1 x i64] } %t198)
  br label %bb55
bb55:
  br label %bb133
bb56:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t203 = load ptr, ptr %l106, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t206 = load ptr, ptr %l106, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 3
  store i1 %t209, ptr %l107, !tbaa !21
  br label %bb58
bb58:
  %t210 = load i1, ptr %l107, !tbaa !21
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l10, !tbaa !29
  %t220 = getelementptr %"compiler/typed:If", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [1 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load { i64, [1 x i64] }, ptr %t223
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t217, ptr %t221, { i64, [1 x i64] } %t225)
  br label %bb62
bb62:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l10, !tbaa !29
  %t232 = getelementptr %"compiler/typed:If", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t229, ptr %t233)
  br label %bb63
bb63:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = getelementptr %"compiler/typed:If", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t237, ptr %t241)
  br label %bb64
bb64:
  br label %bb133
bb65:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t245 = load ptr, ptr %l124, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb66, label %bb67
bb66:
  %t248 = load ptr, ptr %l124, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 17}
  %t251 = icmp eq i64 %t249, 4
  store i1 %t251, ptr %l125, !tbaa !21
  br label %bb67
bb67:
  %t252 = load i1, ptr %l125, !tbaa !21
  br i1 %t252, label %bb68, label %bb69
bb68:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t255, i32 0, i32 1
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l11, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t261, i32 0, i32 2
  %t263 = load ptr, ptr %t262
  store ptr %t263, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  br label %bb71
bb71:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t270, ptr %t271)
  br label %bb72
bb72:
  br label %bb133
bb73:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t275 = load ptr, ptr %l137, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb74, label %bb75
bb74:
  %t278 = load ptr, ptr %l137, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 17}
  %t281 = icmp eq i64 %t279, 9
  store i1 %t281, ptr %l138, !tbaa !21
  br label %bb75
bb75:
  %t282 = load i1, ptr %l138, !tbaa !21
  br i1 %t282, label %bb76, label %bb77
bb76:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l13, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [1 x i64] }, ptr %t291, i32 0, i32 0
  store i64 0, ptr %t292
  %t293 = load { i64, [1 x i64] }, ptr %t291
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t289, ptr %t290, { i64, [1 x i64] } %t293)
  br label %bb79
bb79:
  br label %bb133
bb80:
  %t297 = load ptr, ptr %l1, !tbaa !29
  store ptr %t297, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t298 = load ptr, ptr %l146, !tbaa !29
  %t299 = icmp ne ptr %t298, null
  br i1 %t299, label %bb81, label %bb82
bb81:
  %t301 = load ptr, ptr %l146, !tbaa !29
  %t302 = load i64, ptr %t301, !range !{i64 0, i64 17}
  %t304 = icmp eq i64 %t302, 10
  store i1 %t304, ptr %l147, !tbaa !21
  br label %bb82
bb82:
  %t305 = load i1, ptr %l147, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb83:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t308, i32 0, i32 1
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l14, !tbaa !29
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t314, i32 0, i32 2
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l15, !tbaa !29
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l14, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [1 x i64] }, ptr %t321, i32 0, i32 0
  store i64 0, ptr %t322
  %t323 = load { i64, [1 x i64] }, ptr %t321
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t318, ptr %t319, { i64, [1 x i64] } %t323)
  br label %bb86
bb86:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l15, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [1 x i64] }, ptr %t329, i32 0, i32 0
  store i64 0, ptr %t330
  %t331 = load { i64, [1 x i64] }, ptr %t329
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t327, ptr %t328, { i64, [1 x i64] } %t331)
  br label %bb87
bb87:
  br label %bb133
bb88:
  %t335 = load ptr, ptr %l1, !tbaa !29
  store ptr %t335, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t336 = load ptr, ptr %l161, !tbaa !29
  %t337 = icmp ne ptr %t336, null
  br i1 %t337, label %bb89, label %bb90
bb89:
  %t339 = load ptr, ptr %l161, !tbaa !29
  %t340 = load i64, ptr %t339, !range !{i64 0, i64 17}
  %t342 = icmp eq i64 %t340, 11
  store i1 %t342, ptr %l162, !tbaa !21
  br label %bb90
bb90:
  %t343 = load i1, ptr %l162, !tbaa !21
  br i1 %t343, label %bb91, label %bb92
bb91:
  %t344 = load ptr, ptr %l1, !tbaa !29
  %t346 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 1
  %t347 = getelementptr { %"compiler/source:Span", ptr }, ptr %t346, i32 0, i32 1
  %t348 = load ptr, ptr %t347
  store ptr %t348, ptr %l16, !tbaa !29
  br label %bb97
bb92:
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t351 = load ptr, ptr %l167, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb93, label %bb94
bb93:
  %t354 = load ptr, ptr %l167, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 17}
  %t357 = icmp eq i64 %t355, 12
  store i1 %t357, ptr %l168, !tbaa !21
  br label %bb94
bb94:
  %t358 = load i1, ptr %l168, !tbaa !21
  br i1 %t358, label %bb95, label %bb96
bb95:
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", ptr }, ptr %t361, i32 0, i32 1
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l16, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t365, ptr %t366)
  br label %bb98
bb98:
  br label %bb133
bb99:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t371 = load ptr, ptr %l176, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb100, label %bb101
bb100:
  %t374 = load ptr, ptr %l176, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 17}
  %t377 = icmp eq i64 %t375, 13
  store i1 %t377, ptr %l177, !tbaa !21
  br label %bb101
bb101:
  %t378 = load i1, ptr %l177, !tbaa !21
  br i1 %t378, label %bb102, label %bb103
bb102:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [3 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr }, ptr %t381, i32 0, i32 1
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l17, !tbaa !29
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l17, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Join", ptr %t386, i32 0, i32 0
  %t389 = load ptr, ptr %t388, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t385, ptr %t389)
  br label %bb105
bb105:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l17, !tbaa !29
  %t396 = getelementptr %"compiler/typed:Join", ptr %t394, i32 0, i32 2
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  store { i64, [1 x i64] } zeroinitializer, ptr %t398
  %t399 = getelementptr { i64, [1 x i64] }, ptr %t398, i32 0, i32 0
  store i64 5, ptr %t399
  %t400 = load { i64, [1 x i64] }, ptr %t398
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %t393, { i64, ptr } %t397, { i64, [1 x i64] } %t400)
  br label %bb106
bb106:
  br label %bb133
bb107:
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t405 = load ptr, ptr %l190, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb108, label %bb109
bb108:
  %t408 = load ptr, ptr %l190, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 17}
  %t411 = icmp eq i64 %t409, 14
  store i1 %t411, ptr %l191, !tbaa !21
  br label %bb109
bb109:
  %t412 = load i1, ptr %l191, !tbaa !21
  br i1 %t412, label %bb110, label %bb111
bb110:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", ptr }, ptr %t415, i32 0, i32 1
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l18, !tbaa !29
  br label %bb112
bb111:
  br label %bb122
bb112:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l18, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Spawn", ptr %t420, i32 0, i32 0
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %t419, { i64, ptr } %t423)
  br label %bb113
bb113:
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l199, !tbaa !29
  %t427 = load ptr, ptr %l199, !tbaa !29
  %t428 = getelementptr %"compiler/typed:LocalUses", ptr %t427, i32 0, i32 23
  %t429 = load i64, ptr %t428, !tbaa !24
  %t431 = add i64 %t429, 1
  %t433 = load ptr, ptr %l199, !tbaa !29
  %t434 = getelementptr %"compiler/typed:LocalUses", ptr %t433, i32 0, i32 23
  store i64 %t431, ptr %t434, !tbaa !24
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l18, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Spawn", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t441
  %t442 = getelementptr { i64, [1 x i64] }, ptr %t441, i32 0, i32 0
  store i64 5, ptr %t442
  %t443 = load { i64, [1 x i64] }, ptr %t441
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t435, ptr %t439, { i64, [1 x i64] } %t443)
  br label %bb114
bb114:
  %t447 = load ptr, ptr %l18, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Spawn", ptr %t447, i32 0, i32 2
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  store { i64, ptr } %t450, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l21, !tbaa !24
  br label %bb115
bb115:
  %t456 = load i64, ptr %l20, !tbaa !24
  %t457 = load i64, ptr %l21, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t464 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t464, ptr %l215, !tbaa !27
  %t465 = load i64, ptr %l20, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr ptr, ptr %t468, i64 %t465
  %t470 = load ptr, ptr %t469, !tbaa !39
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/typed:TaskClause", ptr %t470, i32 0, i32 3
  %t476 = load ptr, ptr %t475, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t477
  %t478 = getelementptr { i64, [1 x i64] }, ptr %t477, i32 0, i32 0
  store i64 5, ptr %t478
  %t479 = load { i64, [1 x i64] }, ptr %t477
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t472, ptr %t476, { i64, [1 x i64] } %t479)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t483 = load i64, ptr %l20, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l20, !tbaa !24
  br label %bb115
bb121:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l224, !tbaa !29
  %t488 = load ptr, ptr %l224, !tbaa !29
  %t489 = getelementptr %"compiler/typed:LocalUses", ptr %t488, i32 0, i32 23
  %t490 = load i64, ptr %t489, !tbaa !24
  %t492 = sub i64 %t490, 1
  %t494 = load ptr, ptr %l224, !tbaa !29
  %t495 = getelementptr %"compiler/typed:LocalUses", ptr %t494, i32 0, i32 23
  store i64 %t492, ptr %t495, !tbaa !24
  br label %bb133
bb122:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t497 = load ptr, ptr %l227, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb123, label %bb124
bb123:
  %t500 = load ptr, ptr %l227, !tbaa !29
  %t501 = load i64, ptr %t500, !range !{i64 0, i64 17}
  %t503 = icmp eq i64 %t501, 5
  store i1 %t503, ptr %l228, !tbaa !21
  br label %bb124
bb124:
  %t504 = load i1, ptr %l228, !tbaa !21
  br i1 %t504, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  %t505 = load ptr, ptr %l1, !tbaa !29
  store ptr %t505, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t506 = load ptr, ptr %l231, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb127, label %bb128
bb127:
  %t509 = load ptr, ptr %l231, !tbaa !29
  %t510 = load i64, ptr %t509, !range !{i64 0, i64 17}
  %t512 = icmp eq i64 %t510, 7
  store i1 %t512, ptr %l232, !tbaa !21
  br label %bb128
bb128:
  %t513 = load i1, ptr %l232, !tbaa !21
  br i1 %t513, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_9a2d2471d97215b1_125b5d47933e1fad)
  unreachable
bb133:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %t30, i1 false)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb37
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  br label %bb37
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 5
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Payload", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t57, ptr %t61)
  br label %bb20
bb20:
  br label %bb37
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l41
  br label %bb27
bb27:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t92, i1 true)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd)
  unreachable
bb37:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1)
  unreachable
bb37:
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l3, !tbaa !23
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e2587c8ec5c6f861_9513078f5b00021d)
  unreachable
bb37:
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t36 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 8
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t36
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t40, i32 0, i32 9
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t52 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42, i64 %t49)
  store { i64, [1 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  %t53 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 8
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Plan", ptr %t36, i32 0, i32 9
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t41, %t42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t38, i64 %t45, { i64, [1 x i64] } %a3)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sle i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t15 = and i64 %t11, %t12
  %t17 = icmp ne i64 %t15, 0
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t26, i64 %t27)
  store i64 %t30, ptr %l26
  br label %bb8
bb8:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l33, !tbaa !24
  store i64 %t58, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  store i64 %t79, ptr %l52, !tbaa !24
  %t80 = load i64, ptr %l52, !tbaa !24
  %t81 = load i64, ptr %l52, !tbaa !24
  %t82 = shl i64 1, %t81
  %t85 = and i64 %t78, %t82
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Call", ptr %t90, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l58, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t102 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t89, ptr %t99)
  store i64 %t102, ptr %l61
  br label %bb22
bb22:
  %t103 = load i64, ptr %l61, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sle i64 %t104, 0
  br i1 %t106, label %bb23, label %bb24
bb23:
  store i64 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l3, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = or i64 %t109, %t110
  store i64 %t113, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb15
bb27:
  %t119 = load i64, ptr %l3, !tbaa !24
  store i64 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i64 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i64, ptr %l24, !tbaa !24
  store i64 %t26, ptr %l15, !tbaa !24
  br label %bb101
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Slice", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t49 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  store i64 %t49, ptr %l34
  br label %bb16
bb16:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l15, !tbaa !24
  br label %bb101
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 6
  store i1 %t58, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t70 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallRoots(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  store i64 %t70, ptr %l43
  br label %bb23
bb23:
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l15, !tbaa !24
  br label %bb101
bb24:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 11
  store i1 %t79, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t80 = load i1, ptr %l45, !tbaa !21
  br i1 %t80, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Cond", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t94 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  store i64 %t94, ptr %l53
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Cond", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  store i64 %t103, ptr %l58
  br label %bb31
bb31:
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = load i64, ptr %l58, !tbaa !24
  %t106 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t104, i64 %t105)
  store i64 %t106, ptr %l59
  br label %bb32
bb32:
  %t107 = load i64, ptr %l59, !tbaa !24
  store i64 %t107, ptr %l15, !tbaa !24
  br label %bb101
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l60, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 13
  store i1 %t115, ptr %l61, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t127 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  store i64 %t127, ptr %l68
  br label %bb39
bb39:
  %t128 = load i64, ptr %l68, !tbaa !24
  store i64 %t128, ptr %l15, !tbaa !24
  br label %bb101
bb40:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t130 = load ptr, ptr %l69, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb41, label %bb42
bb41:
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 14
  store i1 %t136, ptr %l70, !tbaa !21
  br label %bb42
bb42:
  %t137 = load i1, ptr %l70, !tbaa !21
  br i1 %t137, label %bb43, label %bb44
bb43:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l7, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  %t148 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  store i64 %t148, ptr %l77
  br label %bb46
bb46:
  %t149 = load i64, ptr %l77, !tbaa !24
  store i64 %t149, ptr %l15, !tbaa !24
  br label %bb101
bb47:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t151 = load ptr, ptr %l78, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb48, label %bb49
bb48:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 12
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb49
bb49:
  %t158 = load i1, ptr %l79, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l8, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Seq", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t172 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  store i64 %t172, ptr %l87
  br label %bb53
bb53:
  %t173 = load i64, ptr %l87, !tbaa !24
  store i64 %t173, ptr %l15, !tbaa !24
  br label %bb101
bb54:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t175 = load ptr, ptr %l88, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb55, label %bb56
bb55:
  %t178 = load ptr, ptr %l88, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 18}
  %t181 = icmp eq i64 %t179, 17
  store i1 %t181, ptr %l89, !tbaa !21
  br label %bb56
bb56:
  %t182 = load i1, ptr %l89, !tbaa !21
  br i1 %t182, label %bb57, label %bb58
bb57:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t194 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t189, ptr %t190)
  store i64 %t194, ptr %l97
  br label %bb60
bb60:
  %t195 = load i64, ptr %l97, !tbaa !24
  store i64 %t195, ptr %l15, !tbaa !24
  br label %bb101
bb61:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb62, label %bb63
bb62:
  %t200 = load ptr, ptr %l98, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 9
  store i1 %t203, ptr %l99, !tbaa !21
  br label %bb63
bb63:
  %t204 = load i1, ptr %l99, !tbaa !21
  br i1 %t204, label %bb64, label %bb65
bb64:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t207, i32 0, i32 2
  %t209 = load i32, ptr %t208, !range !{i32 0, i32 47}
  store i32 %t209, ptr %l10
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t213, i32 0, i32 4
  %t215 = load { i64, ptr }, ptr %t214
  store { i64, ptr } %t215, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t217 = load i32, ptr %l10, !range !{i32 0, i32 47}
  %t219 = trunc i64 20 to i32
  %t220 = icmp eq i32 %t217, %t219
  br i1 %t220, label %bb67, label %bb68
bb67:
  %t222 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t226 = icmp eq i64 %t224, 1
  store i1 %t226, ptr %l108, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb69
bb69:
  %t228 = load i1, ptr %l108, !tbaa !21
  br i1 %t228, label %bb70, label %bb71
bb70:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t230, ptr %l114, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 0
  %t234 = load ptr, ptr %t233, !tbaa !39
  %t238 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t229, ptr %t234)
  store i64 %t238, ptr %l117
  br label %bb72
bb71:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb73
bb72:
  %t239 = load i64, ptr %l117, !tbaa !24
  store i64 %t239, ptr %l112, !tbaa !24
  br label %bb73
bb73:
  %t240 = load i64, ptr %l112, !tbaa !24
  store i64 %t240, ptr %l15, !tbaa !24
  br label %bb101
bb74:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t242 = load ptr, ptr %l118, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb75, label %bb76
bb75:
  %t245 = load ptr, ptr %l118, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 18}
  %t248 = icmp eq i64 %t246, 7
  store i1 %t248, ptr %l119, !tbaa !21
  br label %bb76
bb76:
  %t249 = load i1, ptr %l119, !tbaa !21
  br i1 %t249, label %bb77, label %bb78
bb77:
  br label %bb95
bb78:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb79, label %bb80
bb79:
  %t254 = load ptr, ptr %l122, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 18}
  %t257 = icmp eq i64 %t255, 8
  store i1 %t257, ptr %l123, !tbaa !21
  br label %bb80
bb80:
  %t258 = load i1, ptr %l123, !tbaa !21
  br i1 %t258, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t260 = load ptr, ptr %l126, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb83, label %bb84
bb83:
  %t263 = load ptr, ptr %l126, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 16
  store i1 %t266, ptr %l127, !tbaa !21
  br label %bb84
bb84:
  %t267 = load i1, ptr %l127, !tbaa !21
  br i1 %t267, label %bb85, label %bb86
bb85:
  br label %bb95
bb86:
  %t268 = load ptr, ptr %l1, !tbaa !29
  store ptr %t268, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t269 = load ptr, ptr %l130, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb87, label %bb88
bb87:
  %t272 = load ptr, ptr %l130, !tbaa !29
  %t273 = load i64, ptr %t272, !range !{i64 0, i64 18}
  %t275 = icmp eq i64 %t273, 0
  store i1 %t275, ptr %l131, !tbaa !21
  br label %bb88
bb88:
  %t276 = load i1, ptr %l131, !tbaa !21
  br i1 %t276, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t278 = load ptr, ptr %l134, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb91, label %bb92
bb91:
  %t281 = load ptr, ptr %l134, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 18}
  %t284 = icmp eq i64 %t282, 15
  store i1 %t284, ptr %l135, !tbaa !21
  br label %bb92
bb92:
  %t285 = load i1, ptr %l135, !tbaa !21
  br i1 %t285, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_c8b3a2ed155d5757_c640a14e4e3ad273)
  unreachable
bb101:
  %t286 = load i64, ptr %l15, !tbaa !24
  store i64 %t286, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eSettle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l53 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i64
  %l63 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca i64
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 1
  store i1 %t10, ptr %l3, !tbaa !21
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:ViewWalk", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  %t18 = load ptr, ptr @__olang_prog_scope
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %t18, ptr %t17)
  store i64 %t20, ptr %l24
  br label %bb1
bb1:
  %t21 = load i64, ptr %l24, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb4:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l31, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l9, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i1, ptr %l3, !tbaa !21
  %t76 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i64 %t70, i1 %t71)
  store i1 %t76, ptr %l53
  br label %bb12
bb12:
  %t77 = load i1, ptr %l53, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l55, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 9
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t83, i64 %t84)
  store ptr %t87, ptr %l59
  br label %bb16
bb16:
  %t88 = load ptr, ptr %l55, !tbaa !29
  %t89 = load ptr, ptr %l59, !tbaa !29
  %t90 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  store i64 %t90, ptr %l60
  br label %bb17
bb17:
  %t91 = load i64, ptr %l60, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:LocalUses", ptr %t92, i32 0, i32 10
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t94)
  store i64 %t96, ptr %l63
  br label %bb18
bb18:
  %t97 = load i64, ptr %l63, !tbaa !24
  store i64 %t97, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb19, label %bb20
bb19:
  %t104 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb24
bb21:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l70, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb23
bb23:
  %t124 = load i64, ptr %l70, !tbaa !24
  store i64 %t124, ptr %l67, !tbaa !24
  br label %bb24
bb24:
  %t125 = load i64, ptr %l67, !tbaa !24
  store i64 %t125, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t126 = load i64, ptr %l15, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l16, !tbaa !24
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/typed:LocalUses", ptr %t144, i32 0, i32 10
  %t147 = load i64, ptr %l16, !tbaa !24
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t146, i64 %t147)
  store i64 %t150, ptr %l91
  br label %bb29
bb29:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l91, !tbaa !24
  %t154 = icmp eq i64 %t152, %t151
  br i1 %t154, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t156 = load i64, ptr %l10, !tbaa !24
  store i64 %t156, ptr %l94, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l95, !tbaa !29
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr %"compiler/typed:LocalUses", ptr %t158, i32 0, i32 11
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %s6, ptr %t160, i64 %t161)
  store ptr %t164, ptr %l99
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t165 = load ptr, ptr %l99, !tbaa !29
  %t166 = load ptr, ptr %l95, !tbaa !29
  %t168 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %s6, ptr %t166, ptr %t165)
  store i64 %t168, ptr %l101
  br label %bb33
bb33:
  %t169 = load i64, ptr %l94, !tbaa !24
  %t170 = load i64, ptr %l101, !tbaa !24
  %t171 = or i64 %t169, %t170
  store i64 %t171, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t173 = load i64, ptr %l15, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l15, !tbaa !24
  br label %bb25
bb36:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t182 = load i64, ptr %l9, !tbaa !24
  %t183 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %a2, i64 %t182, i64 %t183)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l8, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:ViewWalk", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load ptr, ptr @__olang_prog_scope
  %t14 = call ptr @compiler_2ftyped_2ecopied(ptr %t11, ptr %v1, ptr %v1, ptr %t9, ptr %t10)
  store ptr %t14, ptr %l10
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l10, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i64 %t26, ptr %l17
  br label %bb8
bb8:
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb11
bb11:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Elem", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store i64 %t65, ptr %l35
  br label %bb20
bb20:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  store i64 %t89, ptr %l45
  br label %bb27
bb27:
  %t90 = load i64, ptr %l45, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 2
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t110 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i64, ptr %l54, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69)
  unreachable
bb40:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca i64
  %l23 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l48 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l56 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = getelementptr %"compiler/typed:dropWalk", ptr %t12, i32 0, i32 4
  store i64 %t10, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 5
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t45, ptr %t43)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:dropWalk", ptr %t54, i32 0, i32 4
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = sub i64 %t57, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t53, i64 %t59)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:dropWalk", ptr %t62, i32 0, i32 5
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t70 = icmp sgt i64 %t68, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:dropWalk", ptr %t74, i32 0, i32 5
  %t78 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t76)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l44
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb19, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l43
  br label %bb18
bb18:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l40, !tbaa !24
  br label %bb26
bb19:
  %t84 = load i32, ptr %l44, !tbaa !23
  %t85 = icmp eq i32 %t84, 65536
  br i1 %t85, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_17c315ca28f40c4c_14b80e258f8c2b0)
  unreachable
bb21:
  %t87 = load i32, ptr %l44, !tbaa !23
  %t88 = icmp eq i32 %t87, 65537
  br i1 %t88, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5)
  unreachable
bb23:
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = icmp eq i32 %t90, 65538
  br i1 %t91, label %bb24, label %bb25
bb24:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6fe9eb3ff5642bc1_33392e6f48613205)
  unreachable
bb25:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5f1ddc7ef7469727_e10177d23ca0510b)
  unreachable
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:dropWalk", ptr %t93, i32 0, i32 6
  %t97 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l52
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb28, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l51
  br label %bb27
bb27:
  %t102 = load i64, ptr %l51, !tbaa !24
  store i64 %t102, ptr %l48, !tbaa !24
  br label %bb35
bb28:
  %t103 = load i32, ptr %l52, !tbaa !23
  %t104 = icmp eq i32 %t103, 65536
  br i1 %t104, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_24a3ccdd47c97c70_8558c77bc7af118c)
  unreachable
bb30:
  %t106 = load i32, ptr %l52, !tbaa !23
  %t107 = icmp eq i32 %t106, 65537
  br i1 %t107, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_130a89b2782f12a5_38e9334e27b56d91)
  unreachable
bb32:
  %t109 = load i32, ptr %l52, !tbaa !23
  %t110 = icmp eq i32 %t109, 65538
  br i1 %t110, label %bb33, label %bb34
bb33:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1916e27cc0da8fc5_b948d7408e366d01)
  unreachable
bb34:
  call void @__olang_bang_failed_plain(ptr @olang_loc_567e5689d7ac5ccb_d57870be630e767)
  unreachable
bb35:
  br label %bb36
bb36:
  br label %bb13
bb37:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l56, !tbaa !29
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = getelementptr %"compiler/typed:dropWalk", ptr %t113, i32 0, i32 4
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = load ptr, ptr %l56, !tbaa !29
  %t120 = getelementptr %"compiler/typed:dropWalk", ptr %t119, i32 0, i32 4
  store i64 %t117, ptr %t120, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l179 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l219 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l223 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l261 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca i1
  %l279 = alloca ptr
  %l280 = alloca i1
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 3
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l35, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t12 = load ptr, ptr %l38, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l38, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l39, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t21 = load ptr, ptr %l42, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l42, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l43, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb178
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t30 = load ptr, ptr %l46, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l46, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l47, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb29
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t45 = load ptr, ptr %l52, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l52, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t52 = load i1, ptr %l53, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l2, !tbaa !29
  br label %bb29
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t60 = load ptr, ptr %l58, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t63 = load ptr, ptr %l58, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t67 = load i1, ptr %l59, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb30
bb30:
  br label %bb178
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t80 = load ptr, ptr %l67, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l67, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 5
  store i1 %t86, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t87 = load i1, ptr %l68, !tbaa !21
  br i1 %t87, label %bb34, label %bb35
bb34:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l3, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Promote", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb37
bb37:
  br label %bb178
bb38:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t106 = load ptr, ptr %l77, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l78, !tbaa !21
  br label %bb40
bb40:
  %t110 = load i1, ptr %l78, !tbaa !21
  br i1 %t110, label %bb41, label %bb42
bb41:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l4, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb44
bb44:
  br label %bb178
bb45:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t122 = load ptr, ptr %l85, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb46, label %bb47
bb46:
  %t125 = load ptr, ptr %l85, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 18}
  %t128 = icmp eq i64 %t126, 7
  store i1 %t128, ptr %l86, !tbaa !21
  br label %bb47
bb47:
  %t129 = load i1, ptr %l86, !tbaa !21
  br i1 %t129, label %bb48, label %bb49
bb48:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t140)
  br label %bb51
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Make", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147)
  br label %bb52
bb52:
  br label %bb178
bb53:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb54, label %bb55
bb54:
  %t154 = load ptr, ptr %l97, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 8
  store i1 %t157, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t158 = load i1, ptr %l98, !tbaa !21
  br i1 %t158, label %bb56, label %bb57
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Collect", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb59
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Collect", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %s7, ptr %t172, ptr %t176, ptr null)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb178
bb61:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t180 = load ptr, ptr %l109, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb62, label %bb63
bb62:
  %t183 = load ptr, ptr %l109, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 18}
  %t186 = icmp eq i64 %t184, 9
  store i1 %t186, ptr %l110, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l110, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t190, i32 0, i32 4
  %t192 = load { i64, ptr }, ptr %t191
  store { i64, ptr } %t192, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t195)
  br label %bb67
bb67:
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t198, i1 false)
  br label %bb68
bb68:
  br label %bb178
bb69:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t201 = load ptr, ptr %l118, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t204 = load ptr, ptr %l118, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 18}
  %t207 = icmp eq i64 %t205, 10
  store i1 %t207, ptr %l119, !tbaa !21
  br label %bb71
bb71:
  %t208 = load i1, ptr %l119, !tbaa !21
  br i1 %t208, label %bb72, label %bb73
bb72:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l8, !tbaa !29
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Slice", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t215, ptr %t219)
  br label %bb75
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Slice", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t227)
  br label %bb76
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Slice", ptr %t232, i32 0, i32 2
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t235)
  br label %bb77
bb77:
  br label %bb178
bb78:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t240 = load ptr, ptr %l136, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb79, label %bb80
bb79:
  %t243 = load ptr, ptr %l136, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 11
  store i1 %t246, ptr %l137, !tbaa !21
  br label %bb80
bb80:
  %t247 = load i1, ptr %l137, !tbaa !21
  br i1 %t247, label %bb81, label %bb82
bb81:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l9, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l9, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Cond", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t258)
  br label %bb84
bb84:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t262)
  store { i64, ptr } %t264, ptr %l147
  br label %bb85
bb85:
  %t265 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l148, !tbaa !24
  %t267 = load i64, ptr %l148, !tbaa !24
  %t268 = mul i64 %t267, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l149, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l148, !tbaa !24
  %t277 = mul i64 %t276, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t273, ptr %t275, i64 %t277, i1 false)
  %t278 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t278, ptr %l10, !tbaa !27
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l9, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Cond", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t279, ptr %t283)
  br label %bb86
bb86:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t286)
  store { i64, ptr } %t288, ptr %l154
  br label %bb87
bb87:
  %t289 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l155, !tbaa !24
  %t291 = load i64, ptr %l155, !tbaa !24
  %t292 = mul i64 %t291, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l156, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = load i64, ptr %l155, !tbaa !24
  %t301 = mul i64 %t300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t297, ptr %t299, i64 %t301, i1 false)
  %t302 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t302, ptr %l11, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s10, ptr %t303, { i64, ptr } %t304)
  br label %bb88
bb88:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l9, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb89
bb89:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s10, ptr %t315, { i64, ptr } %t316)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s10)
  br label %bb178
bb91:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t320 = load ptr, ptr %l165, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb92, label %bb93
bb92:
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 18}
  %t326 = icmp eq i64 %t324, 12
  store i1 %t326, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t327 = load i1, ptr %l166, !tbaa !21
  br i1 %t327, label %bb94, label %bb95
bb94:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l12, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t334 = load ptr, ptr %l12, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Seq", ptr %t334, i32 0, i32 0
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  store i64 %t341, ptr %l15, !tbaa !24
  br label %bb97
bb97:
  %t343 = load i64, ptr %l14, !tbaa !24
  %t344 = load i64, ptr %l15, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t351 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t351, ptr %l179, !tbaa !27
  %t352 = load i64, ptr %l14, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr ptr, ptr %t355, i64 %t352
  %t357 = load ptr, ptr %t356, !tbaa !39
  %t359 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t359, ptr %t357)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t363 = load i64, ptr %l14, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l14, !tbaa !24
  br label %bb97
bb103:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l12, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t367, ptr %t371)
  br label %bb104
bb104:
  br label %bb178
bb105:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t375 = load ptr, ptr %l189, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb106, label %bb107
bb106:
  %t378 = load ptr, ptr %l189, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 18}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l190, !tbaa !21
  br label %bb107
bb107:
  %t382 = load i1, ptr %l190, !tbaa !21
  br i1 %t382, label %bb108, label %bb109
bb108:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 2
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb111
bb111:
  br label %bb178
bb112:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t394 = load ptr, ptr %l197, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb113, label %bb114
bb113:
  %t397 = load ptr, ptr %l197, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 18}
  %t400 = icmp eq i64 %t398, 14
  store i1 %t400, ptr %l198, !tbaa !21
  br label %bb114
bb114:
  %t401 = load i1, ptr %l198, !tbaa !21
  br i1 %t401, label %bb115, label %bb116
bb115:
  %t402 = load ptr, ptr %l1, !tbaa !29
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t404, i32 0, i32 2
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l18, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %t408, ptr %t409)
  br label %bb118
bb118:
  br label %bb178
bb119:
  %t412 = load ptr, ptr %l1, !tbaa !29
  store ptr %t412, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t413 = load ptr, ptr %l205, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb120, label %bb121
bb120:
  %t416 = load ptr, ptr %l205, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 18}
  %t419 = icmp eq i64 %t417, 16
  store i1 %t419, ptr %l206, !tbaa !21
  br label %bb121
bb121:
  %t420 = load i1, ptr %l206, !tbaa !21
  br i1 %t420, label %bb122, label %bb123
bb122:
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t423, i32 0, i32 2
  %t425 = load ptr, ptr %t424
  store ptr %t425, ptr %l19, !tbaa !29
  br label %bb124
bb123:
  br label %bb137
bb124:
  %t427 = load ptr, ptr %l19, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Text", ptr %t427, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l22, !tbaa !24
  br label %bb125
bb125:
  %t436 = load i64, ptr %l21, !tbaa !24
  %t437 = load i64, ptr %l22, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb126, label %bb127
bb126:
  br label %bb136
bb127:
  br label %bb128
bb128:
  %t444 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t444, ptr %l219, !tbaa !27
  %t445 = load i64, ptr %l21, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr ptr, ptr %t448, i64 %t445
  %t450 = load ptr, ptr %t449, !tbaa !39
  store ptr %t450, ptr %l23, !tbaa !29
  %t452 = load ptr, ptr %l23, !tbaa !29
  store ptr %t452, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t453 = load ptr, ptr %l222, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t456 = load ptr, ptr %l222, !tbaa !29
  %t457 = load i64, ptr %t456, !range !{i64 0, i64 2}
  %t459 = icmp eq i64 %t457, 1
  store i1 %t459, ptr %l223, !tbaa !21
  br label %bb130
bb130:
  %t460 = load i1, ptr %l223, !tbaa !21
  br i1 %t460, label %bb131, label %bb132
bb131:
  %t461 = load ptr, ptr %l23, !tbaa !29
  %t463 = getelementptr { i64, [2 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { ptr }, ptr %t463, i32 0, i32 0
  %t465 = load ptr, ptr %t464
  %t467 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t467, ptr %t465)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t472 = load i64, ptr %l21, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l21, !tbaa !24
  br label %bb125
bb136:
  br label %bb178
bb137:
  %t476 = load ptr, ptr %l1, !tbaa !29
  store ptr %t476, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t477 = load ptr, ptr %l233, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb138, label %bb139
bb138:
  %t480 = load ptr, ptr %l233, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 18}
  %t483 = icmp eq i64 %t481, 17
  store i1 %t483, ptr %l234, !tbaa !21
  br label %bb139
bb139:
  %t484 = load i1, ptr %l234, !tbaa !21
  br i1 %t484, label %bb140, label %bb141
bb140:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr { i64, [5 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t487, i32 0, i32 2
  %t489 = load ptr, ptr %t488
  store ptr %t489, ptr %l25, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t491, ptr %t492)
  br label %bb143
bb143:
  br label %bb178
bb144:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t497 = load ptr, ptr %l242, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb145, label %bb146
bb145:
  %t500 = load ptr, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %t500, !range !{i64 0, i64 18}
  %t503 = icmp eq i64 %t501, 15
  store i1 %t503, ptr %l243, !tbaa !21
  br label %bb146
bb146:
  %t504 = load i1, ptr %l243, !tbaa !21
  br i1 %t504, label %bb147, label %bb148
bb147:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l26, !tbaa !29
  br label %bb149
bb148:
  br label %bb177
bb149:
  %t511 = load ptr, ptr %l26, !tbaa !29
  store ptr %t511, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t512 = load ptr, ptr %l248, !tbaa !29
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %bb150, label %bb151
bb150:
  %t515 = load ptr, ptr %l248, !tbaa !29
  %t516 = load i64, ptr %t515, !range !{i64 0, i64 3}
  %t518 = icmp eq i64 %t516, 1
  store i1 %t518, ptr %l249, !tbaa !21
  br label %bb151
bb151:
  %t519 = load i1, ptr %l249, !tbaa !21
  br i1 %t519, label %bb152, label %bb153
bb152:
  %t520 = load ptr, ptr %l26, !tbaa !29
  %t522 = getelementptr { i64, [4 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t522, i32 0, i32 1
  %t524 = load { i64, ptr }, ptr %t523
  store { i64, ptr } %t524, ptr %l27, !tbaa !27
  br label %bb154
bb153:
  br label %bb162
bb154:
  %t526 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t526, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l30, !tbaa !24
  br label %bb155
bb155:
  %t532 = load i64, ptr %l29, !tbaa !24
  %t533 = load i64, ptr %l30, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb156, label %bb157
bb156:
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t540 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t540, ptr %l261, !tbaa !27
  %t541 = load i64, ptr %l29, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr ptr, ptr %t544, i64 %t541
  %t546 = load ptr, ptr %t545, !tbaa !39
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/typed:Capture", ptr %t546, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t548, ptr %t552)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t556 = load i64, ptr %l29, !tbaa !24
  %t558 = add i64 %t556, 1
  store i64 %t558, ptr %l29, !tbaa !24
  br label %bb155
bb161:
  br label %bb176
bb162:
  %t560 = load ptr, ptr %l26, !tbaa !29
  store ptr %t560, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t561 = load ptr, ptr %l270, !tbaa !29
  %t562 = icmp ne ptr %t561, null
  br i1 %t562, label %bb163, label %bb164
bb163:
  %t564 = load ptr, ptr %l270, !tbaa !29
  %t565 = load i64, ptr %t564, !range !{i64 0, i64 3}
  %t567 = icmp eq i64 %t565, 2
  store i1 %t567, ptr %l271, !tbaa !21
  br label %bb164
bb164:
  %t568 = load i1, ptr %l271, !tbaa !21
  br i1 %t568, label %bb165, label %bb166
bb165:
  %t569 = load ptr, ptr %l26, !tbaa !29
  %t571 = getelementptr { i64, [4 x i64] }, ptr %t569, i32 0, i32 1
  %t572 = getelementptr { i32, ptr, i32 }, ptr %t571, i32 0, i32 1
  %t573 = load ptr, ptr %t572
  store ptr %t573, ptr %l32, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t575, ptr %t576)
  br label %bb168
bb168:
  br label %bb176
bb169:
  %t580 = load ptr, ptr %l26, !tbaa !29
  store ptr %t580, ptr %l279, !tbaa !29
  store i1 false, ptr %l280, !tbaa !21
  %t581 = load ptr, ptr %l279, !tbaa !29
  %t582 = icmp ne ptr %t581, null
  br i1 %t582, label %bb170, label %bb171
bb170:
  %t584 = load ptr, ptr %l279, !tbaa !29
  %t585 = load i64, ptr %t584, !range !{i64 0, i64 3}
  %t587 = icmp eq i64 %t585, 0
  store i1 %t587, ptr %l280, !tbaa !21
  br label %bb171
bb171:
  %t588 = load i1, ptr %l280, !tbaa !21
  br i1 %t588, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_e0d071190e38de5d_291e4ea72946f179)
  unreachable
bb176:
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_d40841e1665d5bac_305352f22a4532a8)
  unreachable
bb178:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb52
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 12
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i64 %t50, ptr %l34
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %t51, i64 %t52)
  br label %bb14
bb14:
  br label %bb50
bb15:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 11
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb21
bb21:
  br label %bb50
bb22:
  %t73 = load ptr, ptr %l5, !tbaa !29
  store ptr %t73, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 17}
  %t80 = icmp eq i64 %t78, 3
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb29
bb29:
  br label %bb50
bb30:
  %t103 = load ptr, ptr %l5, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 17}
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr { i64, [3 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l9, !tbaa !29
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  br label %bb37
bb37:
  br label %bb50
bb38:
  %t133 = load ptr, ptr %l5, !tbaa !29
  store ptr %t133, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l70, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 17}
  %t140 = icmp eq i64 %t138, 13
  store i1 %t140, ptr %l71, !tbaa !21
  br label %bb40
bb40:
  %t141 = load i1, ptr %l71, !tbaa !21
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l11, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Join", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t148, ptr %t152)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_9f9fe097503cda9_c6b719cc2534ac35)
  unreachable
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l3, !tbaa !24
  br label %bb4
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 5
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb4
bb4:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l19, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l16, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:dropWalk", ptr %t58, i32 0, i32 6
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l40
  br label %bb15
bb15:
  %t66 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sgt i64 %t66, %a1
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:dropWalk", ptr %t70, i32 0, i32 2
  store ptr %t72, ptr %l45, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:dropWalk", ptr %t73, i32 0, i32 1
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:dropWalk", ptr %t76, i32 0, i32 5
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l52
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb18:
  %t83 = load ptr, ptr %l48, !tbaa !29
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t83, i64 %t84)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l54
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb20, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l53
  br label %bb19
bb19:
  %t90 = load i64, ptr %l53, !tbaa !24
  store i64 %t90, ptr %l46, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb22
bb22:
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = load i64, ptr %l46, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t92)
  store i1 %t93, ptr %l55
  br label %bb23
bb23:
  %t94 = load i1, ptr %l55, !tbaa !21
  store i1 %t94, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l43, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:dropWalk", ptr %t96, i32 0, i32 14
  store ptr %t98, ptr %l57, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:dropWalk", ptr %t99, i32 0, i32 5
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t101, i64 %t102)
  store i64 %t105, ptr %l61
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %l61, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t106, i64 %t107, i1 true)
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l6, !tbaa !24
  br label %bb11
bb31:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l48 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l10, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = add i64 %t7, 1
  %t9 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t9, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = add i64 %t18, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l9, !tbaa !24
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82)
  store i1 %t85, ptr %l54
  br label %bb15
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:dropWalk", ptr %t86, i32 0, i32 10
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t96 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t93)
  store i1 %t96, ptr %l60
  br label %bb16
bb15:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l48, !tbaa !21
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t99, ptr %t103, !tbaa !31
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = add i64 %t104, 1
  store i64 %t105, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %l134 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %l144 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l33, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t34)
  store { i64, ptr } %t36, ptr %l41
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l42, !tbaa !24
  %t39 = load i64, ptr %l42, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l43, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l42, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t51)
  store { i64, ptr } %t53, ptr %l45
  br label %bb9
bb9:
  %t54 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l46, !tbaa !24
  %t56 = load i64, ptr %l46, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l47, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l46, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:dropWalk", ptr %t68, i32 0, i32 2
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l50
  br label %bb10
bb10:
  %t73 = load i64, ptr %l50, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i1, ptr %t75, i64 %t73
  store i1 true, ptr %t76, !tbaa !31
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l51
  br label %bb11
bb11:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l8
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Match", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l60, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %v1, ptr %l8, ptr %t102)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l10, !tbaa !24
  br label %bb12
bb18:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Match", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb19, label %bb20
bb19:
  store ptr %l8, ptr %l71, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f5a8870640a369c_e3a704984aad8c8)
  unreachable
bb22:
  br label %bb23
bb23:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Match", ptr %t127, i32 0, i32 2
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %v1, ptr %t131, ptr %t130)
  br label %bb24
bb24:
  br label %bb25
bb25:
  store ptr %l8, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load i64, ptr %l14, !tbaa !24
  store i64 %t134, ptr %l78, !tbaa !24
  %t135 = load ptr, ptr %l13, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eLen_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %t135)
  store i64 %t137, ptr %l80
  br label %bb27
bb27:
  %t138 = load i64, ptr %l78, !tbaa !24
  %t139 = load i64, ptr %l80, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb29:
  br label %bb30
bb30:
  %t144 = load ptr, ptr %l13, !tbaa !29
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eAt_3ccompiler_2ftyped_3aArm_26_3e(ptr %s0, ptr %s0, ptr %t144, i64 %t145)
  store ptr %t148, ptr %l85
  br label %bb31
bb31:
  %t149 = load ptr, ptr %l85, !tbaa !29
  store ptr %t149, ptr %l15, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t150, { i64, ptr } %t151)
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l15, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Arm", ptr %t154, i32 0, i32 1
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  store i64 %t161, ptr %l18, !tbaa !24
  br label %bb33
bb33:
  %t163 = load i64, ptr %l17, !tbaa !24
  %t164 = load i64, ptr %l18, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb34, label %bb35
bb34:
  br label %bb46
bb35:
  br label %bb36
bb36:
  %t171 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t171, ptr %l96, !tbaa !27
  %t172 = load i64, ptr %l17, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr ptr, ptr %t175, i64 %t172
  %t177 = load ptr, ptr %t176, !tbaa !39
  store ptr %t177, ptr %l19, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l19, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Alt", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t179, ptr %t183)
  br label %bb37
bb37:
  %t187 = load ptr, ptr %l19, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Alt", ptr %t187, i32 0, i32 1
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l22, !tbaa !24
  br label %bb38
bb38:
  %t196 = load i64, ptr %l21, !tbaa !24
  %t197 = load i64, ptr %l22, !tbaa !24
  %t200 = icmp slt i64 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t204 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t204, ptr %l111, !tbaa !27
  %t205 = load i64, ptr %l21, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr ptr, ptr %t208, i64 %t205
  %t210 = load ptr, ptr %t209, !tbaa !39
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Bind", ptr %t210, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t212, ptr %t216)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t220 = load i64, ptr %l21, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l21, !tbaa !24
  br label %bb38
bb44:
  br label %bb45
bb45:
  %t224 = load i64, ptr %l17, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l17, !tbaa !24
  br label %bb33
bb46:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Arm", ptr %t229, i32 0, i32 2
  %t232 = load ptr, ptr %t231, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t228, ptr %t232)
  br label %bb47
bb47:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l15, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Arm", ptr %t236, i32 0, i32 3
  %t239 = load ptr, ptr %t238, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %s0, ptr %t235, ptr %t239)
  br label %bb48
bb48:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l15, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Arm", ptr %t243, i32 0, i32 4
  %t246 = load ptr, ptr %t245, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %s0, ptr %t242, ptr %t246)
  br label %bb49
bb49:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s9, ptr %t249)
  store { i64, ptr } %t251, ptr %l132
  br label %bb50
bb50:
  %t252 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  store i64 %t253, ptr %l133, !tbaa !24
  %t254 = load i64, ptr %l133, !tbaa !24
  %t255 = mul i64 %t254, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  store { i64, ptr } %t258, ptr %l134, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l133, !tbaa !24
  %t264 = mul i64 %t263, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t260, ptr %t262, i64 %t264, i1 false)
  %t265 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t265, ptr %l24, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t266, { i64, ptr } %t267)
  br label %bb51
bb51:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s9, ptr %t270, { i64, ptr } %t271)
  br label %bb52
bb52:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t274)
  store { i64, ptr } %t276, ptr %l140
  br label %bb53
bb53:
  %t277 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  store i64 %t278, ptr %l141, !tbaa !24
  %t279 = load i64, ptr %l141, !tbaa !24
  %t280 = mul i64 %t279, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  %t282 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l142, !tbaa !27
  %t284 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = load i64, ptr %l141, !tbaa !24
  %t289 = mul i64 %t288, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t285, ptr %t287, i64 %t289, i1 false)
  %t290 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l144, !tbaa !24
  %t295 = load i64, ptr %l144, !tbaa !24
  %t296 = icmp eq i64 %t291, %t295
  br i1 %t296, label %bb54, label %bb55
bb54:
  %t298 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l144, !tbaa !24
  %t303 = mul i64 %t302, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t299, ptr %t301, i64 %t303, i1 false)
  br label %bb56
bb55:
  %t304 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t304, ptr %l7, !tbaa !27
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t305 = load i64, ptr %l14, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l14, !tbaa !24
  br label %bb26
bb58:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t309, { i64, ptr } %t310)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l8
  br label %bb3
bb3:
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 1
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:dropWalk", ptr %t18, i32 0, i32 2
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t23, i64 %t24, i64 %t25)
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:dropWalk", ptr %t26, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 false)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Elem", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t68, ptr %t72)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Payload", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 8}
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c533040496e87321_52fb908a3762307d)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = add i64 %t6, 1
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t16, ptr %lp1
  %t18 = load ptr, ptr %lp1
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:dropWalk", ptr %t19, i32 0, i32 2
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l16
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_c1faed4ae36d3640_1d7aa47a4727493c)
  unreachable
bb4:
  %t24 = load i64, ptr %l16, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l23, !tbaa !24
  store i64 %t51, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l20, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/typed:dropWalk", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t74, i64 %t75)
  store i1 %t78, ptr %l45
  br label %bb15
bb15:
  %t79 = load i1, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr %lp1
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i1, ptr %t83, i64 %t81
  store i1 %t79, ptr %t84, !tbaa !31
  br label %bb16
bb16:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:dropWalk", ptr %t89, i32 0, i32 2
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l50
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:dropWalk", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  %t99 = load ptr, ptr %lp1
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t97, ptr %t103, !tbaa !31
  %t104 = load ptr, ptr %lp1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %ret
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l14, !tbaa !29
  store i64 %t13, ptr %l15, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l4
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load i64, ptr %t49
  %t54 = icmp eq i64 %t50, 0
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l24, !tbaa !21
  %t57 = xor i1 %t56, true
  %t58 = load ptr, ptr %l14, !tbaa !29
  %t59 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t59, i1 %t57)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l82 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l111 = alloca i64
  %l120 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i32
  %l131 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l144 = alloca i64
  %l147 = alloca i64
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i32
  %l179 = alloca { i64, ptr }
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 11
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l34
  br label %bb2
bb2:
  %t12 = load i64, ptr %l34, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 11
  store ptr %t15, ptr %l36, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l39, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = load i1, ptr %l39, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 %t29)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t32, i64 %t36)
  br label %bb7
bb7:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb13
bb10:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l54, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l54, !tbaa !24
  store i64 %t67, ptr %l51, !tbaa !24
  br label %bb13
bb13:
  %t68 = load i64, ptr %l51, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:dropWalk", ptr %t87, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t89, i1 false)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb14
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:dropWalk", ptr %t95, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t97, i1 true)
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Try", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb22
bb22:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l82, !tbaa !24
  %t109 = load i64, ptr %l82, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load i64, ptr %l82, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2cf1608fd5d1230c_1374e48cd144e348)
  unreachable
bb25:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb30
bb27:
  %t132 = load i64, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l93, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb29
bb29:
  %t148 = load i64, ptr %l93, !tbaa !24
  store i64 %t148, ptr %l90, !tbaa !24
  br label %bb30
bb30:
  %t149 = load i64, ptr %l90, !tbaa !24
  store i64 %t149, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t150 = load i64, ptr %l15, !tbaa !24
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l16, !tbaa !24
  store i64 %t168, ptr %l111, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:dropWalk", ptr %t169, i32 0, i32 13
  %t172 = load i64, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l2, !tbaa !24
  %t175 = add i64 %t173, 1
  %t178 = mul i64 %t172, %t175
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t185 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t171, i64 %t182)
  store i1 %t185, ptr %l120
  br label %bb35
bb35:
  %t186 = load i1, ptr %l120, !tbaa !21
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i1, ptr %t189, i64 %t187
  store i1 %t186, ptr %t190, !tbaa !31
  br label %bb36
bb36:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb31
bb37:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/typed:dropWalk", ptr %t195, i32 0, i32 11
  %t199 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t197)
  %t200 = extractvalue { i32, i1 } %t199, 1
  %t201 = extractvalue { i32, i1 } %t199, 0
  store i32 %t201, ptr %l127
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb39, label %ok.203, !prof !99
ok.203:
  store i1 %t200, ptr %l126
  br label %bb38
bb38:
  %t204 = load i1, ptr %l126, !tbaa !21
  store i1 %t204, ptr %l123, !tbaa !21
  br label %bb46
bb39:
  %t205 = load i32, ptr %l127, !tbaa !23
  %t206 = icmp eq i32 %t205, 65536
  br i1 %t206, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_73be6a0e490978a7_b5fa18d3e7eede33)
  unreachable
bb41:
  %t208 = load i32, ptr %l127, !tbaa !23
  %t209 = icmp eq i32 %t208, 65537
  br i1 %t209, label %bb42, label %bb43
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fb6091d652311b2_1c71a9a414fce87e)
  unreachable
bb43:
  %t211 = load i32, ptr %l127, !tbaa !23
  %t212 = icmp eq i32 %t211, 65538
  br i1 %t212, label %bb44, label %bb45
bb44:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8c1b8241682c8a5c_1491e83e9da6f28)
  unreachable
bb45:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fc9df9522ae1330_697d53c50db00ce4)
  unreachable
bb46:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:dropWalk", ptr %t214, i32 0, i32 12
  %t218 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t216)
  %t219 = extractvalue { i32, i64 } %t218, 1
  %t220 = extractvalue { i32, i64 } %t218, 0
  store i32 %t220, ptr %l135
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb48, label %ok.222, !prof !99
ok.222:
  store i64 %t219, ptr %l134
  br label %bb47
bb47:
  %t223 = load i64, ptr %l134, !tbaa !24
  store i64 %t223, ptr %l131, !tbaa !24
  br label %bb55
bb48:
  %t224 = load i32, ptr %l135, !tbaa !23
  %t225 = icmp eq i32 %t224, 65536
  br i1 %t225, label %bb49, label %bb50
bb49:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e4195c8d52320dab_6e5abcaf8844f88f)
  unreachable
bb50:
  %t227 = load i32, ptr %l135, !tbaa !23
  %t228 = icmp eq i32 %t227, 65537
  br i1 %t228, label %bb51, label %bb52
bb51:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6df7d27e20fc18e6_9af88db0bee394aa)
  unreachable
bb52:
  %t230 = load i32, ptr %l135, !tbaa !23
  %t231 = icmp eq i32 %t230, 65538
  br i1 %t231, label %bb53, label %bb54
bb53:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c52364142dc414a0_4d1da6470710a144)
  unreachable
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730)
  unreachable
bb55:
  store i64 0, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb56, label %bb57
bb56:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb61
bb58:
  %t247 = load i64, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l147, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l147, !tbaa !24
  store i64 %t263, ptr %l144, !tbaa !24
  br label %bb61
bb61:
  %t264 = load i64, ptr %l144, !tbaa !24
  store i64 %t264, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  %t265 = load i64, ptr %l21, !tbaa !24
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l19, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l22, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/typed:dropWalk", ptr %t283, i32 0, i32 13
  %t287 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t285)
  %t288 = extractvalue { i32, i1 } %t287, 1
  %t289 = extractvalue { i32, i1 } %t287, 0
  store i32 %t289, ptr %l169
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb67, label %ok.291, !prof !99
ok.291:
  store i1 %t288, ptr %l168
  br label %bb66
bb66:
  %t292 = load i1, ptr %l168, !tbaa !21
  store i1 %t292, ptr %l165, !tbaa !21
  br label %bb74
bb67:
  %t293 = load i32, ptr %l169, !tbaa !23
  %t294 = icmp eq i32 %t293, 65536
  br i1 %t294, label %bb68, label %bb69
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab)
  unreachable
bb69:
  %t296 = load i32, ptr %l169, !tbaa !23
  %t297 = icmp eq i32 %t296, 65537
  br i1 %t297, label %bb70, label %bb71
bb70:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cdd2e50680d68485_7d51e204495f7309)
  unreachable
bb71:
  %t299 = load i32, ptr %l169, !tbaa !23
  %t300 = icmp eq i32 %t299, 65538
  br i1 %t300, label %bb72, label %bb73
bb72:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2ee7063c57fe9793_68bf97cc73752027)
  unreachable
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f)
  unreachable
bb74:
  br label %bb75
bb75:
  %t302 = load i64, ptr %l21, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l21, !tbaa !24
  br label %bb62
bb76:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Try", ptr %t306, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t313 = icmp eq i64 %t311, 0
  br i1 %t313, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t315 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t315, ptr %l179, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l180, !tbaa !24
  %t318 = load i64, ptr %l180, !tbaa !24
  %t319 = mul i64 %t318, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l181, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = load i64, ptr %l180, !tbaa !24
  %t328 = mul i64 %t327, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t324, ptr %t326, i64 %t328, i1 false)
  %t329 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t329, ptr %l23, !tbaa !27
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Try", ptr %t330, i32 0, i32 1
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  store { i64, ptr } %t333, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l26, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t339 = load i64, ptr %l25, !tbaa !24
  %t340 = load i64, ptr %l26, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t347 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t347, ptr %l190, !tbaa !27
  %t348 = load i64, ptr %l25, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t348
  %t353 = load ptr, ptr %t352, !tbaa !39
  store ptr %t353, ptr %l27, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t355)
  store { i64, ptr } %t357, ptr %l194
  br label %bb84
bb84:
  %t358 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l195, !tbaa !24
  %t360 = load i64, ptr %l195, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l196, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l195, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t371, ptr %l28, !tbaa !27
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t372, { i64, ptr } %t373)
  br label %bb85
bb85:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l27, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Clause", ptr %t377, i32 0, i32 3
  %t380 = load ptr, ptr %t379, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t376, ptr %t380)
  br label %bb86
bb86:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l27, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Clause", ptr %t384, i32 0, i32 4
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t383, { i64, ptr } %t387)
  br label %bb87
bb87:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t390, { i64, ptr } %t391)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t394 = load i64, ptr %l25, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l25, !tbaa !24
  br label %bb80
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l69 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:dropWalk", ptr %t8, i32 0, i32 2
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb4
bb4:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i1, ptr %t15, i64 %t13
  %t17 = load i1, ptr %t16, !tbaa !31
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l17, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t19 = load i64, ptr %l17, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l18, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:dropWalk", ptr %t21, i32 0, i32 2
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l21
  br label %bb8
bb8:
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i1, ptr %t28, i64 %t26
  store i1 false, ptr %t29, !tbaa !31
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 2
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb15
bb12:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l31, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l31, !tbaa !24
  store i64 %t62, ptr %l28, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:dropWalk", ptr %t82, i32 0, i32 2
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l52
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t90, ptr %l54, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  %t96 = load i1, ptr %t95, !tbaa !31
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t101 = load i64, ptr %l2, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l2, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t105, ptr %l60, !tbaa !27
  %t106 = load i64, ptr %l8, !tbaa !24
  store i64 %t106, ptr %l61, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l62, !tbaa !27
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i1, ptr %t111, i64 %t108
  %t113 = load i1, ptr %t112, !tbaa !31
  br i1 %t113, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb28:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:dropWalk", ptr %t115, i32 0, i32 2
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t117, i64 %t118)
  store i1 %t121, ptr %l69
  br label %bb29
bb29:
  %t122 = load i1, ptr %l69, !tbaa !21
  store i1 %t122, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l65, !tbaa !21
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i1, ptr %t126, i64 %t124
  store i1 %t123, ptr %t127, !tbaa !31
  br label %bb31
bb31:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb16
bb32:
  %t132 = load i64, ptr %l2, !tbaa !24
  store i64 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t10)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Clause", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t30, ptr %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Clause", ptr %t40, i32 0, i32 4
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t46 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t39, { i64, ptr } %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l161 = alloca i1
  %l162 = alloca i1
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca i1
  %l203 = alloca i1
  %l204 = alloca ptr
  %l210 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i1
  %l220 = alloca i1
  %l224 = alloca i1
  %l227 = alloca i1
  %l230 = alloca i1
  %l232 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l251 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l261 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb183
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l52
  br label %bb31
bb31:
  %t83 = load i1, ptr %l52, !tbaa !21
  store i1 %t83, ptr %l19, !tbaa !21
  br label %bb183
bb32:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t85 = load ptr, ptr %l53, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t107 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  store i1 %t107, ptr %l63
  br label %bb38
bb38:
  %t108 = load i1, ptr %l63, !tbaa !21
  store i1 %t108, ptr %l19, !tbaa !21
  br label %bb183
bb39:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb40, label %bb41
bb40:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 18}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t117 = load i1, ptr %l65, !tbaa !21
  br i1 %t117, label %bb42, label %bb43
bb42:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l4, !tbaa !23
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t134 = icmp eq i32 %t130, %t131
  br i1 %t134, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb48
bb46:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Call", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %t136, ptr %t140)
  store i1 %t143, ptr %l79
  br label %bb47
bb47:
  %t144 = load i1, ptr %l79, !tbaa !21
  store i1 %t144, ptr %l75, !tbaa !21
  br label %bb48
bb48:
  %t145 = load i1, ptr %l75, !tbaa !21
  br i1 %t145, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb52
bb50:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l5, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t153 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  store i1 %t153, ptr %l84
  br label %bb51
bb51:
  %t154 = load i1, ptr %l84, !tbaa !21
  store i1 %t154, ptr %l80, !tbaa !21
  br label %bb52
bb52:
  %t155 = load i1, ptr %l80, !tbaa !21
  store i1 %t155, ptr %l19, !tbaa !21
  br label %bb183
bb53:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb54, label %bb55
bb54:
  %t160 = load ptr, ptr %l85, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 18}
  %t163 = icmp eq i64 %t161, 7
  store i1 %t163, ptr %l86, !tbaa !21
  br label %bb55
bb55:
  %t164 = load i1, ptr %l86, !tbaa !21
  br i1 %t164, label %bb56, label %bb57
bb56:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Make", ptr %t172, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t178 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t171, { i64, ptr } %t175)
  store i1 %t178, ptr %l94
  br label %bb59
bb59:
  %t179 = load i1, ptr %l94, !tbaa !21
  br i1 %t179, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb63
bb61:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l6, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Make", ptr %t181, i32 0, i32 3
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t187 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t180, ptr %t184)
  store i1 %t187, ptr %l99
  br label %bb62
bb62:
  %t188 = load i1, ptr %l99, !tbaa !21
  store i1 %t188, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t189 = load i1, ptr %l95, !tbaa !21
  store i1 %t189, ptr %l19, !tbaa !21
  br label %bb183
bb64:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t191 = load ptr, ptr %l100, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb65, label %bb66
bb65:
  %t194 = load ptr, ptr %l100, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 18}
  %t197 = icmp eq i64 %t195, 8
  store i1 %t197, ptr %l101, !tbaa !21
  br label %bb66
bb66:
  %t198 = load i1, ptr %l101, !tbaa !21
  br i1 %t198, label %bb67, label %bb68
bb67:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t201, i32 0, i32 2
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l7, !tbaa !29
  br label %bb69
bb68:
  br label %bb75
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Collect", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t212 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t205, ptr %t209)
  store i1 %t212, ptr %l109
  br label %bb70
bb70:
  %t213 = load i1, ptr %l109, !tbaa !21
  br i1 %t213, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb74
bb72:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l7, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Collect", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %s7, ptr %t214, ptr %t218, ptr null)
  store i1 %t221, ptr %l114
  br label %bb73
bb73:
  %t222 = load i1, ptr %l114, !tbaa !21
  store i1 %t222, ptr %l110, !tbaa !21
  br label %bb74
bb74:
  %t223 = load i1, ptr %l110, !tbaa !21
  store i1 %t223, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb183
bb75:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t225 = load ptr, ptr %l115, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb76, label %bb77
bb76:
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 18}
  %t231 = icmp eq i64 %t229, 9
  store i1 %t231, ptr %l116, !tbaa !21
  br label %bb77
bb77:
  %t232 = load i1, ptr %l116, !tbaa !21
  br i1 %t232, label %bb78, label %bb79
bb78:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t235, i32 0, i32 4
  %t237 = load { i64, ptr }, ptr %t236
  store { i64, ptr } %t237, ptr %l8, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t243 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t239, { i64, ptr } %t240)
  store i1 %t243, ptr %l123
  br label %bb81
bb81:
  %t244 = load i1, ptr %l123, !tbaa !21
  store i1 %t244, ptr %l19, !tbaa !21
  br label %bb183
bb82:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t246 = load ptr, ptr %l124, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb83, label %bb84
bb83:
  %t249 = load ptr, ptr %l124, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 18}
  %t252 = icmp eq i64 %t250, 10
  store i1 %t252, ptr %l125, !tbaa !21
  br label %bb84
bb84:
  %t253 = load i1, ptr %l125, !tbaa !21
  br i1 %t253, label %bb85, label %bb86
bb85:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l9, !tbaa !29
  br label %bb87
bb86:
  br label %bb97
bb87:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l9, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Slice", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t267 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t260, ptr %t264)
  store i1 %t267, ptr %l133
  br label %bb88
bb88:
  %t268 = load i1, ptr %l133, !tbaa !21
  br i1 %t268, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb92
bb90:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l9, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Slice", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t277 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t269, ptr %t273)
  store i1 %t277, ptr %l139
  br label %bb91
bb91:
  %t278 = load i1, ptr %l139, !tbaa !21
  store i1 %t278, ptr %l134, !tbaa !21
  br label %bb92
bb92:
  %t279 = load i1, ptr %l134, !tbaa !21
  br i1 %t279, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb96
bb94:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l9, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Slice", ptr %t281, i32 0, i32 2
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t288 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t280, ptr %t284)
  store i1 %t288, ptr %l145
  br label %bb95
bb95:
  %t289 = load i1, ptr %l145, !tbaa !21
  store i1 %t289, ptr %l140, !tbaa !21
  br label %bb96
bb96:
  %t290 = load i1, ptr %l140, !tbaa !21
  store i1 %t290, ptr %l19, !tbaa !21
  br label %bb183
bb97:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t292 = load ptr, ptr %l146, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb98, label %bb99
bb98:
  %t295 = load ptr, ptr %l146, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 18}
  %t298 = icmp eq i64 %t296, 11
  store i1 %t298, ptr %l147, !tbaa !21
  br label %bb99
bb99:
  %t299 = load i1, ptr %l147, !tbaa !21
  br i1 %t299, label %bb100, label %bb101
bb100:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t302, i32 0, i32 2
  %t304 = load ptr, ptr %t303
  store ptr %t304, ptr %l10, !tbaa !29
  br label %bb102
bb101:
  br label %bb112
bb102:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l10, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Cond", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t314 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t306, ptr %t310)
  store i1 %t314, ptr %l156
  br label %bb103
bb103:
  %t315 = load i1, ptr %l156, !tbaa !21
  br i1 %t315, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb107
bb105:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l10, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Cond", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t323 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t323, ptr %l161
  br label %bb106
bb106:
  %t324 = load i1, ptr %l161, !tbaa !21
  store i1 %t324, ptr %l157, !tbaa !21
  br label %bb107
bb107:
  %t325 = load i1, ptr %l157, !tbaa !21
  br i1 %t325, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb111
bb109:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l10, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Cond", ptr %t327, i32 0, i32 2
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t334 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t326, ptr %t330)
  store i1 %t334, ptr %l167
  br label %bb110
bb110:
  %t335 = load i1, ptr %l167, !tbaa !21
  store i1 %t335, ptr %l162, !tbaa !21
  br label %bb111
bb111:
  %t336 = load i1, ptr %l162, !tbaa !21
  store i1 %t336, ptr %l19, !tbaa !21
  br label %bb183
bb112:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t338 = load ptr, ptr %l168, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb113, label %bb114
bb113:
  %t341 = load ptr, ptr %l168, !tbaa !29
  %t342 = load i64, ptr %t341, !range !{i64 0, i64 18}
  %t344 = icmp eq i64 %t342, 12
  store i1 %t344, ptr %l169, !tbaa !21
  br label %bb114
bb114:
  %t345 = load i1, ptr %l169, !tbaa !21
  br i1 %t345, label %bb115, label %bb116
bb115:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t348, i32 0, i32 2
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l11, !tbaa !29
  br label %bb117
bb116:
  br label %bb123
bb117:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l11, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Seq", ptr %t353, i32 0, i32 0
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  %t359 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t352, { i64, ptr } %t356)
  store i1 %t359, ptr %l177
  br label %bb118
bb118:
  %t360 = load i1, ptr %l177, !tbaa !21
  br i1 %t360, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb122
bb120:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l11, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Seq", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t368 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t361, ptr %t365)
  store i1 %t368, ptr %l182
  br label %bb121
bb121:
  %t369 = load i1, ptr %l182, !tbaa !21
  store i1 %t369, ptr %l178, !tbaa !21
  br label %bb122
bb122:
  %t370 = load i1, ptr %l178, !tbaa !21
  store i1 %t370, ptr %l19, !tbaa !21
  br label %bb183
bb123:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t372 = load ptr, ptr %l183, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb124, label %bb125
bb124:
  %t375 = load ptr, ptr %l183, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 13
  store i1 %t378, ptr %l184, !tbaa !21
  br label %bb125
bb125:
  %t379 = load i1, ptr %l184, !tbaa !21
  br i1 %t379, label %bb126, label %bb127
bb126:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l12, !tbaa !29
  br label %bb128
bb127:
  br label %bb144
bb128:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l12, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Match", ptr %t387, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t393 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t386, { i64, ptr } %t390)
  store i1 %t393, ptr %l192
  br label %bb129
bb129:
  %t394 = load i1, ptr %l192, !tbaa !21
  br i1 %t394, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb133
bb131:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l12, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Match", ptr %t396, i32 0, i32 1
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  %t402 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %t395, { i64, ptr } %t399)
  store i1 %t402, ptr %l197
  br label %bb132
bb132:
  %t403 = load i1, ptr %l197, !tbaa !21
  store i1 %t403, ptr %l193, !tbaa !21
  br label %bb133
bb133:
  %t404 = load i1, ptr %l193, !tbaa !21
  br i1 %t404, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb143
bb135:
  %t405 = load ptr, ptr %l12, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Match", ptr %t405, i32 0, i32 2
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = icmp eq ptr %t408, null
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb136, label %bb137
bb136:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l204, !tbaa !29
  %t415 = load ptr, ptr %l12, !tbaa !29
  %t417 = getelementptr %"compiler/typed:Match", ptr %t415, i32 0, i32 2
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = icmp eq ptr %t418, null
  br i1 %t420, label %bb138, label %bb139
bb137:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb142
bb138:
  call void @__olang_check_failed(ptr @olang_loc_b80660129801afa0_e660219d512f014)
  unreachable
bb139:
  br label %bb140
bb140:
  %t422 = load ptr, ptr %l12, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Match", ptr %t422, i32 0, i32 2
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t426 = load ptr, ptr %l204, !tbaa !29
  %t428 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %t426, ptr %t425)
  store i1 %t428, ptr %l210
  br label %bb141
bb141:
  %t429 = load i1, ptr %l210, !tbaa !21
  store i1 %t429, ptr %l203, !tbaa !21
  br label %bb142
bb142:
  %t430 = load i1, ptr %l203, !tbaa !21
  store i1 %t430, ptr %l198, !tbaa !21
  br label %bb143
bb143:
  %t431 = load i1, ptr %l198, !tbaa !21
  store i1 %t431, ptr %l19, !tbaa !21
  br label %bb183
bb144:
  %t432 = load ptr, ptr %l1, !tbaa !29
  store ptr %t432, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t433 = load ptr, ptr %l211, !tbaa !29
  %t434 = icmp ne ptr %t433, null
  br i1 %t434, label %bb145, label %bb146
bb145:
  %t436 = load ptr, ptr %l211, !tbaa !29
  %t437 = load i64, ptr %t436, !range !{i64 0, i64 18}
  %t439 = icmp eq i64 %t437, 14
  store i1 %t439, ptr %l212, !tbaa !21
  br label %bb146
bb146:
  %t440 = load i1, ptr %l212, !tbaa !21
  br i1 %t440, label %bb147, label %bb148
bb147:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [5 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t443, i32 0, i32 2
  %t445 = load ptr, ptr %t444
  store ptr %t445, ptr %l13, !tbaa !29
  br label %bb149
bb148:
  br label %bb168
bb149:
  %t447 = load ptr, ptr %l13, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Try", ptr %t447, i32 0, i32 2
  %t450 = load i1, ptr %t449, !tbaa !21
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb150, label %bb151
bb150:
  %t454 = load ptr, ptr %l13, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Try", ptr %t454, i32 0, i32 3
  %t457 = load i1, ptr %t456, !tbaa !21
  %t459 = xor i1 %t457, true
  store i1 %t459, ptr %l220, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb152
bb152:
  %t461 = load i1, ptr %l220, !tbaa !21
  br i1 %t461, label %bb153, label %bb154
bb153:
  %t462 = load ptr, ptr %l13, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Try", ptr %t462, i32 0, i32 4
  %t465 = load i1, ptr %t464, !tbaa !21
  store i1 %t465, ptr %l224, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb155
bb155:
  %t467 = load i1, ptr %l224, !tbaa !21
  br i1 %t467, label %bb156, label %bb157
bb156:
  %t468 = load ptr, ptr %l13, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Try", ptr %t468, i32 0, i32 1
  %t471 = load { i64, ptr }, ptr %t470, !tbaa !27
  %t473 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t471)
  store i1 %t473, ptr %l230
  br label %bb158
bb157:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb159
bb158:
  %t474 = load i1, ptr %l230, !tbaa !21
  %t475 = xor i1 %t474, true
  store i1 %t475, ptr %l227, !tbaa !21
  br label %bb159
bb159:
  %t477 = load i1, ptr %l227, !tbaa !21
  br i1 %t477, label %bb160, label %bb161
bb160:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb163
bb161:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l13, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Try", ptr %t479, i32 0, i32 0
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t485 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  store i1 %t485, ptr %l236
  br label %bb162
bb162:
  %t486 = load i1, ptr %l236, !tbaa !21
  store i1 %t486, ptr %l232, !tbaa !21
  br label %bb163
bb163:
  %t487 = load i1, ptr %l232, !tbaa !21
  br i1 %t487, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb167
bb165:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l13, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Try", ptr %t489, i32 0, i32 1
  %t492 = load { i64, ptr }, ptr %t491, !tbaa !27
  %t495 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t488, { i64, ptr } %t492)
  store i1 %t495, ptr %l241
  br label %bb166
bb166:
  %t496 = load i1, ptr %l241, !tbaa !21
  store i1 %t496, ptr %l237, !tbaa !21
  br label %bb167
bb167:
  %t497 = load i1, ptr %l237, !tbaa !21
  store i1 %t497, ptr %l19, !tbaa !21
  br label %bb183
bb168:
  %t498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t498, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t499 = load ptr, ptr %l242, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb169, label %bb170
bb169:
  %t502 = load ptr, ptr %l242, !tbaa !29
  %t503 = load i64, ptr %t502, !range !{i64 0, i64 18}
  %t505 = icmp eq i64 %t503, 16
  store i1 %t505, ptr %l243, !tbaa !21
  br label %bb170
bb170:
  %t506 = load i1, ptr %l243, !tbaa !21
  br i1 %t506, label %bb171, label %bb172
bb171:
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t509, i32 0, i32 2
  %t511 = load ptr, ptr %t510
  store ptr %t511, ptr %l14, !tbaa !29
  br label %bb173
bb172:
  br label %bb175
bb173:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load ptr, ptr %l14, !tbaa !29
  %t516 = getelementptr %"compiler/typed:Text", ptr %t514, i32 0, i32 0
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  %t520 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %t513, { i64, ptr } %t517)
  store i1 %t520, ptr %l251
  br label %bb174
bb174:
  %t521 = load i1, ptr %l251, !tbaa !21
  store i1 %t521, ptr %l19, !tbaa !21
  br label %bb183
bb175:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t523 = load ptr, ptr %l252, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb176, label %bb177
bb176:
  %t526 = load ptr, ptr %l252, !tbaa !29
  %t527 = load i64, ptr %t526, !range !{i64 0, i64 18}
  %t529 = icmp eq i64 %t527, 17
  store i1 %t529, ptr %l253, !tbaa !21
  br label %bb177
bb177:
  %t530 = load i1, ptr %l253, !tbaa !21
  br i1 %t530, label %bb178, label %bb179
bb178:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [5 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t533, i32 0, i32 2
  %t535 = load ptr, ptr %t534
  store ptr %t535, ptr %l15, !tbaa !29
  br label %bb180
bb179:
  br label %bb182
bb180:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load ptr, ptr %l15, !tbaa !29
  %t542 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t537, ptr %t538)
  store i1 %t542, ptr %l261
  br label %bb181
bb181:
  %t543 = load i1, ptr %l261, !tbaa !21
  store i1 %t543, ptr %l19, !tbaa !21
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba)
  unreachable
bb183:
  %t544 = load i1, ptr %l19, !tbaa !21
  store i1 %t544, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Elem", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t86, ptr %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Elem", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Payload", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t128 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t121, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t150 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_1807395182923f6f_ecff5ea7ed15d953)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = sub i64 %t2, 1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t12 = sext i32 %t8 to i64
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s0, ptr %t1, i64 %t4, { i64, ptr } %t26)
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %t55, ptr %t53, i64 %t57)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l105 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca i1
  %l138 = alloca i32
  %l140 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l169 = alloca i32
  %l171 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i32
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l199 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l212 = alloca i1
  %l221 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l233 = alloca i1
  %l240 = alloca i64
  %l244 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l247 = alloca i1
  %l254 = alloca i64
  %l269 = alloca ptr
  %l270 = alloca i1
  %l278 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca i1
  %l309 = alloca i64
  %l313 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t5, ptr %l29, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l30, !tbaa !24
  %t8 = load i64, ptr %l30, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l31, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l30, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:printer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t25)
  store i32 %t27, ptr %l35
  br label %bb4
bb4:
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = load ptr, ptr %l33, !tbaa !29
  %t30 = load i32, ptr %l35, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t28, ptr %s0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l36
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l38, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 0
  store i1 %t40, ptr %l39, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l39, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t44, i32 0, i32 2
  %t46 = load i64, ptr %t45
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t48, 1
  %t54 = extractvalue { i64, ptr } %t48, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t60 = call i64 @__olang_fmt_i64(ptr null, i64 %t49)
  %t61 = add i64 %t58, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t50, i64 %t51)
  %t66 = getelementptr i8, ptr %t65, i64 %t51
  call void @olang_textcopy(ptr %t66, ptr %t53, i64 %t54)
  %t67 = getelementptr i8, ptr %t66, i64 %t54
  call void @olang_textcopy(ptr %t67, ptr %t56, i64 %t57)
  %t68 = getelementptr i8, ptr %t67, i64 %t57
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t49)
  %t70 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t70, ptr %t62, i64 %t63)
  %t71 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t65, 1
  store { i64, ptr } %t72, ptr %l37, !tbaa !27
  br label %bb150
bb11:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load ptr, ptr %l47, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l48, !tbaa !21
  br label %bb13
bb13:
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load i64, ptr %t86
  store i64 %t87, ptr %l4, !tbaa !24
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t91, i32 0, i32 3
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %l56, !tbaa !24
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v1, ptr %s4, ptr %t97)
  store { i64, ptr } %t99, ptr %l58
  br label %bb17
bb17:
  %t100 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = load i64, ptr %l56, !tbaa !24
  %t110 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t111 = add i64 %t108, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t100, i64 %t101)
  %t123 = getelementptr i8, ptr %t122, i64 %t101
  call void @olang_textcopy(ptr %t123, ptr %t103, i64 %t104)
  %t124 = getelementptr i8, ptr %t123, i64 %t104
  call void @olang_textcopy(ptr %t124, ptr %t106, i64 %t107)
  %t125 = getelementptr i8, ptr %t124, i64 %t107
  %t126 = call i64 @__olang_fmt_i64(ptr %t125, i64 %t109)
  %t127 = getelementptr i8, ptr %t125, i64 %t110
  call void @olang_textcopy(ptr %t127, ptr %t112, i64 %t113)
  %t128 = getelementptr i8, ptr %t127, i64 %t113
  call void @olang_textcopy(ptr %t128, ptr %t116, i64 %t117)
  %t129 = getelementptr i8, ptr %t128, i64 %t117
  call void @olang_textcopy(ptr %t129, ptr %t119, i64 %t120)
  %t130 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t122, 1
  store { i64, ptr } %t131, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb150
bb18:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb19, label %bb20
bb19:
  %t137 = load ptr, ptr %l60, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 18}
  %t140 = icmp eq i64 %t138, 2
  store i1 %t140, ptr %l61, !tbaa !21
  br label %bb20
bb20:
  %t141 = load i1, ptr %l61, !tbaa !21
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t144, i32 0, i32 2
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l6, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t150, i32 0, i32 3
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t158 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s6, ptr %t154, ptr %t155)
  store { i64, ptr } %t158, ptr %l70
  br label %bb24
bb24:
  %t159 = load i32, ptr %l7, !tbaa !23
  %t161 = icmp sge i32 %t159, 0
  br i1 %t161, label %bb25, label %bb26
bb25:
  %t163 = load i32, ptr %l7, !tbaa !23
  %t164 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t167 = sext i32 %t163 to i64
  %t168 = call i64 @__olang_fmt_i64(ptr null, i64 %t167)
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t164, i64 %t165)
  %t171 = getelementptr i8, ptr %t170, i64 %t165
  %t172 = call i64 @__olang_fmt_i64(ptr %t171, i64 %t167)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t170, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l73, !tbaa !27
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l73, !tbaa !27
  br label %bb27
bb27:
  %t183 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t185 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t183, i64 %t184)
  %t197 = getelementptr i8, ptr %t196, i64 %t184
  call void @olang_textcopy(ptr %t197, ptr %t186, i64 %t187)
  %t198 = getelementptr i8, ptr %t197, i64 %t187
  call void @olang_textcopy(ptr %t198, ptr %t190, i64 %t191)
  %t199 = getelementptr i8, ptr %t198, i64 %t191
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t196, 1
  store { i64, ptr } %t201, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb150
bb28:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t204 = load ptr, ptr %l78, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb29, label %bb30
bb29:
  %t207 = load ptr, ptr %l78, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 18}
  %t210 = icmp eq i64 %t208, 3
  store i1 %t210, ptr %l79, !tbaa !21
  br label %bb30
bb30:
  %t211 = load i1, ptr %l79, !tbaa !21
  br i1 %t211, label %bb31, label %bb32
bb31:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t214, i32 0, i32 2
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t218 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t218, ptr %l84, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l8, !tbaa !29
  %t223 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t219, ptr %t220)
  store { i64, ptr } %t223, ptr %l87
  br label %bb34
bb34:
  %t224 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t226 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t224, i64 %t225)
  %t241 = getelementptr i8, ptr %t240, i64 %t225
  call void @olang_textcopy(ptr %t241, ptr %t227, i64 %t228)
  %t242 = getelementptr i8, ptr %t241, i64 %t228
  call void @olang_textcopy(ptr %t242, ptr %t230, i64 %t231)
  %t243 = getelementptr i8, ptr %t242, i64 %t231
  call void @olang_textcopy(ptr %t243, ptr %t234, i64 %t235)
  %t244 = getelementptr i8, ptr %t243, i64 %t235
  call void @olang_textcopy(ptr %t244, ptr %t237, i64 %t238)
  %t245 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t240, 1
  store { i64, ptr } %t246, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb150
bb35:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t249 = load ptr, ptr %l89, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb36, label %bb37
bb36:
  %t252 = load ptr, ptr %l89, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 18}
  %t255 = icmp eq i64 %t253, 4
  store i1 %t255, ptr %l90, !tbaa !21
  br label %bb37
bb37:
  %t256 = load i1, ptr %l90, !tbaa !21
  br i1 %t256, label %bb38, label %bb39
bb38:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l9, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l9, !tbaa !29
  %t267 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t263, ptr %t264)
  store { i64, ptr } %t267, ptr %l97
  br label %bb41
bb41:
  %t268 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t270 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t268, i64 %t269)
  %t278 = getelementptr i8, ptr %t277, i64 %t269
  call void @olang_textcopy(ptr %t278, ptr %t271, i64 %t272)
  %t279 = getelementptr i8, ptr %t278, i64 %t272
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t277, 1
  store { i64, ptr } %t281, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb150
bb42:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t284 = load ptr, ptr %l99, !tbaa !29
  %t285 = icmp ne ptr %t284, null
  br i1 %t285, label %bb43, label %bb44
bb43:
  %t287 = load ptr, ptr %l99, !tbaa !29
  %t288 = load i64, ptr %t287, !range !{i64 0, i64 18}
  %t290 = icmp eq i64 %t288, 5
  store i1 %t290, ptr %l100, !tbaa !21
  br label %bb44
bb44:
  %t291 = load i1, ptr %l100, !tbaa !21
  br i1 %t291, label %bb45, label %bb46
bb45:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t294, i32 0, i32 2
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t298 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t298, ptr %l105, !tbaa !27
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l10, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Promote", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t307 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t299, ptr %t303)
  store { i64, ptr } %t307, ptr %l110
  br label %bb48
bb48:
  %t308 = load ptr, ptr %l10, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Promote", ptr %t308, i32 0, i32 1
  %t311 = load i32, ptr %t310, !tbaa !23
  %t312 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t314 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t321 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = sext i32 %t311 to i64
  %t330 = call i64 @__olang_fmt_i64(ptr null, i64 %t329)
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t312, i64 %t313)
  %t336 = getelementptr i8, ptr %t335, i64 %t313
  call void @olang_textcopy(ptr %t336, ptr %t315, i64 %t316)
  %t337 = getelementptr i8, ptr %t336, i64 %t316
  call void @olang_textcopy(ptr %t337, ptr %t318, i64 %t319)
  %t338 = getelementptr i8, ptr %t337, i64 %t319
  call void @olang_textcopy(ptr %t338, ptr %t322, i64 %t323)
  %t339 = getelementptr i8, ptr %t338, i64 %t323
  call void @olang_textcopy(ptr %t339, ptr %t325, i64 %t326)
  %t340 = getelementptr i8, ptr %t339, i64 %t326
  %t341 = call i64 @__olang_fmt_i64(ptr %t340, i64 %t329)
  %t342 = getelementptr i8, ptr %t340, i64 %t330
  call void @olang_textcopy(ptr %t342, ptr %t332, i64 %t333)
  %t343 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t335, 1
  store { i64, ptr } %t344, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb150
bb49:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t347 = load ptr, ptr %l114, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb50, label %bb51
bb50:
  %t350 = load ptr, ptr %l114, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 18}
  %t353 = icmp eq i64 %t351, 6
  store i1 %t353, ptr %l115, !tbaa !21
  br label %bb51
bb51:
  %t354 = load i1, ptr %l115, !tbaa !21
  br i1 %t354, label %bb52, label %bb53
bb52:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t357, i32 0, i32 2
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l11, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Call", ptr %t362, i32 0, i32 0
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t368 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %s15, ptr %t361, ptr %t365)
  store { i64, ptr } %t368, ptr %l123
  br label %bb55
bb55:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l11, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Call", ptr %t370, i32 0, i32 1
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t376 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s15, ptr %t369, { i64, ptr } %t373)
  store { i64, ptr } %t376, ptr %l127
  br label %bb56
bb56:
  %t377 = load ptr, ptr %l11, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Call", ptr %t377, i32 0, i32 2
  %t380 = load i32, ptr %t379, !tbaa !23
  %t381 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t383 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = add i64 %t389, %t392
  %t394 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t396 = add i64 %t393, %t395
  %t398 = sext i32 %t380 to i64
  %t399 = call i64 @__olang_fmt_i64(ptr null, i64 %t398)
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t381, i64 %t382)
  %t405 = getelementptr i8, ptr %t404, i64 %t382
  call void @olang_textcopy(ptr %t405, ptr %t384, i64 %t385)
  %t406 = getelementptr i8, ptr %t405, i64 %t385
  call void @olang_textcopy(ptr %t406, ptr %t387, i64 %t388)
  %t407 = getelementptr i8, ptr %t406, i64 %t388
  call void @olang_textcopy(ptr %t407, ptr %t391, i64 %t392)
  %t408 = getelementptr i8, ptr %t407, i64 %t392
  call void @olang_textcopy(ptr %t408, ptr %t394, i64 %t395)
  %t409 = getelementptr i8, ptr %t408, i64 %t395
  %t410 = call i64 @__olang_fmt_i64(ptr %t409, i64 %t398)
  %t411 = getelementptr i8, ptr %t409, i64 %t399
  call void @olang_textcopy(ptr %t411, ptr %t401, i64 %t402)
  %t412 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t404, 1
  store { i64, ptr } %t413, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb150
bb57:
  %t415 = load ptr, ptr %l1, !tbaa !29
  store ptr %t415, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t416 = load ptr, ptr %l131, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb58, label %bb59
bb58:
  %t419 = load ptr, ptr %l131, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 18}
  %t422 = icmp eq i64 %t420, 7
  store i1 %t422, ptr %l132, !tbaa !21
  br label %bb59
bb59:
  %t423 = load i1, ptr %l132, !tbaa !21
  br i1 %t423, label %bb60, label %bb61
bb60:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [5 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t426, i32 0, i32 2
  %t428 = load ptr, ptr %t427
  store ptr %t428, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb66
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t430 = load ptr, ptr %l12, !tbaa !29
  %t432 = getelementptr %"compiler/typed:Make", ptr %t430, i32 0, i32 0
  %t433 = load i32, ptr %t432, !range !{i32 0, i32 5}
  store i32 %t433, ptr %l138
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %s18, ptr %l138, i64 0)
  br label %bb63
bb63:
  %t435 = load ptr, ptr %s18
  %t436 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t437 = load i64, ptr %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t435, i64 %t437)
  %t439 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  store { i64, ptr } %t440, ptr %l140, !tbaa !27
  %t441 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t442 = load ptr, ptr %t441
  %t443 = icmp ne ptr %t442, null
  br i1 %t443, label %sbgrew.444, label %sbdone.445
sbgrew.444:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.445
sbdone.445:
  %t446 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 0
  %t448 = extractvalue { i64, ptr } %t446, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t454 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s17, ptr %s17, { i64, ptr } %t452)
  store { i64, ptr } %t454, ptr %l142
  br label %bb64
bb64:
  %t455 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t455, ptr %l143, !tbaa !27
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load ptr, ptr %l12, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Make", ptr %t457, i32 0, i32 2
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  %t463 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s17, ptr %t456, { i64, ptr } %t460)
  store { i64, ptr } %t463, ptr %l147
  br label %bb65
bb65:
  %t464 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t466 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 1
  %t468 = extractvalue { i64, ptr } %t466, 0
  %t469 = add i64 %t465, %t468
  %t470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t472 = add i64 %t469, %t471
  %t473 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = add i64 %t472, %t475
  %t477 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t479 = add i64 %t476, %t478
  %t480 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = add i64 %t479, %t482
  %t484 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t464, i64 %t465)
  %t488 = getelementptr i8, ptr %t487, i64 %t465
  call void @olang_textcopy(ptr %t488, ptr %t467, i64 %t468)
  %t489 = getelementptr i8, ptr %t488, i64 %t468
  call void @olang_textcopy(ptr %t489, ptr %t470, i64 %t471)
  %t490 = getelementptr i8, ptr %t489, i64 %t471
  call void @olang_textcopy(ptr %t490, ptr %t474, i64 %t475)
  %t491 = getelementptr i8, ptr %t490, i64 %t475
  call void @olang_textcopy(ptr %t491, ptr %t477, i64 %t478)
  %t492 = getelementptr i8, ptr %t491, i64 %t478
  call void @olang_textcopy(ptr %t492, ptr %t481, i64 %t482)
  %t493 = getelementptr i8, ptr %t492, i64 %t482
  call void @olang_textcopy(ptr %t493, ptr %t484, i64 %t485)
  %t494 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t487, 1
  store { i64, ptr } %t495, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb150
bb66:
  %t497 = load ptr, ptr %l1, !tbaa !29
  store ptr %t497, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t498 = load ptr, ptr %l149, !tbaa !29
  %t499 = icmp ne ptr %t498, null
  br i1 %t499, label %bb67, label %bb68
bb67:
  %t501 = load ptr, ptr %l149, !tbaa !29
  %t502 = load i64, ptr %t501, !range !{i64 0, i64 18}
  %t504 = icmp eq i64 %t502, 8
  store i1 %t504, ptr %l150, !tbaa !21
  br label %bb68
bb68:
  %t505 = load i1, ptr %l150, !tbaa !21
  br i1 %t505, label %bb69, label %bb70
bb69:
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 1
  %t509 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t508, i32 0, i32 2
  %t510 = load ptr, ptr %t509
  store ptr %t510, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t512 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t513 = load ptr, ptr %l13, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Collect", ptr %t513, i32 0, i32 2
  %t516 = load i32, ptr %t515, !tbaa !23
  %t517 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t520 = extractvalue { i64, ptr } %t512, 1
  %t521 = extractvalue { i64, ptr } %t512, 0
  %t522 = add i64 %t518, %t521
  %t523 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t525 = add i64 %t522, %t524
  %t527 = sext i32 %t516 to i64
  %t528 = call i64 @__olang_fmt_i64(ptr null, i64 %t527)
  %t529 = add i64 %t525, %t528
  %t530 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t532 = add i64 %t529, %t531
  %t533 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t532)
  call void @olang_textcopy(ptr %t533, ptr %t517, i64 %t518)
  %t534 = getelementptr i8, ptr %t533, i64 %t518
  call void @olang_textcopy(ptr %t534, ptr %t520, i64 %t521)
  %t535 = getelementptr i8, ptr %t534, i64 %t521
  call void @olang_textcopy(ptr %t535, ptr %t523, i64 %t524)
  %t536 = getelementptr i8, ptr %t535, i64 %t524
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t527)
  %t538 = getelementptr i8, ptr %t536, i64 %t528
  call void @olang_textcopy(ptr %t538, ptr %t530, i64 %t531)
  %t539 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t533, 1
  store { i64, ptr } %t540, ptr %l37, !tbaa !27
  br label %bb150
bb72:
  %t542 = load ptr, ptr %l1, !tbaa !29
  store ptr %t542, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t543 = load ptr, ptr %l159, !tbaa !29
  %t544 = icmp ne ptr %t543, null
  br i1 %t544, label %bb73, label %bb74
bb73:
  %t546 = load ptr, ptr %l159, !tbaa !29
  %t547 = load i64, ptr %t546, !range !{i64 0, i64 18}
  %t549 = icmp eq i64 %t547, 9
  store i1 %t549, ptr %l160, !tbaa !21
  br label %bb74
bb74:
  %t550 = load i1, ptr %l160, !tbaa !21
  br i1 %t550, label %bb75, label %bb76
bb75:
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t553, i32 0, i32 2
  %t555 = load i32, ptr %t554, !range !{i32 0, i32 47}
  store i32 %t555, ptr %l14
  %t557 = load ptr, ptr %l1, !tbaa !29
  %t559 = getelementptr { i64, [5 x i64] }, ptr %t557, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t559, i32 0, i32 3
  %t561 = load i32, ptr %t560, !range !{i32 0, i32 3}
  store i32 %t561, ptr %l15
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t565, i32 0, i32 4
  %t567 = load { i64, ptr }, ptr %t566
  store { i64, ptr } %t567, ptr %l16, !tbaa !27
  br label %bb77
bb76:
  br label %bb86
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t569 = load i32, ptr %l14, !range !{i32 0, i32 47}
  store i32 %t569, ptr %l169
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s23, ptr %l169, i64 0)
  br label %bb78
bb78:
  %t571 = load ptr, ptr %s23
  %t572 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t573 = load i64, ptr %t572
  %t574 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t573)
  call void @olang_textcopy(ptr %t574, ptr %t571, i64 %t573)
  %t575 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  store { i64, ptr } %t576, ptr %l171, !tbaa !27
  %t577 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t578 = load ptr, ptr %t577
  %t579 = icmp ne ptr %t578, null
  br i1 %t579, label %sbgrew.580, label %sbdone.581
sbgrew.580:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.581
sbdone.581:
  %t582 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t582, 0
  %t584 = extractvalue { i64, ptr } %t582, 1
  %t585 = mul i64 %t583, 1
  %t586 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t585)
  call void @llvm.memcpy.p0.p0.i64(ptr %t586, ptr %t584, i64 %t585, i1 false)
  %t587 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t586, 1
  %t590 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, ptr %s22, { i64, ptr } %t588)
  store { i64, ptr } %t590, ptr %l173
  br label %bb79
bb79:
  %t591 = load i32, ptr %l15, !range !{i32 0, i32 3}
  %t593 = trunc i64 0 to i32
  %t594 = icmp eq i32 %t591, %t593
  %t596 = xor i1 %t594, true
  br i1 %t596, label %bb80, label %bb81
bb80:
  %t598 = load i32, ptr %l15, !range !{i32 0, i32 3}
  store i32 %t598, ptr %l178
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %s24, ptr %l178, i64 0)
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l177, !tbaa !27
  br label %bb84
bb82:
  %t600 = load ptr, ptr %s24
  %t601 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t602 = load i64, ptr %t601
  %t603 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t602)
  call void @olang_textcopy(ptr %t603, ptr %t600, i64 %t602)
  %t604 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t603, 1
  store { i64, ptr } %t605, ptr %l180, !tbaa !27
  %t606 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t607 = load ptr, ptr %t606
  %t608 = icmp ne ptr %t607, null
  br i1 %t608, label %sbgrew.609, label %sbdone.610
sbgrew.609:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.610
sbdone.610:
  %t611 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t612 = extractvalue { i64, ptr } %t611, 0
  %t613 = extractvalue { i64, ptr } %t611, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t619 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, ptr %s22, { i64, ptr } %t617)
  store { i64, ptr } %t619, ptr %l182
  br label %bb83
bb83:
  %t620 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t621 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t622 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t623 = extractvalue { i64, ptr } %t622, 1
  %t624 = extractvalue { i64, ptr } %t622, 0
  %t625 = add i64 %t621, %t624
  %t626 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t625)
  call void @olang_textcopy(ptr %t626, ptr %t620, i64 %t621)
  %t627 = getelementptr i8, ptr %t626, i64 %t621
  call void @olang_textcopy(ptr %t627, ptr %t623, i64 %t624)
  %t628 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t626, 1
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t632 = extractvalue { i64, ptr } %t629, 1
  %t633 = mul i64 %t631, 1
  %t634 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t633)
  call void @llvm.memcpy.p0.p0.i64(ptr %t634, ptr %t632, i64 %t633, i1 false)
  %t635 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  store { i64, ptr } %t636, ptr %l177, !tbaa !27
  br label %bb84
bb84:
  %t638 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t638, ptr %l185, !tbaa !27
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t643 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s22, ptr %t639, { i64, ptr } %t640)
  store { i64, ptr } %t643, ptr %l188
  br label %bb85
bb85:
  %t644 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t645 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t646 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t647 = extractvalue { i64, ptr } %t646, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = add i64 %t645, %t648
  %t650 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t651 = extractvalue { i64, ptr } %t650, 1
  %t652 = extractvalue { i64, ptr } %t650, 0
  %t653 = add i64 %t649, %t652
  %t654 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t655 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t656 = add i64 %t653, %t655
  %t657 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 1
  %t659 = extractvalue { i64, ptr } %t657, 0
  %t660 = add i64 %t656, %t659
  %t661 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t663 = add i64 %t660, %t662
  %t664 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t664, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = add i64 %t663, %t666
  %t668 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t671 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t670)
  call void @olang_textcopy(ptr %t671, ptr %t644, i64 %t645)
  %t672 = getelementptr i8, ptr %t671, i64 %t645
  call void @olang_textcopy(ptr %t672, ptr %t647, i64 %t648)
  %t673 = getelementptr i8, ptr %t672, i64 %t648
  call void @olang_textcopy(ptr %t673, ptr %t651, i64 %t652)
  %t674 = getelementptr i8, ptr %t673, i64 %t652
  call void @olang_textcopy(ptr %t674, ptr %t654, i64 %t655)
  %t675 = getelementptr i8, ptr %t674, i64 %t655
  call void @olang_textcopy(ptr %t675, ptr %t658, i64 %t659)
  %t676 = getelementptr i8, ptr %t675, i64 %t659
  call void @olang_textcopy(ptr %t676, ptr %t661, i64 %t662)
  %t677 = getelementptr i8, ptr %t676, i64 %t662
  call void @olang_textcopy(ptr %t677, ptr %t665, i64 %t666)
  %t678 = getelementptr i8, ptr %t677, i64 %t666
  call void @olang_textcopy(ptr %t678, ptr %t668, i64 %t669)
  %t679 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t671, 1
  store { i64, ptr } %t680, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb150
bb86:
  %t682 = load ptr, ptr %l1, !tbaa !29
  store ptr %t682, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t683 = load ptr, ptr %l190, !tbaa !29
  %t684 = icmp ne ptr %t683, null
  br i1 %t684, label %bb87, label %bb88
bb87:
  %t686 = load ptr, ptr %l190, !tbaa !29
  %t687 = load i64, ptr %t686, !range !{i64 0, i64 18}
  %t689 = icmp eq i64 %t687, 10
  store i1 %t689, ptr %l191, !tbaa !21
  br label %bb88
bb88:
  %t690 = load i1, ptr %l191, !tbaa !21
  br i1 %t690, label %bb89, label %bb90
bb89:
  %t691 = load ptr, ptr %l1, !tbaa !29
  %t693 = getelementptr { i64, [5 x i64] }, ptr %t691, i32 0, i32 1
  %t694 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t693, i32 0, i32 2
  %t695 = load ptr, ptr %t694
  store ptr %t695, ptr %l17, !tbaa !29
  br label %bb91
bb90:
  br label %bb95
bb91:
  store %olang.scope zeroinitializer, ptr %s27
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t698 = load ptr, ptr %l17, !tbaa !29
  %t700 = getelementptr %"compiler/typed:Slice", ptr %t698, i32 0, i32 0
  %t701 = load ptr, ptr %t700, !tbaa !29
  %t704 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s27, ptr %t697, ptr %t701)
  store { i64, ptr } %t704, ptr %l199
  br label %bb92
bb92:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load ptr, ptr %l17, !tbaa !29
  %t708 = getelementptr %"compiler/typed:Slice", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t713 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t705, ptr %t709)
  store { i64, ptr } %t713, ptr %l204
  br label %bb93
bb93:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t715 = load ptr, ptr %l17, !tbaa !29
  %t717 = getelementptr %"compiler/typed:Slice", ptr %t715, i32 0, i32 2
  %t718 = load ptr, ptr %t717, !tbaa !29
  %t722 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t714, ptr %t718)
  store { i64, ptr } %t722, ptr %l209
  br label %bb94
bb94:
  %t723 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t724 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t725 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t725, 1
  %t727 = extractvalue { i64, ptr } %t725, 0
  %t728 = add i64 %t724, %t727
  %t729 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t730 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t731 = add i64 %t728, %t730
  %t732 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t732, 1
  %t734 = extractvalue { i64, ptr } %t732, 0
  %t735 = add i64 %t731, %t734
  %t736 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t737 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t738 = add i64 %t735, %t737
  %t739 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 1
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = add i64 %t738, %t741
  %t743 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t744 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t745 = add i64 %t742, %t744
  %t746 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t745)
  call void @olang_textcopy(ptr %t746, ptr %t723, i64 %t724)
  %t747 = getelementptr i8, ptr %t746, i64 %t724
  call void @olang_textcopy(ptr %t747, ptr %t726, i64 %t727)
  %t748 = getelementptr i8, ptr %t747, i64 %t727
  call void @olang_textcopy(ptr %t748, ptr %t729, i64 %t730)
  %t749 = getelementptr i8, ptr %t748, i64 %t730
  call void @olang_textcopy(ptr %t749, ptr %t733, i64 %t734)
  %t750 = getelementptr i8, ptr %t749, i64 %t734
  call void @olang_textcopy(ptr %t750, ptr %t736, i64 %t737)
  %t751 = getelementptr i8, ptr %t750, i64 %t737
  call void @olang_textcopy(ptr %t751, ptr %t740, i64 %t741)
  %t752 = getelementptr i8, ptr %t751, i64 %t741
  call void @olang_textcopy(ptr %t752, ptr %t743, i64 %t744)
  %t753 = insertvalue { i64, ptr } undef, i64 %t745, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t746, 1
  store { i64, ptr } %t754, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  br label %bb150
bb95:
  %t756 = load ptr, ptr %l1, !tbaa !29
  store ptr %t756, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t757 = load ptr, ptr %l211, !tbaa !29
  %t758 = icmp ne ptr %t757, null
  br i1 %t758, label %bb96, label %bb97
bb96:
  %t760 = load ptr, ptr %l211, !tbaa !29
  %t761 = load i64, ptr %t760, !range !{i64 0, i64 18}
  %t763 = icmp eq i64 %t761, 11
  store i1 %t763, ptr %l212, !tbaa !21
  br label %bb97
bb97:
  %t764 = load i1, ptr %l212, !tbaa !21
  br i1 %t764, label %bb98, label %bb99
bb98:
  %t765 = load ptr, ptr %l1, !tbaa !29
  %t767 = getelementptr { i64, [5 x i64] }, ptr %t765, i32 0, i32 1
  %t768 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t767, i32 0, i32 2
  %t769 = load ptr, ptr %t768
  store ptr %t769, ptr %l18, !tbaa !29
  br label %bb100
bb99:
  br label %bb104
bb100:
  store %olang.scope zeroinitializer, ptr %s29
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t772 = load ptr, ptr %l18, !tbaa !29
  %t774 = getelementptr %"compiler/typed:Cond", ptr %t772, i32 0, i32 0
  %t775 = load ptr, ptr %t774, !tbaa !29
  %t779 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t771, ptr %t775)
  store { i64, ptr } %t779, ptr %l221
  br label %bb101
bb101:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load ptr, ptr %l18, !tbaa !29
  %t783 = getelementptr %"compiler/typed:Cond", ptr %t781, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !29
  %t787 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t780, ptr %t784)
  store { i64, ptr } %t787, ptr %l225
  br label %bb102
bb102:
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load ptr, ptr %l18, !tbaa !29
  %t791 = getelementptr %"compiler/typed:Cond", ptr %t789, i32 0, i32 2
  %t792 = load ptr, ptr %t791, !tbaa !29
  %t796 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t788, ptr %t792)
  store { i64, ptr } %t796, ptr %l230
  br label %bb103
bb103:
  %t797 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t798 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t799 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 1
  %t801 = extractvalue { i64, ptr } %t799, 0
  %t802 = add i64 %t798, %t801
  %t803 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t804 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t805 = add i64 %t802, %t804
  %t806 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t807 = extractvalue { i64, ptr } %t806, 1
  %t808 = extractvalue { i64, ptr } %t806, 0
  %t809 = add i64 %t805, %t808
  %t810 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t811 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t812 = add i64 %t809, %t811
  %t813 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t813, 1
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t816 = add i64 %t812, %t815
  %t817 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t818 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t819 = add i64 %t816, %t818
  %t820 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t819)
  call void @olang_textcopy(ptr %t820, ptr %t797, i64 %t798)
  %t821 = getelementptr i8, ptr %t820, i64 %t798
  call void @olang_textcopy(ptr %t821, ptr %t800, i64 %t801)
  %t822 = getelementptr i8, ptr %t821, i64 %t801
  call void @olang_textcopy(ptr %t822, ptr %t803, i64 %t804)
  %t823 = getelementptr i8, ptr %t822, i64 %t804
  call void @olang_textcopy(ptr %t823, ptr %t807, i64 %t808)
  %t824 = getelementptr i8, ptr %t823, i64 %t808
  call void @olang_textcopy(ptr %t824, ptr %t810, i64 %t811)
  %t825 = getelementptr i8, ptr %t824, i64 %t811
  call void @olang_textcopy(ptr %t825, ptr %t814, i64 %t815)
  %t826 = getelementptr i8, ptr %t825, i64 %t815
  call void @olang_textcopy(ptr %t826, ptr %t817, i64 %t818)
  %t827 = insertvalue { i64, ptr } undef, i64 %t819, 0
  %t828 = insertvalue { i64, ptr } %t827, ptr %t820, 1
  store { i64, ptr } %t828, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s29)
  br label %bb150
bb104:
  %t830 = load ptr, ptr %l1, !tbaa !29
  store ptr %t830, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t831 = load ptr, ptr %l232, !tbaa !29
  %t832 = icmp ne ptr %t831, null
  br i1 %t832, label %bb105, label %bb106
bb105:
  %t834 = load ptr, ptr %l232, !tbaa !29
  %t835 = load i64, ptr %t834, !range !{i64 0, i64 18}
  %t837 = icmp eq i64 %t835, 12
  store i1 %t837, ptr %l233, !tbaa !21
  br label %bb106
bb106:
  %t838 = load i1, ptr %l233, !tbaa !21
  br i1 %t838, label %bb107, label %bb108
bb107:
  %t839 = load ptr, ptr %l1, !tbaa !29
  %t841 = getelementptr { i64, [5 x i64] }, ptr %t839, i32 0, i32 1
  %t842 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t841, i32 0, i32 2
  %t843 = load ptr, ptr %t842
  store ptr %t843, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  store %olang.scope zeroinitializer, ptr %s31
  %t845 = load ptr, ptr %l19, !tbaa !29
  %t847 = getelementptr %"compiler/typed:Seq", ptr %t845, i32 0, i32 0
  %t848 = load { i64, ptr }, ptr %t847, !tbaa !27
  %t850 = extractvalue { i64, ptr } %t848, 0
  store i64 %t850, ptr %l240, !tbaa !24
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t852 = load ptr, ptr %l19, !tbaa !29
  %t854 = getelementptr %"compiler/typed:Seq", ptr %t852, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !29
  %t858 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s31, ptr %t851, ptr %t855)
  store { i64, ptr } %t858, ptr %l244
  br label %bb110
bb110:
  %t859 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t860 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t861 = load i64, ptr %l240, !tbaa !24
  %t862 = call i64 @__olang_fmt_i64(ptr null, i64 %t861)
  %t863 = add i64 %t860, %t862
  %t864 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t865 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t866 = add i64 %t863, %t865
  %t867 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 1
  %t869 = extractvalue { i64, ptr } %t867, 0
  %t870 = add i64 %t866, %t869
  %t871 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t872 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t873 = add i64 %t870, %t872
  %t874 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t873)
  call void @olang_textcopy(ptr %t874, ptr %t859, i64 %t860)
  %t875 = getelementptr i8, ptr %t874, i64 %t860
  %t876 = call i64 @__olang_fmt_i64(ptr %t875, i64 %t861)
  %t877 = getelementptr i8, ptr %t875, i64 %t862
  call void @olang_textcopy(ptr %t877, ptr %t864, i64 %t865)
  %t878 = getelementptr i8, ptr %t877, i64 %t865
  call void @olang_textcopy(ptr %t878, ptr %t868, i64 %t869)
  %t879 = getelementptr i8, ptr %t878, i64 %t869
  call void @olang_textcopy(ptr %t879, ptr %t871, i64 %t872)
  %t880 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t874, 1
  store { i64, ptr } %t881, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s31)
  br label %bb150
bb111:
  %t883 = load ptr, ptr %l1, !tbaa !29
  store ptr %t883, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t884 = load ptr, ptr %l246, !tbaa !29
  %t885 = icmp ne ptr %t884, null
  br i1 %t885, label %bb112, label %bb113
bb112:
  %t887 = load ptr, ptr %l246, !tbaa !29
  %t888 = load i64, ptr %t887, !range !{i64 0, i64 18}
  %t890 = icmp eq i64 %t888, 13
  store i1 %t890, ptr %l247, !tbaa !21
  br label %bb113
bb113:
  %t891 = load i1, ptr %l247, !tbaa !21
  br i1 %t891, label %bb114, label %bb115
bb114:
  %t892 = load ptr, ptr %l1, !tbaa !29
  %t894 = getelementptr { i64, [5 x i64] }, ptr %t892, i32 0, i32 1
  %t895 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t894, i32 0, i32 2
  %t896 = load ptr, ptr %t895
  store ptr %t896, ptr %l20, !tbaa !29
  br label %bb116
bb115:
  br label %bb123
bb116:
  %t898 = load ptr, ptr %l20, !tbaa !29
  %t900 = getelementptr %"compiler/typed:Match", ptr %t898, i32 0, i32 1
  %t901 = load { i64, ptr }, ptr %t900, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t901, 0
  store i64 %t903, ptr %l254, !tbaa !24
  %t904 = load ptr, ptr %l20, !tbaa !29
  %t906 = getelementptr %"compiler/typed:Match", ptr %t904, i32 0, i32 2
  %t907 = load ptr, ptr %t906, !tbaa !29
  %t909 = icmp eq ptr %t907, null
  br i1 %t909, label %bb117, label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb118:
  br label %bb119
bb119:
  %t911 = load ptr, ptr %l20, !tbaa !29
  %t913 = getelementptr %"compiler/typed:Match", ptr %t911, i32 0, i32 2
  %t914 = load ptr, ptr %t913, !tbaa !29
  %t917 = getelementptr %"compiler/typed:Arm", ptr %t914, i32 0, i32 3
  %t918 = load ptr, ptr %t917, !tbaa !29
  store ptr %t918, ptr %l21, !tbaa !29
  %t920 = load ptr, ptr %l21, !tbaa !29
  %t922 = icmp eq ptr %t920, null
  br i1 %t922, label %bb120, label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb121:
  br label %bb122
bb122:
  %t924 = load ptr, ptr %l21, !tbaa !29
  %t927 = getelementptr %"compiler/typed:Block", ptr %t924, i32 0, i32 1
  %t928 = load { i64, ptr }, ptr %t927, !tbaa !27
  %t930 = extractvalue { i64, ptr } %t928, 0
  %t931 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t932 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t933 = load i64, ptr %l254, !tbaa !24
  %t934 = call i64 @__olang_fmt_i64(ptr null, i64 %t933)
  %t935 = add i64 %t932, %t934
  %t936 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t937 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t938 = add i64 %t935, %t937
  %t940 = call i64 @__olang_fmt_i64(ptr null, i64 %t930)
  %t941 = add i64 %t938, %t940
  %t942 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t943 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t944 = add i64 %t941, %t943
  %t945 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t944)
  call void @olang_textcopy(ptr %t945, ptr %t931, i64 %t932)
  %t946 = getelementptr i8, ptr %t945, i64 %t932
  %t947 = call i64 @__olang_fmt_i64(ptr %t946, i64 %t933)
  %t948 = getelementptr i8, ptr %t946, i64 %t934
  call void @olang_textcopy(ptr %t948, ptr %t936, i64 %t937)
  %t949 = getelementptr i8, ptr %t948, i64 %t937
  %t950 = call i64 @__olang_fmt_i64(ptr %t949, i64 %t930)
  %t951 = getelementptr i8, ptr %t949, i64 %t940
  call void @olang_textcopy(ptr %t951, ptr %t942, i64 %t943)
  %t952 = insertvalue { i64, ptr } undef, i64 %t944, 0
  %t953 = insertvalue { i64, ptr } %t952, ptr %t945, 1
  store { i64, ptr } %t953, ptr %l37, !tbaa !27
  br label %bb150
bb123:
  %t955 = load ptr, ptr %l1, !tbaa !29
  store ptr %t955, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t956 = load ptr, ptr %l269, !tbaa !29
  %t957 = icmp ne ptr %t956, null
  br i1 %t957, label %bb124, label %bb125
bb124:
  %t959 = load ptr, ptr %l269, !tbaa !29
  %t960 = load i64, ptr %t959, !range !{i64 0, i64 18}
  %t962 = icmp eq i64 %t960, 14
  store i1 %t962, ptr %l270, !tbaa !21
  br label %bb125
bb125:
  %t963 = load i1, ptr %l270, !tbaa !21
  br i1 %t963, label %bb126, label %bb127
bb126:
  %t964 = load ptr, ptr %l1, !tbaa !29
  %t966 = getelementptr { i64, [5 x i64] }, ptr %t964, i32 0, i32 1
  %t967 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t966, i32 0, i32 2
  %t968 = load ptr, ptr %t967
  store ptr %t968, ptr %l22, !tbaa !29
  br label %bb128
bb127:
  br label %bb130
bb128:
  store %olang.scope zeroinitializer, ptr %s35
  %t970 = load ptr, ptr %l0, !tbaa !29
  %t971 = load ptr, ptr %l22, !tbaa !29
  %t973 = getelementptr %"compiler/typed:Try", ptr %t971, i32 0, i32 0
  %t974 = load ptr, ptr %t973, !tbaa !29
  %t977 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s35, ptr %t970, ptr %t974)
  store { i64, ptr } %t977, ptr %l278
  br label %bb129
bb129:
  %t978 = load ptr, ptr %l22, !tbaa !29
  %t980 = getelementptr %"compiler/typed:Try", ptr %t978, i32 0, i32 1
  %t981 = load { i64, ptr }, ptr %t980, !tbaa !27
  %t983 = extractvalue { i64, ptr } %t981, 0
  %t984 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t985 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t986 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t987 = extractvalue { i64, ptr } %t986, 1
  %t988 = extractvalue { i64, ptr } %t986, 0
  %t989 = add i64 %t985, %t988
  %t990 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t991 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t992 = add i64 %t989, %t991
  %t994 = call i64 @__olang_fmt_i64(ptr null, i64 %t983)
  %t995 = add i64 %t992, %t994
  %t996 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t997 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t998 = add i64 %t995, %t997
  %t999 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t998)
  call void @olang_textcopy(ptr %t999, ptr %t984, i64 %t985)
  %t1000 = getelementptr i8, ptr %t999, i64 %t985
  call void @olang_textcopy(ptr %t1000, ptr %t987, i64 %t988)
  %t1001 = getelementptr i8, ptr %t1000, i64 %t988
  call void @olang_textcopy(ptr %t1001, ptr %t990, i64 %t991)
  %t1002 = getelementptr i8, ptr %t1001, i64 %t991
  %t1003 = call i64 @__olang_fmt_i64(ptr %t1002, i64 %t983)
  %t1004 = getelementptr i8, ptr %t1002, i64 %t994
  call void @olang_textcopy(ptr %t1004, ptr %t996, i64 %t997)
  %t1005 = insertvalue { i64, ptr } undef, i64 %t998, 0
  %t1006 = insertvalue { i64, ptr } %t1005, ptr %t999, 1
  store { i64, ptr } %t1006, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s35)
  br label %bb150
bb130:
  %t1008 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1008, ptr %l283, !tbaa !29
  store i1 false, ptr %l284, !tbaa !21
  %t1009 = load ptr, ptr %l283, !tbaa !29
  %t1010 = icmp ne ptr %t1009, null
  br i1 %t1010, label %bb131, label %bb132
bb131:
  %t1012 = load ptr, ptr %l283, !tbaa !29
  %t1013 = load i64, ptr %t1012, !range !{i64 0, i64 18}
  %t1015 = icmp eq i64 %t1013, 15
  store i1 %t1015, ptr %l284, !tbaa !21
  br label %bb132
bb132:
  %t1016 = load i1, ptr %l284, !tbaa !21
  br i1 %t1016, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t1017 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1018 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t1019 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t1021 = extractvalue { i64, ptr } %t1017, 1
  %t1022 = extractvalue { i64, ptr } %t1017, 0
  %t1023 = add i64 %t1019, %t1022
  %t1024 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t1025 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t1026 = add i64 %t1023, %t1025
  %t1027 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1026)
  call void @olang_textcopy(ptr %t1027, ptr %t1018, i64 %t1019)
  %t1028 = getelementptr i8, ptr %t1027, i64 %t1019
  call void @olang_textcopy(ptr %t1028, ptr %t1021, i64 %t1022)
  %t1029 = getelementptr i8, ptr %t1028, i64 %t1022
  call void @olang_textcopy(ptr %t1029, ptr %t1024, i64 %t1025)
  %t1030 = insertvalue { i64, ptr } undef, i64 %t1026, 0
  %t1031 = insertvalue { i64, ptr } %t1030, ptr %t1027, 1
  store { i64, ptr } %t1031, ptr %l37, !tbaa !27
  br label %bb150
bb136:
  %t1033 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1033, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t1034 = load ptr, ptr %l289, !tbaa !29
  %t1035 = icmp ne ptr %t1034, null
  br i1 %t1035, label %bb137, label %bb138
bb137:
  %t1037 = load ptr, ptr %l289, !tbaa !29
  %t1038 = load i64, ptr %t1037, !range !{i64 0, i64 18}
  %t1040 = icmp eq i64 %t1038, 16
  store i1 %t1040, ptr %l290, !tbaa !21
  br label %bb138
bb138:
  %t1041 = load i1, ptr %l290, !tbaa !21
  br i1 %t1041, label %bb139, label %bb140
bb139:
  %t1042 = load ptr, ptr %l1, !tbaa !29
  %t1044 = getelementptr { i64, [5 x i64] }, ptr %t1042, i32 0, i32 1
  %t1045 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1044, i32 0, i32 2
  %t1046 = load ptr, ptr %t1045
  store ptr %t1046, ptr %l23, !tbaa !29
  br label %bb141
bb140:
  br label %bb142
bb141:
  %t1048 = load ptr, ptr %l23, !tbaa !29
  %t1050 = getelementptr %"compiler/typed:Text", ptr %t1048, i32 0, i32 0
  %t1051 = load { i64, ptr }, ptr %t1050, !tbaa !27
  %t1053 = extractvalue { i64, ptr } %t1051, 0
  %t1054 = load ptr, ptr %l23, !tbaa !29
  %t1056 = getelementptr %"compiler/typed:Text", ptr %t1054, i32 0, i32 1
  %t1057 = load i32, ptr %t1056, !tbaa !23
  %t1058 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t1059 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t1061 = call i64 @__olang_fmt_i64(ptr null, i64 %t1053)
  %t1062 = add i64 %t1059, %t1061
  %t1063 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t1064 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t1065 = add i64 %t1062, %t1064
  %t1067 = sext i32 %t1057 to i64
  %t1068 = call i64 @__olang_fmt_i64(ptr null, i64 %t1067)
  %t1069 = add i64 %t1065, %t1068
  %t1070 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t1071 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t1072 = add i64 %t1069, %t1071
  %t1073 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1072)
  call void @olang_textcopy(ptr %t1073, ptr %t1058, i64 %t1059)
  %t1074 = getelementptr i8, ptr %t1073, i64 %t1059
  %t1075 = call i64 @__olang_fmt_i64(ptr %t1074, i64 %t1053)
  %t1076 = getelementptr i8, ptr %t1074, i64 %t1061
  call void @olang_textcopy(ptr %t1076, ptr %t1063, i64 %t1064)
  %t1077 = getelementptr i8, ptr %t1076, i64 %t1064
  %t1078 = call i64 @__olang_fmt_i64(ptr %t1077, i64 %t1067)
  %t1079 = getelementptr i8, ptr %t1077, i64 %t1068
  call void @olang_textcopy(ptr %t1079, ptr %t1070, i64 %t1071)
  %t1080 = insertvalue { i64, ptr } undef, i64 %t1072, 0
  %t1081 = insertvalue { i64, ptr } %t1080, ptr %t1073, 1
  store { i64, ptr } %t1081, ptr %l37, !tbaa !27
  br label %bb150
bb142:
  %t1083 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1083, ptr %l301, !tbaa !29
  store i1 false, ptr %l302, !tbaa !21
  %t1084 = load ptr, ptr %l301, !tbaa !29
  %t1085 = icmp ne ptr %t1084, null
  br i1 %t1085, label %bb143, label %bb144
bb143:
  %t1087 = load ptr, ptr %l301, !tbaa !29
  %t1088 = load i64, ptr %t1087, !range !{i64 0, i64 18}
  %t1090 = icmp eq i64 %t1088, 17
  store i1 %t1090, ptr %l302, !tbaa !21
  br label %bb144
bb144:
  %t1091 = load i1, ptr %l302, !tbaa !21
  br i1 %t1091, label %bb145, label %bb146
bb145:
  %t1092 = load ptr, ptr %l1, !tbaa !29
  %t1094 = getelementptr { i64, [5 x i64] }, ptr %t1092, i32 0, i32 1
  %t1095 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1094, i32 0, i32 1
  %t1096 = load i64, ptr %t1095
  store i64 %t1096, ptr %l24, !tbaa !24
  %t1098 = load ptr, ptr %l1, !tbaa !29
  %t1100 = getelementptr { i64, [5 x i64] }, ptr %t1098, i32 0, i32 1
  %t1101 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1100, i32 0, i32 2
  %t1102 = load ptr, ptr %t1101
  store ptr %t1102, ptr %l25, !tbaa !29
  br label %bb147
bb146:
  br label %bb149
bb147:
  store %olang.scope zeroinitializer, ptr %s41
  %t1104 = load i64, ptr %l24, !tbaa !24
  store i64 %t1104, ptr %l309, !tbaa !24
  %t1105 = load ptr, ptr %l0, !tbaa !29
  %t1106 = load ptr, ptr %l25, !tbaa !29
  %t1110 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s41, ptr %t1105, ptr %t1106)
  store { i64, ptr } %t1110, ptr %l313
  br label %bb148
bb148:
  %t1111 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t1112 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t1113 = load i64, ptr %l309, !tbaa !24
  %t1114 = call i64 @__olang_fmt_i64(ptr null, i64 %t1113)
  %t1115 = add i64 %t1112, %t1114
  %t1116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t1117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t1118 = add i64 %t1115, %t1117
  %t1119 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t1120 = extractvalue { i64, ptr } %t1119, 1
  %t1121 = extractvalue { i64, ptr } %t1119, 0
  %t1122 = add i64 %t1118, %t1121
  %t1123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t1125 = add i64 %t1122, %t1124
  %t1126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1125)
  call void @olang_textcopy(ptr %t1126, ptr %t1111, i64 %t1112)
  %t1127 = getelementptr i8, ptr %t1126, i64 %t1112
  %t1128 = call i64 @__olang_fmt_i64(ptr %t1127, i64 %t1113)
  %t1129 = getelementptr i8, ptr %t1127, i64 %t1114
  call void @olang_textcopy(ptr %t1129, ptr %t1116, i64 %t1117)
  %t1130 = getelementptr i8, ptr %t1129, i64 %t1117
  call void @olang_textcopy(ptr %t1130, ptr %t1120, i64 %t1121)
  %t1131 = getelementptr i8, ptr %t1130, i64 %t1121
  call void @olang_textcopy(ptr %t1131, ptr %t1123, i64 %t1124)
  %t1132 = insertvalue { i64, ptr } undef, i64 %t1125, 0
  %t1133 = insertvalue { i64, ptr } %t1132, ptr %t1126, 1
  store { i64, ptr } %t1133, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s41)
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a387a9465b9f2118_49b9af8105801174)
  unreachable
bb150:
  call void @__olang_scope_close(ptr %s0)
  %t1135 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t88, ptr %t89)
  store { i64, ptr } %t93, ptr %l41
  br label %bb18
bb18:
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l43, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l44, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t122, i32 0, i32 3
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %t126, ptr %t127)
  store { i64, ptr } %t130, ptr %l53
  br label %bb25
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t131)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  store { i64, ptr } %t146, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t149 = load ptr, ptr %l56, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l56, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l57, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Elem", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t163, ptr %t167)
  store { i64, ptr } %t170, ptr %l65
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t171, ptr %t175)
  store { i64, ptr } %t179, ptr %l70
  br label %bb33
bb33:
  %t180 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t181, i64 %t182)
  %t194 = getelementptr i8, ptr %t193, i64 %t182
  call void @olang_textcopy(ptr %t194, ptr %t183, i64 %t184)
  %t195 = getelementptr i8, ptr %t194, i64 %t184
  call void @olang_textcopy(ptr %t195, ptr %t187, i64 %t188)
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t201 = load ptr, ptr %l72, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = load ptr, ptr %l72, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t208 = load i1, ptr %l73, !tbaa !21
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Payload", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t215, ptr %t219)
  store { i64, ptr } %t222, ptr %l81
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Payload", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t226)
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = getelementptr i8, ptr %t236, i64 %t229
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t226)
  %t240 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t236, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t244 = load ptr, ptr %l85, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb42, label %bb43
bb42:
  %t247 = load ptr, ptr %l85, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 8}
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t251 = load i1, ptr %l86, !tbaa !21
  br i1 %t251, label %bb44, label %bb45
bb44:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l10, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t260, i32 0, i32 3
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l10, !tbaa !29
  %t269 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t264, ptr %t265)
  store { i64, ptr } %t269, ptr %l96
  br label %bb47
bb47:
  %t270 = load i32, ptr %l11, !tbaa !23
  %t271 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t273 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t281 = sext i32 %t270 to i64
  %t282 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t283 = add i64 %t279, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = getelementptr i8, ptr %t285, i64 %t275
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t281)
  %t289 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t284, 1
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t293 = load ptr, ptr %l99, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb49, label %bb50
bb49:
  %t296 = load ptr, ptr %l99, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 8}
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t300 = load i1, ptr %l100, !tbaa !21
  br i1 %t300, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_16612f18a9afa54d_299c1e15a68a5059)
  unreachable
bb55:
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l105, !tbaa !24
  %t305 = load i64, ptr %l105, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l106, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l105, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t316, ptr %l12, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  br label %bb20
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 3}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t41)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  br label %bb20
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t54 = load ptr, ptr %l22, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 3}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l23, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { { i64, ptr } }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l29
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l4, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_411550143d3b0e9d_42067e02948bd729)
  unreachable
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 5}
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Make", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store ptr %a0, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 0
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load i32, ptr %l26, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t52, i32 %t53, i32 %t51)
  store i1 %t55, ptr %l28
  br label %bb12
bb12:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t57 = load i1, ptr %l21, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Make", ptr %t58, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l31, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l29, !tbaa !29
  br label %bb16
bb15:
  store ptr null, ptr %l29, !tbaa !29
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l29, !tbaa !29
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb32
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t70 = load ptr, ptr %l34, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l34, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 2
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 10
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8a62bacdff20949b_383b5959755ced57)
  unreachable
bb32:
  %t90 = load ptr, ptr %l4, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ftyped_2efnBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l26 = alloca { i64, ptr }
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 3}
  %t18 = icmp eq i64 %t16, 1
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t40, ptr %l26, !tbaa !27
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t50 = getelementptr %"compiler/typed:Capture", ptr %t46, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t51, i32 %t53)
  store i1 %t56, ptr %l33
  br label %bb16
bb16:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb12
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 3}
  %t71 = icmp eq i64 %t69, 2
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb25, label %bb26
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { i32, ptr, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l47
  br label %bb28
bb28:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ftyped_2efreshCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 6
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l8, !tbaa !29
  br label %bb28
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Promote", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t43, 1
  %t48 = call ptr @compiler_2ftyped_2efreshCall(ptr %v0, ptr %v1, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l27
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l27, !tbaa !29
  store ptr %t49, ptr %l8, !tbaa !29
  br label %bb28
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  %t71 = call ptr @compiler_2ftyped_2efreshCall(ptr %v0, ptr %v1, ptr %t65, i64 %t68)
  store ptr %t71, ptr %l37
  br label %bb22
bb22:
  %t72 = load ptr, ptr %l37, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store ptr null, ptr %l8, !tbaa !29
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7b5addefd2146e51_66c2395e3e23d40d)
  unreachable
bb28:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l22
  br label %bb8
bb8:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = call ptr @compiler_2ftyped_2ewithin(ptr %v0, ptr %v0, ptr %t37)
  store ptr %t39, ptr %l25
  br label %bb11
bb11:
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t43 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t41, %"compiler/source:Span" %t40)
  store i1 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb4
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb6
bb5:
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = or i64 %t10, %t11
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2epiecesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t45, i32 %a1)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/typed:leaveWalk"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca i64
  %l40 = alloca i64
  %l41 = alloca %"compiler/typed:leaveWalk"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  store i1 %t35, ptr %l24
  br label %bb8
bb8:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i64 1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = call ptr @compiler_2ftyped_2ewithin(ptr %v0, ptr %v0, ptr %t38)
  store ptr %t40, ptr %l27
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l27, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t48, %"compiler/source:Span" %t50)
  store i64 %t53, ptr %l35
  br label %bb15
bb14:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = icmp ne i64 %t54, 0
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t63 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %t58, %"compiler/source:Span" %t60)
  store i64 %t63, ptr %l40
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  %t64 = load i64, ptr %l40, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = call %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %s3)
  store %"compiler/typed:leaveWalk" %t65, ptr %l41
  br label %bb21
bb21:
  %t66 = load %"compiler/typed:leaveWalk", ptr %l41
  store %"compiler/typed:leaveWalk" %t66, ptr %l7
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %s3, ptr %v0, ptr %l7, ptr %t67)
  store i1 %t70, ptr %l44
  br label %bb22
bb22:
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call i1 @compiler_2ftyped_2eholds(ptr %v0, ptr %t72, %"compiler/source:Span" %t74)
  store i1 %t77, ptr %l48
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t78 = load i1, ptr %l48, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb4
bb31:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t16 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t18 = trunc i64 3 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  %t21 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t26 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t28 = trunc i64 5 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t33 = trunc i64 6 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t36 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t38 = trunc i64 7 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb37
bb18:
  %t46 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t48 = trunc i64 9 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb19, label %bb20
bb19:
  br label %bb31
bb20:
  %t51 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t53 = trunc i64 10 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t56 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t58 = trunc i64 11 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  %t61 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t63 = trunc i64 12 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t68 = trunc i64 13 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t73 = trunc i64 14 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4231ae67b136756b_a4f71f39f0a47447)
  unreachable
bb37:
  %t76 = load i1, ptr %l8, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2estmtBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca ptr
  %l196 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 2}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 2}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l29, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb137
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l33, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 17}
  %t41 = icmp eq i64 %t39, 0
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l34, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb22
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l40, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l4, !tbaa !29
  br label %bb22
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t65 = load ptr, ptr %l45, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 17}
  %t71 = icmp eq i64 %t69, 15
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l46, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load i1, ptr %l54, !tbaa !21
  store i1 %t85, ptr %l18, !tbaa !21
  br label %bb137
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t87 = load ptr, ptr %l55, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l65
  br label %bb30
bb30:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb34
bb32:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t113, i32 %t115)
  store i1 %t118, ptr %l70
  br label %bb33
bb33:
  %t119 = load i1, ptr %l70, !tbaa !21
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l66, !tbaa !21
  store i1 %t120, ptr %l18, !tbaa !21
  br label %bb137
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t122 = load ptr, ptr %l71, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 17}
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t129 = load i1, ptr %l72, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb50
bb40:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t139, i32 %t141)
  store i1 %t144, ptr %l81
  br label %bb41
bb41:
  %t145 = load i1, ptr %l81, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb45
bb43:
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = load i32, ptr %l1, !tbaa !23
  %t154 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t149, i32 %t151)
  store i1 %t154, ptr %l87
  br label %bb44
bb44:
  %t155 = load i1, ptr %l87, !tbaa !21
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l82, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb49
bb47:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:If", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l92
  br label %bb48
bb48:
  %t165 = load i1, ptr %l92, !tbaa !21
  store i1 %t165, ptr %l88, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l88, !tbaa !21
  store i1 %t166, ptr %l18, !tbaa !21
  br label %bb137
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l94, !tbaa !21
  br label %bb52
bb52:
  %t175 = load i1, ptr %l94, !tbaa !21
  br i1 %t175, label %bb53, label %bb54
bb53:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load i32, ptr %l1, !tbaa !23
  %t193 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t190)
  store i1 %t193, ptr %l104
  br label %bb56
bb56:
  %t194 = load i1, ptr %l104, !tbaa !21
  br i1 %t194, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb60
bb58:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t195, i32 %t196)
  store i1 %t199, ptr %l108
  br label %bb59
bb59:
  %t200 = load i1, ptr %l108, !tbaa !21
  store i1 %t200, ptr %l105, !tbaa !21
  br label %bb60
bb60:
  %t201 = load i1, ptr %l105, !tbaa !21
  store i1 %t201, ptr %l18, !tbaa !21
  br label %bb137
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb62, label %bb63
bb62:
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 6
  store i1 %t209, ptr %l110, !tbaa !21
  br label %bb63
bb63:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb70
bb65:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t218 = load ptr, ptr %l115, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t221 = load ptr, ptr %l115, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 16
  store i1 %t224, ptr %l116, !tbaa !21
  br label %bb67
bb67:
  %t225 = load i1, ptr %l116, !tbaa !21
  br i1 %t225, label %bb68, label %bb69
bb68:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t232 = load ptr, ptr %l10, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l123
  br label %bb71
bb71:
  %t237 = load i1, ptr %l123, !tbaa !21
  store i1 %t237, ptr %l18, !tbaa !21
  br label %bb137
bb72:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t239 = load ptr, ptr %l124, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb73, label %bb74
bb73:
  %t242 = load ptr, ptr %l124, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 17}
  %t245 = icmp eq i64 %t243, 7
  store i1 %t245, ptr %l125, !tbaa !21
  br label %bb74
bb74:
  %t246 = load i1, ptr %l125, !tbaa !21
  br i1 %t246, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb137
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t248 = load ptr, ptr %l128, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l128, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 8
  store i1 %t254, ptr %l129, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l129, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = load i32, ptr %l1, !tbaa !23
  %t267 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t262, i32 %t264)
  store i1 %t267, ptr %l137
  br label %bb84
bb84:
  %t268 = load i1, ptr %l137, !tbaa !21
  store i1 %t268, ptr %l18, !tbaa !21
  br label %bb137
bb85:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t270 = load ptr, ptr %l138, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb86, label %bb87
bb86:
  %t273 = load ptr, ptr %l138, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 17}
  %t276 = icmp eq i64 %t274, 9
  store i1 %t276, ptr %l139, !tbaa !21
  br label %bb87
bb87:
  %t277 = load i1, ptr %l139, !tbaa !21
  br i1 %t277, label %bb88, label %bb89
bb88:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t284, i32 %t285)
  store i1 %t288, ptr %l146
  br label %bb91
bb91:
  %t289 = load i1, ptr %l146, !tbaa !21
  store i1 %t289, ptr %l18, !tbaa !21
  br label %bb137
bb92:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t291 = load ptr, ptr %l147, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb93, label %bb94
bb93:
  %t294 = load ptr, ptr %l147, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 17}
  %t297 = icmp eq i64 %t295, 10
  store i1 %t297, ptr %l148, !tbaa !21
  br label %bb94
bb94:
  %t298 = load i1, ptr %l148, !tbaa !21
  br i1 %t298, label %bb95, label %bb96
bb95:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t301, i32 0, i32 1
  %t303 = load ptr, ptr %t302
  store ptr %t303, ptr %l13, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb103
bb97:
  %t311 = load ptr, ptr %l13, !tbaa !29
  %t313 = load i32, ptr %l1, !tbaa !23
  %t316 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t311, i32 %t313)
  store i1 %t316, ptr %l158
  br label %bb98
bb98:
  %t317 = load i1, ptr %l158, !tbaa !21
  br i1 %t317, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb102
bb100:
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t319 = load i32, ptr %l1, !tbaa !23
  %t322 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t318, i32 %t319)
  store i1 %t322, ptr %l162
  br label %bb101
bb101:
  %t323 = load i1, ptr %l162, !tbaa !21
  store i1 %t323, ptr %l159, !tbaa !21
  br label %bb102
bb102:
  %t324 = load i1, ptr %l159, !tbaa !21
  store i1 %t324, ptr %l18, !tbaa !21
  br label %bb137
bb103:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb104, label %bb105
bb104:
  %t329 = load ptr, ptr %l163, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 17}
  %t332 = icmp eq i64 %t330, 11
  store i1 %t332, ptr %l164, !tbaa !21
  br label %bb105
bb105:
  %t333 = load i1, ptr %l164, !tbaa !21
  br i1 %t333, label %bb106, label %bb107
bb106:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr }, ptr %t336, i32 0, i32 1
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l15, !tbaa !29
  br label %bb112
bb107:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t341 = load ptr, ptr %l169, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb108, label %bb109
bb108:
  %t344 = load ptr, ptr %l169, !tbaa !29
  %t345 = load i64, ptr %t344, !range !{i64 0, i64 17}
  %t347 = icmp eq i64 %t345, 12
  store i1 %t347, ptr %l170, !tbaa !21
  br label %bb109
bb109:
  %t348 = load i1, ptr %l170, !tbaa !21
  br i1 %t348, label %bb110, label %bb111
bb110:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", ptr }, ptr %t351, i32 0, i32 1
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l15, !tbaa !29
  br label %bb112
bb111:
  br label %bb114
bb112:
  %t355 = load ptr, ptr %l15, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t360 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t355, i32 %t357)
  store i1 %t360, ptr %l178
  br label %bb113
bb113:
  %t361 = load i1, ptr %l178, !tbaa !21
  store i1 %t361, ptr %l18, !tbaa !21
  br label %bb137
bb114:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t363 = load ptr, ptr %l179, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb115, label %bb116
bb115:
  %t366 = load ptr, ptr %l179, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 17}
  %t369 = icmp eq i64 %t367, 13
  store i1 %t369, ptr %l180, !tbaa !21
  br label %bb116
bb116:
  %t370 = load i1, ptr %l180, !tbaa !21
  br i1 %t370, label %bb117, label %bb118
bb117:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr }, ptr %t373, i32 0, i32 1
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l16, !tbaa !29
  br label %bb119
bb118:
  br label %bb125
bb119:
  %t377 = load ptr, ptr %l16, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Join", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = load i32, ptr %l1, !tbaa !23
  %t385 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t380, i32 %t382)
  store i1 %t385, ptr %l189
  br label %bb120
bb120:
  %t386 = load i1, ptr %l189, !tbaa !21
  br i1 %t386, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb124
bb122:
  %t387 = load ptr, ptr %l16, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Join", ptr %t387, i32 0, i32 2
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %t390, i32 %t391)
  store i1 %t394, ptr %l194
  br label %bb123
bb123:
  %t395 = load i1, ptr %l194, !tbaa !21
  store i1 %t395, ptr %l190, !tbaa !21
  br label %bb124
bb124:
  %t396 = load i1, ptr %l190, !tbaa !21
  store i1 %t396, ptr %l18, !tbaa !21
  br label %bb137
bb125:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t398 = load ptr, ptr %l195, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb126, label %bb127
bb126:
  %t401 = load ptr, ptr %l195, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 17}
  %t404 = icmp eq i64 %t402, 14
  store i1 %t404, ptr %l196, !tbaa !21
  br label %bb127
bb127:
  %t405 = load i1, ptr %l196, !tbaa !21
  br i1 %t405, label %bb128, label %bb129
bb128:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l17, !tbaa !29
  br label %bb130
bb129:
  br label %bb136
bb130:
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Spawn", ptr %t412, i32 0, i32 0
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  %t416 = load i32, ptr %l1, !tbaa !23
  %t419 = call i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %t415, i32 %t416)
  store i1 %t419, ptr %l204
  br label %bb131
bb131:
  %t420 = load i1, ptr %l204, !tbaa !21
  br i1 %t420, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb135
bb133:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Spawn", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = load i32, ptr %l1, !tbaa !23
  %t429 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t424, i32 %t426)
  store i1 %t429, ptr %l210
  br label %bb134
bb134:
  %t430 = load i1, ptr %l210, !tbaa !21
  store i1 %t430, ptr %l205, !tbaa !21
  br label %bb135
bb135:
  %t431 = load i1, ptr %l205, !tbaa !21
  store i1 %t431, ptr %l18, !tbaa !21
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_ab0bd1a1cb525619_8191fed8583864ed)
  unreachable
bb137:
  %t432 = load i1, ptr %l18, !tbaa !21
  store i1 %t432, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2estmtBreaks(ptr %v0, ptr %t28, i32 %a1)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l2
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  %t45 = sext i32 %t41 to i64
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb10
bb9:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l17, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb23
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 17
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l33
  br label %bb17
bb17:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9bf6326dc96b231_1fb9b096f472b9bd)
  unreachable
bb23:
  %t67 = load i64, ptr %l6, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Alt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Alt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Bind"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Bind" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Bind" %t6, ptr %a1, 1
  store %"compiler/typed:Bind" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Bind", ptr %rv
  ret %"compiler/typed:Bind" %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:BlockInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %a2, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Block"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Block" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Block" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Block" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Block", ptr %rv
  ret %"compiler/typed:Block" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6) #0 {
entry:
  %rv = alloca %"compiler/typed:Clause"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %a0, 0
  %t18 = insertvalue %"compiler/typed:Clause" %t16, { i64, ptr } %a1, 1
  %t20 = insertvalue %"compiler/typed:Clause" %t18, i1 %a2, 2
  %t22 = insertvalue %"compiler/typed:Clause" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/typed:Clause" %t22, { i64, ptr } %a4, 4
  %t26 = insertvalue %"compiler/typed:Clause" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/typed:Clause" %t26, i32 %a6, 6
  store %"compiler/typed:Clause" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Elem"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %a2, 2
  store %"compiler/typed:Elem" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:If" %t10, ptr %a2, 2
  store %"compiler/typed:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:If", ptr %rv
  ret %"compiler/typed:If" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Item"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %a1, 1
  store %"compiler/typed:Item" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local void @compiler_2ftyped_3aLocalUses_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"compiler/typed:LocalUses"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l30
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l31
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l6
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l32
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l7
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l33
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l8
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l34
  br label %bb6
bb6:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l9
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l35
  br label %bb7
bb7:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l10
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l36
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l11
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l37
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l12
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l38
  br label %bb10
bb10:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l13
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l39
  br label %bb11
bb11:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l14
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l40
  br label %bb12
bb12:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l15
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l41
  br label %bb13
bb13:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l16
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l42
  br label %bb14
bb14:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l17
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l43
  br label %bb15
bb15:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l18
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l44
  br label %bb16
bb16:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l19
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l45
  br label %bb17
bb17:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l46
  br label %bb18
bb18:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l21
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l47
  br label %bb19
bb19:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l22
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l48
  br label %bb20
bb20:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l23
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l49
  br label %bb21
bb21:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  %t47 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 0
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %t47, !tbaa !29
  %t49 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 1
  %t50 = load ptr, ptr %l3, !tbaa !29
  store ptr %t50, ptr %t49, !tbaa !29
  %t51 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 2
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 3
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 4
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t55
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 5
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 6
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 7
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %t61
  %t63 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 8
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t63
  %t65 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 9
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t65
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 10
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t67
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 11
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t69
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 12
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 13
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t73
  %t75 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 14
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %t75
  %t77 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 15
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 16
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t79
  %t81 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 17
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t81
  %t83 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 18
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t83
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 19
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t85
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 20
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t87
  %t89 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 21
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t89
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t91
  %t93 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 23
  store i64 0, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/typed:LocalUses", ptr %l50, i32 0, i32 24
  store i32 0, ptr %t95, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l50, i64 704, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [1 x i64] } %a5, 5
  %t26 = insertvalue %"compiler/typed:Local" %t24, i1 false, 6
  store %"compiler/typed:Local" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %a3, 3
  store %"compiler/typed:Match" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [1 x i64] }
  %l22 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"compiler/typed:Plan"
  %t15 = alloca { i64, [1 x i64] }, align 8
  %t28 = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l13, !tbaa !24
  %t2 = load i64, ptr %l13, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l13, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb3:
  %t8 = load i64, ptr %l13, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t17 = load { i64, [1 x i64] }, ptr %t15
  store { i64, [1 x i64] } %t17, ptr %l18
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = icmp sle i64 %t21, 576460752303423487
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb7:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = mul i64 %t24, 16
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = load { i64, [1 x i64] }, ptr %l18
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t26, i64 %t32
  store { i64, [1 x i64] } %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  store i64 %a2, ptr %l22, !tbaa !24
  %t40 = load i64, ptr %l22, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb9:
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  %t50 = load i64, ptr %l25, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_879aacf2d1a22b08_c7cef0899cf1454)
  unreachable
bb11:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l6, !tbaa !27
  %t59 = load i64, ptr %l0, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_642fe669e8876d75_a0626c7162644c61)
  unreachable
bb13:
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = icmp sle i64 %t63, 1152921504606846975
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456)
  unreachable
bb15:
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = mul i64 %t66, 8
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l7, !tbaa !27
  %t72 = load i64, ptr %l0, !tbaa !24
  store i64 %t72, ptr %l32, !tbaa !24
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456)
  unreachable
bb17:
  %t76 = load i64, ptr %l32, !tbaa !24
  %t77 = icmp sle i64 %t76, 576460752303423487
  br i1 %t77, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b6c3975defd019f7_100a23f5f40f96b)
  unreachable
bb19:
  %t79 = load i64, ptr %l32, !tbaa !24
  %t80 = mul i64 %t79, 16
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l8, !tbaa !27
  %t85 = load i64, ptr %l0, !tbaa !24
  store i64 %t85, ptr %l36, !tbaa !24
  %t86 = load i64, ptr %l36, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b6c3975defd019f7_100a23f5f40f96b)
  unreachable
bb21:
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sle i64 %t89, 1152921504606846975
  br i1 %t90, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9ae088e360a77f54_f93713180ac9c008)
  unreachable
bb23:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = mul i64 %t92, 8
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l9, !tbaa !27
  %t98 = load i64, ptr %l0, !tbaa !24
  store i64 %t98, ptr %l40, !tbaa !24
  %t99 = load i64, ptr %l40, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9ae088e360a77f54_f93713180ac9c008)
  unreachable
bb25:
  %t102 = load i64, ptr %l40, !tbaa !24
  %t103 = icmp sle i64 %t102, 1152921504606846975
  br i1 %t103, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2ec6064c293cb761_d5cc4c8f21af0275)
  unreachable
bb27:
  %t105 = load i64, ptr %l40, !tbaa !24
  %t106 = mul i64 %t105, 8
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  %t111 = load i64, ptr %l0, !tbaa !24
  store i64 %t111, ptr %l44, !tbaa !24
  %t112 = load i64, ptr %l44, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_2ec6064c293cb761_d5cc4c8f21af0275)
  unreachable
bb29:
  %t115 = load i64, ptr %l44, !tbaa !24
  %t116 = icmp sle i64 %t115, 1152921504606846975
  br i1 %t116, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a)
  unreachable
bb31:
  %t118 = load i64, ptr %l44, !tbaa !24
  %t119 = mul i64 %t118, 8
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  %t124 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %l48
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a)
  unreachable
bb33:
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t126 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t129, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 2
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 3
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t133, ptr %t132, !tbaa !27
  %t134 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 4
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t135, ptr %t134, !tbaa !27
  %t136 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 5
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t137, ptr %t136, !tbaa !27
  %t138 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 6
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t139, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 7
  %t141 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t141, ptr %t140, !tbaa !27
  %t142 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 8
  %t143 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t143, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/typed:Plan", ptr %l49, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %t144
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l49, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Seq"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/typed:Seq" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Seq" %t10, i1 %a2, 2
  store %"compiler/typed:Seq" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:SiteInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Spawn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Spawn" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Spawn" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Spawn" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/typed:Spawn" %t14, i32 %a3, 3
  store %"compiler/typed:Spawn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Spawn", ptr %rv
  ret %"compiler/typed:Spawn" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Text"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %a1, 1
  store %"compiler/typed:Text" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Try"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Try" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Try" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Try" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/typed:Try" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/typed:Try" %t18, i1 %a4, 4
  store %"compiler/typed:Try" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Try", ptr %rv
  ret %"compiler/typed:Try" %rr
}

define dso_local %"compiler/typed:landLoop" @compiler_2ftyped_3alandLoop_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %rv = alloca %"compiler/typed:landLoop"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_652e3003820639e_452d7c4eea959e6a)
  unreachable
bb3:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t25 = load i32, ptr %l2, !tbaa !23
  %t26 = insertvalue %"compiler/typed:landLoop" undef, i32 %t25, 0
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = insertvalue %"compiler/typed:landLoop" %t26, i64 %t27, 1
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = insertvalue %"compiler/typed:landLoop" %t28, { i64, ptr } %t29, 2
  %t32 = insertvalue %"compiler/typed:landLoop" %t30, { i64, ptr } %t23, 3
  %t34 = insertvalue %"compiler/typed:landLoop" %t32, i1 false, 4
  %t36 = insertvalue %"compiler/typed:landLoop" %t34, i1 false, 5
  store %"compiler/typed:landLoop" %t36, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6ab171d7108733d3_fb4921eacef8293f)
  unreachable
ret:
  %rr = load %"compiler/typed:landLoop", ptr %rv
  ret %"compiler/typed:landLoop" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" locals " }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" blocks " }>, align 8
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sites" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(lit " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(data " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(read " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"(borrow " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(take " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d22 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(promote " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(call " }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 5}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(make " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(collect " }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 47}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 i64 43, label %bb45 i64 44, label %bb46 i64 45, label %bb47 i64 46, label %bb48 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
bb45:
  %t91 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t91, i64 %t92)
  br label %bb1
bb46:
  %t93 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t93, i64 %t94)
  br label %bb1
bb47:
  %t95 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t95, i64 %t96)
  br label %bb1
bb48:
  %t97 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t97, i64 %t98)
  br label %bb1
ret:
  ret void
}

define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 3}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
ret:
  ret void
}

@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d41 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(slice " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(cond " }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(seq " }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d50 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(match " }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" arms, nomatch " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(try " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" clauses)" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(fn " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(text " }>, align 8
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(away " }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tmp " }>, align 8
@.d73 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"target" }>, align 8
@.d75 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d77 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"MakeKind.Tuple" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d78 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"MakeKind.Case" }>, align 8
@.d79 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"MakeKind.Array" }>, align 8
@.d80 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"MakeKind.Fill" }>, align 8
@.d81 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"MakeKind.Copy" }>, align 8
@.d82 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Neg" }>, align 8
@.d83 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitNot" }>, align 8
@.d84 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Not" }>, align 8
@.d85 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Add" }>, align 8
@.d86 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Sub" }>, align 8
@.d87 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Mul" }>, align 8
@.d88 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Div" }>, align 8
@.d89 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Rem" }>, align 8
@.d90 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shl" }>, align 8
@.d91 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shr" }>, align 8
@.d92 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitAnd" }>, align 8
@.d93 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.BitOr" }>, align 8
@.d94 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitXor" }>, align 8
@.d95 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Eq" }>, align 8
@.d96 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ne" }>, align 8
@.d97 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Lt" }>, align 8
@.d98 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Le" }>, align 8
@.d99 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Gt" }>, align 8
@.d100 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ge" }>, align 8
@.d101 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Same" }>, align 8
@.d102 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Convert" }>, align 8
@.d103 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Bitcast" }>, align 8
@.d104 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Len" }>, align 8
@.d105 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.IsCase" }>, align 8
@.d106 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicLoad" }>, align 8
@.d107 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AtomicStore" }>, align 8
@.d108 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.AtomicAdd" }>, align 8
@.d109 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicSwap" }>, align 8
@.d110 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"PrimOp.AtomicCompareSwap" }>, align 8
@.d111 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.Retire" }>, align 8
@.d112 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Destroy" }>, align 8
@.d113 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Drop" }>, align 8
@.d114 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"PrimOp.LeadingZeros" }>, align 8
@.d115 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"PrimOp.TrailingZeros" }>, align 8
@.d116 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.PopCount" }>, align 8
@.d117 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.RotateLeft" }>, align 8
@.d118 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.RotateRight" }>, align 8
@.d119 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ByteSwap" }>, align 8
@.d120 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.Holds" }>, align 8
@.d121 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.LaneLen" }>, align 8
@.d122 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.NonEmpty" }>, align 8
@.d123 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.AnyMake" }>, align 8
@.d124 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AnyInstance" }>, align 8
@.d125 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.AnyIs" }>, align 8
@.d126 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.ErrPush" }>, align 8
@.d127 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.ErrCaught" }>, align 8
@.d128 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ErrTaken" }>, align 8
@.d129 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Check.None" }>, align 8
@.d130 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Check.Abort" }>, align 8
@.d131 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Check.Try" }>, align 8
@olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0)
@olang_loc_bf16ba0368763d37_f19ef32b132443ab = external constant [0 x i8]
@olang_loc_af65136929bfae16_48f8be4437d6c6ea = external constant [0 x i8]
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare { i64, [1 x i64] } @compiler_2ftyped_2eresultScope(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@G_2ecompiler_2ftyped_2emathNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftyped_2emathArity = available_externally constant <{ [248 x i8] }> <{ [248 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@olang_loc_62af31c5105aaa5b_ddb95177f2bf45e7 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d25bca10c486d8b4_954c3a018844fd8 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ecb034f719e18c1b_985175307bfdc34f = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_352016b8dfbaae41_4f83dc304b77dded = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_b47e7a13871964ca_e65b2c3f8690a096 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6690d985632b6de7_b13460b3c8232d4b = external constant [0 x i8]
@olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_9444a0fe500d35e5_4f818c2c3ae57dd9 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3f422f8bccda2eb4_607c7ad0cff40408 = external constant [0 x i8]
@olang_loc_90af12c8bdcc10ef_2ee3a51413a547e3 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_af04a8710b199599_1473152472f015d = external constant [0 x i8]
@olang_loc_e933c796b27591a8_e869c9717a33729c = external constant [0 x i8]
declare %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_198aad80d0550ab5_c06608159f163401 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_28655f8a56cf669d_dc60f62ebe04c639 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d36f57f073c6a2ff_232866ca740484ab = external constant [0 x i8]
@olang_loc_faea1712f2053751_ed9fc9ee56afb56d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4860703a134569c9_d00fc34d053d5355 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
@olang_loc_6ff368c26ca3ad9b_74caa00555ca222f = external constant [0 x i8]
declare ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_b9f0b2a15b6670eb_2e1d369e87bd8cdf = external constant [0 x i8]
@olang_loc_5437ab06fdd2422a_119d1d559b7fc05e = external constant [0 x i8]
@olang_loc_ef0de602c5122041_f82f60a1eb2bb195 = external constant [0 x i8]
@olang_loc_dac0899521d00a27_f5966ad5b7471ec3 = external constant [0 x i8]
@olang_loc_4d8a06dfe39d8193_a27ec756202836f = external constant [0 x i8]
@olang_loc_104aca9b23d55792_b4686871930206ae = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c33a5c6933895_a18ea8bdcccb3229 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_9a2d2471d97215b1_125b5d47933e1fad = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd = external constant [0 x i8]
@olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1 = external constant [0 x i8]
@olang_loc_e2587c8ec5c6f861_9513078f5b00021d = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c8b3a2ed155d5757_c640a14e4e3ad273 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_17c315ca28f40c4c_14b80e258f8c2b0 = external constant [0 x i8]
@olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5 = external constant [0 x i8]
@olang_loc_6fe9eb3ff5642bc1_33392e6f48613205 = external constant [0 x i8]
@olang_loc_5f1ddc7ef7469727_e10177d23ca0510b = external constant [0 x i8]
@olang_loc_24a3ccdd47c97c70_8558c77bc7af118c = external constant [0 x i8]
@olang_loc_130a89b2782f12a5_38e9334e27b56d91 = external constant [0 x i8]
@olang_loc_1916e27cc0da8fc5_b948d7408e366d01 = external constant [0 x i8]
@olang_loc_567e5689d7ac5ccb_d57870be630e767 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e0d071190e38de5d_291e4ea72946f179 = external constant [0 x i8]
@olang_loc_d40841e1665d5bac_305352f22a4532a8 = external constant [0 x i8]
@olang_loc_9f9fe097503cda9_c6b719cc2534ac35 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f5a8870640a369c_e3a704984aad8c8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eLen_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eAt_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c533040496e87321_52fb908a3762307d = external constant [0 x i8]
@olang_loc_c1faed4ae36d3640_1d7aa47a4727493c = external constant [0 x i8]
@olang_loc_2cf1608fd5d1230c_1374e48cd144e348 = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_73be6a0e490978a7_b5fa18d3e7eede33 = external constant [0 x i8]
@olang_loc_2fb6091d652311b2_1c71a9a414fce87e = external constant [0 x i8]
@olang_loc_8c1b8241682c8a5c_1491e83e9da6f28 = external constant [0 x i8]
@olang_loc_4fc9df9522ae1330_697d53c50db00ce4 = external constant [0 x i8]
@olang_loc_e4195c8d52320dab_6e5abcaf8844f88f = external constant [0 x i8]
@olang_loc_6df7d27e20fc18e6_9af88db0bee394aa = external constant [0 x i8]
@olang_loc_c52364142dc414a0_4d1da6470710a144 = external constant [0 x i8]
@olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730 = external constant [0 x i8]
@olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab = external constant [0 x i8]
@olang_loc_cdd2e50680d68485_7d51e204495f7309 = external constant [0 x i8]
@olang_loc_2ee7063c57fe9793_68bf97cc73752027 = external constant [0 x i8]
@olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b80660129801afa0_e660219d512f014 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba = external constant [0 x i8]
@olang_loc_1807395182923f6f_ecff5ea7ed15d953 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_a4fa64762613be8a_d12da9b666f393e6 = external constant [0 x i8]
@olang_loc_a387a9465b9f2118_49b9af8105801174 = external constant [0 x i8]
@olang_loc_16612f18a9afa54d_299c1e15a68a5059 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_411550143d3b0e9d_42067e02948bd729 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_8a62bacdff20949b_383b5959755ced57 = external constant [0 x i8]
@olang_loc_2c2074b813b4d1af_bb6745173ec2e4fb = external constant [0 x i8]
@olang_loc_7b5addefd2146e51_66c2395e3e23d40d = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2ftyped_2ewithin(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b = external constant [0 x i8]
declare %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %v0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4231ae67b136756b_a4f71f39f0a47447 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_942c69358f77327c_b8abecb88c811c88 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_ab0bd1a1cb525619_8191fed8583864ed = external constant [0 x i8]
@olang_loc_9bf6326dc96b231_1fb9b096f472b9bd = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_480f1658b5360f56_487a5534952ab742 = external constant [0 x i8]
@olang_loc_8f643c1a2619646b_285ffd8328f7aef7 = external constant [0 x i8]
@olang_loc_879aacf2d1a22b08_c7cef0899cf1454 = external constant [0 x i8]
@olang_loc_642fe669e8876d75_a0626c7162644c61 = external constant [0 x i8]
@olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456 = external constant [0 x i8]
@olang_loc_b6c3975defd019f7_100a23f5f40f96b = external constant [0 x i8]
@olang_loc_9ae088e360a77f54_f93713180ac9c008 = external constant [0 x i8]
@olang_loc_2ec6064c293cb761_d5cc4c8f21af0275 = external constant [0 x i8]
@olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_652e3003820639e_452d7c4eea959e6a = external constant [0 x i8]
@olang_loc_6ab171d7108733d3_fb4921eacef8293f = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
