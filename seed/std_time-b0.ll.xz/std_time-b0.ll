; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/time:Date" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local %"std/time:Date" @std_2ftime_2eDate_2eOf(i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l35 = alloca i64
  %l78 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l106 = alloca %"std/time:Date"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/time:Date"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t2, 60000000000
  %t7 = add i64 %a0, %t4
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = sdiv i64 %t9, 86400000000000
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = srem i64 %t13, 86400000000000
  store i64 %t15, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = sub i64 %t21, 1
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t26, 86400000000000
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 719468
  store i64 %t33, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = sub i64 %t41, 146096
  store i64 %t43, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l35, !tbaa !24
  %t46 = sdiv i64 %t45, 146097
  store i64 %t46, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = mul i64 %t49, 146097
  %t54 = sub i64 %t48, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = sdiv i64 %t57, 1460
  %t62 = sub i64 %t56, %t59
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t63, 36524
  %t68 = add i64 %t62, %t65
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = sdiv i64 %t69, 146096
  %t74 = sub i64 %t68, %t71
  %t76 = sdiv i64 %t74, 365
  store i64 %t76, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 365, %t79
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = sdiv i64 %t82, 4
  %t87 = add i64 %t81, %t84
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = sdiv i64 %t88, 100
  %t93 = sub i64 %t87, %t90
  %t96 = sub i64 %t78, %t93
  store i64 %t96, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = mul i64 5, %t98
  %t102 = add i64 %t100, 2
  %t104 = sdiv i64 %t102, 153
  store i64 %t104, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = mul i64 153, %t107
  %t111 = add i64 %t109, 2
  %t113 = sdiv i64 %t111, 5
  %t116 = sub i64 %t106, %t113
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp slt i64 %t120, 10
  br i1 %t122, label %bb7, label %bb8
bb7:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = add i64 %t124, 3
  store i64 %t126, ptr %l78, !tbaa !24
  br label %bb9
bb8:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = sub i64 %t128, 9
  store i64 %t130, ptr %l78, !tbaa !24
  br label %bb9
bb9:
  %t132 = load i64, ptr %l78, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = mul i64 %t134, 400
  %t139 = add i64 %t133, %t136
  store i64 %t139, ptr %l86, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp sle i64 %t140, 2
  br i1 %t142, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l89, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb12
bb12:
  %t144 = load i64, ptr %l86, !tbaa !24
  %t145 = load i64, ptr %l89, !tbaa !24
  %t146 = add i64 %t144, %t145
  %t148 = load i64, ptr %l4, !tbaa !24
  %t150 = sdiv i64 %t148, 1000000000
  store i64 %t150, ptr %l14, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = sdiv i64 %t155, 3600
  %t158 = load i64, ptr %l14, !tbaa !24
  %t160 = sdiv i64 %t158, 60
  %t162 = srem i64 %t160, 60
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = srem i64 %t163, 60
  %t166 = load i64, ptr %l4, !tbaa !24
  %t168 = srem i64 %t166, 1000000000
  %t169 = load i64, ptr %l1, !tbaa !24
  %t178 = call %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %s0, i64 %t146, i64 %t153, i64 %t154, i64 %t157, i64 %t162, i64 %t165, i64 %t168, i64 %t169)
  store %"std/time:Date" %t178, ptr %l106
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t179 = load %"std/time:Date", ptr %l106
  store %"std/time:Date" %t179, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Date", ptr %rv
  ret %"std/time:Date" %rr
}

define dso_local { i32, %"std/time:Date" } @std_2ftime_2eDate_2eParse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i32
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l96 = alloca i1
  %l109 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l156 = alloca i1
  %l157 = alloca { i64, ptr }
  %l161 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i32
  %l171 = alloca i32
  %l173 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i32
  %l182 = alloca i1
  %l193 = alloca { i64, ptr }
  %l219 = alloca i1
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i64
  %l229 = alloca i64
  %l231 = alloca i1
  %l234 = alloca i1
  %l237 = alloca i1
  %l252 = alloca %"std/time:Date"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/time:Date" }
  %t126 = alloca { i64, [1 x i64] }, align 8
  %t288 = alloca { i64, [1 x i64] }, align 8
  %t341 = alloca { i64, [1 x i64] }, align 8
  %t365 = alloca { i64, [1 x i64] }, align 8
  %t439 = alloca { i64, [1 x i64] }, align 8
  %t520 = alloca { i64, [1 x i64] }, align 8
  %t569 = alloca { i64, [1 x i64] }, align 8
  %t624 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t1, i64 0, i64 4)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l17
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l16
  br label %bb1
bb1:
  %t8 = load i64, ptr %l16, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i32, ptr %l17, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t17, 0
  store { i32, %"std/time:Date" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t21, i64 4, i8 45)
  store i32 %t23, ptr %l20
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t34, 0
  store { i32, %"std/time:Date" } %t36, ptr %rv
  br label %ret
bb6:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t37, i64 5, i64 2)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l25
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb8, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  %t45 = load i32, ptr %l25, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t53, 0
  store { i32, %"std/time:Date" } %t55, ptr %rv
  br label %ret
bb9:
  %t56 = load i64, ptr %l22, !tbaa !24
  store i64 %t56, ptr %l2, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t57, i64 7, i8 45)
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb11, label %ok.61, !prof !99
ok.61:
  br label %bb10
bb10:
  br label %bb12
bb11:
  %t62 = load i32, ptr %l28, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t62, 0
  %t68 = shl i32 %t66, 16
  %t69 = or i32 %t68, %t64
  %t70 = select i1 %t67, i32 0, i32 %t69
  call void @__olang_scope_close(ptr %s0)
  %t72 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t70, 0
  store { i32, %"std/time:Date" } %t72, ptr %rv
  br label %ret
bb12:
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t73, i64 8, i64 2)
  %t76 = extractvalue { i32, i64 } %t75, 1
  %t77 = extractvalue { i32, i64 } %t75, 0
  store i32 %t77, ptr %l33
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb14, label %ok.79, !prof !99
ok.79:
  store i64 %t76, ptr %l32
  br label %bb13
bb13:
  %t80 = load i64, ptr %l32, !tbaa !24
  store i64 %t80, ptr %l30, !tbaa !24
  br label %bb15
bb14:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  call void @__olang_scope_close(ptr %s0)
  %t91 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t89, 0
  store { i32, %"std/time:Date" } %t91, ptr %rv
  br label %ret
bb15:
  %t92 = load i64, ptr %l30, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sle i64 %t95, 10
  br i1 %t97, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb24
bb17:
  %t99 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t99, ptr %l39, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 10
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = icmp ne i8 %t103, 84
  br i1 %t105, label %bb18, label %bb19
bb18:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l43, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 10
  %t111 = load i8, ptr %t110, !tbaa !32
  %t113 = icmp ne i8 %t111, 116
  store i1 %t113, ptr %l42, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t115 = load i1, ptr %l42, !tbaa !21
  br i1 %t115, label %bb21, label %bb22
bb21:
  %t116 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t116, ptr %l47, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i8, ptr %t118, i64 10
  %t120 = load i8, ptr %t119, !tbaa !32
  %t122 = icmp ne i8 %t120, 32
  store i1 %t122, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t124 = load i1, ptr %l46, !tbaa !21
  store i1 %t124, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t125 = load i1, ptr %l38, !tbaa !21
  br i1 %t125, label %bb25, label %bb26
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 0
  store i64 0, ptr %t127
  %t128 = insertvalue { i64 } undef, i64 10, 0
  %t129 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 1
  store { i64 } %t128, ptr %t129
  %t130 = load { i64, [1 x i64] }, ptr %t126
  %t131 = call ptr @__olang_errpay_push()
  %t132 = ptrtoint ptr %t131 to i64
  %t135 = inttoptr i64 %t132 to ptr
  %t136 = call ptr @__olang_scope_alloc_a(ptr %t135, i64 16, i64 8)
  store { i64, [1 x i64] } %t130, ptr %t136
  call void @__olang_errpay_set(ptr %t136)
  call void @__olang_scope_close(ptr %s0)
  %t139 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t139, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t140 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t142 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t140, i64 11, i64 2)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l57
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb29, label %ok.146, !prof !99
ok.146:
  store i64 %t143, ptr %l56
  br label %bb28
bb28:
  %t147 = load i64, ptr %l56, !tbaa !24
  store i64 %t147, ptr %l54, !tbaa !24
  br label %bb30
bb29:
  %t148 = load i32, ptr %l57, !tbaa !23
  %t149 = lshr i32 %t148, 16
  %t150 = and i32 %t148, 65535
  %t151 = icmp eq i32 %t149, 1
  %t152 = select i1 %t151, i32 1, i32 0
  %t153 = icmp eq i32 %t148, 0
  %t154 = shl i32 %t152, 16
  %t155 = or i32 %t154, %t150
  %t156 = select i1 %t153, i32 0, i32 %t155
  call void @__olang_scope_close(ptr %s0)
  %t158 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t156, 0
  store { i32, %"std/time:Date" } %t158, ptr %rv
  br label %ret
bb30:
  %t159 = load i64, ptr %l54, !tbaa !24
  store i64 %t159, ptr %l4, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t162 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t160, i64 13, i8 58)
  store i32 %t162, ptr %l60
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb32, label %ok.164, !prof !99
ok.164:
  br label %bb31
bb31:
  br label %bb33
bb32:
  %t165 = load i32, ptr %l60, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  call void @__olang_scope_close(ptr %s0)
  %t175 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t173, 0
  store { i32, %"std/time:Date" } %t175, ptr %rv
  br label %ret
bb33:
  %t176 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t178 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t176, i64 14, i64 2)
  %t179 = extractvalue { i32, i64 } %t178, 1
  %t180 = extractvalue { i32, i64 } %t178, 0
  store i32 %t180, ptr %l65
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb35, label %ok.182, !prof !99
ok.182:
  store i64 %t179, ptr %l64
  br label %bb34
bb34:
  %t183 = load i64, ptr %l64, !tbaa !24
  store i64 %t183, ptr %l62, !tbaa !24
  br label %bb36
bb35:
  %t184 = load i32, ptr %l65, !tbaa !23
  %t185 = lshr i32 %t184, 16
  %t186 = and i32 %t184, 65535
  %t187 = icmp eq i32 %t185, 1
  %t188 = select i1 %t187, i32 1, i32 0
  %t189 = icmp eq i32 %t184, 0
  %t190 = shl i32 %t188, 16
  %t191 = or i32 %t190, %t186
  %t192 = select i1 %t189, i32 0, i32 %t191
  call void @__olang_scope_close(ptr %s0)
  %t194 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t192, 0
  store { i32, %"std/time:Date" } %t194, ptr %rv
  br label %ret
bb36:
  %t195 = load i64, ptr %l62, !tbaa !24
  store i64 %t195, ptr %l5, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t198 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t196, i64 16, i8 58)
  store i32 %t198, ptr %l68
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb38, label %ok.200, !prof !99
ok.200:
  br label %bb37
bb37:
  br label %bb39
bb38:
  %t201 = load i32, ptr %l68, !tbaa !23
  %t202 = lshr i32 %t201, 16
  %t203 = and i32 %t201, 65535
  %t204 = icmp eq i32 %t202, 1
  %t205 = select i1 %t204, i32 1, i32 0
  %t206 = icmp eq i32 %t201, 0
  %t207 = shl i32 %t205, 16
  %t208 = or i32 %t207, %t203
  %t209 = select i1 %t206, i32 0, i32 %t208
  call void @__olang_scope_close(ptr %s0)
  %t211 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t209, 0
  store { i32, %"std/time:Date" } %t211, ptr %rv
  br label %ret
bb39:
  %t212 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t214 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t212, i64 17, i64 2)
  %t215 = extractvalue { i32, i64 } %t214, 1
  %t216 = extractvalue { i32, i64 } %t214, 0
  store i32 %t216, ptr %l73
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb41, label %ok.218, !prof !99
ok.218:
  store i64 %t215, ptr %l72
  br label %bb40
bb40:
  %t219 = load i64, ptr %l72, !tbaa !24
  store i64 %t219, ptr %l70, !tbaa !24
  br label %bb42
bb41:
  %t220 = load i32, ptr %l73, !tbaa !23
  %t221 = lshr i32 %t220, 16
  %t222 = and i32 %t220, 65535
  %t223 = icmp eq i32 %t221, 1
  %t224 = select i1 %t223, i32 1, i32 0
  %t225 = icmp eq i32 %t220, 0
  %t226 = shl i32 %t224, 16
  %t227 = or i32 %t226, %t222
  %t228 = select i1 %t225, i32 0, i32 %t227
  call void @__olang_scope_close(ptr %s0)
  %t230 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t228, 0
  store { i32, %"std/time:Date" } %t230, ptr %rv
  br label %ret
bb42:
  %t231 = load i64, ptr %l70, !tbaa !24
  store i64 %t231, ptr %l6, !tbaa !24
  store i64 19, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t232 = load i64, ptr %l7, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t238 = icmp slt i64 %t232, %t235
  br i1 %t238, label %bb43, label %bb44
bb43:
  %t240 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t240, ptr %l80, !tbaa !27
  %t241 = load i64, ptr %l7, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i8, ptr %t244, i64 %t241
  %t246 = load i8, ptr %t245, !tbaa !32
  %t248 = icmp eq i8 %t246, 46
  store i1 %t248, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t250 = load i1, ptr %l79, !tbaa !21
  br i1 %t250, label %bb46, label %bb47
bb46:
  %t251 = load i64, ptr %l7, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l7, !tbaa !24
  %t256 = load i64, ptr %l7, !tbaa !24
  store i64 %t256, ptr %l9, !tbaa !24
  store i64 100000000, ptr %l10, !tbaa !24
  br label %bb48
bb47:
  br label %bb64
bb48:
  %t258 = load i64, ptr %l7, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t264 = icmp slt i64 %t258, %t261
  br i1 %t264, label %bb49, label %bb50
bb49:
  %t266 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t266, ptr %l93, !tbaa !27
  %t267 = load i64, ptr %l7, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t267
  %t272 = load i8, ptr %t271, !tbaa !32
  %t274 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t272)
  store i1 %t274, ptr %l96
  br label %bb51
bb50:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb52
bb51:
  %t275 = load i1, ptr %l96, !tbaa !21
  store i1 %t275, ptr %l92, !tbaa !21
  br label %bb52
bb52:
  %t276 = load i1, ptr %l92, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb53, label %bb54
bb53:
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t279 = load i64, ptr %l7, !tbaa !24
  %t280 = load i64, ptr %l9, !tbaa !24
  %t283 = sub i64 %t279, %t280
  %t285 = icmp sge i64 %t283, 9
  br i1 %t285, label %bb56, label %bb57
bb56:
  %t287 = load i64, ptr %l7, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [1 x i64] }, ptr %t288, i32 0, i32 0
  store i64 0, ptr %t289
  %t291 = insertvalue { i64 } undef, i64 %t287, 0
  %t292 = getelementptr { i64, [1 x i64] }, ptr %t288, i32 0, i32 1
  store { i64 } %t291, ptr %t292
  %t293 = load { i64, [1 x i64] }, ptr %t288
  %t294 = call ptr @__olang_errpay_push()
  %t295 = ptrtoint ptr %t294 to i64
  %t298 = inttoptr i64 %t295 to ptr
  %t299 = call ptr @__olang_scope_alloc_a(ptr %t298, i64 16, i64 8)
  store { i64, [1 x i64] } %t293, ptr %t299
  call void @__olang_errpay_set(ptr %t299)
  call void @__olang_scope_close(ptr %s0)
  %t302 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t302, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t303 = load i64, ptr %l8, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t305, ptr %l109, !tbaa !27
  %t306 = load i64, ptr %l7, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i8, ptr %t309, i64 %t306
  %t311 = load i8, ptr %t310, !tbaa !32
  %t313 = sub i8 %t311, 48
  %t315 = zext i8 %t313 to i64
  %t316 = load i64, ptr %l10, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t303, %t319
  store i64 %t322, ptr %l8, !tbaa !24
  %t324 = load i64, ptr %l10, !tbaa !24
  %t327 = sdiv i64 %t324, 10
  store i64 %t327, ptr %l10, !tbaa !24
  %t329 = load i64, ptr %l7, !tbaa !24
  %t332 = add i64 %t329, 1
  store i64 %t332, ptr %l7, !tbaa !24
  br label %bb59
bb59:
  br label %bb48
bb60:
  %t334 = load i64, ptr %l7, !tbaa !24
  %t335 = load i64, ptr %l9, !tbaa !24
  %t338 = icmp eq i64 %t334, %t335
  br i1 %t338, label %bb61, label %bb62
bb61:
  %t340 = load i64, ptr %l7, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [1 x i64] }, ptr %t341, i32 0, i32 0
  store i64 0, ptr %t342
  %t344 = insertvalue { i64 } undef, i64 %t340, 0
  %t345 = getelementptr { i64, [1 x i64] }, ptr %t341, i32 0, i32 1
  store { i64 } %t344, ptr %t345
  %t346 = load { i64, [1 x i64] }, ptr %t341
  %t347 = call ptr @__olang_errpay_push()
  %t348 = ptrtoint ptr %t347 to i64
  %t351 = inttoptr i64 %t348 to ptr
  %t352 = call ptr @__olang_scope_alloc_a(ptr %t351, i64 16, i64 8)
  store { i64, [1 x i64] } %t346, ptr %t352
  call void @__olang_errpay_set(ptr %t352)
  call void @__olang_scope_close(ptr %s0)
  %t355 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t355, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t362 = icmp sge i64 %t356, %t359
  br i1 %t362, label %bb65, label %bb66
bb65:
  %t364 = load i64, ptr %l7, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [1 x i64] }, ptr %t365, i32 0, i32 0
  store i64 0, ptr %t366
  %t368 = insertvalue { i64 } undef, i64 %t364, 0
  %t369 = getelementptr { i64, [1 x i64] }, ptr %t365, i32 0, i32 1
  store { i64 } %t368, ptr %t369
  %t370 = load { i64, [1 x i64] }, ptr %t365
  %t371 = call ptr @__olang_errpay_push()
  %t372 = ptrtoint ptr %t371 to i64
  %t375 = inttoptr i64 %t372 to ptr
  %t376 = call ptr @__olang_scope_alloc_a(ptr %t375, i64 16, i64 8)
  store { i64, [1 x i64] } %t370, ptr %t376
  call void @__olang_errpay_set(ptr %t376)
  call void @__olang_scope_close(ptr %s0)
  %t379 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t379, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  store i64 0, ptr %l11, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t380, ptr %l140, !tbaa !27
  %t381 = load i64, ptr %l7, !tbaa !24
  %t383 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = getelementptr i8, ptr %t384, i64 %t381
  %t386 = load i8, ptr %t385, !tbaa !32
  %t388 = icmp eq i8 %t386, 90
  br i1 %t388, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb70
bb69:
  %t390 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t390, ptr %l145, !tbaa !27
  %t391 = load i64, ptr %l7, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i8, ptr %t394, i64 %t391
  %t396 = load i8, ptr %t395, !tbaa !32
  %t398 = icmp eq i8 %t396, 122
  store i1 %t398, ptr %l144, !tbaa !21
  br label %bb70
bb70:
  %t400 = load i1, ptr %l144, !tbaa !21
  br i1 %t400, label %bb71, label %bb72
bb71:
  %t401 = load i64, ptr %l7, !tbaa !24
  %t404 = add i64 %t401, 1
  store i64 %t404, ptr %l7, !tbaa !24
  br label %bb97
bb72:
  %t406 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t406, ptr %l152, !tbaa !27
  %t407 = load i64, ptr %l7, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i8, ptr %t410, i64 %t407
  %t412 = load i8, ptr %t411, !tbaa !32
  %t414 = icmp eq i8 %t412, 43
  br i1 %t414, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb75
bb74:
  %t416 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t416, ptr %l157, !tbaa !27
  %t417 = load i64, ptr %l7, !tbaa !24
  %t419 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr i8, ptr %t420, i64 %t417
  %t422 = load i8, ptr %t421, !tbaa !32
  %t424 = icmp eq i8 %t422, 45
  store i1 %t424, ptr %l156, !tbaa !21
  br label %bb75
bb75:
  %t426 = load i1, ptr %l156, !tbaa !21
  br i1 %t426, label %bb76, label %bb77
bb76:
  %t427 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t428 = load i64, ptr %l7, !tbaa !24
  %t430 = add i64 %t428, 1
  %t433 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t427, i64 %t430, i64 2)
  %t434 = extractvalue { i32, i64 } %t433, 1
  %t435 = extractvalue { i32, i64 } %t433, 0
  store i32 %t435, ptr %l166
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb79, label %ok.437, !prof !99
ok.437:
  store i64 %t434, ptr %l165
  br label %bb78
bb77:
  %t438 = load i64, ptr %l7, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t439
  %t440 = getelementptr { i64, [1 x i64] }, ptr %t439, i32 0, i32 0
  store i64 0, ptr %t440
  %t442 = insertvalue { i64 } undef, i64 %t438, 0
  %t443 = getelementptr { i64, [1 x i64] }, ptr %t439, i32 0, i32 1
  store { i64 } %t442, ptr %t443
  %t444 = load { i64, [1 x i64] }, ptr %t439
  %t445 = call ptr @__olang_errpay_push()
  %t446 = ptrtoint ptr %t445 to i64
  %t449 = inttoptr i64 %t446 to ptr
  %t450 = call ptr @__olang_scope_alloc_a(ptr %t449, i64 16, i64 8)
  store { i64, [1 x i64] } %t444, ptr %t450
  call void @__olang_errpay_set(ptr %t450)
  call void @__olang_scope_close(ptr %s0)
  %t453 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t453, ptr %rv
  br label %ret
bb78:
  %t454 = load i64, ptr %l165, !tbaa !24
  store i64 %t454, ptr %l161, !tbaa !24
  br label %bb80
bb79:
  %t455 = load i32, ptr %l166, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  call void @__olang_scope_close(ptr %s0)
  %t465 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t463, 0
  store { i32, %"std/time:Date" } %t465, ptr %rv
  br label %ret
bb80:
  %t466 = load i64, ptr %l161, !tbaa !24
  store i64 %t466, ptr %l12, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t468 = load i64, ptr %l7, !tbaa !24
  %t470 = add i64 %t468, 3
  %t473 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t467, i64 %t470, i8 58)
  store i32 %t473, ptr %l171
  %t474 = icmp ne i32 %t473, 0
  br i1 %t474, label %bb82, label %ok.475, !prof !99
ok.475:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t476 = load i32, ptr %l171, !tbaa !23
  %t477 = lshr i32 %t476, 16
  %t478 = and i32 %t476, 65535
  %t479 = icmp eq i32 %t477, 1
  %t480 = select i1 %t479, i32 1, i32 0
  %t481 = icmp eq i32 %t476, 0
  %t482 = shl i32 %t480, 16
  %t483 = or i32 %t482, %t478
  %t484 = select i1 %t481, i32 0, i32 %t483
  call void @__olang_scope_close(ptr %s0)
  %t486 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t484, 0
  store { i32, %"std/time:Date" } %t486, ptr %rv
  br label %ret
bb83:
  %t487 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t488 = load i64, ptr %l7, !tbaa !24
  %t490 = add i64 %t488, 4
  %t493 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t487, i64 %t490, i64 2)
  %t494 = extractvalue { i32, i64 } %t493, 1
  %t495 = extractvalue { i32, i64 } %t493, 0
  store i32 %t495, ptr %l178
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb85, label %ok.497, !prof !99
ok.497:
  store i64 %t494, ptr %l177
  br label %bb84
bb84:
  %t498 = load i64, ptr %l177, !tbaa !24
  store i64 %t498, ptr %l173, !tbaa !24
  br label %bb86
bb85:
  %t499 = load i32, ptr %l178, !tbaa !23
  %t500 = lshr i32 %t499, 16
  %t501 = and i32 %t499, 65535
  %t502 = icmp eq i32 %t500, 1
  %t503 = select i1 %t502, i32 1, i32 0
  %t504 = icmp eq i32 %t499, 0
  %t505 = shl i32 %t503, 16
  %t506 = or i32 %t505, %t501
  %t507 = select i1 %t504, i32 0, i32 %t506
  call void @__olang_scope_close(ptr %s0)
  %t509 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t507, 0
  store { i32, %"std/time:Date" } %t509, ptr %rv
  br label %ret
bb86:
  %t510 = load i64, ptr %l173, !tbaa !24
  store i64 %t510, ptr %l13, !tbaa !24
  %t511 = load i64, ptr %l12, !tbaa !24
  %t513 = icmp sgt i64 %t511, 23
  br i1 %t513, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb89
bb88:
  %t515 = load i64, ptr %l13, !tbaa !24
  %t517 = icmp sgt i64 %t515, 59
  store i1 %t517, ptr %l182, !tbaa !21
  br label %bb89
bb89:
  %t519 = load i1, ptr %l182, !tbaa !21
  br i1 %t519, label %bb90, label %bb91
bb90:
  store { i64, [1 x i64] } zeroinitializer, ptr %t520
  %t521 = getelementptr { i64, [1 x i64] }, ptr %t520, i32 0, i32 0
  store i64 1, ptr %t521
  %t522 = load { i64, [1 x i64] }, ptr %t520
  %t523 = call ptr @__olang_errpay_push()
  %t524 = ptrtoint ptr %t523 to i64
  %t527 = inttoptr i64 %t524 to ptr
  %t528 = call ptr @__olang_scope_alloc_a(ptr %t527, i64 16, i64 8)
  store { i64, [1 x i64] } %t522, ptr %t528
  call void @__olang_errpay_set(ptr %t528)
  call void @__olang_scope_close(ptr %s0)
  %t531 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65537, 0
  store { i32, %"std/time:Date" } %t531, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t532 = load i64, ptr %l12, !tbaa !24
  %t534 = mul i64 %t532, 60
  %t535 = load i64, ptr %l13, !tbaa !24
  %t538 = add i64 %t534, %t535
  store i64 %t538, ptr %l11, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t540, ptr %l193, !tbaa !27
  %t541 = load i64, ptr %l7, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr i8, ptr %t544, i64 %t541
  %t546 = load i8, ptr %t545, !tbaa !32
  %t548 = icmp eq i8 %t546, 45
  br i1 %t548, label %bb93, label %bb94
bb93:
  %t550 = load i64, ptr %l11, !tbaa !24
  %t553 = sub i64 0, %t550
  store i64 %t553, ptr %l11, !tbaa !24
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t555 = load i64, ptr %l7, !tbaa !24
  %t558 = add i64 %t555, 6
  store i64 %t558, ptr %l7, !tbaa !24
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t560 = load i64, ptr %l7, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t566 = icmp ne i64 %t560, %t563
  br i1 %t566, label %bb98, label %bb99
bb98:
  %t568 = load i64, ptr %l7, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t569
  %t570 = getelementptr { i64, [1 x i64] }, ptr %t569, i32 0, i32 0
  store i64 0, ptr %t570
  %t572 = insertvalue { i64 } undef, i64 %t568, 0
  %t573 = getelementptr { i64, [1 x i64] }, ptr %t569, i32 0, i32 1
  store { i64 } %t572, ptr %t573
  %t574 = load { i64, [1 x i64] }, ptr %t569
  %t575 = call ptr @__olang_errpay_push()
  %t576 = ptrtoint ptr %t575 to i64
  %t579 = inttoptr i64 %t576 to ptr
  %t580 = call ptr @__olang_scope_alloc_a(ptr %t579, i64 16, i64 8)
  store { i64, [1 x i64] } %t574, ptr %t580
  call void @__olang_errpay_set(ptr %t580)
  call void @__olang_scope_close(ptr %s0)
  %t583 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t583, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t584 = load i64, ptr %l2, !tbaa !24
  %t586 = icmp slt i64 %t584, 1
  br i1 %t586, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb103
bb102:
  %t588 = load i64, ptr %l2, !tbaa !24
  %t590 = icmp sgt i64 %t588, 12
  store i1 %t590, ptr %l219, !tbaa !21
  br label %bb103
bb103:
  %t592 = load i1, ptr %l219, !tbaa !21
  br i1 %t592, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb106
bb105:
  %t593 = load i64, ptr %l3, !tbaa !24
  %t595 = icmp slt i64 %t593, 1
  store i1 %t595, ptr %l222, !tbaa !21
  br label %bb106
bb106:
  %t597 = load i1, ptr %l222, !tbaa !21
  br i1 %t597, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l225, !tbaa !21
  br label %bb110
bb108:
  %t598 = load i64, ptr %l3, !tbaa !24
  store i64 %t598, ptr %l226, !tbaa !24
  %t599 = load i64, ptr %l1, !tbaa !24
  %t600 = load i64, ptr %l2, !tbaa !24
  %t603 = call i64 @std_2ftime_2edaysIn(i64 %t599, i64 %t600)
  store i64 %t603, ptr %l229
  br label %bb109
bb109:
  %t604 = load i64, ptr %l226, !tbaa !24
  %t605 = load i64, ptr %l229, !tbaa !24
  %t606 = icmp sgt i64 %t604, %t605
  store i1 %t606, ptr %l225, !tbaa !21
  br label %bb110
bb110:
  %t608 = load i1, ptr %l225, !tbaa !21
  br i1 %t608, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l231, !tbaa !21
  br label %bb113
bb112:
  %t609 = load i64, ptr %l4, !tbaa !24
  %t611 = icmp sgt i64 %t609, 23
  store i1 %t611, ptr %l231, !tbaa !21
  br label %bb113
bb113:
  %t613 = load i1, ptr %l231, !tbaa !21
  br i1 %t613, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l234, !tbaa !21
  br label %bb116
bb115:
  %t614 = load i64, ptr %l5, !tbaa !24
  %t616 = icmp sgt i64 %t614, 59
  store i1 %t616, ptr %l234, !tbaa !21
  br label %bb116
bb116:
  %t618 = load i1, ptr %l234, !tbaa !21
  br i1 %t618, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb119
bb118:
  %t619 = load i64, ptr %l6, !tbaa !24
  %t621 = icmp sgt i64 %t619, 59
  store i1 %t621, ptr %l237, !tbaa !21
  br label %bb119
bb119:
  %t623 = load i1, ptr %l237, !tbaa !21
  br i1 %t623, label %bb120, label %bb121
bb120:
  store { i64, [1 x i64] } zeroinitializer, ptr %t624
  %t625 = getelementptr { i64, [1 x i64] }, ptr %t624, i32 0, i32 0
  store i64 1, ptr %t625
  %t626 = load { i64, [1 x i64] }, ptr %t624
  %t627 = call ptr @__olang_errpay_push()
  %t628 = ptrtoint ptr %t627 to i64
  %t631 = inttoptr i64 %t628 to ptr
  %t632 = call ptr @__olang_scope_alloc_a(ptr %t631, i64 16, i64 8)
  store { i64, [1 x i64] } %t626, ptr %t632
  call void @__olang_errpay_set(ptr %t632)
  call void @__olang_scope_close(ptr %s0)
  %t635 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65537, 0
  store { i32, %"std/time:Date" } %t635, ptr %rv
  br label %ret
bb121:
  br label %bb122
bb122:
  %t636 = load i64, ptr %l1, !tbaa !24
  %t637 = load i64, ptr %l2, !tbaa !24
  %t638 = load i64, ptr %l3, !tbaa !24
  %t639 = load i64, ptr %l4, !tbaa !24
  %t640 = load i64, ptr %l5, !tbaa !24
  %t641 = load i64, ptr %l6, !tbaa !24
  %t642 = load i64, ptr %l8, !tbaa !24
  %t643 = load i64, ptr %l11, !tbaa !24
  %t652 = call %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %s0, i64 %t636, i64 %t637, i64 %t638, i64 %t639, i64 %t640, i64 %t641, i64 %t642, i64 %t643)
  store %"std/time:Date" %t652, ptr %l252
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s0)
  %t653 = load %"std/time:Date", ptr %l252
  %t654 = insertvalue { i32, %"std/time:Date" } zeroinitializer, %"std/time:Date" %t653, 1
  store { i32, %"std/time:Date" } %t654, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/time:Date" }, ptr %rv
  ret { i32, %"std/time:Date" } %rr
}

define dso_local i64 @std_2ftime_2edaysIn(i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t7 = call i1 @std_2ftime_2eisLeap(i64 %a0)
  store i1 %t7, ptr %l5
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  store i64 29, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  store i64 28, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb7:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp eq i64 %t10, 4
  br i1 %t12, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = icmp eq i64 %t14, 6
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb13
bb12:
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = icmp eq i64 %t19, 9
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb13
bb13:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb16
bb15:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb16
bb16:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb17, label %bb18
bb17:
  store i64 30, ptr %l18, !tbaa !24
  br label %bb19
bb18:
  store i64 31, ptr %l18, !tbaa !24
  br label %bb19
bb19:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i8
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l54 = alloca i1
  %rv = alloca { i32, i64 }
  %t16 = alloca { i64, [1 x i64] }, align 8
  %t102 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = add i64 %t1, %t2
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp sgt i64 %t5, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store { i64, [1 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [1 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t19 = insertvalue { i64 } undef, i64 %t15, 0
  %t20 = getelementptr { i64, [1 x i64] }, ptr %t16, i32 0, i32 1
  store { i64 } %t19, ptr %t20
  %t21 = load { i64, [1 x i64] }, ptr %t16
  %t22 = call ptr @__olang_errpay_push()
  %t23 = ptrtoint ptr %t22 to i64
  %t26 = inttoptr i64 %t23 to ptr
  %t27 = call ptr @__olang_scope_alloc_a(ptr %t26, i64 16, i64 8)
  store { i64, [1 x i64] } %t21, ptr %t27
  call void @__olang_errpay_set(ptr %t27)
  %t30 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t30, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb6:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l30, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l9, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l48, !tbaa !27
  %t80 = load i64, ptr %l1, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  store i8 %t89, ptr %l10, !tbaa !22
  %t91 = load i8, ptr %l10, !tbaa !22
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t91)
  store i1 %t93, ptr %l54
  br label %bb14
bb14:
  %t94 = load i1, ptr %l54, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t97, %t98
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t105 = insertvalue { i64 } undef, i64 %t101, 0
  %t106 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 1
  store { i64 } %t105, ptr %t106
  %t107 = load { i64, [1 x i64] }, ptr %t102
  %t108 = call ptr @__olang_errpay_push()
  %t109 = ptrtoint ptr %t108 to i64
  %t112 = inttoptr i64 %t109 to ptr
  %t113 = call ptr @__olang_scope_alloc_a(ptr %t112, i64 16, i64 8)
  store { i64, [1 x i64] } %t107, ptr %t113
  call void @__olang_errpay_set(ptr %t113)
  %t116 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t116, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t117 = load i64, ptr %l3, !tbaa !24
  %t120 = mul i64 %t117, 10
  %t121 = load i8, ptr %l10, !tbaa !22
  %t123 = sub i8 %t121, 48
  %t125 = zext i8 %t123 to i64
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t135 = load i64, ptr %l3, !tbaa !24
  %t137 = insertvalue { i32, i64 } zeroinitializer, i64 %t135, 1
  store { i32, i64 } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca i32
  %t23 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t19 = icmp ne i8 %t15, %a2
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l1, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t26 = insertvalue { i64 } undef, i64 %t22, 0
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 1
  store { i64 } %t26, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t23
  %t29 = call ptr @__olang_errpay_push()
  %t30 = ptrtoint ptr %t29 to i64
  %t33 = inttoptr i64 %t30 to ptr
  %t34 = call ptr @__olang_scope_alloc_a(ptr %t33, i64 16, i64 8)
  store { i64, [1 x i64] } %t28, ptr %t34
  call void @__olang_errpay_set(ptr %t34)
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2ftime_2efraction(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i1
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  %t2 = load i64, ptr %l1, !tbaa !65
  %t5 = udiv i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !65
  %t7 = load i64, ptr %l0, !tbaa !65
  %t8 = load i64, ptr %l1, !tbaa !65
  %t11 = urem i64 %t7, %t8
  store i64 %t11, ptr %l3, !tbaa !65
  %t13 = load i64, ptr %l3, !tbaa !65
  %t15 = icmp eq i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l2, !tbaa !65
  %t19 = call i64 @__olang_fmt_u64(ptr null, i64 %t17)
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  %t21 = call i64 @__olang_fmt_u64(ptr %t20, i64 %t17)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t26, ptr %l4
  %t27 = load i64, ptr %l1, !tbaa !65
  %t29 = udiv i64 %t27, 10
  store i64 %t29, ptr %l5, !tbaa !65
  br label %bb5
bb5:
  %t31 = load i64, ptr %l5, !tbaa !65
  %t33 = icmp ugt i64 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l3, !tbaa !65
  %t37 = icmp ugt i64 %t35, 0
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l21, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t42 = zext i8 48 to i64
  %t43 = load i64, ptr %l3, !tbaa !65
  %t44 = load i64, ptr %l5, !tbaa !65
  %t47 = udiv i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  %t52 = trunc i64 %t50 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 %t52)
  br label %bb12
bb12:
  %t55 = load i64, ptr %l3, !tbaa !65
  %t57 = load i64, ptr %l5, !tbaa !65
  %t60 = urem i64 %t55, %t57
  store i64 %t60, ptr %l3, !tbaa !65
  br label %bb13
bb13:
  %t62 = load i64, ptr %l5, !tbaa !65
  %t65 = udiv i64 %t62, 10
  store i64 %t65, ptr %l5, !tbaa !65
  br label %bb5
bb14:
  %t67 = load i64, ptr %l2, !tbaa !65
  store i64 %t67, ptr %l39, !tbaa !65
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t69, ptr %l41
  br label %bb15
bb15:
  %t70 = load i64, ptr %l39, !tbaa !65
  %t71 = call i64 @__olang_fmt_u64(ptr null, i64 %t70)
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t78)
  %t80 = call i64 @__olang_fmt_u64(ptr %t79, i64 %t70)
  %t81 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = getelementptr i8, ptr %t81, i64 %t73
  call void @olang_textcopy(ptr %t82, ptr %t76, i64 %t77)
  %t83 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t79, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2ftime_2eisLeap(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = srem i64 %t1, 4
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t9 = srem i64 %t7, 100
  %t11 = icmp ne i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb6
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = srem i64 %t13, 400
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l8, !tbaa !21
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l4, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2ftime_2eoffsetOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca [16 x i8]
  %l4 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l17 = alloca i64
  %l47 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = call ptr @localtime(ptr %t4)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  store ptr %t7, ptr %l1, !tbaa !29
  %t8 = insertvalue [16 x i8] undef, i8 0, 0
  %t9 = insertvalue [16 x i8] %t8, i8 0, 1
  %t10 = insertvalue [16 x i8] %t9, i8 0, 2
  %t11 = insertvalue [16 x i8] %t10, i8 0, 3
  %t12 = insertvalue [16 x i8] %t11, i8 0, 4
  %t13 = insertvalue [16 x i8] %t12, i8 0, 5
  %t14 = insertvalue [16 x i8] %t13, i8 0, 6
  %t15 = insertvalue [16 x i8] %t14, i8 0, 7
  %t16 = insertvalue [16 x i8] %t15, i8 0, 8
  %t17 = insertvalue [16 x i8] %t16, i8 0, 9
  %t18 = insertvalue [16 x i8] %t17, i8 0, 10
  %t19 = insertvalue [16 x i8] %t18, i8 0, 11
  %t20 = insertvalue [16 x i8] %t19, i8 0, 12
  %t21 = insertvalue [16 x i8] %t20, i8 0, 13
  %t22 = insertvalue [16 x i8] %t21, i8 0, 14
  %t23 = insertvalue [16 x i8] %t22, i8 0, 15
  store [16 x i8] %t23, ptr %l2
  %t26 = insertvalue { i64, ptr } undef, i64 16, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l2, 1
  store { i64, ptr } %t27, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t28, ptr %l12, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  br i1 %t31, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4fa9c29f8b46a671_b1017f21d5208c3d)
  unreachable
bb3:
  br label %bb4
bb4:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = call i64 @strftime(ptr %t36, i64 16, ptr %t39, ptr %t33)
  store i64 %t42, ptr %l17
  br label %bb5
bb5:
  %t43 = load i64, ptr %l17, !tbaa !65
  %t46 = icmp ult i64 %t43, 5
  br i1 %t46, label %bb6, label %bb7
bb6:
  store i64 0, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t49 = getelementptr [16 x i8], ptr %l2, i64 0, i64 1
  %t50 = load i8, ptr %t49, !tbaa !32
  %t53 = sub i8 %t50, 48
  %t55 = zext i8 %t53 to i64
  %t57 = mul i64 %t55, 36000
  %t58 = getelementptr [16 x i8], ptr %l2, i64 0, i64 2
  %t59 = load i8, ptr %t58, !tbaa !32
  %t62 = sub i8 %t59, 48
  %t64 = zext i8 %t62 to i64
  %t66 = mul i64 %t64, 3600
  %t69 = add i64 %t57, %t66
  %t70 = getelementptr [16 x i8], ptr %l2, i64 0, i64 3
  %t71 = load i8, ptr %t70, !tbaa !32
  %t74 = sub i8 %t71, 48
  %t76 = zext i8 %t74 to i64
  %t78 = mul i64 %t76, 600
  %t81 = add i64 %t69, %t78
  %t82 = getelementptr [16 x i8], ptr %l2, i64 0, i64 4
  %t83 = load i8, ptr %t82, !tbaa !32
  %t86 = sub i8 %t83, 48
  %t88 = zext i8 %t86 to i64
  %t90 = mul i64 %t88, 60
  %t93 = add i64 %t81, %t90
  store i64 %t93, ptr %l4, !tbaa !24
  %t95 = getelementptr [16 x i8], ptr %l2, i64 0, i64 0
  %t96 = load i8, ptr %t95, !tbaa !32
  %t99 = icmp eq i8 %t96, 45
  br i1 %t99, label %bb9, label %bb10
bb9:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = sub i64 0, %t101
  store i64 %t103, ptr %l47, !tbaa !24
  br label %bb11
bb10:
  %t105 = load i64, ptr %l4, !tbaa !24
  store i64 %t105, ptr %l47, !tbaa !24
  br label %bb11
bb11:
  %t107 = load i64, ptr %l47, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2ftime_2estd_2ftime_3aDate_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l63 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca i8
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/time:Date", ptr %t3, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s0, i64 %t6, i64 4, i8 48)
  store { i64, ptr } %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t10 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t10, { i64, ptr } %t9)
  br label %bb3
bb3:
  store ptr %l1, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/time:Date", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t15)
  store { i64, ptr } %t17, ptr %l14
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/time:Date", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t21)
  store { i64, ptr } %t23, ptr %l17
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/time:Date", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t27)
  store { i64, ptr } %t29, ptr %l20
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/time:Date", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t33)
  store { i64, ptr } %t35, ptr %l23
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/time:Date", ptr %t36, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t39)
  store { i64, ptr } %t41, ptr %l26
  br label %bb8
bb8:
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t44 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t42, i64 %t43)
  %t77 = getelementptr i8, ptr %t76, i64 %t43
  call void @olang_textcopy(ptr %t77, ptr %t45, i64 %t46)
  %t78 = getelementptr i8, ptr %t77, i64 %t46
  call void @olang_textcopy(ptr %t78, ptr %t48, i64 %t49)
  %t79 = getelementptr i8, ptr %t78, i64 %t49
  call void @olang_textcopy(ptr %t79, ptr %t52, i64 %t53)
  %t80 = getelementptr i8, ptr %t79, i64 %t53
  call void @olang_textcopy(ptr %t80, ptr %t55, i64 %t56)
  %t81 = getelementptr i8, ptr %t80, i64 %t56
  call void @olang_textcopy(ptr %t81, ptr %t59, i64 %t60)
  %t82 = getelementptr i8, ptr %t81, i64 %t60
  call void @olang_textcopy(ptr %t82, ptr %t62, i64 %t63)
  %t83 = getelementptr i8, ptr %t82, i64 %t63
  call void @olang_textcopy(ptr %t83, ptr %t66, i64 %t67)
  %t84 = getelementptr i8, ptr %t83, i64 %t67
  call void @olang_textcopy(ptr %t84, ptr %t69, i64 %t70)
  %t85 = getelementptr i8, ptr %t84, i64 %t70
  call void @olang_textcopy(ptr %t85, ptr %t73, i64 %t74)
  %t86 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t76, 1
  %t89 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t89, { i64, ptr } %t87)
  br label %bb9
bb9:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/time:Date", ptr %t91, i32 0, i32 6
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = icmp ne i64 %t94, 0
  br i1 %t96, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 46)
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/time:Date", ptr %t99, i32 0, i32 6
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s2, i64 %t102, i64 9, i8 48)
  store { i64, ptr } %t104, ptr %l35
  br label %bb13
bb13:
  %t105 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t105, ptr %l2, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t110 = load i64, ptr %l3, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb15, label %bb16
bb15:
  %t114 = load i64, ptr %l3, !tbaa !24
  %t116 = sub i64 %t114, 1
  %t118 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t116
  %t121 = load i8, ptr %t120, !tbaa !32
  %t123 = icmp eq i8 %t121, 48
  store i1 %t123, ptr %l40, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t125 = load i1, ptr %l40, !tbaa !21
  %t126 = xor i1 %t125, true
  br i1 %t126, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = sub i64 %t128, 1
  store i64 %t131, ptr %l3, !tbaa !24
  br label %bb21
bb21:
  br label %bb14
bb22:
  store ptr %l1, ptr %l49, !tbaa !29
  %t133 = load i64, ptr %l3, !tbaa !24
  store i64 %t133, ptr %l50, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  store i64 %t135, ptr %l51, !tbaa !24
  %t136 = icmp sge i64 0, 0
  br i1 %t136, label %bb23, label %bb24
bb23:
  %t138 = load i64, ptr %l50, !tbaa !24
  %t139 = icmp sle i64 0, %t138
  br i1 %t139, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb25:
  %t141 = load i64, ptr %l50, !tbaa !24
  %t142 = load i64, ptr %l51, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb27:
  %t145 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l50, !tbaa !24
  %t148 = getelementptr i8, ptr %t146, i64 0
  %t149 = sub i64 %t147, 0
  %t150 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t152 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t152, { i64, ptr } %t151)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/time:Date", ptr %t154, i32 0, i32 7
  %t157 = load i64, ptr %t156, !tbaa !24
  %t159 = icmp eq i64 %t157, 0
  br i1 %t159, label %bb31, label %bb32
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 90)
  br label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"std/time:Date", ptr %t162, i32 0, i32 7
  %t165 = load i64, ptr %t164, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb34, label %bb35
bb33:
  br label %bb44
bb34:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"std/time:Date", ptr %t169, i32 0, i32 7
  %t172 = load i64, ptr %t171, !tbaa !24
  store i64 %t172, ptr %l63, !tbaa !24
  br label %bb36
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"std/time:Date", ptr %t174, i32 0, i32 7
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = sub i64 0, %t177
  store i64 %t179, ptr %l63, !tbaa !24
  br label %bb36
bb36:
  %t181 = load i64, ptr %l63, !tbaa !24
  store i64 %t181, ptr %l4, !tbaa !24
  store ptr %l1, ptr %l69, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"std/time:Date", ptr %t182, i32 0, i32 7
  %t185 = load i64, ptr %t184, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb37, label %bb38
bb37:
  store i8 43, ptr %l73, !tbaa !22
  br label %bb39
bb38:
  store i8 45, ptr %l73, !tbaa !22
  br label %bb39
bb39:
  %t189 = load ptr, ptr %l69, !tbaa !29
  %t190 = load i8, ptr %l73, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t189, i8 %t190)
  br label %bb40
bb40:
  store ptr %l1, ptr %l74, !tbaa !29
  %t191 = load i64, ptr %l4, !tbaa !24
  %t193 = sdiv i64 %t191, 60
  %t195 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s5, i64 %t193)
  store { i64, ptr } %t195, ptr %l77
  br label %bb41
bb41:
  %t196 = load i64, ptr %l4, !tbaa !24
  %t198 = srem i64 %t196, 60
  %t200 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s5, i64 %t198)
  store { i64, ptr } %t200, ptr %l80
  br label %bb42
bb42:
  %t201 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t207 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t202, i64 %t203)
  %t212 = getelementptr i8, ptr %t211, i64 %t203
  call void @olang_textcopy(ptr %t212, ptr %t204, i64 %t205)
  %t213 = getelementptr i8, ptr %t212, i64 %t205
  call void @olang_textcopy(ptr %t213, ptr %t208, i64 %t209)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t211, 1
  %t217 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t217, { i64, ptr } %t215)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t220 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t220, ptr %l84
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t221, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ftime_2estd_2ftime_3aDuration_2eStr(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l1, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l12, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = sub i64 0, %t33
  store i64 %t35, ptr %l20, !tbaa !65
  br label %bb9
bb8:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l20, !tbaa !65
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !65
  store i64 %t41, ptr %l3, !tbaa !65
  %t42 = load i64, ptr %l3, !tbaa !65
  %t44 = icmp ult i64 %t42, 1000
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = load i64, ptr %l3, !tbaa !65
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t52 = call i64 @__olang_fmt_u64(ptr null, i64 %t47)
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  %t59 = call i64 @__olang_fmt_u64(ptr %t58, i64 %t47)
  %t60 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l3, !tbaa !65
  %t66 = icmp ult i64 %t64, 1000000
  br i1 %t66, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l33, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !65
  %t71 = call { i64, ptr } @std_2ftime_2efraction(ptr %s4, i64 %t69, i64 1000)
  store { i64, ptr } %t71, ptr %l35
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb16:
  %t88 = load i64, ptr %l3, !tbaa !65
  %t90 = icmp ult i64 %t88, 1000000000
  br i1 %t90, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l39, !tbaa !27
  %t93 = load i64, ptr %l3, !tbaa !65
  %t95 = call { i64, ptr } @std_2ftime_2efraction(ptr %s6, i64 %t93, i64 1000000)
  store { i64, ptr } %t95, ptr %l41
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t96 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t97, i64 %t98)
  %t107 = getelementptr i8, ptr %t106, i64 %t98
  call void @olang_textcopy(ptr %t107, ptr %t100, i64 %t101)
  %t108 = getelementptr i8, ptr %t107, i64 %t101
  call void @olang_textcopy(ptr %t108, ptr %t103, i64 %t104)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb20:
  %t112 = load i64, ptr %l3, !tbaa !65
  %t114 = udiv i64 %t112, 3600000000000
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l3, !tbaa !65
  %t118 = udiv i64 %t116, 60000000000
  %t120 = urem i64 %t118, 60
  store i64 %t120, ptr %l5, !tbaa !65
  %t122 = load i64, ptr %l3, !tbaa !65
  %t124 = urem i64 %t122, 60000000000
  %t126 = call { i64, ptr } @std_2ftime_2efraction(ptr %s0, i64 %t124, i64 1000000000)
  store { i64, ptr } %t126, ptr %l50
  br label %bb21
bb21:
  %t127 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t127, ptr %l6, !tbaa !27
  %t128 = load i64, ptr %l4, !tbaa !65
  %t130 = icmp ugt i64 %t128, 0
  br i1 %t130, label %bb22, label %bb23
bb22:
  %t132 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = load i64, ptr %l4, !tbaa !65
  %t134 = load i64, ptr %l5, !tbaa !65
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t132, 1
  %t138 = extractvalue { i64, ptr } %t132, 0
  %t140 = call i64 @__olang_fmt_u64(ptr null, i64 %t133)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = call i64 @__olang_fmt_u64(ptr null, i64 %t134)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t135, 1
  %t153 = extractvalue { i64, ptr } %t135, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t137, i64 %t138)
  %t159 = getelementptr i8, ptr %t158, i64 %t138
  %t160 = call i64 @__olang_fmt_u64(ptr %t159, i64 %t133)
  %t161 = getelementptr i8, ptr %t159, i64 %t140
  call void @olang_textcopy(ptr %t161, ptr %t142, i64 %t143)
  %t162 = getelementptr i8, ptr %t161, i64 %t143
  %t163 = call i64 @__olang_fmt_u64(ptr %t162, i64 %t134)
  %t164 = getelementptr i8, ptr %t162, i64 %t146
  call void @olang_textcopy(ptr %t164, ptr %t148, i64 %t149)
  %t165 = getelementptr i8, ptr %t164, i64 %t149
  call void @olang_textcopy(ptr %t165, ptr %t152, i64 %t153)
  %t166 = getelementptr i8, ptr %t165, i64 %t153
  call void @olang_textcopy(ptr %t166, ptr %t155, i64 %t156)
  %t167 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t158, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t168, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t170 = load i64, ptr %l5, !tbaa !65
  %t172 = icmp ugt i64 %t170, 0
  br i1 %t172, label %bb25, label %bb26
bb25:
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t175 = load i64, ptr %l5, !tbaa !65
  %t176 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t174, 1
  %t179 = extractvalue { i64, ptr } %t174, 0
  %t181 = call i64 @__olang_fmt_u64(ptr null, i64 %t175)
  %t182 = add i64 %t179, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t176, 1
  %t188 = extractvalue { i64, ptr } %t176, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t178, i64 %t179)
  %t194 = getelementptr i8, ptr %t193, i64 %t179
  %t195 = call i64 @__olang_fmt_u64(ptr %t194, i64 %t175)
  %t196 = getelementptr i8, ptr %t194, i64 %t181
  call void @olang_textcopy(ptr %t196, ptr %t183, i64 %t184)
  %t197 = getelementptr i8, ptr %t196, i64 %t184
  call void @olang_textcopy(ptr %t197, ptr %t187, i64 %t188)
  %t198 = getelementptr i8, ptr %t197, i64 %t188
  call void @olang_textcopy(ptr %t198, ptr %t190, i64 %t191)
  %t199 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t193, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t202 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = extractvalue { i64, ptr } %t202, 0
  %t208 = extractvalue { i64, ptr } %t203, 1
  %t209 = extractvalue { i64, ptr } %t203, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  call void @olang_textcopy(ptr %t215, ptr %t208, i64 %t209)
  %t216 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t214, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t218, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ftime_2etwoDigits(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 2, i8 48)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ftime_2ewhyNot(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [1 x i64] } }
  %l2 = alloca %"std/time:Date"
  %l4 = alloca %"std/time:Date"
  %l5 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i32, { i64, [1 x i64] } }
  %l9 = alloca { i32, { i64, [1 x i64] } }
  %l10 = alloca i32
  %l14 = alloca { i32, { i64, [1 x i64] } }
  %l17 = alloca { i32, { i64, [1 x i64] } }
  %l18 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, %"std/time:Date" } @std_2ftime_2eDate_2eParse(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/time:Date" } %t3, 1
  %t5 = extractvalue { i32, %"std/time:Date" } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/time:Date" %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"std/time:Date", ptr %l4
  store %"std/time:Date" %t8, ptr %l2
  br label %bb13
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l7, !tbaa !21
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l1
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t22 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l1, i32 0, i32 0
  store i32 %t21, ptr %t22, !tbaa !23
  br label %bb3
bb3:
  %t23 = load { i32, { i64, [1 x i64] } }, ptr %l1
  store { i32, { i64, [1 x i64] } } %t23, ptr %l8
  store { i32, { i64, [1 x i64] } } zeroinitializer, ptr %l9
  %t24 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l8, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l10, !tbaa !23
  %t26 = load i32, ptr %l10, !tbaa !23
  %t27 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l9, i32 0, i32 0
  store i32 %t26, ptr %t27, !tbaa !23
  %t28 = load i32, ptr %l10, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = call ptr @__olang_errpay_top_get()
  %t35 = load { i64, [1 x i64] }, ptr %t33
  %t36 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l9, i32 0, i32 1
  store { i64, [1 x i64] } %t35, ptr %t36
  br label %bb5
bb5:
  %t37 = load { i32, { i64, [1 x i64] } }, ptr %l9
  store { i32, { i64, [1 x i64] } } %t37, ptr %l1
  %t38 = load { i32, { i64, [1 x i64] } }, ptr %l1
  store { i32, { i64, [1 x i64] } } %t38, ptr %l14
  %t39 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l14, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  br i1 %t43, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  %t45 = load { i32, { i64, [1 x i64] } }, ptr %l1
  store { i32, { i64, [1 x i64] } } %t45, ptr %l17
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t46 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l17, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  store i32 %t47, ptr %l18, !tbaa !23
  %t48 = load i32, ptr %l18, !tbaa !23
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  %t51 = load ptr, ptr %s2
  %t52 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t51, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l22, !tbaa !27
  %t57 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t58 = load ptr, ptr %t57
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %sbgrew.60, label %sbdone.61
sbgrew.60:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.61
sbdone.61:
  %t62 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb9:
  %t63 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t63, i64 %t64)
  br label %bb8
bb10:
  %t65 = load i32, ptr %l18, !tbaa !23
  %t66 = icmp eq i32 %t65, 65536
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t68, i64 %t69)
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t70, i64 %t71)
  %t72 = getelementptr { i32, { i64, [1 x i64] } }, ptr %l17, i32 0, i32 1
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i64 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  %t77 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t78 = call i64 @__olang_fmt_i64(ptr %t77, i64 %t75)
  call void @__olang_sb_add(ptr %s2, i64 %t78)
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t79, i64 %t80)
  br label %bb8
bb12:
  %t81 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t81, i64 %t82)
  br label %bb8
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t83, ptr %l24, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l25, !tbaa !24
  %t86 = load i64, ptr %l25, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l26, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l25, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t97, ptr %l24, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_errpay_push() cold
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
declare i64 @__olang_fmt_u64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @localtime(ptr)
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%z\00" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare i64 @strftime(ptr, i64, ptr, ptr)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0s" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ns" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"us" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ms" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"h" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare ptr @__olang_errpay_top_get()
declare void @__olang_errpay_pop()
declare void @__olang_sb_done(ptr)
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d19 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"time.Error.Syntax" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d22 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"time.Error.Range" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ok" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4fa9c29f8b46a671_b1017f21d5208c3d = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f63687bbaea10838_93db7057d6025df4 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
