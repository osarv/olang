; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:Verdict" = type { { i64, ptr }, { i64, ptr }, i1, i32, { i64, ptr }, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/effects:part" = type { i64, i64, i32, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:root" = type { i64, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/effects:given" = type { i64, i64, i64, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/effects:coldMark" = type { i64, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/effects:fslot" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/effects:fpath" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/effects:pend" = type { i64, i64, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:pair" = type { i64, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:link" = type { i64, i64, i64 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/effects:fret" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local { i64, ptr } @compiler_2feffects_2eBreaks(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 14
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoalloc, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t28, i32 1)
  store i1 %t31, ptr %l13
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t33, ptr %l14, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l14, !tbaa !27
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l19, !tbaa !24
  %t39 = load i64, ptr %l19, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l20, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %l14, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb10:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoblock, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t58, i32 2)
  store i1 %t61, ptr %l26
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t62 = load i1, ptr %l26, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t65, ptr %l27, !tbaa !27
  br label %bb16
bb16:
  %t67 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l32, !tbaa !24
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l33, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l32, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t80, ptr %l27, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb17:
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNospawn, !tbaa !24
  %t86 = icmp eq i64 %t82, %t83
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t88, i32 5)
  store i1 %t91, ptr %l39
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t92 = load i1, ptr %l39, !tbaa !21
  br i1 %t92, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %l40, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l43, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t95, ptr %l40, !tbaa !27
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l45, !tbaa !24
  %t99 = load i64, ptr %l45, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l46, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l45, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t110, ptr %l40, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb24:
  %t112 = load i64, ptr %l1, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoextern, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t121 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %t118, i32 4)
  store i1 %t121, ptr %l52
  br label %bb27
bb26:
  br label %bb34
bb27:
  %t122 = load i1, ptr %l52, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/effects:Facts", ptr %t123, i32 0, i32 19
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  %t129 = xor i64 %t127, -1
  %t132 = and i64 %t126, %t129
  %t134 = icmp ne i64 %t132, 0
  store i1 %t134, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t136 = load i1, ptr %l53, !tbaa !21
  br i1 %t136, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t137, ptr %l60, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t139, ptr %l60, !tbaa !27
  br label %bb33
bb33:
  %t141 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l65, !tbaa !24
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l65, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t154, ptr %l60, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t155, ptr %rv
  br label %ret
bb34:
  %t156 = load i64, ptr %l1, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2ftypes_2ePromReturns, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2feffects_2enotReturning(ptr %v0, ptr %v1, ptr %t162)
  store { i64, ptr } %t164, ptr %l71
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t165 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t165, ptr %rv
  br label %ret
bb38:
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = load i64, ptr @G_2ecompiler_2ftypes_2ePromPure, !tbaa !24
  %t170 = icmp eq i64 %t166, %t167
  br i1 %t170, label %bb39, label %bb40
bb39:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call { i64, ptr } @compiler_2feffects_2eimpure(ptr %v0, ptr %v1, ptr %t172)
  store { i64, ptr } %t174, ptr %l76
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t175 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t175, ptr %rv
  br label %ret
bb42:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/effects:Facts", ptr %t176, i32 0, i32 15
  %t179 = load i1, ptr %t178, !tbaa !21
  br i1 %t179, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Facts", ptr %t181, i32 0, i32 10
  %t184 = load i1, ptr %t183, !tbaa !21
  store i1 %t184, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t186 = load i1, ptr %l79, !tbaa !21
  br i1 %t186, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb48
bb47:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/effects:Facts", ptr %t187, i32 0, i32 11
  %t190 = load i1, ptr %t189, !tbaa !21
  store i1 %t190, ptr %l82, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l82, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l85, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t193, ptr %l86, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l87, !tbaa !24
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = mul i64 %t196, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l88, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l87, !tbaa !24
  %t206 = mul i64 %t205, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t202, ptr %t204, i64 %t206, i1 false)
  %t207 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t207, ptr %l86, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t208, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/effects:Facts", ptr %t209, i32 0, i32 8
  %t212 = load i1, ptr %t211, !tbaa !21
  br i1 %t212, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t214, ptr %l91, !tbaa !27
  br label %bb54
bb53:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t216, ptr %l91, !tbaa !27
  br label %bb54
bb54:
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l96, !tbaa !24
  %t220 = load i64, ptr %l96, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l97, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l96, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t231, ptr %l91, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca i1
  %l116 = alloca ptr
  %l119 = alloca i1
  %l135 = alloca i64
  %l138 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/effects:Facts", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Facts", ptr %t7, i32 0, i32 0
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t13, i32 0, i32 0
  store i1 %t12, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Facts", ptr %t16, i32 0, i32 1
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Facts", ptr %t21, i32 0, i32 1
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = getelementptr %"compiler/effects:Facts", ptr %t27, i32 0, i32 1
  store i1 %t26, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Facts", ptr %t35, i32 0, i32 2
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = getelementptr %"compiler/effects:Facts", ptr %t41, i32 0, i32 2
  store i1 %t40, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/effects:Facts", ptr %t44, i32 0, i32 3
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 3
  %t52 = load i1, ptr %t51, !tbaa !21
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l29, !tbaa !21
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 3
  store i1 %t54, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Facts", ptr %t58, i32 0, i32 4
  %t61 = load i1, ptr %t60, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Facts", ptr %t63, i32 0, i32 4
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t68 = load i1, ptr %l35, !tbaa !21
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = getelementptr %"compiler/effects:Facts", ptr %t69, i32 0, i32 4
  store i1 %t68, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Facts", ptr %t72, i32 0, i32 5
  %t75 = load i1, ptr %t74, !tbaa !21
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/effects:Facts", ptr %t77, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l41, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Facts", ptr %t83, i32 0, i32 5
  store i1 %t82, ptr %t84, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Facts", ptr %t86, i32 0, i32 6
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb21
bb20:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Facts", ptr %t91, i32 0, i32 6
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l47, !tbaa !21
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = getelementptr %"compiler/effects:Facts", ptr %t97, i32 0, i32 6
  store i1 %t96, ptr %t98, !tbaa !21
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l50, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Facts", ptr %t100, i32 0, i32 7
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb24
bb23:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/effects:Facts", ptr %t105, i32 0, i32 7
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t110 = load i1, ptr %l53, !tbaa !21
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = getelementptr %"compiler/effects:Facts", ptr %t111, i32 0, i32 7
  store i1 %t110, ptr %t112, !tbaa !21
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l56, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/effects:Facts", ptr %t114, i32 0, i32 8
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb27
bb26:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/effects:Facts", ptr %t119, i32 0, i32 8
  %t122 = load i1, ptr %t121, !tbaa !21
  store i1 %t122, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t124 = load i1, ptr %l59, !tbaa !21
  %t125 = load ptr, ptr %l56, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Facts", ptr %t125, i32 0, i32 8
  store i1 %t124, ptr %t126, !tbaa !21
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/effects:Facts", ptr %t128, i32 0, i32 9
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb29:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/effects:Facts", ptr %t133, i32 0, i32 9
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t138 = load i1, ptr %l65, !tbaa !21
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = getelementptr %"compiler/effects:Facts", ptr %t139, i32 0, i32 9
  store i1 %t138, ptr %t140, !tbaa !21
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l68, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Facts", ptr %t142, i32 0, i32 10
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb33
bb32:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/effects:Facts", ptr %t147, i32 0, i32 10
  %t150 = load i1, ptr %t149, !tbaa !21
  store i1 %t150, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t152 = load i1, ptr %l71, !tbaa !21
  %t153 = load ptr, ptr %l68, !tbaa !29
  %t154 = getelementptr %"compiler/effects:Facts", ptr %t153, i32 0, i32 10
  store i1 %t152, ptr %t154, !tbaa !21
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l74, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/effects:Facts", ptr %t156, i32 0, i32 11
  %t159 = load i1, ptr %t158, !tbaa !21
  br i1 %t159, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb36
bb35:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/effects:Facts", ptr %t161, i32 0, i32 11
  %t164 = load i1, ptr %t163, !tbaa !21
  store i1 %t164, ptr %l77, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l77, !tbaa !21
  %t167 = load ptr, ptr %l74, !tbaa !29
  %t168 = getelementptr %"compiler/effects:Facts", ptr %t167, i32 0, i32 11
  store i1 %t166, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l80, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/effects:Facts", ptr %t170, i32 0, i32 12
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb39
bb38:
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/effects:Facts", ptr %t175, i32 0, i32 12
  %t178 = load i1, ptr %t177, !tbaa !21
  store i1 %t178, ptr %l83, !tbaa !21
  br label %bb39
bb39:
  %t180 = load i1, ptr %l83, !tbaa !21
  %t181 = load ptr, ptr %l80, !tbaa !29
  %t182 = getelementptr %"compiler/effects:Facts", ptr %t181, i32 0, i32 12
  store i1 %t180, ptr %t182, !tbaa !21
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l86, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/effects:Facts", ptr %t184, i32 0, i32 13
  %t187 = load i1, ptr %t186, !tbaa !21
  br i1 %t187, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb42
bb41:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/effects:Facts", ptr %t189, i32 0, i32 13
  %t192 = load i1, ptr %t191, !tbaa !21
  store i1 %t192, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t194 = load i1, ptr %l89, !tbaa !21
  %t195 = load ptr, ptr %l86, !tbaa !29
  %t196 = getelementptr %"compiler/effects:Facts", ptr %t195, i32 0, i32 13
  store i1 %t194, ptr %t196, !tbaa !21
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l92, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/effects:Facts", ptr %t198, i32 0, i32 14
  %t201 = load i1, ptr %t200, !tbaa !21
  br i1 %t201, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb45
bb44:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/effects:Facts", ptr %t203, i32 0, i32 14
  %t206 = load i1, ptr %t205, !tbaa !21
  store i1 %t206, ptr %l95, !tbaa !21
  br label %bb45
bb45:
  %t208 = load i1, ptr %l95, !tbaa !21
  %t209 = load ptr, ptr %l92, !tbaa !29
  %t210 = getelementptr %"compiler/effects:Facts", ptr %t209, i32 0, i32 14
  store i1 %t208, ptr %t210, !tbaa !21
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l98, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/effects:Facts", ptr %t212, i32 0, i32 15
  %t215 = load i1, ptr %t214, !tbaa !21
  br i1 %t215, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb48
bb47:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr %"compiler/effects:Facts", ptr %t217, i32 0, i32 15
  %t220 = load i1, ptr %t219, !tbaa !21
  store i1 %t220, ptr %l101, !tbaa !21
  br label %bb48
bb48:
  %t222 = load i1, ptr %l101, !tbaa !21
  %t223 = load ptr, ptr %l98, !tbaa !29
  %t224 = getelementptr %"compiler/effects:Facts", ptr %t223, i32 0, i32 15
  store i1 %t222, ptr %t224, !tbaa !21
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l104, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/effects:Facts", ptr %t226, i32 0, i32 16
  %t229 = load i1, ptr %t228, !tbaa !21
  br i1 %t229, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb51
bb50:
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr %"compiler/effects:Facts", ptr %t231, i32 0, i32 16
  %t234 = load i1, ptr %t233, !tbaa !21
  store i1 %t234, ptr %l107, !tbaa !21
  br label %bb51
bb51:
  %t236 = load i1, ptr %l107, !tbaa !21
  %t237 = load ptr, ptr %l104, !tbaa !29
  %t238 = getelementptr %"compiler/effects:Facts", ptr %t237, i32 0, i32 16
  store i1 %t236, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l110, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/effects:Facts", ptr %t240, i32 0, i32 17
  %t243 = load i1, ptr %t242, !tbaa !21
  br i1 %t243, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb54
bb53:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr %"compiler/effects:Facts", ptr %t245, i32 0, i32 17
  %t248 = load i1, ptr %t247, !tbaa !21
  store i1 %t248, ptr %l113, !tbaa !21
  br label %bb54
bb54:
  %t250 = load i1, ptr %l113, !tbaa !21
  %t251 = load ptr, ptr %l110, !tbaa !29
  %t252 = getelementptr %"compiler/effects:Facts", ptr %t251, i32 0, i32 17
  store i1 %t250, ptr %t252, !tbaa !21
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l116, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/effects:Facts", ptr %t254, i32 0, i32 18
  %t257 = load i1, ptr %t256, !tbaa !21
  br i1 %t257, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb57
bb56:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/effects:Facts", ptr %t259, i32 0, i32 18
  %t262 = load i1, ptr %t261, !tbaa !21
  store i1 %t262, ptr %l119, !tbaa !21
  br label %bb57
bb57:
  %t264 = load i1, ptr %l119, !tbaa !21
  %t265 = load ptr, ptr %l116, !tbaa !29
  %t266 = getelementptr %"compiler/effects:Facts", ptr %t265, i32 0, i32 18
  store i1 %t264, ptr %t266, !tbaa !21
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr %"compiler/effects:Facts", ptr %t267, i32 0, i32 19
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = icmp eq i64 %t270, 0
  br i1 %t272, label %bb58, label %bb59
bb58:
  br label %ret
bb59:
  br label %bb60
bb60:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/effects:Facts", ptr %t275, i32 0, i32 19
  %t278 = load i64, ptr %t277, !tbaa !24
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr %"compiler/effects:Facts", ptr %t279, i32 0, i32 19
  %t282 = load i64, ptr %t281, !tbaa !24
  %t285 = or i64 %t278, %t282
  %t288 = getelementptr %"compiler/effects:Facts", ptr %t274, i32 0, i32 19
  store i64 %t285, ptr %t288, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t289 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t289, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  %t292 = load i64, ptr %l2, !tbaa !24
  %t295 = icmp sgt i64 %t291, %t292
  br i1 %t295, label %bb61, label %bb62
bb61:
  %t297 = load i64, ptr %l4, !tbaa !24
  %t299 = icmp sgt i64 %t297, 0
  br i1 %t299, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb66
bb63:
  %t301 = load i64, ptr %l3, !tbaa !24
  %t302 = load i64, ptr %l2, !tbaa !24
  %t305 = sub i64 %t301, %t302
  %t306 = load i64, ptr %l4, !tbaa !24
  %t309 = add i64 %t305, %t306
  %t311 = sub i64 %t309, 1
  %t312 = load i64, ptr %l4, !tbaa !24
  %t315 = sdiv i64 %t311, %t312
  store i64 %t315, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t317 = load i64, ptr %l138, !tbaa !24
  store i64 %t317, ptr %l135, !tbaa !24
  br label %bb66
bb66:
  %t318 = load i64, ptr %l135, !tbaa !24
  store i64 %t318, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb67
bb67:
  %t319 = load i64, ptr %l6, !tbaa !24
  %t320 = load i64, ptr %l5, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb68, label %bb69
bb68:
  br label %bb75
bb69:
  br label %bb70
bb70:
  %t327 = load i64, ptr %l2, !tbaa !24
  %t328 = load i64, ptr %l6, !tbaa !24
  %t329 = load i64, ptr %l4, !tbaa !24
  %t332 = mul i64 %t328, %t329
  %t335 = add i64 %t327, %t332
  store i64 %t335, ptr %l7, !tbaa !24
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i64, ptr %l7, !tbaa !24
  %t340 = getelementptr %"compiler/effects:Facts", ptr %t337, i32 0, i32 20
  %t342 = getelementptr [6 x i64], ptr %t340, i64 0, i64 %t338
  %t343 = load i64, ptr %t342, !tbaa !34
  %t345 = icmp slt i64 %t343, 0
  br i1 %t345, label %bb71, label %bb72
bb71:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i64, ptr %l7, !tbaa !24
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t350 = load i64, ptr %l7, !tbaa !24
  %t352 = getelementptr %"compiler/effects:Facts", ptr %t349, i32 0, i32 20
  %t354 = getelementptr [6 x i64], ptr %t352, i64 0, i64 %t350
  %t355 = load i64, ptr %t354, !tbaa !34
  %t358 = getelementptr %"compiler/effects:Facts", ptr %t347, i32 0, i32 20
  %t360 = getelementptr [6 x i64], ptr %t358, i64 0, i64 %t348
  store i64 %t355, ptr %t360, !tbaa !34
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t361 = load i64, ptr %l6, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l6, !tbaa !24
  br label %bb67
bb75:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2eMergeCold(ptr %v0, ptr %a0, %"compiler/effects:Facts" %a1) #0 {
entry:
  %l1 = alloca %"compiler/effects:Facts"
  %l3 = alloca i1
  %s0 = alloca %olang.scope
  store %"compiler/effects:Facts" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 1
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t4 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  store i1 %t5, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t8 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 1
  store i1 %t7, ptr %t8, !tbaa !21
  %t9 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 0
  store i1 false, ptr %t9, !tbaa !21
  call void @compiler_2feffects_2eMerge(ptr %v0, ptr %s0, ptr %a0, ptr %l1)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecapIndex(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l32 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l14, !tbaa !24
  store i64 %t29, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l11, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = shl i64 1, %t51
  %t56 = icmp eq i64 %t52, %a0
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb7
bb15:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eBlame(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/effects:Verdict" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:Verdict"
  %l7 = alloca %"compiler/effects:Verdict"
  %l10 = alloca %"compiler/effects:Verdict"
  %l12 = alloca %"compiler/effects:Verdict"
  %rv = alloca %"compiler/effects:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store %"compiler/effects:Verdict" %a1, ptr %l5
  %t4 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v3, ptr %l5)
  store %"compiler/effects:Verdict" %t4, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load %"compiler/effects:Verdict", ptr %l7
  %t11 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t7, %"compiler/effects:Verdict" %t8, i64 %a2, { i64, ptr } %a3)
  store %"compiler/effects:Verdict" %t11, ptr %l10
  br label %bb2
bb2:
  %t13 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v3, ptr %l10)
  store %"compiler/effects:Verdict" %t13, ptr %l12
  br label %bb3
bb3:
  %t14 = load %"compiler/effects:Verdict", ptr %l12
  store %"compiler/effects:Verdict" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eJudge(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/effects:Verdict"
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/effects:part"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/effects:Facts"
  %l15 = alloca %"compiler/effects:Verdict"
  %l20 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/effects:Facts"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/effects:part"
  %l63 = alloca %"compiler/effects:part"
  %l67 = alloca i1
  %l71 = alloca i1
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca %"compiler/effects:Facts"
  %l94 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/effects:Verdict"
  %l99 = alloca %"compiler/effects:Verdict"
  %l100 = alloca i64
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/effects:Verdict"
  %l107 = alloca %"compiler/effects:Verdict"
  %l113 = alloca i1
  %l117 = alloca i1
  %l124 = alloca i32
  %l128 = alloca i32
  %l135 = alloca i1
  %l141 = alloca ptr
  %l144 = alloca %"compiler/effects:Facts"
  %l149 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca %"compiler/effects:Verdict"
  %l154 = alloca %"compiler/effects:Verdict"
  %l155 = alloca i64
  %l158 = alloca { i64, ptr }
  %l160 = alloca %"compiler/effects:Verdict"
  %l162 = alloca %"compiler/effects:Verdict"
  %l168 = alloca %"compiler/effects:Facts"
  %l170 = alloca i1
  %l176 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca %"compiler/effects:Verdict"
  %l181 = alloca %"compiler/effects:Verdict"
  %l183 = alloca %"compiler/effects:Verdict"
  %l185 = alloca %"compiler/effects:Verdict"
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca i64
  %l196 = alloca %"compiler/effects:Facts"
  %l201 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca %"compiler/effects:Verdict"
  %l206 = alloca %"compiler/effects:Verdict"
  %l208 = alloca %"compiler/effects:Verdict"
  %l210 = alloca %"compiler/effects:Verdict"
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Verdict"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %v2)
  store %"compiler/effects:Verdict" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Verdict", ptr %l15
  store %"compiler/effects:Verdict" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t12 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t8, i32 %a3)
  store i64 %t12, ptr %l20
  br label %bb2
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2feffects_2eEffectWords, !tbaa !24
  %t14 = load i64, ptr %l20, !tbaa !24
  %t16 = and i64 %t14, %t13
  store i64 %t16, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  store i1 %t24, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l25, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb9
bb7:
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l29, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 1
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l32
  br label %bb8
bb8:
  %t33 = load i64, ptr %l29, !tbaa !24
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = icmp sge i64 %t33, %t34
  store i1 %t35, ptr %l28, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l28, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t38, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/effects:Facts" %t44, ptr %l37
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t45, i64 %t46)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Effects", ptr %t49, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t51)
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %t53, ptr %a2, i64 0)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 36
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l46
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %l46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l48
  br label %bb17
bb17:
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t64, ptr %lp6
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t66 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = load ptr, ptr %lp6
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgedParts(ptr %v0, ptr %v0, ptr %v0, ptr %t67, i64 %t68, ptr %t69)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l52
  br label %bb18
bb18:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t75
  store ptr %t75, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %l54, !tbaa !24
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l56
  br label %bb20
bb20:
  %t81 = load i64, ptr %l54, !tbaa !24
  %t82 = load i64, ptr %l56, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb21, label %bb22
bb21:
  br label %bb116
bb22:
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/effects:part" %t91, ptr %l61
  br label %bb24
bb24:
  %t93 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l61)
  store %"compiler/effects:part" %t93, ptr %l63
  br label %bb25
bb25:
  %t94 = load %"compiler/effects:part", ptr %l63
  store %"compiler/effects:part" %t94, ptr %l9
  %t95 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb26, label %bb27
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Effects", ptr %t102, i32 0, i32 8
  %t105 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  %t109 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t104, i64 %t106)
  store i1 %t109, ptr %l71
  br label %bb28
bb27:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb29
bb28:
  %t110 = load i1, ptr %l71, !tbaa !21
  store i1 %t110, ptr %l67, !tbaa !21
  br label %bb29
bb29:
  %t111 = load i1, ptr %l67, !tbaa !21
  br i1 %t111, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s5, ptr %t112, i64 %t114)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l74
  br label %bb32
bb31:
  br label %bb52
bb32:
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s5, ptr %l74)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l76
  br label %bb33
bb33:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  %t121 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %t121
  store ptr %t121, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l78, !tbaa !24
  %t124 = load ptr, ptr %l10, !tbaa !29
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %t124)
  store i64 %t126, ptr %l80
  br label %bb35
bb35:
  %t127 = load i64, ptr %l78, !tbaa !24
  %t128 = load i64, ptr %l80, !tbaa !24
  %t129 = icmp slt i64 %t127, %t128
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb37:
  br label %bb38
bb38:
  %t133 = load ptr, ptr %l10, !tbaa !29
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l85
  br label %bb39
bb39:
  %t138 = load i64, ptr %l85, !tbaa !24
  store i64 %t138, ptr %l12, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l86, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t140, i64 %t141)
  store %"compiler/effects:Facts" %t144, ptr %l89
  br label %bb40
bb40:
  %t145 = load i64, ptr %l5, !tbaa !24
  %t146 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s6, ptr %v2, ptr %t146, ptr %l89, i64 %t145, ptr %l4)
  br label %bb41
bb41:
  %t150 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t151, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t153, ptr %l94
  br label %bb42
bb42:
  %t154 = load i1, ptr %l94, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb43, label %bb44
bb43:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t158, ptr %l97
  %t160 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l97)
  store %"compiler/effects:Verdict" %t160, ptr %l99
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t161 = load i64, ptr %l12, !tbaa !24
  store i64 %t161, ptr %l100, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i64, ptr %l12, !tbaa !24
  %t166 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %v2, ptr %t162, i64 %t163)
  store { i64, ptr } %t166, ptr %l103
  br label %bb46
bb46:
  %t167 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = mul i64 %t168, 1
  %t171 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t169, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t174 = load ptr, ptr %l96, !tbaa !29
  %t175 = load %"compiler/effects:Verdict", ptr %l99
  %t176 = load i64, ptr %l100, !tbaa !24
  %t178 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t174, %"compiler/effects:Verdict" %t175, i64 %t176, { i64, ptr } %t173)
  store %"compiler/effects:Verdict" %t178, ptr %l105
  br label %bb47
bb47:
  %t180 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l105)
  store %"compiler/effects:Verdict" %t180, ptr %l107
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  %t181 = load %"compiler/effects:Verdict", ptr %l107
  store %"compiler/effects:Verdict" %t181, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l11, !tbaa !24
  br label %bb34
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb115
bb52:
  %t186 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb55
bb54:
  %t193 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t194 = load i64, ptr %t193, !tbaa !24
  %t195 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  store i1 %t198, ptr %l113, !tbaa !21
  br label %bb55
bb55:
  %t200 = load i1, ptr %l113, !tbaa !21
  br i1 %t200, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb58
bb57:
  %t201 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t206 = icmp eq i64 %t202, %t203
  store i1 %t206, ptr %l117, !tbaa !21
  br label %bb58
bb58:
  %t208 = load i1, ptr %l117, !tbaa !21
  br i1 %t208, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s9
  %t209 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb61, label %bb62
bb60:
  br label %bb70
bb61:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i64, ptr %l1, !tbaa !24
  %t218 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  %t223 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t216, i64 %t217, i64 %t219)
  store i32 %t223, ptr %l128
  br label %bb63
bb62:
  %t224 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 2
  %t225 = load i32, ptr %t224, !tbaa !23
  store i32 %t225, ptr %l124, !tbaa !23
  br label %bb64
bb63:
  %t227 = load i32, ptr %l128, !tbaa !23
  store i32 %t227, ptr %l124, !tbaa !23
  br label %bb64
bb64:
  %t228 = load i32, ptr %l124, !tbaa !23
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeType(ptr %v0, ptr %v2, ptr %t229, i32 %t228, i64 %t231, ptr %l4)
  br label %bb65
bb65:
  %t236 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s9, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t239, ptr %l135
  br label %bb66
bb66:
  %t240 = load i1, ptr %l135, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb67, label %bb68
bb67:
  %t243 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s9)
  store %"compiler/effects:Verdict" %t243, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb115
bb70:
  %t245 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t246 = load i64, ptr %t245, !tbaa !24
  %t247 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t250 = icmp eq i64 %t246, %t247
  br i1 %t250, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l141, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t255 = load i64, ptr %t254, !tbaa !24
  %t258 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t253, i64 %t255)
  store %"compiler/effects:Facts" %t258, ptr %l144
  br label %bb73
bb72:
  br label %bb83
bb73:
  %t259 = load i64, ptr %l5, !tbaa !24
  %t260 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s11, ptr %v2, ptr %t260, ptr %l144, i64 %t259, ptr %l4)
  br label %bb74
bb74:
  %t264 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  %t267 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t267, ptr %l149
  br label %bb75
bb75:
  %t268 = load i1, ptr %l149, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb76, label %bb77
bb76:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l151, !tbaa !29
  %t272 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t272, ptr %l152
  %t274 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l152)
  store %"compiler/effects:Verdict" %t274, ptr %l154
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t275 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t276 = load i64, ptr %t275, !tbaa !24
  store i64 %t276, ptr %l155, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t279 = load i64, ptr %t278, !tbaa !24
  %t282 = call { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %v2, ptr %t277, i64 %t279)
  store { i64, ptr } %t282, ptr %l158
  br label %bb79
bb79:
  %t283 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t290 = load ptr, ptr %l151, !tbaa !29
  %t291 = load %"compiler/effects:Verdict", ptr %l154
  %t292 = load i64, ptr %l155, !tbaa !24
  %t294 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t290, %"compiler/effects:Verdict" %t291, i64 %t292, { i64, ptr } %t289)
  store %"compiler/effects:Verdict" %t294, ptr %l160
  br label %bb80
bb80:
  %t296 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l160)
  store %"compiler/effects:Verdict" %t296, ptr %l162
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s11)
  %t297 = load %"compiler/effects:Verdict", ptr %l162
  store %"compiler/effects:Verdict" %t297, ptr %rv
  br label %ret
bb82:
  call void @__olang_scope_close(ptr %s11)
  br label %bb83
bb83:
  %t298 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  %t303 = icmp eq i64 %t299, %t300
  br i1 %t303, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s13
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t307 = load i64, ptr %t306, !tbaa !24
  %t310 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t305, i64 %t307)
  store %"compiler/effects:Facts" %t310, ptr %l168
  br label %bb86
bb85:
  br label %bb99
bb86:
  %t311 = load %"compiler/effects:Facts", ptr %l168
  store %"compiler/effects:Facts" %t311, ptr %l14
  %t312 = getelementptr %"compiler/effects:Facts", ptr %l14, i32 0, i32 21
  %t313 = load i64, ptr %t312, !tbaa !24
  %t315 = call i1 @compiler_2feffects_2ehasBit(i64 %t313, i64 0)
  store i1 %t315, ptr %l170
  br label %bb87
bb87:
  %t316 = load i1, ptr %l170, !tbaa !21
  br i1 %t316, label %bb88, label %bb89
bb88:
  %t317 = getelementptr %"compiler/effects:Facts", ptr %l14, i32 0, i32 18
  store i1 true, ptr %t317, !tbaa !21
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s13, ptr %v2, ptr %t318, ptr %l14, i64 %t319, ptr %l4)
  br label %bb91
bb91:
  %t324 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  %t327 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s13, { i64, ptr } %t325, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t327, ptr %l176
  br label %bb92
bb92:
  %t328 = load i1, ptr %l176, !tbaa !21
  %t329 = xor i1 %t328, true
  br i1 %t329, label %bb93, label %bb94
bb93:
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l178, !tbaa !29
  %t332 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t332, ptr %l179
  %t334 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l179)
  store %"compiler/effects:Verdict" %t334, ptr %l181
  br label %bb95
bb94:
  br label %bb98
bb95:
  %t335 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t336 = load i64, ptr %t335, !tbaa !24
  %t337 = load ptr, ptr %l178, !tbaa !29
  %t338 = load %"compiler/effects:Verdict", ptr %l181
  %t340 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t337, %"compiler/effects:Verdict" %t338, i64 %t336, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/effects:Verdict" %t340, ptr %l183
  br label %bb96
bb96:
  %t342 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l183)
  store %"compiler/effects:Verdict" %t342, ptr %l185
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  %t343 = load %"compiler/effects:Verdict", ptr %l185
  store %"compiler/effects:Verdict" %t343, ptr %rv
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb99:
  %t344 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  %t349 = icmp eq i64 %t345, %t346
  br i1 %t349, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s16
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l189, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l190, !tbaa !29
  %t353 = load i64, ptr %l1, !tbaa !24
  store i64 %t353, ptr %l191, !tbaa !24
  %t354 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t355 = load i64, ptr %t354, !tbaa !24
  store i64 %t355, ptr %l192, !tbaa !24
  %t356 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 3
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = icmp eq ptr %t357, null
  br i1 %t359, label %bb102, label %bb103
bb101:
  br label %bb114
bb102:
  call void @__olang_check_failed(ptr @olang_loc_cce6b986552578d0_26bb880b6e07dfc)
  unreachable
bb103:
  br label %bb104
bb104:
  %t361 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 3
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t363 = load ptr, ptr %l190, !tbaa !29
  %t364 = load i64, ptr %l191, !tbaa !24
  %t365 = load i64, ptr %l192, !tbaa !24
  %t367 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v0, ptr %t363, i64 %t364, i64 %t365, ptr %t362)
  store %"compiler/effects:Facts" %t367, ptr %l196
  br label %bb105
bb105:
  %t368 = load i64, ptr %l5, !tbaa !24
  %t369 = load ptr, ptr %l189, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %s16, ptr %v2, ptr %t369, ptr %l196, i64 %t368, ptr %l4)
  br label %bb106
bb106:
  %t373 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  %t376 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s16, { i64, ptr } %t374, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t376, ptr %l201
  br label %bb107
bb107:
  %t377 = load i1, ptr %l201, !tbaa !21
  %t378 = xor i1 %t377, true
  br i1 %t378, label %bb108, label %bb109
bb108:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l203, !tbaa !29
  %t381 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t381, ptr %l204
  %t383 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l204)
  store %"compiler/effects:Verdict" %t383, ptr %l206
  br label %bb110
bb109:
  br label %bb113
bb110:
  %t384 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t385 = load i64, ptr %t384, !tbaa !24
  %t386 = load ptr, ptr %l203, !tbaa !29
  %t387 = load %"compiler/effects:Verdict", ptr %l206
  %t389 = call %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t386, %"compiler/effects:Verdict" %t387, i64 %t385, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store %"compiler/effects:Verdict" %t389, ptr %l208
  br label %bb111
bb111:
  %t391 = call %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v2, ptr %l208)
  store %"compiler/effects:Verdict" %t391, ptr %l210
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s16)
  %t392 = load %"compiler/effects:Verdict", ptr %l210
  store %"compiler/effects:Verdict" %t392, ptr %rv
  br label %ret
bb113:
  call void @__olang_scope_close(ptr %s16)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t393 = load i64, ptr %l8, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l8, !tbaa !24
  br label %bb19
bb116:
  %t397 = load %"compiler/effects:Verdict", ptr %l4
  store %"compiler/effects:Verdict" %t397, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 16
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t8, i64 %a1)
  store ptr %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t17, i64 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l13
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l12
  br label %bb3
bb3:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/effects:Facts"
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/effects:Facts"
  %l17 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/effects:Facts"
  %l32 = alloca %"compiler/effects:Facts"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t16, ptr %l11
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load %"compiler/effects:Facts", ptr %l11
  store %"compiler/effects:Facts" %t17, ptr %l2
  %t18 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 14
  store i1 true, ptr %t18, !tbaa !21
  %t19 = load %"compiler/effects:Facts", ptr %l2
  call void @__olang_scope_close(ptr %s1)
  store %"compiler/effects:Facts" %t19, ptr %rv
  br label %ret
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t21)
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 15
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l17
  br label %bb10
bb10:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = icmp slt i64 %t30, 2
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %t33, i64 %t34)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 10
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = icmp eq i64 %t44, 0
  br i1 %t45, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 9
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t49, i64 %t50)
  store %"compiler/effects:Facts" %t53, ptr %l29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t54 = load %"compiler/effects:Facts", ptr %l29
  store %"compiler/effects:Facts" %t54, ptr %rv
  br label %ret
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2enamed(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/effects:Facts" %t59, ptr %l32
  br label %bb20
bb20:
  %t60 = load %"compiler/effects:Facts", ptr %l32
  store %"compiler/effects:Facts" %t60, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 23
  %t6 = load %"compiler/effects:Facts", ptr %t5
  store %"compiler/effects:Facts" %t6, ptr %l2
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load %"compiler/effects:Facts", ptr %l8
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 23
  store %"compiler/effects:Facts" %t10, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/effects:Effects", ptr %t13, i32 0, i32 34
  store i64 -1, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %t16, i64 %a1)
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 23
  %t23 = load %"compiler/effects:Facts", ptr %t22
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/effects:Facts", ptr %l2
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t25, i32 0, i32 23
  store %"compiler/effects:Facts" %t26, ptr %t29
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb34
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/effects:Effects", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb17
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l34
  br label %bb16
bb16:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l29, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t70 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  store i1 %t70, ptr %l38
  br label %bb20
bb19:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb21
bb20:
  %t71 = load i1, ptr %l38, !tbaa !21
  store i1 %t71, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l35, !tbaa !21
  store i1 %t72, ptr %l6, !tbaa !21
  br label %bb34
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 18}
  %t80 = icmp eq i64 %t78, 17
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t92 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargGlobal(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  store i1 %t92, ptr %l47
  br label %bb28
bb28:
  %t93 = load i1, ptr %l47, !tbaa !21
  store i1 %t93, ptr %l6, !tbaa !21
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_7ef30bd5545b1b3f_da1c1797c8787b93)
  unreachable
bb34:
  %t94 = load i1, ptr %l6, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:root"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca %"compiler/effects:root"
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca %"compiler/effects:root"
  %l43 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  store %"compiler/effects:root" %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = getelementptr %"compiler/effects:root", ptr %l27, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t45)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l30
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb12, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l29
  br label %bb11
bb11:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l22, !tbaa !24
  store i64 %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb29
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t74 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store %"compiler/effects:root" %t74, ptr %l39
  br label %bb21
bb21:
  %t75 = load %"compiler/effects:root", ptr %l39
  store %"compiler/effects:root" %t75, ptr %l5
  %t76 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 1
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Effects", ptr %t82, i32 0, i32 29
  %t85 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t84, i64 %t86)
  %t90 = extractvalue { i32, i64 } %t89, 1
  %t91 = extractvalue { i32, i64 } %t89, 0
  store i32 %t91, ptr %l48
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb26, label %ok.93, !prof !99
ok.93:
  store i64 %t90, ptr %l47
  br label %bb25
bb25:
  %t94 = load i64, ptr %l47, !tbaa !24
  store i64 %t94, ptr %l43, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb28
bb28:
  %t95 = load i64, ptr %l43, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb30, label %bb31
bb30:
  %t100 = load ptr, ptr %l49, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 17
  store i1 %t103, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t115 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargParam(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store i64 %t115, ptr %l57
  br label %bb35
bb35:
  %t116 = load i64, ptr %l57, !tbaa !24
  store i64 %t116, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4055e0fe87b920f9_59f1ceb8b6607d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblame(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/effects:Verdict" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/effects:Verdict"
  %l2 = alloca i64
  %l4 = alloca %"compiler/effects:Verdict"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Verdict"
  store ptr %a0, ptr %l0
  store %"compiler/effects:Verdict" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/effects:Verdict", ptr %l1
  store %"compiler/effects:Verdict" %t1, ptr %l4
  %t5 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 4
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l15, !tbaa !27
  %t8 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 4
  store { i64, ptr } %a3, ptr %t8, !tbaa !27
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e4
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l15
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  call void @__olang_region_release_part(ptr %t13, i64 %t12)
  store { i64, ptr } zeroinitializer, ptr %l15
  br label %bb2
bb2:
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t14 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l8, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l11, !tbaa !24
  %t65 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t63
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  %t67 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t69, ptr %s0, { i64, ptr } %t66, { i64, ptr } %t68)
  store i1 %t72, ptr %l46
  br label %bb13
bb13:
  %t73 = load i1, ptr %l46, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t74 = load i64, ptr %l11, !tbaa !24
  store i64 %t74, ptr %l47, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = load i64, ptr %l47, !tbaa !24
  %t77 = shl i64 1, %t76
  store i64 %t77, ptr %l5, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l10, !tbaa !24
  br label %bb9
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = getelementptr %"compiler/effects:Effects", ptr %t83, i32 0, i32 47
  store i64 %t84, ptr %t87, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l53, !tbaa !29
  %t89 = ptrtoint ptr %v0 to i64
  store i64 %t89, ptr %l54, !tbaa !24
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e48
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = call ptr @__olang_region_make_part(ptr %v0)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l54, !tbaa !24
  br label %bb20
bb20:
  %t94 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = load i64, ptr %l54
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l58, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e48
  br i1 %t111, label %bb21, label %bb22
bb21:
  %t113 = load i64, ptr %l54
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = load { i64, ptr }, ptr %l58
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  %t120 = icmp eq ptr %t119, %t114
  call void @__olang_region_settle(ptr %t114, i1 %t120)
  br label %bb22
bb22:
  %t121 = load ptr, ptr %l53, !tbaa !29
  %t122 = getelementptr %"compiler/effects:Effects", ptr %t121, i32 0, i32 48
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l60, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t125 = load ptr, ptr %l53, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Effects", ptr %t125, i32 0, i32 48
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e48
  br i1 %t127, label %bb23, label %bb24
bb23:
  %t129 = load { i64, ptr }, ptr %l60
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t131 = extractvalue { i64, ptr } %t129, 1
  call void @__olang_region_release_part(ptr %t131, i64 %t130)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %bb24
bb24:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/effects:Effects", ptr %t132, i32 0, i32 49
  store i1 false, ptr %t134, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t135, i64 %t136)
  br label %bb25
bb25:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/effects:Effects", ptr %t139, i32 0, i32 47
  store i64 0, ptr %t141, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Effects", ptr %t142, i32 0, i32 49
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb26, label %bb27
bb26:
  %t149 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t149, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/effects:Effects", ptr %t151, i32 0, i32 1
  %t154 = load i64, ptr %l2, !tbaa !24
  %t157 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t153, i64 %t154)
  store ptr %t157, ptr %l73
  br label %bb29
bb29:
  %t158 = load ptr, ptr %l73, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Body", ptr %t158, i32 0, i32 3
  %t161 = load i64, ptr %t160, !tbaa !24
  %t163 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 5
  store i64 %t161, ptr %t163, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/effects:Effects", ptr %t164, i32 0, i32 50
  %t167 = load %"compiler/source:Span", ptr %t166
  %t169 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 6
  store %"compiler/source:Span" %t167, ptr %t169
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/effects:Effects", ptr %t170, i32 0, i32 51
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t174 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 7
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l80, !tbaa !27
  %t177 = getelementptr %"compiler/effects:Verdict", ptr %l4, i32 0, i32 7
  store { i64, ptr } %t173, ptr %t177, !tbaa !27
  %t178 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e7
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load { i64, ptr }, ptr %l80
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  call void @__olang_region_release_part(ptr %t182, i64 %t181)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %bb31
bb31:
  %t183 = load %"compiler/effects:Verdict", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Verdict" %t183, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l25 = alloca { i64, ptr }
  %l31 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 26
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp eq i64 %t8, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i1 @compiler_2ftyped_2eFails(ptr %v1, ptr %t12)
  store i1 %t15, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i1, ptr %l14, !tbaa !21
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldBlock(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Block", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l5, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 47
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = icmp eq i64 %t50, 0
  br i1 %t52, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 26
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb21
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyStmt(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb12
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebodyName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/effects:Effects", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t44, i64 %t45)
  store ptr %t46, ptr %l24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l17, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s1, ptr %t51, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t56 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t57, i64 %t58)
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  store { i64, ptr } %t67, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb8:
  %t69 = load { i64, [2 x i64] }, ptr %l2
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 4
  br i1 %t72, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  br label %bb25
bb12:
  %t76 = load { i64, [2 x i64] }, ptr %l2
  %t78 = extractvalue { i64, [2 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 1
  br i1 %t79, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  br label %bb25
bb16:
  %t83 = load { i64, [2 x i64] }, ptr %l2
  %t85 = extractvalue { i64, [2 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 3
  br i1 %t86, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t88, ptr %l10, !tbaa !27
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t90, ptr %l10, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_480f10282bdc13cf_4349ffb73b811f6b)
  unreachable
bb25:
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l43, !tbaa !24
  %t94 = load i64, ptr %l43, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l44, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l43, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t105, ptr %l10, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebounds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/effects:given"
  %l21 = alloca %"compiler/effects:Facts"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i32
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i64
  %l78 = alloca i64
  %l80 = alloca i1
  %l84 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l113 = alloca i64
  %l115 = alloca i1
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca %"compiler/effects:given"
  %l129 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l144 = alloca i1
  %l146 = alloca ptr
  %l151 = alloca %"compiler/effects:Facts"
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l21
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/effects:Effects", ptr %t3, i32 0, i32 7
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 1
  %t11 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 0
  store i32 %t11, ptr %l27
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l26
  br label %bb2
bb2:
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l29
  br label %bb5
bb3:
  br label %bb4
bb4:
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l30
  br label %bb6
bb5:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l22
  br label %bb7
bb6:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l22
  br label %bb7
bb7:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 4
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l34
  br label %bb8
bb8:
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l36
  br label %bb9
bb9:
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %l36)
  store i64 %t30, ptr %l38
  br label %bb10
bb10:
  %t31 = load i64, ptr %l38, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb13:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l45, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l45, !tbaa !24
  store i64 %t58, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb19:
  br label %bb20
bb20:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Effects", ptr %t78, i32 0, i32 4
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l66
  br label %bb21
bb21:
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l66)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l68
  br label %bb22
bb22:
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l68, i64 %t87)
  store i64 %t90, ptr %l71
  br label %bb23
bb23:
  %t91 = load i64, ptr %l71, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb27
bb25:
  %t96 = load i64, ptr %l10, !tbaa !24
  store i64 %t96, ptr %l75, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Effects", ptr %t97, i32 0, i32 1
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l78
  br label %bb26
bb26:
  %t102 = load i64, ptr %l75, !tbaa !24
  %t103 = load i64, ptr %l78, !tbaa !24
  %t104 = icmp sge i64 %t102, %t103
  store i1 %t104, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t106 = load i1, ptr %l74, !tbaa !21
  br i1 %t106, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb31
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/effects:Effects", ptr %t107, i32 0, i32 10
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l84
  br label %bb30
bb30:
  %t114 = load i64, ptr %l84, !tbaa !24
  %t115 = icmp eq i64 %t114, 0
  store i1 %t115, ptr %l80, !tbaa !21
  br label %bb31
bb31:
  %t117 = load i1, ptr %l80, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l11, !tbaa !24
  store i64 63, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb40
bb37:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l92, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb39
bb39:
  %t144 = load i64, ptr %l92, !tbaa !24
  store i64 %t144, ptr %l89, !tbaa !24
  br label %bb40
bb40:
  %t145 = load i64, ptr %l89, !tbaa !24
  store i64 %t145, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t146 = load i64, ptr %l15, !tbaa !24
  %t147 = load i64, ptr %l14, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb42, label %bb43
bb42:
  br label %bb83
bb43:
  br label %bb44
bb44:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l16, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/effects:Effects", ptr %t164, i32 0, i32 10
  %t167 = load i64, ptr %l10, !tbaa !24
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t166, i64 %t167)
  store i64 %t170, ptr %l113
  br label %bb45
bb45:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l113, !tbaa !24
  %t174 = call i1 @compiler_2feffects_2ehasBit(i64 %t172, i64 %t171)
  store i1 %t174, ptr %l115
  br label %bb46
bb46:
  %t175 = load i1, ptr %l115, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb47, label %bb48
bb47:
  br label %bb82
bb48:
  br label %bb49
bb49:
  store i1 false, ptr %l17, !tbaa !21
  store ptr %l3, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb50
bb50:
  %t179 = load i64, ptr %l19, !tbaa !24
  store i64 %t179, ptr %l118, !tbaa !24
  %t180 = load ptr, ptr %l18, !tbaa !29
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t180)
  store i64 %t182, ptr %l120
  br label %bb51
bb51:
  %t183 = load i64, ptr %l118, !tbaa !24
  %t184 = load i64, ptr %l120, !tbaa !24
  %t185 = icmp slt i64 %t183, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb52, label %bb53
bb52:
  br label %bb75
bb53:
  br label %bb54
bb54:
  %t189 = load ptr, ptr %l18, !tbaa !29
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t189, i64 %t190)
  store %"compiler/effects:given" %t193, ptr %l125
  br label %bb55
bb55:
  %t194 = load %"compiler/effects:given", ptr %l125
  store %"compiler/effects:given" %t194, ptr %l20
  %t195 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 0
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = icmp ne i64 %t196, %t197
  br i1 %t200, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l129, !tbaa !21
  br label %bb58
bb57:
  %t202 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 1
  %t203 = load i64, ptr %t202, !tbaa !24
  %t204 = load i64, ptr %l16, !tbaa !24
  %t207 = icmp ne i64 %t203, %t204
  store i1 %t207, ptr %l129, !tbaa !21
  br label %bb58
bb58:
  %t209 = load i1, ptr %l129, !tbaa !21
  br i1 %t209, label %bb59, label %bb60
bb59:
  br label %bb74
bb60:
  br label %bb61
bb61:
  store i1 true, ptr %l17, !tbaa !21
  %t210 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 2
  %t211 = load i64, ptr %t210, !tbaa !24
  %t212 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t215 = icmp eq i64 %t211, %t212
  br i1 %t215, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb68
bb63:
  %t217 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 2
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  br i1 %t222, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/effects:Effects", ptr %t224, i32 0, i32 8
  %t227 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 3
  %t228 = load i64, ptr %t227, !tbaa !24
  %t231 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t226, i64 %t228)
  store i1 %t231, ptr %l144
  br label %bb66
bb65:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb67
bb66:
  %t232 = load i1, ptr %l144, !tbaa !21
  %t233 = xor i1 %t232, true
  store i1 %t233, ptr %l140, !tbaa !21
  br label %bb67
bb67:
  %t235 = load i1, ptr %l140, !tbaa !21
  store i1 %t235, ptr %l136, !tbaa !21
  br label %bb68
bb68:
  %t236 = load i1, ptr %l136, !tbaa !21
  br i1 %t236, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l2, ptr %l146, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/effects:Effects", ptr %t237, i32 0, i32 0
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  %t243 = getelementptr %"compiler/effects:given", ptr %l20, i32 0, i32 4
  %t244 = load i32, ptr %t243, !tbaa !23
  %t247 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t242, i32 %t244)
  store %"compiler/effects:Facts" %t247, ptr %l151
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t248 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s10, ptr %t248, ptr %l151)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s10)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l19, !tbaa !24
  br label %bb50
bb75:
  %t254 = load i1, ptr %l17, !tbaa !21
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr %l2, ptr %l157, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/effects:Effects", ptr %t258, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = getelementptr %"compiler/generic:Program", ptr %t261, i32 0, i32 2
  store ptr %t263, ptr %l160, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i64, ptr %l10, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t270 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t264, i64 %t265, i64 %t266)
  store i32 %t270, ptr %l164
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t271 = load ptr, ptr %l160, !tbaa !29
  %t272 = load i32, ptr %l164, !tbaa !23
  %t273 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t271, i32 %t272)
  store %"compiler/effects:Facts" %t273, ptr %l165
  br label %bb79
bb79:
  %t274 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s12, ptr %t274, ptr %l165)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t276 = load i64, ptr %l15, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l15, !tbaa !24
  br label %bb41
bb83:
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb84:
  %t280 = load i64, ptr %l8, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l8, !tbaa !24
  br label %bb17
bb85:
  call void @__olang_scope_close(ptr %s1)
  %t284 = load %"compiler/effects:Facts", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t284, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecMayCallBack(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 18
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Effects", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 19
  %t22 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l10
  br label %bb3
bb3:
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = icmp sgt i64 %t23, 0
  store i1 %t24, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l5, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 53
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = call i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinksOwnC(ptr %v0, ptr %t42)
  store i1 %t44, ptr %l20
  br label %bb10
bb9:
  br label %bb18
bb10:
  %t45 = load i1, ptr %l20, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ehasExport(ptr %v0, ptr %t46)
  store i1 %t48, ptr %l23
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t49 = load i1, ptr %l23, !tbaa !21
  store i1 %t49, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l24, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb17
bb17:
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load ptr, ptr %l16, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 53
  store i64 %t51, ptr %t53, !tbaa !24
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 53
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallEdge(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l40 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Effects", ptr %t16, i32 0, i32 14
  %t19 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19, i1 true)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 4
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s2, ptr %t24, i64 %t25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l20
  br label %bb9
bb9:
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l22
  br label %bb10
bb10:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t32 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %t32
  store ptr %t32, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t35)
  store i64 %t37, ptr %l26
  br label %bb12
bb12:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t44, i64 %t45)
  store i64 %t48, ptr %l31
  br label %bb16
bb16:
  %t49 = load i64, ptr %l31, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp eq i64 %t49, %t51
  br i1 %t54, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s2)
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/effects:Effects", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l40
  br label %bb22
bb22:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t68, i64 %t67)
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  %t72 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eedge(ptr %v0, ptr %t70, i64 %t71, i64 %t72)
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInstLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i64
  %l35 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca %"compiler/effects:part"
  %l44 = alloca %"compiler/effects:part"
  %l47 = alloca %"compiler/effects:part"
  %l51 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca %"compiler/effects:part"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i32
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l16
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l11, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/effects:Effects", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 33
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t25)
  store ptr %t28, ptr %l24
  br label %bb7
bb6:
  br label %bb19
bb7:
  %t29 = load ptr, ptr %l24, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 5
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l27
  br label %bb8
bb8:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = icmp slt i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 33
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlotOf(ptr %v0, ptr %v1, ptr %t38, i64 %t42, i64 %t43, ptr %t44)
  store i64 %t49, ptr %l35
  br label %bb11
bb10:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb12
bb11:
  %t50 = load i64, ptr %l35, !tbaa !24
  store i64 %t50, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l29, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 36
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i32, ptr %l3, !tbaa !23
  %t65 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t59, i64 %t60, i32 %t61, ptr null)
  store %"compiler/effects:part" %t65, ptr %l44
  br label %bb15
bb14:
  %t66 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  %t70 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t66, i64 0, i32 %t67, ptr null)
  store %"compiler/effects:part" %t70, ptr %l47
  br label %bb16
bb15:
  %t71 = load %"compiler/effects:part", ptr %l44
  store %"compiler/effects:part" %t71, ptr %l40
  br label %bb17
bb16:
  %t72 = load %"compiler/effects:part", ptr %l47
  store %"compiler/effects:part" %t72, ptr %l40
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load %"compiler/effects:part", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t73, %"compiler/effects:part" %t74)
  br label %bb18
bb18:
  br label %ret
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 61
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77, i64 %t78)
  store i1 %t81, ptr %l51
  br label %bb20
bb20:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb24
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/effects:Effects", ptr %t83, i32 0, i32 60
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l56
  br label %bb23
bb23:
  %t90 = load i1, ptr %l56, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/effects:Effects", ptr %t94, i32 0, i32 36
  store ptr %t96, ptr %l59, !tbaa !29
  %t97 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t97, i64 0, i32 %t98, ptr null)
  store %"compiler/effects:part" %t101, ptr %l62
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t102 = load ptr, ptr %l59, !tbaa !29
  %t103 = load %"compiler/effects:part", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t102, %"compiler/effects:part" %t103)
  br label %bb28
bb28:
  br label %ret
bb29:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 60
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v0, ptr %t106, i64 %t107)
  %t111 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t110, 1
  %t112 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t110, 0
  store i32 %t112, ptr %l68
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb31, label %ok.114, !prof !99
ok.114:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l67
  br label %bb30
bb30:
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %l67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l70
  br label %bb33
bb31:
  br label %bb32
bb32:
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l71
  br label %bb34
bb33:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l63
  br label %bb35
bb34:
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  %t122 = load i64, ptr %l9, !tbaa !24
  store i64 %t122, ptr %l73, !tbaa !24
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l75
  br label %bb37
bb37:
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = load i64, ptr %l75, !tbaa !24
  %t128 = icmp slt i64 %t126, %t127
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb38, label %bb39
bb38:
  br label %bb44
bb39:
  br label %bb40
bb40:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store ptr %t136, ptr %l80
  br label %bb41
bb41:
  %t137 = load ptr, ptr %l80, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  %t144 = add i64 %a4, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v0, ptr %v1, ptr %t138, ptr %t137, ptr %t140, i32 %t141, i64 %t144)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb36
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyLocal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca %"compiler/effects:part"
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca %"compiler/effects:part"
  %l44 = alloca i1
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i32
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l14
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t12 = load i64, ptr %l13, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l9, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Effects", ptr %t18, i32 0, i32 36
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i32, ptr %l2, !tbaa !23
  %t27 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t21, i64 %t22, i32 %t23, ptr null)
  store %"compiler/effects:part" %t27, ptr %l22
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load %"compiler/effects:part", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t28, %"compiler/effects:part" %t29)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Effects", ptr %t30, i32 0, i32 38
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t32, i64 %t33)
  store i1 %t36, ptr %l26
  br label %bb10
bb10:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb12:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t38, 0
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 37
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t49 = load i1, ptr %l34, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/effects:Effects", ptr %t54, i32 0, i32 36
  store ptr %t56, ptr %l37, !tbaa !29
  %t57 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v0, i64 %t57, i64 0, i32 %t58, ptr null)
  store %"compiler/effects:part" %t61, ptr %l40
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load %"compiler/effects:part", ptr %l40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t62, %"compiler/effects:part" %t63)
  br label %bb21
bb21:
  br label %ret
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Effects", ptr %t64, i32 0, i32 37
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l44
  br label %bb23
bb23:
  %t71 = load i1, ptr %l44, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t74, i32 0, i32 37
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  %t81 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t80, 1
  %t82 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t80, 0
  store i32 %t82, ptr %l51
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb28, label %ok.84, !prof !99
ok.84:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l50
  br label %bb27
bb27:
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l53
  br label %bb30
bb28:
  br label %bb29
bb29:
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l54
  br label %bb31
bb30:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l46
  br label %bb32
bb31:
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l46
  br label %bb32
bb32:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l5
  store ptr %l5, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb33
bb33:
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %l56, !tbaa !24
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l58
  br label %bb34
bb34:
  %t96 = load i64, ptr %l56, !tbaa !24
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l63
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l63, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t113 = add i64 %a3, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v0, ptr %t108, ptr %t107, i64 %t113)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l7, !tbaa !24
  br label %bb33
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Clause", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Clause", ptr %t8, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/effects:coldMark"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca %"compiler/effects:coldMark"
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/effects:coldMark" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldOpen(ptr %v0, ptr %t1)
  store %"compiler/effects:coldMark" %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load %"compiler/effects:coldMark", ptr %l8
  store %"compiler/effects:coldMark" %t4, ptr %l2
  %t7 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t30, ptr %t28)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/effects:coldMark", ptr %l2
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldClose(ptr %v0, ptr %t38, %"compiler/effects:coldMark" %t39)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:coldMark"
  %l6 = alloca %"compiler/effects:coldMark"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/effects:coldMark" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldOpen(ptr %v0, ptr %t5)
  store %"compiler/effects:coldMark" %t7, ptr %l6
  br label %bb4
bb4:
  %t8 = load %"compiler/effects:coldMark", ptr %l6
  store %"compiler/effects:coldMark" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t9, ptr %t10)
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/effects:coldMark", ptr %l2
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldClose(ptr %v0, ptr %t14, %"compiler/effects:coldMark" %t15)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefaultsExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Try", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t56 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %a0, ptr %t49)
  store i1 %t56, ptr %l35
  br label %bb9
bb9:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l7, !tbaa !24
  br label %bb5
bb14:
  br label %bb15
bb15:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l29 = alloca i1
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i32
  %l78 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i1, ptr %l9, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 37
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 37
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l18
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v0, ptr %t26, i64 %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 37
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v0, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l24
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store ptr %t36, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l23, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  br label %bb15
bb12:
  %t41 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t41, 65536
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_12d41178ea699117_cd5c06b5e62ab993)
  unreachable
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bfb31f4e096fcfdd_9eff6572189cd471)
  unreachable
bb15:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t45, ptr %t44)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l29
  br label %bb18
bb18:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/effects:Effects", ptr %t53, i32 0, i32 60
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l33
  br label %bb21
bb20:
  br label %bb33
bb21:
  %t60 = load i1, ptr %l33, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 60
  store ptr %t65, ptr %l36, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l37, !tbaa !24
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l38
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v0, ptr %t68, i64 %t69, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/effects:Effects", ptr %t71, i32 0, i32 60
  %t74 = load i64, ptr %l1, !tbaa !24
  %t77 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l44
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb28, label %ok.81, !prof !99
ok.81:
  store ptr %t78, ptr %l43
  br label %bb27
bb27:
  %t82 = load ptr, ptr %l43, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  br label %bb31
bb28:
  %t83 = load i32, ptr %l44, !tbaa !23
  %t84 = icmp eq i32 %t83, 65536
  br i1 %t84, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bdb589e9fb60a385_99895746a144f341)
  unreachable
bb30:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6c2f84c28d80f803_c1ff4c3310f9a27)
  unreachable
bb31:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t87, ptr %t86)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Effects", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l3, !tbaa !23
  %t98 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t98, ptr %l51
  br label %bb34
bb34:
  %t99 = load i1, ptr %l51, !tbaa !21
  br i1 %t99, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb38
bb36:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Effects", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l3, !tbaa !23
  %t109 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l57
  br label %bb37
bb37:
  %t110 = load i1, ptr %l57, !tbaa !21
  store i1 %t110, ptr %l52, !tbaa !21
  br label %bb38
bb38:
  %t111 = load i1, ptr %l52, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t118 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %t114, ptr %t115, i64 0)
  store i64 %t118, ptr %l61
  br label %bb42
bb42:
  %t119 = load i64, ptr %l61, !tbaa !24
  store i64 %t119, ptr %l4, !tbaa !24
  %t120 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp ne i64 %t120, 0
  br i1 %t122, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/effects:Effects", ptr %t124, i32 0, i32 30
  store ptr %t126, ptr %l65, !tbaa !29
  %t127 = load i64, ptr %l1, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/effects:Effects", ptr %t129, i32 0, i32 30
  %t132 = load i64, ptr %l1, !tbaa !24
  %t135 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t131, i64 %t132)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l73
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb46, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l72
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t140 = load i64, ptr %l72, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb48
bb48:
  %t141 = load i64, ptr %l67, !tbaa !24
  %t142 = load i64, ptr %l68, !tbaa !24
  %t143 = or i64 %t141, %t142
  %t144 = load ptr, ptr %l65, !tbaa !29
  %t145 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145, i64 %t143)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/effects:Effects", ptr %t147, i32 0, i32 2
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb51, label %bb52
bb51:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/effects:Effects", ptr %t152, i32 0, i32 39
  store ptr %t154, ptr %l78, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t157 = mul i64 2, %t155
  store i64 %t157, ptr %l80, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t162 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebuilt(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  store i1 %t162, ptr %l83
  br label %bb53
bb52:
  br label %bb58
bb53:
  %t163 = load i1, ptr %l83, !tbaa !21
  br i1 %t163, label %bb54, label %bb55
bb54:
  store i64 1, ptr %l84, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb56
bb56:
  %t164 = load i64, ptr %l80, !tbaa !24
  %t165 = load i64, ptr %l84, !tbaa !24
  %t166 = add i64 %t164, %t165
  %t167 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t167, i64 %t166)
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l147 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l24
  br label %bb3
bb3:
  %t15 = load i1, ptr %l24, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l30
  br label %bb7
bb7:
  %t27 = load i1, ptr %l30, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l25, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/effects:Effects", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l36
  br label %bb12
bb12:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l41
  br label %bb13
bb13:
  %t52 = load i32, ptr %l41, !range !{i32 0, i32 33}
  store i32 %t52, ptr %l4
  %t53 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb48
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/effects:Effects", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l48
  br label %bb17
bb17:
  %t68 = load i1, ptr %l48, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edtorCalled(ptr %v0, ptr %t69, i32 %t70)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/effects:Effects", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l53, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l58
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l53, !tbaa !29
  %t90 = load i32, ptr %l58, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l59
  br label %bb23
bb23:
  %t92 = load i32, ptr %l59, !range !{i32 0, i32 6}
  %t94 = trunc i64 0 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Effects", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/effects:Effects", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l69
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t113, i32 %t114)
  store { i64, ptr } %t115, ptr %l70
  br label %bb27
bb27:
  %t116 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t116, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l77, !tbaa !27
  %t130 = load i64, ptr %l6, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 %t130
  %t135 = load i32, ptr %t134, !tbaa !33
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l2, !tbaa !24
  %t141 = add i64 %t139, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t137, i32 %t135, i64 %t141)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l6, !tbaa !24
  br label %bb28
bb34:
  br label %ret
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/effects:Effects", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l88, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/effects:Effects", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l3, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l93
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l88, !tbaa !29
  %t166 = load i32, ptr %l93, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l94
  br label %bb37
bb37:
  %t168 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t168, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t173 = load i64, ptr %l10, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t181, ptr %l101, !tbaa !27
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l12, !tbaa !23
  %t189 = load i32, ptr %l12, !tbaa !23
  %t191 = icmp ne i32 %t189, 0
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l12, !tbaa !23
  %t195 = load i64, ptr %l2, !tbaa !24
  %t197 = add i64 %t195, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t193, i32 %t194, i64 %t197)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  br label %bb74
bb48:
  %t205 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t207 = trunc i64 23 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t210 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t212 = trunc i64 22 to i32
  %t213 = icmp eq i32 %t210, %t212
  br i1 %t213, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/effects:Effects", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  store ptr %t220, ptr %l118, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/effects:Effects", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 2
  %t227 = load i32, ptr %l3, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l123
  br label %bb54
bb54:
  %t231 = load ptr, ptr %l118, !tbaa !29
  %t232 = load i32, ptr %l123, !tbaa !23
  %t233 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t231, i32 %t232)
  store { i64, ptr } %t233, ptr %l124
  br label %bb55
bb55:
  %t234 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t234, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  %t239 = load i64, ptr %l14, !tbaa !24
  %t240 = load i64, ptr %l15, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t247 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t247, ptr %l131, !tbaa !27
  %t248 = load i64, ptr %l14, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l2, !tbaa !24
  %t259 = add i64 %t257, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t255, i32 %t253, i64 %t259)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t263 = load i64, ptr %l14, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l14, !tbaa !24
  br label %bb56
bb62:
  br label %bb74
bb63:
  %t267 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t269 = trunc i64 19 to i32
  %t270 = icmp eq i32 %t267, %t269
  br i1 %t270, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l142, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/effects:Effects", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l3, !tbaa !23
  %t282 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t278, i32 %t279)
  store i32 %t282, ptr %l147
  br label %bb67
bb67:
  %t283 = load i64, ptr %l2, !tbaa !24
  %t285 = add i64 %t283, 1
  %t286 = load ptr, ptr %l142, !tbaa !29
  %t287 = load i32, ptr %l147, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t286, i32 %t287, i64 %t285)
  br label %bb68
bb68:
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_a95aecd22ff58df7_af716a2d87a126b3)
  unreachable
bb74:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eedge(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l20 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Effects", ptr %t16, i32 0, i32 15
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp eq i64 %t23, 2
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l11, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t27, i32 0, i32 18
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l20
  br label %bb12
bb12:
  %t34 = load i64, ptr %l20, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %t37, i64 %t38)
  br label %bb15
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 20
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t43, i64 %t44)
  store i1 %t47, ptr %l43
  br label %bb23
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 19
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l27
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Effects", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l31
  br label %bb17
bb17:
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = load i64, ptr %l31, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/effects:Effects", ptr %t66, i32 0, i32 19
  store ptr %t68, ptr %l34, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  store i64 %t69, ptr %l35, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Effects", ptr %t70, i32 0, i32 19
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l39
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb34
bb23:
  %t80 = load i1, ptr %l43, !tbaa !21
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/effects:Effects", ptr %t81, i32 0, i32 18
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l48
  br label %bb26
bb25:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/effects:Effects", ptr %t88, i32 0, i32 19
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l52
  br label %bb27
bb27:
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = icmp slt i64 %t95, %t96
  store i1 %t97, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t99 = load i1, ptr %l44, !tbaa !21
  br i1 %t99, label %bb29, label %bb30
bb29:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Effects", ptr %t100, i32 0, i32 19
  store ptr %t102, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  store i64 %t103, ptr %l56, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 18
  %t107 = load i64, ptr %l2, !tbaa !24
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l60
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = load i64, ptr %l56, !tbaa !24
  %t113 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t112, i64 %t113)
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb70
bb9:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 9
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb12, label %bb13
bb12:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t26, i32 0, i32 2
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 52}
  store i32 %t28, ptr %l2
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t32, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t36 = load i32, ptr %l2, !range !{i32 0, i32 52}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l33, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t57 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t48, ptr %t53)
  store i1 %t57, ptr %l36
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t58 = load i1, ptr %l36, !tbaa !21
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l31, !tbaa !21
  store i1 %t59, ptr %l12, !tbaa !21
  br label %bb70
bb22:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l37, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 18}
  %t67 = icmp eq i64 %t65, 17
  store i1 %t67, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t68 = load i1, ptr %l38, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t75, ptr %t76)
  store i1 %t80, ptr %l46
  br label %bb28
bb28:
  %t81 = load i1, ptr %l46, !tbaa !21
  store i1 %t81, ptr %l12, !tbaa !21
  br label %bb70
bb29:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = load ptr, ptr %l47, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 18}
  %t89 = icmp eq i64 %t87, 12
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb32, label %bb33
bb32:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Seq", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t104 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t97, ptr %t101)
  store i1 %t104, ptr %l56
  br label %bb35
bb35:
  %t105 = load i1, ptr %l56, !tbaa !21
  store i1 %t105, ptr %l12, !tbaa !21
  br label %bb70
bb36:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb37, label %bb38
bb37:
  %t110 = load ptr, ptr %l57, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 11
  store i1 %t113, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t114 = load i1, ptr %l58, !tbaa !21
  br i1 %t114, label %bb39, label %bb40
bb39:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l6, !tbaa !29
  br label %bb41
bb40:
  br label %bb47
bb41:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l6, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Cond", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t128 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t121, ptr %t125)
  store i1 %t128, ptr %l66
  br label %bb42
bb42:
  %t129 = load i1, ptr %l66, !tbaa !21
  br i1 %t129, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb46
bb44:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l6, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Cond", ptr %t131, i32 0, i32 2
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t138 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t130, ptr %t134)
  store i1 %t138, ptr %l72
  br label %bb45
bb45:
  %t139 = load i1, ptr %l72, !tbaa !21
  store i1 %t139, ptr %l67, !tbaa !21
  br label %bb46
bb46:
  %t140 = load i1, ptr %l67, !tbaa !21
  store i1 %t140, ptr %l12, !tbaa !21
  br label %bb70
bb47:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t142 = load ptr, ptr %l73, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb48, label %bb49
bb48:
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 18}
  %t148 = icmp eq i64 %t146, 13
  store i1 %t148, ptr %l74, !tbaa !21
  br label %bb49
bb49:
  %t149 = load i1, ptr %l74, !tbaa !21
  br i1 %t149, label %bb50, label %bb51
bb50:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l7, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t160 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earmsExisting(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  store i1 %t160, ptr %l81
  br label %bb53
bb53:
  %t161 = load i1, ptr %l81, !tbaa !21
  store i1 %t161, ptr %l12, !tbaa !21
  br label %bb70
bb54:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t163 = load ptr, ptr %l82, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb55, label %bb56
bb55:
  %t166 = load ptr, ptr %l82, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 18}
  %t169 = icmp eq i64 %t167, 14
  store i1 %t169, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t170 = load i1, ptr %l83, !tbaa !21
  br i1 %t170, label %bb57, label %bb58
bb57:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l8, !tbaa !29
  br label %bb59
bb58:
  br label %bb65
bb59:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l8, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Try", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t184 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexisting(ptr %v0, ptr %v1, ptr %t177, ptr %t181)
  store i1 %t184, ptr %l91
  br label %bb60
bb60:
  %t185 = load i1, ptr %l91, !tbaa !21
  br i1 %t185, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb64
bb62:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t190 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edefaultsExisting(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  store i1 %t190, ptr %l95
  br label %bb63
bb63:
  %t191 = load i1, ptr %l95, !tbaa !21
  store i1 %t191, ptr %l92, !tbaa !21
  br label %bb64
bb64:
  %t192 = load i1, ptr %l92, !tbaa !21
  store i1 %t192, ptr %l12, !tbaa !21
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_a0f9105d1bd497f9_bea5821deca669ad)
  unreachable
bb70:
  %t193 = load i1, ptr %l12, !tbaa !21
  store i1 %t193, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l97 = alloca i1
  %l98 = alloca ptr
  %l103 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca i1
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i1
  %l173 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l208 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i1
  %l275 = alloca { i64, ptr }
  %l285 = alloca ptr
  %l286 = alloca i1
  %l299 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l331 = alloca ptr
  %l332 = alloca i1
  %l351 = alloca { i64, ptr }
  %l358 = alloca ptr
  %l359 = alloca i1
  %l366 = alloca ptr
  %l367 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t6 = load ptr, ptr %l49, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l49, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l50, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l50, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t15 = load ptr, ptr %l53, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l53, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l54, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l54, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb208
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t24 = load ptr, ptr %l57, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l57, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l58, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l58, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereadOut(ptr %v0, ptr %v1, ptr %t44, ptr %t45, i32 %t46)
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i1 false)
  br label %bb20
bb20:
  br label %bb208
bb21:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t55 = load ptr, ptr %l70, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb22, label %bb23
bb22:
  %t58 = load ptr, ptr %l70, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l71, !tbaa !21
  br label %bb23
bb23:
  %t62 = load i1, ptr %l71, !tbaa !21
  br i1 %t62, label %bb24, label %bb25
bb24:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb30
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t70 = load ptr, ptr %l76, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l76, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 4
  store i1 %t76, ptr %l77, !tbaa !21
  br label %bb27
bb27:
  %t77 = load i1, ptr %l77, !tbaa !21
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i1 false)
  br label %bb31
bb31:
  br label %bb208
bb32:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t89 = load ptr, ptr %l84, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l84, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 5
  store i1 %t95, ptr %l85, !tbaa !21
  br label %bb34
bb34:
  %t96 = load i1, ptr %l85, !tbaa !21
  br i1 %t96, label %bb35, label %bb36
bb35:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l5, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Effects", ptr %t109, i32 0, i32 23
  %t112 = getelementptr %"compiler/effects:Facts", ptr %t111, i32 0, i32 0
  store i1 true, ptr %t112, !tbaa !21
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Effects", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l5, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l97
  br label %bb38
bb38:
  %t123 = load i1, ptr %l97, !tbaa !21
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l98, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/effects:Effects", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l103
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t135 = load ptr, ptr %l98, !tbaa !29
  %t136 = load i32, ptr %l103, !tbaa !23
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edropsCalled(ptr %v0, ptr %t135, i32 %t136, i64 0)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Promote", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t137, ptr %t141)
  br label %bb44
bb44:
  br label %bb208
bb45:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t146 = load ptr, ptr %l108, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb46, label %bb47
bb46:
  %t149 = load ptr, ptr %l108, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 16
  store i1 %t152, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t153 = load i1, ptr %l109, !tbaa !21
  br i1 %t153, label %bb48, label %bb49
bb48:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l7, !tbaa !29
  br label %bb50
bb49:
  br label %bb63
bb50:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/effects:Effects", ptr %t160, i32 0, i32 23
  %t163 = getelementptr %"compiler/effects:Facts", ptr %t162, i32 0, i32 0
  store i1 true, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Text", ptr %t164, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l10, !tbaa !24
  br label %bb51
bb51:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t181 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t181, ptr %l123, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr ptr, ptr %t185, i64 %t182
  %t187 = load ptr, ptr %t186, !tbaa !39
  store ptr %t187, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l11, !tbaa !29
  store ptr %t189, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t190 = load ptr, ptr %l126, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t193 = load ptr, ptr %l126, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 2}
  %t196 = icmp eq i64 %t194, 1
  store i1 %t196, ptr %l127, !tbaa !21
  br label %bb56
bb56:
  %t197 = load i1, ptr %l127, !tbaa !21
  br i1 %t197, label %bb57, label %bb58
bb57:
  %t198 = load ptr, ptr %l11, !tbaa !29
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { ptr }, ptr %t200, i32 0, i32 0
  %t202 = load ptr, ptr %t201
  %t204 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t204, ptr %t202)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l9, !tbaa !24
  br label %bb51
bb62:
  br label %bb208
bb63:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t214 = load ptr, ptr %l137, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb64, label %bb65
bb64:
  %t217 = load ptr, ptr %l137, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 18}
  %t220 = icmp eq i64 %t218, 8
  store i1 %t220, ptr %l138, !tbaa !21
  br label %bb65
bb65:
  %t221 = load i1, ptr %l138, !tbaa !21
  br i1 %t221, label %bb66, label %bb67
bb66:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l13, !tbaa !29
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/effects:Effects", ptr %t228, i32 0, i32 23
  %t231 = getelementptr %"compiler/effects:Facts", ptr %t230, i32 0, i32 0
  store i1 true, ptr %t231, !tbaa !21
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l13, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Collect", ptr %t233, i32 0, i32 0
  %t236 = load ptr, ptr %t235, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t232, ptr %t236)
  br label %bb69
bb69:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l13, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Collect", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v1, ptr %t239, ptr %t243)
  br label %bb70
bb70:
  br label %bb208
bb71:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t248 = load ptr, ptr %l151, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb72, label %bb73
bb72:
  %t251 = load ptr, ptr %l151, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 6
  store i1 %t254, ptr %l152, !tbaa !21
  br label %bb73
bb73:
  %t255 = load i1, ptr %l152, !tbaa !21
  br i1 %t255, label %bb74, label %bb75
bb74:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l14, !tbaa !23
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l15, !tbaa !29
  br label %bb76
bb75:
  br label %bb89
bb76:
  %t268 = load i32, ptr %l14, !tbaa !23
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t272 = icmp eq i32 %t268, %t269
  br i1 %t272, label %bb77, label %bb78
bb77:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/effects:Effects", ptr %t274, i32 0, i32 23
  %t277 = getelementptr %"compiler/effects:Facts", ptr %t276, i32 0, i32 16
  store i1 true, ptr %t277, !tbaa !21
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l15, !tbaa !29
  %t280 = load i32, ptr %l14, !tbaa !23
  %t284 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewCall(ptr %v0, ptr %v1, ptr %t278, ptr %t279, i32 %t280)
  store i1 %t284, ptr %l166
  br label %bb80
bb80:
  %t285 = load i1, ptr %l166, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/effects:Effects", ptr %t286, i32 0, i32 68
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 2
  %t292 = load i32, ptr %t291, !tbaa !23
  %t294 = sext i32 %t292 to i64
  %t297 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t288, i64 %t294)
  store i1 %t297, ptr %l173
  br label %bb83
bb82:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb84
bb83:
  %t298 = load i1, ptr %l173, !tbaa !21
  %t299 = xor i1 %t298, true
  store i1 %t299, ptr %l167, !tbaa !21
  br label %bb84
bb84:
  %t301 = load i1, ptr %l167, !tbaa !21
  br i1 %t301, label %bb85, label %bb86
bb85:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/effects:Effects", ptr %t302, i32 0, i32 23
  %t305 = getelementptr %"compiler/effects:Facts", ptr %t304, i32 0, i32 0
  store i1 true, ptr %t305, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %t306, ptr %t307)
  br label %bb88
bb88:
  br label %bb208
bb89:
  %t310 = load ptr, ptr %l1, !tbaa !29
  store ptr %t310, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t311 = load ptr, ptr %l178, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb90, label %bb91
bb90:
  %t314 = load ptr, ptr %l178, !tbaa !29
  %t315 = load i64, ptr %t314, !range !{i64 0, i64 18}
  %t317 = icmp eq i64 %t315, 7
  store i1 %t317, ptr %l179, !tbaa !21
  br label %bb91
bb91:
  %t318 = load i1, ptr %l179, !tbaa !21
  br i1 %t318, label %bb92, label %bb93
bb92:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t321, i32 0, i32 1
  %t323 = load i32, ptr %t322
  store i32 %t323, ptr %l16, !tbaa !23
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l17, !tbaa !29
  br label %bb94
bb93:
  br label %bb110
bb94:
  %t331 = load ptr, ptr %l17, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Make", ptr %t331, i32 0, i32 4
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t338 = icmp sge i64 %t336, 0
  br i1 %t338, label %bb95, label %bb96
bb95:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i32, ptr %l16, !tbaa !23
  %t342 = load ptr, ptr %l17, !tbaa !29
  %t346 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einPlace(ptr %v0, ptr %v1, ptr %t340, i32 %t341, ptr %t342)
  store i1 %t346, ptr %l194
  br label %bb97
bb96:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb98
bb97:
  %t347 = load i1, ptr %l194, !tbaa !21
  %t348 = xor i1 %t347, true
  store i1 %t348, ptr %l190, !tbaa !21
  br label %bb98
bb98:
  %t350 = load i1, ptr %l190, !tbaa !21
  br i1 %t350, label %bb99, label %bb100
bb99:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/effects:Effects", ptr %t351, i32 0, i32 23
  %t354 = getelementptr %"compiler/effects:Facts", ptr %t353, i32 0, i32 0
  store i1 true, ptr %t354, !tbaa !21
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l17, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Make", ptr %t356, i32 0, i32 3
  %t359 = load ptr, ptr %t358, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t355, ptr %t359)
  br label %bb102
bb102:
  %t362 = load ptr, ptr %l17, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Make", ptr %t362, i32 0, i32 2
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  store { i64, ptr } %t365, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t367 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t367, 0
  store i64 %t369, ptr %l20, !tbaa !24
  br label %bb103
bb103:
  %t371 = load i64, ptr %l19, !tbaa !24
  %t372 = load i64, ptr %l20, !tbaa !24
  %t375 = icmp slt i64 %t371, %t372
  %t377 = xor i1 %t375, true
  br i1 %t377, label %bb104, label %bb105
bb104:
  br label %bb109
bb105:
  br label %bb106
bb106:
  %t379 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t379, ptr %l208, !tbaa !27
  %t380 = load i64, ptr %l19, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr ptr, ptr %t383, i64 %t380
  %t385 = load ptr, ptr %t384, !tbaa !39
  %t387 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t387, ptr %t385)
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t392 = load i64, ptr %l19, !tbaa !24
  %t394 = add i64 %t392, 1
  store i64 %t394, ptr %l19, !tbaa !24
  br label %bb103
bb109:
  br label %bb208
bb110:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t397 = load ptr, ptr %l216, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb111, label %bb112
bb111:
  %t400 = load ptr, ptr %l216, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 18}
  %t403 = icmp eq i64 %t401, 9
  store i1 %t403, ptr %l217, !tbaa !21
  br label %bb112
bb112:
  %t404 = load i1, ptr %l217, !tbaa !21
  br i1 %t404, label %bb113, label %bb114
bb113:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t407, i32 0, i32 2
  %t409 = load i32, ptr %t408, !range !{i32 0, i32 52}
  store i32 %t409, ptr %l22
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t413, i32 0, i32 4
  %t415 = load { i64, ptr }, ptr %t414
  store { i64, ptr } %t415, ptr %l23, !tbaa !27
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l22, !range !{i32 0, i32 52}
  %t419 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %t417, i32 %t418, { i64, ptr } %t419)
  br label %bb116
bb116:
  br label %bb208
bb117:
  %t423 = load ptr, ptr %l1, !tbaa !29
  store ptr %t423, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t424 = load ptr, ptr %l227, !tbaa !29
  %t425 = icmp ne ptr %t424, null
  br i1 %t425, label %bb118, label %bb119
bb118:
  %t427 = load ptr, ptr %l227, !tbaa !29
  %t428 = load i64, ptr %t427, !range !{i64 0, i64 18}
  %t430 = icmp eq i64 %t428, 10
  store i1 %t430, ptr %l228, !tbaa !21
  br label %bb119
bb119:
  %t431 = load i1, ptr %l228, !tbaa !21
  br i1 %t431, label %bb120, label %bb121
bb120:
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr { i64, [5 x i64] }, ptr %t432, i32 0, i32 1
  %t435 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t434, i32 0, i32 2
  %t436 = load ptr, ptr %t435
  store ptr %t436, ptr %l24, !tbaa !29
  br label %bb122
bb121:
  br label %bb126
bb122:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l24, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Slice", ptr %t439, i32 0, i32 0
  %t442 = load ptr, ptr %t441, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %t438, ptr %t442, i1 false)
  br label %bb123
bb123:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l24, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Slice", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t445, ptr %t449)
  br label %bb124
bb124:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l24, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Slice", ptr %t454, i32 0, i32 2
  %t457 = load ptr, ptr %t456, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t453, ptr %t457)
  br label %bb125
bb125:
  br label %bb208
bb126:
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t462 = load ptr, ptr %l244, !tbaa !29
  %t463 = icmp ne ptr %t462, null
  br i1 %t463, label %bb127, label %bb128
bb127:
  %t465 = load ptr, ptr %l244, !tbaa !29
  %t466 = load i64, ptr %t465, !range !{i64 0, i64 18}
  %t468 = icmp eq i64 %t466, 11
  store i1 %t468, ptr %l245, !tbaa !21
  br label %bb128
bb128:
  %t469 = load i1, ptr %l245, !tbaa !21
  br i1 %t469, label %bb129, label %bb130
bb129:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t472, i32 0, i32 2
  %t474 = load ptr, ptr %t473
  store ptr %t474, ptr %l25, !tbaa !29
  br label %bb131
bb130:
  br label %bb135
bb131:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load ptr, ptr %l25, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Cond", ptr %t477, i32 0, i32 0
  %t480 = load ptr, ptr %t479, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t476, ptr %t480)
  br label %bb132
bb132:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load ptr, ptr %l25, !tbaa !29
  %t487 = getelementptr %"compiler/typed:Cond", ptr %t485, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t484, ptr %t488)
  br label %bb133
bb133:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l25, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Cond", ptr %t492, i32 0, i32 2
  %t495 = load ptr, ptr %t494, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t491, ptr %t495)
  br label %bb134
bb134:
  br label %bb208
bb135:
  %t499 = load ptr, ptr %l1, !tbaa !29
  store ptr %t499, ptr %l261, !tbaa !29
  store i1 false, ptr %l262, !tbaa !21
  %t500 = load ptr, ptr %l261, !tbaa !29
  %t501 = icmp ne ptr %t500, null
  br i1 %t501, label %bb136, label %bb137
bb136:
  %t503 = load ptr, ptr %l261, !tbaa !29
  %t504 = load i64, ptr %t503, !range !{i64 0, i64 18}
  %t506 = icmp eq i64 %t504, 12
  store i1 %t506, ptr %l262, !tbaa !21
  br label %bb137
bb137:
  %t507 = load i1, ptr %l262, !tbaa !21
  br i1 %t507, label %bb138, label %bb139
bb138:
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t510, i32 0, i32 2
  %t512 = load ptr, ptr %t511
  store ptr %t512, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb149
bb140:
  %t514 = load ptr, ptr %l26, !tbaa !29
  %t516 = getelementptr %"compiler/typed:Seq", ptr %t514, i32 0, i32 0
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  store { i64, ptr } %t517, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t519 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t519, 0
  store i64 %t521, ptr %l29, !tbaa !24
  br label %bb141
bb141:
  %t523 = load i64, ptr %l28, !tbaa !24
  %t524 = load i64, ptr %l29, !tbaa !24
  %t527 = icmp slt i64 %t523, %t524
  %t529 = xor i1 %t527, true
  br i1 %t529, label %bb142, label %bb143
bb142:
  br label %bb147
bb143:
  br label %bb144
bb144:
  %t531 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t531, ptr %l275, !tbaa !27
  %t532 = load i64, ptr %l28, !tbaa !24
  %t534 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = getelementptr ptr, ptr %t535, i64 %t532
  %t537 = load ptr, ptr %t536, !tbaa !39
  %t539 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t539, ptr %t537)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t543 = load i64, ptr %l28, !tbaa !24
  %t545 = add i64 %t543, 1
  store i64 %t545, ptr %l28, !tbaa !24
  br label %bb141
bb147:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l26, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Seq", ptr %t548, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t547, ptr %t551)
  br label %bb148
bb148:
  br label %bb208
bb149:
  %t554 = load ptr, ptr %l1, !tbaa !29
  store ptr %t554, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t555 = load ptr, ptr %l285, !tbaa !29
  %t556 = icmp ne ptr %t555, null
  br i1 %t556, label %bb150, label %bb151
bb150:
  %t558 = load ptr, ptr %l285, !tbaa !29
  %t559 = load i64, ptr %t558, !range !{i64 0, i64 18}
  %t561 = icmp eq i64 %t559, 13
  store i1 %t561, ptr %l286, !tbaa !21
  br label %bb151
bb151:
  %t562 = load i1, ptr %l286, !tbaa !21
  br i1 %t562, label %bb152, label %bb153
bb152:
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t565, i32 0, i32 2
  %t567 = load ptr, ptr %t566
  store ptr %t567, ptr %l31, !tbaa !29
  br label %bb154
bb153:
  br label %bb176
bb154:
  %t569 = load ptr, ptr %l31, !tbaa !29
  %t571 = getelementptr %"compiler/typed:Match", ptr %t569, i32 0, i32 0
  %t572 = load { i64, ptr }, ptr %t571, !tbaa !27
  store { i64, ptr } %t572, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t574 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t574, 0
  store i64 %t576, ptr %l34, !tbaa !24
  br label %bb155
bb155:
  %t578 = load i64, ptr %l33, !tbaa !24
  %t579 = load i64, ptr %l34, !tbaa !24
  %t582 = icmp slt i64 %t578, %t579
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb156, label %bb157
bb156:
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t586 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t586, ptr %l299, !tbaa !27
  %t587 = load i64, ptr %l33, !tbaa !24
  %t589 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr ptr, ptr %t590, i64 %t587
  %t592 = load ptr, ptr %t591, !tbaa !39
  %t594 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %t594, ptr %t592)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t598 = load i64, ptr %l33, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l33, !tbaa !24
  br label %bb155
bb161:
  %t602 = load ptr, ptr %l31, !tbaa !29
  %t604 = getelementptr %"compiler/typed:Match", ptr %t602, i32 0, i32 1
  %t605 = load { i64, ptr }, ptr %t604, !tbaa !27
  store { i64, ptr } %t605, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t607 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t609 = extractvalue { i64, ptr } %t607, 0
  store i64 %t609, ptr %l38, !tbaa !24
  br label %bb162
bb162:
  %t611 = load i64, ptr %l37, !tbaa !24
  %t612 = load i64, ptr %l38, !tbaa !24
  %t615 = icmp slt i64 %t611, %t612
  %t617 = xor i1 %t615, true
  br i1 %t617, label %bb163, label %bb164
bb163:
  br label %bb168
bb164:
  br label %bb165
bb165:
  %t619 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t619, ptr %l314, !tbaa !27
  %t620 = load i64, ptr %l37, !tbaa !24
  %t622 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr ptr, ptr %t623, i64 %t620
  %t625 = load ptr, ptr %t624, !tbaa !39
  %t627 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t627, ptr %t625)
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t631 = load i64, ptr %l37, !tbaa !24
  %t633 = add i64 %t631, 1
  store i64 %t633, ptr %l37, !tbaa !24
  br label %bb162
bb168:
  %t635 = load ptr, ptr %l31, !tbaa !29
  %t637 = getelementptr %"compiler/typed:Match", ptr %t635, i32 0, i32 2
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t640 = icmp eq ptr %t638, null
  %t642 = xor i1 %t640, true
  br i1 %t642, label %bb169, label %bb170
bb169:
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l325, !tbaa !29
  %t645 = load ptr, ptr %l31, !tbaa !29
  %t647 = getelementptr %"compiler/typed:Match", ptr %t645, i32 0, i32 2
  %t648 = load ptr, ptr %t647, !tbaa !29
  %t650 = icmp eq ptr %t648, null
  br i1 %t650, label %bb171, label %bb172
bb170:
  br label %bb175
bb171:
  call void @__olang_check_failed(ptr @olang_loc_949627fca0824f08_4c3b1084581425e4)
  unreachable
bb172:
  br label %bb173
bb173:
  %t652 = load ptr, ptr %l31, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Match", ptr %t652, i32 0, i32 2
  %t655 = load ptr, ptr %t654, !tbaa !29
  %t656 = load ptr, ptr %l325, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %t656, ptr %t655)
  br label %bb174
bb174:
  br label %bb175
bb175:
  br label %bb208
bb176:
  %t658 = load ptr, ptr %l1, !tbaa !29
  store ptr %t658, ptr %l331, !tbaa !29
  store i1 false, ptr %l332, !tbaa !21
  %t659 = load ptr, ptr %l331, !tbaa !29
  %t660 = icmp ne ptr %t659, null
  br i1 %t660, label %bb177, label %bb178
bb177:
  %t662 = load ptr, ptr %l331, !tbaa !29
  %t663 = load i64, ptr %t662, !range !{i64 0, i64 18}
  %t665 = icmp eq i64 %t663, 14
  store i1 %t665, ptr %l332, !tbaa !21
  br label %bb178
bb178:
  %t666 = load i1, ptr %l332, !tbaa !21
  br i1 %t666, label %bb179, label %bb180
bb179:
  %t667 = load ptr, ptr %l1, !tbaa !29
  %t669 = getelementptr { i64, [5 x i64] }, ptr %t667, i32 0, i32 1
  %t670 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t669, i32 0, i32 2
  %t671 = load ptr, ptr %t670
  store ptr %t671, ptr %l40, !tbaa !29
  br label %bb181
bb180:
  br label %bb193
bb181:
  %t673 = load ptr, ptr %l40, !tbaa !29
  %t675 = getelementptr %"compiler/typed:Try", ptr %t673, i32 0, i32 2
  %t676 = load i1, ptr %t675, !tbaa !21
  br i1 %t676, label %bb182, label %bb183
bb182:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/effects:Effects", ptr %t678, i32 0, i32 23
  %t681 = getelementptr %"compiler/effects:Facts", ptr %t680, i32 0, i32 16
  store i1 true, ptr %t681, !tbaa !21
  br label %bb184
bb183:
  br label %bb184
bb184:
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load ptr, ptr %l40, !tbaa !29
  %t685 = getelementptr %"compiler/typed:Try", ptr %t683, i32 0, i32 0
  %t686 = load ptr, ptr %t685, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t682, ptr %t686)
  br label %bb185
bb185:
  %t689 = load ptr, ptr %l40, !tbaa !29
  %t691 = getelementptr %"compiler/typed:Try", ptr %t689, i32 0, i32 1
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  store { i64, ptr } %t692, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t694 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t696 = extractvalue { i64, ptr } %t694, 0
  store i64 %t696, ptr %l43, !tbaa !24
  br label %bb186
bb186:
  %t698 = load i64, ptr %l42, !tbaa !24
  %t699 = load i64, ptr %l43, !tbaa !24
  %t702 = icmp slt i64 %t698, %t699
  %t704 = xor i1 %t702, true
  br i1 %t704, label %bb187, label %bb188
bb187:
  br label %bb192
bb188:
  br label %bb189
bb189:
  %t706 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t706, ptr %l351, !tbaa !27
  %t707 = load i64, ptr %l42, !tbaa !24
  %t709 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !27
  %t711 = getelementptr ptr, ptr %t710, i64 %t707
  %t712 = load ptr, ptr %t711, !tbaa !39
  %t714 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclause(ptr %v0, ptr %v1, ptr %t714, ptr %t712)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t718 = load i64, ptr %l42, !tbaa !24
  %t720 = add i64 %t718, 1
  store i64 %t720, ptr %l42, !tbaa !24
  br label %bb186
bb192:
  br label %bb208
bb193:
  %t722 = load ptr, ptr %l1, !tbaa !29
  store ptr %t722, ptr %l358, !tbaa !29
  store i1 false, ptr %l359, !tbaa !21
  %t723 = load ptr, ptr %l358, !tbaa !29
  %t724 = icmp ne ptr %t723, null
  br i1 %t724, label %bb194, label %bb195
bb194:
  %t726 = load ptr, ptr %l358, !tbaa !29
  %t727 = load i64, ptr %t726, !range !{i64 0, i64 18}
  %t729 = icmp eq i64 %t727, 15
  store i1 %t729, ptr %l359, !tbaa !21
  br label %bb195
bb195:
  %t730 = load i1, ptr %l359, !tbaa !21
  br i1 %t730, label %bb196, label %bb197
bb196:
  %t731 = load ptr, ptr %l1, !tbaa !29
  %t733 = getelementptr { i64, [5 x i64] }, ptr %t731, i32 0, i32 1
  %t734 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t733, i32 0, i32 2
  %t735 = load ptr, ptr %t734
  store ptr %t735, ptr %l45, !tbaa !29
  br label %bb198
bb197:
  br label %bb200
bb198:
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %t737, ptr %t738)
  br label %bb199
bb199:
  br label %bb208
bb200:
  %t741 = load ptr, ptr %l1, !tbaa !29
  store ptr %t741, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t742 = load ptr, ptr %l366, !tbaa !29
  %t743 = icmp ne ptr %t742, null
  br i1 %t743, label %bb201, label %bb202
bb201:
  %t745 = load ptr, ptr %l366, !tbaa !29
  %t746 = load i64, ptr %t745, !range !{i64 0, i64 18}
  %t748 = icmp eq i64 %t746, 17
  store i1 %t748, ptr %l367, !tbaa !21
  br label %bb202
bb202:
  %t749 = load i1, ptr %l367, !tbaa !21
  br i1 %t749, label %bb203, label %bb204
bb203:
  %t750 = load ptr, ptr %l1, !tbaa !29
  %t752 = getelementptr { i64, [5 x i64] }, ptr %t750, i32 0, i32 1
  %t753 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t752, i32 0, i32 2
  %t754 = load ptr, ptr %t753
  store ptr %t754, ptr %l46, !tbaa !29
  br label %bb205
bb204:
  br label %bb207
bb205:
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t757 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t756, ptr %t757)
  br label %bb206
bb206:
  br label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_ca5d43677e660e3e_842659f2ce3d2d4a)
  unreachable
bb208:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca %"compiler/effects:root"
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i64
  %l41 = alloca ptr
  %l47 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store %"compiler/effects:root" %t35, ptr %l19
  br label %bb10
bb10:
  %t36 = getelementptr %"compiler/effects:root", ptr %l19, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 17
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i64 %t58, ptr %l29
  br label %bb17
bb17:
  %t59 = load i64, ptr %l29, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 18}
  %t67 = icmp eq i64 %t65, 12
  store i1 %t67, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l31, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Seq", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l41, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Seq", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb26, label %bb27
bb25:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b6aab166389be830_fe1a1964ddaa5424)
  unreachable
bb27:
  br label %bb28
bb28:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l41, !tbaa !29
  %t98 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t96, ptr %t95)
  store i64 %t98, ptr %l47
  br label %bb29
bb29:
  %t99 = load i64, ptr %l47, !tbaa !24
  store i64 %t99, ptr %l40, !tbaa !24
  br label %bb30
bb30:
  %t100 = load i64, ptr %l40, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i64 -1, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_28b83159130c3f56_5f8d6e7786c968a)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlotOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca %"compiler/effects:fslot"
  %l48 = alloca i1
  %l51 = alloca %"compiler/effects:fslot"
  %l53 = alloca %"compiler/effects:fslot"
  %l56 = alloca i1
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l13
  br label %bb1
bb1:
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l4)
  store i64 %t10, ptr %l17
  br label %bb3
bb3:
  %t11 = load i64, ptr %l17, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l24, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s2, ptr %l4, i64 %t58)
  store %"compiler/effects:fslot" %t61, ptr %l44
  br label %bb14
bb14:
  %t62 = getelementptr %"compiler/effects:fslot", ptr %l44, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t67 = icmp eq i64 %t63, %a2
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %s0, ptr %l4, i64 %t69)
  store %"compiler/effects:fslot" %t72, ptr %l51
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb17:
  %t74 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %s2, ptr %l51)
  store %"compiler/effects:fslot" %t74, ptr %l53
  br label %bb18
bb18:
  %t75 = getelementptr %"compiler/effects:fslot", ptr %l53, i32 0, i32 1
  %t79 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %s0, ptr %v1, ptr %t75, ptr %a3)
  store i1 %t79, ptr %l56
  br label %bb19
bb19:
  %t80 = load i1, ptr %l56, !tbaa !21
  store i1 %t80, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l48, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l59
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l59, !tbaa !24
  %t90 = add i64 %t88, %t87
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t90, ptr %rv
  br label %ret
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb10
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldSlots(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/effects:fpath"
  %l16 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i32
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca %"compiler/typed:Local"
  %l69 = alloca i32
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"compiler/effects:fpath"
  %l83 = alloca %"compiler/effects:fpath"
  %l84 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca %"compiler/effects:fslot"
  %l95 = alloca %"compiler/effects:fslot"
  %l101 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 58
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H3f7eb4254a4c517352479452f11f6219(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load i1, ptr %l16, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 58
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc098dfa5961f28f78d4c086fb0a8b3d1(ptr %v0, ptr %v1, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t15, 1
  %t17 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l21
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %v1, ptr %l21)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l24
  br label %bb7
bb5:
  br label %bb6
bb6:
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l25
  br label %bb8
bb7:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb9
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %rv
  br label %ret
bb10:
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l26
  br label %bb11
bb11:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l30
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l30, !tbaa !29
  store ptr %t35, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 5
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l33
  br label %bb13
bb13:
  %t41 = load i64, ptr %l33, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb19
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l40, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  br label %bb47
bb22:
  br label %bb23
bb23:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l9, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l58, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l59, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 7
  store ptr %t92, ptr %l61, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 5
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t95, i64 %t96)
  store i32 %t99, ptr %l65
  br label %bb24
bb24:
  %t100 = load i32, ptr %l65, !tbaa !23
  %t101 = sext i32 %t100 to i64
  %t102 = load ptr, ptr %l61, !tbaa !29
  %t104 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t102, i64 %t101)
  store %"compiler/typed:Local" %t104, ptr %l67
  br label %bb25
bb25:
  %t105 = getelementptr %"compiler/typed:Local", ptr %l67, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t109 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %t107, i32 %t106)
  store i32 %t109, ptr %l69
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l58, !tbaa !29
  %t111 = load i32, ptr %l69, !tbaa !23
  %t112 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %s4, ptr %t110, i32 %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l70
  br label %bb27
bb27:
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %s4, ptr %l70)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l72
  br label %bb28
bb28:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  %t116 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t116
  store ptr %t116, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load i64, ptr %l11, !tbaa !24
  store i64 %t118, ptr %l74, !tbaa !24
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %s4, ptr %t119)
  store i64 %t121, ptr %l76
  br label %bb30
bb30:
  %t122 = load i64, ptr %l74, !tbaa !24
  %t123 = load i64, ptr %l76, !tbaa !24
  %t124 = icmp slt i64 %t122, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb32:
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = call %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %s4, ptr %s4, ptr %t128, i64 %t129)
  store %"compiler/effects:fpath" %t132, ptr %l81
  br label %bb34
bb34:
  %t134 = call %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %s5, ptr %l81)
  store %"compiler/effects:fpath" %t134, ptr %l83
  br label %bb35
bb35:
  %t135 = load %"compiler/effects:fpath", ptr %l83
  store %"compiler/effects:fpath" %t135, ptr %l12
  store ptr %l2, ptr %l84, !tbaa !29
  %t136 = load i64, ptr %l9, !tbaa !24
  store i64 %t136, ptr %l85, !tbaa !24
  %t137 = ptrtoint ptr %s5 to i64
  store i64 %t137, ptr %l86, !tbaa !24
  %t138 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3afslot_2e1
  br i1 %t138, label %bb36, label %bb37
bb36:
  %t140 = call ptr @__olang_region_make(ptr %s5)
  %t141 = ptrtoint ptr %t140 to i64
  store i64 %t141, ptr %l86, !tbaa !24
  br label %bb37
bb37:
  %t142 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 0
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l88
  %t144 = load i64, ptr %l86
  %t145 = inttoptr i64 %t144 to ptr
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %t145, ptr %l88)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l90
  br label %bb38
bb38:
  %t148 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3afslot_2e1
  br i1 %t148, label %bb39, label %bb40
bb39:
  %t150 = load i64, ptr %l86
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = call ptr @__olang_region_or(ptr %t154, ptr null)
  %t156 = call ptr @__olang_region_home(ptr %t155)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr null
  %t159 = icmp eq ptr %t158, %t151
  call void @__olang_region_settle(ptr %t151, i1 %t159)
  br label %bb40
bb40:
  %t160 = getelementptr %"compiler/effects:fpath", ptr %l12, i32 0, i32 1
  %t161 = load i32, ptr %t160, !tbaa !23
  %t162 = load i64, ptr %l85, !tbaa !24
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t165 = call %"compiler/effects:fslot" @compiler_2feffects_3afslot_2ector(ptr %s5, ptr %s5, i64 %t162, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, i32 %t161)
  store %"compiler/effects:fslot" %t165, ptr %l93
  br label %bb41
bb41:
  %t167 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %s5, ptr %l93)
  store %"compiler/effects:fslot" %t167, ptr %l95
  br label %bb42
bb42:
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = load %"compiler/effects:fslot", ptr %l95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ePush_3ccompiler_2feffects_3afslot_3e(ptr %v1, ptr %s5, ptr %t168, %"compiler/effects:fslot" %t169)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t170 = load i64, ptr %l11, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l11, !tbaa !24
  br label %bb29
bb45:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l8, !tbaa !24
  br label %bb20
bb47:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/effects:Effects", ptr %t178, i32 0, i32 58
  store ptr %t180, ptr %l101, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  store i64 %t181, ptr %l102, !tbaa !24
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l103
  %t184 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l103)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l105
  br label %bb48
bb48:
  %t185 = load ptr, ptr %l101, !tbaa !29
  %t186 = load i64, ptr %l102, !tbaa !24
  %t187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hafeff049746af34a0f4960f24da5119b(ptr %v0, ptr %s0, ptr %t185, i64 %t186, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187)
  br label %bb49
bb49:
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/effects:part"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/effects:pend"
  %l21 = alloca %"compiler/effects:pend"
  %l28 = alloca i64
  %l30 = alloca i1
  %l45 = alloca i64
  %l47 = alloca i64
  %l52 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca %"compiler/effects:part"
  %l69 = alloca %"compiler/effects:part"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 35
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l14
  br label %bb2
bb2:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/effects:pend" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eAt_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/effects:pend" %t19, ptr %l19
  br label %bb6
bb6:
  %t21 = call %"compiler/effects:pend" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apend(ptr %v0, ptr %l19)
  store %"compiler/effects:pend" %t21, ptr %l21
  br label %bb7
bb7:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store ptr %t22, ptr %lp3
  %t23 = load %"compiler/effects:pend", ptr %l21
  %t24 = load ptr, ptr %lp3
  store %"compiler/effects:pend" %t23, ptr %t24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %lp3
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresolve(ptr %v0, ptr %v0, ptr %t25, ptr %t26)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t33, i32 0, i32 40
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l28
  br label %bb11
bb11:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = icmp sgt i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 41
  %t44 = load i1, ptr %t43, !tbaa !21
  store i1 %t44, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutsJudged(ptr %v0, ptr %t47)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Effects", ptr %t49, i32 0, i32 63
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Effects", ptr %t55, i32 0, i32 33
  %t58 = load i64, ptr %t57, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretFields(ptr %v0, ptr %t54, i64 %t58)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Effects", ptr %t61, i32 0, i32 43
  %t64 = load i1, ptr %t63, !tbaa !21
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/effects:Effects", ptr %t68, i32 0, i32 46
  store i1 true, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/effects:Effects", ptr %t71, i32 0, i32 44
  store ptr %t73, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l45, !tbaa !24
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l47
  br label %bb27
bb27:
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = load i64, ptr %l47, !tbaa !24
  %t81 = icmp slt i64 %t79, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb28, label %bb29
bb28:
  br label %bb51
bb29:
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store ptr %t89, ptr %l52
  br label %bb31
bb31:
  %t90 = load ptr, ptr %l52, !tbaa !29
  store ptr %t90, ptr %l6, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t93)
  br label %bb32
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v0, ptr %t95, ptr %t96, i64 0)
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Effects", ptr %t100, i32 0, i32 36
  store ptr %t102, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  %t104 = load i64, ptr %l8, !tbaa !24
  store i64 %t104, ptr %l60, !tbaa !24
  %t105 = load ptr, ptr %l7, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %t105)
  store i64 %t107, ptr %l62
  br label %bb35
bb35:
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l62, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb36, label %bb37
bb36:
  br label %bb49
bb37:
  br label %bb38
bb38:
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store %"compiler/effects:part" %t118, ptr %l67
  br label %bb39
bb39:
  %t120 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %l67)
  store %"compiler/effects:part" %t120, ptr %l69
  br label %bb40
bb40:
  %t121 = load %"compiler/effects:part", ptr %l69
  store %"compiler/effects:part" %t121, ptr %l9
  %t122 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t127 = icmp eq i64 %t123, %t124
  br i1 %t127, label %bb41, label %bb42
bb41:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/effects:Effects", ptr %t129, i32 0, i32 45
  %t132 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t131, i64 %t133)
  br label %bb43
bb42:
  %t136 = getelementptr %"compiler/effects:part", ptr %l9, i32 0, i32 0
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  %t141 = icmp ne i64 %t137, %t138
  br i1 %t141, label %bb44, label %bb45
bb43:
  br label %bb47
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/effects:Effects", ptr %t143, i32 0, i32 46
  store i1 false, ptr %t145, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t146 = load i64, ptr %l8, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l8, !tbaa !24
  br label %bb34
bb49:
  br label %bb50
bb50:
  %t150 = load i64, ptr %l5, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l5, !tbaa !24
  br label %bb26
bb51:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:part" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/effects:part"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/effects:part"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l32 = alloca %"compiler/effects:part"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i32
  %l44 = alloca %"compiler/effects:part"
  %rv = alloca %"compiler/effects:part"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  store i64 %t16, ptr %l13, !tbaa !24
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l15, !tbaa !24
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t20)
  store i32 %t22, ptr %l17
  br label %bb6
bb6:
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t23, i64 %t24, i32 %t25, ptr null)
  store %"compiler/effects:part" %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load %"compiler/effects:part", ptr %l18
  store %"compiler/effects:part" %t27, ptr %l6
  br label %bb25
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 3}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t43 = load i64, ptr @G_2ecompiler_2feffects_2ePartLambda, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store i64 %t46, ptr %l27, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t47)
  store i32 %t49, ptr %l29
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = load i32, ptr %l29, !tbaa !23
  %t56 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v2, ptr %v3, i64 %t52, i64 %t53, i32 %t54, ptr %t50)
  store %"compiler/effects:part" %t56, ptr %l32
  br label %bb15
bb15:
  %t57 = load %"compiler/effects:part", ptr %l32
  store %"compiler/effects:part" %t57, ptr %l6
  br label %bb25
bb16:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 3}
  %t65 = icmp eq i64 %t63, 2
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { i32, ptr, i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t73 = load i64, ptr @G_2ecompiler_2feffects_2ePartAdapter, !tbaa !24
  store i64 %t73, ptr %l39, !tbaa !24
  %t74 = load i32, ptr %l5, !tbaa !23
  %t76 = sext i32 %t74 to i64
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t77)
  store i32 %t79, ptr %l43
  br label %bb22
bb22:
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i32, ptr %l43, !tbaa !23
  %t83 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t80, i64 %t81, i32 %t82, ptr null)
  store %"compiler/effects:part" %t83, ptr %l44
  br label %bb23
bb23:
  %t84 = load %"compiler/effects:part", ptr %l44
  store %"compiler/effects:part" %t84, ptr %l6
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e33fbd58e0454875_653468874e31cf21)
  unreachable
bb25:
  %t85 = load %"compiler/effects:part", ptr %l6
  store %"compiler/effects:part" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l49 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i64
  %l79 = alloca i64
  %l82 = alloca %"compiler/effects:pend"
  %l85 = alloca ptr
  %l86 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb47
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 3}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l20, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb38
bb11:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 23
  %t40 = getelementptr %"compiler/effects:Facts", ptr %t39, i32 0, i32 0
  store i1 true, ptr %t40, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Capture", ptr %t61, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t67)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l49
  br label %bb22
bb22:
  %t80 = load i64, ptr %l49, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/effects:Effects", ptr %t81, i32 0, i32 24
  %t84 = load i32, ptr %l2, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t83, i64 %t86)
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Effects", ptr %t89, i32 0, i32 42
  store i1 true, ptr %t91, !tbaa !21
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb25, label %bb26
bb25:
  br label %bb37
bb26:
  br label %bb27
bb27:
  %t106 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t106, ptr %l62, !tbaa !27
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  store ptr %t112, ptr %l12, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load ptr, ptr %l12, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Capture", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t118)
  store i32 %t120, ptr %l68
  br label %bb28
bb28:
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = load i32, ptr %l68, !tbaa !23
  %t123 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t123, ptr %l69
  br label %bb29
bb29:
  %t124 = load i1, ptr %l69, !tbaa !21
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/effects:Effects", ptr %t125, i32 0, i32 35
  store ptr %t127, ptr %l71, !tbaa !29
  %t128 = load i64, ptr %l8, !tbaa !24
  store i64 %t128, ptr %l72, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l2, !tbaa !23
  %t132 = sext i32 %t130 to i64
  %t133 = load ptr, ptr %l12, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Capture", ptr %t133, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t142 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %t129, i64 %t132, i64 %t138)
  store i64 %t142, ptr %l79
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t143 = load ptr, ptr %l12, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Capture", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l79, !tbaa !24
  %t150 = call %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v1, ptr %v0, i64 %t147, i64 %t148, ptr %t146)
  store %"compiler/effects:pend" %t150, ptr %l82
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l71, !tbaa !29
  %t152 = load %"compiler/effects:pend", ptr %l82
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v0, ptr %t151, %"compiler/effects:pend" %t152)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb24
bb37:
  br label %bb47
bb38:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t158 = load ptr, ptr %l85, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb39, label %bb40
bb39:
  %t161 = load ptr, ptr %l85, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 3}
  %t164 = icmp eq i64 %t162, 2
  store i1 %t164, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { i32, ptr, i32 }, ptr %t168, i32 0, i32 0
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l13, !tbaa !23
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [4 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { i32, ptr, i32 }, ptr %t174, i32 0, i32 1
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l14, !tbaa !29
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/effects:Effects", ptr %t178, i32 0, i32 42
  store i1 true, ptr %t180, !tbaa !21
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Effects", ptr %t181, i32 0, i32 23
  %t184 = getelementptr %"compiler/effects:Facts", ptr %t183, i32 0, i32 0
  store i1 true, ptr %t184, !tbaa !21
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t185, ptr %t186)
  br label %bb44
bb44:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/effects:Effects", ptr %t190, i32 0, i32 24
  %t193 = load i32, ptr %l13, !tbaa !23
  %t195 = sext i32 %t193 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t192, i64 %t195)
  br label %bb45
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d8634726df7208f7_383307572af5b0b3)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb39
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i1 %t29, ptr %l19
  br label %bb12
bb12:
  %t30 = load i1, ptr %l19, !tbaa !21
  store i1 %t30, ptr %l6, !tbaa !21
  br label %bb39
bb13:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 4
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Elem", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t46, ptr %t50)
  store i1 %t53, ptr %l29
  br label %bb19
bb19:
  %t54 = load i1, ptr %l29, !tbaa !21
  store i1 %t54, ptr %l6, !tbaa !21
  br label %bb39
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l31, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Payload", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  store i1 %t77, ptr %l39
  br label %bb26
bb26:
  %t78 = load i1, ptr %l39, !tbaa !21
  store i1 %t78, ptr %l6, !tbaa !21
  br label %bb39
bb27:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 8}
  %t86 = icmp eq i64 %t84, 2
  store i1 %t86, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t87 = load i1, ptr %l41, !tbaa !21
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t98 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eargGlobal(ptr %v0, ptr %v1, ptr %t94, ptr %t95)
  store i1 %t98, ptr %l48
  br label %bb33
bb33:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_994d18a8c74b163b_1372ae1002f7258f)
  unreachable
bb39:
  %t100 = load i1, ptr %l6, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2egrow(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"compiler/effects:Facts"
  %l27 = alloca ptr
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca ptr
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/effects:Facts"
  %l60 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l88 = alloca ptr
  %l102 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i64
  %l115 = alloca i64
  %l138 = alloca ptr
  %l143 = alloca ptr
  %l149 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 15
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l20
  br label %bb3
bb3:
  %t11 = load i64, ptr %l17, !tbaa !24
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 3
  store ptr %t19, ptr %l24, !tbaa !29
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t20, ptr %l25
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l24, !tbaa !29
  %t22 = load %"compiler/effects:Facts", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t21, %"compiler/effects:Facts" %t22)
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Effects", ptr %t23, i32 0, i32 4
  store ptr %t25, ptr %l27, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l28
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l27, !tbaa !29
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s1, ptr %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/effects:Effects", ptr %t29, i32 0, i32 5
  store ptr %t31, ptr %l30, !tbaa !29
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l31
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l30, !tbaa !29
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s1, ptr %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34)
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 6
  store ptr %t37, ptr %l33, !tbaa !29
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l34
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l33, !tbaa !29
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %s1, ptr %t39, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40)
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 9
  store ptr %t43, ptr %l36, !tbaa !29
  %t44 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s1)
  store %"compiler/effects:Facts" %t44, ptr %l37
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l36, !tbaa !29
  %t46 = load %"compiler/effects:Facts", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t45, %"compiler/effects:Facts" %t46)
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 0)
  br label %bb17
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t51, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t53, i64 -1)
  br label %bb18
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Effects", ptr %t55, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t57, i64 -1)
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/effects:Effects", ptr %t59, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t61, i1 false)
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 0)
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/effects:Effects", ptr %t67, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 -1)
  br label %bb22
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/effects:Effects", ptr %t71, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 0)
  br label %bb23
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t77, i1 false)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb25:
  br label %bb1
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 52
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Effects", ptr %t86, i32 0, i32 52
  store i1 true, ptr %t88, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Effects", ptr %t89, i32 0, i32 1
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l60
  br label %bb29
bb28:
  br label %bb47
bb29:
  %t94 = load i64, ptr %l60, !tbaa !24
  store i64 %t94, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb30, label %bb31
bb30:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb35
bb32:
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l67, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb34
bb34:
  %t121 = load i64, ptr %l67, !tbaa !24
  store i64 %t121, ptr %l64, !tbaa !24
  br label %bb35
bb35:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb36
bb36:
  %t123 = load i64, ptr %l5, !tbaa !24
  %t124 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb37, label %bb38
bb37:
  br label %bb46
bb38:
  br label %bb39
bb39:
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i64, ptr %l5, !tbaa !24
  %t133 = load i64, ptr %l3, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l6, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/effects:Effects", ptr %t141, i32 0, i32 1
  %t144 = load i64, ptr %l6, !tbaa !24
  %t147 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t143, i64 %t144)
  store ptr %t147, ptr %l88
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l88, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Body", ptr %t148, i32 0, i32 1
  %t151 = load { i64, [2 x i64] }, ptr %t150
  store { i64, [2 x i64] } %t151, ptr %l7
  %t153 = load { i64, [2 x i64] }, ptr %l7
  %t155 = extractvalue { i64, [2 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 3
  br i1 %t156, label %bb41, label %bb42
bb41:
  %t158 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t159 = getelementptr { i32 }, ptr %t158, i32 0, i32 0
  %t160 = load i32, ptr %t159
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/effects:Effects", ptr %t162, i32 0, i32 54
  %t166 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t164, i32 %t160, i64 %t166)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t170 = load i64, ptr %l5, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l5, !tbaa !24
  br label %bb36
bb46:
  br label %bb47
bb47:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/effects:Effects", ptr %t174, i32 0, i32 16
  %t178 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l102
  br label %bb48
bb48:
  %t179 = load i64, ptr %l102, !tbaa !24
  %t180 = icmp eq i64 %t179, 0
  br i1 %t180, label %bb49, label %bb50
bb49:
  store i64 0, ptr %l9, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/effects:Effects", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/load:Loader", ptr %t188, i32 0, i32 10
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t190)
  store i64 %t192, ptr %l108
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t193 = load i64, ptr %l108, !tbaa !24
  store i64 %t193, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb52, label %bb53
bb52:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb57
bb54:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l9, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l11, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l11, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l115, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb56
bb56:
  %t220 = load i64, ptr %l115, !tbaa !24
  store i64 %t220, ptr %l112, !tbaa !24
  br label %bb57
bb57:
  %t221 = load i64, ptr %l112, !tbaa !24
  store i64 %t221, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb59, label %bb60
bb59:
  br label %bb69
bb60:
  br label %bb61
bb61:
  %t230 = load i64, ptr %l9, !tbaa !24
  %t231 = load i64, ptr %l13, !tbaa !24
  %t232 = load i64, ptr %l11, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l14, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/effects:Effects", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 0
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = getelementptr %"compiler/load:Loader", ptr %t246, i32 0, i32 10
  %t249 = load i64, ptr %l14, !tbaa !24
  %t252 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t248, i64 %t249)
  store ptr %t252, ptr %l138
  br label %bb62
bb62:
  %t253 = load ptr, ptr %l138, !tbaa !29
  %t255 = getelementptr %"compiler/load:Module", ptr %t253, i32 0, i32 4
  %t256 = load i64, ptr %t255, !tbaa !24
  %t258 = icmp sge i64 %t256, 0
  br i1 %t258, label %bb63, label %bb64
bb63:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/effects:Effects", ptr %t260, i32 0, i32 16
  store ptr %t262, ptr %l143, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/effects:Effects", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t266, i32 0, i32 0
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = getelementptr %"compiler/load:Loader", ptr %t269, i32 0, i32 10
  %t272 = load i64, ptr %l14, !tbaa !24
  %t275 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t271, i64 %t272)
  store ptr %t275, ptr %l149
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t276 = load ptr, ptr %l149, !tbaa !29
  %t278 = getelementptr %"compiler/load:Module", ptr %t276, i32 0, i32 4
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t281, i64 %t279, i64 %t280)
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t284 = load i64, ptr %l13, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l13, !tbaa !24
  br label %bb58
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeType(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/effects:Facts"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/effects:Facts"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca i64
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store i32 %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/effects:Effects", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t6, i32 %t7)
  store %"compiler/effects:Facts" %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load %"compiler/effects:Facts", ptr %l16
  store %"compiler/effects:Facts" %t11, ptr %l4
  %t12 = getelementptr %"compiler/effects:Facts", ptr %l4, i32 0, i32 15
  store i1 false, ptr %t12, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  store i64 %t62, ptr %l43, !tbaa !24
  %t63 = load i64, ptr %l43, !tbaa !24
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = shl i64 1, %t64
  store i64 %t65, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l11, !tbaa !24
  %t71 = and i64 %a2, %t68
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb16
bb13:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %s0, ptr %s2, ptr %l4, i64 %t75)
  store { i64, ptr } %t78, ptr %l52
  br label %bb14
bb14:
  %t79 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t87, ptr %l54
  br label %bb15
bb15:
  %t88 = load i1, ptr %l54, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l3, !tbaa !29
  store ptr %t90, ptr %l55, !tbaa !29
  %t91 = ptrtoint ptr %v1 to i64
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t92, label %bb20, label %bb21
bb20:
  %t94 = call ptr @__olang_region_make_part(ptr %v1)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t96
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  store { i64, ptr } %t99, ptr %l60, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l61, !tbaa !24
  %t103 = load i64, ptr %l61, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = load i64, ptr %l56
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_held_alloc(ptr %t106, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l62, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l61, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t116, label %bb22, label %bb23
bb22:
  %t118 = load i64, ptr %l56
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load { i64, ptr }, ptr %l62
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  %t125 = icmp eq ptr %t124, %t119
  call void @__olang_region_settle(ptr %t119, i1 %t125)
  br label %bb23
bb23:
  %t126 = load ptr, ptr %l55, !tbaa !29
  %t127 = getelementptr %"compiler/effects:Verdict", ptr %t126, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l64, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t130 = load ptr, ptr %l55, !tbaa !29
  %t131 = getelementptr %"compiler/effects:Verdict", ptr %t130, i32 0, i32 0
  store { i64, ptr } %t129, ptr %t131, !tbaa !27
  %t132 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aVerdict_2e0
  br i1 %t132, label %bb24, label %bb25
bb24:
  %t134 = load { i64, ptr }, ptr %l64
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  call void @__olang_region_release_part(ptr %t136, i64 %t135)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %bb25
bb25:
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t139 = getelementptr %"compiler/effects:Verdict", ptr %t137, i32 0, i32 2
  store i1 false, ptr %t139, !tbaa !21
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = getelementptr %"compiler/effects:Verdict", ptr %t140, i32 0, i32 3
  store i32 %t141, ptr %t144, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l9, !tbaa !24
  br label %bb8
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgedParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %l7 = alloca ptr
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/effects:part"
  %l21 = alloca %"compiler/effects:part"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/effects:part"
  %l28 = alloca %"compiler/effects:part"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/effects:part"
  %l43 = alloca %"compiler/effects:part"
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/effects:part" %t19, ptr %l19
  br label %bb7
bb7:
  %t21 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v1, ptr %l19)
  store %"compiler/effects:part" %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load %"compiler/effects:part", ptr %l21
  store %"compiler/effects:part" %t22, ptr %l6
  %t23 = getelementptr %"compiler/effects:part", ptr %l6, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t28 = icmp ne i64 %t24, %t25
  br i1 %t28, label %bb9, label %bb10
bb9:
  store ptr %l3, ptr %l25, !tbaa !29
  %t30 = load %"compiler/effects:part", ptr %l6
  store %"compiler/effects:part" %t30, ptr %l26
  %t32 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v2, ptr %l26)
  store %"compiler/effects:part" %t32, ptr %l28
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load %"compiler/effects:part", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %t33, %"compiler/effects:part" %t34)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb13:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %s2, ptr %v2, ptr %a0, i64 %a1, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l32
  br label %bb14
bb14:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %t42
  store ptr %t42, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l8, !tbaa !24
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load ptr, ptr %l7, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %t45)
  store i64 %t47, ptr %l36
  br label %bb16
bb16:
  %t48 = load i64, ptr %l34, !tbaa !24
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = call %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %t54, i64 %t55)
  store %"compiler/effects:part" %t58, ptr %l41
  br label %bb20
bb20:
  %t60 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v2, ptr %l41)
  store %"compiler/effects:part" %t60, ptr %l43
  br label %bb21
bb21:
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t61, ptr %lp9
  %t62 = load %"compiler/effects:part", ptr %l43
  %t63 = load ptr, ptr %lp9
  store %"compiler/effects:part" %t62, ptr %t63
  %t64 = load ptr, ptr %lp9
  %t65 = load %"compiler/effects:part", ptr %t64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v2, ptr %v2, ptr %l3, %"compiler/effects:part" %t65)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb15
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb2
bb26:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2emutGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/effects:pair"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l11 = alloca %"compiler/effects:pair"
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l30 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca %"compiler/names:Entry"
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"compiler/effects:pair" %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"compiler/effects:pair", ptr %l11
  store %"compiler/effects:pair" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 17
  %t12 = load %"compiler/effects:pair", ptr %l3
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H7835af935af759534f3892df019d3666(ptr %v0, ptr %t11, %"compiler/effects:pair" %t12)
  store i1 %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 17
  %t20 = load %"compiler/effects:pair", ptr %l3
  %t23 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H5e2f333902255d77192898689554d128(ptr %v0, ptr %t19, %"compiler/effects:pair" %t20)
  %t24 = extractvalue { i32, i1 } %t23, 1
  %t25 = extractvalue { i32, i1 } %t23, 0
  store i32 %t25, ptr %l21
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb6, label %ok.27, !prof !99
ok.27:
  store i1 %t24, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l16, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb9:
  store i1 false, ptr %l4, !tbaa !21
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l1, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 1
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 1
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l37
  br label %bb16
bb15:
  br label %bb31
bb16:
  %t64 = load ptr, ptr %l37, !tbaa !29
  %t66 = getelementptr %"compiler/names:Table", ptr %t64, i32 0, i32 0
  store ptr %t66, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l42
  br label %bb18
bb18:
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb19, label %bb20
bb19:
  br label %bb30
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/names:Entry" %t82, ptr %l47
  br label %bb22
bb22:
  %t83 = load %"compiler/names:Entry", ptr %l47
  store %"compiler/names:Entry" %t83, ptr %l7
  %t84 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 3
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l6, !tbaa !24
  br label %bb17
bb30:
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/effects:Effects", ptr %t99, i32 0, i32 17
  %t102 = load %"compiler/effects:pair", ptr %l3
  %t103 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %t101, %"compiler/effects:pair" %t102, i1 %t103)
  br label %bb32
bb32:
  %t107 = load i1, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2enamed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l17 = alloca %"compiler/effects:Facts"
  %l21 = alloca %"compiler/effects:Facts"
  %l25 = alloca i64
  %l28 = alloca i64
  %l48 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca %"compiler/effects:Facts"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/effects:Facts"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 9
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/effects:Facts" %t17, ptr %l17
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/effects:Facts", ptr %l17
  store %"compiler/effects:Facts" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/effects:Effects", ptr %t19, i32 0, i32 9
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/effects:Facts" %t25, ptr %l21
  br label %bb6
bb6:
  %t26 = load %"compiler/effects:Facts", ptr %l21
  store %"compiler/effects:Facts" %t26, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 63, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb12
bb9:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l28, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %l25, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l25, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 22
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = call i1 @compiler_2feffects_2ehasBit(i64 %t74, i64 %t75)
  store i1 %t78, ptr %l48
  br label %bb17
bb17:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/effects:Effects", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t92 = call i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %t86, i64 %t87, i64 %t88)
  store i32 %t92, ptr %l56
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t94 = load i32, ptr %l56, !tbaa !23
  %t95 = call %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %t93, i32 %t94)
  store %"compiler/effects:Facts" %t95, ptr %l57
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s4, ptr %t96, ptr %l57)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb13
bb25:
  %t102 = load %"compiler/effects:Facts", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/effects:Facts" %t102, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eonStack(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i1
  %l28 = alloca i64
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i32
  %l92 = alloca i32
  %l97 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i32
  %l110 = alloca i1
  %l115 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l127 = alloca i1
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l12, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  store ptr %t12, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 5
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t20 = load i1, ptr %l16, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/source:Span", ptr %t27
  store %"compiler/source:Span" %t28, ptr %l4
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l28
  br label %bb6
bb6:
  %t45 = load i64, ptr %l28, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l8, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l8, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb11
bb11:
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l46
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp sge i64 %t83, %t86
  br i1 %t89, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb16
bb14:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = load i64, ptr %l2, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t96, i32 %t103)
  store i1 %t106, ptr %l58
  br label %bb15
bb15:
  %t107 = load i1, ptr %l58, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t110 = load i1, ptr %l51, !tbaa !21
  br i1 %t110, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb18:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/effects:Effects", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t117, ptr %l64, !tbaa !27
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t116, i32 %t123)
  store i64 %t126, ptr %l67
  br label %bb19
bb19:
  %t127 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t128 = load i64, ptr %l67, !tbaa !24
  %t130 = and i64 %t128, %t127
  %t132 = icmp ne i64 %t130, 0
  store i1 %t132, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t134 = load i1, ptr %l60, !tbaa !21
  br i1 %t134, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/effects:Effects", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  store ptr %t141, ptr %l74, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/effects:Effects", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l8, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l79
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l74, !tbaa !29
  %t153 = load i32, ptr %l79, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t152, i32 %t153)
  store i1 %t154, ptr %l80
  br label %bb25
bb25:
  %t155 = load i1, ptr %l80, !tbaa !21
  br i1 %t155, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/effects:Effects", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l5, !tbaa !23
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l86
  br label %bb29
bb29:
  %t167 = load i1, ptr %l86, !tbaa !21
  br i1 %t167, label %bb30, label %bb31
bb30:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/effects:Effects", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l5, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l92
  br label %bb32
bb31:
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t178, ptr %l87, !tbaa !23
  br label %bb33
bb32:
  %t180 = load i32, ptr %l92, !tbaa !23
  store i32 %t180, ptr %l87, !tbaa !23
  br label %bb33
bb33:
  %t181 = load i32, ptr %l87, !tbaa !23
  store i32 %t181, ptr %l10, !tbaa !23
  %t182 = load i32, ptr %l10, !tbaa !23
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t186 = icmp eq i32 %t182, %t183
  br i1 %t186, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb38
bb35:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/effects:Effects", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  store ptr %t193, ptr %l100, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/effects:Effects", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %l10, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l105
  br label %bb36
bb36:
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t205 = load i32, ptr %l105, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l106
  br label %bb37
bb37:
  %t207 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t209 = trunc i64 18 to i32
  %t210 = icmp eq i32 %t207, %t209
  %t212 = xor i1 %t210, true
  store i1 %t212, ptr %l97, !tbaa !21
  br label %bb38
bb38:
  %t214 = load i1, ptr %l97, !tbaa !21
  br i1 %t214, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb42
bb40:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/effects:Effects", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l10, !tbaa !23
  %t224 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t220, i32 %t221)
  store i1 %t224, ptr %l115
  br label %bb41
bb41:
  %t225 = load i1, ptr %l115, !tbaa !21
  store i1 %t225, ptr %l110, !tbaa !21
  br label %bb42
bb42:
  %t226 = load i1, ptr %l110, !tbaa !21
  br i1 %t226, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/effects:Effects", ptr %t228, i32 0, i32 0
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l10, !tbaa !23
  %t237 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l121
  br label %bb46
bb46:
  %t238 = load i1, ptr %l121, !tbaa !21
  br i1 %t238, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb50
bb48:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/effects:Effects", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l10, !tbaa !23
  %t248 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t244, i32 %t245)
  store i1 %t248, ptr %l127
  br label %bb49
bb49:
  %t249 = load i1, ptr %l127, !tbaa !21
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb50
bb50:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb51, label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/effects:Effects", ptr %t252, i32 0, i32 65
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/effects:Effects", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/effects:Effects", ptr %t261, i32 0, i32 1
  %t264 = load i64, ptr %l7, !tbaa !24
  %t265 = load i64, ptr %l2, !tbaa !24
  %t271 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v0, ptr %v0, ptr %t254, ptr %t260, ptr %t263, i64 %t264, i64 %t265)
  store i1 %t271, ptr %l138
  br label %bb54
bb54:
  %t272 = load i1, ptr %l138, !tbaa !21
  store i1 %t272, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca %"compiler/effects:root"
  %l11 = alloca i1
  %l12 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/effects:root" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  %t19 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  store i64 %t19, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 29
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb9
bb9:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Effects", ptr %t30, i32 0, i32 30
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t32, i64 %t33)
  store i1 %t36, ptr %l22
  br label %bb12
bb12:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/effects:Effects", ptr %t40, i32 0, i32 41
  store i1 true, ptr %t42, !tbaa !21
  %t43 = load i64, ptr @G_2ecompiler_2feffects_2eoutLocal, !tbaa !24
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = sub i64 %t43, %t44
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassWrites(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/effects:link"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/effects:link"
  %l40 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i64
  %l65 = alloca %"compiler/effects:Facts"
  %l68 = alloca i1
  %l76 = alloca %"compiler/effects:Facts"
  %l79 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l91 = alloca ptr
  %l104 = alloca %"compiler/effects:Facts"
  %l107 = alloca i64
  %l109 = alloca i64
  %l114 = alloca i64
  %l119 = alloca ptr
  %l129 = alloca %"compiler/effects:Facts"
  %l132 = alloca i1
  %l137 = alloca %"compiler/effects:Facts"
  %l138 = alloca i64
  %l140 = alloca i64
  %l145 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %s1, ptr %t3, i64 %t4)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l26
  br label %bb1
bb1:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  store ptr %t11, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l30, !tbaa !24
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb4
bb4:
  %t17 = load i64, ptr %l30, !tbaa !24
  %t18 = load i64, ptr %l32, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb74
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = call %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %s1, ptr %t23, i64 %t24)
  store %"compiler/effects:link" %t27, ptr %l37
  br label %bb8
bb8:
  %t28 = load %"compiler/effects:link", ptr %l37
  store %"compiler/effects:link" %t28, ptr %l7
  %t29 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp slt i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb10:
  %t34 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l41, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 1
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l44
  br label %bb11
bb11:
  %t41 = load i64, ptr %l41, !tbaa !24
  %t42 = load i64, ptr %l44, !tbaa !24
  %t43 = icmp sge i64 %t41, %t42
  store i1 %t43, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l40, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb16
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/effects:Effects", ptr %t46, i32 0, i32 15
  %t49 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t50)
  store i64 %t53, ptr %l50
  br label %bb15
bb15:
  %t54 = load i64, ptr %l50, !tbaa !24
  %t55 = icmp slt i64 %t54, 1
  store i1 %t55, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l46, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %bb73
bb18:
  br label %bb19
bb19:
  %t59 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %a3, i64 %t60)
  store i1 %t63, ptr %l54
  br label %bb20
bb20:
  %t64 = load i1, ptr %l54, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb24
bb22:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/effects:Effects", ptr %t65, i32 0, i32 15
  %t68 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t69)
  store i64 %t72, ptr %l59
  br label %bb23
bb23:
  %t73 = load i64, ptr %l59, !tbaa !24
  %t74 = icmp eq i64 %t73, 2
  store i1 %t74, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t76 = load i1, ptr %l55, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb25, label %bb26
bb25:
  br label %bb73
bb26:
  br label %bb27
bb27:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/effects:Effects", ptr %t79, i32 0, i32 9
  %t82 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t86 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t81, i64 %t83)
  store %"compiler/effects:Facts" %t86, ptr %l65
  br label %bb28
bb28:
  %t87 = getelementptr %"compiler/effects:Facts", ptr %l65, i32 0, i32 21
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  %t93 = call i1 @compiler_2feffects_2ehasBit(i64 %t88, i64 %t90)
  store i1 %t93, ptr %l68
  br label %bb29
bb29:
  %t94 = load i1, ptr %l68, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb30, label %bb31
bb30:
  br label %bb73
bb31:
  br label %bb32
bb32:
  %t97 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load i64, ptr @G_2ecompiler_2feffects_2eglobalParam, !tbaa !24
  %t102 = icmp eq i64 %t98, %t99
  br i1 %t102, label %bb33, label %bb34
bb33:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/effects:Effects", ptr %t104, i32 0, i32 9
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t106, i64 %t107)
  store %"compiler/effects:Facts" %t110, ptr %l76
  br label %bb35
bb34:
  br label %bb48
bb35:
  %t111 = getelementptr %"compiler/effects:Facts", ptr %l76, i32 0, i32 3
  %t112 = load i1, ptr %t111, !tbaa !21
  br i1 %t112, label %bb36, label %bb37
bb36:
  br label %bb73
bb37:
  br label %bb38
bb38:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l79, !tbaa !24
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb40
bb40:
  %t120 = load i64, ptr %l79, !tbaa !24
  %t121 = load i64, ptr %l81, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l86
  br label %bb44
bb44:
  %t131 = load i64, ptr %l86, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/effects:Effects", ptr %t134, i32 0, i32 9
  %t140 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t131)
  store ptr %t140, ptr %l91
  br label %bb45
bb45:
  %t141 = load ptr, ptr %l91, !tbaa !29
  %t143 = load i1, ptr %l12, !tbaa !21
  %t146 = getelementptr %"compiler/effects:Facts", ptr %t141, i32 0, i32 3
  store i1 %t143, ptr %t146, !tbaa !21
  br label %bb46
bb46:
  %t147 = load i64, ptr %l9, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l9, !tbaa !24
  br label %bb39
bb47:
  %t151 = load i64, ptr %l4, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l4, !tbaa !24
  br label %bb73
bb48:
  %t155 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t156 = load i64, ptr %t155, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2feffects_2eoutParam, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb49, label %bb50
bb49:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/effects:Effects", ptr %t162, i32 0, i32 9
  %t165 = load i64, ptr %l1, !tbaa !24
  %t168 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t164, i64 %t165)
  store %"compiler/effects:Facts" %t168, ptr %l104
  br label %bb51
bb50:
  br label %bb64
bb51:
  %t169 = getelementptr %"compiler/effects:Facts", ptr %l104, i32 0, i32 17
  %t170 = load i1, ptr %t169, !tbaa !21
  br i1 %t170, label %bb52, label %bb53
bb52:
  br label %bb73
bb53:
  br label %bb54
bb54:
  %t172 = load ptr, ptr %l2, !tbaa !29
  store ptr %t172, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb55
bb55:
  %t174 = load i64, ptr %l15, !tbaa !24
  store i64 %t174, ptr %l107, !tbaa !24
  %t175 = load ptr, ptr %l14, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t175)
  store i64 %t177, ptr %l109
  br label %bb56
bb56:
  %t178 = load i64, ptr %l107, !tbaa !24
  %t179 = load i64, ptr %l109, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t184 = load ptr, ptr %l14, !tbaa !29
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t184, i64 %t185)
  store i64 %t188, ptr %l114
  br label %bb60
bb60:
  %t189 = load i64, ptr %l114, !tbaa !24
  store i1 true, ptr %l18, !tbaa !21
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/effects:Effects", ptr %t192, i32 0, i32 9
  %t198 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t194, i64 %t189)
  store ptr %t198, ptr %l119
  br label %bb61
bb61:
  %t199 = load ptr, ptr %l119, !tbaa !29
  %t201 = load i1, ptr %l18, !tbaa !21
  %t204 = getelementptr %"compiler/effects:Facts", ptr %t199, i32 0, i32 17
  store i1 %t201, ptr %t204, !tbaa !21
  br label %bb62
bb62:
  %t205 = load i64, ptr %l15, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l15, !tbaa !24
  br label %bb55
bb63:
  %t209 = load i64, ptr %l4, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l4, !tbaa !24
  br label %bb73
bb64:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/effects:Effects", ptr %t213, i32 0, i32 9
  %t216 = load i64, ptr %l1, !tbaa !24
  %t219 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t215, i64 %t216)
  store %"compiler/effects:Facts" %t219, ptr %l129
  br label %bb65
bb65:
  %t220 = getelementptr %"compiler/effects:Facts", ptr %l129, i32 0, i32 21
  %t221 = load i64, ptr %t220, !tbaa !24
  %t222 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t223 = load i64, ptr %t222, !tbaa !24
  %t226 = call i1 @compiler_2feffects_2ehasBit(i64 %t221, i64 %t223)
  store i1 %t226, ptr %l132
  br label %bb66
bb66:
  %t227 = load i1, ptr %l132, !tbaa !21
  br i1 %t227, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t228 = load i64, ptr %l1, !tbaa !24
  store i64 %t228, ptr %l20, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/effects:Effects", ptr %t230, i32 0, i32 9
  %t233 = load i64, ptr %l1, !tbaa !24
  %t236 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t232, i64 %t233)
  store %"compiler/effects:Facts" %t236, ptr %l137
  br label %bb70
bb70:
  %t237 = getelementptr %"compiler/effects:Facts", ptr %l137, i32 0, i32 21
  %t238 = load i64, ptr %t237, !tbaa !24
  store i64 %t238, ptr %l138, !tbaa !24
  %t239 = getelementptr %"compiler/effects:link", ptr %l7, i32 0, i32 2
  %t240 = load i64, ptr %t239, !tbaa !24
  %t242 = call i64 @compiler_2feffects_2eparamBit(i64 %t240)
  store i64 %t242, ptr %l140
  br label %bb71
bb71:
  %t243 = load i64, ptr %l138, !tbaa !24
  %t244 = load i64, ptr %l140, !tbaa !24
  %t245 = or i64 %t243, %t244
  store i64 %t245, ptr %l21, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/effects:Effects", ptr %t247, i32 0, i32 9
  %t250 = load i64, ptr %l20, !tbaa !24
  %t253 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t249, i64 %t250)
  store ptr %t253, ptr %l145
  br label %bb72
bb72:
  %t254 = load ptr, ptr %l145, !tbaa !29
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = getelementptr %"compiler/effects:Facts", ptr %t254, i32 0, i32 21
  store i64 %t256, ptr %t259, !tbaa !24
  %t260 = load i64, ptr %l4, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l4, !tbaa !24
  br label %bb73
bb73:
  %t264 = load i64, ptr %l6, !tbaa !24
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l6, !tbaa !24
  br label %bb3
bb74:
  call void @__olang_scope_close(ptr %s1)
  %t268 = load i64, ptr %l4, !tbaa !24
  store i64 %t268, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb57
bb10:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t36, i32 0, i32 3
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l3, !tbaa !23
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2emutGlobal(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i1 %t46, ptr %l28
  br label %bb16
bb16:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 23
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t50, i32 0, i32 4
  store i1 true, ptr %t51, !tbaa !21
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb57
bb20:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb21, label %bb22
bb21:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 8}
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb22
bb22:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb23, label %bb24
bb23:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb26
bb26:
  br label %bb57
bb27:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb28, label %bb29
bb28:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 3
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb33
bb33:
  br label %bb57
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t92 = load ptr, ptr %l47, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 4
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l48, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Elem", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t106, ptr %t110)
  br label %bb40
bb40:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Elem", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t113, ptr %t117)
  br label %bb41
bb41:
  br label %bb57
bb42:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t122 = load ptr, ptr %l60, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t125 = load ptr, ptr %l60, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l61, !tbaa !21
  br label %bb44
bb44:
  %t129 = load i1, ptr %l61, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Payload", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceParts(ptr %v0, ptr %v1, ptr %t136, ptr %t140)
  br label %bb48
bb48:
  br label %bb57
bb49:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t144 = load ptr, ptr %l69, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb50, label %bb51
bb50:
  %t147 = load ptr, ptr %l69, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 8}
  %t150 = icmp eq i64 %t148, 6
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb51
bb51:
  %t151 = load i1, ptr %l70, !tbaa !21
  br i1 %t151, label %bb52, label %bb53
bb52:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l8, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb55
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8e774b84f9d07387_321b570aadbfd9f3)
  unreachable
bb57:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/effects:root"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca %"compiler/effects:root"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca %"compiler/effects:root"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca %"compiler/effects:root"
  %l37 = alloca i64
  %l39 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca %"compiler/effects:root"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca %"compiler/effects:root"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l66 = alloca i64
  %l68 = alloca %"compiler/effects:root"
  %l69 = alloca %"compiler/effects:root"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/effects:root"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t20 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s1, i64 %t18, i1 false)
  store %"compiler/effects:root" %t20, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t21 = load %"compiler/effects:root", ptr %l17
  store %"compiler/effects:root" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store %"compiler/effects:root" %t41, ptr %l26
  br label %bb13
bb13:
  %t42 = load %"compiler/effects:root", ptr %l26
  store %"compiler/effects:root" %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb27
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Elem", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store %"compiler/effects:root" %t65, ptr %l36
  br label %bb20
bb20:
  %t66 = load %"compiler/effects:root", ptr %l36
  store %"compiler/effects:root" %t66, ptr %l5
  %t67 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = getelementptr %"compiler/effects:root", ptr %l5, i32 0, i32 1
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Effects", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Elem", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t81)
  store i32 %t83, ptr %l45
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = load i32, ptr %l45, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l46
  br label %bb24
bb24:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i64, ptr %l37, !tbaa !24
  %t89 = load i1, ptr %l39, !tbaa !21
  %t90 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s3, i64 %t88, i1 %t89)
  store %"compiler/effects:root" %t90, ptr %l47
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t91 = load %"compiler/effects:root", ptr %l47
  store %"compiler/effects:root" %t91, ptr %rv
  br label %ret
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 5
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Payload", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t107, ptr %t111)
  store %"compiler/effects:root" %t114, ptr %l57
  br label %bb33
bb33:
  %t115 = load %"compiler/effects:root", ptr %l57
  store %"compiler/effects:root" %t115, ptr %rv
  br label %ret
bb34:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 8}
  %t123 = icmp eq i64 %t121, 2
  store i1 %t123, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t124 = load i1, ptr %l59, !tbaa !21
  br i1 %t124, label %bb37, label %bb38
bb37:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l7, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t135 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexprRoot(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  store i64 %t135, ptr %l66
  br label %bb40
bb40:
  %t136 = load i64, ptr %l66, !tbaa !24
  %t139 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s5, i64 %t136, i1 true)
  store %"compiler/effects:root" %t139, ptr %l68
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  %t140 = load %"compiler/effects:root", ptr %l68
  store %"compiler/effects:root" %t140, ptr %rv
  br label %ret
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = call %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %s6, i64 -1, i1 false)
  store %"compiler/effects:root" %t141, ptr %l69
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  %t142 = load %"compiler/effects:root", ptr %l69
  store %"compiler/effects:root" %t142, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_def19e55677a13ff_78d59d2dfbb79d83)
  unreachable
ret:
  %rr = load %"compiler/effects:root", ptr %rv
  ret %"compiler/effects:root" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/effects:given"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l21 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/effects:part"
  %l35 = alloca %"compiler/effects:part"
  %l40 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l66 = alloca %"compiler/effects:part"
  %l73 = alloca i1
  %l77 = alloca i1
  %l80 = alloca ptr
  %l84 = alloca %"compiler/effects:part"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca i32
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca %"compiler/effects:given"
  %l107 = alloca i1
  %l124 = alloca ptr
  %l128 = alloca %"compiler/effects:part"
  %l132 = alloca i1
  %l136 = alloca i1
  %l138 = alloca ptr
  %l141 = alloca %"compiler/effects:part"
  %l147 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca i64
  %l153 = alloca i64
  %l158 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca %"compiler/effects:part"
  %l166 = alloca ptr
  %l170 = alloca %"compiler/effects:part"
  %l175 = alloca ptr
  %l179 = alloca %"compiler/effects:part"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/effects:part", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/effects:part", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feffects_2eGivMade, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/effects:part", ptr %t20, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l4, !tbaa !29
  store ptr %t30, ptr %l31, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = load %"compiler/effects:part", ptr %t31
  store %"compiler/effects:part" %t33, ptr %l33
  %t35 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v3, ptr %l33)
  store %"compiler/effects:part" %t35, ptr %l35
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l31, !tbaa !29
  %t37 = load %"compiler/effects:part", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t36, %"compiler/effects:part" %t37)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/effects:part", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/effects:Effects", ptr %t47, i32 0, i32 8
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/effects:part", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t49, i64 %t53)
  store i1 %t56, ptr %l45
  br label %bb14
bb13:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb15
bb14:
  %t57 = load i1, ptr %l45, !tbaa !21
  store i1 %t57, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l40, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/effects:part", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s3, ptr %t59, i64 %t63)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l49
  br label %bb18
bb17:
  br label %bb30
bb18:
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s3, ptr %l49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l51
  br label %bb19
bb19:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t70 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  store ptr %t70, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l53, !tbaa !24
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t73)
  store i64 %t75, ptr %l55
  br label %bb21
bb21:
  %t76 = load i64, ptr %l53, !tbaa !24
  %t77 = load i64, ptr %l55, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb25
bb25:
  %t87 = load i64, ptr %l60, !tbaa !24
  %t88 = load ptr, ptr %l4, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/effects:part", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t98 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t89, i64 %t87, i32 %t94, ptr null)
  store %"compiler/effects:part" %t98, ptr %l66
  br label %bb26
bb26:
  %t99 = load ptr, ptr %l61, !tbaa !29
  %t100 = load %"compiler/effects:part", ptr %l66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t99, %"compiler/effects:part" %t100)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb20
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = getelementptr %"compiler/effects:part", ptr %t105, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t112 = icmp ne i64 %t108, %t109
  br i1 %t112, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb33
bb32:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/effects:given", ptr %t114, i32 0, i32 6
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = icmp slt i64 %t117, 0
  store i1 %t119, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t121 = load i1, ptr %l73, !tbaa !21
  br i1 %t121, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb36
bb35:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = icmp sgt i64 %t122, 4
  store i1 %t124, ptr %l77, !tbaa !21
  br label %bb36
bb36:
  %t126 = load i1, ptr %l77, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t127 = load ptr, ptr %l4, !tbaa !29
  store ptr %t127, ptr %l80, !tbaa !29
  %t128 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/effects:part", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %t131, !tbaa !23
  %t135 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t128, i64 0, i32 %t132, ptr null)
  store %"compiler/effects:part" %t135, ptr %l84
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t136 = load ptr, ptr %l80, !tbaa !29
  %t137 = load %"compiler/effects:part", ptr %l84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t136, %"compiler/effects:part" %t137)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  store i1 false, ptr %l9, !tbaa !21
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/effects:Effects", ptr %t138, i32 0, i32 7
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  %t145 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t144, 1
  %t146 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t144, 0
  store i32 %t146, ptr %l90
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb43, label %ok.148, !prof !99
ok.148:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l89
  br label %bb42
bb42:
  %t150 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l89)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l92
  br label %bb45
bb43:
  br label %bb44
bb44:
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l93
  br label %bb46
bb45:
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l85
  br label %bb47
bb46:
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l85
  br label %bb47
bb47:
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load i64, ptr %l12, !tbaa !24
  store i64 %t156, ptr %l95, !tbaa !24
  %t157 = load ptr, ptr %l11, !tbaa !29
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %t157)
  store i64 %t159, ptr %l97
  br label %bb49
bb49:
  %t160 = load i64, ptr %l95, !tbaa !24
  %t161 = load i64, ptr %l97, !tbaa !24
  %t162 = icmp slt i64 %t160, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb96
bb51:
  br label %bb52
bb52:
  %t166 = load ptr, ptr %l11, !tbaa !29
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = call %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %s0, ptr %t166, i64 %t167)
  store %"compiler/effects:given" %t170, ptr %l102
  br label %bb53
bb53:
  %t171 = load %"compiler/effects:given", ptr %l102
  store %"compiler/effects:given" %t171, ptr %l13
  %t172 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 0
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/effects:given", ptr %t174, i32 0, i32 6
  %t177 = load i64, ptr %t176, !tbaa !24
  %t180 = icmp ne i64 %t173, %t177
  br i1 %t180, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb56
bb55:
  %t182 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 1
  %t183 = load i64, ptr %t182, !tbaa !24
  %t184 = load ptr, ptr %l3, !tbaa !29
  %t186 = getelementptr %"compiler/effects:part", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = icmp ne i64 %t183, %t187
  store i1 %t190, ptr %l107, !tbaa !21
  br label %bb56
bb56:
  %t192 = load i1, ptr %l107, !tbaa !21
  br i1 %t192, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb58:
  br label %bb59
bb59:
  store i1 true, ptr %l9, !tbaa !21
  %t193 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t194 = load i64, ptr %t193, !tbaa !24
  %t195 = load i64, ptr @G_2ecompiler_2feffects_2eGivResField, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  br i1 %t198, label %bb60, label %bb61
bb60:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i64, ptr %l1, !tbaa !24
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t203 = load i64, ptr %l5, !tbaa !24
  %t205 = add i64 %t203, 1
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %s8, ptr %v3, ptr %t200, i64 %t201, ptr %l13, ptr %t202, i64 %t205)
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb63:
  %t211 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t212 = load i64, ptr %t211, !tbaa !24
  %t213 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t216 = icmp eq i64 %t212, %t213
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t218 = load ptr, ptr %l4, !tbaa !29
  store ptr %t218, ptr %l124, !tbaa !29
  %t219 = load i64, ptr @G_2ecompiler_2feffects_2eGivSlot, !tbaa !24
  %t220 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t221 = load i64, ptr %t220, !tbaa !24
  %t222 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t223 = load i32, ptr %t222, !tbaa !23
  %t227 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t219, i64 %t221, i32 %t223, ptr null)
  store %"compiler/effects:part" %t227, ptr %l128
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t228 = load ptr, ptr %l124, !tbaa !29
  %t229 = load %"compiler/effects:part", ptr %l128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t228, %"compiler/effects:part" %t229)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb68:
  %t230 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t231 = load i64, ptr %t230, !tbaa !24
  %t232 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t235 = icmp eq i64 %t231, %t232
  br i1 %t235, label %bb69, label %bb70
bb69:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/effects:Effects", ptr %t237, i32 0, i32 8
  %t240 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t241 = load i64, ptr %t240, !tbaa !24
  %t244 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t239, i64 %t241)
  store i1 %t244, ptr %l136
  br label %bb71
bb70:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb72
bb71:
  %t245 = load i1, ptr %l136, !tbaa !21
  %t246 = xor i1 %t245, true
  store i1 %t246, ptr %l132, !tbaa !21
  br label %bb72
bb72:
  %t248 = load i1, ptr %l132, !tbaa !21
  br i1 %t248, label %bb73, label %bb74
bb73:
  %t249 = load ptr, ptr %l4, !tbaa !29
  store ptr %t249, ptr %l138, !tbaa !29
  %t250 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t251 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t252 = load i32, ptr %t251, !tbaa !23
  %t255 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t250, i64 0, i32 %t252, ptr null)
  store %"compiler/effects:part" %t255, ptr %l141
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t256 = load ptr, ptr %l138, !tbaa !29
  %t257 = load %"compiler/effects:part", ptr %l141
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t256, %"compiler/effects:part" %t257)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb77:
  %t258 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t259 = load i64, ptr %t258, !tbaa !24
  %t260 = load i64, ptr @G_2ecompiler_2feffects_2eGivResult, !tbaa !24
  %t263 = icmp eq i64 %t259, %t260
  br i1 %t263, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t267 = load i64, ptr %t266, !tbaa !24
  %t270 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %s14, ptr %t265, i64 %t267)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t270, ptr %l147
  br label %bb80
bb79:
  br label %bb92
bb80:
  %t272 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s14, ptr %l147)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %l149
  br label %bb81
bb81:
  %t273 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  %t274 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %t274
  store ptr %t274, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb82
bb82:
  %t276 = load i64, ptr %l15, !tbaa !24
  store i64 %t276, ptr %l151, !tbaa !24
  %t277 = load ptr, ptr %l14, !tbaa !29
  %t279 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t277)
  store i64 %t279, ptr %l153
  br label %bb83
bb83:
  %t280 = load i64, ptr %l151, !tbaa !24
  %t281 = load i64, ptr %l153, !tbaa !24
  %t282 = icmp slt i64 %t280, %t281
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t286 = load ptr, ptr %l14, !tbaa !29
  %t287 = load i64, ptr %l15, !tbaa !24
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t286, i64 %t287)
  store i64 %t290, ptr %l158
  br label %bb87
bb87:
  %t291 = load i64, ptr %l158, !tbaa !24
  %t292 = load ptr, ptr %l4, !tbaa !29
  store ptr %t292, ptr %l159, !tbaa !29
  %t293 = load i64, ptr @G_2ecompiler_2feffects_2eGivNamed, !tbaa !24
  %t295 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t296 = load i32, ptr %t295, !tbaa !23
  %t300 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t293, i64 %t291, i32 %t296, ptr null)
  store %"compiler/effects:part" %t300, ptr %l163
  br label %bb88
bb88:
  %t301 = load ptr, ptr %l159, !tbaa !29
  %t302 = load %"compiler/effects:part", ptr %l163
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t301, %"compiler/effects:part" %t302)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t303 = load i64, ptr %l15, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l15, !tbaa !24
  br label %bb82
bb91:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb92:
  %t307 = load ptr, ptr %l4, !tbaa !29
  store ptr %t307, ptr %l166, !tbaa !29
  %t308 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 2
  %t309 = load i64, ptr %t308, !tbaa !24
  %t310 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 3
  %t311 = load i64, ptr %t310, !tbaa !24
  %t312 = getelementptr %"compiler/effects:given", ptr %l13, i32 0, i32 4
  %t313 = load i32, ptr %t312, !tbaa !23
  %t317 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t309, i64 %t311, i32 %t313, ptr null)
  store %"compiler/effects:part" %t317, ptr %l170
  br label %bb93
bb93:
  %t318 = load ptr, ptr %l166, !tbaa !29
  %t319 = load %"compiler/effects:part", ptr %l170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t318, %"compiler/effects:part" %t319)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s8)
  br label %bb95
bb95:
  %t320 = load i64, ptr %l12, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l12, !tbaa !24
  br label %bb48
bb96:
  %t324 = load i1, ptr %l9, !tbaa !21
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb97, label %bb98
bb97:
  %t328 = load ptr, ptr %l4, !tbaa !29
  store ptr %t328, ptr %l175, !tbaa !29
  %t329 = load i64, ptr @G_2ecompiler_2feffects_2eGivBound, !tbaa !24
  %t330 = load ptr, ptr %l3, !tbaa !29
  %t332 = getelementptr %"compiler/effects:part", ptr %t330, i32 0, i32 2
  %t333 = load i32, ptr %t332, !tbaa !23
  %t336 = call %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v3, ptr %v3, i64 %t329, i64 0, i32 %t333, ptr null)
  store %"compiler/effects:part" %t336, ptr %l179
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t337 = load ptr, ptr %l175, !tbaa !29
  %t338 = load %"compiler/effects:part", ptr %l179
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v3, ptr %v3, ptr %t337, %"compiler/effects:part" %t338)
  br label %bb100
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretsOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/effects:Effects", ptr %a0, i32 0, i32 8
  %t7 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %v0, ptr %v1, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t7, 1
  %t9 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  br label %bb1
bb1:
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l9
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l10
  br label %bb5
bb4:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l2
  br label %bb6
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l2
  br label %bb6
bb6:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t57, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Arm", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  br label %bb16
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanAssigned(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 55
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/effects:Effects", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l14, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 11
  %t37 = load ptr, ptr %t36, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v0, ptr %t33, ptr %t37)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l2, !tbaa !24
  br label %bb1
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l161 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l183 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t17 = load ptr, ptr %l29, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l29, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l30, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t32 = load ptr, ptr %l35, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l35, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 15
  store i1 %t38, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l36, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb14
bb14:
  br label %bb117
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l44, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 17}
  %t58 = icmp eq i64 %t56, 1
  store i1 %t58, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l45, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  br label %bb22
bb22:
  br label %bb117
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t82 = load ptr, ptr %l57, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l57, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 3
  store i1 %t88, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t89 = load i1, ptr %l58, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb29
bb29:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/typed:If", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb30
bb30:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/typed:If", ptr %t113, i32 0, i32 2
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb117
bb32:
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t120 = load ptr, ptr %l74, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l74, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 17}
  %t126 = icmp eq i64 %t124, 4
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb35, label %bb36
bb35:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l6, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  br label %bb38
bb38:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb39
bb39:
  br label %bb117
bb40:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 17}
  %t156 = icmp eq i64 %t154, 6
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb42
bb42:
  %t157 = load i1, ptr %l88, !tbaa !21
  br i1 %t157, label %bb43, label %bb44
bb43:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l8, !tbaa !29
  br label %bb49
bb44:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t165 = load ptr, ptr %l93, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 17}
  %t171 = icmp eq i64 %t169, 16
  store i1 %t171, ptr %l94, !tbaa !21
  br label %bb46
bb46:
  %t172 = load i1, ptr %l94, !tbaa !21
  br i1 %t172, label %bb47, label %bb48
bb47:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb50
bb50:
  br label %bb117
bb51:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t184 = load ptr, ptr %l101, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb52, label %bb53
bb52:
  %t187 = load ptr, ptr %l101, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 11
  store i1 %t190, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t191 = load i1, ptr %l102, !tbaa !21
  br i1 %t191, label %bb54, label %bb55
bb54:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb60
bb55:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t199 = load ptr, ptr %l107, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t202 = load ptr, ptr %l107, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 17}
  %t205 = icmp eq i64 %t203, 12
  store i1 %t205, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t206 = load i1, ptr %l108, !tbaa !21
  br i1 %t206, label %bb58, label %bb59
bb58:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb61
bb61:
  br label %bb117
bb62:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t219 = load ptr, ptr %l116, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t222 = load ptr, ptr %l116, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 17}
  %t225 = icmp eq i64 %t223, 10
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l117, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l10, !tbaa !29
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l11, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb68
bb68:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t244, ptr %t245)
  br label %bb69
bb69:
  br label %bb117
bb70:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t249 = load ptr, ptr %l129, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t252 = load ptr, ptr %l129, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 17}
  %t255 = icmp eq i64 %t253, 9
  store i1 %t255, ptr %l130, !tbaa !21
  br label %bb72
bb72:
  %t256 = load i1, ptr %l130, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l12, !tbaa !29
  br label %bb79
bb74:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t264 = load ptr, ptr %l135, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb75, label %bb76
bb75:
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i64, ptr %t267, !range !{i64 0, i64 17}
  %t270 = icmp eq i64 %t268, 8
  store i1 %t270, ptr %l136, !tbaa !21
  br label %bb76
bb76:
  %t271 = load i1, ptr %l136, !tbaa !21
  br i1 %t271, label %bb77, label %bb78
bb77:
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t274, i32 0, i32 1
  %t276 = load ptr, ptr %t275
  store ptr %t276, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t278, ptr %t279)
  br label %bb80
bb80:
  br label %bb117
bb81:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t283 = load ptr, ptr %l143, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb82, label %bb83
bb82:
  %t286 = load ptr, ptr %l143, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 17}
  %t289 = icmp eq i64 %t287, 13
  store i1 %t289, ptr %l144, !tbaa !21
  br label %bb83
bb83:
  %t290 = load i1, ptr %l144, !tbaa !21
  br i1 %t290, label %bb84, label %bb85
bb84:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr }, ptr %t293, i32 0, i32 1
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l13, !tbaa !29
  br label %bb86
bb85:
  br label %bb95
bb86:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Join", ptr %t298, i32 0, i32 0
  %t301 = load ptr, ptr %t300, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t297, ptr %t301)
  br label %bb87
bb87:
  %t305 = load ptr, ptr %l13, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Join", ptr %t305, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  store i64 %t312, ptr %l16, !tbaa !24
  br label %bb88
bb88:
  %t314 = load i64, ptr %l15, !tbaa !24
  %t315 = load i64, ptr %l16, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb89, label %bb90
bb89:
  br label %bb94
bb90:
  br label %bb91
bb91:
  %t322 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t322, ptr %l161, !tbaa !27
  %t323 = load i64, ptr %l15, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr ptr, ptr %t326, i64 %t323
  %t328 = load ptr, ptr %t327, !tbaa !39
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t334 = load ptr, ptr %t333, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t337 = load i64, ptr %l15, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l15, !tbaa !24
  br label %bb88
bb94:
  br label %bb117
bb95:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t342 = load ptr, ptr %l169, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb96, label %bb97
bb96:
  %t345 = load ptr, ptr %l169, !tbaa !29
  %t346 = load i64, ptr %t345, !range !{i64 0, i64 17}
  %t348 = icmp eq i64 %t346, 14
  store i1 %t348, ptr %l170, !tbaa !21
  br label %bb97
bb97:
  %t349 = load i1, ptr %l170, !tbaa !21
  br i1 %t349, label %bb98, label %bb99
bb98:
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr }, ptr %t352, i32 0, i32 1
  %t354 = load ptr, ptr %t353
  store ptr %t354, ptr %l18, !tbaa !29
  br label %bb100
bb99:
  br label %bb112
bb100:
  %t356 = load ptr, ptr %l18, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Spawn", ptr %t356, i32 0, i32 0
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  store { i64, ptr } %t359, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l21, !tbaa !24
  br label %bb101
bb101:
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l21, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb102, label %bb103
bb102:
  br label %bb110
bb103:
  br label %bb104
bb104:
  %t373 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t373, ptr %l183, !tbaa !27
  %t374 = load i64, ptr %l20, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr ptr, ptr %t377, i64 %t374
  %t379 = load ptr, ptr %t378, !tbaa !39
  store ptr %t379, ptr %l22, !tbaa !29
  %t381 = load ptr, ptr %l22, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb105, label %bb106
bb105:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t391 = load i64, ptr %l20, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l20, !tbaa !24
  br label %bb101
bb110:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l18, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Spawn", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %t395, ptr %t399)
  br label %bb111
bb111:
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_376d296af4c830bb_f1e6df173964d75f)
  unreachable
bb117:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:Facts"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/effects:Facts"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i1
  %l40 = alloca %"compiler/effects:Facts"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i64
  %l56 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l74 = alloca %"compiler/effects:Facts"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca i64
  %l122 = alloca i1
  %l123 = alloca i64
  %l126 = alloca i64
  %l130 = alloca i1
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca %"compiler/effects:Facts"
  %l148 = alloca i64
  %l157 = alloca ptr
  %l161 = alloca %"compiler/effects:Facts"
  %l169 = alloca i64
  %l171 = alloca i64
  %l176 = alloca i64
  %l181 = alloca %"compiler/effects:Facts"
  %l186 = alloca %"compiler/effects:Facts"
  %l195 = alloca i64
  %l197 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l208 = alloca i64
  %l212 = alloca i64
  %l220 = alloca i64
  %l222 = alloca i64
  %l227 = alloca i64
  %l229 = alloca ptr
  %l230 = alloca i64
  %l234 = alloca %"compiler/effects:Facts"
  %l236 = alloca ptr
  %l237 = alloca i64
  %l241 = alloca %"compiler/effects:Facts"
  %l243 = alloca i1
  %l247 = alloca i64
  %l249 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i1
  %l261 = alloca i1
  %l262 = alloca i1
  %l265 = alloca i1
  %l272 = alloca i64
  %l274 = alloca i64
  %l279 = alloca i64
  %l285 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t1, ptr %l40
  br label %bb1
bb1:
  %t2 = load %"compiler/effects:Facts", ptr %l40
  store %"compiler/effects:Facts" %t2, ptr %l2
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l41
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l43, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l45
  br label %bb4
bb4:
  %t11 = load i64, ptr %l43, !tbaa !24
  %t12 = load i64, ptr %l45, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l50
  br label %bb8
bb8:
  %t22 = load i64, ptr %l50, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t22, i1 true)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l5, !tbaa !24
  br label %bb3
bb11:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l56
  br label %bb12
bb12:
  %t33 = load i64, ptr %l56, !tbaa !24
  %t34 = icmp sgt i64 %t33, 1
  store i1 %t34, ptr %l7, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l58, !tbaa !29
  %t37 = load ptr, ptr %l58, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t37, i32 0, i32 13
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l58, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t43, i32 0, i32 13
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l9, !tbaa !24
  store i64 %t47, ptr %l62, !tbaa !24
  %t48 = load ptr, ptr %l8, !tbaa !29
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t48)
  store i64 %t50, ptr %l64
  br label %bb14
bb14:
  %t51 = load i64, ptr %l62, !tbaa !24
  %t52 = load i64, ptr %l64, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb69
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l8, !tbaa !29
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l69
  br label %bb18
bb18:
  %t62 = load i64, ptr %l69, !tbaa !24
  store i64 %t62, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l70, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/effects:Effects", ptr %t63, i32 0, i32 3
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/effects:Facts" %t69, ptr %l74
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s5, ptr %t70, ptr %l74)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  store i64 0, ptr %l11, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/effects:Effects", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l79
  br label %bb21
bb21:
  %t80 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s6, ptr %l79)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l81
  br label %bb22
bb22:
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %l81)
  store i64 %t82, ptr %l83
  br label %bb23
bb23:
  %t83 = load i64, ptr %l83, !tbaa !24
  store i64 %t83, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t90 = load i64, ptr %l13, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb29
bb26:
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l90, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb28
bb28:
  %t110 = load i64, ptr %l90, !tbaa !24
  store i64 %t110, ptr %l87, !tbaa !24
  br label %bb29
bb29:
  %t111 = load i64, ptr %l87, !tbaa !24
  store i64 %t111, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t112 = load i64, ptr %l15, !tbaa !24
  %t113 = load i64, ptr %l14, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb32:
  br label %bb33
bb33:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l15, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l16, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/effects:Effects", ptr %t130, i32 0, i32 4
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l111
  br label %bb34
bb34:
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s7, ptr %l111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l113
  br label %bb35
bb35:
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %l113, i64 %t139)
  store i64 %t142, ptr %l116
  br label %bb36
bb36:
  %t143 = load i64, ptr %l116, !tbaa !24
  store i64 %t143, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = icmp eq i64 %t144, %t145
  br i1 %t148, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = icmp slt i64 %t150, 0
  br i1 %t152, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb43
bb41:
  %t154 = load i64, ptr %l17, !tbaa !24
  store i64 %t154, ptr %l123, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/effects:Effects", ptr %t155, i32 0, i32 1
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t157)
  store i64 %t159, ptr %l126
  br label %bb42
bb42:
  %t160 = load i64, ptr %l123, !tbaa !24
  %t161 = load i64, ptr %l126, !tbaa !24
  %t162 = icmp sge i64 %t160, %t161
  store i1 %t162, ptr %l122, !tbaa !21
  br label %bb43
bb43:
  %t164 = load i1, ptr %l122, !tbaa !21
  br i1 %t164, label %bb44, label %bb45
bb44:
  %t165 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 14
  store i1 true, ptr %t165, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb45:
  br label %bb46
bb46:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t166)
  store i1 %t169, ptr %l130
  br label %bb47
bb47:
  %t170 = load i1, ptr %l130, !tbaa !21
  br i1 %t170, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb49:
  br label %bb50
bb50:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/effects:Effects", ptr %t171, i32 0, i32 5
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l134
  br label %bb51
bb51:
  %t179 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s7, ptr %l134)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l136
  br label %bb52
bb52:
  %t180 = load i64, ptr %l16, !tbaa !24
  %t183 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l136, i64 %t180)
  store i1 %t183, ptr %l139
  br label %bb53
bb53:
  %t184 = load i1, ptr %l139, !tbaa !21
  br i1 %t184, label %bb54, label %bb55
bb54:
  store ptr %l2, ptr %l140, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/effects:Effects", ptr %t185, i32 0, i32 9
  %t188 = load i64, ptr %l17, !tbaa !24
  %t191 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t187, i64 %t188)
  store %"compiler/effects:Facts" %t191, ptr %l144
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t192 = load ptr, ptr %l140, !tbaa !29
  %t193 = load %"compiler/effects:Facts", ptr %l144
  call void @compiler_2feffects_2eMergeCold(ptr %s0, ptr %t192, %"compiler/effects:Facts" %t193)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb58:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/effects:Effects", ptr %t194, i32 0, i32 12
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l148
  br label %bb59
bb59:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/effects:Effects", ptr %t201, i32 0, i32 13
  %t204 = load i64, ptr %t203, !tbaa !24
  %t205 = load i64, ptr %l148, !tbaa !24
  %t207 = icmp eq i64 %t205, %t204
  br i1 %t207, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/effects:Effects", ptr %t209, i32 0, i32 12
  %t212 = load i64, ptr %l17, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/effects:Effects", ptr %t213, i32 0, i32 13
  %t216 = load i64, ptr %t215, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t211, i64 %t212, i64 %t216)
  br label %bb63
bb63:
  store ptr %l2, ptr %l157, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/effects:Effects", ptr %t220, i32 0, i32 9
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t222, i64 %t223)
  store %"compiler/effects:Facts" %t226, ptr %l161
  br label %bb64
bb64:
  %t227 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s7, ptr %t227, ptr %l161)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  %t229 = load i64, ptr %l15, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l15, !tbaa !24
  br label %bb30
bb67:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb68
bb68:
  %t233 = load i64, ptr %l9, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l9, !tbaa !24
  br label %bb13
bb69:
  %t237 = load i1, ptr %l7, !tbaa !21
  br i1 %t237, label %bb70, label %bb71
bb70:
  %t239 = getelementptr %"compiler/effects:Facts", ptr %l2, i32 0, i32 8
  store i1 true, ptr %t239, !tbaa !21
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t240, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb73
bb73:
  %t242 = load i64, ptr %l19, !tbaa !24
  store i64 %t242, ptr %l169, !tbaa !24
  %t243 = load ptr, ptr %l18, !tbaa !29
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t243)
  store i64 %t245, ptr %l171
  br label %bb74
bb74:
  %t246 = load i64, ptr %l169, !tbaa !24
  %t247 = load i64, ptr %l171, !tbaa !24
  %t248 = icmp slt i64 %t246, %t247
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb75, label %bb76
bb75:
  br label %bb83
bb76:
  br label %bb77
bb77:
  %t252 = load ptr, ptr %l18, !tbaa !29
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t252, i64 %t253)
  store i64 %t256, ptr %l176
  br label %bb78
bb78:
  %t257 = load i64, ptr %l176, !tbaa !24
  store i64 %t257, ptr %l20, !tbaa !24
  %t258 = load %"compiler/effects:Facts", ptr %l2
  store %"compiler/effects:Facts" %t258, ptr %l21
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/effects:Effects", ptr %t260, i32 0, i32 3
  %t263 = load i64, ptr %l20, !tbaa !24
  %t266 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t262, i64 %t263)
  store %"compiler/effects:Facts" %t266, ptr %l181
  br label %bb79
bb79:
  %t267 = getelementptr %"compiler/effects:Facts", ptr %l181, i32 0, i32 21
  %t268 = load i64, ptr %t267, !tbaa !24
  %t270 = getelementptr %"compiler/effects:Facts", ptr %l21, i32 0, i32 21
  store i64 %t268, ptr %t270, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/effects:Effects", ptr %t271, i32 0, i32 3
  %t274 = load i64, ptr %l20, !tbaa !24
  %t277 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t273, i64 %t274)
  store %"compiler/effects:Facts" %t277, ptr %l186
  br label %bb80
bb80:
  %t278 = getelementptr %"compiler/effects:Facts", ptr %l186, i32 0, i32 22
  %t279 = load i64, ptr %t278, !tbaa !24
  %t281 = getelementptr %"compiler/effects:Facts", ptr %l21, i32 0, i32 22
  store i64 %t279, ptr %t281, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/effects:Effects", ptr %t282, i32 0, i32 9
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load %"compiler/effects:Facts", ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t284, i64 %t285, %"compiler/effects:Facts" %t286)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t290 = load i64, ptr %l19, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l19, !tbaa !24
  br label %bb73
bb83:
  br label %bb84
bb84:
  store i64 0, ptr %l22, !tbaa !24
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb85
bb85:
  %t296 = load i64, ptr %l24, !tbaa !24
  store i64 %t296, ptr %l195, !tbaa !24
  %t297 = load ptr, ptr %l23, !tbaa !29
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t297)
  store i64 %t299, ptr %l197
  br label %bb86
bb86:
  %t300 = load i64, ptr %l195, !tbaa !24
  %t301 = load i64, ptr %l197, !tbaa !24
  %t302 = icmp slt i64 %t300, %t301
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb87, label %bb88
bb87:
  br label %bb94
bb88:
  br label %bb89
bb89:
  %t306 = load ptr, ptr %l23, !tbaa !29
  %t307 = load i64, ptr %l24, !tbaa !24
  %t310 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t306, i64 %t307)
  store i64 %t310, ptr %l202
  br label %bb90
bb90:
  %t311 = load i64, ptr %l202, !tbaa !24
  store i64 %t311, ptr %l25, !tbaa !24
  %t312 = load i64, ptr %l22, !tbaa !24
  store i64 %t312, ptr %l203, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i64, ptr %l25, !tbaa !24
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t320 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassWrites(ptr %v0, ptr %v1, ptr %s0, ptr %t313, i64 %t314, ptr %t315, ptr %l3)
  store i64 %t320, ptr %l208
  br label %bb91
bb91:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i64, ptr %l25, !tbaa !24
  %t326 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassCalls(ptr %v0, ptr %s0, ptr %t321, i64 %t322, ptr %l3)
  store i64 %t326, ptr %l212
  br label %bb92
bb92:
  %t327 = load i64, ptr %l208, !tbaa !24
  %t328 = load i64, ptr %l212, !tbaa !24
  %t329 = add i64 %t327, %t328
  %t330 = load i64, ptr %l203, !tbaa !24
  %t332 = add i64 %t330, %t329
  store i64 %t332, ptr %l22, !tbaa !24
  br label %bb93
bb93:
  %t334 = load i64, ptr %l24, !tbaa !24
  %t336 = add i64 %t334, 1
  store i64 %t336, ptr %l24, !tbaa !24
  br label %bb85
bb94:
  %t338 = load i64, ptr %l22, !tbaa !24
  %t340 = icmp eq i64 %t338, 0
  br i1 %t340, label %bb95, label %bb96
bb95:
  br label %bb99
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb84
bb99:
  store i1 false, ptr %l26, !tbaa !21
  store i1 false, ptr %l27, !tbaa !21
  %t342 = load ptr, ptr %l1, !tbaa !29
  store ptr %t342, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb100
bb100:
  %t344 = load i64, ptr %l29, !tbaa !24
  store i64 %t344, ptr %l220, !tbaa !24
  %t345 = load ptr, ptr %l28, !tbaa !29
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t345)
  store i64 %t347, ptr %l222
  br label %bb101
bb101:
  %t348 = load i64, ptr %l220, !tbaa !24
  %t349 = load i64, ptr %l222, !tbaa !24
  %t350 = icmp slt i64 %t348, %t349
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb102, label %bb103
bb102:
  br label %bb114
bb103:
  br label %bb104
bb104:
  %t354 = load ptr, ptr %l28, !tbaa !29
  %t355 = load i64, ptr %l29, !tbaa !24
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t354, i64 %t355)
  store i64 %t358, ptr %l227
  br label %bb105
bb105:
  %t359 = load i64, ptr %l227, !tbaa !24
  store i64 %t359, ptr %l30, !tbaa !24
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/effects:Effects", ptr %t360, i32 0, i32 10
  store ptr %t362, ptr %l229, !tbaa !29
  %t363 = load i64, ptr %l30, !tbaa !24
  store i64 %t363, ptr %l230, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/effects:Effects", ptr %t364, i32 0, i32 9
  %t367 = load i64, ptr %l30, !tbaa !24
  %t370 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t366, i64 %t367)
  store %"compiler/effects:Facts" %t370, ptr %l234
  br label %bb106
bb106:
  %t371 = getelementptr %"compiler/effects:Facts", ptr %l234, i32 0, i32 22
  %t372 = load i64, ptr %t371, !tbaa !24
  %t373 = load ptr, ptr %l229, !tbaa !29
  %t374 = load i64, ptr %l230, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t373, i64 %t374, i64 %t372)
  br label %bb107
bb107:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l236, !tbaa !29
  %t377 = load i64, ptr %l30, !tbaa !24
  store i64 %t377, ptr %l237, !tbaa !24
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/effects:Effects", ptr %t378, i32 0, i32 9
  %t381 = load i64, ptr %l30, !tbaa !24
  %t384 = call %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t380, i64 %t381)
  store %"compiler/effects:Facts" %t384, ptr %l241
  br label %bb108
bb108:
  %t385 = getelementptr %"compiler/effects:Facts", ptr %l241, i32 0, i32 21
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load ptr, ptr %l236, !tbaa !29
  %t388 = load i64, ptr %l237, !tbaa !24
  %t390 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritesUnowned(ptr %v0, ptr %t387, i64 %t388, i64 %t386)
  store i1 %t390, ptr %l243
  br label %bb109
bb109:
  %t391 = load i1, ptr %l243, !tbaa !21
  br i1 %t391, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb112
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t392 = load i64, ptr %l29, !tbaa !24
  %t394 = add i64 %t392, 1
  store i64 %t394, ptr %l29, !tbaa !24
  br label %bb100
bb114:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb115
bb115:
  %t398 = load i64, ptr %l32, !tbaa !24
  store i64 %t398, ptr %l247, !tbaa !24
  %t399 = load ptr, ptr %l31, !tbaa !29
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t399)
  store i64 %t401, ptr %l249
  br label %bb116
bb116:
  %t402 = load i64, ptr %l247, !tbaa !24
  %t403 = load i64, ptr %l249, !tbaa !24
  %t404 = icmp slt i64 %t402, %t403
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb117, label %bb118
bb117:
  br label %bb133
bb118:
  br label %bb119
bb119:
  %t408 = load ptr, ptr %l31, !tbaa !29
  %t409 = load i64, ptr %l32, !tbaa !24
  %t412 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t408, i64 %t409)
  store i64 %t412, ptr %l254
  br label %bb120
bb120:
  %t413 = load i64, ptr %l254, !tbaa !24
  store i64 %t413, ptr %l33, !tbaa !24
  %t414 = load i1, ptr %l26, !tbaa !21
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb121, label %bb122
bb121:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/effects:Effects", ptr %t418, i32 0, i32 14
  %t421 = load i64, ptr %l33, !tbaa !24
  %t424 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t420, i64 %t421)
  store i1 %t424, ptr %l261
  br label %bb123
bb122:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb124
bb123:
  %t425 = load i1, ptr %l261, !tbaa !21
  store i1 %t425, ptr %l257, !tbaa !21
  br label %bb124
bb124:
  %t426 = load i1, ptr %l257, !tbaa !21
  br i1 %t426, label %bb125, label %bb126
bb125:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i64, ptr %l33, !tbaa !24
  %t431 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallsThrough(ptr %v0, ptr %t427, i64 %t428)
  store i1 %t431, ptr %l265
  br label %bb127
bb126:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb128
bb127:
  %t432 = load i1, ptr %l265, !tbaa !21
  store i1 %t432, ptr %l262, !tbaa !21
  br label %bb128
bb128:
  %t433 = load i1, ptr %l262, !tbaa !21
  br i1 %t433, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb131
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t434 = load i64, ptr %l32, !tbaa !24
  %t436 = add i64 %t434, 1
  store i64 %t436, ptr %l32, !tbaa !24
  br label %bb115
bb133:
  %t438 = load i1, ptr %l26, !tbaa !21
  br i1 %t438, label %bb134, label %bb135
bb134:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethroughBounds(ptr %v0, ptr %v1, ptr %t440, ptr %t441)
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  %t444 = load ptr, ptr %l1, !tbaa !29
  store ptr %t444, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb138
bb138:
  %t446 = load i64, ptr %l35, !tbaa !24
  store i64 %t446, ptr %l272, !tbaa !24
  %t447 = load ptr, ptr %l34, !tbaa !29
  %t449 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t447)
  store i64 %t449, ptr %l274
  br label %bb139
bb139:
  %t450 = load i64, ptr %l272, !tbaa !24
  %t451 = load i64, ptr %l274, !tbaa !24
  %t452 = icmp slt i64 %t450, %t451
  %t454 = xor i1 %t452, true
  br i1 %t454, label %bb140, label %bb141
bb140:
  br label %bb150
bb141:
  br label %bb142
bb142:
  %t456 = load ptr, ptr %l34, !tbaa !29
  %t457 = load i64, ptr %l35, !tbaa !24
  %t460 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t456, i64 %t457)
  store i64 %t460, ptr %l279
  br label %bb143
bb143:
  %t461 = load i64, ptr %l279, !tbaa !24
  store i64 %t461, ptr %l36, !tbaa !24
  %t462 = load i1, ptr %l27, !tbaa !21
  br i1 %t462, label %bb144, label %bb145
bb144:
  %t464 = load i64, ptr %l36, !tbaa !24
  store i1 true, ptr %l38, !tbaa !21
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/effects:Effects", ptr %t466, i32 0, i32 9
  %t472 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v0, ptr %t468, i64 %t464)
  store ptr %t472, ptr %l285
  br label %bb146
bb145:
  br label %bb147
bb146:
  %t473 = load ptr, ptr %l285, !tbaa !29
  %t475 = load i1, ptr %l38, !tbaa !21
  %t478 = getelementptr %"compiler/effects:Facts", ptr %t473, i32 0, i32 18
  store i1 %t475, ptr %t478, !tbaa !21
  br label %bb147
bb147:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/effects:Effects", ptr %t479, i32 0, i32 15
  %t482 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t481, i64 %t482, i64 2)
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t485 = load i64, ptr %l35, !tbaa !24
  %t487 = add i64 %t485, 1
  store i64 %t487, ptr %l35, !tbaa !24
  br label %bb138
bb150:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotBase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l10 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca %"compiler/typed:Local"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/effects:Effects", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  store ptr %t17, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l18
  br label %bb4
bb4:
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t29, i64 %t30)
  store %"compiler/typed:Local" %t33, ptr %l23
  br label %bb8
bb8:
  %t34 = load %"compiler/typed:Local", ptr %l23
  store %"compiler/typed:Local" %t34, ptr %l6
  %t35 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 4
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 7}
  %t38 = trunc i64 5 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb3
bb13:
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/effects:root"
  %l5 = alloca i1
  %l9 = alloca %"compiler/effects:root"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 23
  %t10 = getelementptr %"compiler/effects:Facts", ptr %t9, i32 0, i32 3
  store i1 true, ptr %t10, !tbaa !21
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/effects:root" %t15, ptr %l9
  br label %bb5
bb5:
  %t16 = load %"compiler/effects:root", ptr %l9
  store %"compiler/effects:root" %t16, ptr %l2
  %t17 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 1
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/effects:root", ptr %l2, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %t27, i64 %t29)
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/effects:Effects", ptr %t32, i32 0, i32 23
  %t35 = getelementptr %"compiler/effects:Facts", ptr %t34, i32 0, i32 17
  store i1 true, ptr %t35, !tbaa !21
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i64
  %l29 = alloca i1
  %l32 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/effects:Effects", ptr %t14, i32 0, i32 30
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, i64 } %t20, 1
  %t22 = extractvalue { i32, i64 } %t20, 0
  store i32 %t22, ptr %l15
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb6, label %ok.24, !prof !99
ok.24:
  store i64 %t21, ptr %l14
  br label %bb5
bb5:
  %t25 = load i64, ptr %l14, !tbaa !24
  store i64 %t25, ptr %l10, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t26 = load i64, ptr %l10, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sge i64 %t27, 63
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/effects:Effects", ptr %t31, i32 0, i32 23
  %t34 = getelementptr %"compiler/effects:Facts", ptr %t33, i32 0, i32 17
  store i1 true, ptr %t34, !tbaa !21
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 23
  %t39 = getelementptr %"compiler/effects:Facts", ptr %t38, i32 0, i32 21
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = call i64 @compiler_2feffects_2eparamBit(i64 %t41)
  store i64 %t43, ptr %l23
  br label %bb12
bb12:
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = or i64 %t44, %t45
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = or i64 %t46, %t47
  %t52 = load ptr, ptr %l19, !tbaa !29
  %t53 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 23
  %t54 = getelementptr %"compiler/effects:Facts", ptr %t53, i32 0, i32 21
  store i64 %t50, ptr %t54, !tbaa !24
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp eq i64 %t59, 0
  store i1 %t61, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l29, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/effects:Effects", ptr %t64, i32 0, i32 2
  %t67 = load i1, ptr %t66, !tbaa !21
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Effects", ptr %t70, i32 0, i32 40
  %t73 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %a1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load i1, ptr %l13, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/effects:Effects", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l19
  br label %bb8
bb8:
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = icmp sgt i64 %t41, 0
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eviewsOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Effects", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Effects", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l18
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/effects:Effects", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l32
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l31
  br label %bb12
bb12:
  %t55 = load i64, ptr %l31, !tbaa !24
  store i64 %t55, ptr %l25, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  store i64 %t56, ptr %l21, !tbaa !24
  br label %bb32
bb16:
  %t57 = load { i64, [2 x i64] }, ptr %l2
  %t59 = extractvalue { i64, [2 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t63 = getelementptr { i32, i32 }, ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l4, !tbaa !23
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t67 = getelementptr { i32, i32 }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t70 = load i32, ptr %l5, !tbaa !23
  %t72 = icmp eq i32 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 7
  %t83 = load i32, ptr %l4, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l48
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb23, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l47
  br label %bb22
bb21:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb26
bb22:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l40, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l39, !tbaa !24
  br label %bb26
bb26:
  %t95 = load i64, ptr %l39, !tbaa !24
  store i64 %t95, ptr %l21, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6bf1b4bd1b6b313_44dd2df342c09ca7)
  unreachable
bb32:
  %t96 = load i64, ptr %l21, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l19 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i64
  %l53 = alloca i64
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalk(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/effects:Effects", ptr %t5, i32 0, i32 18
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/effects:Effects", ptr %t9, i32 0, i32 22
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8, i64 %t12)
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/effects:Effects", ptr %t16, i32 0, i32 19
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/effects:Effects", ptr %t20, i32 0, i32 22
  %t23 = load i64, ptr %t22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19, i64 %t23)
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = getelementptr %"compiler/effects:Effects", ptr %t28, i32 0, i32 22
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = getelementptr %"compiler/effects:Effects", ptr %t34, i32 0, i32 22
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Effects", ptr %t36, i32 0, i32 21
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Effects", ptr %t42, i32 0, i32 20
  %t45 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t44, i64 %t45, i1 true)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 4
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s1, ptr %t50, i64 %t51)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l31
  br label %bb6
bb6:
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l33
  br label %bb7
bb7:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  store ptr %t58, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb9
bb9:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l42
  br label %bb13
bb13:
  %t75 = load i64, ptr %l42, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eedge(ptr %v0, ptr %t76, i64 %t77, i64 %t75)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l3, !tbaa !24
  br label %bb8
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpand(ptr %v0, ptr %t86, i64 %t87)
  br label %bb17
bb17:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/effects:Effects", ptr %t90, i32 0, i32 19
  %t93 = load i64, ptr %l1, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l53
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Effects", ptr %t97, i32 0, i32 18
  %t100 = load i64, ptr %l1, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l57
  br label %bb19
bb19:
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = load i64, ptr %l57, !tbaa !24
  %t106 = icmp ne i64 %t104, %t105
  br i1 %t106, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l59
  br label %bb23
bb23:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l5
  br label %bb24
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/effects:Effects", ptr %t110, i32 0, i32 21
  %t114 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t112)
  %t115 = extractvalue { i32, i64 } %t114, 1
  %t116 = extractvalue { i32, i64 } %t114, 0
  store i32 %t116, ptr %l64
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb26, label %ok.118, !prof !99
ok.118:
  store i64 %t115, ptr %l63
  br label %bb25
bb25:
  %t119 = load i64, ptr %l63, !tbaa !24
  store i64 %t119, ptr %l60, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  br label %bb35
bb28:
  %t120 = load i64, ptr %l60, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/effects:Effects", ptr %t121, i32 0, i32 20
  %t124 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t123, i64 %t124, i1 false)
  br label %bb29
bb29:
  %t127 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t127)
  br label %bb30
bb30:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = icmp eq i64 %t130, %t131
  br i1 %t134, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2esettle(ptr %v0, ptr %s0, ptr %t136, ptr %l5)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalk(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca i64
  %l49 = alloca i1
  %l52 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 15
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %t7, i64 %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/effects:Effects", ptr %t15, i32 0, i32 23
  %t18 = load %"compiler/effects:Facts", ptr %t17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t13, i64 %t14, %"compiler/effects:Facts" %t18)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Effects", ptr %t22, i32 0, i32 4
  store ptr %t24, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/effects:Effects", ptr %t26, i32 0, i32 24
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l16
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l16)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l18
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l13, !tbaa !29
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hca3b6abf349bf7326560c41fbdf5fb42(ptr %v0, ptr %s0, ptr %t32, i64 %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34)
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 5
  store ptr %t37, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 25
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l23
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l25
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l20, !tbaa !29
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hca3b6abf349bf7326560c41fbdf5fb42(ptr %v0, ptr %s0, ptr %t45, i64 %t46, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47)
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Effects", ptr %t48, i32 0, i32 6
  store ptr %t50, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/effects:Effects", ptr %t52, i32 0, i32 27
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l30
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %s0, ptr %l30)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l32
  br label %bb8
bb8:
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = load i64, ptr %l28, !tbaa !24
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Had7562134349141a1e65e244951d3fe8(ptr %v0, ptr %s0, ptr %t58, i64 %t59, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60)
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Effects", ptr %t61, i32 0, i32 28
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l35
  br label %bb10
bb10:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = icmp sgt i64 %t66, 0
  br i1 %t67, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %t69, i32 0, i32 7
  store ptr %t71, ptr %l38, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l39, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/effects:Effects", ptr %t73, i32 0, i32 28
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l41
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s1, ptr %l41)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l43
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H17d172c890106e7669720f11d3813b09(ptr %v0, ptr %s1, ptr %t79, i64 %t80, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/effects:Effects", ptr %t82, i32 0, i32 14
  store ptr %t84, ptr %l45, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Effects", ptr %t86, i32 0, i32 42
  %t89 = load i1, ptr %t88, !tbaa !21
  br i1 %t89, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb19
bb17:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/effects:Effects", ptr %t91, i32 0, i32 28
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l52
  br label %bb18
bb18:
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = icmp sgt i64 %t96, 0
  store i1 %t97, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t99 = load ptr, ptr %l45, !tbaa !29
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = load i1, ptr %l49, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t99, i64 %t100, i1 %t101)
  br label %bb20
bb20:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Effects", ptr %t102, i32 0, i32 43
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb21, label %bb22
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/effects:Effects", ptr %t107, i32 0, i32 46
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb23, label %bb24
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/effects:Effects", ptr %t112, i32 0, i32 8
  store ptr %t114, ptr %l59, !tbaa !29
  %t115 = load i64, ptr %l1, !tbaa !24
  store i64 %t115, ptr %l60, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/effects:Effects", ptr %t116, i32 0, i32 45
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l62
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s3, ptr %l62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l64
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = load i64, ptr %l60, !tbaa !24
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %s3, ptr %t122, i64 %t123, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewalkBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"compiler/effects:Facts"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l69 = alloca i64
  %l75 = alloca i64
  %l81 = alloca i64
  %l89 = alloca i64
  %l95 = alloca i64
  %l100 = alloca ptr
  %l106 = alloca i32
  %l109 = alloca i1
  %l110 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i1
  %l118 = alloca ptr
  %l124 = alloca i32
  %l127 = alloca i1
  %l128 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i1
  %l138 = alloca i64
  %l144 = alloca i64
  %l150 = alloca i64
  %l156 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i64
  %l163 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l165 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l167 = alloca ptr
  %l168 = alloca i64
  %l170 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l172 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l202 = alloca ptr
  %l206 = alloca i32
  %l218 = alloca i64
  %l221 = alloca i64
  %l225 = alloca i64
  %l228 = alloca i64
  %l249 = alloca %"compiler/typed:Local"
  %l261 = alloca ptr
  %l262 = alloca i64
  %l264 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l266 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l270 = alloca i64
  %l272 = alloca i64
  %l277 = alloca i32
  %l284 = alloca ptr
  %l286 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l287 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l291 = alloca ptr
  %l292 = alloca i64
  %l297 = alloca i64
  %l298 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l24, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l25, !tbaa !29
  %t10 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t10, ptr %l26
  br label %bb2
bb2:
  %t11 = load %"compiler/effects:Facts", ptr %l26
  %t12 = load ptr, ptr %l25, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Effects", ptr %t12, i32 0, i32 23
  store %"compiler/effects:Facts" %t11, ptr %t13
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l27, !tbaa !29
  %t15 = ptrtoint ptr %v0 to i64
  store i64 %t15, ptr %l28, !tbaa !24
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e24
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = call ptr @__olang_region_make(ptr %v0)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l28, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l28
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t21, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l30
  br label %bb5
bb5:
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e24
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l28
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = call ptr @__olang_region_or(ptr %t29, ptr null)
  %t31 = call ptr @__olang_region_home(ptr %t30)
  %t32 = icmp ne ptr %t31, null
  %t33 = select i1 %t32, ptr %t31, ptr null
  %t34 = icmp eq ptr %t33, %t26
  call void @__olang_region_settle(ptr %t26, i1 %t34)
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Effects", ptr %t35, i32 0, i32 24
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l32
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = getelementptr %"compiler/effects:Effects", ptr %t39, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %t40
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e24
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = call ptr @__olang_region_or(ptr %t45, ptr null)
  %t47 = call ptr @__olang_region_home(ptr %t46)
  %t48 = icmp ne ptr %t47, null
  %t49 = select i1 %t48, ptr %t47, ptr null
  call void @__olang_region_drop(ptr %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l32
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l34, !tbaa !29
  %t51 = ptrtoint ptr %v0 to i64
  store i64 %t51, ptr %l35, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e25
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = call ptr @__olang_region_make(ptr %v0)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l35
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t57, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l37
  br label %bb12
bb12:
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e25
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load i64, ptr %l35
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr null
  %t70 = icmp eq ptr %t69, %t62
  call void @__olang_region_settle(ptr %t62, i1 %t70)
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Effects", ptr %t71, i32 0, i32 25
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l39
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  %t75 = load ptr, ptr %l34, !tbaa !29
  %t76 = getelementptr %"compiler/effects:Effects", ptr %t75, i32 0, i32 25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t76
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e25
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_drop(ptr %t85)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l39
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/effects:Effects", ptr %t86, i32 0, i32 26
  store i64 0, ptr %t88, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l42, !tbaa !29
  %t90 = ptrtoint ptr %v0 to i64
  store i64 %t90, ptr %l43, !tbaa !24
  %t91 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t93 = call ptr @__olang_region_make(ptr %v0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l43, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l43
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %t96, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l45
  br label %bb19
bb19:
  %t98 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t100 = load i64, ptr %l43
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr null)
  %t106 = call ptr @__olang_region_home(ptr %t105)
  %t107 = icmp ne ptr %t106, null
  %t108 = select i1 %t107, ptr %t106, ptr null
  %t109 = icmp eq ptr %t108, %t101
  call void @__olang_region_settle(ptr %t101, i1 %t109)
  br label %bb21
bb21:
  %t110 = load ptr, ptr %l42, !tbaa !29
  %t111 = getelementptr %"compiler/effects:Effects", ptr %t110, i32 0, i32 27
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t111
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l47
  %t113 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t114 = load ptr, ptr %l42, !tbaa !29
  %t115 = getelementptr %"compiler/effects:Effects", ptr %t114, i32 0, i32 27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %t115
  %t116 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e27
  br i1 %t116, label %bb22, label %bb23
bb22:
  %t118 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = call ptr @__olang_region_home(ptr %t121)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_drop(ptr %t124)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l47
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/effects:Effects", ptr %t125, i32 0, i32 28
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t127)
  store i64 %t129, ptr %l51
  br label %bb24
bb24:
  %t130 = load i64, ptr %l51, !tbaa !24
  %t131 = icmp sgt i64 %t130, 0
  br i1 %t131, label %bb25, label %bb26
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/effects:Effects", ptr %t133, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eClear_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %t135)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/effects:Effects", ptr %t137, i32 0, i32 35
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l57
  br label %bb29
bb29:
  %t142 = load i64, ptr %l57, !tbaa !24
  %t143 = icmp sgt i64 %t142, 0
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/effects:Effects", ptr %t145, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eClear_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %t147)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/effects:Effects", ptr %t149, i32 0, i32 37
  %t153 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l63
  br label %bb34
bb34:
  %t154 = load i64, ptr %l63, !tbaa !24
  %t155 = icmp sgt i64 %t154, 0
  br i1 %t155, label %bb35, label %bb36
bb35:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/effects:Effects", ptr %t157, i32 0, i32 37
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %t159)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/effects:Effects", ptr %t161, i32 0, i32 38
  %t165 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l69
  br label %bb39
bb39:
  %t166 = load i64, ptr %l69, !tbaa !24
  %t167 = icmp sgt i64 %t166, 0
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/effects:Effects", ptr %t169, i32 0, i32 38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t171)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/effects:Effects", ptr %t173, i32 0, i32 39
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l75
  br label %bb44
bb44:
  %t178 = load i64, ptr %l75, !tbaa !24
  %t179 = icmp sgt i64 %t178, 0
  br i1 %t179, label %bb45, label %bb46
bb45:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/effects:Effects", ptr %t181, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t183)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/effects:Effects", ptr %t185, i32 0, i32 40
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l81
  br label %bb49
bb49:
  %t190 = load i64, ptr %l81, !tbaa !24
  %t191 = icmp sgt i64 %t190, 0
  br i1 %t191, label %bb50, label %bb51
bb50:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/effects:Effects", ptr %t193, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t195)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/effects:Effects", ptr %t197, i32 0, i32 41
  store i1 false, ptr %t199, !tbaa !21
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/effects:Effects", ptr %t200, i32 0, i32 42
  store i1 false, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/effects:Effects", ptr %t203, i32 0, i32 44
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t205)
  store i64 %t207, ptr %l89
  br label %bb54
bb54:
  %t208 = load i64, ptr %l89, !tbaa !24
  %t209 = icmp sgt i64 %t208, 0
  br i1 %t209, label %bb55, label %bb56
bb55:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/effects:Effects", ptr %t211, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eClear_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t213)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/effects:Effects", ptr %t215, i32 0, i32 45
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t217)
  store i64 %t219, ptr %l95
  br label %bb59
bb59:
  %t220 = load i64, ptr %l95, !tbaa !24
  %t221 = icmp sgt i64 %t220, 0
  br i1 %t221, label %bb60, label %bb61
bb60:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/effects:Effects", ptr %t223, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t225)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/effects:Effects", ptr %t227, i32 0, i32 46
  store i1 false, ptr %t229, !tbaa !21
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l100, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/effects:Effects", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 2
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Body", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %t239, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t236, i32 %t240)
  store i32 %t243, ptr %l106
  br label %bb64
bb64:
  %t244 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t246 = trunc i64 21 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb65, label %bb66
bb65:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l110, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/effects:Effects", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Body", ptr %t256, i32 0, i32 2
  %t259 = load i32, ptr %t258, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t255, i32 %t259)
  store i32 %t262, ptr %l116
  br label %bb67
bb66:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb69
bb67:
  %t263 = load ptr, ptr %l110, !tbaa !29
  %t264 = load i32, ptr %l116, !tbaa !23
  %t265 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %t263, i32 %t264)
  store i1 %t265, ptr %l117
  br label %bb68
bb68:
  %t266 = load i1, ptr %l117, !tbaa !21
  store i1 %t266, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t267 = load i1, ptr %l109, !tbaa !21
  %t268 = load ptr, ptr %l100, !tbaa !29
  %t269 = getelementptr %"compiler/effects:Effects", ptr %t268, i32 0, i32 43
  store i1 %t267, ptr %t269, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l118, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/effects:Effects", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 2
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 2
  %t280 = load i32, ptr %t279, !tbaa !23
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t276, i32 %t280)
  store i32 %t283, ptr %l124
  br label %bb70
bb70:
  %t284 = load i32, ptr %l124, !range !{i32 0, i32 33}
  %t286 = trunc i64 21 to i32
  %t287 = icmp eq i32 %t284, %t286
  br i1 %t287, label %bb71, label %bb72
bb71:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l128, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/effects:Effects", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  %t296 = load ptr, ptr %l2, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Body", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %t298, !tbaa !23
  %t302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t295, i32 %t299)
  store i32 %t302, ptr %l134
  br label %bb73
bb72:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb75
bb73:
  %t303 = load ptr, ptr %l128, !tbaa !29
  %t304 = load i32, ptr %l134, !tbaa !23
  %t305 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t305, ptr %l135
  br label %bb74
bb74:
  %t306 = load i1, ptr %l135, !tbaa !21
  store i1 %t306, ptr %l127, !tbaa !21
  br label %bb75
bb75:
  %t307 = load i1, ptr %l127, !tbaa !21
  %t308 = load ptr, ptr %l118, !tbaa !29
  %t309 = getelementptr %"compiler/effects:Effects", ptr %t308, i32 0, i32 63
  store i1 %t307, ptr %t309, !tbaa !21
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/effects:Effects", ptr %t310, i32 0, i32 60
  %t314 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %t312)
  store i64 %t314, ptr %l138
  br label %bb76
bb76:
  %t315 = load i64, ptr %l138, !tbaa !24
  %t316 = icmp sgt i64 %t315, 0
  br i1 %t316, label %bb77, label %bb78
bb77:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/effects:Effects", ptr %t318, i32 0, i32 60
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %t320)
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/effects:Effects", ptr %t322, i32 0, i32 61
  %t326 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t324)
  store i64 %t326, ptr %l144
  br label %bb81
bb81:
  %t327 = load i64, ptr %l144, !tbaa !24
  %t328 = icmp sgt i64 %t327, 0
  br i1 %t328, label %bb82, label %bb83
bb82:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/effects:Effects", ptr %t330, i32 0, i32 61
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t332)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/effects:Effects", ptr %t334, i32 0, i32 62
  %t338 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t336)
  store i64 %t338, ptr %l150
  br label %bb86
bb86:
  %t339 = load i64, ptr %l150, !tbaa !24
  %t340 = icmp sgt i64 %t339, 0
  br i1 %t340, label %bb87, label %bb88
bb87:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/effects:Effects", ptr %t342, i32 0, i32 62
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t344)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/effects:Effects", ptr %t346, i32 0, i32 66
  %t350 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t348)
  store i64 %t350, ptr %l156
  br label %bb91
bb91:
  %t351 = load i64, ptr %l156, !tbaa !24
  %t352 = icmp sgt i64 %t351, 0
  br i1 %t352, label %bb92, label %bb93
bb92:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/effects:Effects", ptr %t354, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t356)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l160, !tbaa !29
  %t359 = ptrtoint ptr %v0 to i64
  store i64 %t359, ptr %l161, !tbaa !24
  %t360 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t360, label %bb96, label %bb97
bb96:
  %t362 = call ptr @__olang_region_make(ptr %v0)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l161, !tbaa !24
  br label %bb97
bb97:
  %t364 = load i64, ptr %l161
  %t365 = inttoptr i64 %t364 to ptr
  %t366 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t365)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t366, ptr %l163
  br label %bb98
bb98:
  %t367 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t367, label %bb99, label %bb100
bb99:
  %t369 = load i64, ptr %l161
  %t370 = inttoptr i64 %t369 to ptr
  %t371 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l163, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = call ptr @__olang_region_or(ptr %t373, ptr null)
  %t375 = call ptr @__olang_region_home(ptr %t374)
  %t376 = icmp ne ptr %t375, null
  %t377 = select i1 %t376, ptr %t375, ptr null
  %t378 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l163, i32 0, i32 1
  %t379 = load { i64, ptr }, ptr %t378
  %t380 = extractvalue { i64, ptr } %t379, 1
  %t381 = call ptr @__olang_region_or(ptr %t380, ptr null)
  %t382 = call ptr @__olang_region_home(ptr %t381)
  %t383 = icmp ne ptr %t382, null
  %t384 = select i1 %t383, ptr %t382, ptr %t377
  %t385 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l163, i32 0, i32 0
  %t386 = load { i64, ptr }, ptr %t385
  %t387 = extractvalue { i64, ptr } %t386, 1
  %t388 = call ptr @__olang_region_or(ptr %t387, ptr null)
  %t389 = call ptr @__olang_region_home(ptr %t388)
  %t390 = icmp ne ptr %t389, null
  %t391 = select i1 %t390, ptr %t389, ptr %t384
  %t392 = icmp eq ptr %t391, %t370
  call void @__olang_region_settle(ptr %t370, i1 %t392)
  br label %bb100
bb100:
  %t393 = load ptr, ptr %l160, !tbaa !29
  %t394 = getelementptr %"compiler/effects:Effects", ptr %t393, i32 0, i32 29
  %t395 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t394
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t395, ptr %l165
  %t396 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l163
  %t397 = load ptr, ptr %l160, !tbaa !29
  %t398 = getelementptr %"compiler/effects:Effects", ptr %t397, i32 0, i32 29
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t396, ptr %t398
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e29
  br i1 %t399, label %bb101, label %bb102
bb101:
  %t401 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l165, i32 0, i32 2
  %t402 = load { i64, ptr }, ptr %t401
  %t403 = extractvalue { i64, ptr } %t402, 1
  %t404 = call ptr @__olang_region_or(ptr %t403, ptr null)
  %t405 = call ptr @__olang_region_home(ptr %t404)
  %t406 = icmp ne ptr %t405, null
  %t407 = select i1 %t406, ptr %t405, ptr null
  %t408 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l165, i32 0, i32 1
  %t409 = load { i64, ptr }, ptr %t408
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = call ptr @__olang_region_or(ptr %t410, ptr null)
  %t412 = call ptr @__olang_region_home(ptr %t411)
  %t413 = icmp ne ptr %t412, null
  %t414 = select i1 %t413, ptr %t412, ptr %t407
  %t415 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l165, i32 0, i32 0
  %t416 = load { i64, ptr }, ptr %t415
  %t417 = extractvalue { i64, ptr } %t416, 1
  %t418 = call ptr @__olang_region_or(ptr %t417, ptr null)
  %t419 = call ptr @__olang_region_home(ptr %t418)
  %t420 = icmp ne ptr %t419, null
  %t421 = select i1 %t420, ptr %t419, ptr %t414
  call void @__olang_region_drop(ptr %t421)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l165
  br label %bb102
bb102:
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l167, !tbaa !29
  %t423 = ptrtoint ptr %v0 to i64
  store i64 %t423, ptr %l168, !tbaa !24
  %t424 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e30
  br i1 %t424, label %bb103, label %bb104
bb103:
  %t426 = call ptr @__olang_region_make(ptr %v0)
  %t427 = ptrtoint ptr %t426 to i64
  store i64 %t427, ptr %l168, !tbaa !24
  br label %bb104
bb104:
  %t428 = load i64, ptr %l168
  %t429 = inttoptr i64 %t428 to ptr
  %t430 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t429)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t430, ptr %l170
  br label %bb105
bb105:
  %t431 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e30
  br i1 %t431, label %bb106, label %bb107
bb106:
  %t433 = load i64, ptr %l168
  %t434 = inttoptr i64 %t433 to ptr
  %t435 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l170, i32 0, i32 2
  %t436 = load { i64, ptr }, ptr %t435
  %t437 = extractvalue { i64, ptr } %t436, 1
  %t438 = call ptr @__olang_region_or(ptr %t437, ptr null)
  %t439 = call ptr @__olang_region_home(ptr %t438)
  %t440 = icmp ne ptr %t439, null
  %t441 = select i1 %t440, ptr %t439, ptr null
  %t442 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l170, i32 0, i32 1
  %t443 = load { i64, ptr }, ptr %t442
  %t444 = extractvalue { i64, ptr } %t443, 1
  %t445 = call ptr @__olang_region_or(ptr %t444, ptr null)
  %t446 = call ptr @__olang_region_home(ptr %t445)
  %t447 = icmp ne ptr %t446, null
  %t448 = select i1 %t447, ptr %t446, ptr %t441
  %t449 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l170, i32 0, i32 0
  %t450 = load { i64, ptr }, ptr %t449
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = call ptr @__olang_region_or(ptr %t451, ptr null)
  %t453 = call ptr @__olang_region_home(ptr %t452)
  %t454 = icmp ne ptr %t453, null
  %t455 = select i1 %t454, ptr %t453, ptr %t448
  %t456 = icmp eq ptr %t455, %t434
  call void @__olang_region_settle(ptr %t434, i1 %t456)
  br label %bb107
bb107:
  %t457 = load ptr, ptr %l167, !tbaa !29
  %t458 = getelementptr %"compiler/effects:Effects", ptr %t457, i32 0, i32 30
  %t459 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t458
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t459, ptr %l172
  %t460 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l170
  %t461 = load ptr, ptr %l167, !tbaa !29
  %t462 = getelementptr %"compiler/effects:Effects", ptr %t461, i32 0, i32 30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t460, ptr %t462
  %t463 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e30
  br i1 %t463, label %bb108, label %bb109
bb108:
  %t465 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 2
  %t466 = load { i64, ptr }, ptr %t465
  %t467 = extractvalue { i64, ptr } %t466, 1
  %t468 = call ptr @__olang_region_or(ptr %t467, ptr null)
  %t469 = call ptr @__olang_region_home(ptr %t468)
  %t470 = icmp ne ptr %t469, null
  %t471 = select i1 %t470, ptr %t469, ptr null
  %t472 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 1
  %t473 = load { i64, ptr }, ptr %t472
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = call ptr @__olang_region_or(ptr %t474, ptr null)
  %t476 = call ptr @__olang_region_home(ptr %t475)
  %t477 = icmp ne ptr %t476, null
  %t478 = select i1 %t477, ptr %t476, ptr %t471
  %t479 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = call ptr @__olang_region_or(ptr %t481, ptr null)
  %t483 = call ptr @__olang_region_home(ptr %t482)
  %t484 = icmp ne ptr %t483, null
  %t485 = select i1 %t484, ptr %t483, ptr %t478
  call void @__olang_region_drop(ptr %t485)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l172
  br label %bb109
bb109:
  store i64 0, ptr %l3, !tbaa !24
  %t486 = load ptr, ptr %l2, !tbaa !29
  %t488 = getelementptr %"compiler/typed:Body", ptr %t486, i32 0, i32 5
  %t490 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t488)
  store i64 %t490, ptr %l176
  br label %bb110
bb110:
  %t491 = load i64, ptr %l176, !tbaa !24
  store i64 %t491, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t492 = load i64, ptr %l4, !tbaa !24
  %t493 = load i64, ptr %l3, !tbaa !24
  %t496 = icmp sgt i64 %t492, %t493
  br i1 %t496, label %bb111, label %bb112
bb111:
  %t498 = load i64, ptr %l5, !tbaa !24
  %t500 = icmp sgt i64 %t498, 0
  br i1 %t500, label %bb113, label %bb114
bb112:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb116
bb113:
  %t502 = load i64, ptr %l4, !tbaa !24
  %t503 = load i64, ptr %l3, !tbaa !24
  %t506 = sub i64 %t502, %t503
  %t507 = load i64, ptr %l5, !tbaa !24
  %t510 = add i64 %t506, %t507
  %t512 = sub i64 %t510, 1
  %t513 = load i64, ptr %l5, !tbaa !24
  %t516 = sdiv i64 %t512, %t513
  store i64 %t516, ptr %l183, !tbaa !24
  br label %bb115
bb114:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb115
bb115:
  %t518 = load i64, ptr %l183, !tbaa !24
  store i64 %t518, ptr %l180, !tbaa !24
  br label %bb116
bb116:
  %t519 = load i64, ptr %l180, !tbaa !24
  store i64 %t519, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb117
bb117:
  %t520 = load i64, ptr %l7, !tbaa !24
  %t521 = load i64, ptr %l6, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb118, label %bb119
bb118:
  br label %bb124
bb119:
  br label %bb120
bb120:
  %t528 = load i64, ptr %l3, !tbaa !24
  %t529 = load i64, ptr %l7, !tbaa !24
  %t530 = load i64, ptr %l5, !tbaa !24
  %t533 = mul i64 %t529, %t530
  %t536 = add i64 %t528, %t533
  store i64 %t536, ptr %l8, !tbaa !24
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/effects:Effects", ptr %t538, i32 0, i32 29
  store ptr %t540, ptr %l202, !tbaa !29
  %t541 = load ptr, ptr %l2, !tbaa !29
  %t543 = getelementptr %"compiler/typed:Body", ptr %t541, i32 0, i32 5
  %t544 = load i64, ptr %l8, !tbaa !24
  %t547 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t543, i64 %t544)
  store i32 %t547, ptr %l206
  br label %bb121
bb121:
  %t548 = load i32, ptr %l206, !tbaa !23
  %t549 = sext i32 %t548 to i64
  %t550 = load i64, ptr %l8, !tbaa !24
  %t551 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t551, i64 %t549, i64 %t550)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t554 = load i64, ptr %l7, !tbaa !24
  %t556 = add i64 %t554, 1
  store i64 %t556, ptr %l7, !tbaa !24
  br label %bb117
bb124:
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t560 = getelementptr %"compiler/typed:Body", ptr %t558, i32 0, i32 1
  %t561 = load { i64, [2 x i64] }, ptr %t560
  %t563 = extractvalue { i64, [2 x i64] } %t561, 0
  %t564 = icmp eq i64 %t563, 4
  br i1 %t564, label %bb125, label %bb126
bb125:
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t568 = getelementptr %"compiler/typed:Body", ptr %t566, i32 0, i32 1
  %t569 = getelementptr { i64, [2 x i64] }, ptr %t568, i32 0, i32 1
  %t570 = getelementptr { i32 }, ptr %t569, i32 0, i32 0
  %t571 = load i32, ptr %t570
  store i32 %t571, ptr %l9, !tbaa !23
  %t573 = load ptr, ptr %l2, !tbaa !29
  %t575 = getelementptr %"compiler/typed:Body", ptr %t573, i32 0, i32 5
  %t577 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t575)
  store i64 %t577, ptr %l218
  br label %bb127
bb126:
  br label %bb146
bb127:
  %t578 = load i64, ptr %l218, !tbaa !24
  store i64 %t578, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t579 = load ptr, ptr %l2, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Body", ptr %t579, i32 0, i32 7
  %t583 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t581)
  store i64 %t583, ptr %l221
  br label %bb128
bb128:
  %t584 = load i64, ptr %l221, !tbaa !24
  store i64 %t584, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t585 = load i64, ptr %l12, !tbaa !24
  %t586 = load i64, ptr %l11, !tbaa !24
  %t589 = icmp sgt i64 %t585, %t586
  br i1 %t589, label %bb129, label %bb130
bb129:
  %t591 = load i64, ptr %l13, !tbaa !24
  %t593 = icmp sgt i64 %t591, 0
  br i1 %t593, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb134
bb131:
  %t595 = load i64, ptr %l12, !tbaa !24
  %t596 = load i64, ptr %l11, !tbaa !24
  %t599 = sub i64 %t595, %t596
  %t600 = load i64, ptr %l13, !tbaa !24
  %t603 = add i64 %t599, %t600
  %t605 = sub i64 %t603, 1
  %t606 = load i64, ptr %l13, !tbaa !24
  %t609 = sdiv i64 %t605, %t606
  store i64 %t609, ptr %l228, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb133
bb133:
  %t611 = load i64, ptr %l228, !tbaa !24
  store i64 %t611, ptr %l225, !tbaa !24
  br label %bb134
bb134:
  %t612 = load i64, ptr %l225, !tbaa !24
  store i64 %t612, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb135
bb135:
  %t613 = load i64, ptr %l15, !tbaa !24
  %t614 = load i64, ptr %l14, !tbaa !24
  %t617 = icmp slt i64 %t613, %t614
  %t619 = xor i1 %t617, true
  br i1 %t619, label %bb136, label %bb137
bb136:
  br label %bb145
bb137:
  br label %bb138
bb138:
  %t621 = load i64, ptr %l11, !tbaa !24
  %t622 = load i64, ptr %l15, !tbaa !24
  %t623 = load i64, ptr %l13, !tbaa !24
  %t626 = mul i64 %t622, %t623
  %t629 = add i64 %t621, %t626
  store i64 %t629, ptr %l16, !tbaa !24
  %t631 = load ptr, ptr %l2, !tbaa !29
  %t633 = getelementptr %"compiler/typed:Body", ptr %t631, i32 0, i32 7
  %t634 = load i64, ptr %l16, !tbaa !24
  %t637 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t633, i64 %t634)
  store %"compiler/typed:Local" %t637, ptr %l249
  br label %bb139
bb139:
  %t638 = getelementptr %"compiler/typed:Local", ptr %l249, i32 0, i32 4
  %t639 = load i32, ptr %t638, !range !{i32 0, i32 7}
  %t641 = trunc i64 5 to i32
  %t642 = icmp eq i32 %t639, %t641
  %t644 = xor i1 %t642, true
  br i1 %t644, label %bb140, label %bb141
bb140:
  br label %bb144
bb141:
  br label %bb142
bb142:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/effects:Effects", ptr %t646, i32 0, i32 29
  %t649 = load i64, ptr %l16, !tbaa !24
  %t650 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t648, i64 %t649, i64 %t650)
  br label %bb143
bb143:
  %t654 = load i64, ptr %l10, !tbaa !24
  %t656 = add i64 %t654, 1
  store i64 %t656, ptr %l10, !tbaa !24
  br label %bb144
bb144:
  %t658 = load i64, ptr %l15, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l15, !tbaa !24
  br label %bb135
bb145:
  br label %bb146
bb146:
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l261, !tbaa !29
  %t663 = ptrtoint ptr %v0 to i64
  store i64 %t663, ptr %l262, !tbaa !24
  %t664 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t664, label %bb147, label %bb148
bb147:
  %t666 = call ptr @__olang_region_make(ptr %v0)
  %t667 = ptrtoint ptr %t666 to i64
  store i64 %t667, ptr %l262, !tbaa !24
  br label %bb148
bb148:
  %t668 = load i64, ptr %l262
  %t669 = inttoptr i64 %t668 to ptr
  %t670 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t669)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t670, ptr %l264
  br label %bb149
bb149:
  %t671 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t671, label %bb150, label %bb151
bb150:
  %t673 = load i64, ptr %l262
  %t674 = inttoptr i64 %t673 to ptr
  %t675 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l264, i32 0, i32 2
  %t676 = load { i64, ptr }, ptr %t675
  %t677 = extractvalue { i64, ptr } %t676, 1
  %t678 = call ptr @__olang_region_or(ptr %t677, ptr null)
  %t679 = call ptr @__olang_region_home(ptr %t678)
  %t680 = icmp ne ptr %t679, null
  %t681 = select i1 %t680, ptr %t679, ptr null
  %t682 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l264, i32 0, i32 1
  %t683 = load { i64, ptr }, ptr %t682
  %t684 = extractvalue { i64, ptr } %t683, 1
  %t685 = call ptr @__olang_region_or(ptr %t684, ptr null)
  %t686 = call ptr @__olang_region_home(ptr %t685)
  %t687 = icmp ne ptr %t686, null
  %t688 = select i1 %t687, ptr %t686, ptr %t681
  %t689 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l264, i32 0, i32 0
  %t690 = load { i64, ptr }, ptr %t689
  %t691 = extractvalue { i64, ptr } %t690, 1
  %t692 = call ptr @__olang_region_or(ptr %t691, ptr null)
  %t693 = call ptr @__olang_region_home(ptr %t692)
  %t694 = icmp ne ptr %t693, null
  %t695 = select i1 %t694, ptr %t693, ptr %t688
  %t696 = icmp eq ptr %t695, %t674
  call void @__olang_region_settle(ptr %t674, i1 %t696)
  br label %bb151
bb151:
  %t697 = load ptr, ptr %l261, !tbaa !29
  %t698 = getelementptr %"compiler/effects:Effects", ptr %t697, i32 0, i32 31
  %t699 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t698
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t699, ptr %l266
  %t700 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l264
  %t701 = load ptr, ptr %l261, !tbaa !29
  %t702 = getelementptr %"compiler/effects:Effects", ptr %t701, i32 0, i32 31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t700, ptr %t702
  %t703 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e31
  br i1 %t703, label %bb152, label %bb153
bb152:
  %t705 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l266, i32 0, i32 2
  %t706 = load { i64, ptr }, ptr %t705
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = call ptr @__olang_region_or(ptr %t707, ptr null)
  %t709 = call ptr @__olang_region_home(ptr %t708)
  %t710 = icmp ne ptr %t709, null
  %t711 = select i1 %t710, ptr %t709, ptr null
  %t712 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l266, i32 0, i32 1
  %t713 = load { i64, ptr }, ptr %t712
  %t714 = extractvalue { i64, ptr } %t713, 1
  %t715 = call ptr @__olang_region_or(ptr %t714, ptr null)
  %t716 = call ptr @__olang_region_home(ptr %t715)
  %t717 = icmp ne ptr %t716, null
  %t718 = select i1 %t717, ptr %t716, ptr %t711
  %t719 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l266, i32 0, i32 0
  %t720 = load { i64, ptr }, ptr %t719
  %t721 = extractvalue { i64, ptr } %t720, 1
  %t722 = call ptr @__olang_region_or(ptr %t721, ptr null)
  %t723 = call ptr @__olang_region_home(ptr %t722)
  %t724 = icmp ne ptr %t723, null
  %t725 = select i1 %t724, ptr %t723, ptr %t718
  call void @__olang_region_drop(ptr %t725)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l266
  br label %bb153
bb153:
  %t726 = load ptr, ptr %l2, !tbaa !29
  %t728 = getelementptr %"compiler/typed:Body", ptr %t726, i32 0, i32 19
  store ptr %t728, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb154
bb154:
  %t730 = load i64, ptr %l18, !tbaa !24
  store i64 %t730, ptr %l270, !tbaa !24
  %t731 = load ptr, ptr %l17, !tbaa !29
  %t733 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t731)
  store i64 %t733, ptr %l272
  br label %bb155
bb155:
  %t734 = load i64, ptr %l270, !tbaa !24
  %t735 = load i64, ptr %l272, !tbaa !24
  %t736 = icmp slt i64 %t734, %t735
  %t738 = xor i1 %t736, true
  br i1 %t738, label %bb156, label %bb157
bb156:
  br label %bb162
bb157:
  br label %bb158
bb158:
  %t740 = load ptr, ptr %l17, !tbaa !29
  %t741 = load i64, ptr %l18, !tbaa !24
  %t744 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t740, i64 %t741)
  store i32 %t744, ptr %l277
  br label %bb159
bb159:
  %t745 = load i32, ptr %l277, !tbaa !23
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = getelementptr %"compiler/effects:Effects", ptr %t746, i32 0, i32 31
  %t751 = sext i32 %t745 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t748, i64 %t751, i1 true)
  br label %bb160
bb160:
  br label %bb161
bb161:
  %t754 = load i64, ptr %l18, !tbaa !24
  %t756 = add i64 %t754, 1
  store i64 %t756, ptr %l18, !tbaa !24
  br label %bb154
bb162:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l284, !tbaa !29
  %t759 = load ptr, ptr %l2, !tbaa !29
  %t761 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eDropsRun(ptr %v0, ptr %v0, ptr %t759)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t761, ptr %l286
  br label %bb163
bb163:
  %t762 = load ptr, ptr %l284, !tbaa !29
  %t763 = getelementptr %"compiler/effects:Effects", ptr %t762, i32 0, i32 32
  %t764 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t763
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t764, ptr %l287
  %t765 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l286
  %t766 = load ptr, ptr %l284, !tbaa !29
  %t767 = getelementptr %"compiler/effects:Effects", ptr %t766, i32 0, i32 32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t765, ptr %t767
  %t768 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3aEffects_2e32
  br i1 %t768, label %bb164, label %bb165
bb164:
  %t770 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l287, i32 0, i32 2
  %t771 = load { i64, ptr }, ptr %t770
  %t772 = extractvalue { i64, ptr } %t771, 1
  %t773 = call ptr @__olang_region_or(ptr %t772, ptr null)
  %t774 = call ptr @__olang_region_home(ptr %t773)
  %t775 = icmp ne ptr %t774, null
  %t776 = select i1 %t775, ptr %t774, ptr null
  %t777 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l287, i32 0, i32 1
  %t778 = load { i64, ptr }, ptr %t777
  %t779 = extractvalue { i64, ptr } %t778, 1
  %t780 = call ptr @__olang_region_or(ptr %t779, ptr null)
  %t781 = call ptr @__olang_region_home(ptr %t780)
  %t782 = icmp ne ptr %t781, null
  %t783 = select i1 %t782, ptr %t781, ptr %t776
  %t784 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l287, i32 0, i32 0
  %t785 = load { i64, ptr }, ptr %t784
  %t786 = extractvalue { i64, ptr } %t785, 1
  %t787 = call ptr @__olang_region_or(ptr %t786, ptr null)
  %t788 = call ptr @__olang_region_home(ptr %t787)
  %t789 = icmp ne ptr %t788, null
  %t790 = select i1 %t789, ptr %t788, ptr %t783
  call void @__olang_region_drop(ptr %t790)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l287
  br label %bb165
bb165:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = load i64, ptr %l1, !tbaa !24
  %t795 = getelementptr %"compiler/effects:Effects", ptr %t791, i32 0, i32 33
  store i64 %t792, ptr %t795, !tbaa !24
  %t796 = load ptr, ptr %l0, !tbaa !29
  store ptr %t796, ptr %l291, !tbaa !29
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/effects:Effects", ptr %t797, i32 0, i32 16
  %t800 = load ptr, ptr %l2, !tbaa !29
  %t802 = getelementptr %"compiler/typed:Body", ptr %t800, i32 0, i32 3
  %t803 = load i64, ptr %t802, !tbaa !24
  %t806 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t799, i64 %t803)
  %t807 = extractvalue { i32, i64 } %t806, 1
  %t808 = extractvalue { i32, i64 } %t806, 0
  store i32 %t808, ptr %l298
  %t809 = icmp ne i32 %t808, 0
  br i1 %t809, label %bb167, label %ok.810, !prof !99
ok.810:
  store i64 %t807, ptr %l297
  br label %bb166
bb166:
  %t811 = load i64, ptr %l297, !tbaa !24
  store i64 %t811, ptr %l292, !tbaa !24
  br label %bb169
bb167:
  br label %bb168
bb168:
  store i64 -1, ptr %l292, !tbaa !24
  br label %bb169
bb169:
  %t812 = load i64, ptr %l292, !tbaa !24
  %t813 = load ptr, ptr %l291, !tbaa !29
  %t814 = getelementptr %"compiler/effects:Effects", ptr %t813, i32 0, i32 34
  store i64 %t812, ptr %t814, !tbaa !24
  %t815 = load ptr, ptr %l2, !tbaa !29
  %t817 = getelementptr %"compiler/typed:Body", ptr %t815, i32 0, i32 11
  %t818 = load ptr, ptr %t817, !tbaa !29
  %t820 = icmp eq ptr %t818, null
  br i1 %t820, label %bb170, label %bb171
bb170:
  %t822 = load ptr, ptr %l2, !tbaa !29
  %t824 = getelementptr %"compiler/typed:Body", ptr %t822, i32 0, i32 1
  %t825 = load { i64, [2 x i64] }, ptr %t824
  %t829 = extractvalue { i64, [2 x i64] } %t825, 0
  %t830 = icmp eq i64 %t829, 2
  br i1 %t830, label %bb172, label %bb173
bb171:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ekeptLocals(ptr %v0, ptr %v0, ptr %t832, ptr %t833)
  br label %bb181
bb172:
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb180
bb175:
  br i1 true, label %bb176, label %bb177
bb176:
  br label %bb178
bb177:
  br label %bb179
bb178:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t838 = getelementptr %"compiler/effects:Effects", ptr %t836, i32 0, i32 23
  %t839 = getelementptr %"compiler/effects:Facts", ptr %t838, i32 0, i32 14
  store i1 true, ptr %t839, !tbaa !21
  br label %bb180
bb179:
  call void @__olang_check_failed(ptr @olang_loc_1339f6fe14a38149_c7d1650dc39f436d)
  unreachable
bb180:
  br label %bb183
bb181:
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t841 = load ptr, ptr %l2, !tbaa !29
  %t843 = getelementptr %"compiler/typed:Body", ptr %t841, i32 0, i32 11
  %t844 = load ptr, ptr %t843, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eblock(ptr %v0, ptr %v0, ptr %t840, ptr %t844)
  br label %bb182
bb182:
  br label %bb183
bb183:
  %t847 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efinish(ptr %v0, ptr %t847)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyDoes(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/effects:Facts"
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Effects", ptr %t1, i32 0, i32 23
  %t4 = load %"compiler/effects:Facts", ptr %t3
  store %"compiler/effects:Facts" %t4, ptr %l1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/effects:Effects", ptr %t7, i32 0, i32 33
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 21
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritesUnowned(ptr %v0, ptr %t6, i64 %t10, i64 %t12)
  store i1 %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t18 = getelementptr %"compiler/effects:Facts", ptr %l1, i32 0, i32 18
  store i1 true, ptr %t18, !tbaa !21
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/effects:Effects", ptr %t19, i32 0, i32 47
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %s0, ptr %v1, ptr %l1, i64 %t22)
  store { i64, ptr } %t25, ptr %l12
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/effects:root"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca i1
  %l26 = alloca %"compiler/effects:root"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estore(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb48
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eglobalReached(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i1 %t39, ptr %l22
  br label %bb13
bb13:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/effects:Effects", ptr %t41, i32 0, i32 23
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t43, i32 0, i32 3
  store i1 true, ptr %t44, !tbaa !21
  br label %ret
bb15:
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call %"compiler/effects:root" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eplaceRoot(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store %"compiler/effects:root" %t49, ptr %l26
  br label %bb17
bb17:
  %t50 = load %"compiler/effects:root", ptr %l26
  store %"compiler/effects:root" %t50, ptr %l4
  %t51 = getelementptr %"compiler/effects:root", ptr %l4, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = icmp sge i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:root", ptr %l4, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethrough(ptr %v0, ptr %t56, i64 %t58)
  br label %bb20
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Effects", ptr %t61, i32 0, i32 23
  %t64 = getelementptr %"compiler/effects:Facts", ptr %t63, i32 0, i32 17
  store i1 true, ptr %t64, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb48
bb22:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 18}
  %t72 = icmp eq i64 %t70, 17
  store i1 %t72, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l33, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritten(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb28
bb28:
  br label %bb48
bb29:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t85 = load ptr, ptr %l40, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l41, !tbaa !21
  br label %bb31
bb31:
  %t92 = load i1, ptr %l41, !tbaa !21
  br i1 %t92, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb34, label %bb35
bb34:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 7
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb35
bb35:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb36, label %bb37
bb36:
  br label %bb42
bb37:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t103 = load ptr, ptr %l48, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb38, label %bb39
bb38:
  %t106 = load ptr, ptr %l48, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 0
  store i1 %t109, ptr %l49, !tbaa !21
  br label %bb39
bb39:
  %t110 = load i1, ptr %l49, !tbaa !21
  br i1 %t110, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/effects:Effects", ptr %t111, i32 0, i32 23
  %t114 = getelementptr %"compiler/effects:Facts", ptr %t113, i32 0, i32 17
  store i1 true, ptr %t114, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_b365fbc2fc2a8203_e371dcb77fb488d7)
  unreachable
bb48:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb13
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/effects:Facts", ptr %t11, i32 0, i32 1
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/effects:Facts", ptr %t17, i32 0, i32 10
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/effects:Facts", ptr %t23, i32 0, i32 14
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb93
bb13:
  %t29 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t31 = trunc i64 1 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/effects:Facts", ptr %t34, i32 0, i32 0
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb19
bb18:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/effects:Facts", ptr %t39, i32 0, i32 10
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb22
bb21:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/effects:Facts", ptr %t45, i32 0, i32 14
  %t48 = load i1, ptr %t47, !tbaa !21
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb22
bb22:
  %t50 = load i1, ptr %l23, !tbaa !21
  store i1 %t50, ptr %l2, !tbaa !21
  br label %bb93
bb23:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t53 = trunc i64 2 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb33
bb26:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/effects:Facts", ptr %t56, i32 0, i32 2
  %t59 = load i1, ptr %t58, !tbaa !21
  br i1 %t59, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb29
bb28:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/effects:Facts", ptr %t61, i32 0, i32 10
  %t64 = load i1, ptr %t63, !tbaa !21
  store i1 %t64, ptr %l30, !tbaa !21
  br label %bb29
bb29:
  %t66 = load i1, ptr %l30, !tbaa !21
  br i1 %t66, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb32
bb31:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/effects:Facts", ptr %t67, i32 0, i32 14
  %t70 = load i1, ptr %t69, !tbaa !21
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb32
bb32:
  %t72 = load i1, ptr %l33, !tbaa !21
  store i1 %t72, ptr %l2, !tbaa !21
  br label %bb93
bb33:
  %t73 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t75 = trunc i64 3 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb43
bb36:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Facts", ptr %t78, i32 0, i32 3
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb39
bb38:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/effects:Facts", ptr %t83, i32 0, i32 10
  %t86 = load i1, ptr %t85, !tbaa !21
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb39
bb39:
  %t88 = load i1, ptr %l40, !tbaa !21
  br i1 %t88, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb42
bb41:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/effects:Facts", ptr %t89, i32 0, i32 14
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l43, !tbaa !21
  br label %bb42
bb42:
  %t94 = load i1, ptr %l43, !tbaa !21
  store i1 %t94, ptr %l2, !tbaa !21
  br label %bb93
bb43:
  %t95 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t97 = trunc i64 4 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb53
bb46:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/effects:Facts", ptr %t100, i32 0, i32 5
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb49
bb48:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/effects:Facts", ptr %t105, i32 0, i32 10
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l50, !tbaa !21
  br label %bb49
bb49:
  %t110 = load i1, ptr %l50, !tbaa !21
  br i1 %t110, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb52
bb51:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/effects:Facts", ptr %t111, i32 0, i32 14
  %t114 = load i1, ptr %t113, !tbaa !21
  store i1 %t114, ptr %l53, !tbaa !21
  br label %bb52
bb52:
  %t116 = load i1, ptr %l53, !tbaa !21
  store i1 %t116, ptr %l2, !tbaa !21
  br label %bb93
bb53:
  %t117 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t119 = trunc i64 5 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb63
bb56:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/effects:Facts", ptr %t122, i32 0, i32 7
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb59
bb58:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/effects:Facts", ptr %t127, i32 0, i32 10
  %t130 = load i1, ptr %t129, !tbaa !21
  store i1 %t130, ptr %l60, !tbaa !21
  br label %bb59
bb59:
  %t132 = load i1, ptr %l60, !tbaa !21
  br i1 %t132, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb62
bb61:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/effects:Facts", ptr %t133, i32 0, i32 14
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb62
bb62:
  %t138 = load i1, ptr %l63, !tbaa !21
  store i1 %t138, ptr %l2, !tbaa !21
  br label %bb93
bb63:
  %t139 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t141 = trunc i64 6 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb73
bb66:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/effects:Facts", ptr %t144, i32 0, i32 8
  %t147 = load i1, ptr %t146, !tbaa !21
  br i1 %t147, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb69
bb68:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/effects:Facts", ptr %t149, i32 0, i32 10
  %t152 = load i1, ptr %t151, !tbaa !21
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb69
bb69:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb72
bb71:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/effects:Facts", ptr %t155, i32 0, i32 14
  %t158 = load i1, ptr %t157, !tbaa !21
  store i1 %t158, ptr %l73, !tbaa !21
  br label %bb72
bb72:
  %t160 = load i1, ptr %l73, !tbaa !21
  store i1 %t160, ptr %l2, !tbaa !21
  br label %bb93
bb73:
  %t161 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t163 = trunc i64 7 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t166)
  store i1 %t168, ptr %l79
  br label %bb77
bb77:
  %t169 = load i1, ptr %l79, !tbaa !21
  store i1 %t169, ptr %l2, !tbaa !21
  br label %bb93
bb78:
  %t170 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t172 = trunc i64 8 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2ePure(ptr %v0, ptr %t175)
  store i1 %t177, ptr %l83
  br label %bb82
bb82:
  %t178 = load i1, ptr %l83, !tbaa !21
  store i1 %t178, ptr %l2, !tbaa !21
  br label %bb93
bb83:
  %t179 = load i32, ptr %l1, !range !{i32 0, i32 11}
  %t181 = trunc i64 9 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eReturns(ptr %v0, ptr %t184)
  store i1 %t186, ptr %l87
  br label %bb87
bb87:
  %t187 = load i1, ptr %l87, !tbaa !21
  store i1 %t187, ptr %l2, !tbaa !21
  br label %bb93
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_5b8067b2e95ea30f_d9100a71d97bc52b)
  unreachable
bb93:
  %t188 = load i1, ptr %l2, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 1
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 2
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 3
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 5
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 7
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Facts", ptr %t36, i32 0, i32 10
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t42, i32 0, i32 12
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/effects:Facts", ptr %t48, i32 0, i32 14
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/effects:Facts", ptr %t55, i32 0, i32 13
  %t58 = load i1, ptr %t57, !tbaa !21
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb28, label %bb29
bb28:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/effects:Facts", ptr %t62, i32 0, i32 19
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp eq i64 %t65, 0
  store i1 %t67, ptr %l31, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb30
bb30:
  %t69 = load i1, ptr %l31, !tbaa !21
  br i1 %t69, label %bb31, label %bb32
bb31:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Facts", ptr %t70, i32 0, i32 21
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l35, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb33
bb33:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb34, label %bb35
bb34:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Facts", ptr %t78, i32 0, i32 22
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb36
bb36:
  %t85 = load i1, ptr %l39, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2ePure(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 18
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 3
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 17
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 5
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 10
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/effects:Facts", ptr %t36, i32 0, i32 11
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/effects:Facts", ptr %t42, i32 0, i32 14
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 19
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  %t55 = xor i64 %t53, -1
  %t58 = and i64 %t52, %t55
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 9
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 8
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/effects:Facts", ptr %t12, i32 0, i32 10
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/effects:Facts", ptr %t18, i32 0, i32 2
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/effects:Facts", ptr %t24, i32 0, i32 6
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/effects:Facts", ptr %t30, i32 0, i32 14
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eendsNote(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eTerminates(ptr %v0, ptr %t22)
  store i1 %t24, ptr %l8
  br label %bb4
bb4:
  %t25 = load i1, ptr %l8, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l15, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2feffects_2eimpure(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/effects:Facts", ptr %t6, i32 0, i32 11
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l8, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/effects:Facts", ptr %t28, i32 0, i32 3
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/effects:Facts", ptr %t49, i32 0, i32 4
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t54, ptr %l19, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l20, !tbaa !24
  %t57 = load i64, ptr %l20, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l21, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l20, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t68, ptr %l19, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/effects:Facts", ptr %t70, i32 0, i32 18
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/effects:Facts", ptr %t75, i32 0, i32 17
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l24, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l28, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l29, !tbaa !24
  %t84 = load i64, ptr %l29, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l30, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l29, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t95, ptr %l28, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/effects:Facts", ptr %t97, i32 0, i32 5
  %t100 = load i1, ptr %t99, !tbaa !21
  br i1 %t100, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/effects:Facts", ptr %t102, i32 0, i32 19
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load i64, ptr @G_2ecompiler_2feffects_2eCapThreads, !tbaa !24
  %t108 = xor i64 %t106, -1
  %t111 = and i64 %t105, %t108
  %t113 = icmp ne i64 %t111, 0
  store i1 %t113, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i1, ptr %l33, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t116, ptr %l41, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l42, !tbaa !24
  %t119 = load i64, ptr %l42, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l43, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l42, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t130, ptr %l41, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t132, ptr %l45, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l46, !tbaa !24
  %t135 = load i64, ptr %l46, !tbaa !24
  %t136 = mul i64 %t135, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l47, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l46, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  %t146 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t146, ptr %l45, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2feffects_2eparamBit(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp slt i64 %t5, 63
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l0, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = shl i64 1, %t12
  store i64 %t13, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t15 = load i64, ptr %l6, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feffects_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2feffects_2eparamOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l18
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t23 = load ptr, ptr %l19, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t36 = load ptr, ptr %l25, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l26, !tbaa !21
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l3, !tbaa !23
  br label %bb26
bb16:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t84, i32 0, i32 2
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l3, !tbaa !23
  br label %bb26
bb25:
  br label %bb44
bb26:
  store i64 0, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 5
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l47
  br label %bb27
bb27:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb33
bb30:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb32
bb32:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb33
bb33:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l7, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t130 = load i64, ptr %l4, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l9, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 5
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t142, i64 %t143)
  store i32 %t146, ptr %l75
  br label %bb38
bb38:
  %t147 = load i32, ptr %l3, !tbaa !23
  %t148 = load i32, ptr %l75, !tbaa !23
  %t150 = icmp eq i32 %t148, %t147
  br i1 %t150, label %bb39, label %bb40
bb39:
  %t152 = load i64, ptr %l9, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_bef23b7223d78d87_3941411f391512b)
  unreachable
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feffects_2equickC(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2feffects_2equickNames, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t2 = load ptr, ptr %l1
  store i64 26, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = getelementptr [26 x { i64, ptr }], ptr %t13, i64 0, i64 %t14
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !37
  %t22 = load ptr, ptr @__olang_prog_scope
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t22, { i64, ptr } %a0, { i64, ptr } %t18)
  store i1 %t25, ptr %l17
  br label %bb5
bb5:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2feffects_2estmtSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 15
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 1
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb79
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 17}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 17}
  %t85 = icmp eq i64 %t83, 4
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 17}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 16
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb79
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 17}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 17}
  %t147 = icmp eq i64 %t145, 5
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 17}
  %t162 = icmp eq i64 %t160, 7
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 17}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb79
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 17}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb71
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 9
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb71
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 10
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb71
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 13
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t247 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t247, ptr %l6
  br label %bb79
bb72:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t250 = load ptr, ptr %l107, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l107, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 17}
  %t256 = icmp eq i64 %t254, 14
  store i1 %t256, ptr %l108, !tbaa !21
  br label %bb74
bb74:
  %t257 = load i1, ptr %l108, !tbaa !21
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 0
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l5
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t264 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t264, ptr %l6
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_f9d1419be2a6bd97_a466df32bbf19e6b)
  unreachable
bb79:
  %t266 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t266, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/effects:Facts"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x i64] undef, i64 -1, 0
  %t2 = insertvalue [6 x i64] %t1, i64 -1, 1
  %t3 = insertvalue [6 x i64] %t2, i64 -1, 2
  %t4 = insertvalue [6 x i64] %t3, i64 -1, 3
  %t5 = insertvalue [6 x i64] %t4, i64 -1, 4
  %t6 = insertvalue [6 x i64] %t5, i64 -1, 5
  %t9 = insertvalue %"compiler/effects:Facts" undef, i1 false, 0
  %t11 = insertvalue %"compiler/effects:Facts" %t9, i1 false, 1
  %t13 = insertvalue %"compiler/effects:Facts" %t11, i1 false, 2
  %t15 = insertvalue %"compiler/effects:Facts" %t13, i1 false, 3
  %t17 = insertvalue %"compiler/effects:Facts" %t15, i1 false, 4
  %t19 = insertvalue %"compiler/effects:Facts" %t17, i1 false, 5
  %t21 = insertvalue %"compiler/effects:Facts" %t19, i1 false, 6
  %t23 = insertvalue %"compiler/effects:Facts" %t21, i1 false, 7
  %t25 = insertvalue %"compiler/effects:Facts" %t23, i1 false, 8
  %t27 = insertvalue %"compiler/effects:Facts" %t25, i1 false, 9
  %t29 = insertvalue %"compiler/effects:Facts" %t27, i1 false, 10
  %t31 = insertvalue %"compiler/effects:Facts" %t29, i1 false, 11
  %t33 = insertvalue %"compiler/effects:Facts" %t31, i1 false, 12
  %t35 = insertvalue %"compiler/effects:Facts" %t33, i1 false, 13
  %t37 = insertvalue %"compiler/effects:Facts" %t35, i1 false, 14
  %t39 = insertvalue %"compiler/effects:Facts" %t37, i1 false, 15
  %t41 = insertvalue %"compiler/effects:Facts" %t39, i1 false, 16
  %t43 = insertvalue %"compiler/effects:Facts" %t41, i1 false, 17
  %t45 = insertvalue %"compiler/effects:Facts" %t43, i1 false, 18
  %t47 = insertvalue %"compiler/effects:Facts" %t45, i64 0, 19
  %t49 = insertvalue %"compiler/effects:Facts" %t47, [6 x i64] %t6, 20
  %t51 = insertvalue %"compiler/effects:Facts" %t49, i64 0, 21
  %t53 = insertvalue %"compiler/effects:Facts" %t51, i64 0, 22
  store %"compiler/effects:Facts" %t53, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Facts", ptr %rv
  ret %"compiler/effects:Facts" %rr
}

define dso_local %"compiler/effects:Verdict" @compiler_2feffects_3aVerdict_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %rv = alloca %"compiler/effects:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  store i1 true, ptr %l2, !tbaa !21
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l19, !tbaa !24
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t47, ptr %l4, !tbaa !27
  store i64 -1, ptr %l5, !tbaa !24
  %t48 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t48, ptr %l21
  br label %bb1
bb1:
  %t49 = load %"compiler/source:Span", ptr %l21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t50, ptr %l23, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l24, !tbaa !24
  %t53 = load i64, ptr %l24, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l25, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l24, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = insertvalue %"compiler/effects:Verdict" undef, { i64, ptr } %t65, 0
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = insertvalue %"compiler/effects:Verdict" %t66, { i64, ptr } %t67, 1
  %t69 = load i1, ptr %l2, !tbaa !21
  %t70 = insertvalue %"compiler/effects:Verdict" %t68, i1 %t69, 2
  %t71 = load i32, ptr %l3, !tbaa !23
  %t72 = insertvalue %"compiler/effects:Verdict" %t70, i32 %t71, 3
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t74 = insertvalue %"compiler/effects:Verdict" %t72, { i64, ptr } %t73, 4
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = insertvalue %"compiler/effects:Verdict" %t74, i64 %t75, 5
  %t78 = insertvalue %"compiler/effects:Verdict" %t76, %"compiler/source:Span" %t49, 6
  %t80 = insertvalue %"compiler/effects:Verdict" %t78, { i64, ptr } %t64, 7
  store %"compiler/effects:Verdict" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define dso_local %"compiler/effects:coldMark" @compiler_2feffects_3acoldMark_2ector(ptr %v0, i64 %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:coldMark"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:coldMark" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/effects:coldMark" %t6, i1 %a1, 1
  store %"compiler/effects:coldMark" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:coldMark", ptr %rv
  ret %"compiler/effects:coldMark" %rr
}

define dso_local %"compiler/effects:fpath" @compiler_2feffects_3afpath_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:fpath"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:fpath" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t8 = insertvalue %"compiler/effects:fpath" %t6, i32 %a1, 1
  store %"compiler/effects:fpath" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fpath", ptr %rv
  ret %"compiler/effects:fpath" %rr
}

define dso_local %"compiler/effects:fret" @compiler_2feffects_3afret_2ector(ptr %v0, ptr %v1, ptr %v2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %rv = alloca %"compiler/effects:fret"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/effects:fret" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t8 = insertvalue %"compiler/effects:fret" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  store %"compiler/effects:fret" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fret", ptr %rv
  ret %"compiler/effects:fret" %rr
}

define dso_local %"compiler/effects:given" @compiler_2feffects_3agiven_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:given"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l5, !tbaa !24
  store i64 %a1, ptr %l6, !tbaa !24
  store i64 %a2, ptr %l7, !tbaa !24
  store i64 %a3, ptr %l8, !tbaa !24
  store i32 %a4, ptr %l9, !tbaa !23
  %t11 = ptrtoint ptr %v0 to i64
  store i64 %t11, ptr %l17, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = call ptr @__olang_region_make(ptr %v0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l17, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l17
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t17, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l19
  br label %bb3
bb3:
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3agiven_2e5
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l17
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr null
  %t30 = icmp eq ptr %t29, %t22
  call void @__olang_region_settle(ptr %t22, i1 %t30)
  br label %bb5
bb5:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = insertvalue %"compiler/effects:given" undef, i64 %t32, 0
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = insertvalue %"compiler/effects:given" %t33, i64 %t34, 1
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = insertvalue %"compiler/effects:given" %t35, i64 %t36, 2
  %t38 = load i64, ptr %l8, !tbaa !24
  %t39 = insertvalue %"compiler/effects:given" %t37, i64 %t38, 3
  %t40 = load i32, ptr %l9, !tbaa !23
  %t41 = insertvalue %"compiler/effects:given" %t39, i32 %t40, 4
  %t43 = insertvalue %"compiler/effects:given" %t41, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, 5
  %t45 = insertvalue %"compiler/effects:given" %t43, i64 -1, 6
  store %"compiler/effects:given" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:given", ptr %rv
  ret %"compiler/effects:given" %rr
}

define dso_local %"compiler/effects:part" @compiler_2feffects_3apart_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:part"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i32 %a2, ptr %l6, !tbaa !23
  store ptr %a3, ptr %l7, !tbaa !29
  %t9 = ptrtoint ptr %v1 to i64
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = call ptr @__olang_region_make(ptr %v1)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l14, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l14
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t15, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l16
  br label %bb3
bb3:
  %t17 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apart_2e4
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l14
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr null
  %t28 = icmp eq ptr %t27, %t20
  call void @__olang_region_settle(ptr %t20, i1 %t28)
  br label %bb5
bb5:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = insertvalue %"compiler/effects:part" undef, i64 %t30, 0
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = insertvalue %"compiler/effects:part" %t31, i64 %t32, 1
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = insertvalue %"compiler/effects:part" %t33, i32 %t34, 2
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t37 = insertvalue %"compiler/effects:part" %t35, ptr %t36, 3
  %t39 = insertvalue %"compiler/effects:part" %t37, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, 4
  %t41 = insertvalue %"compiler/effects:part" %t39, i64 -1, 5
  store %"compiler/effects:part" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

define dso_local %"compiler/effects:pend" @compiler_2feffects_3apend_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:pend"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = ptrtoint ptr %v1 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apend_2e3
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_region_make(ptr %v1)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l10
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t13, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l12
  br label %bb3
bb3:
  %t15 = load i1, ptr @olang_2esole_2ecompiler_2feffects_3apend_2e3
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l10
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr null)
  %t23 = call ptr @__olang_region_home(ptr %t22)
  %t24 = icmp ne ptr %t23, null
  %t25 = select i1 %t24, ptr %t23, ptr null
  %t26 = icmp eq ptr %t25, %t18
  call void @__olang_region_settle(ptr %t18, i1 %t26)
  br label %bb5
bb5:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = insertvalue %"compiler/effects:pend" undef, i64 %t28, 0
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = insertvalue %"compiler/effects:pend" %t29, i64 %t30, 1
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t33 = insertvalue %"compiler/effects:pend" %t31, ptr %t32, 2
  %t35 = insertvalue %"compiler/effects:pend" %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, 3
  store %"compiler/effects:pend" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:pend", ptr %rv
  ret %"compiler/effects:pend" %rr
}

@.d0 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"reach code that did not check" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"allocate" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"block" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"start a task" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"call C" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"call through a function value it does not follow, which may lead back to it" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call itself" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"compiler/effects:Verdict" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3aVerdict(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:Verdict"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca %"compiler/effects:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:Verdict", ptr %a0
  store %"compiler/effects:Verdict" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 4
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l11, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l13, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t70 = getelementptr %"compiler/effects:Verdict", ptr %l1, i32 0, i32 7
  store { i64, ptr } %t69, ptr %t70, !tbaa !27
  %t71 = load %"compiler/effects:Verdict", ptr %l1
  store %"compiler/effects:Verdict" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:Verdict", ptr %rv
  ret %"compiler/effects:Verdict" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:part"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:part"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:part", ptr %a0
  store %"compiler/effects:part" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:part", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:part", ptr %l1
  store %"compiler/effects:part" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:part", ptr %rv
  ret %"compiler/effects:part" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"this value's Call" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"this lambda" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e4 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
@olang_2esole_2ecompiler_2feffects_3aEffects_2e48 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e7 = weak hidden constant i1 false
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a lambda" }>, align 8
@.d22 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a constructor" }>, align 8
@.d23 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a destructor" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a body" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fslot"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fslot"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fslot", ptr %a0
  store %"compiler/effects:fslot" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fslot", ptr %l1
  store %"compiler/effects:fslot" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fslot", ptr %rv
  ret %"compiler/effects:fslot" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fpath"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fpath"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fpath", ptr %a0
  store %"compiler/effects:fpath" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fpath", ptr %l1
  store %"compiler/effects:fpath" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fpath", ptr %rv
  ret %"compiler/effects:fpath" %rr
}

@olang_2esole_2ecompiler_2feffects_3afslot_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_home(ptr)
define linkonce_odr %"compiler/effects:pend" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apend(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:pend"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:pend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:pend", ptr %a0
  store %"compiler/effects:pend" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:pend", ptr %l1, i32 0, i32 3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:pend", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:pend", ptr %l1
  store %"compiler/effects:pend" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:pend", ptr %rv
  ret %"compiler/effects:pend" %rr
}

@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3aVerdict_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2feffects_3aEffects_2e24 = weak hidden constant i1 false
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2feffects_3aEffects_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e29 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e31 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3aEffects_2e32 = weak hidden constant i1 false
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"; recursive" }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"; always ends" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"call through a function value or an 'any', which may do anything" }>, align 8
@.d30 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"write a global" }>, align 8
@.d31 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"read a global that changes" }>, align 8
@.d32 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"write through what it was not given writably" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"call C" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2feffects_3agiven_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3apart_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feffects_3apend_2e3 = weak hidden constant i1 false
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3apart_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:part"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 72
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:part", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:part" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3apart(ptr %v0, ptr %t15)
  store %"compiler/effects:part" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:part", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:part", ptr %t22, i64 %t20
  store %"compiler/effects:part" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:given"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 80
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:given", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %t15)
  store %"compiler/effects:given" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:given", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:given", ptr %t22, i64 %t20
  store %"compiler/effects:given" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fslot"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 48
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fslot", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %t15)
  store %"compiler/effects:fslot" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fslot", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fslot", ptr %t22, i64 %t20
  store %"compiler/effects:fslot" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fpath"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fpath", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %t15)
  store %"compiler/effects:fpath" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fpath", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fpath", ptr %t22, i64 %t20
  store %"compiler/effects:fpath" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:given"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:given"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:given", ptr %a0
  store %"compiler/effects:given" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:given", ptr %l1
  store %"compiler/effects:given" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:given", ptr %rv
  ret %"compiler/effects:given" %rr
}

@G_2ecompiler_2ftypes_2ePromNoalloc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoblock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNospawn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromNoextern = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapThreads = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2ePromReturns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2feffects_2enotReturning(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2ePromPure = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eCapCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feffects_2eEffectWords = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\7F\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eClear_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassify(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eLen_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:part" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2eAt_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ejudgeFacts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2feffects_2eGivSlot = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2eGivBound = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eslotType(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2feffects_2eGivNamed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feffects_2ePartAdapter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feffects_2ehasBit(i64 %a0, i64 %a1)
@G_2ecompiler_2feffects_2ePartLambda = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cce6b986552578d0_26bb880b6e07dfc = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2elambdaFacts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eextern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7ef30bd5545b1b3f_da1c1797c8787b93 = external constant [0 x i8]
@olang_loc_4055e0fe87b920f9_59f1ceb8b6607d = external constant [0 x i8]
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @compiler_2ftyped_2eFails(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewhyStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_480f10282bdc13cf_4349ffb73b811f6b = external constant [0 x i8]
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7b34d2d8e55697dbed551519dd59c955(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eLen_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:given" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eAt_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2eFacts_2eBound(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinksOwnC(ptr %v0, ptr %a0)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ehasExport(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ePush_3ccompiler_2feffects_3apart_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:part" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H812d4871fea5544bd17001c04038a9fe(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0900524597b2264f5a31dc7ea3fca989(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eclassifyInst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i64 %a4)
declare %"compiler/effects:coldMark" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldOpen(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecoldClose(ptr %v0, ptr %a0, %"compiler/effects:coldMark" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eisFn(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc680bc8b736298027ff580de04f60380(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hfb9e5165fbc860148668cf342d052cc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_12d41178ea699117_cd5c06b5e62ab993 = external constant [0 x i8]
@olang_loc_bfb31f4e096fcfdd_9eff6572189cd471 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einstType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bdb589e9fb60a385_99895746a144f341 = external constant [0 x i8]
@olang_loc_6c2f84c28d80f803_c1ff4c3310f9a27 = external constant [0 x i8]
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2erootBits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ebuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2edtorCalled(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a95aecd22ff58df7_af716a2d87a126b3 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earmsExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a0f9105d1bd497f9_bea5821deca669ad = external constant [0 x i8]
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ereadOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2einPlace(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_949627fca0824f08_4c3b1084581425e4 = external constant [0 x i8]
@olang_loc_ca5d43677e660e3e_842659f2ce3d2d4a = external constant [0 x i8]
@olang_loc_b6aab166389be830_fe1a1964ddaa5424 = external constant [0 x i8]
@olang_loc_28b83159130c3f56_5f8d6e7786c968a = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eLen_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:fslot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2eAt_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eEq_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H3f7eb4254a4c517352479452f11f6219(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc098dfa5961f28f78d4c086fb0a8b3d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2estructOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epaths(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eLen_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:fpath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e_2eAt_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/effects:fslot" @compiler_2feffects_3afslot_2ector(ptr %v0, ptr %v1, i64 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e_2ePush_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:fslot" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hafeff049746af34a0f4960f24da5119b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eLen_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:pend" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eAt_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eoutsJudged(ptr %v0, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eretFields(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eGivMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_e33fbd58e0454875_653468874e31cf21 = external constant [0 x i8]
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecaptureSlot(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2ePush_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/effects:pend" %a1)
@olang_loc_d8634726df7208f7_383307572af5b0b3 = external constant [0 x i8]
@olang_loc_994d18a8c74b163b_1372ae1002f7258f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2ePush_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, %"compiler/effects:Facts" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H691765597a1d0d55e0f84306543aa643(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apart_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2feffects_2eGivResField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2efieldParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/effects:pair" @compiler_2feffects_3apair_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H7835af935af759534f3892df019d3666(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H5e2f333902255d77192898689554d128(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_Ha1bc2f35f7d195c0ca99c509224bae7a(ptr %v0, ptr %a0, %"compiler/effects:pair" %a1, i1 %a2)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@G_2ecompiler_2feffects_2eoutParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eoutLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\FC\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hec46674a538af874724ad5c9698b0829(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eLen_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0)
declare %"compiler/effects:link" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eAt_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feffects_2eglobalParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eRefMut_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_8e774b84f9d07387_321b570aadbfd9f3 = external constant [0 x i8]
declare %"compiler/effects:root" @compiler_2feffects_3aroot_2ector(ptr %v0, i64 %a0, i1 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_def19e55677a13ff_78d59d2dfbb79d83 = external constant [0 x i8]
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eresField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i64 %a4)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2escanTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_376d296af4c830bb_f1e6df173964d75f = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eSetAt_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/effects:Facts" %a2)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2epassCalls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ewritesUnowned(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ecallsThrough(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ethroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6bf1b4bd1b6b313_44dd2df342c09ca7 = external constant [0 x i8]
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eexpand(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hca3b6abf349bf7326560c41fbdf5fb42(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Had7562134349141a1e65e244951d3fe8(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H17d172c890106e7669720f11d3813b09(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e_2eClear_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3apend_3e_2eClear_3ccompiler_2feffects_3apend_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H0398947fe830469ce1a64c5da7c2d54d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eClear_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eDropsRun(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2feffects_2ecompiler_2feffects_3aEffects_2ekeptLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1339f6fe14a38149_c7d1650dc39f436d = external constant [0 x i8]
@olang_loc_b365fbc2fc2a8203_e371dcb77fb488d7 = external constant [0 x i8]
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eReturns(ptr %v0, ptr %a0)
@olang_loc_5b8067b2e95ea30f_d9100a71d97bc52b = external constant [0 x i8]
@olang_loc_bef23b7223d78d87_3941411f391512b = external constant [0 x i8]
@G_2ecompiler_2feffects_2equickNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@olang_loc_f9d1419be2a6bd97_a466df32bbf19e6b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
